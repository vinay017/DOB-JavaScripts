﻿///====================================================================
/// Name        :   Elevator Safety Task Form Scripts 
/// Description :   This will have All Methods for Elevator Safety Task form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyTask.js
/// Author      :   
///====================================================================
var DOB = window.DOB || {};
DOB.ElevatorSafetyTask = function () {
    function onLoad() {
        setTaskForm();
        showHideSections();
        actionOnChange();
        qaReviewActionOptionsSet();
    }
    function actionOnChange(executionContext) {
        try {
            var attribute, results;
            if (executionContext) {
                attribute = executionContext.getEventSource();
            }
            else if (Xrm.Page.getAttribute("dobnyc_est_reportstatus").getValue() == 2) {
                attribute = Xrm.Page.getAttribute('dobnyc_est_elv3qasupervisoraction');
            }
            else if (Xrm.Page.getAttribute("dobnyc_est_reportstatus").getValue() == 3) {
                attribute = Xrm.Page.getAttribute('dobnyc_est_elv3qareviewaction');
            }
            if (attribute.getName() == 'dobnyc_est_elv3qasupervisoraction') {
                switch (attribute.getValue()) {
                    //Assign QA
                    case 1:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(true);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("required");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                        //Incomplete Submission
                    case 2:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(false);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //none
                    default:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(false);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
            else if (attribute.getName() == 'dobnyc_est_elv3qareviewaction') {
                switch (attribute.getValue()) {
                    case 3:
                    case 4:
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                    case 6:
                        results = areDocumentsApproved("dobnyc_est_elv3qareviewaction", "dobnyc_esdl_qareviewtask");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //other cases
                    default:
                        results = areDocumentsApproved("dobnyc_est_elv3qareviewaction", "dobnyc_esdl_qareviewtask");
                        if (results == true)
                            Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
        } catch (e) { }
    }

    function GetRelatedDocumentList(taskId, taskReviewField) {
        fetchXml = '<fetch version="1.0">' +
            '<entity name="dobnyc_elevatorsafetydocumentlist" >' +
            '<attribute name="dobnyc_elevatorsafetydocumentlistid" />' +
            '<attribute name="dobnyc_esdl_documentstatus" />' +
            '<filter type="and">' +
            '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
            '</filter>' +
            '</entity>' +
            '</fetch>';
        var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return documents;
    }

    function areDocumentsApproved(taskReviewAction, taskReviewField) {
        var taskId = Xrm.Page.data.entity.getId();
        var nextAction = Xrm.Page.getAttribute(taskReviewAction).getValue();
        if (nextAction == null)
            return true;//false;
        var documents = GetRelatedDocumentList(taskId, taskReviewField);

        var isApproved = true;
        for (i = 0; i < documents.length; i++) {
            var statusValue = documents[i].attributes['dobnyc_esdl_documentstatus'].value;
            if (statusValue != 3) {
                isApproved = false;
            }
        }
        if (!isApproved) {
            alert("Must approve all documents before submitting.");
            Xrm.Page.getAttribute(taskReviewAction).setValue(null);
        }
        return isApproved;
    }

    function qaReviewActionOptionsSet() {
        try {
            debugger;
            if (Xrm.Page.getAttribute("dobnyc_est_reportstatus").getValue() == 3)// QA Review
            {
                var inspection_Type;
                if (Xrm.Page.getAttribute("dobnyc_est_taskformfor").getValue() == 2) //ELV 29
                {
                    //get inspection type of elv3					
                    var elv29id = Xrm.Page.getAttribute('dobnyc_est_clicktogotoelv29').getValue()[0].id;
                    var req = new XMLHttpRequest();
                    req.open("GET", Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/dobnyc_elv29Set(guid'" + elv29id + "')?$select=dobnyc_dobnyc_elv3_dobnyc_elv29_elv29_ELV3Lookup/dobnyc_InspectionType&$expand=dobnyc_dobnyc_elv3_dobnyc_elv29_elv29_ELV3Lookup", false);
                    req.setRequestHeader("Accept", "application/json");
                    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                    req.onreadystatechange = function () {
                        if (this.readyState === 4) {
                            this.onreadystatechange = null;
                            if (this.status === 200) {
                                var result = JSON.parse(this.responseText).d;
                                inspection_Type = result.dobnyc_dobnyc_elv3_dobnyc_elv29_elv29_ELV3Lookup.dobnyc_InspectionType;
                            }
                        }
                    };
                    req.send();
                    if (inspection_Type.Value == 7 || inspection_Type.Value == 8) //PVT/QC aoc
                    {
                        Xrm.Page.getControl("dobnyc_est_elv3qareviewaction").removeOption(1);	//Remove "Accepted" option					
                    }
                    else //cat1 aoc
                    {
                        Xrm.Page.getControl("dobnyc_est_elv3qareviewaction").removeOption(5);	//Remove "Corrections Accepted-Violations Dismissed" option					
                        Xrm.Page.getControl("dobnyc_est_elv3qareviewaction").removeOption(6);	//Remove "Corrections Accepted-Violations Not Dismissed" option					
                    }
                }
                else if (Xrm.Page.getAttribute("dobnyc_est_taskformfor").getValue() == 1)//ELV 3
                {
                    Xrm.Page.getControl("dobnyc_est_elv3qareviewaction").removeOption(5);	//Remove "Corrections Accepted-Violations Dismissed" option					
                    Xrm.Page.getControl("dobnyc_est_elv3qareviewaction").removeOption(6);	//Remove "Corrections Accepted-Violations Not Dismissed" option	
                }
            }
        }
        catch (e) { }
    }

    function setTaskForm() {
        try {
            var Taskform = Xrm.Page.getAttribute("dobnyc_est_taskformfor").getValue();
            var form = Xrm.Page.ui.formSelector.getCurrentItem();
            if (form != null) {
                var formId = form.getId();
                var formLabel = form.getLabel();
            }
            if (Taskform == 1 && formLabel != "ELV3 Task Form") {
                var items = Xrm.Page.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();

                    if (formLabel == "ELV3 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
            if (Taskform == 2 && formLabel != "ELV29 Task Form") {
                var items = Xrm.Page.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();
                    if (formLabel == "ELV29 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
        } catch (e) { }
    }
    function showHideSections() {
        try {
            if (Xrm.Page.getAttribute("dobnyc_est_reportstatus")) {
                var elv3ReportStatus = Xrm.Page.getAttribute("dobnyc_est_reportstatus").getValue();
                var elv3QASuperSectionNames = ['QASDocumentSection', 'QASupervisorReviewSection'];
                var elv3QASectionNames = ['QADocumentSection', 'QAReviewSection'];

                //QA Supervisor Review
                if (elv3ReportStatus == 2) {
                    $.each(elv3QASuperSectionNames, function (index, v) {
                        Xrm.Page.ui.tabs.get('General').sections.get(v).setVisible(true);
                    });
                    Xrm.Page.getAttribute("dobnyc_est_elv3qasupervisoraction").setRequiredLevel("required");
                }
                    //QA Review
                else if (elv3ReportStatus == 3) {
                    $.each(elv3QASectionNames, function (index, v) {
                        Xrm.Page.ui.tabs.get('General').sections.get(v).setVisible(true);
                    });
                    Xrm.Page.getAttribute("dobnyc_est_elv3qareviewaction").setRequiredLevel("required");
                }
            }
        } catch (e) { }
    }
    return {
        OnLoad: onLoad,
        ActionOnChange: actionOnChange
    };
}();