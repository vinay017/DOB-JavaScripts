﻿///====================================================================
/// Name        :   Elevator Safety Master 
/// Description :   This will have All Methods for Elevator Safety 
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyMaster.js
/// Author      :   
///====================================================================
var DOB = window.DOB || {};
DOB.ElevatorSafetyMaster = function () {

    //Controls declaration

    var ELV3InspectionType =
       {
           CAT1: 1,
           CAT3: 2,
           CAT5: 3,
           HoistJumpUP: 4,
           HoistJumpDown: 5,
           NinetyDayTempRenewal: 6,
           PVTInspection: 7,
           QCInspection: 8


       }
    var ELV3ReportStatus =
        {
            Prefiling: 1,
            QASupervisorReview: 2,
            QAReview: 3,
            QAFailed: 4,
            Accepted: 5,
            Incomplete: 6,
            CivilPenalitiesDue: 7,
            AcceptedDefects: 9


        }

    "use strict";

    function task_onLoad() {
        setTaskForm();
        task_showHideSections();
    }

    function task_actionOnChange(executionContext) {
        try {
            var attribute = executionContext.getEventSource();
            if (attribute.getName() == 'dobnyc_est_elv3qasupervisoraction') {
                switch (attribute.getValue()) {
                    //Assign QA
                    case 1:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(true);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("required");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                        //Incomplete Submission
                    case 2:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(false);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //none
                    default:
                        Xrm.Page.getControl("dobnyc_est_assignto").setVisible(false);
                        Xrm.Page.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
            else if (attribute.getName() == 'dobnyc_est_elv3qareviewaction') {
                switch (attribute.getValue()) {
                    case 3:
                    case 4:
                        Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //other cases
                    default:
                        var results = areDocumentsApproved("dobnyc_est_elv3qareviewaction", "dobnyc_esdl_qareviewtask");
                        if (results == true)
                            Xrm.Page.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
        } catch (e) { }
    }

    function elv3_onLoad() {
        elv3_showHideSections();
        elv3_showHideTaskURL(); // based on report status hide and show Task URL
        elv3_showHidePVTQCFields(); //based on Inspection type hide and show fields
    }
    function elv3_showHidePVTQCFields() {
        try {
            var currentInspectionType = Xrm.Page.getAttribute("dobnyc_inspectiontype").getValue();
            if (!(currentInspectionType == ELV3InspectionType.PVTInspection || currentInspectionType == ELV3InspectionType.QCInspection)) {
                DisplayHideControls(["dobnyc_elv3_disposition", "dobnyc_elv3_ceaseuse", "dobnyc_elv3_violation", "dobnyc_elv3_alternatedeviceinservice"], false);
            }
        } catch (e) { }


    }
    //this function is used to hide and show controls
    function DisplayHideControls(controlNames, isVisible) {
        try {
            if (controlNames != null && controlNames.length > 0) {
                for (var i = 0; i < controlNames.length; i++) {
                    Xrm.Page.getControl(controlNames[i]).setVisible(isVisible);
                }
            }
        }
        catch (excp) {
            //alert(excp);
        }
    }


    function elv3_showHideTaskURL() {
        try {
            var currentReportStatus = Xrm.Page.getAttribute("dobnyc_elv3_reportstatus").getValue();
            if (!(currentReportStatus == ELV3ReportStatus.QASupervisorReview || currentReportStatus == ELV3ReportStatus.QAReview)) {
                Xrm.Page.getControl("dobnyc_elv3_currenttaskurl").setVisible(false);
            }
        } catch (e) { }
    }

    function setTaskForm() {
        try {
            var Taskform = Xrm.Page.getAttribute("dobnyc_est_taskformfor").getValue();
            var form = Xrm.Page.ui.formSelector.getCurrentItem();
            if (form != null) {
                var formId = form.getId();
                var formLabel = form.getLabel();
            }
            if (Taskform == 1 && formLabel != "ELV3 Task Form") {
                var items = Xrm.Page.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();

                    if (formLabel == "ELV3 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
            if (Taskform == 2 && formLabel != "ELV29 Task Form") {
                var items = Xrm.Page.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();
                    if (formLabel == "ELV29 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
        } catch (e) { }
    }

    function task_showHideSections() {
        try {
            if (Xrm.Page.getAttribute("dobnyc_est_reportstatus")) {
                var elv3ReportStatus = Xrm.Page.getAttribute("dobnyc_est_reportstatus").getValue();
                var elv3QASuperSectionNames = ['QASDocumentSection', 'QASupervisorReviewSection'];
                var elv3QASectionNames = ['QADocumentSection', 'QAReviewSection'];

                //QA Supervisor Review
                if (elv3ReportStatus == 2) {
                    $.each(elv3QASuperSectionNames, function (index, v) {
                        Xrm.Page.ui.tabs.get('General').sections.get(v).setVisible(true);
                    });
                }
                    //QA Review
                else if (elv3ReportStatus == 3) {
                    $.each(elv3QASectionNames, function (index, v) {
                        Xrm.Page.ui.tabs.get('General').sections.get(v).setVisible(true);
                    });
                }
            }
        } catch (e) { }
    }

    function elv3_showHideSections() {
        try {
            if (Xrm.Page.getAttribute("dobnyc_inspectiontype")) {
                var inspectionType = Xrm.Page.getAttribute("dobnyc_inspectiontype").getValue();
                if (inspectionType == 1) {
                    Xrm.Page.ui.tabs.get('General').sections.get('DefectsGrid').setVisible(true);
                }
            }
        } catch (e) { }
    }

    function acceptDocument() {
        debugger;
        try {
            var isValidRole = checkSecurityRole();
            if (isValidRole) {
                var DocumentURL = Xrm.Page.getAttribute("dobnyc_esdl_documenturl").getValue();
                var DocumentViewed = Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").getText();

                if (DocumentViewed == "Yes") {
                    var message = "Would you like to accept this document?";
                    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
                    function yesCloseCallback() {
                        Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setValue(3);
                        Xrm.Page.data.entity.save();
                    }
                    function noCloseCallback() {
                        return;
                    }
                }
                else {
                    alert("Please view the Document at least once before accepting it");
                }

            }
            else {
                alert("insufficient privileges. Please Contact Administrator. ");
            }
        } catch (e) { }
    }

    function rejectDocument() {
        debugger;
        var isValidRole = checkSecurityRole();
        if (isValidRole) {
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = Xrm.Page.context.getUserId();
            lookup[0].name = Xrm.Page.context.getUserName();
            lookup[0].entityType = "systemuser";
            var loginId = lookup[0].id;
            var ViewedbyId = getLookupId("dobnyc_esdl_viewedby");
            if (ViewedbyId != loginId) {
                alert("Please view document first before Rejecting!");
                return;
            }
            var message = "Would you like to reject this document?";
            Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
            function yesCloseCallback() {
                Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setValue(4);
                Xrm.Page.data.entity.save();
            }
            function noCloseCallback() {
                return;
            }
        }
        else {
            alert("insufficient privileges. Please Contact Administrator. ");
        }
    }

    function replaceDocument() {
        debugger;
        console.log('replace document code');
    }

    function downloadDocument() {
        try {
            debugger;
            var returnValue = null;
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = Xrm.Page.context.getUserId();
            lookup[0].name = Xrm.Page.context.getUserName();
            lookup[0].entityType = "systemuser";

            var URL = Xrm.Page.getAttribute("dobnyc_esdl_documenturl").getValue();

            if (URL == null) {
                alert("There is no document to download");
                return;
            }

            var Id = Xrm.Page.data.entity.getId();

            var JBGUID = null;
            var path = null;

            var Documentfor = Xrm.Page.getAttribute("dobnyc_esdl_regardingform").getValue();
            //alert("Documentfor: " + Documentfor);
            if (Documentfor == 1) //ELV3
            {

                JBGUID = getLookupId("dobnyc_esdl_elv3");
                //alert(JBGUID);
                returnValue = retrieveMultipleCustom("dobnyc_elv3Set", "?select= dobnyc_Borough,dobnyc_name,dobnyc_elv3_ElevatorId&$filter=dobnyc_elv3Id eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Elevators\\" + returnValue[0].dobnyc_elv3_ElevatorId.Name + '\\' + (returnValue[0].dobnyc_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
                }
            }
            else if (Documentfor == 2) //ELV29
            {
                JBGUID = getLookupId("dobnyc_esdl_elv29");
                returnValue = retrieveMultipleCustom("dobnyc_elv29Set", "?select= dobnyc_borough,dobnyc_name,dobnyc_elv29_DeviceID&$filter=dobnyc_elv29Id eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Elevators\\" + returnValue[0].dobnyc_elv29_DeviceID.Name + '\\' + (returnValue[0].dobnyc_borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

                }

            }
            else if (Documentfor == 3) //ELV36
            {

                JBGUID = getLookupId("dobnyc_esdl_elv36");
                returnValue = retrieveMultipleCustom("dobnyc_elv36Set", "?select= dobnyc_elv36_Borough,dobnyc_name,dobnyc_elv36_DeviceID&$filter=dobnyc_boilernotregisteredId eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Boilers\\" + returnValue[0].dobnyc_elv36_DeviceID + '\\' + (returnValue[0].dobnyc_elv36_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
                }
            }


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                headers: {
                    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                },
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");
                        Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_viewedby").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").setValue(true);
                        Xrm.Page.getAttribute("dobnyc_esdl_viewedby").setValue(lookup);
                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("Download is Un-successful");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        } catch (e) { }
    }

    function getRelatedDocumentList(taskId, taskReviewField) {
        var fetchXml = '<fetch version="1.0">' +
            '<entity name="dobnyc_elevatorsafetydocumentlist" >' +
                '<attribute name="dobnyc_elevatorsafetydocumentlistid" />' +
                '<attribute name="dobnyc_esdl_documentstatus" />' +
                '<filter type="and">' +
                    '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
                '</filter>' +
              '</entity>' +
            '</fetch>';
        var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return documents;
    }

    function areDocumentsApproved(taskReviewAction, taskReviewField) {
        var taskId = Xrm.Page.data.entity.getId();
        var documents = getRelatedDocumentList(taskId, taskReviewField);
        var isApproved = true;
        for (var i = 0; i < documents.length; i++) {
            var statusValue = documents[i].attributes['dobnyc_esdl_documentstatus'].value;
            if (statusValue != 3) {
                isApproved = false;
            }
        }
        if (!isApproved) {
            alert("Must approve all documents in the Document List");
            Xrm.Page.getAttribute(taskReviewAction).setValue(null);
        }
        return isApproved;
    }

    function checkSecurityRole() {
        var isValidRole = false;
        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = getRoleName(userRoleId);
            if (userRoleName == "System Administrator") {
                return true;
            }

        }
        return isValidRole;
    }

    function getRoleName(userRoleId) {
        //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
        var selectQuery = "RoleSet(guid'" + userRoleId + "')?$select=Name";
        var odataSelect = Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/" + selectQuery;
        //alert(odataSelect);
        var roleName = null;
        $.ajax({
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                var result = data.d;
                if (!!result) {
                    roleName = result.Name;
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) {
                //alert('OData Select Failed: ' + odataSelect);
            }
        });
        return roleName;
    }

    function getLookupId(attributeName) {
        var lookupObject = Xrm.Page.getAttribute(attributeName);
        if (lookupObject != null) {
            var lookUpObjectValue = lookupObject.getValue();
            if ((lookUpObjectValue != null)) {
                var lookuptextvalue = lookUpObjectValue[0].name;
                var lookupid = lookUpObjectValue[0].id;
                return lookupid;
            }
        }
    }

    return {
        Task_OnLoad: task_onLoad,
        Task_ActionOnChange: task_actionOnChange,
        ELV3_OnLoad: elv3_onLoad,
        AcceptDocument: acceptDocument,
        RejectDocument: rejectDocument,
        ReplaceDocument: replaceDocument,
        DownloadDocument: downloadDocument
    };
}();