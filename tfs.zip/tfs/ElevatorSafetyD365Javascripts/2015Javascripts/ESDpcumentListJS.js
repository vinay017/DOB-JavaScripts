﻿///===================================================================================
/// Name        :   Elevator Safety Document List Form Scripts 
/// Description :   This will have All Methods for Elevator Safety DOcument List form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyDocumentList.js
/// Author      :   
///===================================================================================

var DOB = window.DOB || {};
DOB.ElevatorSafetyDocumentList = function () {
    function acceptDocument() {
        debugger;
        try {
            var isValidRole = checkSecurityRole();
            if (isValidRole) {
                var DocumentURL = Xrm.Page.getAttribute("dobnyc_esdl_documenturl").getValue();
                var DocumentViewed = Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").getText();

                if (DocumentViewed == "Yes") {
                    var message = "Would you like to accept this document?";
                    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
                    function yesCloseCallback() {
                        Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setValue(3);
                        Xrm.Page.data.entity.save();
                    }
                    function noCloseCallback() {
                        return;
                    }
                }
                else {
                    alert("Please view the document at least once before accepting it.");
                }

            }
            else {
                alert("insufficient privileges. Please Contact Administrator. ");
            }
        } catch (e) { }
    }

    function rejectDocument() {
        debugger;
        var isValidRole = checkSecurityRole();
        if (isValidRole) {
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = Xrm.Page.context.getUserId();
            lookup[0].name = Xrm.Page.context.getUserName();
            lookup[0].entityType = "systemuser";
            var loginId = lookup[0].id;
            var ViewedbyId = getLookupId("dobnyc_esdl_viewedby");
            if (ViewedbyId != loginId) {
                alert("Please view the document first before rejecting it.");
                return;
            }
            var message = "Would you like to reject this document?";
            Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
            function yesCloseCallback() {
                Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_esdl_documentstatus").setValue(4);
                Xrm.Page.data.entity.save();
            }
            function noCloseCallback() {
                return;
            }
        }
        else {
            alert("insufficient privileges. Please Contact Administrator. ");
        }
    }

    function replaceDocument() {
        debugger;
        console.log('replace document code');
    }

    function downloadDocument() {
        try {
            debugger;
            var returnValue = null;
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = Xrm.Page.context.getUserId();
            lookup[0].name = Xrm.Page.context.getUserName();
            lookup[0].entityType = "systemuser";

            var URL = Xrm.Page.getAttribute("dobnyc_esdl_documenturl").getValue();

            if (URL == null) {
                alert("There is no document to download.");
                return;
            }

            var Id = Xrm.Page.data.entity.getId();

            var JBGUID = null;
            var path = null;

            var Documentfor = Xrm.Page.getAttribute("dobnyc_esdl_regardingform").getValue();
            //alert("Documentfor: " + Documentfor);
            if (Documentfor == 1) //ELV3
            {

                JBGUID = getLookupId("dobnyc_esdl_elv3");
                //alert(JBGUID);
                returnValue = retrieveMultipleCustom("dobnyc_elv3Set", "?select= dobnyc_Borough,dobnyc_name,dobnyc_elv3_ElevatorId&$filter=dobnyc_elv3Id eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Elevators\\" + returnValue[0].dobnyc_elv3_ElevatorId.Name + '\\' + (returnValue[0].dobnyc_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
                }
            }
            else if (Documentfor == 2) //ELV29
            {
                JBGUID = getLookupId("dobnyc_esdl_elv29");
                returnValue = retrieveMultipleCustom("dobnyc_elv29Set", "?select= dobnyc_borough,dobnyc_name,dobnyc_elv29_DeviceID&$filter=dobnyc_elv29Id eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Elevators\\" + returnValue[0].dobnyc_elv29_DeviceID.Name + '\\' + (returnValue[0].dobnyc_borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

                }

            }
            else if (Documentfor == 3) //ELV36
            {

                JBGUID = getLookupId("dobnyc_esdl_elv36");
                returnValue = retrieveMultipleCustom("dobnyc_elv36Set", "?select= dobnyc_elv36_Borough,dobnyc_name,dobnyc_elv36_DeviceID&$filter=dobnyc_boilernotregisteredId eq guid'" + JBGUID + "'");
                if (returnValue != null && returnValue[0] != null) {
                    path = "Elevators\\" + returnValue[0].dobnyc_elv36_DeviceID + '\\' + (returnValue[0].dobnyc_elv36_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
                }
            }


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                //headers: {
                //    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                //},
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");
                        Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_viewedby").setSubmitMode("always");
                        Xrm.Page.getAttribute("dobnyc_esdl_isdocumentviewed").setValue(true);
                        Xrm.Page.getAttribute("dobnyc_esdl_viewedby").setValue(lookup);
                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("The document download was unsuccessful.");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading the document. Please try again or contact your administrator.");
                }
            });
        } catch (e) { }
    }

    function getRelatedDocumentList(taskId, taskReviewField) {
        var fetchXml = '<fetch version="1.0">' +
            '<entity name="dobnyc_elevatorsafetydocumentlist" >' +
                '<attribute name="dobnyc_elevatorsafetydocumentlistid" />' +
                '<attribute name="dobnyc_esdl_documentstatus" />' +
                '<filter type="and">' +
                    '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
                '</filter>' +
              '</entity>' +
            '</fetch>';
        var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return documents;
    }

    function areDocumentsApproved(taskReviewAction, taskReviewField) {
        var taskId = Xrm.Page.data.entity.getId();
        var documents = getRelatedDocumentList(taskId, taskReviewField);
        var isApproved = true;
        for (var i = 0; i < documents.length; i++) {
            var statusValue = documents[i].attributes['dobnyc_esdl_documentstatus'].value;
            if (statusValue != 3) {
                isApproved = false;
            }
        }
        if (!isApproved) {
            alert("Must approve all documents in the Document List");
            Xrm.Page.getAttribute(taskReviewAction).setValue(null);
        }
        return isApproved;
    }

    function checkSecurityRole() {
        var isValidRole = false;
        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = getRoleName(userRoleId);
            if (userRoleName == "System Administrator" || userRoleName == "Elevator Safety-QA Clerk" || userRoleName == "Elevator Safety-QA Supervisor") {
                return true;
            }

        }
        return isValidRole;
    }

    function getRoleName(userRoleId) {
        //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
        var selectQuery = "RoleSet(guid'" + userRoleId + "')?$select=Name";
        var odataSelect = Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/" + selectQuery;
        //alert(odataSelect);
        var roleName = null;
        $.ajax({
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                var result = data.d;
                if (!!result) {
                    roleName = result.Name;
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) {
                //alert('OData Select Failed: ' + odataSelect);
            }
        });
        return roleName;
    }

    function getLookupId(attributeName) {
        var lookupObject = Xrm.Page.getAttribute(attributeName);
        if (lookupObject != null) {
            var lookUpObjectValue = lookupObject.getValue();
            if ((lookUpObjectValue != null)) {
                var lookuptextvalue = lookUpObjectValue[0].name;
                var lookupid = lookUpObjectValue[0].id;
                return lookupid;
            }
        }
    }

    return {
        AcceptDocument: acceptDocument,
        RejectDocument: rejectDocument,
        ReplaceDocument: replaceDocument,
        DownloadDocument: downloadDocument
    };
}();