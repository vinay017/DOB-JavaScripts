﻿///====================================================================
/// Name        :   DOBNYC All Common Utilities
/// Description :   This file contains all common functions/methods called through out the CRM site, for all worktypes. 
/// Usage       :   
/// Script Name :   dobnyc_AllCommonUtilities.js
/// Author      :   Department of Buildings
///====================================================================

DOB = window.DOB || {};
DOB.AllUtilities = function () {
    //"use strict";

    //Variable Declaration
    var RoleNames = {
        CATeam: "MULTISTAKES - Central Assignment Team"
		, CPE1Team: "MULTISTAKES - CPE/ACPE Team 1"
		, CPE2Team: "MULTISTAKES - CPE/ACPE Team 2"
		, CPE3Team: "MULTISTAKES - CPE/ACPE Team 3"
		, CPE4Team: "MULTISTAKES - CPE/ACPE Team 4"
		, PE1Team: "MULTISTAKES - PE Team 1"
		, PE2Team: "MULTISTAKES - PE Team 2"
		, PE3Team: "MULTISTAKES - PE Team 3"
		, PE4Team: "MULTISTAKES - PE Team 4"
		, QAAAHVTeam: "MULTISTAKES - QA Administrator - AHV"
		, QAALOCTeam: "MULTISTAKES - QA Administrator - LOC"
		, QAAPW2Team: "MULTISTAKES - QA Administrator - Work Permits(PW2)"
		, QASAHVTeam: "MULTISTAKES - QA Supervisor - AHV"
		, QASLOCTeam: "MULTISTAKES - QA Supervisor - LOC"
		, QASPW2Team: "MULTISTAKES - QA Supervisor - Work Permits(PW2)"
		, QASPPAATeam: "MULTISTAKES - QA Supervisor - Prof-Cert PAA"
		, QASPPW2Team: "MULTISTAKES - QA Supervisor - Prof-Cert With PW2"
		, QASPNoPW2Team: "MULTISTAKES - QA Supervisor - Prof-Cert Without PW2"
		, SystemAdmin: "System Administrator"
		, OperationsAdmin: "BUILDNYC - Operations Admin"
    };

    ///PW1 Standardization: Start
    var WorkType = {
        PL: "PL"				//PL - Plumbing New Work
		, SP: "SP"				//SP - Sprinklers New Work
		, SD: "SD"				//SD - Standpipe New Work
		, PL_LG: "PL_LG"			//PL - Plumbing Legalization
		, SP_LG: "SP_LG"			//SP - Sprinklers Legalization
		, PL_SP: "PL_SP"			//PL & SP
		, PL_SD: "PL_SD"			//PL & SD
		, SP_SD: "SP_SD"			//SP & SD
		, PL_SP_SD: "PL_SP_SD" 	//PL, SP & SD
		, PL_SP_LG: "PL_SP_LG" 	//PL & SP Legalization
		, AN: "AN"				//AN - Antenna
		, CC: "CC"				//CC - Curb Cut		 
		, FN: "FN"				//FN - Fence
		, SF: "SF"				//SF - Scaffold
		, SG: "SG"				//SG - Sign
		, SH: "SH"				//SH - Side Walk Shed		 
		, SH_SF: "SH_SF"			//SH & SF
		, SH_FN: "SH_FN"			//SH & FN
		, SF_FN: "SF_FN"			//SF & FN
		, SH_SF_FN: "SH_SF_FN"	//SH, SF & FN
		, PA: "PA"				//Place of Assembly
		, TPA: "TPA"				//Temporary Place of Assembly
		, BE: "BE"				//Boiler Equipment
		, MS: "MS"				//Mechanical Systems
		, ST: "ST"				//Structural
		, GC: "GC"				//GC - General Constructions		
		, LAA: "LAA"				//LAA
		, VT: "VT"				//VT - Elevators
		, EL: "EL"				//EL - Electrical
    };
    ///PW1 Standardization: End
    //Controls declaration

    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================

    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns> 
    };

    var setState = function (enabled) {
        ///<summary> Set State of attributes and Tabs </summary>
        ///<returns>no return</returns>
        ///<param name="enabled" type="Boolean">Set state for tabs and attributes.</param>            
    };

    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================

    var helper = function () {
        ///<summary> Set state of attributes and tabs based on Antenna Scope of Work is in ecosystem </summary>
        ///<returns>no return</returns> 
    };

    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of Antenna Scope of Work
    ///==================================================================================================================

    var onLoad = function () {
        init();
    };

    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of Antenna Scope of Work
    ///==================================================================================================================


    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();
    };

    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in Antenna Scope of Work
    ///==================================================================================================================

    var toggleLoader = function (ShowOverLay) {
        var divOverLayName = "divOverLay";
        var CRMTopBar = top.document.getElementById("crmTopBar");
        var divOverlays = top.document.getElementById(divOverLayName);

        if (ShowOverLay) {
            if (CRMTopBar) {
                if (divOverlays) {
                    showOverLayDiv(divOverLayName);
                }
                else {
                    createOverLay(CRMTopBar, divOverLayName);
                }
            }
        }
        else {
            hideOverLayDiv(divOverLayName);
        }
    };

    var createOverLay = function (CRMTopBar, divOverLayName) {
        var divOverlay = document.createElement('div');
        divOverlay.setAttribute('id', divOverLayName);

        divOverlay.style.textAlign = "center";
        divOverlay.style.position = "absolute";
        divOverlay.style.top = "0px";
        divOverlay.style.left = "0px";
        divOverlay.style.bottom = "0px";
        divOverlay.style.right = "0px";
        divOverlay.style.zIndex = "100";
        divOverlay.style.backgroundColor = "rgba(0,0,0,0.4)";
        var imgSource = "<img id='OverLayLoading' alt='Loading...' src='/_imgs/AdvFind/progress.gif' style='text-align:center; position:absolute; top:50%; left:49%; right:0px;'/>";
        divOverlay.innerHTML = imgSource;
        divOverlay.style.display = "block";
        CRMTopBar.parentNode.insertBefore(divOverlay, CRMTopBar);

    };

    var showOverLayDiv = function (divOverLayName) {
        try {
            if (top.document.getElementById(divOverLayName)) {
                top.document.getElementById(divOverLayName).style.display = "block";
            }
            else {
                createOverLay(CRMTopBar, divOverLayName);
            }
        }
        catch (err) {
            alert(err.description);
        }
    };

    var hideOverLayDiv = function (divOverLayName) {
        try {
            var node = top.document.getElementById(divOverLayName);
            if (node) {
                if (node.parentNode) {
                    node.parentNode.removeChild(node);
                }
            }
        }
        catch (err) {
            alert(err.description);
        }
    };

    var filterUsersByTeam = function (lookup, assignedTeam) {
        debugger;
        if (lookup != null && lookup != '') {
            var regExpress = /\s*;\s*/;
            var lookupList = lookup.split(regExpress);
            //Get Team Name by passing 0 to the below method.
            var teamName = getLookupDetails(assignedTeam, 0);

            if (teamName != null && teamName != '') {
                try {
                    var entityName = "systemuser";
                    //*Important: Set the view selector value as Off for the "User Lookups" in the Form. If not, user can select other views too.
                    var viewDisplayName = "User Lookup View";
                    var fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
                        "<entity name='systemuser'>" +
                        "<attribute name='fullname' />" +
                        "<attribute name='businessunitid' />" +
                        "<attribute name='title' />" +
                        "<attribute name='address1_telephone1' />" +
                        "<attribute name='positionid' />" +
                        "<attribute name='systemuserid' />" +
                        "<order attribute='fullname' descending='false' />" +
                        "<link-entity name='teammembership' from='systemuserid' to='systemuserid' visible='false' intersect='true'>" +
                        "<link-entity name='team' from='teamid' to='teamid' alias='ab'>" +
                        "<filter type='and'>" +
                        "<filter type='or'>" +
                        "<condition attribute='dobnyc_parentteamname' operator='like' value='%" + teamName + "%' />" +
                        "<condition attribute='name' operator='like' value='%" + teamName + "%' />" +
                        "</filter>" +
                        "</filter>" +
                        "</link-entity>" +
                        "</link-entity>" +
                        "</entity>" +
                        "</fetch>";

                    var layoutXML = "<grid name='resultset' object='8' jump='fullname' select='1' icon='1' preview='1'>" +
                        "<row name='result' id='systemuserid'>" +
                        "<cell name='fullname' width='300' />" +
                        "</row>" +
                        "</grid>";

                    debugger;
                    for (var i = 0; i < lookupList.length; i++) {
                        if (Xrm.Page.getControl(lookupList[i]) != null && Xrm.Page.getControl(lookupList[i]) != undefined) {
                            var viewId = Xrm.Page.getControl(lookupList[i]).getDefaultView();
                            Xrm.Page.getControl(lookupList[i]).addCustomView(viewId, entityName, viewDisplayName, fetchXML, layoutXML, true);
                        }
                        // Xrm.Page.getControl(lookup).addPreSearch(function(){
                        // //var fetchXML = "<filter type='and'> <condition attribute='name' operator='like' value='%"+teamName+"%' /> </filter>";						
                        // Xrm.Page.getControl(lookup).addCustomFilter(fetchXML);
                        // });
                    }
                }
                catch (err) {
                    throw new Error(err.Message);
                }
            }
        }
    };

    ///<summary>Get Custom Configuration Value based on Key</summary>
    ///<returns>Value from Custom Configuration</returns>
    ///<param name="key" type="String"/>
    var getMessage = function (key) {
        /// get Data from configuration entity
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Page.context.getUserLcid() + "'");

        if (returnValue != null && returnValue[0] != null)
            return returnValue[0].dobnyc_name;
        return "Unable to get configuration message for Key : " + key + ".";
    };

    ///<summary>Get Lookup Name or ID based on Lookup field name.</summary>
    ///<returns>Name or ID of the Lookup</returns>
    ///<param name="attributeName" type="lookup Field Name">Lookup Field Name</param>
    ///<param name="NameorId" type="integer">0 to get Name and 1 to get ID of the Lookup</param>
    var getLookupDetails = function (attributeName, NameorId) {
        var lookupObject = Xrm.Page.getAttribute(attributeName);
        if (lookupObject != null) {
            var lookUpObjectValue = Xrm.Page.getAttribute(attributeName).getValue();
            if ((lookUpObjectValue != null)) {
                var lookuptextvalue = lookUpObjectValue[0].name;
                var lookupid = lookUpObjectValue[0].id;
                if (NameorId == 0)
                    return lookuptextvalue;
                else
                    return lookupid;
            }
        }
    };

    ///Calling: DOB.AllUtilities.SetCustomSectionBarValue('WebResource_Objections','Obj_New');
    var setCustomSectionBarValue = function (resource, val) {
        if (resource != null && resource != undefined && val != null && val != undefined) {
            var strOuterHtml = document.getElementById(resource).outerHTML;
            var replaceValue = "?data=" + strOuterHtml.split('?data=').pop().split('" src=').shift();
            var replaceWith = "?data=" + val;
            strOuterHtml = strOuterHtml.replace(replaceValue, replaceWith);
            //in IE closing</iframe> tage is not appending so we have to append this explicitly in case of IE

            var checkClosingOuterHtml = strOuterHtml.substring(strOuterHtml.length, strOuterHtml.length - 8);

            if (checkClosingOuterHtml != "/iframe>") {

                strOuterHtml = strOuterHtml + '\"></iframe>';
            }

            document.getElementById(resource).outerHTML = strOuterHtml;
        }
    };

    var displayHideControls = function (controlNames, isVisible) {
        try {
            if (controlNames != null && controlNames.length > 0) {
                for (var i = 0; i < controlNames.length; i++) {
                    Xrm.Page.getControl(controlNames[i]).setVisible(isVisible);
                }
            }
        }
        catch (excp) {
            //alert(excp);
        }
    };

    var displayHideSections = function (parentTabName, sectionNames, isVisible) {
        try {
            if (parentTabName != null && Xrm.Page.ui.tabs.get(parentTabName) && sectionNames != null && sectionNames.length > 0) {
                for (var i = 0; i < sectionNames.length; i++) {
                    Xrm.Page.ui.tabs.get(parentTabName).sections.get(sectionNames[i]).setVisible(isVisible);
                }
            }
        }
        catch (excp) {
            //alert(excp);
        }
    };

    var getViewIdByName = function (viewName) {
        var viewId = "";
        var fetchXml =
		   "<fetch mapping='logical'>" +
			  "<entity name='savedquery'>" +
			  "<attribute name='savedqueryid' />" +
				  "<filter>" +
					"<condition attribute='name' operator='eq' value='" + viewName + "' />" +
				  "</filter>" +
			  "</entity>" +
		   "</fetch>";

        var retrievedViews = XrmServiceToolkit.Soap.Fetch(fetchXml);
        viewId = retrievedViews[0].attributes['savedqueryid'].value;
        return viewId;
    };

    var getRoleName = function (userId) {
        var fetchXml =
			"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >" +
				"<entity name='role' >" +
					"<attribute name='name' />" +
					"<order attribute='name' descending='false' />" +
					"<link-entity name='systemuserroles' from='roleid' to='roleid' visible='false' intersect='true' >" +
						"<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='aa' >" +
							"<filter type='and' >" +
								"<condition attribute='systemuserid' operator='eq' value='" + userId + "'/>" +
							"</filter>" +
						"</link-entity>" +
					"</link-entity>" +
				"</entity>" +
			"</fetch>";
        var retrievedContacts = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return retrievedContacts;
    };

    var getTeamRoleNames = function (TeamId) {
        var fetchXml =
			"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>" +
				"<entity name='role'>" +
					"<attribute name='name' />" +
					"<order attribute='name' descending='false' />" +
					"<link-entity name='teamroles' from='roleid' to='roleid' visible='false' intersect='true'>" +
						"<link-entity name='team' from='teamid' to='teamid' alias='ad'>" +
							"<filter type='and' >" +
								"<condition attribute='teamid' operator='eq' uitype='team' value='" + TeamId + "' />" +
							"</filter>" +
						"</link-entity>" +
					"</link-entity>" +
				"</entity>" +
			"</fetch>";
        var retrievedContacts = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return retrievedContacts;
    };

    var disableFormFields = function disableFormFields(onOff) {
        Xrm.Page.ui.controls.forEach(function (control, index) {
            if (doesControlHaveattribute(control)) {
                control.setDisabled(onOff);
            }
        });
    };

    var hasMatchingRole = function (currentUserRoles, checkRole) {
        debugger;
        var currentUserRoleLength = currentUserRoles.length;
        if (currentUserRoleLength > 0) {
            for (var curl = 0; curl < currentUserRoleLength; curl++) {
                if (currentUserRoles[curl].attributes.name.value.toUpperCase() == checkRole.toUpperCase()) {
                    return true;
                }
            }
        }
        return false;
    };

    var hasMatchingRoles = function (currentUserRoles, ownerRoles) {
        debugger;
        var ownerRoleLength = ownerRoles.length, currentUserRoleLength = currentUserRoles.length;
        var hasRoles = false;
        for (var i = 0; i < ownerRoleLength; i++) {
            for (var j = 0; j < currentUserRoleLength; j++) {
                debugger;
                if (ownerRoles[i].attributes.name.value.toUpperCase() == currentUserRoles[j].attributes.name.value.toUpperCase()) {
                    return true;
                }
            }
        }
        return hasRoles;
    };

    var getRoleNameByTeam = function (teamName) {
        var roleName = "";
        switch (teamName) {
            case "CPE/ACPE Team 1":
                roleName = RoleNames.CPE1Team;
                break;
            case "CPE/ACPE Team 2":
                roleName = RoleNames.CPE2Team;
                break;
            case "CPE/ACPE Team 3":
                roleName = RoleNames.CPE3Team;
                break;
            case "CPE/ACPE Team 4":
                roleName = RoleNames.CPE4Team;
                break;
            case "Central Assigner Team":
                roleName = RoleNames.CATeam;
                break;
            case "PE Team 1":
                roleName = RoleNames.PE1Team;
                break;
            case "PE Team 2":
                roleName = RoleNames.PE2Team;
                break;
            case "PE Team 3":
                roleName = RoleNames.PE3Team;
                break;
            case "PE Team 4":
                roleName = RoleNames.PE4Teamm;
                break;
            default:
                break;
        }
        return roleName;
    };

    var setTaskPermissionsByRole = function () {
        debugger;

        var currentUserId = Xrm.Page.context.getUserId();
        var currentUserRoles = getRoleName(currentUserId);

        if (hasMatchingRole(currentUserRoles, RoleNames.SystemAdmin) || hasMatchingRole(currentUserRoles, RoleNames.OperationsAdmin)) {
            disableFormFields(false);
            //return;
        }

        var Taskform = (Xrm.Page.getAttribute("dobnyc_task_taskform") != null) ? Xrm.Page.getAttribute("dobnyc_task_taskform").getValue() : 0;
        var isLOCTask = (Xrm.Page.getAttribute("dobnyc_isloctaskform") != null) ? Xrm.Page.getAttribute("dobnyc_isloctaskform").getValue() : false;
        var isAHVTask = (Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade") != null) ? Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade").getValue() : false;
        var isWPTask = (Xrm.Page.getAttribute("dobnyc_isworkpermittaskform") != null) ? Xrm.Page.getAttribute("dobnyc_isworkpermittaskform").getValue() : false;
        var isWPAvailable = (Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable") != null) ? Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable").getValue() : false;
        var taskOwnerLookup = '';
        var taskOwner = '';
        var isAllowed = false;
        var onwerRoles = null;

        switch (Taskform) {
            case 1:///CPE Filing:3
                //var filingStatus = (Xrm.Page.getAttribute("dobnyc_current") != null) ? Xrm.Page.getAttribute("dobnyc_current").getValue() : 0;
                taskOwnerLookup = Xrm.Page.getAttribute("ownerid").getValue();
                taskOwner = (taskOwnerLookup != null && taskOwnerLookup != undefined) ? taskOwnerLookup[0].name : "";
                isAllowed = hasMatchingRole(currentUserRoles, getRoleNameByTeam(taskOwner));
                break;
            case 2:///PE Filing:4
                taskOwnerLookup = Xrm.Page.getAttribute("ownerid").getValue();
                taskOwner = (taskOwnerLookup != null && taskOwnerLookup != undefined) ? taskOwnerLookup[0].id : "";
                isAllowed = hasMatchingRoles(currentUserRoles, getRoleName(taskOwner));
                if (!isAllowed) {
                    taskOwnerLookup = Xrm.Page.getAttribute("dobnyc_ms_cpeacpeteam").getValue();
                    taskOwner = (taskOwnerLookup != null && taskOwnerLookup != undefined) ? taskOwnerLookup[0].name : "";
                    isAllowed = hasMatchingRole(currentUserRoles, getRoleNameByTeam(taskOwner));
                }
                break;
            case 3:///QA A
                if (isWPTask > 0) {
                    assignedTeamName = "QA Team - Work Permits(PW2)";
                } else if (isLOCTask > 0) {
                    assignedTeamName = "QA Team - LOC";
                } else if (isAHVTask > 0) {
                    assignedTeamName = "AHV QA Administrator Team";
                }
                break;
            case 4:///QA S
                if (isWPTask > 0) {
                    assignedTeamName = "QA Supervisor Team - Work Permits(PW2)";
                } else if (isLOCTask > 0) {
                    assignedTeamName = "QA Supervisor Team - LOC";
                } else if (isAHVTask > 0) {
                    assignedTeamName = "AHV QA Administrator";
                }
                break;
            case 5:///PC QA S
                break;
            case 6:///PC QA A
                if (isWPAvailable > 0) {
                    assignedTeamName = "Prof-Cert With PW2 - QA Supervisor Team";
                }
                else {
                    if (PAA) {
                        assignedTeamName = "Prof-Cert PAA - QA Supervisor Team";
                    }
                    else {
                        assignedTeamName = "Prof-Cert Without PW2 - QA Supervisor Team";
                    }
                }
                break;
            case 13:///Central Assigner
                isAllowed = hasMatchingRole(currentUserRoles, RoleNames.CATeam);
                break;

            default:
                isAllowed = false;
                break;
        }

        if (isAllowed) {
            disableFormFields(false);
        } else {
            disableFormFields(true);
        }
    };

    var hideAddButtonSubgrid = function (subgridId) {
        debugger;
        try {
            addEventToGridRefresh(subgridId, setAddButtonDisplayNone);
        }
        catch (e) {

        }
    };

    var addEventToGridRefresh = function (subgridId, functionToCall) {
        // retrieve the subgrid
        var grid = document.getElementById(subgridId);
        // if the subgrid still not available we try again after 1 second
        if (grid == null) {
            setTimeout(function () { addEventToGridRefresh(subgridId, functionToCall); }, 1000);
            return;
        }

        // add the function to the onRefresh event
        grid.control.add_onRefresh(functionToCall);

        var imageId = subgridId + "_" + "addImageButton";
        if (imageId) {
            if (document.getElementById(imageId).style.display.toLowerCase() == "block") {
                setAddButtonDisplayNone(subgridId);
            }
        }
    };

    var setAddButtonDisplayNone = function (subgridId) {
        var imageId = subgridId + "_" + "addImageButton";
        if (imageId) {
            document.getElementById(imageId).style.display = 'none';
        }
    };

    var getInternetExplorerVersion = function () {
        var rv = -1;
        if (navigator.appName == 'Microsoft Internet Explorer') {
            var ua = navigator.userAgent;
            var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
            if (re.exec(ua) != null)
                rv = parseFloat(RegExp.$1);
        }
        else if (navigator.appName == 'Netscape') {
            var ua = navigator.userAgent;
            var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
            if (re.exec(ua) != null)
                rv = parseFloat(RegExp.$1);
        }
        return rv;
    };

    ///PW1 Standardization: Start
    var setBPFbyWorkType = function () {
        debugger;
        try {
            var isHistoricForm = (Xrm.Page.getAttribute("dobnyc_ishistoricfiling") != null) ? Xrm.Page.getAttribute("dobnyc_ishistoricfiling").getValue() : false;
            if (!isHistoricForm) {
                var currentJobFilingId = Xrm.Page.data.entity.getId();
                if (currentJobFilingId != null && currentJobFilingId != undefined) {
                    var returnAssociatedWorkTypes = null;
                    var workTypeName = '';
                    returnAssociatedWorkTypes = retrieveMultipleCustom("dobnyc_worktypeSet", "?$select=dobnyc_name,dobnyc_WorkType,dobnyc_worktypeId&$filter=dobnyc_AWT_GotoJobFiling/Id eq guid'" + currentJobFilingId + "'");
                    if (returnAssociatedWorkTypes != null && returnAssociatedWorkTypes.length > 0) {
                        for (var i = 0; i < returnAssociatedWorkTypes.length; i++) {
                            workTypeName = returnAssociatedWorkTypes[i].dobnyc_name;
                            if (workTypeName != '') {
                                selectBPFbyWorkType(workTypeName);
                                break;
                            }
                        }
                    }
                }
            }
        }
        catch (e) { alert(e); }
    };

    var selectBPFbyWorkType = function (workType) {
        debugger;
        if (workType != null) {
            switch (workType) {
                //PL, SP, SD with Legalization
                case (WorkType.PL):
                case (WorkType.SP):
                case (WorkType.PL_SP):
                case (WorkType.PL_LG):
                case (WorkType.SP_LG):
                case (WorkType.PL_SP_LG):
                case (WorkType.SD):
                case (WorkType.PL_SD):
                case (WorkType.SP_SD):
                case (WorkType.PL_SP_SD):
                    DOB.Utilities.SetBusinessProcessFlowbyName("DOB PL SP SD Business Process Flow");
                    break;
                    //AN, CC
                case (WorkType.AN):
                case (WorkType.CC):
                    DOB.Utilities.SetBusinessProcessFlowbyName("DOB AN CC Business Process Flow");
                    break;
                    //FAB4
                case (WorkType.FN):
                case (WorkType.SF):
                case (WorkType.SG):
                case (WorkType.SH):
                    DOB.Utilities.SetBusinessProcessFlowbyName("DOB FAB4 Business Process Flow");
                    break;
                    //PA, TPA
                case (WorkType.TPA):
                case (WorkType.PA):
                    //DOB.Utilities.SetBusinessProcessFlowbyName("DOB PA TPA Business Process Flow");
                    break;
                    //BE, MS, ST, GC
                case (WorkType.BE):
                case (WorkType.MS):
                case (WorkType.ST):
                case (WorkType.GC):
                    DOB.Utilities.SetBusinessProcessFlowbyName("DOB BE MS ST Business Process Flow");
                    break;
                case (WorkType.LAA):
                    break;
                case (WorkType.VT):
                    break;
                default:
                    DOB.Utilities.SetBusinessProcessFlowbyName("DOB PL SP SD Business Process Flow");
                    break;
            }
        }
    };

    var checkPW1Corrections = function () {
        debugger;
        var Taskform = (Xrm.Page.getAttribute("dobnyc_task_taskform") != null) ? Xrm.Page.getAttribute("dobnyc_task_taskform").getValue() : 0;
        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobFilingId = (gotoJobFiling.getValue() != null) ? gotoJobFiling.getValue()[0].id : "";
        var correctionsInitiated = areCorrectionsInitiated(jobFilingId);
        if (correctionsInitiated) {
            alert("Please be noted that corrections have been initiated by Applicant of Record during your review. \nAll actions are halted until corrections are completed.");
            switch (Taskform) {
                case 1:///CPE Filing:3				
                    break;
                case 2:///PE Filing:4
                    break;
                case 3:///QA A	
                    break;
                case 4:///QA S	
                    break;
                case 5:///PC QA S
                    if (Xrm.Page.getAttribute("dobnyc_assigntoqaclerk") != null) {
                        Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setValue(null);
                    }
                    break;
                case 6:///PC QA A
                    break;
                case 13:///Central Assigner
                    if (Xrm.Page.getAttribute("dobnyc_ms_cpeacpeteam") != null) {
                        Xrm.Page.getAttribute("dobnyc_ms_cpeacpeteam").setValue(null);
                    }
                    break;
                default:
                    break;
            }
            return false;
        }
    };

    var areCorrectionsInitiated = function (jobFilingId) {
        var isCorrectionInitiated = false;
        var returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_QAFailedReason,dobnyc_QAFailedStatus,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobFilingId + "'");
        isCorrectionInitiated = returnJobFiling[0].dobnyc_IsCorrectionInitiated;
        return isCorrectionInitiated;
    };

    ///PW1 Standardization: End

    ///==================================================================================================================
    /// Event :   Method Returns 
    ///==================================================================================================================

    return {
        ToggleLoader: toggleLoader
        , FilterUsersByTeam: filterUsersByTeam
        , GetMessage: getMessage
        , GetLookupDetails: getLookupDetails
        , SetCustomSectionBarValue: setCustomSectionBarValue
        , DisplayHideControls: displayHideControls
        , DisplayHideSections: displayHideSections
		, GetViewIdByName: getViewIdByName
		, GetRoleName: getRoleName
		, GetTeamRoleNames: getTeamRoleNames
		, DisableFormFields: disableFormFields
		, SetTaskPermissionsByRole: setTaskPermissionsByRole
		, HideAddButtonSubgrid: hideAddButtonSubgrid
		, HasMatchingRole: hasMatchingRole
		, SetBPFbyWorkType: setBPFbyWorkType
		, SelectBPFbyWorkType: selectBPFbyWorkType
		, CheckPW1Corrections: checkPW1Corrections
    };
}();