﻿///===================================================================================
/// Name        :   Elevator Safety Document List Form Scripts 
/// Description :   This will have All Methods for Elevator Safety DOcument List form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyDocumentList.js
/// Author      :   
///===================================================================================

var DOB = window.DOB || {};
DOB.ElevatorSafetyDocumentList = function () {
    var formContext;

    function onLoad(executionContext)
    {
        formContext = executionContext.getFormContext();
    }

    function acceptDocument() {
        debugger;
        try {
            var isValidRole = checkSecurityRole();
            if (isValidRole) {
                var DocumentURL = formContext.getAttribute("dobnyc_esdl_documenturl").getValue();
                var DocumentViewed = formContext.getAttribute("dobnyc_esdl_isdocumentviewed").getValue();

                if (DocumentViewed) {
                    var message = "Would you like to accept this document?";
                    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
                    function yesCloseCallback() {
                        formContext.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                        formContext.getAttribute("dobnyc_esdl_documentstatus").setValue(3);
                        formContext.data.entity.save();
                    }
                    function noCloseCallback() {
                        return;
                    }
                }
                else {
                    alert("Please view the document at least once before accepting it.");
                }

            }
            else {
                alert("insufficient privileges. Please Contact Administrator. ");
            }
        } catch (e) { }
    }

    function rejectDocument() {
        debugger;
        var isValidRole = checkSecurityRole();
        if (isValidRole) {
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = formContext.context.getUserId();
            lookup[0].name = formContext.context.getUserName();
            lookup[0].entityType = "systemuser";
            var loginId = lookup[0].id;
            var ViewedbyId = getLookupId("dobnyc_esdl_viewedby");
            if (ViewedbyId != loginId) {
                alert("Please view the document first before rejecting it.");
                return;
            }
            var message = "Would you like to reject this document?";
            Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
            function yesCloseCallback() {
                formContext.getAttribute("dobnyc_esdl_documentstatus").setSubmitMode("always");
                formContext.getAttribute("dobnyc_esdl_documentstatus").setValue(4);
                formContext.data.entity.save();
            }
            function noCloseCallback() {
                return;
            }
        }
        else {
            alert("insufficient privileges. Please Contact Administrator. ");
        }
    }

    function replaceDocument() {
        debugger;
        console.log('replace document code');
    }

    function replaceBracketsInGuid(id) {
        return id.replace("{", "").replace("}", "");
    }

    function downloadDocument() {
        try {
            debugger;
            var returnValue = null;
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = formContext.context.getUserId();
            lookup[0].name = formContext.context.getUserName();
            lookup[0].entityType = "systemuser";

            var URL = formContext.getAttribute("dobnyc_esdl_documenturl").getValue();

            if (URL == null) {
                alert("There is no document to download.");
                return;
            }

            var Id = formContext.data.entity.getId();

            var JBGUID = null;
            var path = null;
            var query;

            var Documentfor = formContext.getAttribute("dobnyc_esdl_regardingform").getValue();
            //alert("Documentfor: " + Documentfor);
            if (Documentfor == 1) //ELV3
            {

                JBGUID = getLookupId("dobnyc_esdl_elv3");
                JBGUID= replaceBracketsInGuid(JBGUID);

                /*    Sample for retreivemultiple using webapi 
                      1)add 's' to entity name
                      2)start query with $
                      3)all column names must be in small letters
                      4)output will be stored in "results.value"


                query = "$select=_ftc_ccp_boroughdirector_value,ftc_ccp_boroughid,ftc_name,ftc_ccp_boroughidcode,_ftc_ccp_boroughmanager_value,_ftc_ccp_teamcoordinator_value,ftc_name&$filter=ftc_name eq '" + encodeURIComponent(boroughNametoCCP) + "'";
                SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_ccp_boroughs", query, function (results) {
                    if (results.value.length > 0)  //Active requests exist
                    {
                        _ftc_ccp_boroughdirector_value = results.value[0]["_ftc_ccp_boroughdirector_value"];
                        ftc_ccp_boroughid = results.value[0]["ftc_ccp_boroughid"];
                        ftc_ccp_boroughidcode = results.value[0]["ftc_ccp_boroughidcode"];
                        _ftc_ccp_boroughmanager_value = results.value[0]["_ftc_ccp_boroughmanager_value"];

                        _ftc_ccp_teamcoordinator_value = results.value[0]["_ftc_ccp_teamcoordinator_value"];

                        ftc_name = results.value[0]["ftc_name"]
                    }

                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () { });
                */
            

                /*
                SAMPLE result format
                {entities:
                [0:
                {
                @odata.etag:"W/"239222136"",
                dobnyc_bin:"1000043",
                dobnyc_borough@OData.Community.Display.V1.FormattedValue:"MANHATTAN",
                dobnyc_borough:1,
                _dobnyc_elv3_elevatorid_value@OData.Community.Display.V1.FormattedValue:"1P12014",
                _dobnyc_elv3_elevatorid_value@Microsoft.Dynamics.CRM.associatednavigationproperty:"dobnyc_elv3_elevatorid",
                _dobnyc_elv3_elevatorid_value@Microsoft.Dynamics.CRM.lookuplogicalname:"dobnyc_elevatordevice",
                _dobnyc_elv3_elevatorid_value:"26c17389-965b-e711-810d-be63705ddcc1",
                dobnyc_elv3id:"5db66f7c-c1e9-e811-8125-005056ab45d6"}
                ]
                }
                */


                query = "$select= dobnyc_borough,dobnyc_name,dobnyc_elv3_elevatorid,_dobnyc_elv3_elevatorid_value&$filter=dobnyc_elv3id eq " + JBGUID;
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_elv3s", query, function (results) {
                    if (results.value.length > 0)  //Active requests exist
                    {
                      
                         path = "Elevators\\" + results.value[0]["_dobnyc_elv3_elevatorid_value@OData.Community.Display.V1.FormattedValue"] + '\\' + (results.value[0]["dobnyc_borough"]) + '\\' + results.value[0]["dobnyc_name"] + "\\Supporting Documents\\";
                    }

                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

              
            }
            else if (Documentfor == 2) //ELV29
            {
                JBGUID = getLookupId("dobnyc_esdl_elv29");
                JBGUID = replaceBracketsInGuid(JBGUID);
                query = "$select= dobnyc_borough,dobnyc_name,dobnyc_elv29_deviceid,_dobnyc_elv29_deviceid_value&$filter=dobnyc_elv29id eq " + JBGUID;
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_elv29s", query, function (results) {
                    if (results.value.length > 0)  //Active requests exist
                    {
                        
                        path = "Elevators\\" + results.value[0]["_dobnyc_elv29_deviceid_value@OData.Community.Display.V1.FormattedValue"] + '\\' + (results.value[0]["dobnyc_borough"]) + '\\' + results.value[0]["dobnyc_name"] + "\\Supporting Documents\\";
                    }

                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

             

            }
            else if (Documentfor == 3) //ELV36
            {

                JBGUID = getLookupId("dobnyc_esdl_elv36");
                JBGUID = replaceBracketsInGuid(JBGUID);
                query = "$select= dobnyc_elv36_borough,dobnyc_name,dobnyc_elv36_deviceid,_dobnyc_elv36_deviceid_value&$filter=dobnyc_elv36id eq " + JBGUID;
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_elv36s", query, function (results) {
                    if (results.value.length > 0)  //Active requests exist
                    {

                        path = "Elevators\\" + results.value[0]["_dobnyc_elv36_deviceid_value@OData.Community.Display.V1.FormattedValue"] + '\\' + (results.value[0]["dobnyc_elv36_borough"]) + '\\' + results.value[0]["dobnyc_name"] + "\\Supporting Documents\\";
                    }

                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

               
            }


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                //headers: {
                //    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                //},
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");
                        formContext.getAttribute("dobnyc_esdl_isdocumentviewed").setSubmitMode("always");
                        formContext.getAttribute("dobnyc_esdl_viewedby").setSubmitMode("always");
                        formContext.getAttribute("dobnyc_esdl_isdocumentviewed").setValue(true);
                        formContext.getAttribute("dobnyc_esdl_viewedby").setValue(lookup);
                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("The document download was unsuccessful.");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading the document. Please try again or contact your administrator.");
                }
            });
        } catch (e) { }
    }

    function getRelatedDocumentList(taskId, taskReviewField) {
        var fetchXml = '<fetch version="1.0">' +
            '<entity name="dobnyc_elevatorsafetydocumentlist" >' +
                '<attribute name="dobnyc_elevatorsafetydocumentlistid" />' +
                '<attribute name="dobnyc_esdl_documentstatus" />' +
                '<filter type="and">' +
                    '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
                '</filter>' +
              '</entity>' +
            '</fetch>';
        var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return documents;
    }

    function areDocumentsApproved(taskReviewAction, taskReviewField) {
        var taskId = formContext.data.entity.getId();
        var documents = getRelatedDocumentList(taskId, taskReviewField);
        var isApproved = true;
        for (var i = 0; i < documents.length; i++) {
            var statusValue = documents[i].attributes['dobnyc_esdl_documentstatus'].value;
            if (statusValue != 3) {
                isApproved = false;
            }
        }
        if (!isApproved) {
            alert("Must approve all documents in the Document List");
            formContext.getAttribute(taskReviewAction).setValue(null);
        }
        return isApproved;
    }

    function checkSecurityRole() {
        var isValidRole = false;
        var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.securityRoles; //formcontext will not give security roles so we need to use xrm.utility
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            //var userRoleName = getRoleName(userRoleId);
            var userRoleName = GetRoleName(userRoleId); //added newly for D365
            if (userRoleName == "System Administrator" || userRoleName == "Elevator Safety-QA Clerk" || userRoleName == "Elevator Safety-QA Supervisor") {
                return true;
            }

        }
        return isValidRole;
    }

    //added newly for D365
    function GetRoleName(userRoleId) {
        var roleName = null;

        SDK.WEBAPI.retrieveRecord(false, userRoleId, "role", "name", "",
            function (result) {
                if (result.length != 0) {
                    roleName = result["name"];
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

        //if (roleName != null)
        //    roleName = roleName.toLowerCase();

        return roleName;
    }

    function getRoleName(userRoleId) {
        //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
        var selectQuery = "RoleSet(guid'" + userRoleId + "')?$select=Name";
        var odataSelect = Xrm.Utility.getGlobalContext().getClientUrl() + "/XRMServices/2011/OrganizationData.svc/" + selectQuery; //clientURl also should ge fetched from xrm.utility
        //alert(odataSelect);
        var roleName = null;
        $.ajax({
            type: "GET",
            async: false,
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: odataSelect,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data, textStatus, XmlHttpRequest) {
                var result = data.d;
                if (!!result) {
                    roleName = result.Name;
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) {
                //alert('OData Select Failed: ' + odataSelect);
            }
        });
        return roleName;
    }

    function getLookupId(attributeName) {
        var lookupObject = formContext.getAttribute(attributeName);
        if (lookupObject != null) {
            var lookUpObjectValue = lookupObject.getValue();
            if ((lookUpObjectValue != null)) {
                var lookuptextvalue = lookUpObjectValue[0].name;
                var lookupid = lookUpObjectValue[0].id;
                return lookupid;
            }
        }
    }

    return {
        AcceptDocument: acceptDocument,
        RejectDocument: rejectDocument,
        ReplaceDocument: replaceDocument,
        DownloadDocument: downloadDocument,
        onLoad: onLoad
    };
}();