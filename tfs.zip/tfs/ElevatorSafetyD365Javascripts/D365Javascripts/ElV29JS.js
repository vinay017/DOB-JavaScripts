﻿///====================================================================
/// Name        :   Elevator Safety ELV29 JavaScripts
/// Description :   This will have All Methods for Elevator Safety ELV29 form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyELV29.js
/// Author      :   
///====================================================================
var DOB = window.DOB || {};
DOB.ElevatorSafetyELV29 = function () {

    var formContext = "";
    var ELV3InspectionType = {
        CAT1: 1,
        CAT3: 2,
        CAT5: 3,
        HoistJumpUP: 4,
        HoistJumpDown: 5,
        NinetyDayTempRenewal: 6,
        PVTInspection: 7,
        QCInspection: 8
    }
    var ELV29ReportStatus = {
        Prefiling: 1,
        QASupervisorReview: 2,
        QAReview: 3,
        QAFailed: 4,
        Accepted: 5,
        Incomplete: 6,
        CivilPenalitiesDue: 7,
        AcceptedDefects: 9
    }
    var elv29FormTabNames = {
        general: "General"
    }

    var elv29SectionNames = {

    }

    function onLoad(executionContext) {
        formContext = executionContext.getFormContext();
        showHideTaskURL();
    }


    function getLookupId(attributeName, formContext) {

        lookupObject = formContext.getAttribute(attributeName);

        if (lookupObject != null) {

            var lookUpObjectValue = lookupObject.getValue();

            if ((lookUpObjectValue != null)) {

                var lookuptextvalue = lookUpObjectValue[0].name;

                var lookupid = lookUpObjectValue[0].id;
                return lookupid;

            }

        }
    }

    function getLookupName(attributeName, formContext) {

        lookupObject = formContext.getAttribute(attributeName);

        if (lookupObject != null) {

            var lookUpObjectValue = lookupObject.getValue();

            if ((lookUpObjectValue != null)) {

                var lookuptextvalue = lookUpObjectValue[0].name;

                var lookupid = lookUpObjectValue[0].id;
                return lookuptextvalue;

            }

        }

    }


    function showHideTaskURL() {
        try {
            var currentReportStatus = formContext.getAttribute("dobnyc_elv29_reportstatus").getValue();
            if (!(currentReportStatus == ELV29ReportStatus.QASupervisorReview || currentReportStatus == ELV29ReportStatus.QAReview)) {
                formContext.getControl("dobnyc_elv29_currenttaskurl").setVisible(false);
            }
        }
        catch (e) { }
    }

    function viewPDF() {
        try {

           // var formContext = primaryControl;
            var returnValue = null;

            var URL = formContext.getAttribute("dobnyc_filingpdfurl").getValue();

            if (URL == null) {
                alert("There is no document to download.");
                return;
            }

            var JBGUID = formContext.data.entity.getId();
            var elv3Name = formContext.getAttribute("dobnyc_name").getValue();

            var path = "Elevators\\" + elv3Name + "\\Supporting Documents\\";


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                //headers: {
                //    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                //},
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");

                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("The document download was unsuccessful.");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading the document. Please try again or contact your administrator.");
                }
            });
        } catch (e) { }
    }

    function viewPDFButtonRule() {
        //var formContext = primaryControl;
        var userFilingActions = formContext.getAttribute("dobnyc_elv29_userfilingactions").getValue();
        if (userFilingActions == 3)//File
        {
            return true;
        }
        else {
            return false;
        }

    }

    function viewPDFELV36() {
        try {
           // var formContext = primaryControl;
            var returnValue = null;

            var URL = formContext.getAttribute("dobnyc_filingpdfurl").getValue();

            if (URL == null) {
                alert("There is no document to download.");
                return;
            }

            var JBGUID = formContext.data.entity.getId();
            var elv3Name = formContext.getAttribute("dobnyc_name").getValue();

            var path = "Elevators\\" + elv3Name + "\\Supporting Documents\\";


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                //headers: {
                //    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                //},
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");

                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("The document download was unsuccessful.");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading the document. Please try again or contact your administrator.");
                }
            });
        } catch (e) { }
    }

    function viewPDFButtonRuleELV36() {
        //var formContext = primaryControl;
        var userFilingActions = formContext.getAttribute("dobnyc_reportstatus").getValue();
        if (userFilingActions == 2)//File
        {
            return true;
        }
        else {
            return false;
        }

    }


    return {
        OnLoad: onLoad,
        viewPDF: viewPDF,
        viewPDFButtonRule: viewPDFButtonRule,
        viewPDFELV36: viewPDFELV36,
        viewPDFButtonRuleELV36: viewPDFButtonRuleELV36
    };
}();