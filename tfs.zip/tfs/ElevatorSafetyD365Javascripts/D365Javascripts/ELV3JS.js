﻿///====================================================================
/// Name        :   Elevator Safety Task Form Scripts 
/// Description :   This will have All Methods for Elevator Safety ELV3 form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyELV3.js
/// Author      :   
///====================================================================
var DOB = window.DOB || {};
DOB.ElevatorSafetyELV3 = function () {
    var formContext = "";
    var ELV3InspectionType = {
        CAT1: 1,
        CAT3: 2,
        CAT5: 3,
        HoistJumpUP: 4,
        HoistJumpDown: 5,
        NinetyDayTempRenewal: 6,
        PVTInspection: 7,
        QCInspection: 8
    }
    var ELV3ReportStatus = {
        Prefiling: 1,
        QASupervisorReview: 2,
        QAReview: 3,
        QAFailed: 4,
        Accepted: 5,
        Incomplete: 6,
        CivilPenalitiesDue: 7,
        AcceptedDefects: 9,
        NRF: 13
    }
    var elv3FormTabNames = {
        general: "General"
    }

    var elv3SectionNames = {
        witnessDirectorInfoSection: "WitnessDirectorInformationSection",
        witnessInspectorInfoSection: "WitnessInspectorInformationSection",
        witnessDirectorStatementsSection: "WitnessingAgencyDirectorStatementSection",
        witnessInspectorStatementsSection: "WitnessingAgencyInspectorStatementSection",
        OwnerStatementsandSignatures: "OwnerStatementsandSignatures"
    }

    function onLoad(executionContext) {
        formContext = executionContext.getFormContext();
        showHideSections();
        showHideCAT1andCat5SectionNames();//section lable change based on inspection type
        showHideTaskURL(); // based on report status hide and show Task URL
        showHidePVTQCFields(); //based on Inspection type hide and show fields
        showHideCAT5Fields(); //based on inspection type hide and show fields
        showHideDataMigrationFields();//if the elv3 is datamigrated record then display the notification 
        showHideCAT5NRFFields();// NRF fields Shows if status equals to NRF.
        if (formContext.getAttribute("dobnyc_reporttype") && formContext.getAttribute("dobnyc_reporttype").getValue() == 2) {
            personalHoistValidations();
        }
        else if (formContext.getAttribute("dobnyc_reporttype") && formContext.getAttribute("dobnyc_reporttype").getValue() == 1 && !(formContext.getAttribute("dobnyc_inspectiontype").getValue() == ELV3InspectionType.PVTInspection || formContext.getAttribute("dobnyc_inspectiontype").getValue() == ELV3InspectionType.QCInspection)) {


            if (!formContext.getAttribute("dobnyc_tnfsubmitted").getValue() && !formContext.getAttribute("dobnyc_elv3_ismigrated").getValue()) {
                formContext.ui.setFormNotification("The pre-inspection notification has not been submitted.", 'INFO', 'cat135Flag');
            }



            else if (formContext.getAttribute('dobnyc_tnfsubmitteddateadvancedays') && formContext.getAttribute('dobnyc_tnfsubmitteddateadvancedays').getValue() < 7) {


                if ((formContext.getAttribute('dobnyc_inspectiontype') && formContext.getAttribute('dobnyc_inspectiontype').getValue() == ELV3InspectionType.CAT1 || formContext.getAttribute('dobnyc_inspectiontype').getValue() == ELV3InspectionType.CAT5) && !formContext.getAttribute("dobnyc_elv3_ismigrated").getValue()) {
                    formContext.ui.setFormNotification("The pre-inspection notification has not been submitted 7 calendar days prior to inspection.", 'INFO', 'cat135Flag1');;
                }

            }
        }
    }


    function showHideDataMigrationFields() {
        var ismigrated = formContext.getAttribute("dobnyc_elv3_ismigrated").getValue();
        if (ismigrated) {
            DOB.AllUtilities.DisplayHideControls(["dobnyc_elv3_ismigrated"], true);
            formContext.ui.setFormNotification("This is a historic migrated record from BIS. ", 'INFO', 'elv3_ismigrated');;

        }


    }

    function showHideSections() {
        try {
            if (formContext.getAttribute("dobnyc_inspectiontype")) {
                var inspectionType = formContext.getAttribute("dobnyc_inspectiontype").getValue();
                if (inspectionType == ELV3InspectionType.CAT1 || inspectionType == ELV3InspectionType.PVTInspection || inspectionType == ELV3InspectionType.QCInspection) {
                    formContext.ui.tabs.get('General').sections.get('DefectsGrid').setVisible(true);
                }
            }
        }
        catch (e) {
        }
    }

    function showHidePVTQCFields() {
        debugger;
        try {

            var currentInspectionType = formContext.getAttribute("dobnyc_inspectiontype").getValue();
            if ((currentInspectionType == ELV3InspectionType.PVTInspection || currentInspectionType == ELV3InspectionType.QCInspection)) {
                DOB.AllUtilities.DisplayHideControls(["dobnyc_elv3_disposition", "dobnyc_elv3_alternatedeviceinservice", "dobnyc_elv3_sequencenumber", "dobnyc_elv3_violationdate", "dobnyc_elv3_starttime", "dobnyc_elv3_endtime"], true);
                //in PVT QC inspection type hide witness sections
                //"dobnyc_elv3_starttime", "dobnyc_elv3_endtime",
                DOB.AllUtilities.DisplayHideSections(elv3FormTabNames.general, [elv3SectionNames.witnessDirectorInfoSection, elv3SectionNames.witnessDirectorStatementsSection, elv3SectionNames.witnessInspectorInfoSection, elv3SectionNames.witnessInspectorStatementsSection, elv3SectionNames.OwnerStatementsandSignatures], false);
                //in PVT QC inspection type change the inspecting agency label to Approved agency
                DOB.AllUtilities.SetCustomSectionBarValue('WebResource_InspectingAgencyHeader', 'Approved Agency information');

                DOB.AllUtilities.SetCustomSectionBarValue('WebResource_InspectingDirectorStatements', "Approved Agency Director/Co-Director's Statement and Signature");
                DOB.AllUtilities.SetCustomSectionBarValue('WebResource_InspectionInspectorsection', "Approved Agency Inspector's Statement and Signature");
                DOB.AllUtilities.SetCustomSectionBarValue('WebResource_PerformingAgencyDirector', "Director/Co-Director Information");
                formContext.ui.tabs.get('General').sections.get('{8db01b81-02fe-4fa2-b940-123b5b09e2a9}_section_5').setLabel("Inspector Information");
                //formContext.getControl("{8db01b81-02fe-4fa2-b940-123b5b09e2a9}_section_5").setLabel("Inspector Information")
                //formContext.getControl("WitnessInspectorInformationSection").setLabel('Inspector Information');
                //Hide Owner Section fields
                DOB.AllUtilities.DisplayHideControls(["dobnyc_owner_email", "dobnyc_owner_type", "dobnyc_propertyowner_lastname", "dobnyc_elv3_mi", "dobnyc_propertyowner_state", "dobnyc_propertyowner_zip", "dobnyc_propertyowner_businesstelephone", "dobnyc_propertyowner_mobile", "dobnyc_filingyear"], false);
                //Change the Labels of owner section
                formContext.getControl("dobnyc_propertyowner_firstname").setLabel('Name');

                formContext.getControl("dobnyc_propertyowner_businessname").setLabel('Corporation Name');
                formContext.getControl("dobnyc_propertyowner_address").setLabel('Street');
                if (currentInspectionType == ELV3InspectionType.PVTInspection) {
                    formContext.getControl("dobnyc_inspectiontestdate").setLabel('PVT Inspection Date');
                }
                else {
                    formContext.getControl("dobnyc_inspectiontestdate").setLabel('QC Inspection Date');
                }



            }
            else {
                DOB.AllUtilities.DisplayHideControls(["dobnyc_elv3_ceaseuse", "dobnyc_elv3_violation", "dobnyc_elv3_ceaseuse1", "dobnyc_elv3_violation1"], false);

            }
        }
        catch (e) {
        }
    }

    function showHideCAT5Fields() {
        try {

            var currentInspectionType = formContext.getAttribute("dobnyc_inspectiontype").getValue();
            if (currentInspectionType == ELV3InspectionType.CAT5) {
                DOB.AllUtilities.DisplayHideControls(["dobnyc_filingyear", "dobnyc_elv3_isdefectsexist"], false); //for CAT5 filing year should be hidden

            }
        }
        catch (e) {
        }
    }

    function showHideCAT5NRFFields() {
        try {

            var currentReportStatus = formContext.getAttribute("dobnyc_elv3_reportstatus").getValue();
            if (currentReportStatus == ELV3ReportStatus.NRF) {
                formContext.getControl("dobnyc_elv3_violationdate").setVisible(true);
                formContext.getControl("dobnyc_elv3_violation").setVisible(true);
                formContext.getControl("dobnyc_elv3_elv3nrffee").setVisible(true);
            }
        }
        catch (e) {
        }
    }

    function showHideCAT1andCat5SectionNames() {
        try {

            var currentInspectionType = formContext.getAttribute("dobnyc_inspectiontype").getValue();
            if (!(currentInspectionType == ELV3InspectionType.CAT5 || currentInspectionType == ELV3InspectionType.CAT1)) {
                formContext.getControl("WebResource_PerformingAgencyDirector").setVisible(false);
                formContext.getControl("WebResource_PerformingAgencyDirector1").setVisible(true);
               // DOB.AllUtilities.SetCustomSectionBarValue('WebResource_PerformingAgencyDirector', "Director/Co-Director Information");
                formContext.ui.tabs.get('General').sections.get('{8db01b81-02fe-4fa2-b940-123b5b09e2a9}_section_5').setLabel("Inspector Information");
                formContext.getControl("WebResource_WitnessingAgencyDirector").setVisible(false);
                formContext.getControl("WebResource_WitnessingAgencyDirector1").setVisible(true);
               // DOB.AllUtilities.SetCustomSectionBarValue('WebResource_WitnessingAgencyDirector', "Director/Co-Director Information");
                formContext.ui.tabs.get('General').sections.get('WitnessInspectorInformationSection').setLabel("Inspector Information");

            }
        }
        catch (e) {
        }
    }




    function getLookupId(attributeName) {

        lookupObject = formContext.getAttribute(attributeName);

        if (lookupObject != null) {

            var lookUpObjectValue = lookupObject.getValue();

            if ((lookUpObjectValue != null)) {

                var lookuptextvalue = lookUpObjectValue[0].name;

                var lookupid = lookUpObjectValue[0].id;
                return lookupid;

            }

        }
    }

    function getLookupName(attributeName) {

        lookupObject = formContext.getAttribute(attributeName);

        if (lookupObject != null) {

            var lookUpObjectValue = lookupObject.getValue();

            if ((lookUpObjectValue != null)) {

                var lookuptextvalue = lookUpObjectValue[0].name;

                var lookupid = lookUpObjectValue[0].id;
                return lookuptextvalue;

            }

        }

    }


    function showHideTaskURL() {
        try {
            var currentReportStatus = formContext.getAttribute("dobnyc_elv3_reportstatus").getValue();
            if (!(currentReportStatus == ELV3ReportStatus.QASupervisorReview || currentReportStatus == ELV3ReportStatus.QAReview)) {
                formContext.getControl("dobnyc_elv3_currenttaskurl").setVisible(false);
            }
        }
        catch (e) { }
    }

    function personalHoistValidations() {
        try {
            DOB.AllUtilities.DisplayHideSections(elv3FormTabNames.general, ["PrivateResidence"], false);
            DOB.AllUtilities.DisplayHideControls(["dobnyc_filingyear", "dobnyc_elv3_isdefectsexist", "dobnyc_elv3_isitprivateresidence"], false); //for PersonalHoist filing year should be hidden\
            // DOB.AllUtilities.DisplayHideControls(["dobnyc_elv3_90daytempdate"], true); //for PersonalHoist temp 90 day  should be show
            // Flag - TNF not Submitted
            if (formContext.getAttribute("dobnyc_tnfsubmitted")) {
                if (!formContext.getAttribute("dobnyc_tnfsubmitted").getValue()) {
                    formContext.ui.setFormNotification("The pre-inspection notification has not been submitted.", 'INFO', 'personalHoistFlag1');
                }
                    // Flag - TNF not Submitted 3 days adv
                else if (formContext.getAttribute("dobnyc_tnfsubmitted3daysadvance") && !formContext.getAttribute("dobnyc_tnfsubmitted3daysadvance").getValue()) {
                    formContext.ui.setFormNotification("The pre-inspection notification has not been submitted 3 business days before inspection.", 'INFO', 'personalHoistFlag2');;
                }
            }
            // Inspection date ahead 1 day
            if (formContext.getAttribute("dobnyc_inspectiondateahead1day") && formContext.getAttribute("dobnyc_inspectiondateahead1day").getValue()) {
                formContext.ui.setFormNotification("Inspection date is more than 1 business day from the report submission date.", 'INFO', 'personalHoistFlag3');;
            }
            // 90 days expired on tnf submit
            if (formContext.getAttribute("dobnyc_90daysexpiredontnfsubmitdate")) {
                if (formContext.getAttribute("dobnyc_90daysexpiredontnfsubmitdate").getValue()) {
                    formContext.ui.setFormNotification("The 90 day temp renewal expired on the date that the pre-inspection notification was submitted.", 'INFO', 'personalHoistFlag4');
                }
                else if (formContext.getAttribute("dobnyc_90daysexpiredoninspectiondate") && formContext.getAttribute("dobnyc_90daysexpiredoninspectiondate").getValue()) {
                    formContext.ui.setFormNotification("The 90 day temp renewal expired on the date of inspection.", 'INFO', 'personalHoistFlag5');;
                }
            }
            // 90 days expired on inspection date
            //Build Permit Expirey

            if (formContext.getAttribute("dobnyc_elv3_isbuildpermitexpired") && formContext.getAttribute("dobnyc_elv3_isbuildpermitexpired").getValue()) {
                formContext.ui.setFormNotification("Permit expired on the date of inspection.", 'INFO', 'personalHoistFlag6');
            }
            //Build Permit Expirey

            //Hide and show witness Statements and signatures
            var witnessDirectorLookupID = getLookupId("dobnyc_witnessagency_director");
            //if director is not given then hide all witness statements sections
            if (!(witnessDirectorLookupID && witnessDirectorLookupID != null)) {
                DOB.AllUtilities.DisplayHideSections(elv3FormTabNames.general, [elv3SectionNames.witnessDirectorStatementsSection, elv3SectionNames.witnessInspectorStatementsSection], false);

            }
            //Hide and show witness Statements and signatures
            //show Floor from Floor To for Jump up/Down Inspections
            var currentInspectionType = formContext.getAttribute("dobnyc_inspectiontype").getValue();
            if ((currentInspectionType == ELV3InspectionType.HoistJumpDown || currentInspectionType == ELV3InspectionType.HoistJumpUP)) {
                DOB.AllUtilities.DisplayHideControls(["dobnyc_elv3_floorfrom", "dobnyc_elv3_floorto"], true);
            }

            //show Floor from Floor To for Jump up/Down Inspections


        }
        catch (e) { }
    }

    //download document from documentum.
    function viewPDF() {
        try {

            var returnValue = null;

            var URL = formContext.getAttribute("dobnyc_filingpdfurl").getValue();

            if (URL == null) {
                alert("There is no document to download.");
                return;
            }

            var JBGUID = formContext.data.entity.getId();
            var elv3Name = formContext.getAttribute("dobnyc_trackingnumber").getValue();

            var path = "Elevators\\" + elv3Name + "\\Supporting Documents\\";


            $.support.cors = true;

            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
                processData: true,
                crossDomain: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
                cache: false,
                //headers: {
                //    'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
                //},
                beforeSend: function (XMLHttpRequest) {
                    XMLHttpRequest.setRequestHeader("Accept", "application/json");
                },
                success: function (data, textStatus, XmlHttpRequest) {
                    if (data.DownloadIsSuccess == true) {
                        //alert("Download Successful");

                        window.open(data.downloadPath);

                    }
                    else {

                        //alert(data.ErrorDescription);
                        alert("The document download was unsuccessful.");
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading the document. Please try again or contact your administrator.");
                }
            });
        } catch (e) { }
    }
    //enable disable rule for view filing button
    function viewPDFButtonRule() {
        var userFilingActions = formContext.getAttribute("dobnyc_elv3_userfilingactions").getValue();
        if (userFilingActions == 3)//File
        {
            return true;
        }
        else {
            return false;
        }

    }


    return {
        OnLoad: onLoad,
        viewPDF: viewPDF,
        viewPDFButtonRule: viewPDFButtonRule
    };
}();