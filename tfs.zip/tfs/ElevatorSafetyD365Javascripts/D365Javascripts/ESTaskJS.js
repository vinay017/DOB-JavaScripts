﻿///====================================================================
/// Name        :   Elevator Safety Task Form Scripts 
/// Description :   This will have All Methods for Elevator Safety Task form
/// Usage       :   
/// Script Name :   DOBNYC_ElevatorSafetyTask.js
/// Author      :   
///====================================================================
var DOB = window.DOB || {};
DOB.ElevatorSafetyTask = function () {
    var formContext = "";
    function onLoad(executionContext) {
        formContext = executionContext.getFormContext();
        setTaskForm();
        showHideSections();
        actionOnChange();
        qaReviewActionOptionsSet();
    }
    function actionOnChange(executionContext) {
        try {
            var attribute, results;
            if (executionContext) {
                attribute = executionContext.getEventSource();
            }
            else if (formContext.getAttribute("dobnyc_est_reportstatus").getValue() == 2) {
                attribute = formContext.getAttribute('dobnyc_est_elv3qasupervisoraction');
            }
            else if (formContext.getAttribute("dobnyc_est_reportstatus").getValue() == 3) {
                attribute = formContext.getAttribute('dobnyc_est_elv3qareviewaction');
            }
            if (attribute.getName() == 'dobnyc_est_elv3qasupervisoraction') {
                switch (attribute.getValue()) {
                    //Assign QA
                    case 1:
                        formContext.getControl("dobnyc_est_assignto").setVisible(true);
                        formContext.getAttribute("dobnyc_est_assignto").setRequiredLevel("required");
                        formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                        //Incomplete Submission
                    case 2:
                        formContext.getControl("dobnyc_est_assignto").setVisible(false);
                        formContext.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //none
                    default:
                        formContext.getControl("dobnyc_est_assignto").setVisible(false);
                        formContext.getAttribute("dobnyc_est_assignto").setRequiredLevel("none");
                        formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
            else if (attribute.getName() == 'dobnyc_est_elv3qareviewaction') {
                switch (attribute.getValue()) {
                    case 3:
                    case 4:
                        formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                    case 6:
                        results = areDocumentsApproved("dobnyc_est_elv3qareviewaction", "dobnyc_esdl_qareviewtask");
                        formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("required");
                        break;
                        //other cases
                    case 1:
                        results = areDocumentsApproved("dobnyc_est_elv3qareviewaction", "dobnyc_esdl_qareviewtask");
                        if (results == true)
                            formContext.getAttribute("dobnyc_est_externalcomments").setRequiredLevel("none");
                        break;
                }
            }
        } catch (e) { }
    }

    function GetRelatedDocumentList(taskId, taskReviewField) {
        fetchXml = '<fetch version="1.0">' +
            '<entity name="dobnyc_elevatorsafetydocumentlist" >' +
            '<attribute name="dobnyc_elevatorsafetydocumentlistid" />' +
            '<attribute name="dobnyc_esdl_documentstatus" />' +
            '<filter type="and">' +
            '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
            '</filter>' +
            '</entity>' +
            '</fetch>';
        var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
        return documents;
    }

    function GetRelatedDocumentListWebapi(taskId, taskReviewField) {
        var finalResults;
        taskId = replaceBracketsInGuid(taskId);

        var query = "$select=dobnyc_esdl_documentstatus&$filter=_" + taskReviewField + "_value eq " + taskId;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_elevatorsafetydocumentlists", query, function (results) {
            if (results.value.length > 0)  //Active requests exist
            {
                finalResults = results;

            }

        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        return finalResults;
    }

    function areDocumentsApproved(taskReviewAction, taskReviewField) {
        var taskId = formContext.data.entity.getId();
        var nextAction = formContext.getAttribute(taskReviewAction).getValue();
        if (nextAction == null)
            return true;//false;
        var documents = GetRelatedDocumentListWebapi(taskId, taskReviewField);

        var isApproved = true;
        if (documents != null)
        {
            for (i = 0; i < documents.value.length; i++) {
                var statusValue = documents.value[i]['dobnyc_esdl_documentstatus'];
                if (statusValue != 3) {
                    isApproved = false;
                }
            }
        }
       
        if (!isApproved) {
            var alertStrings = { confirmButtonLabel: "Yes", text: "Must approve all documents before submitting..", title: "Warning" };
            var alertOptions = { height: 120, width: 260 };
            Xrm.Navigation.openAlertDialog(alertStrings, alertOptions)
           // alert("Must approve all documents before submitting.");
            formContext.getAttribute(taskReviewAction).setValue(null);
        }
        return isApproved;
    }

    function replaceBracketsInGuid(id) {
        return id.replace("{", "").replace("}", "");
    }

    function getELV3InspectionType(elv29id)
    {
        let inspectionType;
        var req = new XMLHttpRequest();
        req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.0/dobnyc_elv29s?$expand=dobnyc_elv29_elv3lookup($select=dobnyc_inspectiontype)&$filter=dobnyc_elv29id eq "+elv29id, false);
        req.setRequestHeader("OData-MaxVersion", "4.0");
        req.setRequestHeader("OData-Version", "4.0");
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var results = JSON.parse(this.response);
                    for (var i = 0; i < results.value.length; i++) {
                       
                        //Use @odata.nextLink to query resulting related records
                        inspectionType=  results.value[i].dobnyc_elv29_elv3lookup.dobnyc_inspectiontype;
                    }
                } else {
                    Xrm.Utility.alertDialog(this.statusText);
                }
            }
        };
        req.send();
        return inspectionType;
    }
    function qaReviewActionOptionsSet() {
        try {
            debugger;
            if (formContext.getAttribute("dobnyc_est_reportstatus").getValue() == 3)// QA Review
            {
                var inspection_Type;
                if (formContext.getAttribute("dobnyc_est_taskformfor").getValue() == 2) //ELV 29
                {
                   
                    //get inspection type of elv3					
                    var elv29id = formContext.getAttribute('dobnyc_est_clicktogotoelv29').getValue()[0].id;
                    elv29id = replaceBracketsInGuid(elv29id);
                    inspection_Type= getELV3InspectionType(elv29id);
                    if (inspection_Type == 7 || inspection_Type == 8) //PVT/QC aoc
                    {
                        formContext.getControl("dobnyc_est_elv3qareviewaction").removeOption(1);	//Remove "Accepted" option					
                    }
                    else //cat1 aoc
                    {
                        formContext.getControl("dobnyc_est_elv3qareviewaction").removeOption(5);	//Remove "Corrections Accepted-Violations Dismissed" option					
                        formContext.getControl("dobnyc_est_elv3qareviewaction").removeOption(6);	//Remove "Corrections Accepted-Violations Not Dismissed" option					
                    }
                }
                else if (formContext.getAttribute("dobnyc_est_taskformfor").getValue() == 1)//ELV 3
                {
                    formContext.getControl("dobnyc_est_elv3qareviewaction").removeOption(5);	//Remove "Corrections Accepted-Violations Dismissed" option					
                    formContext.getControl("dobnyc_est_elv3qareviewaction").removeOption(6);	//Remove "Corrections Accepted-Violations Not Dismissed" option	
                }
            }
        }
        catch (e) { }
    }

    function setTaskForm() {
        try {
            var Taskform = formContext.getAttribute("dobnyc_est_taskformfor").getValue();
            var form = formContext.ui.formSelector.getCurrentItem();
            if (form != null) {
                var formId = form.getId();
                var formLabel = form.getLabel();
            }
            if (Taskform == 1 && formLabel != "ELV3 Task Form") {
                var items = formContext.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();

                    if (formLabel == "ELV3 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
            if (Taskform == 2 && formLabel != "ELV29 Task Form") {
                var items = formContext.ui.formSelector.items.get();
                for (var i in items) {
                    var form = items[i];
                    var formId = form.getId();
                    var formLabel = form.getLabel();
                    if (formLabel == "ELV29 Task Form") {
                        form.navigate();
                        return;
                    }
                }
            }
        } catch (e) { }
    }
    function showHideSections() {
        try {
            if (formContext.getAttribute("dobnyc_est_reportstatus")) {
                var elv3ReportStatus = formContext.getAttribute("dobnyc_est_reportstatus").getValue();
                var elv3QASuperSectionNames = ['QASDocumentSection', 'QASupervisorReviewSection'];
                var elv3QASectionNames = ['QADocumentSection', 'QAReviewSection'];

                //QA Supervisor Review
                if (elv3ReportStatus == 2) {
                    for (var i = 0; i < elv3QASuperSectionNames.length; i++)
                    {
                        formContext.ui.tabs.get('General').sections.get(elv3QASuperSectionNames[i]).setVisible(true);
                    }
                   
                    formContext.getAttribute("dobnyc_est_elv3qasupervisoraction").setRequiredLevel("required");
                }
                    //QA Review
                else if (elv3ReportStatus == 3) {
                    for (var i = 0; i < elv3QASectionNames.length; i++) {
                        formContext.ui.tabs.get('General').sections.get(elv3QASectionNames[i]).setVisible(true);
                    }
                    ;
                    formContext.getAttribute("dobnyc_est_elv3qareviewaction").setRequiredLevel("required");
                }
            }
        } catch (e) { }
    }
    return {
        OnLoad: onLoad,
        ActionOnChange: actionOnChange
    };
}();