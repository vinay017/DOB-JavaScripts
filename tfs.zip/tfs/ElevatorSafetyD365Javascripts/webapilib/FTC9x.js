﻿/*
statuscodeName Values:
    new
	in progress
	pending with supervisor
	pending with manager
	returned for modification
    submitted
	assigned to facilitator
	completed
	expired
	auto closed
	withdrawn

FTCUserRole Values:
	requestor
	scheduler
	facilitator
	
72564204-2593-418a-9d13-fad6de625f2e : Review & Submit StageID	
*/
//Global Variables==========================================================
var FTCUserID;
var FTCUserID_NoBraces;

var statuscodeName;

var StageID_GUID;

var IsReadonlyForm = false;

var FTCUserRole = "requestor";

let FTCBoroughNames = { BnxNorth: "Bronx (North)", BnxSouth: "Bronx (South)", BklynEast: "Brooklyn (East)", BklynWest: "Brooklyn (West)", Queens: "Queens", Staten: "Staten Island", MN: "Manhattan (North)", MS: "Manhattan (South)" };
let CCPBoroughNames = { BnxNorth: "Bronx North", BnxSouth: "Bronx South", BklynEast: "Brooklyn East", BklynWest: "Brooklyn West", Queens: "Queens", Staten: "Staten Island", MN: "Manhattan" };
let disciplines = { DV: 1, MH: 2, Medical: 3, Substanc: 4, Education: 5 };//used in fetching the correct consultation team. Both earlychildhood and adolescent belongs to education category
let disciplinesCheckBoxes = { DV: "DV", MH: "MH", SU: "SU", MED: "MED", EDU: "ECD", AD: "AD" };
//==========================================================================

function RFForm_Onload() {
    //debugger;
    //Set Global Variables========================================================	
    FTCUserID = Xrm.Page.context.getUserId();
    FTCUserID_NoBraces = replaceBracketsInGuid(FTCUserID);
    statuscodeName = Xrm.Page.getAttribute("statuscode").getText().toLowerCase();


    if (Xrm.Page.getAttribute("ftc_ftcstageid").getValue() !== null) {
        StageID_GUID = Xrm.Page.getAttribute("ftc_ftcstageid").getValue()[0].id;
    }

    //Lock Assign Application to scheduler-Start
    let isSchedulerAssigned = Xrm.Page.getAttribute("ftc_assignapplicationtoscheduler").getValue();
    if (isSchedulerAssigned) {
        DisableControls(["ftc_assignapplicationtoscheduler"]);
    }
    //Lock Assign Application to scheduler-End

    FTCUserRole = GetFTCUserRole();

    //Service Termination Conferenece Type Logic-start
    serviceTerminationConferenceLogic();
    serviceTerminationReasonOnChange();
    //Service Termination Conferenece Type Logic-End


    //Add event handlers
    if (FTCUserRole === "scheduler" || FTCUserRole === "facilitator" || FTCUserRole === "ftc admin") {
        Xrm.Page.getControl("ftc_sch_assignedfacilitator").addPreSearch(addFacilitatorFilter);
        Xrm.Page.getControl("ftc_sch_facilitatorborough").addPreSearch(addFacilitatorBoroughFilter);
        Xrm.Page.getControl("ftc_fac_whatwasupdatedpurposeofconf").addPreSearch(addUpdatedConfFilter);
    }

    Xrm.Page.getControl("ftc_locofconfteam").addPreSearch(addLocOfConfTeamFilter);
    Xrm.Page.getControl("ftc_relationshiptochild").addPreSearch(addRelationshipToChildFilter);
    Xrm.Page.getControl("ftc_relationshiptochild1").addPreSearch(addRelationshipToChildFilter1);
    Xrm.Page.getControl("ftc_relationshiptochild2").addPreSearch(addRelationshipToChildFilter2);
    Xrm.Page.getControl("ftc_relationshiptochild3").addPreSearch(addRelationshipToChildFilter3);


    Xrm.Page.data.process.addOnStageChange(RFForm_OnStageChange);
    Xrm.Page.data.process.addOnProcessStatusChange(RFForm_OnProcessStatusChange);
    Xrm.Page.data.process.addOnStageSelected(RFForm_OnStageSelected);
    //==============================================================================

    if (statuscodeName === "new") {
        Xrm.Page.getAttribute("ftc_requestedby").setValue(GetCurrentUser());
        Xrm.Page.getAttribute('ftc_dateofconferencerequest').setValue(GetCurrentDate());

        //Agency Name: ods_nmempofficename
        //Agency Code: ods_cdempofficemail
        SDK.WEBAPI.retrieveRecord(false, FTCUserID_NoBraces, "systemuser", "ods_nmempofficename,ods_cdempofficemail", "",
            function (result) {

                if (result.length != 0) {
                    Xrm.Page.getAttribute("ftc_agency").setValue(result.ods_nmempofficename);
                    Xrm.Page.getAttribute("ftc_agencycode").setValue(result.ods_cdempofficemail);
                }


            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    }


    if (FTCUserRole === "facilitator" && statuscodeName == "assigned to facilitator") {
        var StageID = Xrm.Page.getAttribute('ftc_stageid').getValue();
        var CP_User = GetCPForStage(StageID);

        if (CP_User !== null) {
            SDK.WEBAPI.retrieveRecord(true, CP_User[1], "systemuser", "address1_telephone1,fullname,ods_cdempofficemail", "",
                function (result) {
                    if (result.length != 0) {
                        Xrm.Page.getAttribute('ftc_fac_caseplannername').setValue(result["fullname"]);
                        Xrm.Page.getAttribute('ftc_fac_caseplannerphone').setValue(result["address1_telephone1"]);
                        Xrm.Page.getAttribute('ftc_fac_caseplanningagency').setValue(result["ods_cdempofficemail"]);
                    }
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
        }
        else {
            var Requestor_GUID;

            if (Xrm.Page.getAttribute("ftc_requestedby").getValue() !== null) {
                Requestor_GUID = Xrm.Page.getAttribute("ftc_requestedby").getValue()[0].id;
            }

            SDK.WEBAPI.retrieveRecord(true, replaceBracketsInGuid(Requestor_GUID), "systemuser", "address1_telephone1,fullname", "$expand=parentsystemuserid($select=address1_telephone1,fullname)",
                function (result) {
                    if (result.length != 0) {
                        Xrm.Page.getAttribute('ftc_fac_childprotspecname').setValue(result["fullname"]);
                        Xrm.Page.getAttribute('ftc_fac_childprotspecphone').setValue(result["address1_telephone1"]);
                        if (result.hasOwnProperty("parentsystemuserid")) {
                            Xrm.Page.getAttribute('ftc_fac_cpssupname').setValue(result["parentsystemuserid"]["fullname"]);
                            Xrm.Page.getAttribute('ftc_fac_cpssupphone').setValue(result["parentsystemuserid"]["address1_telephone1"]);
                        }
                    }
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

        }
    }


    Xrm.Page.getAttribute("ftc_sch_reschedule").setValue(false);

    Xrm.Page.getAttribute("ftc_reqtoreschconf").setValue(false);

    SetFormState(FTCUserRole, statuscodeName, Xrm.Page.data.process.getActiveStage().getName());
}

function RFForm_OnProcessStatusChange() {
    //getting the Status here as it will be changed by BPF Workflows
    statuscodeName = Xrm.Page.getAttribute("statuscode").getText().toLowerCase();

    SetFormState(FTCUserRole, statuscodeName, "Facilitator");
}

function RFForm_OnStageChange(ExecutionContextObj) {

    var ActiveStage = Xrm.Page.data.process.getActiveStage().getName();

    //alert(ExecutionContextObj.getEventArgs().getDirection())

    //getting the Status here as it will be changed by BPF Workflows
    statuscodeName = Xrm.Page.getAttribute("statuscode").getText().toLowerCase();

    //if (statuscodeName === "returned for modification" && ActiveStage !== "Review & Submit")
    if ((statuscodeName === "returned for change by supervisor" || statuscodeName === "returned for change by manager") && ActiveStage !== "Review & Submit")
        setActiveStage("72564204-2593-418a-9d13-fad6de625f2e", "Review & Submit", 5);

    SetFormState(FTCUserRole, statuscodeName, ActiveStage);

    //CCP Form Creation Start

    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())

    if (ConfType != null) {
        ConfType = ConfType.name.toLowerCase()
    }
    //below code should work only for Child Safety conference
    if (ConfType == "child safety conference" && (ActiveStage == "Supervisor" || ActiveStage == "Manager")) {
        CCPFormCreation(replaceBracketsInGuid(Xrm.Page.data.entity.getId()));
    }
    //CCP Form Creation End

}

function CCPFormCreation(ftcId) {

    //Get the FTC ID ,Conference Type==Child SafetyConf
    //Check this FTC ID has any CCP applications already created
    //If not created then loop through reason for conference to identify the disciplines. if none of the disciplines matches with CCP then return
    //else create the CCP by collecting general information , Borough Info, 
    //then based on borough identify the team corodinator,directors,managers for that borough
    //Based on the discipline identify the Consultunt Teams.
    //set the isSubmit flag to yes and put the Parent CCP in inprocess stage.

    var prevApplicationPresent = false;




    let query = "$select=ftc_name&$filter=_ftc_ccp_ftcrequestform_value eq " + ftcId;

    //check if any ccp requests present with passed Ftc id
    SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_ccprequestforms", query, function (results) {
        if (results.value.length > 0)  //Active requests exist
        {
            prevApplicationPresent = true;
        }
        else                        //No Active requests exist
        {
            prevApplicationPresent = false;
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    if (prevApplicationPresent) {
        //application already present so return
        return;
    }




    //loop through  Reasons and identify the disciplines for CCP

    let isDV = false, isMH = false, isSU = false, isMed = false, isECD = false, isAd = false, boroughNameFromFTC, boroughNametoCCP;

    var _ftc_ccp_boroughdirector_value, ftc_name;
    var _ftc_ccp_boroughdirector_value_formatted;
    var _ftc_ccp_boroughdirector_value_lookuplogicalname;
    var ftc_ccp_boroughid;
    var ftc_ccp_boroughidcode;
    var _ftc_ccp_boroughmanager_value;
    var _ftc_ccp_boroughmanager_value_formatted;
    var _ftc_ccp_boroughmanager_value_lookuplogicalname;
    var _ftc_ccp_teamcoordinator_value;
    var _ftc_ccp_teamcoordinator_value_formatted;
    var _ftc_ccp_teamcoordinator_value_lookuplogicalname;

    let DVTeamLookup, SUTeamLookup, MedTeamLookup, EduTeamLookup;

    let ftcFilelds;//used to store the results from below query

    SDK.WEBAPI.retrieveRecord(false, ftcId, "ftc_ftcrequestform", "ftc_acscasenumber,ftc_agency,_ftc_requestormanager_value,_ftc_requestorsupervisor_value,ftc_agencycode,ftc_casename,ftc_dateofconferencerequest,_ftc_ftcstageid_value,_ftc_locofconfteam_value,ftc_pid,ftc_preferredconfdate1,_ftc_requestedby_value,ftc_stageid", "$expand=ftc_ftc_ftcrequestform_ftc_conferencerequestr($select=ftc_name)",
        function (result) {
            if (result.length != 0) {
                ftcFilelds = result;
                if (result["ftc_ftc_ftcrequestform_ftc_conferencerequestr"] != null && result["ftc_ftc_ftcrequestform_ftc_conferencerequestr"].length > 0) {
                    for (let i = 0; i < result["ftc_ftc_ftcrequestform_ftc_conferencerequestr"].length; i++) {
                        let reasonValue = result["ftc_ftc_ftcrequestform_ftc_conferencerequestr"][i]["ftc_name"].toLowerCase();
                        switch (reasonValue) {
                            case "domestic violence":
                                {
                                    isDV = true;
                                    break;
                                }
                            case "mental health":
                                {
                                    isMH = true;
                                    break;
                                }
                            case "substance abuse":
                            case "substance misuse/abuse":
                                {
                                    isSU = true;
                                    break;
                                }
                            case "health concerns (mental or medical/hospitalization)":
                                {
                                    isMed = true;
                                    break;
                                }
                            default:
                                {
                                    break;
                                }

                        }


                    }

                }


            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    //check the DV falg in FTC 

    if (Xrm.Page.getAttribute("ftc_isdvconference").getValue()) {
        isDV = true;
    }


    if (isDV || isMH || isSU || isMed || isECD || isAd) {
        //proceed further only if any one discipline is true

        //get the Borough information from FTC then map it to CCP borough
        if (ftcFilelds != null && ftcFilelds) {


            //get the name of the borough
            SDK.WEBAPI.retrieveRecord(false, ftcFilelds["_ftc_locofconfteam_value"], "team", "name", "",
                function (result) {
                    if (result != null) {
                        boroughNameFromFTC = result["name"];

                    }
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

            switch (boroughNameFromFTC) {
                case FTCBoroughNames.BklynEast:
                    {
                        boroughNametoCCP = CCPBoroughNames.BklynEast;
                        break;
                    }
                case FTCBoroughNames.BklynWest:
                    {
                        boroughNametoCCP = CCPBoroughNames.BklynWest;
                        break;
                    }
                case FTCBoroughNames.BnxNorth:
                    {
                        boroughNametoCCP = CCPBoroughNames.BnxNorth;
                        break;
                    }
                case FTCBoroughNames.BnxSouth:
                    {
                        boroughNametoCCP = CCPBoroughNames.BnxSouth;
                        break;
                    }
                case FTCBoroughNames.MN:
                case FTCBoroughNames.MS:
                    {
                        boroughNametoCCP = CCPBoroughNames.MN;
                        break;
                    }
                case FTCBoroughNames.Queens:
                    {
                        boroughNametoCCP = CCPBoroughNames.Queens;

                        break;
                    }
                case FTCBoroughNames.Staten:
                    {
                        boroughNametoCCP = CCPBoroughNames.Staten;
                        break;
                    }
            }

            //based on the ccp borough get the Borough managers,borough Directors,Team Corodinator
            query = "$select=_ftc_ccp_boroughdirector_value,ftc_ccp_boroughid,ftc_name,ftc_ccp_boroughidcode,_ftc_ccp_boroughmanager_value,_ftc_ccp_teamcoordinator_value,ftc_name&$filter=ftc_name eq '" + encodeURIComponent(boroughNametoCCP) + "'";
            SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_ccp_boroughs", query, function (results) {
                if (results.value.length > 0)  //Active requests exist
                {
                    _ftc_ccp_boroughdirector_value = results.value[0]["_ftc_ccp_boroughdirector_value"];
                    ftc_ccp_boroughid = results.value[0]["ftc_ccp_boroughid"];
                    ftc_ccp_boroughidcode = results.value[0]["ftc_ccp_boroughidcode"];
                    _ftc_ccp_boroughmanager_value = results.value[0]["_ftc_ccp_boroughmanager_value"];

                    _ftc_ccp_teamcoordinator_value = results.value[0]["_ftc_ccp_teamcoordinator_value"];

                    ftc_name = results.value[0]["ftc_name"]
                }

            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

            //identify the Teams based on disciplines
            if (ftc_ccp_boroughid != null) {
                if (isDV || isMH) {
                    DVTeamLookup = identifyCCPTeamsBasedonDiscipline(ftc_ccp_boroughid, disciplines.DV);
                }
                if (isSU) {
                    SUTeamLookup = identifyCCPTeamsBasedonDiscipline(ftc_ccp_boroughid, disciplines.Substanc);
                }
                if (isMed) {
                    MedTeamLookup = identifyCCPTeamsBasedonDiscipline(ftc_ccp_boroughid, disciplines.Medical);
                }
                if (isECD || isAd) {
                    EduTeamLookup = identifyCCPTeamsBasedonDiscipline(ftc_ccp_boroughid, disciplines.Education);
                }


                //Create the CCP Record
                // "ftc_acscasenumber,ftc_agency,_ftc_requestormanager_value,_ftc_requestorsupervisor_value,ftc_agencycode,ftc_casename,ftc_dateofconferencerequest,_ftc_ftcstageid_value,_ftc_locofconfteam_value,ftc_pid,ftc_preferredconfdate1,_ftc_requestedby_value,ftc_stageid
                //odata.bind should be a non null value
                //always use schema name in odata bind

                var entity = {};
                entity.ftc_ccp_stageid = ftcFilelds["ftc_stageid"];
                entity.ftc_ccp_pid = ftcFilelds["ftc_pid"];
                entity.ftc_ccp_casenumber = ftcFilelds["ftc_acscasenumber"];
                entity.ftc_ccp_casename = ftcFilelds["ftc_casename"];
                entity.ftc_ccp_borough = ftc_name;
                if (ftcFilelds["_ftc_requestormanager_value"] != null)
                    entity["ftc_ccp_RequestorManager@odata.bind"] = (ftcFilelds["_ftc_requestormanager_value"] != null) ? "/systemusers(" + ftcFilelds['_ftc_requestormanager_value'] + ")" : null;
                if (ftcFilelds["_ftc_requestorsupervisor_value"] != null)
                    entity["ftc_ccp_RequestorSuperviosor@odata.bind"] = (ftcFilelds["_ftc_requestorsupervisor_value"] != null) ? "/systemusers(" + ftcFilelds['_ftc_requestorsupervisor_value'] + ")" : null;
                if (_ftc_ccp_boroughdirector_value != null)
                    entity["ftc_ccp_BoroughDirectorsTeam@odata.bind"] = (_ftc_ccp_boroughdirector_value != null) ? "/teams(" + _ftc_ccp_boroughdirector_value + ")" : null;
                if (_ftc_ccp_boroughmanager_value != null)
                    entity["ftc_ccp_BoroughManager@odata.bind"] = (_ftc_ccp_boroughmanager_value != null) ? "/systemusers(" + _ftc_ccp_boroughmanager_value + ")" : null;
                if (_ftc_ccp_teamcoordinator_value != null)
                    entity["ftc_ccp_BoroughTeamCoordinators@odata.bind"] = (_ftc_ccp_teamcoordinator_value != null) ? "/teams(" + _ftc_ccp_teamcoordinator_value + ")" : null;

                entity["ftc_ccp_FTCRequestForm@odata.bind"] = "/ftc_ftcrequestforms(" + ftcId + ")";
                // entity.ftc_ccp_zone = "gff";
                if (ftcFilelds['_ftc_ftcstageid_value'] != null)
                    entity["ftc_ccp_StageIDLookup@odata.bind"] = (ftcFilelds['_ftc_ftcstageid_value'] != null) ? "/ods_stages(" + ftcFilelds['_ftc_ftcstageid_value'] + ")" : null;
                entity.ftc_ccp_isicsc = true;
                entity.ftc_ccp_dateofappointment = new Date(ftcFilelds["ftc_preferredconfdate1"]).toISOString();
                entity.ftc_ccp_discipline = frameDisciplineFinalString(isDV, isMH, isMed, isSU, isECD, isAd);
                entity.ftc_ccp_domesticviolence = isDV;
                entity.ftc_ccp_education = isECD;
                entity.ftc_ccp_adolescentdevelopment = isAd;
                entity.ftc_ccp_medical = isMed;
                entity.ftc_ccp_mentalhealth = isMH;
                entity.ftc_ccp_substanceuse = isSU;
                entity.ftc_ccp_onsitewithfamily = true;
                entity.ftc_ccp_isapplicationcreatedfromftc = true;
                entity.ftc_ccp_submitrequestform = true;
                entity["ftc_ccp_BoroughLookup@odata.bind"] = "/ftc_ccp_boroughs(" + ftc_ccp_boroughid + ")";
                if (DVTeamLookup != null)
                    entity["ftc_ccp_DVMHConsulationTeam@odata.bind"] = (DVTeamLookup != null) ? "/teams(" + DVTeamLookup[0].id + ")" : null;
                if (EduTeamLookup != null)
                    entity["ftc_ccp_EducationConsultationTeam@odata.bind"] = (EduTeamLookup != null) ? "/teams(" + EduTeamLookup[0].id + ")" : null;
                if (MedTeamLookup != null)
                    entity["ftc_ccp_MedicalConsultationTeam@odata.bind"] = (MedTeamLookup != null) ? "/teams(" + MedTeamLookup[0].id + ")" : null;
                if (SUTeamLookup != null)
                    entity["ftc_ccp_SubstanceUseConsulationTeam@odata.bind"] = (SUTeamLookup != null) ? "/teams(" + SUTeamLookup[0].id + ")" : null;


                SDK.WEBAPI.createRecord(false, entity, "ftc_ccprequestforms", function () { }, function (errMsg) { alert(errMsg); });




            }
            else {
                return;
            }


        }

    }

}


function frameDisciplineFinalString(DVCheckbox, MHCheckbox, MedCheckbox, SUCheckbox, EduCheckbox, adolescentCheckbox) {

    let finalString;
    if (DVCheckbox) {
        finalString = disciplinesCheckBoxes.DV;
    }
    if (MHCheckbox) {

        finalString = (finalString != null && finalString != "") ? finalString + "," + disciplinesCheckBoxes.MH : disciplinesCheckBoxes.MH;
    }
    if (MedCheckbox) {

        finalString = (finalString != null && finalString != "") ? finalString + "," + disciplinesCheckBoxes.MED : disciplinesCheckBoxes.MED;
    }
    if (SUCheckbox) {

        finalString = (finalString != null && finalString != "") ? finalString + "," + disciplinesCheckBoxes.SU : disciplinesCheckBoxes.SU;
    }
    if (EduCheckbox) {

        finalString = (finalString != null && finalString != "") ? finalString + "," + disciplinesCheckBoxes.EDU : disciplinesCheckBoxes.EDU;
    }
    if (adolescentCheckbox) {

        finalString = (finalString != null && finalString != "") ? finalString + "," + disciplinesCheckBoxes.AD : disciplinesCheckBoxes.AD;
    }

    return (finalString != null && finalString != "") ? finalString : null;
}


function identifyCCPTeamsBasedonDiscipline(boroughId, discipline) {

    let lookupObject
    let query = "$select=_ftc_ccpboroughlookup_value,ftc_ccpdiscipline,name,teamid&$filter=_ftc_ccpboroughlookup_value eq " + boroughId + " and  ftc_ccpdiscipline eq " + discipline;
    SDK.WEBAPI.retrieveMultipleRecords(false, "teams", query, function (results) {
        if (results.value.length > 0)  //Active requests exist
        {
            lookupObject = new Array();
            lookupObject[0] = new Object();
            lookupObject[0].id = results.value[0]["teamid"];
            lookupObject[0].name = results.value[0]["name"];
            lookupObject[0].entityType = "team";


        }

    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    return lookupObject;

}

function setActiveStage(StageID, StageName, Counter) {
    if (Counter > 0) {
        Xrm.Page.data.save().then(function () {
            Xrm.Page.data.process.setActiveStage(StageID, function (status) {
                if (status !== "success")
                    setActiveStage(StageID, StageName, --Counter);
            });
        }, function () { });
    }
}



function RFForm_OnStageSelected(execContext) {
    var SelectedStage = execContext.getEventArgs().getStage().getName();
    SetFormState(FTCUserRole, statuscodeName, SelectedStage);
}

//This function is called from following functions Onload-at the end, OnSave-at the end, OnProcessStatusChange, OnStageChange, OnStageSelected
function SetFormState(UserSecurityRole, RecordStatus, ActiveStage) {
    //1. Set IsReadonlyForm based on User Security Role and Status
    if (RecordStatus == "withdrawn" || RecordStatus == "expired" || RecordStatus == "auto closed" || RecordStatus == "completed"
        || (UserSecurityRole == "requestor" && (RecordStatus == "pending with supervisor" || RecordStatus == "pending with manager" || RecordStatus == "submitted" || RecordStatus == "assigned to facilitator"))
        || ((UserSecurityRole == "scheduler" || UserSecurityRole === "ftc admin") && RecordStatus == "assigned to facilitator")
        || (UserSecurityRole == "supervisor")
        || (UserSecurityRole == "manager")
        || (UserSecurityRole == "ftc admin")
    ) {

        IsReadonlyForm = true;
        DisableAllFieldsOnForm();
    }

    //2. BPF Fields
    //ShowHideBPFFields();
    EnableDisableStatusUpdateFieldsInBPF(UserSecurityRole, RecordStatus);

    //||(UserSecurityRole == "supervisor" && (RecordStatus=="returned for modification" || RecordStatus=="pending with manager" || RecordStatus=="submitted" || RecordStatus=="assigned to facilitator"))
    //||(UserSecurityRole == "manager" && (RecordStatus=="returned for modification" || RecordStatus=="pending with supervisor" || RecordStatus=="submitted" || RecordStatus=="assigned to facilitator"))

    //3. Sections And Tabs
    SetFormStateSectionsTabs(UserSecurityRole, RecordStatus, ActiveStage);

    //4. Fields

    DisableFields(["ftc_reqtoreschconf", "ftc_sch_reschedule", "ftc_wastheconferencewithdrawn"]);
    //Requestor Reschedule field
    if (UserSecurityRole == "requestor" && (RecordStatus == "submitted" || RecordStatus == "assigned to facilitator"))// && Xrm.Page.getAttribute("ftc_reqtoreschconf").getValue()===false)
    {
        EnableFields(["ftc_reqtoreschconf"]);
    }

    //disable contact info fields for scheduler and facilitator
    if (UserSecurityRole == "scheduler" || UserSecurityRole == "facilitator" || UserSecurityRole == "ftc admin") {

        DisableFields(["ftc_followupcontactname", "ftc_followupcontactphone", "ftc_caseaddressline1", "ftc_caseaddressline2", "ftc_caseaddresscity", "ftc_caseaddressstate", "ftc_caseaddresszip", "ftc_locofconfteam"]);
    }

    //Show Scheduler/Facilitator Reschedule fields
    if ((UserSecurityRole == "scheduler" || UserSecurityRole == "facilitator" || UserSecurityRole == "ftc admin") && RecordStatus == "assigned to facilitator") {
        DisableFields(["ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_starttimeampm", "ftc_sch_endtimeofschconf", "ftc_sch_endtimeampm", "ftc_sch_assignedfacilitator", "ftc_sch_reasonforreschedule", "ftc_sch_startminutes", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
        //On Form these are not shown
        ShowFields(["ftc_sch_reschedule", "ftc_sch_reasonforreschedule", "ftc_sch_reasonforreschother"]);
    }

    //Scheduler/Facilitator Reschedule field
    if ((UserSecurityRole == "scheduler" || UserSecurityRole == "facilitator" || UserSecurityRole == "ftc admin") && RecordStatus == "assigned to facilitator")// && Xrm.Page.getAttribute("ftc_sch_reschedule").getValue()===false)
    {
        var reschFlag = Xrm.Page.getAttribute("ftc_scheduletimesflag").getValue();
        if (reschFlag !== 2) {
            EnableFields(["ftc_sch_reschedule"]);
        }
    }

    //Withdraw field
    if ((UserSecurityRole == "requestor" || UserSecurityRole == "scheduler" || UserSecurityRole == "ftc admin") && (RecordStatus == "submitted" || RecordStatus == "assigned to facilitator")) {
        EnableFields(["ftc_wastheconferencewithdrawn"]);
    }

    RemoveEditableGridWhiteSpace();
}

function SetFormStateSectionsTabs(UserSecurityRole, RecordStatus, ActiveStage) {
    var AllTabs = ["tab_General", "conference_details", "Tab_Family_Composition", "tab_child_welfare_history", "tab_lts_court_cases", "School_Information", "Special_Circumstances", "Conference_Participants", "tab_ftc_history", "FTC_Status_History", "tab_RequestForRescheduleWithDraw", "tab_Scheduler_Assignment_Form", "Tab_Action_Plan", "Tab_Action_Plan_UpdateConfDetails", "tab_Notes"];
    var AllRequestTabs = ["tab_General", "conference_details", "Tab_Family_Composition", "tab_child_welfare_history", "tab_lts_court_cases", "School_Information", "Special_Circumstances", "Conference_Participants", "tab_ftc_history", "FTC_Status_History", "tab_Notes"];

    HideTabs(AllTabs);
    //ExpandTabs(AllTabs);

    if (ActiveStage == "General")
        ShowTabs(["tab_General"]);
    else if (ActiveStage == "Conference Details") {
        ShowTabs(["conference_details"]);
        SetConfTypeSettings();
    }
    else if (ActiveStage == "Family Composition")
        ShowTabs(["Tab_Family_Composition", "tab_ftc_history"]);
    else if (ActiveStage == "Child Welfare History")
        ShowTabs(["tab_child_welfare_history"]);
    else if (ActiveStage == "LTS")
        ShowTabs(["tab_lts_court_cases"]);
    else if (ActiveStage == "School Information")
        ShowTabs(["School_Information"]);
    else if (ActiveStage == "Special Circumstances")
        ShowTabs(["Special_Circumstances"]);
    else if (ActiveStage == "Conference Participants")
        ShowTabs(["Conference_Participants"]);
    else if (ActiveStage == "Review & Submit" || ActiveStage == "Supervisor" || ActiveStage == "Manager") {
        RequestorFormMode(UserSecurityRole, RecordStatus);
    }
    else if (ActiveStage == "Scheduler" && (UserSecurityRole == "requestor" || UserSecurityRole == "supervisor" || UserSecurityRole == "manager")) {
        RequestorFormMode(UserSecurityRole, RecordStatus)
    }
    else if (ActiveStage == "Scheduler" && (UserSecurityRole == "scheduler" || UserSecurityRole == "ftc admin")) {
        SchedulerFormMode();
    }
    else if (ActiveStage == "Scheduler" && UserSecurityRole == "facilitator") {
        SchedulerFormMode();
    }
    else if (ActiveStage == "Facilitator" && (UserSecurityRole == "requestor" || UserSecurityRole == "supervisor" || UserSecurityRole == "manager")) {
        RequestorFormMode(UserSecurityRole, RecordStatus);
    }
    else if (ActiveStage == "Facilitator" && (UserSecurityRole == "scheduler" || UserSecurityRole == "ftc admin")) {
        SchedulerFormMode();
    }
    else if (ActiveStage == "Facilitator" && UserSecurityRole == "facilitator") {
        FacilitatorFormMode();
    }


    if (RecordStatus !== "new") {
        ShowSections("tab_General", ["sec_contact_Information", "sec_conference_address"]);
    }

    AllGrids();

    //Collapse Tabs After hiding/showing tabs followed by hiding/showing sections.
    if (ActiveStage == "Review & Submit" || ActiveStage == "Supervisor" || ActiveStage == "Manager" || ((ActiveStage == "Scheduler" || ActiveStage == "Facilitator") && (UserSecurityRole == "requestor" || UserSecurityRole == "supervisor" || UserSecurityRole == "manager" || UserSecurityRole == "ftc admin"))) {
        AllRequestTabs.splice(AllRequestTabs.indexOf("tab_General"), 1);
        CollapseTabs(AllRequestTabs);
    }
}


function ShowHideBPFFields() {

    HideControls(["header_process_ftc_isfamilyprevinvolvedcws", "header_process_ftc_activecourtcase", "header_process_ftc_ischildrenenrolledinschool", "header_process_ftc_agencycode"]);

    //Xrm.Page.getControl("header_process_ftc_sta_submitrequestform").setVisible(false);
    //Xrm.Page.getControl("header_process_ftc_sta_assigntofacilitator").setVisible(false);
    //Xrm.Page.getControl("header_process_ftc_closeftcrequest").setVisible(false);
}

function RequestorFormMode(UserSecurityRole, RecordStatus) {
    var AllRequestTabs = ["tab_General", "conference_details", "Tab_Family_Composition", "tab_child_welfare_history", "tab_lts_court_cases", "School_Information", "Special_Circumstances", "Conference_Participants", "tab_ftc_history", "FTC_Status_History", "tab_Notes"];
    ShowTabs(AllRequestTabs);
    SetConfTypeSettings();

    if ((RecordStatus === "submitted" || RecordStatus === "assigned to facilitator") && (UserSecurityRole == "requestor")) //Any status after submitted - close statuses
        ShowTabs(["tab_RequestForRescheduleWithDraw"]);

}


function SchedulerFormMode() {

    //1)Check the assign application to scheduler question if it is Yes then check whether the current logged in user and Assigned scheduler user are same or not
    //2)if both user are same then unlock the Scheduler  fields else lock the scheduler fieds

    let isSchedulerAssigned = Xrm.Page.getAttribute("ftc_assignapplicationtoscheduler").getValue();
    ShowTabs(["tab_General", "tab_Scheduler_Assignment_Form", "tab_Notes"]);


    if (isSchedulerAssigned && assignScheduler()) {
        DisableControls(["ftc_assignapplicationtoscheduler"]);
        EnableControls(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
        setRequired(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_assignapplicationtoscheduler", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
    }
    else {
        if (FTCUserRole == "ftc admin") {
            EnableControls(["ftc_assignapplicationtoscheduler", "header_process_ftc_assignapplicationtoscheduler"]);
        }
        setRequired(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_assignapplicationtoscheduler", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
        DisableControls(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
        if (Xrm.Page.getAttribute("ftc_assignedscheduler").getValue() != null && (!assignScheduler())) {
            Xrm.Page.ui.setFormNotification("A Scheduler is already assigned to this application. If you want to work on this application click on 'Assign Scheduler' button on the top ", "Warning", "assignSchedulerNotification");
        }

    }


}

function assignScheduler() {


    let assignedSchedulerGuid = (Xrm.Page.getAttribute("ftc_assignedscheduler").getValue() != null) ? replaceBracketsInGuid(Xrm.Page.getAttribute("ftc_assignedscheduler").getValue()[0].id) : false;

    if (assignedSchedulerGuid && FTCUserID_NoBraces == assignedSchedulerGuid) {

        //check whether the current logged in user and Assigned scheduler user are same or not
        return true;
    }
    else {
        return false;

    }


}


function assignApplicationtoSchedulerOnChange() {

    let isSchedulerAssigned = Xrm.Page.getAttribute("ftc_assignapplicationtoscheduler").getValue();
    if (isSchedulerAssigned) {

        //assign current user  to assignSchedulr field
        var lookupObject = GetCurrentUser();
        Xrm.Page.getAttribute("ftc_assignedscheduler").setValue(lookupObject);
        Xrm.Page.data.save().then(
            function () {
                EnableControls(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
                DisableControls(["ftc_assignapplicationtoscheduler"]);
                setRequired(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_assignapplicationtoscheduler", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
            },
            function () { });



    }


}

function assignSchedulerButtonEnablerule() {

    FTCUserRole = GetFTCUserRole();
    FTCUserID_NoBraces = replaceBracketsInGuid(FTCUserID);



    //Add event handlers
    //1)Assign scheduler flag is yes 2) user role should be scheduler and stage should be scheduler 3)Logged in userrd and  assigned schedulerID should be different
    if (Xrm.Page.getAttribute("ftc_assignapplicationtoscheduler").getValue() && (FTCUserRole === "scheduler" || FTCUserRole === "ftc admin") && Xrm.Page.data.process.getActiveStage().getName() == "Scheduler" && Xrm.Page.getAttribute("ftc_assignedscheduler").getValue() != null && replaceBracketsInGuid(Xrm.Page.getAttribute("ftc_assignedscheduler").getValue()[0].id) != FTCUserID_NoBraces) {

        return true;
    }
    else {
        return false;
    }


}



function assignSchedulerButtonCommand() {

    assignApplicationtoSchedulerOnChange();
    Xrm.Page.ui.clearFormNotification("assignSchedulerNotification");


}
function assignDifferentFacilitatorButtonEnableRule() {

    FTCUserRole = GetFTCUserRole();
    FTCUserID_NoBraces = replaceBracketsInGuid(FTCUserID);
    //stage should be assigned to facilitator, role should be scheduler , any scheduler can change or only previous scheduler 
    if ((FTCUserRole === "scheduler" || FTCUserRole === "ftc admin") && Xrm.Page.data.process.getActiveStage().getName() == "Facilitator") {

        return true;
    }
    else {
        return false;
    }

}

function assignDifferentFacilitatorButtonCommand() {
    let ConfirmOption;
    Xrm.Utility.confirmDialog("Are you sure you would like to Reassign this application to new facilitator?",
        function () {
            EnableControls(["ftc_sch_facilitatorborough", "ftc_sch_assignedfacilitator"]);
            setRequired(["ftc_sch_facilitatorborough", "ftc_sch_assignedfacilitator"]);
            Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").setValue(null);
        },
        function () { ConfirmOption = "Cancel"; });



}


function FacilitatorFormMode() {
    ShowTabs(["tab_General", "tab_Scheduler_Assignment_Form", "tab_Notes", "tab_child_welfare_history", "School_Information"]);
    SetUpdatedConfTypeSettings();
}

//Based on User Role and Status
function EnableDisableStatusUpdateFieldsInBPF(UserSecurityRole, RecordStatus) {
    DisableControls(["header_process_ftc_sta_submitrequestform", "header_process_ftc_supervisoractionoptions", "header_process_ftc_supervisorcomments", "header_process_ftc_manageractionoptions", "header_process_ftc_managercomments", "header_process_ftc_sta_assigntofacilitator", "header_process_ftc_closeftcrequest", "header_process_ftc_conferencetype"]);

    if (UserSecurityRole == "requestor" && (RecordStatus == "in progress" || RecordStatus == "returned for change by supervisor" || RecordStatus == "returned for change by manager"))
        EnableControls(["header_process_ftc_sta_submitrequestform"]);
    else if ((UserSecurityRole == "supervisor" || UserSecurityRole == "ftc admin") && (RecordStatus == "pending with supervisor")) //FTC Admin can also approve the request
        EnableControls(["header_process_ftc_supervisoractionoptions", "header_process_ftc_supervisorcomments"]);
    else if ((UserSecurityRole == "manager" || UserSecurityRole == "ftc admin") && (RecordStatus == "pending with manager"))//FTC Admin can also approve the request
        EnableControls(["header_process_ftc_manageractionoptions", "header_process_ftc_managercomments"]);
    else if ((UserSecurityRole == "scheduler" || UserSecurityRole === "ftc admin") && RecordStatus == "submitted")
        EnableControls(["header_process_ftc_sta_assigntofacilitator"]);
    else if (UserSecurityRole == "facilitator" && RecordStatus == "assigned to facilitator")
        EnableControls(["header_process_ftc_closeftcrequest"]);
}

function AllGrids() {
    ActiveCourtCase_OnChange();
    FTCHistory_OnChange(); //This has only Readonly Grid.
    SetGridState(true, "Tab_Family_Composition", "sec_cws_familycomposition_Editable", "sec_cws_familycomposition_Readonly", "Grid_Family_Composition_Editable");
    CWS_NY_OnChange();
    //CWS_OutsideNY_OnChange();
    School_Information_OnChange();
    Acute_Hospital_OnChange();
    Child_Juvenile_OnChange();
    Child_ExpectingBaby_OnChange();
    Child_ParentingChild_OnChange();
    SetGridState(true, "Conference_Participants", "Sec_Conference_Participants_Editable", "Sec_Conference_Participants_Readonly", "Conference_Participants");
    ConferenceRecomm_OnChange();
}


function SetGridState(DisplayFlag, TabName, EditableSecName, ReadonlySecName, EditableGridName) {
    if (DisplayFlag === true) {
        if (!IsReadonlyForm) {
            Xrm.Page.ui.tabs.get(TabName).sections.get(EditableSecName).setVisible(true);
            Xrm.Page.ui.tabs.get(TabName).sections.get(ReadonlySecName).setVisible(false);
            if (EditableGridName !== null) {
                setTimeout(function () { Xrm.Page.getControl(EditableGridName).refresh(); }, 300);
            }
        }
        else {
            Xrm.Page.ui.tabs.get(TabName).sections.get(EditableSecName).setVisible(false);
            Xrm.Page.ui.tabs.get(TabName).sections.get(ReadonlySecName).setVisible(true);
        }
    }
    else {
        Xrm.Page.ui.tabs.get(TabName).sections.get(EditableSecName).setVisible(false);
        Xrm.Page.ui.tabs.get(TabName).sections.get(ReadonlySecName).setVisible(false);
    }

}


function SetConfTypeSettings() {

    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())

    if (ConfType != null) {
        ConfType = ConfType.name.toLowerCase()
    }


    var NonEmergencyConfFields =
        [
            "ftc_ischildreninfostercare",
            "ftc_nameoffosterparent",
            "ftc_isadvocatecase",
            "ftc_intensityofneed",
            "ftc_isdvconference"
        ]

    //HideControls(["WebResource_ConfDetails_EmergencyConditions", "WebResource_ConfDetails_HasSafetyPlan"]);
    HideSections("conference_details", ["sec_emergency_removal"]);
    HideFields(NonEmergencyConfFields);

    var ShowConfTypeFields = null;
    var ShowConfTypeWebResources = null;
    var setRequiredConfTypeFields = null;

    switch (ConfType) {
        case "child safety conference":
            ShowConfTypeFields = ["ftc_isdvconference"];
            setRequiredConfTypeFields = ["ftc_isdvconference"];

            ShowSections("conference_details", ["sec_emergency_removal"]);
            //ShowConfTypeWebResources = ["WebResource_ConfDetails_EmergencyConditions", "WebResource_ConfDetails_HasSafetyPlan"];
            break;
        case "elevated risk":
            ShowConfTypeFields = ["ftc_isadvocatecase"];
            setRequiredConfTypeFields = ["ftc_isadvocatecase"];
            break;
        case "final discharge":
            ShowConfTypeFields = ["ftc_nameoffosterparent"];
            break;
        case "follow up child safety conference":
            ShowConfTypeFields = ["ftc_ischildreninfostercare", "ftc_nameoffosterparent", "ftc_isdvconference"];
            setRequiredConfTypeFields = ["ftc_ischildreninfostercare", "ftc_isdvconference"];
            break;
        case "goal change":
            break;
        case "permanency planning 12 month":
            ShowConfTypeFields = ["ftc_nameoffosterparent"];
            break;
        case "placement preservation":
            ShowSections("conference_details", ["sec_emergency_removal"]);
            ShowConfTypeFields = ["ftc_nameoffosterparent"];
            //ShowConfTypeWebResources = ["WebResource_ConfDetails_EmergencyConditions", "WebResource_ConfDetails_HasSafetyPlan"]
            setRequiredConfTypeFields = ["ftc_nameoffosterparent", "ftc_emergencyremoval", "ftc_isparentcaretakerarrested", "ftc_caretakername", "ftc_iskinshipplacement", "ftc_locationofplacement", "ftc_hasscrclearanceconducted"];
            break;
        case "preventive planning 30-45 days":
            ShowConfTypeFields = ["ftc_isadvocatecase"];
            setRequiredConfTypeFields = ["ftc_isadvocatecase"];
            break;
        case "service termination":
            ShowConfTypeFields = ["ftc_isadvocatecase", "ftc_intensityofneed"];
            setRequiredConfTypeFields = ["ftc_isadvocatecase", "ftc_intensityofneed"];
            break;
        case "trial discharge":
            ShowConfTypeFields = ["ftc_nameoffosterparent"];
            break;

    }

    ShowFields(ShowConfTypeFields);
    ShowControls(ShowConfTypeWebResources);
    setRequired(setRequiredConfTypeFields);

}

function SetUpdatedConfTypeSettings() {

    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_fac_whatwasupdatedpurposeofconf").getValue())

    if (ConfType != null) {
        ConfType = ConfType.name.toLowerCase()
        ShowTabs(["Tab_Action_Plan_UpdateConfDetails"]);
        setRequired(["ftc_fac_programtype"]);
    }
    else {
        HideTabs(["Tab_Action_Plan_UpdateConfDetails"]);
        setNotRequired(["ftc_fac_programtype"]);
    }


    var NonEmergencyConfFields =
        [
            "ftc_fac_schildreninfostercare",
            "ftc_fac_nameoffosterparent",
            "ftc_fac_isadvocatecase",
            "ftc_fac_intensityofneed",
        ]

    HideControls(["WebResource_Updated_ConfDetails_EmergencyConditions", "WebResource_Updated_ConfDetails_HasSafetyPlan"]);
    HideSections("Tab_Action_Plan_UpdateConfDetails", ["sec_updated_emergency_removal"]);
    HideFields(NonEmergencyConfFields);

    var NotrequiredFields = ["ftc_fac_isadvocatecase", "ftc_fac_schildreninfostercare", "ftc_fac_intensityofneed", "ftc_fac_nameoffosterparent", "ftc_fac_emergencyremoval", "ftc_fac_isparentcaretakerarrested", "ftc_fac_caretakername", "ftc_fac_iskinshipplacement", "ftc_fac_locationofplacement", "ftc_fac_hasscrclearanceconducted"]
    setNotRequired(NotrequiredFields);


    var ShowConfTypeFields = null;
    var ShowConfTypeWebResources = null;
    var setRequiredConfTypeFields = null;

    switch (ConfType) {
        case "child safety conference":
            ShowSections("Tab_Action_Plan_UpdateConfDetails", ["sec_updated_emergency_removal"]);
            ShowConfTypeWebResources = ["WebResource_Updated_ConfDetails_EmergencyConditions", "WebResource_Updated_ConfDetails_HasSafetyPlan"];
            break;
        case "elevated risk":
            ShowConfTypeFields = ["ftc_fac_isadvocatecase"];
            setRequiredConfTypeFields = ["ftc_fac_isadvocatecase"];
            break;
        case "final discharge":
            ShowConfTypeFields = ["ftc_fac_nameoffosterparent"];
            break;
        case "follow up child safety conference":
            ShowConfTypeFields = ["ftc_fac_schildreninfostercare", "ftc_fac_nameoffosterparent"];
            setRequiredConfTypeFields = ["ftc_fac_schildreninfostercare"];
            break;
        case "goal change":
            break;
        case "permanency planning 12 month":
            ShowConfTypeFields = ["ftc_fac_nameoffosterparent"];
            break;
        case "placement preservation":
            ShowSections("Tab_Action_Plan_UpdateConfDetails", ["sec_updated_emergency_removal"]);
            ShowConfTypeFields = ["ftc_fac_nameoffosterparent"];
            ShowConfTypeWebResources = ["WebResource_Updated_ConfDetails_EmergencyConditions", "WebResource_Updated_ConfDetails_HasSafetyPlan"];
            setRequiredConfTypeFields = ["ftc_fac_nameoffosterparent", "ftc_fac_emergencyremoval", "ftc_fac_isparentcaretakerarrested", "ftc_fac_caretakername", "ftc_fac_iskinshipplacement", "ftc_fac_locationofplacement", "ftc_fac_hasscrclearanceconducted"];
            break;
        case "preventive planning 30-45 days":
            ShowConfTypeFields = ["ftc_fac_isadvocatecase"];
            setRequiredConfTypeFields = ["ftc_fac_isadvocatecase"];
            break;
        case "service termination":
            ShowConfTypeFields = ["ftc_fac_isadvocatecase", "ftc_fac_intensityofneed"];
            setRequiredConfTypeFields = ["ftc_fac_isadvocatecase", "ftc_fac_intensityofneed"];
            break;
        case "trial discharge":
            ShowConfTypeFields = ["ftc_fac_nameoffosterparent"];
            break;

    }

    ShowFields(ShowConfTypeFields);
    ShowControls(ShowConfTypeWebResources);
    setRequired(setRequiredConfTypeFields);

}

function RFForm_OnSave(context) {

    //Status = New
    Xrm.Page.ui.clearFormNotification("NoPermOnStageID");
    Xrm.Page.ui.clearFormNotification("NoTeamAssigned");
    Xrm.Page.ui.clearFormNotification("MorethanOneTeamAssigned");
    Xrm.Page.ui.clearFormNotification("StageIDOwnerConfigIssue");
    Xrm.Page.ui.clearFormNotification("StageIDNotAssigned");
    Xrm.Page.ui.clearFormNotification("StageIDPIDCombinationIncorrect");
    Xrm.Page.ui.clearFormNotification("ActiveRequestsForStageIDConfType");
    Xrm.Page.ui.clearFormNotification("ConfTypeIsGoalChange");

    //Status = In Progress
    Xrm.Page.ui.clearFormNotification("SCRClearanceNotConducted");

    //Status = Submit
    Xrm.Page.ui.clearFormNotification("PrimaryChildNotChoosen");
    Xrm.Page.ui.clearFormNotification("RequestExpired");

    //Xrm.Page.ui.clearFormNotification("ChildsWithDifferentBorough");
    Xrm.Page.ui.clearFormNotification("NoLocationForSelectedChild");

    //Set Global Variables: OnSave Status Reason may be changed by user, so update it.
    statuscodeName = Xrm.Page.getAttribute("statuscode").getText().toLowerCase();



    if (Xrm.Page.data.process.getActiveStage().getName() == "Family Composition") {
        if (!IsFTCFamilyMemberSelected()) {
            Xrm.Page.ui.setFormNotification("Choose Primary child in the Family Composition grid", "ERROR", "PrimaryChildNotChoosen");
            context.getEventArgs().preventDefault();
            return false;
        }
    }

    //FTC History Data Retrieval
    if (statuscodeName == "in progress" && !Xrm.Page.getAttribute("ftc_isftchistoryretrieved").getValue()) {
        var ChildRecomm_StageID = Xrm.Page.getAttribute('ftc_stageid').getValue();
        if (ChildRecomm_StageID !== null) {
            var ChildRecommGUIDS = GetChildRecommForStageID(ChildRecomm_StageID);

            if (ChildRecommGUIDS != null && ChildRecommGUIDS.length !== 0) {
                UpdateChidRecommRecordsWithFTCID(ChildRecommGUIDS);
                Xrm.Page.getAttribute("ftc_isftchistoryretrieved").setValue(true);
            }
        }
    }

    //LTS Data Retrieval
    if (statuscodeName == "in progress" && !Xrm.Page.getAttribute("ftc_isltsdataretrieved").getValue()) {
        var CINs = GetCINsForSelectedFTCFamilyMembers();

        if (CINs !== null && CINs.length !== 0) {
            var LTSSourceGUIDS = GetLTSSourceGUIDSForCINS(CINs);
            if (LTSSourceGUIDS != null && LTSSourceGUIDS.length !== 0) {
                UpdateLTSSourceRecordsWithFTCID(LTSSourceGUIDS);
                Xrm.Page.getAttribute("ftc_isltsdataretrieved").setValue(true);

            }

        }

    }


    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())

    if (ConfType != null) {
        ConfType = ConfType.name.toLowerCase();
    }


    if (statuscodeName === "new") {
        //Set 'Status Reason' to 'In progress'
        //Xrm.Page.getAttribute("statuscode").setSubmitMode("always");


        //Temporarily Disabled Validation for Unit Testing - Start================

        //Get Stage Owner
        var StageID = Xrm.Page.getAttribute('ftc_stageid').getValue();

        var owner = GetStageOwner(StageID);

        var owner_GUID, owner_Name, entitytype;

        if (owner != null) {

            if (!ValidateStageIDAndPID()) {
                Xrm.Page.ui.setFormNotification("Please enter valid StageID and PID", "ERROR", "StageIDPIDCombinationIncorrect")
                context.getEventArgs().preventDefault();
                return false;
            }

            if (IsActiveStageIDAndConfTypeRequests()) {
                Xrm.Page.ui.setFormNotification("There is already an Active FTC request for the StageID and Conference Type selected", "ERROR", "ActiveRequestsForStageIDConfType")
                context.getEventArgs().preventDefault();
                return false;
            }

            if (ConfType === "goal change") {
                Xrm.Page.ui.setFormNotification("PLEASE FOLLOW UP WITH THE OFFICE OF YOUTH SERVICES FOR ACS FACILITATED ALL GOAL CHANGE CONFERENCES, OYSSFTC@acs.nyc.gov", "INFO", "ConfTypeIsGoalChange");
                context.getEventArgs().preventDefault();
                return false;
            }
            //Service Termination COnference Type Logic

            owner_Name = owner[0];
            owner_GUID = owner[1];
            entitytype = owner[2];
            Xrm.Page.getAttribute("ownerid").setValue([{ id: "{" + owner_GUID + "}", name: owner_Name, entityType: entitytype }]);



        }
        else {
            context.getEventArgs().preventDefault();
            return false;
        }

        //Temporarily Disabled Validation for Unit Testing - End================

        UpdateStatus(1, "in progress");
        return true;
    }
    else if (statuscodeName === "in progress" && (ConfType === "child safety conference" || ConfType === "placement preservation") && Xrm.Page.getAttribute("ftc_hasscrclearanceconducted").getValue() === false) //FTC Request = Auto Close
    {
        Xrm.Page.ui.setFormNotification("Cannot request a Conference until SCR Clearance Conducted", "INFO", "SCRClearanceNotConducted");
        UpdateStatus(100000004, "auto closed");
        return true;
    }
    else if (Xrm.Page.getAttribute("ftc_sta_submitrequestform").getValue() == "100000000" && statuscodeName === "in progress" && FTCUserRole === "requestor") //FTC Request = Submitted
    {

        if (!IsFTCFamilyMemberSelected()) {
            Xrm.Page.ui.setFormNotification("Choose Primary child in the Family Composition grid", "ERROR", "PrimaryChildNotChoosen");
            context.getEventArgs().preventDefault();
            return false;
        }

        if (GetCurrentDate() >= Xrm.Page.getAttribute("ftc_duedateforsubmission").getValue()) {
            Xrm.Page.ui.setFormNotification("Request has been expired and can not be submitted. Please create new request.", "ERROR", "RequestExpired");
            context.getEventArgs().preventDefault();
            return false;
        }

        Xrm.Page.getAttribute("ftc_daterequestformsubmission").setValue(GetCurrentDate());
        UpdateDueDateForScheduling();
        return true;
    }
    else if (Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").getValue() === true && (statuscodeName === "submitted" || statuscodeName === "assigned to facilitator") && (FTCUserRole === "requestor" || FTCUserRole === "scheduler" || FTCUserRole === "ftc admin")) 	//FTC Request = Withdrawn
    {

        Xrm.Page.getAttribute("ftc_withdrawaldate").setValue(GetCurrentDate());
        Xrm.Page.getAttribute("ftc_withdrawnby").setValue(GetCurrentUser());
        Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").setValue(true);

        UpdateStatus(100000001, "withdrawn");

        //Xrm.Utility.confirmDialog("Are you sure you would like to withdraw the Conference?",
        //    function () {
        //        Xrm.Page.getAttribute("ftc_withdrawaldate").setValue(GetCurrentDate());
        //        Xrm.Page.getAttribute("ftc_withdrawnby").setValue(GetCurrentUser());
        //        Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").setValue(true);

        //        UpdateStatus(100000001, "withdrawn");
        //        return true;
        //    },
        //    function () {
        //        Xrm.Page.getAttribute("ftc_reasonforwithdrawal").setRequiredLevel("none");
        //      //  Xrm.Page.getAttribute("ftc_reasonforwithdrawal").setValue(null);
        //       // Xrm.Page.getControl("ftc_reasonforwithdrawal").setDisabled(true);
        //        Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").setValue(false);
        //        context.getEventArgs().preventDefault();
        //        //ftc_reasonforwithdrawal



        //    });



        //var ConfirmOption;
        //Xrm.Utility.confirmDialog("Are you sure you would like to withdraw the Conference?", function () { ConfirmOption = "Yes"; }, function () { ConfirmOption = "Cancel"; })

        //if (ConfirmOption == "Cancel") {
        //    context.getEventArgs().preventDefault();
        //    return false;
        //}


        //Xrm.Page.getAttribute("ftc_withdrawaldate").setValue(GetCurrentDate());
        //Xrm.Page.getAttribute("ftc_withdrawnby").setValue(GetCurrentUser());
        //Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").setValue(true);

        //UpdateStatus(100000001, "withdrawn");
        //return true;
    }
    else if (Xrm.Page.getAttribute("ftc_sta_assigntofacilitator").getValue() == "100000000" && statuscodeName === "submitted" && (FTCUserRole === "scheduler" || FTCUserRole === "ftc admin")) 	//FTC Request = Assign to Facilitator 
    {
        var AssignedFacilitatorSchedule = null;

        if (Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue() !== null) {
            AssignedFacilitatorSchedule = Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue()[0].id;
        }

        if (AssignedFacilitatorSchedule !== null) {
            AssignedFacilitatorSchedule = replaceBracketsInGuid(AssignedFacilitatorSchedule);

            var note = Xrm.Page.getAttribute("ftc_sch_starttimeofschconf").getValue() + ":" + Xrm.Page.getAttribute("ftc_sch_startminutes").getText() + ((Xrm.Page.getAttribute("ftc_sch_starttimeampm").getValue()) ? "AM" : "PM") + "-" + Xrm.Page.getAttribute("ftc_sch_endtimeofschconf").getValue() + ":" + Xrm.Page.getAttribute("ftc_sch_endminutes").getText() + ((Xrm.Page.getAttribute("ftc_sch_endtimeampm").getValue()) ? "AM" : "PM");


            var ftc_sch_dateconfexpectedtoheld = Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue();
            var schedule_note = ("00" + (ftc_sch_dateconfexpectedtoheld.getMonth() + 1)).slice(-2) + "-" + ("00" + ftc_sch_dateconfexpectedtoheld.getDate()).slice(-2) + "-" + ftc_sch_dateconfexpectedtoheld.getFullYear() + " " + note;


            Xrm.Page.getAttribute("ftc_sch_schedulenote").setValue(schedule_note);
            UpdateAssginedFacilitatorEmail(AssignedFacilitatorSchedule);
            AddNotesToFacilitatorSchedule(AssignedFacilitatorSchedule, note);

            Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").setValue(GetCurrentDate());

            Xrm.Page.getAttribute("ftc_sch_scheduledby").setValue(GetCurrentUser());

            UpdateDueDateForCompletion();
            UpdateStatus(100000006, "assigned to facilitator");
            moveNext(Xrm.Page.data.process.getActiveStage().getName());
            return true;
        }

    }
    else if ((Xrm.Page.getAttribute("ftc_sch_reschedule").getIsDirty() === true || Xrm.Page.getAttribute("ftc_sch_reschedule").getSubmitMode() === "always") && Xrm.Page.getAttribute("ftc_sch_reschedule").getValue() === true && statuscodeName === "assigned to facilitator" && (FTCUserRole === "scheduler" || FTCUserRole === "facilitator" || FTCUserRole === "ftc admin"))	//Scheduler/Facilitator Reschedule
    {

        var ConfirmOption;
        //Xrm.Utility.confirmDialog("Are you sure you would like to Reschedule the conference?", function () { ConfirmOption = "Yes"; }, function () { ConfirmOption = "Cancel"; })
        //if (ConfirmOption == "Cancel") {
        //    context.getEventArgs().preventDefault();
        //    //Xrm.Utility.openEntityForm(Xrm.Page.data.entity.getEntityName(), Xrm.Page.data.entity.getId());
        //    return false;
        //}

        var AssignedFacilitatorSchedule = null;

        if (Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue() !== null) {
            AssignedFacilitatorSchedule = Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue()[0].id;
        }

        if (AssignedFacilitatorSchedule !== null) {
            AssignedFacilitatorSchedule = replaceBracketsInGuid(AssignedFacilitatorSchedule);

            var note = Xrm.Page.getAttribute("ftc_sch_starttimeofschconf").getValue() + ":" + Xrm.Page.getAttribute("ftc_sch_startminutes").getText() + ((Xrm.Page.getAttribute("ftc_sch_starttimeampm").getValue()) ? "AM" : "PM") + "-" + Xrm.Page.getAttribute("ftc_sch_endtimeofschconf").getValue() + ":" + Xrm.Page.getAttribute("ftc_sch_endminutes").getText() + ((Xrm.Page.getAttribute("ftc_sch_endtimeampm").getValue()) ? "AM" : "PM");

            var ftc_sch_dateconfexpectedtoheld = Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue();
            var schedule_note = ("00" + (ftc_sch_dateconfexpectedtoheld.getMonth() + 1)).slice(-2) + "-" + ("00" + ftc_sch_dateconfexpectedtoheld.getDate()).slice(-2) + "-" + ftc_sch_dateconfexpectedtoheld.getFullYear() + " " + note;


            Xrm.Page.getAttribute("ftc_sch_schedulenote").setValue(schedule_note);
            UpdateAssginedFacilitatorEmail(AssignedFacilitatorSchedule);
            AddNotesToFacilitatorSchedule(AssignedFacilitatorSchedule, note);

            RemoveNotesFromOrgFacilitatorSchedule();

            Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").setValue(GetCurrentDate());
            Xrm.Page.getAttribute("ftc_sch_scheduledby").setValue(GetCurrentUser());

            Xrm.Page.getAttribute("ftc_sch_isrescheduled").setValue(true); //Flag that indicates FTC is Rescheduled by Scheduler or Facilitator.
            UpdateDueDateForCompletion();

        }

        DisableFields(["ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_starttimeampm", "ftc_sch_endtimeofschconf", "ftc_sch_endtimeampm", "ftc_sch_assignedfacilitator", "ftc_sch_reasonforreschedule", "ftc_sch_reasonforreschother", "ftc_sch_startminutes", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);

        return true;
    }
    else if (Xrm.Page.getAttribute("ftc_closeftcrequest").getValue() == "100000000" && statuscodeName === "assigned to facilitator" && FTCUserRole === "facilitator") 	//FTC Request = Close FTC
    {
        UpdateStatus(100000005, "completed");
        return true;
    }
    else if ((Xrm.Page.getAttribute("ftc_reqtoreschconf").getIsDirty() === true || Xrm.Page.getAttribute("ftc_reqtoreschconf").getSubmitMode() === "always") && Xrm.Page.getAttribute("ftc_reqtoreschconf").getValue() === true && (statuscodeName === "submitted" || statuscodeName === "assigned to facilitator") && (FTCUserRole === "requestor"))	//Requestor Requested for Reschedule
    {
        var ConfirmOption;
        Xrm.Utility.confirmDialog("Are you sure you would like to Request For Reschedule the conference?", function () { ConfirmOption = "Yes"; }, function () { ConfirmOption = "Cancel"; })
        if (ConfirmOption == "Cancel") {
            //Xrm.Page.getAttribute("ftc_reqtoreschconf").setValue(false);
            context.getEventArgs().preventDefault();
            //Xrm.Utility.openEntityForm(Xrm.Page.data.entity.getEntityName(), Xrm.Page.data.entity.getId());
            return false;
        }

        Xrm.Page.getAttribute("ftc_conferencerescheduleddate").setValue(GetCurrentDate()); //This field is in "Request for Reschdule/Withdraw" section.
        //Xrm.Page.getAttribute("ftc_sch_isrescheduled").setValue(true); //If needed create new field for Requestor Reschedule. "ftc_sch_isrescheduled" is used for to indicate FTC is Rescheduled by Scheduler or Facilitator.

        DisableFields(["ftc_reasonforreschedule", "ftc_reasonforreschduleother", "ftc_preferredconfdate1", "ftc_preferredconfdate2", "ftc_preferredconfdate3"]);
        return true;
    }
    return true;
}

//This function will determine whether requestor should proceed with application or not when conference type is Service Termination

function serviceTerminationConferenceLogic() {
    //1) Get the conf type
    //2)Get the Prog Type
    //3)if conf type==St and prgtype==safecare,fft--cw,sft,family connections, boys town, bsft then display a confirmation dialog if yes then lock prog type and proceed with application else close
    //4) if above condition is false then proceed with the application

    var confType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue());

    if (confType != null) {
        confType = confType.name.toLowerCase();
    }
    else {
        return;
    }

    var progType = getLookup(Xrm.Page.getAttribute("ftc_programtype").getValue());

    if (progType != null) {
        progType = progType.name.toLowerCase();
    }
    else {
        return;
    }

    var reasonForST = Xrm.Page.getAttribute("ftc_serviceterminationreason").getValue();


    if ((progType == "safe care" || progType == "fft-cw" || progType == "sft" || progType == "family connections" || progType == "boys town" || progType == "bsft") &&
        (confType == "service termination")) {


        //only show the below popoup once if user selected yes do not show again.

        if (reasonForST != null) {
            //already data collected why they are scheduling this meeting so no popup
            DisableFields(["ftc_programtype", "ftc_serviceterminationconferencereason", "ftc_serviceterminationreason"]);
            ShowFields(["ftc_serviceterminationreason"]);
        }
        else {


            var confirmStrings = {
                text: "This family does not require ACS facilitation for this Service Termination Conference. Do you still want ACS to facilitate the conference? Please select Yes to continue with the request. Select No to stop request creation and go back.", "cancelButtonLabel": "No", confirmButtonLabel: "Yes"
            };
            var confirmOptions = { height: 250, width: 600 };
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        DisableFields(["ftc_programtype"]);
                        //show the reason field for the first time
                        ShowFields(["ftc_serviceterminationreason"]);
                        Xrm.Page.getAttribute("ftc_serviceterminationreason").setRequiredLevel("required");
                    }
                    else {
                        //do not show unasved items pop up. 
                        var attributes = Xrm.Page.data.entity.attributes.get();
                        for (var i in attributes) {
                            attributes[i].setSubmitMode("never");
                        }
                        Xrm.Page.ui.close();
                        context.getEventArgs().preventDefault();
                    }

                });


        }

    }


}

//This will show ST conference reason Other field when user selected other as option
function serviceTerminationReasonOnChange() {
    var reasonForST = Xrm.Page.getAttribute("ftc_serviceterminationreason").getValue();
    if (reasonForST != null && reasonForST == 2)//reason is other
    {
        showHideRequiredNotReqired(["ftc_serviceterminationconferencereason"], true, true, false);
    }
    else {
        showHideRequiredNotReqired(["ftc_serviceterminationconferencereason"], false, false, true);
    }

}


function conferenceTypeOnChange() {

    var confType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue());

    if (confType != null) {
        confType = confType.name.toLowerCase();
    }
    else {
        showHideRequiredNotReqired(["ftc_programtype", "ftc_serviceterminationconferencereason", "ftc_serviceterminationreason"], false, false, true);


        return;

    }

    if (confType == "service termination") {
        ShowFields(["ftc_programtype"]);
        Xrm.Page.getAttribute("ftc_programtype").setRequiredLevel("required");

    }
    else {
        //hide and clear the program type
        showHideRequiredNotReqired(["ftc_serviceterminationconferencereason", "ftc_serviceterminationreason"], false, false, true);

    }

}


//this function will make controls show, make required and clear values
function showHideRequiredNotReqired(arrayOfControls, showField, makeRequired, setNull) {

    if (arrayOfControls !== null) {
        for (var k = 0; k < arrayOfControls.length; k++) {
            if (showField) {
                ShowFields([arrayOfControls[k]]);
            }
            else {
                HideFields([arrayOfControls[k]]);
            }
            if (makeRequired) {

                Xrm.Page.getAttribute(arrayOfControls[k]).setRequiredLevel("required");
            }
            else {
                Xrm.Page.getAttribute(arrayOfControls[k]).setRequiredLevel("none");
            }
            if (setNull) {
                Xrm.Page.getAttribute(arrayOfControls[k]).setValue(null);
            }

        }
    }

}




function UpdateStatus(StatusCode, StatusCodeName) {
    Xrm.Page.getAttribute("statuscode").setValue(StatusCode);
    //Set Global Variables: As we change the Status Reason, update global variable.
    statuscodeName = StatusCodeName;
    //Refresh the Form as we have updated the Status.
    SetFormState(FTCUserRole, statuscodeName, Xrm.Page.data.process.getActiveStage().getName());
}


function moveNext(currentStage) {
    var pollingAttemptsRemaining = 10;
    var intervalId;
    intervalId = setInterval(function () {
        pollingAttemptsRemaining -= 1;
        if (Xrm.Page.data.process.getActiveStage().getName() != currentStage) {
            clearInterval(intervalId);
        }
        if (!Xrm.Page.data.entity.getIsDirty() && Xrm.Page.data.process.getActiveStage().getName() == currentStage) {
            Xrm.Page.data.process.moveNext();
            pollingAttemptsRemaining = 0;
            clearInterval(intervalId);
        }
        if (pollingAttemptsRemaining <= 0) {
            clearInterval(intervalId);
        }
    }, 200);
}


//{Utility Functions : Start ================================================================

//Date Funtions
function GetCurrentUser() {
    var object = new Array();
    object[0] = new Object();
    object[0].id = Xrm.Page.context.getUserId().replace("{", "").replace("}", "");
    object[0].name = Xrm.Page.context.getUserName();
    object[0].entityType = "systemuser";
    return object;

}

function GetCurrentDate() {
    var today = new Date();

    today.setHours(0);
    today.setMinutes(0);
    today.setSeconds(0);
    today.setMilliseconds(0);

    return today;

}

function AddDaysToDate(date, numberofdays) {
    if (date != null)
        date.setDate(date.getDate() + parseInt(numberofdays));
    return date;
}

//Miscellaneous Function
function getLookup(lookup) {
    if (lookup != null && lookup.length != 0) {
        return lookup[0];
    }

    return null;
}

function replaceBracketsInGuid(id) {
    return id.replace("{", "").replace("}", "");
}

//Form Fields/Tabs/Sections/Fields Functions
function DisableAllFieldsOnForm() {
    Xrm.Page.data.entity.attributes.forEach(function (attribute) {
        attribute.controls.get().forEach(function (control) {
            if (control) {
                control.setDisabled(true);
            }
        });
    });
}

function DisableFields(fields) {
    if (fields != null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).controls.get().forEach(
                function (control) {
                    if (control) {
                        control.setDisabled(true);
                    }
                }
            );
        }
    }
}

function EnableFields(fields) {

    if (fields !== null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).controls.get().forEach(
                function (control) {
                    if (control) {
                        control.setDisabled(false);
                    }
                }
            );
        }
    }
}

function HideFields(fields) {
    if (fields !== null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).controls.get().forEach(
                function (control) {
                    if (control) {
                        control.setVisible(false);
                    }
                }
            );
        }
    }
}

function ShowFields(fields) {
    if (fields !== null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).controls.get().forEach(
                function (control) {
                    if (control) {
                        control.setVisible(true);
                    }
                }
            );
        }
    }
}


function DisableControls(controls) {
    if (controls !== null) {
        for (var k = 0; k < controls.length; k++) {
            Xrm.Page.getControl(controls[k]).setDisabled(true);
        }
    }
}

function EnableControls(controls) {

    if (controls !== null) {
        for (var k = 0; k < controls.length; k++) {
            Xrm.Page.getControl(controls[k]).setDisabled(false);
        }
    }
}

function HideControls(controls) {
    if (controls !== null) {
        for (var k = 0; k < controls.length; k++) {
            Xrm.Page.getControl(controls[k]).setVisible(false);
        }
    }

}

function ShowControls(controls) {
    if (controls != null) {
        for (var k = 0; k < controls.length; k++) {
            Xrm.Page.getControl(controls[k]).setVisible(true);
        }
    }
}

function setRequired(fields) {
    if (fields !== null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).setRequiredLevel("required");
        }
    }
}

function setNotRequired(fields) {
    if (fields !== null) {
        for (var k = 0; k < fields.length; k++) {
            Xrm.Page.getAttribute(fields[k]).setRequiredLevel("none");
        }
    }
}


function ShowTabs(tabs) {
    if (tabs != null) {
        for (var k = 0; k < tabs.length; k++) {
            Xrm.Page.ui.tabs.getByName(tabs[k]).setVisible(true);
        }
    }
}

function HideTabs(tabs) {
    if (tabs != null) {
        for (var k = 0; k < tabs.length; k++) {
            Xrm.Page.ui.tabs.getByName(tabs[k]).setVisible(false);
        }
    }
}


function ExpandTabs(tabs) {
    if (tabs != null) {
        for (var k = 0; k < tabs.length; k++) {
            Xrm.Page.ui.tabs.getByName(tabs[k]).setDisplayState("expanded");
        }
    }
}

function CollapseTabs(tabs) {
    if (tabs != null) {
        for (var k = 0; k < tabs.length; k++) {
            Xrm.Page.ui.tabs.getByName(tabs[k]).setDisplayState("collapsed");
        }
    }
}


function ShowSections(tab, sections) {
    if (tab != null && sections != null) {
        for (var k = 0; k < sections.length; k++) {
            Xrm.Page.ui.tabs.get(tab).sections.get(sections[k]).setVisible(true);
        }
    }
}

function HideSections(tab, sections) {
    if (tab != null && sections != null) {
        for (var k = 0; k < sections.length; k++) {
            Xrm.Page.ui.tabs.get(tab).sections.get(sections[k]).setVisible(false);
        }
    }
}

//User Entity, Security Role Functions
function IsUserHasRole(roleName) {
    roleName = roleName.toLowerCase();
    var currentUserRoles = Xrm.Page.context.getUserRoles();
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == roleName) {
            return true;
        }
    }
    return false;
}

function GetRoleName(userRoleId) {
    var roleName = null;

    SDK.WEBAPI.retrieveRecord(false, userRoleId, "role", "name", "",
        function (result) {
            if (result.length != 0) {
                roleName = result["name"];
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    if (roleName != null)
        roleName = roleName.toLowerCase();

    return roleName;
}

//Get Team Names
function getUserTeam(userId) {
    var myTeamId = null;
    var myTeamName = null;
    var myTeams = [];

    SDK.WEBAPI.retrieveRecord(false, userId, "systemuser", "systemuserid", "$expand=teammembership_association($select=isdefault,name)",
        function (result) {
            if (result.length != 0) {
                var systemuserid = result["systemuserid"];
                for (var a = 0; a < result.teammembership_association.length; a++) {
                    if (!result.teammembership_association[a]["isdefault"]) //If not default team add to myTeams array
                    {
                        myTeamName = result.teammembership_association[a]["name"];
                        myTeamId = result.teammembership_association[a]["teamid"];
                        myTeams.push(myTeamName + "," + myTeamId);
                    }
                }
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    return myTeams;
}

function ValidateDate(strControlName) {
    var DateField = Xrm.Page.getAttribute(strControlName)
    var NumberOfDays_Backward = 7;
    var NumberOfDays_Forward = 60;

    Xrm.Page.getControl(strControlName).clearNotification();

    // Verify that the field is valid
    if ((typeof (DateField) != "undefined") && (DateField != null)) {
        if (DateField.getValue() != null) {
            var SelectedDate = DateField.getValue()

            var BackwardDate = GetCurrentDate();
            var ForwardDate = GetCurrentDate();
            AddDaysToDate(BackwardDate, -NumberOfDays_Backward);
            AddDaysToDate(ForwardDate, NumberOfDays_Forward);

            var BackwardDateStr = ("00" + (BackwardDate.getMonth() + 1)).slice(-2) + "-" + ("00" + BackwardDate.getDate()).slice(-2) + "-" + BackwardDate.getFullYear();
            var ForwardDateStr = ("00" + (ForwardDate.getMonth() + 1)).slice(-2) + "-" + ("00" + ForwardDate.getDate()).slice(-2) + "-" + ForwardDate.getFullYear();

            try {
                if (SelectedDate < BackwardDate) {
                    Xrm.Page.getControl(strControlName).setNotification("Date can not be less than " + BackwardDateStr + " (" + NumberOfDays_Backward + " days past date from today's date)");
                    return false;
                }

                if (SelectedDate > ForwardDate) {
                    Xrm.Page.getControl(strControlName).setNotification("Date can not be more than " + ForwardDateStr + " (" + NumberOfDays_Forward + " days from today's date)");
                    return false;
                }

            }
            catch (e) {
            }
        }
    }

    return true;
}



//}Utility Functions : End ==============================================================

//{Business Rules - For Creating the FTC Request


//Returns true, if Active requests for StageID and ConfType selected.
function IsActiveStageIDAndConfTypeRequests() {
    var IsActiveRequests = true;

    var confTypeGUID = replaceBracketsInGuid(Xrm.Page.getAttribute("ftc_conferencetype").getValue()[0].id);
    var StageID = Xrm.Page.getAttribute("ftc_stageid").getValue();

    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())

    if (ConfType != null) {
        ConfType = ConfType.name.toLowerCase();
    }

    var query;

    if (ConfType === "child safety conference" || ConfType === "follow up child safety conference") {
        //"In Progress", Submitted, "Assigned to Facilitator", "Returned for modification","Pending with Supervisor", "Pending with Manager" are considered as Active FTC Requests
        //ftc_isdvconference=No or ftc_isdvconference=null
        query = "$select=ftc_name,statuscode&$filter=( statuscode eq 1 or  statuscode eq 100000000 or  statuscode eq 100000006 or  statuscode eq 100000009 or  statuscode eq 100000007 or  statuscode eq 100000008) and  _ftc_conferencetype_value eq " + confTypeGUID + " and  ftc_stageid eq '" + StageID + "' and (ftc_isdvconference eq 100000001 or ftc_isdvconference eq null)";

    }
    else {
        //"In Progress", Submitted, "Assigned to Facilitator", "Returned for modification","Pending with Supervisor", "Pending with Manager" are considered as Active FTC Requests
        query = "$select=ftc_name,statuscode&$filter=( statuscode eq 1 or  statuscode eq 100000000 or  statuscode eq 100000006 or  statuscode eq 100000009 or  statuscode eq 100000007 or  statuscode eq 100000008) and  _ftc_conferencetype_value eq " + confTypeGUID + " and  ftc_stageid eq '" + StageID + "'";
    }


    SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_ftcrequestforms", query, function (results) {
        if (results.value.length > 0)  //Active requests exist
        {
            IsActiveRequests = true;
        }
        else                        //No Active requests exist
        {
            IsActiveRequests = false;
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });


    return IsActiveRequests;
}

function GetStageOwner(StageID) {
    var role = null;
    var IsCP, CP_GUID, CP_Name, IsMG, IsWM, WM_GUID, WM_Name, IsCW, CW_GUID, CW_Name, MG_GUID, MG_Name, IsPR, PR_GUID, PR_Name = null;

    //Get SPLEmplyee records for the stage and Loop through all the records
    var query = "$select=_ods_person_value,ods_stageid,_ods_stagepersonrole_value&$filter=ods_stageid eq '" + StageID + "' and  _ods_person_value eq " + FTCUserID_NoBraces;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "ods_stagepersonlinkemployees", query, function (result) {
        for (var i = 0; i < result.value.length; i++) {
            role = result.value[i]["_ods_stagepersonrole_value@OData.Community.Display.V1.FormattedValue"];

            if (role == "CP") {
                IsCP = "yes"
                CP_GUID = result.value[i]["_ods_person_value"];
                CP_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];

            }
            else if (role == "MG") {
                IsMG = "yes"
                MG_GUID = result.value[i]["_ods_person_value"];
                MG_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];
            }
            else if (role == "PR") {
                IsPR = "yes"
                PR_GUID = result.value[i]["_ods_person_value"];
                PR_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];
            }
            else if (role == "WM") {
                IsWM = "yes"
                WM_GUID = result.value[i]["_ods_person_value"];
                WM_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];
            }
            else if (role == "CW") {
                IsCW = "yes"
                CW_GUID = result.value[i]["_ods_person_value"];
                CW_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];
            }
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    //Logic Here

    if (IsCP != null) {
        var CP_Team = getUserTeam(CP_GUID);

        var CP_TeamName, CP_TeamGUID;
        var FTCUserTeamName, FTCUserTeamID;

        if (CP_Team.length == 1) {

            CP_TeamName = CP_Team[0].split(",")[0];
            CP_TeamGUID = CP_Team[0].split(",")[1];


            var UserTeams = getUserTeam(FTCUserID_NoBraces);
            if (UserTeams.length == 1) {
                FTCUserTeamName = UserTeams[0].split(",")[0];
                FTCUserTeamID = UserTeams[0].split(",")[1];


                if (FTCUserTeamName.toLowerCase() == CP_TeamName.toLowerCase()) {
                    return [CP_TeamName, CP_TeamGUID, "team"]
                }
                else {
                    Xrm.Page.ui.setFormNotification("User do not have permissions on StageID", "ERROR", "NoPermOnStageID");
                    return null;
                }

            }
            else if (UserTeams.length == 0) {
                Xrm.Page.ui.setFormNotification("No teams assigned to user, please check with admin to correct access to the system", "ERROR", "NoTeamAssigned");
                return null;
            }
            else if (UserTeams.length > 1) {
                Xrm.Page.ui.setFormNotification("More than one team assiged, please check with admin to correct access to the system", "ERROR", "MorethanOneTeamAssigned");
                return null;
            }

        }
        else {
            Xrm.Page.ui.setFormNotification("StageID Owner Team not configured correctly in system, please check with admin", "ERROR", "StageIDOwnerConfigIssue");
            return null;
        }
    }
    else if (IsMG != null) {

        if (MG_GUID.toLowerCase() == FTCUserID_NoBraces.toLowerCase()) {
            return [MG_Name, MG_GUID, "systemuser"];
        }
        else {
            Xrm.Page.ui.setFormNotification("User do not have permissions on StageID", "ERROR", "NoPermOnStageID");
            return null;
        }

    }
    else if (IsPR != null) {
        debugger;
        if (PR_GUID.toLowerCase() == FTCUserID_NoBraces.toLowerCase()) {
            return [PR_Name, PR_GUID, "systemuser"]
        }
        else {
            Xrm.Page.ui.setFormNotification("User do not have permissions on StageID", "ERROR", "NoPermOnStageID");
            return null;
        }

    }
    else if (IsWM != null) {
        debugger;
        if (WM_GUID.toLowerCase() == FTCUserID_NoBraces.toLowerCase()) {
            return [WM_Name, WM_GUID, "systemuser"]
        }
        else {
            Xrm.Page.ui.setFormNotification("User do not have permissions on StageID", "ERROR", "NoPermOnStageID");
            return null;
        }

    }
    else if (IsCW != null) {
        debugger;
        if (CW_GUID.toLowerCase() == FTCUserID_NoBraces.toLowerCase()) {
            return [CW_Name, CW_GUID, "systemuser"]
        }
        else {
            Xrm.Page.ui.setFormNotification("User do not have permissions on StageID", "ERROR", "NoPermOnStageID");
            return null;
        }

    }


    else {
        Xrm.Page.ui.setFormNotification("StageID not assigned to any one in the system yet, please wait for sometime. If issue still exist, please check with admin.", "ERROR", "StageIDNotAssigned");
        return null;
    }

    //==================

}

//}

//{Business Rules - For Submitting the FTC Request

function IsFTCFamilyMemberSelected() {
    var IsFamilyMemberSelected = false;
    var FTC_GUID = replaceBracketsInGuid(Xrm.Page.data.entity.getId());

    SDK.WEBAPI.retrieveRecord(false, FTC_GUID, "ftc_ftcrequestform", "ftc_ftcrequestformid", "$expand=ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID($select=ftc_age,ftc_primarychild)",
        function (result) {
            if (result.length != 0) {
                var ftc_ftcrequestformid = result["ftc_ftcrequestformid"];
                for (var a = 0; a < result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID.length; a++) {
                    if (result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID[a]["ftc_primarychild"]) {
                        IsFamilyMemberSelected = true;
                    }
                }
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    return IsFamilyMemberSelected;
}

//}

//{LTS - Fetch LTS Data

function GetCINsForSelectedFTCFamilyMembers() {
    var FTC_GUID = replaceBracketsInGuid(Xrm.Page.data.entity.getId());
    var CINs = new Array();

    SDK.WEBAPI.retrieveRecord(false, FTC_GUID, "ftc_ftcrequestform", "ftc_name", "$expand=ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID($select=ftc_cin,ftc_primarychild)",
        function (result) {
            if (result.length != 0) {
                var ftc_name = result["ftc_name"];
                for (var a = 0; a < result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID.length; a++) {
                    if ((result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID[a]["ftc_primarychild"] == true) && (result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID[a]["ftc_cin"] !== null)) {
                        CINs.push(result.ftc_ftc_ftcrequestform_ftc_familymember_FamilyMemberFTCID[a]["ftc_cin"]);
                    }
                }
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    return CINs;
}

function GetLTSSourceGUIDSForCINS(CINs) {
    var LTSSourceGUIDS = new Array();
    var query;
    for (var i = 0; i < CINs.length; i++) {
        query = "$filter=lts_cinno eq '" + CINs[i] + "'";
        SDK.WEBAPI.retrieveMultipleRecords(false, "lts_ltscourtcases", query, function (results) {
            for (var j = 0; j < results.value.length; j++) {
                LTSSourceGUIDS.push(results.value[j]["lts_ltscourtcaseid"]);
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
    }
    return LTSSourceGUIDS;
}

function UpdateLTSSourceRecordsWithFTCID(LTSSourceGUIDS) {
    var FTC_GUID = replaceBracketsInGuid(Xrm.Page.data.entity.getId());

    var entity = {};
    entity["lts_LTSCourtCaseFTCID@odata.bind"] = "/ftc_ftcrequestforms(" + FTC_GUID + ")";

    for (var a = 0; a < LTSSourceGUIDS.length; a++) {
        SDK.WEBAPI.updateRecord(false, LTSSourceGUIDS[a], entity, "lts_ltscourtcases", function () {/*alert("Success");*/ }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
    }
}

//}

//{FTC History Functionality
function GetChildRecommForStageID(StageID) {
    var ChildRecommGUIDS = new Array();
    var query = "$filter=ftc_stageid eq '" + StageID + "'";
    SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_childrecommendations", query, function (results) {
        for (var i = 0; i < results.value.length; i++) {
            ChildRecommGUIDS.push(results.value[i]["ftc_childrecommendationid"]);
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    return ChildRecommGUIDS;
}

function UpdateChidRecommRecordsWithFTCID(ChildRecommGUIDS) {
    var FTC_GUID = replaceBracketsInGuid(Xrm.Page.data.entity.getId());

    if (FTC_GUID !== null) {
        var entity = {};
        entity["ftc_CopyToFTCID@odata.bind"] = "/ftc_ftcrequestforms(" + FTC_GUID + ")";

        for (var a = 0; a < ChildRecommGUIDS.length; a++) {
            SDK.WEBAPI.updateRecord(true, ChildRecommGUIDS[a], entity, "ftc_childrecommendations", function () {/*alert("Success");*/ }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
        }
    }
}

//}

//{Look up Filters
function addLocOfConfTeamFilter() {
    var filter = "<filter type='and'><condition attribute='teamtype' operator='eq' value='0' /><condition attribute='ftc_teamtype' operator='eq' value='Scheduler' /></filter>"
    Xrm.Page.getControl("ftc_locofconfteam").addCustomFilter(filter);
}

function addRelationshipToChildFilter() {
    var filter = "<filter type='and'><condition attribute='ftc_filter' operator='eq' value='confdetails' /></filter>"
    Xrm.Page.getControl("ftc_relationshiptochild").addCustomFilter(filter);
}
function addRelationshipToChildFilter1() {
    var filter = "<filter type='and'><condition attribute='ftc_filter' operator='eq' value='confdetails' /></filter>"
    Xrm.Page.getControl("ftc_relationshiptochild1").addCustomFilter(filter);
}
function addRelationshipToChildFilter2() {
    var filter = "<filter type='and'><condition attribute='ftc_filter' operator='eq' value='confdetails' /></filter>"
    Xrm.Page.getControl("ftc_relationshiptochild2").addCustomFilter(filter);
}
function addRelationshipToChildFilter3() {
    var filter = "<filter type='and'><condition attribute='ftc_filter' operator='eq' value='confdetails' /></filter>"
    Xrm.Page.getControl("ftc_relationshiptochild3").addCustomFilter(filter);
}


function addUpdatedConfFilter() {
    var filter = "<filter type='and'><condition attribute='ftc_isupdatedconftype' operator='eq' value='1' /></filter>"
    Xrm.Page.getControl("ftc_fac_whatwasupdatedpurposeofconf").addCustomFilter(filter);
}


//}

//{Field OnChange Functions



function ConfExpectedDate_onchange(ctrlName) {
    /*
	if(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue() <= AddDaysToDate(GetCurrentDate(),-7))
	{
		Xrm.Page.getControl("ftc_sch_dateconfexpectedtoheld").setNotification("Date Conference is Expected to be Held should be a future date or within past 7 days from current date");
	}
	else
	{
		Xrm.Page.getControl("ftc_sch_dateconfexpectedtoheld").clearNotification();
	}
	*/

    ValidateDate(ctrlName);
    Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").setValue(null);
}

function FacilitatorBorough_OnChange() {
    Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").setValue(null);
}

//Grids
function ActiveCourtCase_OnChange() {
    var ftc_activecourtcase = Xrm.Page.getAttribute("ftc_activecourtcase").getValue();

    if (ftc_activecourtcase == "100000000") {
        ftc_activecourtcase = true;
    }
    SetGridState(ftc_activecourtcase, "tab_lts_court_cases", "sec_lts_editable_grid", "sec_lts_readonly_grid", "Grid_lts_court_cases_Editable");
}

function FTCHistory_OnChange() {
    if (Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedftc").getText() && Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedftc").getText().toLowerCase() === "yes") {
        Xrm.Page.ui.tabs.get("tab_ftc_history").sections.get("sec_ftc_history_readonly").setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get("tab_ftc_history").sections.get("sec_ftc_history_readonly").setVisible(false);
    }
}


function CWS_NY_OnChange() {
    var Displayflag = false;
    if (Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedcws").getText() && Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedcws").getText().toLowerCase() === "yes") {
        Displayflag = true;
    }
    SetGridState(Displayflag, "tab_child_welfare_history", "sec_CWS_Editable_Grid", "sec_CWS_Readonly_Grid", "Grid_CWS_NY_Editable");
    SetGridState(Displayflag, "tab_child_welfare_history", "sec_CWS_Editable_Grid", "sec_CWS_Readonly_Grid", "Grid_CWS_OutsideNY_Editable");
}

/*
function CWS_OutsideNY_OnChange() {
var Displayflag = false;
if (Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedcwsoutsideny").getText() && Xrm.Page.getAttribute("ftc_isfamilyprevinvolvedcwsoutsideny").getText().toLowerCase() === "yes")
{
	Displayflag = true;
}
SetGridState(Displayflag,"tab_child_welfare_history","sec_CWSOusideNY_Edit_Grid","sec_CWSOusideNY_Readonly_Grid","Grid_CWS_OutsideNY_Editable");
}
*/

function School_Information_OnChange() {
    var ftc_ischildrenenrolledinschool = Xrm.Page.getAttribute("ftc_ischildrenenrolledinschool").getValue();
    if (ftc_ischildrenenrolledinschool == "100000000")
        ftc_ischildrenenrolledinschool = true;
    SetGridState(ftc_ischildrenenrolledinschool, "School_Information", "Sec_School_Information_Editable", "Sec_School_Information_Readonly", "Grid_Schools_Information_Editable");
}

function Acute_Hospital_OnChange() {
    var ftc_ischildinacutepsychiatrichospital = Xrm.Page.getAttribute("ftc_ischildinacutepsychiatrichospital").getValue();
    SetGridState(ftc_ischildinacutepsychiatrichospital, "Special_Circumstances", "sec_Acute_hospital_grid_Editable", "sec_Acute_hospital_grid_Readonly", "Grid_Acute_Psychiatric_Hospitals_Editable");
}

function Child_Juvenile_OnChange() {

    var ftc_ischildinjuvenilesetting = Xrm.Page.getAttribute("ftc_ischildinjuvenilesetting").getValue();
    SetGridState(ftc_ischildinjuvenilesetting, "Special_Circumstances", "sec_juvenile_settings_grid_Editable", "sec_juvenile_settings_grid_Readonly", "Grid_Child_juvenile_settings_Editable");

}

function Child_ExpectingBaby_OnChange() {

    var ftc_ischildexpectingbaby = Xrm.Page.getAttribute("ftc_ischildexpectingbaby").getValue();
    SetGridState(ftc_ischildexpectingbaby, "Special_Circumstances", "sec_child_expectingbaby_grid_Editable", "sec_child_expectingbaby_grid_Readonly", "Grid_Child_expecting_baby_Editable");

}

function Child_ParentingChild_OnChange() {

    var ftc_ischildparentingchild = Xrm.Page.getAttribute("ftc_ischildparentingchild").getValue();
    SetGridState(ftc_ischildparentingchild, "Special_Circumstances", "sec_child_parentingchild_grid_Editable", "sec_child_parentingchild_grid_Readonly", "Grid_Child_parenting_Children_Editable");

}

function ConferenceRecomm_OnChange() {

    var ftc_fac_whatconfrecom = Xrm.Page.getAttribute("ftc_fac_whatconfrecom").getValue();
    SetGridState(ftc_fac_whatconfrecom, "Tab_Action_Plan", "Sec_Conf_Recomm_Editable", "Sec_Conf_Recomm_Readonly", "Grid_Conf_Recomm_Editable");

}

function Withdraw_OnChange() {
    //var obj = Xrm.Page.getControl('WebResource_sch_DateConfConSentToAgency').getObject().contentDocument.getElementById('sch_DateConfConSentToAgency');

    if (Xrm.Page.getAttribute("ftc_wastheconferencewithdrawn").getValue() === true) {
        setNotRequired(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);

        //Xrm.Page.getAttribute("ftc_reasonforwithdrawal").setRequiredLevel("required");
        //Xrm.Page.getControl("ftc_reasonforwithdrawal").setVisible(true);
        //Xrm.Page.getControl("ftc_withdrawaldate").setDisabled(true);
        //Xrm.Page.getControl("ftc_reasonforwithdrawal").setDisabled(false);
        //Xrm.Page.getControl("ftc_reasonforwithdrawal").setVisible(true);
        //if (obj) {
        //    obj.innerHTML = "";
        //}
    }
    else {
        Xrm.Page.getAttribute("ftc_reasonforwithdrawal").setRequiredLevel("none");
        Xrm.Page.getAttribute("ftc_reasonforwithdrawal").setValue(null);
        Xrm.Page.getControl("ftc_reasonforwithdrawal").setVisible(false);
        Xrm.Page.getControl("ftc_withdrawaldate").setDisabled(false);
        //Xrm.Page.getControl("ftc_reasonforwithdrawal").setVisible(false);
        setRequired(["ftc_sch_assignedfacilitator", "ftc_sch_dateconfconfirmsenttoagency", "ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_startminutes", "ftc_sch_endtimeofschconf", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
        //if (obj) {
        //    obj.innerHTML = "&nbsp;*";
        //}
    }
}

function PreferredConfDate_OnChange(strControlName) {
    if (ValidateDate(strControlName)) {
        Xrm.Page.getControl(strControlName).clearNotification();

        var Dt1 = Xrm.Page.getAttribute("ftc_preferredconfdate1").getValue();
        var Dt2 = Xrm.Page.getAttribute("ftc_preferredconfdate2").getValue();
        var Dt3 = Xrm.Page.getAttribute("ftc_preferredconfdate3").getValue();

        if (Dt1 !== null && Dt2 !== null && Dt1.getTime() === Dt2.getTime()) {
            Xrm.Page.getControl(strControlName).setNotification("Preferred Conference Dates should be unique. Please choose different date.");
        }
        else if (Dt1 !== null && Dt3 !== null && Dt1.getTime() === Dt3.getTime()) {
            Xrm.Page.getControl(strControlName).setNotification("Preferred Conference Dates should be unique. Please choose different date.");
        }
        else if (Dt2 !== null && Dt3 !== null && Dt2.getTime() === Dt3.getTime()) {
            Xrm.Page.getControl(strControlName).setNotification("Preferred Conference Dates should be unique. Please choose different date.");
        }
    }
}

function UpdatedConfTypeSettings_OnChange() {
    Xrm.Page.getAttribute("ftc_fac_programtype").setValue(null);
    SetUpdatedConfTypeSettings();
}

function DidPurposeOfConfChanged_OnChange() {
    var obj = Xrm.Page.getControl('WebResource_fac_WhatUpdatedPurposeConf').getObject().contentDocument.getElementById('fac_WhatUpdatedPurposeConf');

    if (Xrm.Page.getAttribute("ftc_fac_didpurposeofconfchange").getValue() === false) {
        Xrm.Page.getAttribute("ftc_fac_whatwasupdatedpurposeofconf").setValue(null);
        SetUpdatedConfTypeSettings();
        if (obj) {
            obj.innerHTML = "";
        }
    }
    else {
        if (obj) {
            obj.innerHTML = "&nbsp;*";
        }
    }
}

//}

//{Business Rules - Scheduler Functionality Functions
function addFacilitatorBoroughFilter() {
    var filter = "<filter type='and'><condition attribute='teamtype' operator='eq' value='0' /><condition attribute='ftc_teamtype' operator='eq' value='Scheduler' /></filter>"
    Xrm.Page.getControl("ftc_sch_facilitatorborough").addCustomFilter(filter);
}

function addFacilitatorFilter() {

    var dateconfexpectedtoheld = Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue();

    var dateconfexpectedtoheld_string, dateconfexpectedtoheld_stringCRM, dateconfexpectedtoheld_stringCRMISO;

    dateconfexpectedtoheld_string = "1900-01-01"; //default value

    var FacBorough = getLookup(Xrm.Page.getAttribute("ftc_sch_facilitatorborough").getValue())


    if (dateconfexpectedtoheld !== null && FacBorough !== null) {

        var FacBoroughGuid_NoBraces = replaceBracketsInGuid(FacBorough.id);
        //var FacBorough_Name = FacBorough.name.toLowerCase();

        var month = dateconfexpectedtoheld.getMonth() + 1;
        dateconfexpectedtoheld_string = dateconfexpectedtoheld.getFullYear() + "-" + month + "-" + dateconfexpectedtoheld.getDate(); //2017-11-16
        dateconfexpectedtoheld_stringCRM = month + "/" + dateconfexpectedtoheld.getDate() + "/" + dateconfexpectedtoheld.getFullYear(); //11/16/2017
        dateconfexpectedtoheld_stringCRMISO = new Date(dateconfexpectedtoheld_stringCRM).toISOString(); //"2017-11-16T05:00:00.000Z"

        //Retrieve multiple records from Facilitators, select ID,GUID
        var facilitators = new Array();
        var query = "$select=_ftc_facilitatorname_value,ftc_id,_ftc_sch_facilitatorborough_value&$filter=_ftc_sch_facilitatorborough_value eq " + FacBoroughGuid_NoBraces + "";

        SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_facilitators", query, function (results) {
            for (var i = 0; i < results.value.length; i++) {
                // id:ID,     facilitatorBorough_GUID:  Facilitator Borough,       facilitatorUser_GUID:Facilitator Name
                facilitators.push({ id: results.value[i].ftc_id, facilitator_GUID: results.value[i].ftc_facilitatorid, facilitatorBorough_GUID: results.value[i]._ftc_sch_facilitatorborough_value, facilitatorUser_GUID: results.value[i]._ftc_facilitatorname_value });
            }

        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        //Retrieve multiple records based on Date from Facilitator Schedules, select ID.
        var facilitatorsSchedules = new Set();
        var query1 = "$select=ftc_id&$filter=_ftc_schform_facilitatorborough_value eq " + FacBoroughGuid_NoBraces + " and ftc_date eq " + dateconfexpectedtoheld_stringCRMISO;
        SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_facilitatorschedules", query1, function (results) {
            for (var i = 0; i < results.value.length; i++) {
                facilitatorsSchedules.add(results.value[i].ftc_id);
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });


        //Iterate facilitators, if the ID is not in the facilitatorsSchedules Set then create the facilitatorsSchedule record.
        for (var i = 0; i < facilitators.length; i++) {
            if (!facilitatorsSchedules.has(facilitators[i].id)) {
                CreateFacilitatorSchedule(facilitators[i].id, facilitators[i].facilitator_GUID, facilitators[i].facilitatorBorough_GUID, dateconfexpectedtoheld_stringCRM, facilitators[i].facilitatorUser_GUID);
            }
        }

    }
    else {
        Xrm.Utility.alertDialog("Please enter 'Date Conference is Expected to be Held' and 'Facilitator Borough'");
    }

    var filter;
    if (FacBorough !== null)
        filter = "<filter type='and'><condition attribute='ftc_isavailable' value='1' operator='eq'/><condition attribute='ftc_date' value='" + dateconfexpectedtoheld_string + "' operator='on'/><condition attribute='ftc_schform_facilitatorborough' value='" + FacBorough.id + "' operator='eq' uitype='team' uiname='" + FacBorough.name + "'/></filter>";
    else
        filter = "<filter type='and'><condition attribute='ftc_isavailable' value='1' operator='eq'/><condition attribute='ftc_date' value='" + dateconfexpectedtoheld_string + "' operator='on'/></filter>";

    Xrm.Page.getControl("ftc_sch_assignedfacilitator").addCustomFilter(filter);

}


function addFacilitatorFilter_Old() {

    var dateconfexpectedtoheld = Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue();

    var dateconfexpectedtoheld_string, dateconfexpectedtoheld_stringCRM, dateconfexpectedtoheld_stringCRMISO;

    dateconfexpectedtoheld_string = "1900-01-01"; //default value

    if (dateconfexpectedtoheld !== null) {
        var month = dateconfexpectedtoheld.getMonth() + 1;
        dateconfexpectedtoheld_string = dateconfexpectedtoheld.getFullYear() + "-" + month + "-" + dateconfexpectedtoheld.getDate(); //2017-11-16
        dateconfexpectedtoheld_stringCRM = month + "/" + dateconfexpectedtoheld.getDate() + "/" + dateconfexpectedtoheld.getFullYear(); //11/16/2017
        dateconfexpectedtoheld_stringCRMISO = new Date(dateconfexpectedtoheld_stringCRM).toISOString(); //"2017-11-16T05:00:00.000Z"

        //Retrieve multiple records from Facilitators, select ID,GUID
        var facilitators = new Array();
        var query = "$select=ftc_id,ftc_sch_facilitatorboroughguid";
        SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_facilitators", query, function (results) {
            for (var i = 0; i < results.value.length; i++) {
                facilitators.push({ id: results.value[i].ftc_id, facilitator_GUID: results.value[i].ftc_facilitatorid, facilitatorBorough_GUID: results.value[i].ftc_sch_facilitatorboroughguid });
            }

        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        //Retrieve multiple records based on Date from Facilitator Schedules, select ID.
        var facilitatorsSchedules = new Set();
        var query1 = "$select=ftc_id&$filter=ftc_date eq " + dateconfexpectedtoheld_stringCRMISO;
        SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_facilitatorschedules", query1, function (results) {
            for (var i = 0; i < results.value.length; i++) {
                facilitatorsSchedules.add(results.value[i].ftc_id);
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });


        //Iterate facilitators, if the ID is not in the facilitatorsSchedules Set then create the facilitatorsSchedule record.
        for (var i = 0; i < facilitators.length; i++) {
            if (!facilitatorsSchedules.has(facilitators[i].id)) {
                CreateFacilitatorSchedule(facilitators[i].facilitator_GUID, facilitators[i].facilitatorBorough_GUID, dateconfexpectedtoheld_stringCRM);
            }
        }

    }
    else {
        Xrm.Utility.alertDialog("Please enter Date Conference is Expected to be Held");
    }

    var filter = "<filter type='and'><condition attribute='ftc_isavailable' value='1' operator='eq'/><condition attribute='ftc_date' value='" + dateconfexpectedtoheld_string + "' operator='on'/></filter>";

    Xrm.Page.getControl("ftc_sch_assignedfacilitator").addCustomFilter(filter);

}

function CreateFacilitatorSchedule(id, facilitator_GUID, facilitatorBorough_GUID, date, facilitatorUser_GUID) {
    var entity = {};
    entity["ftc_FacilitatorScheduleFacilitator@odata.bind"] = "/ftc_facilitators(" + facilitator_GUID + ")";
    entity["ftc_schform_FacilitatorBorough@odata.bind"] = "/teams(" + replaceBracketsInGuid(facilitatorBorough_GUID) + ")";
    entity.ftc_id = id;
    entity.ftc_date = new Date(date).toISOString();
    entity.ftc_facilitatorguid = facilitatorUser_GUID;
    SDK.WEBAPI.createRecord(false, entity, "ftc_facilitatorschedules", function () {/*alert("Success");*/ }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
}

function AddNotesToFacilitatorSchedule(FacilitatorSchedule_Guid, note) {

    //fetch notes based on 	FacilitatorSchedule_Guid
    var ftc_notes;

    SDK.WEBAPI.retrieveRecord(false, FacilitatorSchedule_Guid, "ftc_facilitatorschedule", "ftc_notes", "",
        function (result) {
            if (result.length != 0) {
                ftc_notes = result.ftc_notes;
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    var entity = {};

    if (ftc_notes !== null) {
        entity.ftc_notes = ftc_notes + "," + note
    }
    else {
        entity.ftc_notes = note
    }

    SDK.WEBAPI.updateRecord(false, FacilitatorSchedule_Guid, entity, "ftc_facilitatorschedules", function () {/*alert("Success");*/ }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

}


function RemoveNotesFromOrgFacilitatorSchedule() {

    var ftc_sch_orgschedulenote = Xrm.Page.getAttribute("ftc_sch_orgschedulenote").getValue();
    var ftc_sch_orgschedulenote_Array;
    var NoteToRemove;

    if (ftc_sch_orgschedulenote !== null) {
        ftc_sch_orgschedulenote_Array = ftc_sch_orgschedulenote.split(" ");

        if (ftc_sch_orgschedulenote_Array.length == 2)
            NoteToRemove = ftc_sch_orgschedulenote_Array[1];
    }


    if (NoteToRemove !== null && Xrm.Page.getAttribute("ftc_sch_orgassignedfacilitator").getValue() !== null) {
        var OrgAssignedFacilitatorSchedule = replaceBracketsInGuid(Xrm.Page.getAttribute("ftc_sch_orgassignedfacilitator").getValue()[0].id);

        //Get note from Facilitator Schedule
        var ftc_notes;
        SDK.WEBAPI.retrieveRecord(false, OrgAssignedFacilitatorSchedule, "ftc_facilitatorschedule", "ftc_notes", "",
            function (result) {
                if (result.length != 0) {
                    ftc_notes = result.ftc_notes;
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });


        if (ftc_notes != null && ftc_notes) { //check null condition
            //Create new note
            var new_ftc_notes = ftc_notes.replace((NoteToRemove + ","), ""); //start and middle element

            if (new_ftc_notes.length == ftc_notes.length) {
                new_ftc_notes = ftc_notes.replace(("," + NoteToRemove), ""); //last element
                if (new_ftc_notes.length == ftc_notes.length)
                    new_ftc_notes = ftc_notes.replace(NoteToRemove, "");	//single element
            }

            //Update Facilitator Schedule with new note
            var entity = {};
            entity.ftc_notes = new_ftc_notes;
            SDK.WEBAPI.updateRecord(false, OrgAssignedFacilitatorSchedule, entity, "ftc_facilitatorschedules", function () {/*alert("Success");*/ }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
        }

    }
}

function UpdateDueDateForScheduling() {
    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())
    var ConfTypeID_NoBraces = null;
    if (ConfType != null)
        ConfTypeID_NoBraces = replaceBracketsInGuid(ConfType.id);

    var ftc_daterequestformsubmission = Xrm.Page.getAttribute("ftc_daterequestformsubmission").getValue();
    var ftc_heldtimeframe, ftc_scheduletimeframe, ftc_name;

    SDK.WEBAPI.retrieveRecord(false, ConfTypeID_NoBraces, "ftc_conferencetype", "ftc_heldtimeframe,ftc_scheduletimeframe,ftc_name", "",
        function (result) {
            if (result.length != 0) {
                ftc_heldtimeframe = result.ftc_heldtimeframe;
                ftc_scheduletimeframe = result.ftc_scheduletimeframe;
                ftc_name = result.ftc_name;
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });


    if (ftc_name.toLowerCase() === "follow up child safety conference") {
        //Get the date when previous child safety conference is completed for the stageID.
        var StageID = Xrm.Page.getAttribute('ftc_stageid').getValue();
        var Prev_ftc_ftccloseddate = null;

        var query = "$select=ftc_ftccloseddate&$filter=ftc_stageid eq '" + StageID + "' and  statuscode eq 100000005";
        SDK.WEBAPI.retrieveMultipleRecords(false, "ftc_ftcrequestforms", query, function (results) {
            for (var i = 0; i < results.value.length; i++) {
                if (Prev_ftc_ftccloseddate == null || Prev_ftc_ftccloseddate < results.value[i].ftc_ftccloseddate) {
                    Prev_ftc_ftccloseddate = results.value[i].ftc_ftccloseddate;
                }
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete"); */ });

        if (Prev_ftc_ftccloseddate != null) {
            Xrm.Page.getAttribute("ftc_duedateforscheduling").setValue(AddDaysToDate(Prev_ftc_ftccloseddate, ftc_scheduletimeframe));
        }
        else {
            Xrm.Page.getAttribute("ftc_duedateforscheduling").setValue(AddDaysToDate(ftc_daterequestformsubmission, ftc_scheduletimeframe));
        }
    }
    else {
        Xrm.Page.getAttribute("ftc_duedateforscheduling").setValue(AddDaysToDate(ftc_daterequestformsubmission, ftc_scheduletimeframe));
    }
}

function UpdateDueDateForCompletion() {
    var ConfType = getLookup(Xrm.Page.getAttribute("ftc_conferencetype").getValue())
    var ConfTypeID_NoBraces = null;
    if (ConfType != null) {
        ConfTypeID_NoBraces = replaceBracketsInGuid(ConfType.id);
    }
    var ftc_sch_dateconferenceassigned = Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").getValue();
    var ftc_heldtimeframe, ftc_scheduletimeframe, ftc_name;

    SDK.WEBAPI.retrieveRecord(false, ConfTypeID_NoBraces, "ftc_conferencetype", "ftc_heldtimeframe,ftc_scheduletimeframe,ftc_name", "",
        function (result) {
            if (result.length != 0) {
                ftc_heldtimeframe = result.ftc_heldtimeframe;
                ftc_scheduletimeframe = result.ftc_scheduletimeframe;
                ftc_name = result.ftc_name;
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    Xrm.Page.getAttribute("ftc_duedateforftc").setValue(AddDaysToDate(ftc_sch_dateconferenceassigned, ftc_heldtimeframe));
}


function UpdateAssginedFacilitatorEmail(AssignedFacilitatorSchedule) {
    var ftc_facilitatorguid;
    var ftc_name;

    SDK.WEBAPI.retrieveRecord(false, AssignedFacilitatorSchedule, "ftc_facilitatorschedule", "ftc_facilitatorguid,ftc_name", "",
        function (result) {
            if (result.length != 0) {
                ftc_facilitatorguid = result.ftc_facilitatorguid;
                ftc_name = result.ftc_name;
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

    Xrm.Page.getAttribute("ftc_sch_assignedfacilitatoremail").setValue([{ id: ftc_facilitatorguid, name: ftc_name, entityType: "systemuser" }]);
}

//Reschdule Functionality

//function onChangeOfReSchedule() {
//    if (Xrm.Page.getAttribute("ftc_sch_reschedule").getValue() === true) {
//        DisableFields(["ftc_sch_reschedule"]);
//        EnableFields(["ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_starttimeampm", "ftc_sch_endtimeofschconf", "ftc_sch_endtimeampm", "ftc_sch_assignedfacilitator", "ftc_sch_reasonforreschedule", "ftc_sch_startminutes", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
//        //,"ftc_sch_assignedmanageroffacilitator"

//        Xrm.Page.getAttribute("ftc_sch_orgdateconfassigned").setValue(Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").getValue());
//        Xrm.Page.getAttribute("ftc_sch_orgdateconfexptobeheld").setValue(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue());

//        Xrm.Page.getAttribute("ftc_sch_reschedule").setSubmitMode("always");

//        //Created these fields to remove notes from original Facilitator Schedule record
//        Xrm.Page.getAttribute("ftc_sch_orgassignedfacilitator").setValue(Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue());
//        Xrm.Page.getAttribute("ftc_sch_orgschedulenote").setValue(Xrm.Page.getAttribute("ftc_sch_schedulenote").getValue());

//        if (Xrm.Page.data.process.getActiveStage().getName() === "Facilitator") {
//            setNotRequired(["ftc_dateftcheld"]);
//        }
//    }
//}

function onChangeOfReSchedule() {
    Xrm.Utility.confirmDialog("Are you sure you would like to Reschedule the conference?",
        function () {
            if (Xrm.Page.getAttribute("ftc_sch_reschedule").getValue() === true) {
                DisableFields(["ftc_sch_reschedule"]);
                EnableFields(["ftc_sch_dateconfexpectedtoheld", "ftc_sch_starttimeofschconf", "ftc_sch_starttimeampm", "ftc_sch_endtimeofschconf", "ftc_sch_endtimeampm", "ftc_sch_assignedfacilitator", "ftc_sch_reasonforreschedule", "ftc_sch_startminutes", "ftc_sch_endminutes", "ftc_sch_facilitatorborough"]);
                //,"ftc_sch_assignedmanageroffacilitator"

                Xrm.Page.getAttribute("ftc_sch_orgdateconfassigned").setValue(Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").getValue());
                Xrm.Page.getAttribute("ftc_sch_orgdateconfexptobeheld").setValue(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue());
                Xrm.Page.getAttribute("ftc_sch_reschedule").setSubmitMode("always");
                //Created these fields to remove notes from original Facilitator Schedule record
                Xrm.Page.getAttribute("ftc_sch_orgassignedfacilitator").setValue(Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue());
                Xrm.Page.getAttribute("ftc_sch_orgschedulenote").setValue(Xrm.Page.getAttribute("ftc_sch_schedulenote").getValue());
                if (Xrm.Page.data.process.getActiveStage().getName() === "Facilitator") {
                    setNotRequired(["ftc_dateftcheld"]);
                }
            }
        },
        function () {
            Xrm.Page.getAttribute("ftc_sch_reschedule").setValue(false);
            //context.getEventArgs().preventDefault();
        });
}



function AssignedFacilitator_OnChange() {
    var AssignedFacilitatorSchedule;
    if (Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue() !== null) {
        AssignedFacilitatorSchedule = Xrm.Page.getAttribute("ftc_sch_assignedfacilitator").getValue()[0].id;
        AssignedFacilitatorSchedule = replaceBracketsInGuid(AssignedFacilitatorSchedule);

        //Get Facilitator GUID from FacilitatorSchedule Record
        var ftc_facilitatorguid;

        SDK.WEBAPI.retrieveRecord(false, AssignedFacilitatorSchedule, "ftc_facilitatorschedule", "ftc_facilitatorguid", "",
            function (result) {
                if (result.length != 0) {
                    ftc_facilitatorguid = result.ftc_facilitatorguid;
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });

        if (ftc_facilitatorguid !== null)
            ftc_facilitatorguid = replaceBracketsInGuid(ftc_facilitatorguid);

        //Get Manager details from Facilitator Record
        var _parentsystemuserid_value, _parentsystemuserid_value_formatted, _parentsystemuserid_value_lookuplogicalname;

        SDK.WEBAPI.retrieveRecordWithFormattedData(false, ftc_facilitatorguid, "systemuser", "_parentsystemuserid_value", "", function (result) {
            if (result.length != 0) {
                _parentsystemuserid_value = result["_parentsystemuserid_value"];
                _parentsystemuserid_value_formatted = result["_parentsystemuserid_value@OData.Community.Display.V1.FormattedValue"];
                _parentsystemuserid_value_lookuplogicalname = result["_parentsystemuserid_value@Microsoft.Dynamics.CRM.lookuplogicalname"];
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });


        //Set the "Assigned Manager" field on the form
        if (_parentsystemuserid_value !== null)
            Xrm.Page.getAttribute("ftc_sch_assignedmanageroffacilitator").setValue([{ id: "{" + _parentsystemuserid_value + "}", name: _parentsystemuserid_value_formatted, entityType: "systemuser" }]);
        else
            Xrm.Page.getAttribute("ftc_sch_assignedmanageroffacilitator").setValue(null);


    }

}

//}

//Business Rules - Facilitator
function GetCPForStage(StageID) {
    var role = null;
    var IsCP, CP_GUID, CP_Name = null;

    //Get SPLEmplyee records for the stage and Loop through all the records
    var query = "$select=_ods_person_value,ods_stageid,_ods_stagepersonrole_value&$filter=ods_stageid eq '" + StageID + "'"
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "ods_stagepersonlinkemployees", query, function (result) {
        for (var i = 0; i < result.value.length; i++) {
            role = result.value[i]["_ods_stagepersonrole_value@OData.Community.Display.V1.FormattedValue"];
            if (role == "CP") {
                IsCP = "yes"
                CP_GUID = result.value[i]["_ods_person_value"];
                CP_Name = result.value[i]["_ods_person_value@OData.Community.Display.V1.FormattedValue"];
            }
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });


    if (IsCP != null)
        return [CP_Name, CP_GUID, "systemuser"];
    else
        return null;

}

function CWPFacilitator_OnChange() {
    var ftc_facilitatorguid = null;

    if (Xrm.Page.getAttribute("ftc_fac_cwpfacilitatornamenew").getValue() !== null) {
        var CWPFacilitator_GUID = Xrm.Page.getAttribute("ftc_fac_cwpfacilitatornamenew").getValue()[0].id;

        SDK.WEBAPI.retrieveRecord(false, replaceBracketsInGuid(CWPFacilitator_GUID), "ftc_facilitator", "_ftc_facilitatorname_value", "",
            function (result) {
                if (result.length != 0) {
                    ftc_facilitatorguid = result._ftc_facilitatorname_value;
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
    }

    if (ftc_facilitatorguid !== null) {
        SDK.WEBAPI.retrieveRecord(false, replaceBracketsInGuid(ftc_facilitatorguid), "systemuser", "address1_telephone1", "",
            function (result) {
                if (result.length != 0) {
                    Xrm.Page.getAttribute("ftc_fac_cwpfacilitatorphone").setValue(result.address1_telephone1);
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); });
    }
    else {
        Xrm.Page.getAttribute("ftc_fac_cwpfacilitatorphone").setValue(null);
    }
}

//Requestor Reschedule Functionaility
function onChangeOfRequestorReSchedule() {
    if (Xrm.Page.getAttribute("ftc_reqtoreschconf").getValue() === true) {
        DisableFields(["ftc_reqtoreschconf"]);
        //Enable Three Preferred Dates
        EnableFields(["ftc_reasonforreschedule", "ftc_preferredconfdate1", "ftc_preferredconfdate2", "ftc_preferredconfdate3"]);

        Xrm.Page.getAttribute("ftc_reqtoreschconf").setSubmitMode("always");
    }

}

//Returns requestor/scheduler/facilitator
function GetFTCUserRole() {
    var IsFacilitator = false;
    var IsScheduler = false;
    var IsManager = false;
    var IsSupervisor = false;
    var IsFTCAdmin = false;

    var currentUserRoles = Xrm.Page.context.getUserRoles();
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);

        if (userRoleName == "ftc facilitator") {
            IsFacilitator = true;
        }
        else if (userRoleName == "ftc scheduler") {
            IsScheduler = true;
        }
        else if (userRoleName == "ftc manager") {
            IsManager = true;
        }
        else if (userRoleName == "ftc supervisor") {
            IsSupervisor = true;
        }
        else if (userRoleName == "ftc admin") {
            IsFTCAdmin = true;
        }
    }

    if (IsFacilitator == true)
        return "facilitator";
    else if (IsScheduler == true)
        return "scheduler";
    else if (IsManager == true)
        return "manager";
    else if (IsSupervisor == true)
        return "supervisor";
    else if (IsFTCAdmin == true)
        return "ftc admin";
    else
        return "requestor";

}

function RemoveEditableGridWhiteSpace() {
    var Editable_Grids_Divs = ["Grid_lts_court_cases_Editable_d", "Grid_Family_Composition_Editable_d", "Grid_CWS_NY_Editable_d", "Grid_CWS_OutsideNY_Editable_d", "Grid_Schools_Information_Editable_d", "Grid_Acute_Psychiatric_Hospitals_Editable_d", "Grid_Child_juvenile_settings_Editable_d", "Grid_Child_expecting_baby_Editable_d", "Grid_Child_parenting_Children_Editable_d", "Conference_Participants_d", "Grid_Conf_Recomm_Editable_d"];

    for (var i = 0; i < Editable_Grids_Divs.length; i++) {
        if (parent.document.getElementById(Editable_Grids_Divs[i]) != null) {
            parent.document.getElementById(Editable_Grids_Divs[i]).setAttribute("style", "padding-bottom: 0px; height: 202px;");
        }
    }
}




//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function StageID_PID_OnChange() {
    //alert("stage_pid");

    //Xrm.Page.ui.clearFormNotification("StageIDPIDCombinationIncorrect");

    var StageID = Xrm.Page.getAttribute('ftc_stageid').getValue();
    var PID = Xrm.Page.getAttribute('ftc_pid').getValue();

    //if (StageID == null) {
    //    Xrm.Page.getControl("ftc_stageid").clearNotification();
    //    Xrm.Page.getControl("ftc_stageid").setNotification("Enter Stage ID");
    //    return false;
    //}

    //if (PID == null) {
    //    Xrm.Page.getControl("ftc_pid").clearNotification();
    //    Xrm.Page.getControl("ftc_pid").setNotification("Enter PID");
    //    return false;
    //}


    if (StageID != null && PID != null) {

        //Xrm.Page.getControl("ftc_stageid").clearNotification();
        //Xrm.Page.getControl("ftc_pid").clearNotification();

        var query = "$select=ods_stageidentity,ods_casenumber,ods_name&$filter=ods_name eq " + "'" + StageID + "'";
        SDK.WEBAPI.retrieveMultipleRecords(true, "ods_stages", query, function (results) {
            if (results.value.length == 0) {
                //Xrm.Page.getControl("ftc_stageid").setNotification("Enter a valid Stage ID");
                alert("Enter a valid Stage ID");

                return false;
            } else if (results.value.length > 1) {
                //Xrm.Page.getControl("ftc_stageid").setNotification("More than one record exit in Stages Entity for the provided StageID. Please check with Admin");
                alert("More than one record exit in Stages Entity for the provided StageID. Please check with Admin");

                return false;
            } else {
                Xrm.Page.getControl("ftc_stageid").clearNotification();

                var object = new Array();
                object[0] = new Object();
                object[0].id = results.value[0].ods_stageid;
                object[0].name = results.value[0].ods_name;
                object[0].entityType = "ods_stage";

                Xrm.Page.getAttribute("ftc_ftcstageid").setValue(object);

                StageID_GUID = results.value[0].ods_stageid;

                if (ValidateStageIDAndPID()) {
                    Xrm.Page.getAttribute("ftc_casename").setValue(results.value[0].ods_stageidentity);
                    Xrm.Page.getAttribute("ftc_acscasenumber").setValue(results.value[0].ods_casenumber);
                }
                else {
                    // Xrm.Page.ui.setFormNotification("Please enter valid StageID and PID", "ERROR", "StageIDPIDCombinationIncorrect");
                    alert("Please enter valid StageID and PID", "ERROR", "StageIDPIDCombinationIncorrect");
                    Xrm.Page.getAttribute("ftc_casename").setValue(null);
                    Xrm.Page.getAttribute("ftc_acscasenumber").setValue(null);
                }
            }

        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    }

}




///////////////////////////

function ValidateStageIDAndPID() {
    var PID = Xrm.Page.getAttribute('ftc_pid').getValue();
    var StageID_GUID = getStageGuid();
    var isValidCombination = false;

    var query = "$select=_ods_person_value,_ods_stage_value&$expand=ods_person($select=ods_pidno)&$filter=_ods_stage_value eq " + replaceBracketsInGuid(StageID_GUID) + "";
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "ods_stagepersonlinks", query, function (results) {
        for (var i = 0; i < results.value.length; i++) {
            if (results.value[i]["ods_person"]["ods_pidno"] == PID) {
                isValidCombination = true;
            }
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    return isValidCombination;

}








///////////
function getStageGuid() {
    var stage_guid;
    var stageId = Xrm.Page.getAttribute('ftc_stageid').getValue();
    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Page.context.getClientUrl() + "/api/data/v9.1/ods_stages?$select=ods_name,ods_stageid&$filter=ods_name eq '" + stageId + "'", false);
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            req.onreadystatechange = null;
            if (this.status === 200) {
                var results = JSON.parse(this.response);
                for (var i = 0; i < results.value.length; i++) {
                    var ods_name = results.value[i]["ods_name"];
                    stage_guid = results.value[i]["ods_stageid"];
                }
            } else {
                Xrm.Utility.alertDialog(this.statusText);
            }
        }
    };
    req.send();

    return stage_guid
}





/////////

//onSave
function scheduleHistory() {
    // Xrm.Page.getAttribute("ftc_sch_dateconferenceassigned").setValue(GetCurrentDate());  ftc_schedulerdateofrequestforreschedule
    var scheduleFlag = Xrm.Page.getAttribute("ftc_scheduletimesflag").getValue();
    var rescheduleOption = Xrm.Page.getAttribute("ftc_sch_reschedule").getValue();
    if (rescheduleOption == false && scheduleFlag == null) {
        Xrm.Page.getAttribute("ftc_scheduledate").setValue(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue());
        Xrm.Page.getAttribute("ftc_dateofschedule").setValue(GetCurrentDate());
    }
    else if (rescheduleOption == true && scheduleFlag == null) {
        Xrm.Page.getAttribute("ftc_scheduletimesflag").setValue(1);
        Xrm.Page.getAttribute("ftc_schedulerconferencerescheduleddate").setValue(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue());
        Xrm.Page.getAttribute("ftc_schedulerdateofrequestforreschedule").setValue(GetCurrentDate());
    }
    else if (rescheduleOption == true && scheduleFlag == 1) {
        Xrm.Page.getAttribute("ftc_scheduletimesflag").setValue(2);
        Xrm.Page.getAttribute("ftc_schedulerconferencerescheduleddate2nd").setValue(Xrm.Page.getAttribute("ftc_sch_dateconfexpectedtoheld").getValue());
        Xrm.Page.getAttribute("ftc_schedulerdateofrequestforreschedule2nd").setValue(GetCurrentDate());
    }

}