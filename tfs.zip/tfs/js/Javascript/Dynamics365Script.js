DOB = window.DOB || {};
DOB.Dynamics365 = function () {
    var getExecutionContext = function (context) {
        if (!window.executionContext)
            window.executionContext = context.getFormContext();
    }

    var highlightChangesetFields = function (changesetRecords) {
        if (isUCI()) {
            setTimeout(highlight, 10000);
        }
        else {
            highlight();
        }

        function highlight() {
            if (changesetRecords) {
                if (changesetRecords.length > 0) {
                    for (var i = 0; i < changesetRecords.length; i++) {
                        var attributename = changesetRecords[i].dobnyc_fieldschemaname;
                        if (attributename != undefined) {
                            if (isUCI()) {
                                $("[data-id*='" + attributename + "']", parent.document).css("background-color", "red");
                            }
                            else {
                                for (var j = 0; j <= 5; j++) {
                                    var newAttributename = "";

                                    if (j > 0) newAttributename = attributename + j;
                                    else newAttributename = attributename;

                                    if (parent.document.getElementById(newAttributename) != undefined) {
                                        parent.document.getElementById(newAttributename).style.color = "red";
                                        parent.document.getElementById(newAttributename).style.backgroundColor = "red";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    var fetch = function (entity, fetchXML) {
        var result = null;

        var req = new XMLHttpRequest();
        req.open(
            "GET",
            Xrm.Utility.getGlobalContext().getClientUrl() +
            "/api/data/v9.0/" + entity + "?fetchXml=" +
            encodeURIComponent(fetchXML),
            false
        );
        req.setRequestHeader("Prefer", 'odata.include-annotations="*"');
        req.onreadystatechange = function () {
            if (this.readyState === 4) {
                req.onreadystatechange = null;
                if (this.status === 200) {
                    var resp = JSON.parse(this.response);
                    result = resp.value;
                }
            }
        };
        req.send();

        return result;
    }

    var isUCI = function () {
        return Xrm.Internal.isUci()
    }

    return {
        GetExecutionContext: getExecutionContext,
        HighlightChangesetFields: highlightChangesetFields,
        Fetch: fetch
    };
}();