﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_ElavatorViolationNumberMethods
    {
        StringBuilder crmTrace = new StringBuilder();

        //public ValidateElevatorDOBViolationNumberResponse ValidateElevatorDOBViolationNumber(ValidateElevatorDOBViolationNumberRequest request)
        //{
        //    ValidateElevatorDOBViolationNumberResponse response = null;
        //    string bisResponseString = string.Empty;
        //    try
        //    {
        //        crmTrace.AppendLine("Validate Violation Number - Start");
        //        string requestString = SerializeObject(request);
        //        StringBuilder requestStringBuilder = new StringBuilder();
        //        requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
        //        bisResponseString = GetBisResponse(request, requestString,crmTrace);

        //        response = DeSerializeXML(bisResponseString, response);

        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "ValidateElevatorDOBViolationNumber", crmTrace.ToString(), "  Trace log", request.UserID, "UserBrowserInfo");
        //        DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "ValidateElevatorDOBViolationNumber", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_ValidateElavatorViolationNumbere Class - ValidateElevatorDOBViolationNumber Method Exceptions", "browserinfo");
        //        return response;
        //        //throw ex;

        //    }
        //    return response;
        //}

        public T2 AllElevatorDOBViolationMethods<T1,T2>(T1 request, T2 response,string JobFilingNumber,string SourceChannel,string UserID,string methodName)
        {
            
            string bisResponseString = string.Empty;
            try
            {
                crmTrace.AppendLine("Validate Violation Number - Start");
                string requestString = SerializeObject(request);
                StringBuilder requestStringBuilder = new StringBuilder();
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
               // string requestString = "<CRMI_0VI_PC><PC_DATA><PC_CRM_DOB_VIOL_NUMBER_FULL>021518E1234H123456</PC_CRM_DOB_VIOL_NUMBER_FULL><PC_CRM_DOB_VIOL_SEQ_NUMBER>123456</PC_CRM_DOB_VIOL_SEQ_NUMBER><PC_CRM_CEASE_USE>Y</PC_CRM_CEASE_USE><PC_CRM_VIOLATION_TYPE>ELEVATOR</PC_CRM_VIOLATION_TYPE><PC_CRM_VIOL_ISSUE_DATE>2018-03-16</PC_CRM_VIOL_ISSUE_DATE><PC_CRM_BADGE_NUMBER>1234</PC_CRM_BADGE_NUMBER><PC_CUSTOM_PC_INTERFACE_ID>CRMI_0VI</PC_CUSTOM_PC_INTERFACE_ID></PC_DATA></CRMI_0VI_PC>";
                bisResponseString = GetBisResponse(request, requestString, crmTrace);

                response = DeSerializeXML(bisResponseString, response);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingNumber, SourceChannel, methodName, crmTrace.ToString(), "  Trace log", UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(UserID, SourceChannel, methodName, ex.Message, DOB.Logging.LogLevelL4N.ERROR, UserID, "Exception Details", "ExternalSystem_ValidateElavatorViolationNumbere Class - AllElevatorDOBViolationMethods Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
            return response;
        }

        public static string GetBisResponse<T>(T request, string inputXML,StringBuilder crmTrace)
        {
            try
            {
                //string requestBuilder = MessageStrings.MXBI_CR6.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType).Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count);
                crmTrace.AppendLine("GetExternalSystemResponse Started!");

                ServiceSoapClient webClient = new ServiceSoapClient();
                string bisResponseString = webClient.CALLBROKERXML(inputXML);
                crmTrace.AppendLine("GetExternalSystemResponse Ended!");
                return bisResponseString;
            }
            catch (SoapException ex)
            {
                throw ex;
            }

        }


        public static string SerializeObject<T>(T request)
        {
            string inputXML = string.Empty;
            Console.WriteLine("Writing With XmlTextWriter");
            try
            {
                //XmlSerializer serializer = new XmlSerializer(typeof(PC_DATA));
                //using (MemoryStream memStm = new MemoryStream())
                //{
                //    serializer.Serialize(memStm, request);
                //    memStm.Position = 0;
                //    inputXML = new StreamReader(memStm).ReadToEnd();
                //}
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(typeof(T));
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, request, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception ex)
            {
            }
            return inputXML;
        }

        public static T DeSerializeXML<T>(string xml,T response)
        {
            StringReader strReader = null;
            XmlSerializer serializer = null;
            XmlTextReader xmlReader = null;
           
            try
            {
                strReader = new StringReader(xml);
                serializer = new XmlSerializer(typeof(T));
                xmlReader = new XmlTextReader(strReader);
                response = (T)serializer.Deserialize(xmlReader);
            }
            catch (Exception exp)
            {
                throw new Exception("Error in processing the xml. Detail exception :" + exp.Message);
            }
            finally
            {
                if (xmlReader != null)
                {
                    xmlReader.Close();
                }
                if (strReader != null)
                {
                    strReader.Close();
                }
            }
            return response;
        }
    }
}
