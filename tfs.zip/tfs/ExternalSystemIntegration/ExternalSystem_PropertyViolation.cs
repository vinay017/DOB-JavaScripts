﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;


namespace ExternalSystemIntegration
{
    public class ExternalSystem_PropertyViolation
    {
        StringBuilder Trace = new StringBuilder();

        public PropertyViolationResponse GetPropertyViolation(PropertyViolationRequest request)
        {
            
            PropertyViolationResponse response = new PropertyViolationResponse();
            String PRM_DOBNOW_JOBNUMBER;
            String PRM_DOBNOW_FILINGNUMBER;

            try
            {
                Trace.AppendLine("GetPropertyViolation Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.Bin != null)
                {
                    PRM_DOBNOW_JOBNUMBER = !string.IsNullOrEmpty(request.JobNumber) ? request.JobNumber : string.Empty;
                    PRM_DOBNOW_FILINGNUMBER = !string.IsNullOrEmpty(request.FilingNumber) ? request.FilingNumber : string.Empty;

                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_BIS_CRM_PC.Replace(RequestAttributes.PRM_BUILDNYC_BIN, request.Bin);
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_DOBNOW_JOBNUMBER, PRM_DOBNOW_JOBNUMBER);
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_DOBNOW_FILINGNUMBER, PRM_DOBNOW_FILINGNUMBER);
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                    
                }

                Trace.AppendLine("GetPropertyViolation End!");
                return response;

            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetPropertyViolation", Trace.ToString(), " Property Violation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetPropertyViolation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_PropertyViolation Class - GetPropertyViolation Method Exceptions", "browserinfo");
                return response;
                //throw ex; ;

            }

        }


        internal PropertyViolationResponse GetExternalSystemResponse(string requestObj)
        {
            PropertyViolationResponse response = new PropertyViolationResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj); // SampleData.AddressValidation; //string.Empty;

                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.ErrorMsg);
                response.BISViolation = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.BIS_WORK_WITHOUT_PERMIT);
                response.ECBViolation = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.ECB_WORK_WITHOUT_PERMIT);
                response.OpenA1 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.OPEN_A1);
                response.OpenNB = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.OPEN_NB);
                response.VacantLand = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_VACANT_LAND);
                response.Latitude = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.GO_LATITUDE);
                response.Longitude = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.GO_LONGITUDE);
                response.PSpecialArea1 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_SPECIAL_AREA_1);
                response.PSpecialArea2 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_SPECIAL_AREA_2);
                response.PSpecialArea3 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_SPECIAL_AREA_3);
                response.PSpecialArea4 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_SPECIAL_AREA_4);
                response.PSpecialArea5 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_SPECIAL_AREA_5);
                response.TransitAuthority = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_TA);
                response.SpecialDistrict1 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_FIN_ZONE_SPEC_DIST1);
                response.SpecialDistrict2 = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_FIN_ZONE_SPEC_DIST2);
                response.LoftFlag = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.P_LOFT_FLAG);
                response.Zipcode = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.VlNumZip);
                response.CommunityBoard = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.VlCommBd);
                response.FilingOnHold = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.FILING_HOLD);
                response.ApprovalOnHold = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.APPROVAL_HOLD);
                response.PermitOnHold = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.PERMIT_HOLD);
                response.SignOffOnHold = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.SIGNOFF_HOLD);
                response.WithdrawalOnHold = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.WITHDRAWAL_HOLD);
                response.ObsoleteFlag = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.OBSOLETE_FLAG);
                response.LittleE = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.LittleE);
                response.LandmarkStatus = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.LandmarkStatus);
                response.NumberOfStories = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberOfStories);
                response.StopWork = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberStopWork);
                response.VacateFlag = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberVacateFlag);
                response.Class1Violation = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberClass1Violation);
                response.PadlockFlag= Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.PadlockFlag);
                response.BuyoutFlag = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.BuyoutFlag);
                response.SandyDemoFlag = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberSandyDemoFlag);
                response.CompromisedStructure = Common.GetAttributeValueFromResponse(responseString, PropertyViolationResponseAttributesTags.NumberCompromisedStructure);

                if (response.LittleE != "N/A")
                {
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(responseString);
                    XmlElement root = xDoc.DocumentElement;
                    XmlNodeList crmTagList = root.GetElementsByTagName("CRM");
                    for (int i = 0; i < crmTagList.Count; i++)
                    {
                        LittleEDetails littleEDetailList = new LittleEDetails();
                        string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                        littleEDetailList.LittleEFlag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyViolationResponseAttributesTags.LittleEflag);
                        littleEDetailList.LittleEPartialFlag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyViolationResponseAttributesTags.LittleEPartialFlag);
                        littleEDetailList.LittleEEffectiveDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyViolationResponseAttributesTags.LittleEEffectiveDate);
                        littleEDetailList.LittleESatisfiedDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyViolationResponseAttributesTags.LittleESatisfiedDate);
                        response.littleEDetailsList.Add(littleEDetailList);
                    }
                }
                Trace.AppendLine("Response FilingOnHold: " + response.FilingOnHold.ToString());

                DOBLogger.WriteCommunicationLog("GetPropertyViolation Responce log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " Property Profile trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_PropertyViolation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
        }



    }
}
