﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.CommonHandler
{
    public class SerializeHandler
    {
        public static string GetBisResponse<T>(T request, string inputXML, StringBuilder crmTrace)
        {
            try
            {
                //string requestBuilder = MessageStrings.MXBI_CR6.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType).Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count);
                crmTrace.AppendLine("GetExternalSystemResponse Started!");

                ServiceSoapClient webClient = new ServiceSoapClient();
                string bisResponseString = webClient.CALLBROKERXML(inputXML);
                crmTrace.AppendLine("GetExternalSystemResponse Ended!");
                return bisResponseString;
            }
            catch (SoapException ex)
            {
                throw ex;
            }

        }


        public static string SerializeObject<T>(T request)
        {
            string inputXML = string.Empty;
            Console.WriteLine("Writing With XmlTextWriter");
            try
            {
                //XmlSerializer serializer = new XmlSerializer(typeof(PC_DATA));
                //using (MemoryStream memStm = new MemoryStream())
                //{
                //    serializer.Serialize(memStm, request);
                //    memStm.Position = 0;
                //    inputXML = new StreamReader(memStm).ReadToEnd();
                //}
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(typeof(T));
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, request, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception ex)
            {
            }
            return inputXML;
        }

        public static T DeSerializeXML<T>(string xml, T response)
        {
            StringReader strReader = null;
            XmlSerializer serializer = null;
            XmlTextReader xmlReader = null;

            try
            {
                strReader = new StringReader(xml);
                serializer = new XmlSerializer(typeof(T));
                xmlReader = new XmlTextReader(strReader);
                response = (T)serializer.Deserialize(xmlReader);
            }
            catch (Exception exp)
            {
                throw new Exception("Error in processing the xml. Detail exception :" + exp.Message);
            }
            finally
            {
                if (xmlReader != null)
                {
                    xmlReader.Close();
                }
                if (strReader != null)
                {
                    strReader.Close();
                }
            }
            return response;
        }
    }
}
