﻿using DOB.Logging;
using ExternalSystemIntegration.Integration_BFIRST;
using ExternalSystemIntegration.Objects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetBISTableDetails
    {
        StringBuilder Trace = new StringBuilder();

        public BIS_TableDetailsResponse GetBISTableDetails_Master(BIS_TableDetailsRequest request)
        {
            BIS_TableDetailsResponse response = new BIS_TableDetailsResponse();
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("GetBISTableDetails Started!");
                ExternalSystem_GetBISTableDetails bistable = new ExternalSystem_GetBISTableDetails();
                BIS_TableDetailsResponse tempresponse = new BIS_TableDetailsResponse();
                tempresponse = bistable.GetBISTableDetails(request);
                response = tempresponse;

                #region Loop all counts
                if (!string.IsNullOrEmpty(response.TotalRecsTable))
                {
                    var recordCount = Convert.ToDecimal(response.TotalRecsTable);
                    var iterationcounts = Convert.ToInt16(recordCount / 50);
                    if (iterationcounts > 0)
                    {
                        for (int j = 1; j <= iterationcounts; j++)
                        {
                            string requestAllCount = (50 + j).ToString().PadLeft(4, '0');
                            request.AllCount = requestAllCount;
                            ExternalSystem_GetBISTableDetails bistable2 = new ExternalSystem_GetBISTableDetails();
                            BIS_TableDetailsResponse tempresponse2 = new BIS_TableDetailsResponse();
                            tempresponse2 = bistable.GetBISTableDetails(request);
                            foreach (string t in tempresponse2.BisTableDefinitions)
                            {
                                response.BisTableDefinitions.Add(t);

                            }
                        }
                    }
                }
                #endregion

                Trace.AppendLine("GetBISTableDetails End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBISTableDetails_Master", Trace.ToString(), " GetBISTableDetails_Master trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBISTableDetails_Master", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetBISTableDetails Class - GetBISTableDetails_Master Method Exceptions", "browserinfo");
                return response;

            }
        }

        public BIS_TableDetailsResponse GetBISTableDetails(BIS_TableDetailsRequest request)
        {
            BIS_TableDetailsResponse response = new BIS_TableDetailsResponse();
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("GetBISTableDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && !string.IsNullOrEmpty( request.AllCount) && !string.IsNullOrEmpty(request.AllTblType))
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CRM_017_TBL_DTS_PC.Replace(RequestAttributes.PRM_Count, request.AllCount).Replace(RequestAttributes.PRM_TableType, request.AllTblType);

                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetBISTableDetails End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBISTableDetails", Trace.ToString(), " GetBISTableDetails trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBISTableDetails", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetBISTableDetails Class - GetBISTableDetails Method Exceptions", "browserinfo");
                return response;

            }
        }

        internal BIS_TableDetailsResponse GetExternalSystemResponse(string requestObj)
        {
            BIS_TableDetailsResponse response = new BIS_TableDetailsResponse();
            BaseRequest Brequest = new BaseRequest();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);
                #region Read attributes from XML Response
                response.MF_RETURN_CODE = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.MF_RETURN_CODE);
                response.MF_OVERALL_TEXT = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.MF_OVERALL_TEXT);
                response.Datu = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.Datu);
                response.Pgm = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.Pgm);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.GlRecCountN);
                response.TotalRecsTable = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.TotalRecsTable);
                response.MF_OVERALL_TEXT = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.MF_OVERALL_TEXT);
                response.MF_OVERALL_TEXT = Common.GetAttributeValueFromResponse(responseString, BISTableDetailsResponseAttributesTags.MF_OVERALL_TEXT);

                #region GetListValues
                List<string> tempList = new List<string>();
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList BISTBL2List = root.GetElementsByTagName("BISTBL2");
                foreach (XmlNode node in BISTBL2List)
                {
                    string innerNodes = node.InnerXml;
                    List<string> tempObj = new List<string>();
                    tempList.Add( Common.GetAttributeValueFromResponse(innerNodes, BISTableDetailsResponseAttributesTags.BisTableCode) + " - " + Common.GetAttributeValueFromResponse(innerNodes, BISTableDetailsResponseAttributesTags.BisTableDescription));
                    
                }

                response.BisTableDefinitions = tempList;
                #endregion

                #endregion
                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetBISTableDetails trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_GetBISTableDetails Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;

            }
        }
    }
}
