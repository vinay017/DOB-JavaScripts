﻿using System;
using System.Text;
using System.Xml;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_PensBisJobHandler
    {
        StringBuilder Trace = new StringBuilder();
        public PensBisJobInformationResponse GetPensBisJobInformation(PensBisJobInformationRequest request)
        {
            PensBisJobInformationResponse response = new PensBisJobInformationResponse();
            try
            {
                Trace.AppendLine("GetPensBisJobInformation start");
                string requestBuilder = string.Empty;
                if (request != null)
                {
                    Trace.AppendLine("GetPensBisJobInformation : RequestBuilder Started!");
                    if (!string.IsNullOrEmpty(request.DocumentNumber) && !string.IsNullOrEmpty(request.BisJobNumber))
                        requestBuilder = MessageStrings.MXBI_C25.Replace(RequestAttributes.PRM_Pens_DocNumber, request.DocumentNumber).Replace(RequestAttributes.PRM_Pens_JobNumber, request.BisJobNumber);
                    else
                    {
                        response.ReturnError = "Please provide document and job number";
                        return response;
                    }
                    Trace.AppendLine("GetPensBisJobInformation : RequestBuilder Ended!");
                    Trace.AppendLine("GetPensBisJobInformation :  RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetPensBisJobInformation end");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetPensBisJobInformation", Trace.ToString(), "GetPensBisJobInformation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetPensBisJobInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_PensBisJobHandler Class - GetPensBisJobInformation Method Exceptions", "browserinfo");
                return response;
            }


        }

        internal PensBisJobInformationResponse GetExternalSystemResponse(string requestObj)
        {
            PensBisJobInformationResponse response = new PensBisJobInformationResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("ExternalSystem_PensBisJobHandler : GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_RETURN_CODE);
                response.OverallText = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_OVERALL_TEXT);
                response.BisJobNumber = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_JOB_NUMBER);
                response.DocumentNumber = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_JOB_DOCUMENT_NUMBER);
                response.JobAptCondoNumber = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_APT_CONDO_NUMBER);
                response.JobBin = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_BIN_NUMBER);
                response.JobBlock = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_BLOCK);
                response.JobBorough = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_BORO);
                response.JobHouseNumber = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_HOUSE_NUMBER);
                response.JobLot = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_LOT);
                response.JobStreetName = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_STREET_NAME);
                response.JobType = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_JOB_TYPE);
                response.JobZip = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_ZIP5);
                response.ApplicantEmail = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_APP_EMAIL);
                response.ApplicantFirstName = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_APP_FIRST_NAME);
                response.ApplicantLastName = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_APP_LAST_NAME);
                response.CommunityBoardNumber = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.VlCommBd);
                response.PlanExaminerBisId = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_J_PLAN_ASSIGNEE_ID);
                response.AppointmentDurationFlag = Common.GetAttributeValueFromResponse(responseString, PensJobResponseAttributesTags.MF_PLAN_APPOINTMENT_FLAG);

                Trace.AppendLine("ExternalSystem_PensBisJobHandler : GetExternalSystemResponse End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetPensBisJobInformation : GetExternalSystemResponse", Trace.ToString(), "GetPensBisJobInformation trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetPensBisJobInformation : GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_PensBisJobHandler Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
            }
        }
    }
}
