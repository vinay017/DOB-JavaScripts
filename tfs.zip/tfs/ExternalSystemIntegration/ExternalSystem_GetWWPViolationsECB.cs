﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Text;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using ExternalSystemIntegration.Objects;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetWWPViolationsECB
    {
        StringBuilder Trace = new StringBuilder();


        public WWPViolationsECBResponse GetECBViolationDetails_Master(WWPViolationsRequest request)
        {
            WWPViolationsECBResponse response = new WWPViolationsECBResponse();
            try
            {
                Trace.AppendLine("GetECBViolationDetails_Master Started!");
                request.AllCount = "0001";
                request.BoroughKey = "I";
                response = GetECBViolationDetails(request);
                #region Loop all pages records
                if (!string.IsNullOrEmpty(response.GlRecCountN))
                {
                    var noofAdditionalPages = Convert.ToDecimal(response.GlRecCountN);
                    var iterationcounts = Convert.ToInt16(response.ECBViolationsList.Count / 25); // Length of array = 25
                    if (iterationcounts > 0 && noofAdditionalPages > 0)
                    {
                        for (int k = 1; k <= noofAdditionalPages; k++)
                        {
                            string requestAllCount = ((25 * k) + 1).ToString().PadLeft(4, '0');
                            request.AllCount = requestAllCount;
                            WWPViolationsECBResponse reponse2 = new WWPViolationsECBResponse();
                            reponse2 = GetECBViolationDetails(request);
                            foreach (ECBViolationsWWP t in reponse2.ECBViolationsList)
                            {
                                response.ECBViolationsList.Add(t);

                            }
                        }

                    }
                }
                #endregion
                Trace.AppendLine("GetLicenseDetails End!");
                return response;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetECBViolationDetails_Master-External system", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetECBViolationDetails_Master-External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
            }

            return response;
        }

        public WWPViolationsECBResponse GetECBViolationDetails(WWPViolationsRequest request)
        {
            WWPViolationsECBResponse response = new WWPViolationsECBResponse();

            try
            {
                Trace.AppendLine("GetECBViolationDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.AllBin != null && request.AllCount != null && request.BoroughKey != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_C29.Replace(RequestAttributes.PRM_BUILDNYC_BIN, request.AllBin).Replace(RequestAttributes.PRM_ALLCOUNT, request.AllCount).Replace(RequestAttributes.PRM_BOROUGHKEY, request.BoroughKey);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder, request);
                    
                }
                else
                {
                    response.ReturnError = "Request is not proper. Please verify.";
                    return response;
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetECBViolationDetails-External system", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetECBViolationDetails-External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
            }

            return response;
        }

        internal WWPViolationsECBResponse GetExternalSystemResponse(string requestBuilder, WWPViolationsRequest request)
        {
            WWPViolationsECBResponse response = new WWPViolationsECBResponse();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");

                #region Direct tags
                response.MF_RETURN_CODE = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.MF_RETURN_CODE);
                response.MF_OVERALL_TEXT = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.MF_OVERALL_TEXT);
                response.MF_MORE_ERRORS = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.MF_MORE_ERRORS);
                response.MF_ERROR_TABLE = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.MF_ERROR_TABLE);
                response.Pgm = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.Pgm);
                response.VlNumbHous = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.VlNumbHous);
                response.NmStrt = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.NmStrt);
                response.NmBoro = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.NmBoro);
                response.VlBin = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.VlBin);
                response.VlNumbZip = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.VlNumbZip);
                response.VlTaxBlock = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.VlTaxBlock);
                response.VlTaxLot = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.VlTaxLot);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.GlRecCountN);
                #endregion

                #region sub tags

                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("ECB");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    ECBViolationsWWP detailsList = new ECBViolationsWWP();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.ExtActiveFlag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtActiveFlag);
                    detailsList.ExtEcbViolNo = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtEcbViolNo);
                    detailsList.ExtRespName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtRespName);
                    detailsList.ExtDobViolNo = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtDobViolNo);
                    detailsList.ExtViolType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolType);
                    detailsList.ExtStatus = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtStatus);
                    detailsList.ExtViolCode1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode1);
                    detailsList.ExtViolCode2 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode2);
                    detailsList.ExtViolCode3 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode3);
                    detailsList.ExtViolCode4 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode4);
                    detailsList.ExtViolCode5 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode5);
                    detailsList.ExtViolCode6 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode6);
                    detailsList.ExtViolCode7 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode7);
                    detailsList.ExtViolCode8 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode8);
                    detailsList.ExtTaxLienExp = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtTaxLienExp);
                    detailsList.ExtViolCode1Exp = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationECBResponseAttributesTags.ExtViolCode1Exp);

                    response.ECBViolationsList.Add(detailsList);
                }
                #endregion

                

            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetExternalSystemResponse- External system", Trace.ToString(), " Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetExternalSystemResponse- External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetWWPViolationsECB Class - GetExternalSystemResponse Method Exceptions", "browserinfo");

            }

            return response;
        }

        internal List<ECBViolationsWWP> GetECBViolationsWWPList(string requestBuilder, WWPViolationsRequest request)
        {
            List<ECBViolationsWWP> response = new List<ECBViolationsWWP>();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");
                
                #region sub tags

                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("ECB");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    ECBViolationsWWP detailsList = new ECBViolationsWWP();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.ExtActiveFlag = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtActiveFlag);
                    detailsList.ExtEcbViolNo = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtEcbViolNo);
                    detailsList.ExtRespName = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtRespName);
                    detailsList.ExtDobViolNo = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtDobViolNo);
                    detailsList.ExtViolType = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolType);
                    detailsList.ExtStatus = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtStatus);
                    detailsList.ExtViolCode1 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode1);
                    detailsList.ExtViolCode2 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode2);
                    detailsList.ExtViolCode3 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode3);
                    detailsList.ExtViolCode4 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode4);
                    detailsList.ExtViolCode5 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode5);
                    detailsList.ExtViolCode6 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode6);
                    detailsList.ExtViolCode7 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode7);
                    detailsList.ExtViolCode8 = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode8);
                    detailsList.ExtTaxLienExp = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtTaxLienExp);
                    detailsList.ExtViolCode1Exp = Common.GetAttributeValueFromResponse(responseString, WWPViolationECBResponseAttributesTags.ExtViolCode1Exp);

                    response.Add(detailsList);
                }
                #endregion



            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetExternalSystemResponse- External system", Trace.ToString(), " Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetExternalSystemResponse- External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetWWPViolationsECB Class - GetExternalSystemResponse Method Exceptions", "browserinfo");

            }

            return response;
        }

    }
}
