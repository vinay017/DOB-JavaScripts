﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Text;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using ExternalSystemIntegration.Objects;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetWWPViolationsDOB
    {
        StringBuilder Trace = new StringBuilder();


        public WWPViolationsDOBResponse GetDOBViolationDetails_Master(WWPViolationsRequest request)
        {
            WWPViolationsDOBResponse response = new WWPViolationsDOBResponse();
            try
            {
                Trace.AppendLine("GetDOBViolationDetails_Master Started!");
                request.AllCount = "0001";
                request.BoroughKey = "I";
                response = GetDOBViolationDetails(request);
                #region Loop all pages records
                if (!string.IsNullOrEmpty(response.GlRecCountN))
                {
                    var noofAdditionalPages = Convert.ToDecimal(response.GlRecCountN);
                    var iterationcounts = Convert.ToInt16(response.DOBViolationsList.Count / 25); // Length of array = 25
                    if (iterationcounts > 0 && noofAdditionalPages > 0)
                    {
                        for (int k = 1; k <= noofAdditionalPages; k++)
                        {
                            string requestAllCount = ((25 * k) + 1).ToString().PadLeft(4, '0');
                            request.AllCount = requestAllCount;
                            WWPViolationsDOBResponse reponse2 = new WWPViolationsDOBResponse();
                            reponse2 = GetDOBViolationDetails(request);
                            foreach (DOBViolationsWWP t in reponse2.DOBViolationsList)
                            {
                                response.DOBViolationsList.Add(t);

                            }
                        }

                    }
                }
                #endregion
                Trace.AppendLine("GetLicenseDetails End!");
                return response;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetDOBViolationDetails_Master-External system", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetDOBViolationDetails_Master-External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
            }

            return response;
        }

        public WWPViolationsDOBResponse GetDOBViolationDetails(WWPViolationsRequest request)
        {
            WWPViolationsDOBResponse response = new WWPViolationsDOBResponse();

            try
            {
                Trace.AppendLine("GetDOBViolationDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.AllBin != null && request.AllCount != null && request.BoroughKey != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_C28.Replace(RequestAttributes.PRM_BUILDNYC_BIN, request.AllBin).Replace(RequestAttributes.PRM_ALLCOUNT, request.AllCount).Replace(RequestAttributes.PRM_BOROUGHKEY, request.BoroughKey);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder, request);

                }
                else
                {
                    response.ReturnError = "Request is not proper. Please verify.";
                    return response;
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetDOBViolationDetails-External system", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetDOBViolationDetails-External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
            }

            return response;
        }

        internal WWPViolationsDOBResponse GetExternalSystemResponse(string requestBuilder, WWPViolationsRequest request)
        {
            WWPViolationsDOBResponse response = new WWPViolationsDOBResponse();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");

                #region Direct tags
                response.MF_RETURN_CODE = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.MF_RETURN_CODE);
                response.MF_OVERALL_TEXT = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.MF_OVERALL_TEXT);
                response.MF_MORE_ERRORS = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.MF_MORE_ERRORS);
                response.MF_ERROR_TABLE = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.MF_ERROR_TABLE);
                response.Pgm = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.Pgm);
                response.VlNumbHous = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.VlNumbHous);
                response.NmStrt = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.NmStrt);
                response.NmBoro = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.NmBoro);
                response.VlBin = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.VlBin);
                response.VlNumbZip = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.VlNumbZip);
                response.VlTaxBlock = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.VlTaxBlock);
                response.VlTaxLot = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.VlTaxLot);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, WWPViolationDOBResponseAttributesTags.GlRecCountN);
                #endregion

                #region sub tags

                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("WWP");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    DOBViolationsWWP detailsList = new DOBViolationsWWP();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.ApplTransText = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.ApplTransText);
                    detailsList.ApplNumOcv3 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.ApplNumOcv3);
                    detailsList.ApplStatus = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.ApplStatus);
                    detailsList.ApplDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.ApplDate);
                    detailsList.OvDateTxt = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvDateTxt);
                    detailsList.OvDisDateN2k = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvDisDateN2k);
                    detailsList.OvBadgeTxt = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvBadgeTxt);
                    detailsList.OvDisBadge = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvDisBadge);
                    detailsList.OvAgncyTxt = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvAgncyTxt);
                    detailsList.OvDisAgncy = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OvDisAgncy);
                    detailsList.LnoTag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.LnoTag);
                    detailsList.LnoArea = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.LnoArea);
                    detailsList.Comment1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.Comment1);
                    detailsList.Comment2 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.Comment2);
                    detailsList.Isn = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.Isn);
                    detailsList.DrillType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.DrillType);
                    detailsList.OAModelExp = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.OAModelExp);
                    detailsList.ViDOBNOWIdV3 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, WWPViolationDOBResponseAttributesTags.ViDOBNOWIdV3);

                    response.DOBViolationsList.Add(detailsList);
                }
                #endregion



            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetExternalSystemResponse- External system", Trace.ToString(), " Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetExternalSystemResponse- External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetWWPViolationsDOB Class - GetExternalSystemResponse Method Exceptions", "browserinfo");

            }

            return response;
        }



    }
}
