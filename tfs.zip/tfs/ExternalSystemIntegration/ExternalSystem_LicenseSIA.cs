﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using DOB.Logging;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_LicenseSIA
    {
        StringBuilder Trace = new StringBuilder();

        public SIALicensingResponse GetLicenseInformationforSIA(SIALicensingRequest request)
        {
            SIALicensingResponse response = new SIALicensingResponse();
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("GetLicenseInformationforSIA Started!");
                string requestBuilder = string.Empty;
                if (request != null )
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CR7.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType).Replace(RequestAttributes.PRM_ALLISN, request.Allisn);

                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetLicenseInformationforSIA End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetLicenseInformationforSIA", Trace.ToString(), " LicenseValidation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetLicenseInformationforSIA", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseSIA Class - GetLicenseInformationforSIA Method Exceptions", "browserinfo");
                return response;
               
            }
            
        }

        internal SIALicensingResponse GetExternalSystemResponse(string requestObj)
        {
            SIALicensingResponse response = new SIALicensingResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);
                
                response.LicenseNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseNumber);
                response.LicenseType = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseType);
                response.Status = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Status);
                response.Statusdate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Statusdate);
                response.Transcode = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Transcode);
                response.DocketNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.DocketNumber);
                response.LicenseClass = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseClass);
                response.LicenseEntryDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseEntryDate);
                response.LicenseClassType = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseClassType);
                response.DocketNumber2 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.DocketNumber2);
                response.TransDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.TransDate);
                response.OperId = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.OperId);
                response.RenewDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.RenewDate);
                response.Expiredate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Expiredate);
                response.IssueDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.IssueDate);
                response.LicenseUse1 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseUse1);
                response.LicenseUse2 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.LicenseUse2);
                response.NoselfCert = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.NoselfCert);
                response.Exec298Flag = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Exec298Flag);
                response.Exec298Date = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Exec298Date);
                response.RsLtrFlag = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.RsLtrFlag);
                response.CityEmployee = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.CityEmployee);
                response.Respforboiler = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Respforboiler);
                response.GrandFather1 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.GrandFather1);
                response.Grandfather2 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Grandfather2);
                response.TestCementFlag = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.TestCementFlag);
                response.PERANumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.PERANumber);
                response.FirmNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.FirmNumber);
                response.FirmResponsibleRep = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.FirmResponsibleRep);
                response.Pin = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Pin);
                response.RegistrationFlag = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.RegistrationFlag);
                response.RegistrationDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.RegistrationDate);
                response.BlockFlag = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BlockFlag);
                response.BlockBeginDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BlockBeginDate);
                response.BlockEndDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BlockEndDate);
                response.BlockComment = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BlockComment);
                response.Journeymen = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Journeymen);
                response.Apprentices = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Apprentices);
                response.Helpers = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Helpers);
                response.Keytext = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Keytext);
                response.ApplSsn = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplSsn);
                response.ApplBirthDate = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplBirthDate);
                response.ApplLastName = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplLastName);
                response.ApplFirstName = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplFirstName);
                response.ApplInitial = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplInitial);
                response.ApplHouseNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplHouseNumber);
                response.ApplStreetName = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplStreetName);
                response.ApplCity = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplCity);
                response.ApplState = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplState);
                response.ApplZip = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplZip);
                response.ApplMobile = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplMobile);
                response.ApplPhone = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplPhone);
                response.ApplFax = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplFax);
                response.ApplEmail = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.ApplEmail);
                response.BusPhone = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusPhone);
                response.busFax = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.busFax);
                response.BusEmail = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusEmail);
                response.BusHouseNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusHouseNumber);
                response.BusStreetName = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusStreetName);
                response.BusAddrLine2 = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusAddrLine2);
                response.BusCity = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusCity);
                response.BusState = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusState);
                response.BusZip = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusZip);
                //response.BusName = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusName);

                response.BusName = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusName)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusName).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusName).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusName);
                response.BusEin = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusEin);
                response.BusFeeexempt = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusFeeexempt);
                response.BusExpid = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusExpid);
                response.BusText = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.BusText);
                response.Aff1Of1Name = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Aff1Of1Name);
                response.Aff1Of1Title = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Aff1Of1Title);
                response.Aff1Of1License = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Aff1Of1License);
                response.Aff1Of1Type = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Aff1Of1Type);
                response.Aff1Of1Pct = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.Aff1Of1Pct);
                response.AgencyNumber = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.AgencyNumber);
                response.AgencyISN = Common.GetAttributeValueFromResponse(responseString, LicenseInformationSIAResponseTags.AgencyISN);

                #region GetListValues
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("CRM");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    DirectorInformationDetails directorDetailsList = new DirectorInformationDetails();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;
                    if (!string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorLicenseNumber)))
                    {
                        directorDetailsList.DirectoLicenseNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorLicenseNumber);
                        directorDetailsList.DirectorLicensetype = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorLicensetype);
                        directorDetailsList.DirectorFirstName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorFirstName);
                        directorDetailsList.DirectorLastName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorLastName);
                        directorDetailsList.DirectorPCT = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorPCT);
                        directorDetailsList.DirectorTitle = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, LicenseInformationSIAResponseTags.DirectorTitle);
                    }

                    response.directorInfo.Add(directorDetailsList);
                }
                #endregion EndGetListValues

                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " LicenseValidation trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_LicenseSIA Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
                
            }

        }
    }
}
