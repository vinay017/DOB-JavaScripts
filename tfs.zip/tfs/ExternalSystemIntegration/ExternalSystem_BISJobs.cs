﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_BISJobs
    {
        StringBuilder Trace = new StringBuilder();
        public BISJobResponse GetBISJobInformation(BISJobRequest request)
        {
            BISJobResponse response = new BISJobResponse();

            try
            {
                Trace.AppendLine("GetBISJobInformation Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.BISJobNumber != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CR2.Replace(RequestAttributes.PRM_BUILDNYC_BISJOBNUMBER, request.BISJobNumber).Replace(RequestAttributes.PRM_BUILDNYC_BISDOCNumber, request.BISDocNumber);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("GetBISJobInformation Ended!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBISJobInformation", Trace.ToString(), " GetBISJobInformation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBISJobInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_BISJobs Class - GetBISJobInformation Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }

        }

        internal BISJobResponse GetExternalSystemResponse(string requestObj)
        {
            BISJobResponse response = new BISJobResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj); // SampleData.AddressValidation; //string.Empty;

                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.ErrorCode);
                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.ErrorMsg);
                response.BIN = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.VlBin);
                response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.VlNumHous);
                response.StreetName = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.NmStrt);
                response.Borough = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.NmBoro);
                response.J_JOB_IS_OPEN = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_JOB_IS_OPEN);
                response.J_JOB_TYPE = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_JOB_TYPE);
                response.J_BIN_NUMBER = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_BIN_NUMBER);
                response.J_JOB_NUMBER = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_JOB_NUMBER);
                response.IsTCOIssued = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.IsTCOIssued);
                response.IsTCOOpen = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.IsTCOOpen);
                response.IsTCOWithdrawn = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.IsTCOWithdrawn);
                response.J_HOLD_FLAG = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_HOLD_FLAG);
                response.J_JOB_SPECIAL_ACTION_STATUS = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_JOB_SPECIAL_ACTION_STATUS);
                response.J_JOB_STATUS = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_JOB_STATUS);
                
                //response.J_JOB_IS_OPEN = Common.GetAttributeValueFromResponse(responseString, BISJobResponseAttributesTags.J_BIN_NUMBER);
                Trace.AppendLine("Response BIN:" + response.BIN.ToString());

                DOBLogger.WriteCommunicationLog("BISJobResponse log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                Trace.AppendLine("GetExternalSystemResponse Ended!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetBISJobInformation trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_BISJobs Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
        }



    }
}
