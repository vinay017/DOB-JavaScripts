﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class PropertyViolationRequest : BaseRequest
    {

        public string Bin { get; set; }

        public string JobNumber { get; set; }

        public string FilingNumber { get; set; }

    }
}
