﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_0VI_PC")]
    public class ValidateElevatorDOBViolationNumberRequest: BaseRequest
    {
        /*
         <CRMI_0VI_PC>
            <PC_DATA>
                <PC_CRM_DOB_VIOL_NUMBER_FULL>021518E1234H123456</PC_CRM_DOB_VIOL_NUMBER_FULL>
                <PC_CRM_DOB_VIOL_SEQ_NUMBER>123456</PC_CRM_DOB_VIOL_SEQ_NUMBER>
                <PC_CRM_CEASE_USE>Y</PC_CRM_CEASE_USE>
                <PC_CRM_VIOLATION_TYPE>ELEVATOR</PC_CRM_VIOLATION_TYPE>
                <PC_CRM_VIOL_ISSUE_DATE>2018-03-16</PC_CRM_VIOL_ISSUE_DATE>
                <PC_CRM_BADGE_NUMBER>1234</PC_CRM_BADGE_NUMBER>
                <PC_CUSTOM_PC_INTERFACE_ID>CRMI_0VI</PC_CUSTOM_PC_INTERFACE_ID>
            </PC_DATA>
        </CRMI_0VI_PC>
                 */     
       
            public ValidateElevatorDOBViolationNumberRequestChild PC_DATA = new ValidateElevatorDOBViolationNumberRequestChild();
        

      
    }


    public class ValidateElevatorDOBViolationNumberRequestChild : BaseRequest
    {



        private string eventDateTime;

       

        [XmlElement]
        public string PC_CRM_DOB_VIOL_NUMBER_FULL { get; set; }
        //public string RecordId { get { return this.recordId; } set { this.recordId = string.Format("{0:00000000000000}", Convert.ToInt32(value)); } }
        [XmlElement]
        public string PC_CRM_DOB_VIOL_SEQ_NUMBER { get; set; }
        [XmlElement]
        public string PC_CRM_CEASE_USE { get; set; }
        [XmlElement]
        public string PC_CRM_VIOL_ISSUE_DATE { get { return this.eventDateTime; } set { CultureInfo ci = CultureInfo.InvariantCulture; this.eventDateTime = Convert.ToDateTime(value).ToString("yyyy-MM-dd", ci); } }
        [XmlElement]
        public string PC_CRM_VIOLATION_TYPE { get; set; }
        [XmlElement]
        public string PC_CRM_BADGE_NUMBER { get; set; }
        [XmlElement]
        public string PC_CUSTOM_PC_INTERFACE_ID = "CRMI_0VI";


    }

  
}
