﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BISJobResponse : BaseResponse
    {
        public string BIN { get; set; }

        public string SpecialName { get; set; }

        public string Borough { get; set; }

        public string BuildingClass { get; set; }

        public string Block { get; set; }

        public string Lot { get; set; }

        public string LotFlag { get; set; }

        public string LandMark { get; set; }

        public string FINZone1 { get; set; }

        public string FINZone2 { get; set; }

        public string FINZone3 { get; set; }

        public string AddressType { get; set; }

        public string HouseNumber { get; set; }

        public string LowHouseNumber { get; set; }

        public string StreetName { get; set; }

        public string StreetNumber1 { get; set; }

        public string StreetNumber2 { get; set; }

        public string MethodName { get; set; }

        public string GlJobType { get; set; }

        public string GlRecCountN { get; set; }

        public string J_BIN_NUMBER { get; set; }

        public string J_JOB_NUMBER { get; set; }

        public string J_JOB_DcOCUMENT_NUMBER { get; set; }

        public string J_JOB_TYPE { get; set; }

        public string J_JOB_IS_OPEN { get; set; }

        public string IsTCOIssued { get; set; }

        public string IsTCOOpen { get; set; }

        public string IsTCOWithdrawn { get; set; }

        public string J_HOLD_FLAG { get; set; }
        public string J_JOB_SPECIAL_ACTION_STATUS { get; set; }
        public string J_JOB_STATUS { get; set; }


    }


}
