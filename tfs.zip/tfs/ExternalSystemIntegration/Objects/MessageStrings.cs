﻿
namespace ExternalSystemIntegration.Objects
{
    public sealed class MessageStrings
    {
        public const string MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC = "<MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC><PC_DATA><PC_BORO>PRM_BUILDNYC_BOROUGH</PC_BORO><PC_HOUSE_NUMBER>PRM_BUILDNYC_HOUSENO</PC_HOUSE_NUMBER><PC_STREET_NAME>PRM_BUILDNYC_STREET</PC_STREET_NAME><PC_LAST_METHOD>MXBN_105</PC_LAST_METHOD></PC_DATA></MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC>";
        public const string MXBI_BIS_PROPERTY_DATA_PC = "<MXBI_BIS_PROPERTY_DATA_PC><PC_DATA><VlNumbBoro /><VlBin>PRM_BUILDNYC_BIN</VlBin><AllInquiryType>BXS1IQ70</AllInquiryType><BiswebReporting>B</BiswebReporting><FrontEndCalling>Y</FrontEndCalling></PC_DATA></MXBI_BIS_PROPERTY_DATA_PC>";
        public const string MXBI_BIS_PROPERTY_DATA_PC_ADDRESS = "<MXBI_BIS_PROPERTY_DATA_PC><PC_DATA><VlNumbBoro>PRM_BUILDNYC_BOROUGH</VlNumbBoro><VlNumbHous>PRM_BUILDNYC_HOUSENO</VlNumbHous><NmStrt>PRM_BUILDNYC_STREET</NmStrt><AllInquiryType>BXS1IQ70</AllInquiryType><BiswebReporting>B</BiswebReporting><FrontEndCalling>Y</FrontEndCalling></PC_DATA></MXBI_BIS_PROPERTY_DATA_PC>";
        public const string MXBI_BIS_CRM_PC = "<MXBI_CRM_001_GET_PROPERTY_FLAGS_PC><PC_DATA><AllInquiryType>CRM1BIN</AllInquiryType><AllBin>PRM_BUILDNYC_BIN</AllBin><PassJobNumber>PRM_DOBNOW_JOBNUMBER</PassJobNumber><PassDocNumber>PRM_DOBNOW_FILINGNUMBER</PassDocNumber><PC_LAST_METHOD>MXBI_CR1</PC_LAST_METHOD></PC_DATA></MXBI_CRM_001_GET_PROPERTY_FLAGS_PC>";
        public const string MXBI_CR2 = "<MXBI_CRM_002_GET_JOB_FLAGS_PC><PC_DATA><AllInquiryType>CRM1JOB</AllInquiryType><PassJobNumber>PRM_BUILDNYC_BISJOBNumber</PassJobNumber><PassDocNumber>PRM_BUILDNYC_BISDOCNumber</PassDocNumber><PC_LAST_METHOD>MXBI_CR2</PC_LAST_METHOD></PC_DATA></MXBI_CRM_002_GET_JOB_FLAGS_PC>";
        public const string MXBI_CR3 = "<MXBI_CRM_003_GET_LIC_FLAGS_PC><PC_DATA><AllInquiryType>CRM1LIC</AllInquiryType><ALL_LIC_TYPE>PRM_BUILDNYC_LICENSETYPE</ALL_LIC_TYPE><ALL_LIC_NO>PRM_BUILDNYC_LICENSENO</ALL_LIC_NO></PC_DATA></MXBI_CRM_003_GET_LIC_FLAGS_PC>";
        public const string MXBI_CR4 = "<MXBI_CRM_004_GET_HOT_FLAGS_PC><PC_DATA><AllInquiryType>CRM1HOT</AllInquiryType><CRM_LIC_TYPE>PRM_BUILDNYC_LICENSETYPE</CRM_LIC_TYPE><ALL_LIC_NO>PRM_BUILDNYC_LICENSENO</ALL_LIC_NO></PC_DATA></MXBI_CRM_004_GET_HOT_FLAGS_PC> ";
        public const string MXBI_CR5 = "<MXBI_CRM_005_GET_PAS_FLAGS_PC><PC_DATA ><AllInquiryType>BXS1RGB1</AllInquiryType><ALL_REG_STATUS>02</ALL_REG_STATUS><KEY_OLD>PRM_BUILDNYC_EMAIL</KEY_OLD></PC_DATA></MXBI_CRM_005_GET_PAS_FLAGS_PC>";
        public const string MXBI_CR6 = "<MXBI_CRM_006_GET_LOC_FLAGS_PC><PC_DATA><AllCount>PRM_BUILDNYC_PAGINGCOUNT</AllCount><InternalFlag>I</InternalFlag><AllLicType>PRM_BUILDNYC_LICENSETYPE</AllLicType><AllLicNo>PRM_BUILDNYC_LICENSENO</AllLicNo></PC_DATA></MXBI_CRM_006_GET_LOC_FLAGS_PC>";
        public const string MXBI_CR7 = "<MXBI_CRM_007_GET_LIC2_FLAGS_PC><PC_DATA><ALL_LIC_TYPE>PRM_BUILDNYC_LICENSETYPE</ALL_LIC_TYPE><ALL_LIC_NO>PRM_BUILDNYC_LICENSENO</ALL_LIC_NO><AllIsn>PRM_ALLISN</AllIsn></PC_DATA></MXBI_CRM_007_GET_LIC2_FLAGS_PC>";
        public const string MXBI_CR8 = "<MXBI_CRM_008_LIC_DET_FLAGS_PC><PC_DATA><KEY_OLD>PRM_BUILDNYC_LICENSENOTYPESPACEDELIMIT</KEY_OLD></PC_DATA></MXBI_CRM_008_LIC_DET_FLAGS_PC>";
        public const string MXBI_CR9 = "<MXBI_CRM_009_FAS_STA_FLAGS_PC><PC_DATA><AllControlNumber>PRM_FACADES_CONTROLNUMBER</AllControlNumber></PC_DATA></MXBI_CRM_009_FAS_STA_FLAGS_PC>";
        public const string MXBI_CR10 = "<MXBI_CRM_010_PRO_BLK_LOT_PC><PC_DATA><AllBorough>PRM_BUILDNYC_BOROUGH</AllBorough><AllCount>PRM_BUILDNYC_PAGINGCOUNT</AllCount><AllBlock>PRM_BUILDNYC_BLOCK</AllBlock><AllLot>PRM_BUILDNYC_LOT</AllLot></PC_DATA></MXBI_CRM_010_PRO_BLK_LOT_PC>";
        public const string MXBI_CR10Optional = "<MXBI_CRM_010_PRO_BLK_LOT_PC><PC_DATA><AllBorough>PRM_BUILDNYC_BOROUGH</AllBorough><AllCount>PRM_BUILDNYC_PAGINGCOUNT</AllCount><AllBlock>PRM_BUILDNYC_BLOCK</AllBlock></PC_DATA></MXBI_CRM_010_PRO_BLK_LOT_PC>";
        public const string MXBI_CR11 = "<MXBI_CRM_011_ECB_FLAGS_PC><PC_DATA><AllBin>PRM_BUILDNYC_BIN</AllBin><BoilerNumber>PRM_SD_ECB_VOILATIONNUMBER</BoilerNumber></PC_DATA></MXBI_CRM_011_ECB_FLAGS_PC>";
        public const string MXBI_BIS_ELEV_PC = "<MXBI_BIS_ELEV_PC><PC_DATA><AllBin>PRM_BUIDLNYC_BIN</AllBin><PassRecordNumber>PRM_BUILDNYC_RECORDNO</PassRecordNumber><PassDeviceNumber>PRM_BUILDNYC_DEVICENO</PassDeviceNumber><PC_LAST_METHOD>MXBI_PHE</PC_LAST_METHOD></PC_DATA></MXBI_BIS_ELEV_PC>";
        public const string MXBI_CRM_012_BOL_SET_PC = "<MXBI_CRM_012_BOL_SET_PC><AllBorough>PRM_BOROUGH</AllBorough><AllCount>PRM_COUNT</AllCount><BiswebReporting>PRM_REPORTING</BiswebReporting><BoroughKey>PRM_KEYBOROUGH</BoroughKey><ReadSw>PRM_READSW</ReadSw><AllEmailAddrCurrent>PRM_ALLEMAILADDRCURRENT</AllEmailAddrCurrent><FinFlag>PRM_FIN</FinFlag><AllKey1>PRM_ALLKEY</AllKey1></MXBI_CRM_012_BOL_SET_PC>"; //newly added in request for protected address
        public const string MXBI_BIS_ELE2BR_PC = "<MXBI_BIS_ELE2BR_PC><PC_DATA><AllBin>PRM_BIN</AllBin><AllCount>PRM_COUNT</AllCount><PassRecordNumber>PRM_PASSRECNUM</PassRecordNumber><PC_LAST_METHOD>MXBI_BEL</PC_LAST_METHOD></PC_DATA></MXBI_BIS_ELE2BR_PC>";
        public const string MXBI_BIS_ELEVBR_PC = "<MXBI_BIS_ELEVBR_PC><PC_DATA><AllBin>PRM_BIN</AllBin><AllCount>PRM_COUNT</AllCount><PC_LAST_METHOD>MXBI_BEL</PC_LAST_METHOD></PC_DATA></MXBI_BIS_ELEVBR_PC>";
        public const string MXBI_CRM_013_BOL_DET_PC = "<MXBI_CRM_013_BOL_DET_PC><AllIsn>PRM_ISN</AllIsn><AllBorough>PRM_BOROUGH</AllBorough><BiswebReporting>PRM_BISWEBREP</BiswebReporting><BoroughKey>PRM_KEYBOROUGH</BoroughKey><ReadSw>PRM_READSW</ReadSw><AllEmailAddrCurrent>PRM_ALLEMAILADDRCURRENT</AllEmailAddrCurrent><FinFlag>PRM_FIN</FinFlag></MXBI_CRM_013_BOL_DET_PC>"; //newly added in request for protected address
        public const string MXBI_CRM_014_BOL_RES_PC = "<MXBI_CRM_014_BOL_RES_PC><AllKey1>PRM_ALLKEY</AllKey1><AllCount>PRM_ALLCOUNT</AllCount><BiswebReporting>PRM_BISWEBREP</BiswebReporting><BoroughKey>PRM_KEYBOROUGH</BoroughKey><ReadSw>PRM_READSW</ReadSw><AllEmailAddrCurrent>PRM_ALLEMAILADDRCURRENT</AllEmailAddrCurrent><FinFlag>PRM_FIN</FinFlag></MXBI_CRM_014_BOL_RES_PC>"; //newly added in request for protected address
        public const string MXBI_CRM_015_BOL_DTS_PC = "<MXBI_CRM_015_BOL_DTS_PC><AllBPno>PRM_BOILERID</AllBPno><AllBPtype>PRM_BOILERTYPE</AllBPtype><AllBPser>PRM_BOILERSERIAL</AllBPser><AllBorough>PRM_BOROUGH</AllBorough><BiswebReporting>PRM_BISWEBREP</BiswebReporting><AllEmailAddrCurrent>PRM_ALLEMAILADDRCURRENT</AllEmailAddrCurrent><BoroughKey>PRM_KEYBOROUGH</BoroughKey></MXBI_CRM_015_BOL_DTS_PC>";//newly added in request for protected address
        public const string MXBI_CRM_016_ELE_DTS_PC = "<MXBI_CRM_016_ELE_DTS_PC><AllControlNumber>PRM_CONTROLNUMBER</AllControlNumber><AllBorough>PRM_BOROUGH</AllBorough><BiswebReporting>PRM_BISWEBREP</BiswebReporting><BoroughKey>PRM_KEYBOROUGH</BoroughKey><PageNumber>PRM_PAGENO</PageNumber><AllControlNumber /></MXBI_CRM_016_ELE_DTS_PC>";
        public const string MXBI_CRM_017_TBL_DTS_PC = "<MXBI_CRM_017_TBL_DTS_PC><PC_DATA><AllCount>PRM_Count</AllCount><AllTblType>PRM_TableType</AllTblType></PC_DATA></MXBI_CRM_017_TBL_DTS_PC>";
        public const string MXBI_C25= "<MXBI_CRM_PENS_PC><PC_DATA><PassJobNumber>PRM_JOB_NUMBER</PassJobNumber><PassDocNumber>PRM_DOC_NUMBER</PassDocNumber><PC_LAST_METHOD>MXBI_C25</PC_LAST_METHOD></PC_DATA></MXBI_CRM_PENS_PC>";
        public const string MXBI_C28 = "<MXBI_CRM_28_VIOL_WWP_PC><PC_DATA><AllBin>PRM_BUILDNYC_BIN</AllBin><AllCount>PRM_ALLCOUNT</AllCount><BoroughKey>PRM_BOROUGHKEY</BoroughKey></PC_DATA></MXBI_CRM_28_VIOL_WWP_PC>";
        public const string MXBI_C29 = "<MXBI_CRM_29_VIOL_ECB_PC><PC_DATA><AllBin>PRM_BUILDNYC_BIN</AllBin><AllCount>PRM_ALLCOUNT</AllCount><BoroughKey>PRM_BOROUGHKEY</BoroughKey></PC_DATA></MXBI_CRM_29_VIOL_ECB_PC>";

    }

    public sealed class MessageName
    {
        public const string MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC = "MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC";
        public const string MXBI_CRM_003_GET_LIC_FLAGS_MF = "MXBI_CRM_003_GET_LIC_FLAGS_MF";
    }

    public sealed class LicenseInformationSIAResponseTags
    {
        public const string LicenseNumber = "L-LICENSE-NUMBER";
        public const string LicenseType = "L-LICENSE-TYPE";
        public const string Status = "L-STATUS";
        public const string Statusdate = "L-STATUS-DATE";
        public const string Transcode = "L-TRANS-CODE";
        public const string DocketNumber = "L-DOCKET-NUMBER";
        public const string LicenseClass = "L-LICENSE-CLASS";
        public const string LicenseEntryDate = "L-LICENSE-ENTRY-DATE";
        public const string LicenseClassType = "L-LICENSE-CLASS-TYPE";
        public const string DocketNumber2 = "L-DOCKET-NUMBER2";
        public const string TransDate = "L-TRANS-DATE";
        public const string OperId = "L-OPER-ID";
        public const string RenewDate = "L-RENEW-DATE";
        public const string Expiredate = "L-EXPIRE-DATE";
        public const string IssueDate = "L-ISSUE-DATE";
        public const string LicenseUse1 = "L-LICENSE-USE-1";
        public const string LicenseUse2 = "L-LICENSE-USE-2";
        public const string NoselfCert = "L-NO-SELFCERT";
        public const string Exec298Flag = "L-EXEC298-FLAG";
        public const string Exec298Date = "L-EXEC298-DATE";
        public const string RsLtrFlag = "L-RS-LTR-FLAG";
        public const string CityEmployee = "L-CITY-EMPLOYEE";
        public const string Respforboiler = "L-RESP-FOR-BOILER";
        public const string GrandFather1 = "L-GRANDFATHER-1";
        public const string Grandfather2 = "L-GRANDFATHER-2";
        public const string TestCementFlag = "L-TEST-CEMENT-FLAG";
        public const string PERANumber = "L-PE-RA-NUMBER";
        public const string FirmNumber = "L-FIRM-NUMBER";
        public const string FirmResponsibleRep = "L-FIRM-RESPONSIBLE-REP";
        public const string Pin = "L-PIN";
        public const string RegistrationFlag = "L-REGISTRATION-FLAG";
        public const string RegistrationDate = "L-REGISTRATION-DATE";
        public const string BlockFlag = "L-BLOCK-FLAG";
        public const string BlockBeginDate = "L-BLOCK-BEGIN-DATE";
        public const string BlockEndDate = "L-BLOCK-END-DATE";
        public const string BlockComment = "L-BLOCK-COMMENT";
        public const string Journeymen = "L-JOURNEYMEN";
        public const string Apprentices = "L-APPRENTICES";
        public const string Helpers = "L-HELPERS";
        public const string Keytext = "L-KEY-TEXT";
        public const string ApplSsn = "L-APPL-SSN";
        public const string ApplBirthDate = "L-APPL-BIRTH-DATE";
        public const string ApplLastName = "L-APPL-LAST-NAME";
        public const string ApplFirstName = "L-APPL-FIRST-NAME";
        public const string ApplInitial = "L-APPL-INITIAL";
        public const string ApplHouseNumber = "L-APPL-HOUSE-NUMBER";
        public const string ApplStreetName = "L-APPL-STREET-NAME";
        public const string ApplCity = "L-APPL-CITY";
        public const string ApplState = "L-APPL-STATE";
        public const string ApplZip = "L-APPL-ZIP";
        public const string ApplMobile = "L-APPL-MOBILE";
        public const string ApplPhone = "L-APPL-PHONE";
        public const string ApplFax = "L-APPL-FAX";
        public const string ApplEmail = "L-APPL-EMAIL";
        public const string BusPhone = "L-BUS-PHONE";
        public const string busFax = "L-BUS-FAX";
        public const string BusEmail = "L-BUS-EMAIL";
        public const string BusHouseNumber = "L-BUS-HOUSE-NUMBER";
        public const string BusStreetName = "L-BUS-STREET-NAME";
        public const string BusAddrLine2 = "L-BUS-ADDR-LINE-2";
        public const string BusCity = "L-BUS-CITY";
        public const string BusState = "L-BUS-STATE";
        public const string BusZip = "L-BUS-ZIP";
        public const string BusName = "L-BUS-NAME";
        public const string BusEin = "L-BUS-EIN";
        public const string BusFeeexempt = "L-BUS-FEE-EXEMPT";
        public const string BusExpid = "L-BUS-EXP-ID";
        public const string BusText = "L-BUS-TEXT";
        public const string Aff1Of1Name = "L-AFF1-OF1-NAME";
        public const string Aff1Of1Title = "L-AFF1-OF1-TITLE";
        public const string Aff1Of1License = "L-AFF1-OF1-LICENSE";
        public const string Aff1Of1Type = "L-AFF1-OF1-TYPE";
        public const string Aff1Of1Pct = "L-AFF1-OF1-PCT";

        public const string DirectorLastName = "DIRECTOR-LAST-NAME";
        public const string DirectorFirstName = "DIRECTOR-FIRST-NAME";
        public const string DirectorTitle = "DIRECTOR-TITLE";
        public const string DirectorLicenseNumber = "DIRECTOR-LICENSE-NO";
        public const string DirectorLicensetype = "DIRECTOR-LICENSE-TYPE";
        public const string DirectorPCT = "DIRECTOR-PCT";
        public const string AgencyNumber = "L-AGENCY-NUMBER";
        public const string AgencyISN = "AGENCY-ISN";
    }

    public sealed class PropertyFlagInformation
    {
        public const string TaxLot = "PTaxLot";
        public const string HouseNumber = "PHouseNumber";
        public const string StreetName = "PStreetName";
        public const string DobLowHouseNumber = "PDobLowHouseNumber";
        public const string DobHighHouseNumber = "PDobHighHouseNumber";
        public const string VerifyType = "PVerifyType";
        public const string LandmarkStatus = "PLandmarkStatus";
        public const string Bin = "PBin";
        public const string BinInd = "TBinInd";
        public const string ObsoleteFlag = "ObsoleteFlag";
    }

        public sealed class AgencyNumberInformation
    {
        public const string ErrorCode = "MF_RETURN_CODE";
        public const string ErrorMessage = "MF_OVERALL_TEXT";
        public const string ErrorTablel = "MF_MORE_ERRORS";
        public const string NotUsed  = "NotUsed";
        public const string AllControlNumber = "AllControlNumber";
        public const string Date = "Datu";
        public const string HouseNumber = "VlNumbHous";
        public const string StreetName = "NmStrt";
        public const string BoroughName = "NmBoro";
        public const string Bin = "VlBin";
        public const string Zip = "VlNumbZip";
        public const string TaxBlock = "VlTaxBlock";
        public const string TaxLot = "VlTaxLot";
        public const string CensTract = "VlCensTract";
        public const string HealthArea = "VlHlthArea";
        public const string HseLow = "HseLo";
        public const string HseHi = "HseHi";
        public const string JobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string TotalRecordCount = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";

        public const string EndorsementFlag = "LEndorsementFlag";
        public const string EndorsementType = "LEndorsementType";
        public const string EndorsementTypeExp = "LEndorsementTypeExp";
        public const string EndorsementNumber = "LEndorsementNumber";
        public const string EndorsementDesc = "LEndorsementDesc";
        public const string EndorsementCodeRef1 = "LEndorsementCodeRef1";
        public const string EndorsementAddDate = "LEndorsementAddDate";
        public const string EndorsementDelDate = "LEndorsementDelDate";
        

    }

    public sealed class BisLicenseInformation
    {
        //start of main object values
        public const string Fin = "Fin";
        public const string ErrorMsg = "ErrorMsg";
        public const string Date = "Datu";
        public const string Pgm = "Pgm";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        //end of main object values

        //start of list values
        public const string RE_BUS_NAME = "RE-BUS-NAME";
        public const string RE_EMAIL_ADDR = "RE-EMAIL-ADDR";
        public const string RE_APP_TYPE = "RE-APP-TYPE";
        public const string RE_APP_NUMBER = "RE-APP-NUMBER";
        public const string RE_LAST_NAME = "RE-LAST-NAME";
        public const string RE_FIRST_NAME = "RE-FIRST-NAME";
        public const string RE_STATUS = "RE-STATUS";
        public const string RE_STATUS_DATE = "RE-STATUS-DATE";
        public const string RE_PASSWORD = "RE-PASSWORD";
        public const string RE_PREP_ADDRESS = "RE-PREP-ADDRESS";
        public const string RE_PREP_CITY = "RE-PREP-CITY";
        public const string RE_PREP_STATE = "RE-PREP-STATE";
        public const string RE_PREP_ZIP = "RE-PREP-ZIP";
        public const string RE_PREP_PHONE = "RE-PREP-PHONE";
        public const string RE_PREP_MOBILE = "RE-PREP-MOBILE";
        //end of list values

        public const string SHOW_SUSTAINABLE_LINK = "SHOW-SUSTAINABLE-LINK";
    }

    public sealed class RequestAttributes
    {
        public const string PRM_BUILDNYC_BOROUGH = "PRM_BUILDNYC_BOROUGH";
        public const string PRM_BUILDNYC_BLOCK = "PRM_BUILDNYC_BLOCK";
        public const string PRM_BUILDNYC_LOT = "PRM_BUILDNYC_LOT";
        public const string PRM_BUILDNYC_STREET = "PRM_BUILDNYC_STREET";
        public const string PRM_BUILDNYC_HOUSENO = "PRM_BUILDNYC_HOUSENO";
        public const string PRM_BUILDNYC_BIN = "PRM_BUILDNYC_BIN";
        public const string PRM_BUILDNYC_BISJOBNUMBER = "PRM_BUILDNYC_BISJOBNumber";
        public const string PRM_BUILDNYC_LICENSENO = "PRM_BUILDNYC_LICENSENO";
        public const string PRM_BUILDNYC_LICENSETYPE = "PRM_BUILDNYC_LICENSETYPE";
        public const string PRM_BUILDNYC_EMAIL = "PRM_BUILDNYC_EMAIL";
        public const string PRM_BUILDNYC_BISDOCNumber = "PRM_BUILDNYC_BISDOCNumber";
        public const string PRM_BUILDNYC_PAGINGCOUNT = "PRM_BUILDNYC_PAGINGCOUNT";
        public const string PRM_BUILDNYC_LICENSENOTYPESPACEDELIMIT = "PRM_BUILDNYC_LICENSENOTYPESPACEDELIMIT";
        public const string PRM_FACADES_CONTROLNUMBER = "PRM_FACADES_CONTROLNUMBER";
        public const string PRM_SD_ECB_VOILATIONNUMBER = "PRM_SD_ECB_VOILATIONNUMBER";
        public const string PRM_ALLISN = "PRM_ALLISN";
        public const string PRM_DOBNOW_JOBNUMBER= "PRM_DOBNOW_JOBNUMBER";
        public const string PRM_DOBNOW_FILINGNUMBER = "PRM_DOBNOW_FILINGNUMBER";
        public const string PRM_Count = "PRM_Count";
        public const string PRM_TableType = "PRM_TableType";
        public const string PRM_Pens_DocNumber = "PRM_DOC_NUMBER";
        public const string PRM_Pens_JobNumber = "PRM_JOB_NUMBER";
        public const string PRM_ALLCOUNT = "PRM_ALLCOUNT";
        public const string PRM_BOROUGHKEY = "PRM_BOROUGHKEY";
    }

    public sealed class ElevatorDetailsRequestAttributesTags
    {
        public const string PRM_BUIDLNYC_BIN = "PRM_BUIDLNYC_BIN";
        public const string PRM_BUILDNYC_RECORDNO = "PRM_BUILDNYC_RECORDNO";
        public const string PRM_BUILDNYC_DEVICENO = "PRM_BUILDNYC_DEVICENO";
       
    }

    public sealed class ElevatorDetailsResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip= "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi= "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DvDeviceNo = "DvDeviceNo";
        public const string DvStatusDate = "DvStatusDate";
        public const string DvLlawRecordNo = "DvLlawRecordNo";
        public const string DvExactLocation = "DvExactLocation";
        public const string DvApprovalDate = "DvApprovalDate";
        public const string DvAlterationDate = "DvAlterationDate";
        public const string DvFloorFrom = "DvFloorFrom";
        public const string DvTravDist = "DvTravDist";
        public const string DvWorkingPresurePSI = "DvWorkingPresurePSI";
        public const string DvFloorTo = "DvFloorTo";
        public const string DvSpeedFpm = "DvSpeedFpm";
        public const string DvCapacityLbs = "DvCapacityLbs";
        public const string DvCarEntrance = "DvCarEntrance";
        public const string DvManufacturer = "DvManufacturer";
        public const string DvHropeQty = "DvHropeQty";
        public const string DvCropeQty = "DvCropeQty";
        public const string DvMropeQty = "DvMropeQty";
        public const string DvBropeQty = "DvBropeQty";
        public const string DvHropeSize = "DvHropeSize";
        public const string DvCropeSize = "DvCropeSize";
        public const string DvMropeSize = "DvMropeSize";
        public const string DvBropeSize = "DvBropeSize";
        public const string DvHropeKind = "DvHropeKind";
        public const string DvCropeKind = "DvCropeKind";
        public const string DvMropeKind = "DvMropeKind";
        public const string DvBropeKind = "DvBropeKind";
        public const string DvGovernorType = "DvGovernorType";
        public const string DvSafetyType = "DvSafetyType";
        public const string DvGropeQty = "DvGropeQty";
        public const string DvMachineType = "DvMachineType";
        public const string DvModeOperation = "DvModeOperation";
        public const string DvGropeSize = "DvGropeSize";
        public const string DvCarBufferType = "DvCarBufferType";
        public const string DvFiremanService = "DvFiremanService";
        public const string DvGropeKind = "DvGropeKind";
        public const string DvLastperInspDate = "DvLastperInspDate";
        public const string DvLastperInspDisp = "DvLastperInspDisp";
        public const string DvLastperInspBadgeNo = "DvLastperInspBadgeNo";
        public const string DvCeaseUse = "DvCeaseUse";
        public const string DvAlterDateService = "DvAlterDateService";
        public const string DvApplicationNoArray = "DvApplicationNoArray";
        public const string LLBin = "LLBin";
        public const string HouseNumber = "HouseNumber";
        public const string StreetName = "StreetName";
        public const string DvCarBufferTypeExp = "DvCarBufferTypeExp";
        public const string DvCarEntrancesExp = "DvCarEntrancesExp";
        public const string DvGovernorTypeExp = "DvGovernorTypeExp";
        public const string MachineTypeExp = "DvMachineTypeExp";
        public const string DvModeOperationExp = "DvModeOperationExp";
        public const string DvHRopeKindExp = "DvHRopeKindExp";
        public const string DvCropeKindExp = "DvCropeKindExp";
        public const string DvMropeKindExp = "DvMropeKindExp";
        public const string DvBropeKindExp = "DvBropeKindExp";
        public const string DvGropeKindExp = "DvGropeKindExp";
        public const string DvSafetyTypeExp = "DvSafetyTypeExp";
        public const string DeviceStatus = "DeviceStatus";
        public const string DeviceType = "DeviceType";
        public const string ElpElevator = "ElpElevator";

    }

    public sealed class AddresssValidationResponseAttributesTags
    {

        //////Address Validation Tags

        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MF_BIN = "MF_BIN";
        public const string MF_SPECIAL_NAME = "MF_SPECIAL_NAME";
        public const string MF_BORO_CODE = "MF_BORO_CODE";
        public const string MF_FIN_BLDG_CLASS = "MF_FIN_BLDG_CLASS";
        public const string MF_TAX_BLOCK = "MF_TAX_BLOCK";
        public const string MF_TAX_LOT = "MF_TAX_LOT";
        public const string MF_LOFT_FLAG = "MF_LOFT_FLAG";
        public const string MF_LANDMARK_STATUS = "MF_LANDMARK_STATUS";
        public const string MF_FIN_ZONE1 = "MF_FIN_ZONE1";
        public const string MF_FIN_ZONE2 = "MF_FIN_ZONE2";
        public const string MF_FIN_ZONE3 = "MF_FIN_ZONE3";
        public const string MF_FIN_ZONE_SPEC_DIST1 = "MF_FIN_ZONE_SPEC_DIST1";
        public const string MF_FIN_ZONE_SPEC_DIST2 = "MF_FIN_ZONE_SPEC_DIST2";
        public const string MF_FIN_ZONE_OVERLAY1 = "MF_FIN_ZONE_OVERLAY1";
        public const string MF_FIN_ZONE_OVERLAY2 = "MF_FIN_ZONE_OVERLAY2";
        public const string MF_FIN_ZONE_AS_OF_DATE = "MF_FIN_ZONE_AS_OF_DATE";
        public const string MF_FIN_ZONE_PENDING_FLAG = "MF_FIN_ZONE_PENDING_FLAG";
        public const string MF_ADDRESS_TYPE = "MF_ADDRESS_TYPE";
        public const string MF_HOUSE_NUMBER = "MF_HOUSE_NUMBER";
        public const string MF_STREET_NAME = "MF_STREET_NAME";
        public const string MF_LOW_HOUSE_NUMBER = "MF_LOW_HOUSE_NUMBER";
        public const string MF_HIGH_HOUSE_NUMBER = "MF_HIGH_HOUSE_NUMBER";
        public const string MF_CROSS_STREET_NUMBER_1 = "MF_CROSS_STREET_NUMBER_1";
        public const string MF_CROSS_STREET_NUMBER_2 = "MF_CROSS_STREET_NUMBER_2";



    }

    public sealed class PropertyProfileResponseAttributesTags
    {
        ///// Property Profile Tags

        public const string ErrorCode = "MF_RETURN_CODE";
        public const string ErrorMsg = "MF_OVERALL_TEXT";
        public const string VlNumbHous = "VlNumbHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlNumbZip = "VlNumbZip";
        public const string VlBin = "VlBin";
        public const string VlNumbPage = "VlNumbPage";
        public const string revBin = "revBin";
        public const string PrevIsn = "PrevIsn";
        public const string NextBin = "NextBin";
        public const string NextIsn = "NextIsn";
        public const string VlStreet1 = "VlStreet1";
        public const string VlNumber1 = "VlNumber1";
        public const string VlStreet2 = "VlStreet2";
        public const string VlNumber2 = "VlNumber2";
        public const string VlStreet3 = "VlStreet3";
        public const string VlNumber3 = "VlNumber3";
        public const string VlStreet4 = "VlStreet4";
        public const string VlNumber4 = "VlNumber4";
        public const string VlStreet5 = "VlStreet5";
        public const string VlNumber5 = "VlNumber5";
        public const string VlStreet6 = "VlStreet6";
        public const string VlNumber6 = "VlNumber6";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlHlthArea = "VlHlthArea";
        public const string VlCensTract = "VlCensTract";
        public const string VlCommBoard = "VlCommBoard";
        public const string NmSpclPlace = "NmSpclPlace";
        public const string VlPropRecs = "VlPropRecs";
        public const string VlFinaOccpncy = "VlFinaOccpncy";
        public const string StLandMark = "StLandMark";
        public const string VlCompTot = "VlCompTot";
        public const string VlCompOpn = "VlCompOpn";
        public const string VlJobFill = "VlJobFill";
        public const string VlDobViolTot = "VlDobViolTot";
        public const string VlDobViolOpn = "VlDobViolOpn";
        public const string VlActn = "VlActn";
        public const string VlEcbViolTot = "VlEcbViolTot";
        public const string VlEcbViolOpn = "VlEcbViolOpn";
        public const string MfStCode = "MfStCode";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string JobCount = "JobCount";
        public const string PraCount = "PraCount";
        public const string PBuildingRemarks = "PBuildingRemarks";
        public const string PSpecialStatus = "PSpecialStatus";
        public const string PLocalLawTrans = "PLocalLawTrans";
        public const string PLoftFlagTransOld = "PLoftFlagTransOld";
        public const string PSroTrans = "PSroTrans";
        public const string PTaTrans = "PTaTrans";
        public const string PUbTrans = "PUbTrans";
        public const string PDobSpecialDistrictTrans = "PDobSpecialDistrictTrans";
        public const string PLittleE = "PLittleE";
        public const string PAdultUseFlagTrans = "PAdultUseFlagTrans";
        public const string PCityOwnedFlagTrans = "PCityOwnedFlagTrans";
        public const string PDobLot1 = "PDobLot1";
        public const string PDobLot2 = "PDobLot2";
        public const string PDobLot3 = "PDobLot3";
        public const string PDobLot4 = "PDobLot4";
        public const string PDobBlock = "PDobBlock";
        public const string GrandSign = "GrandSign";
        public const string BuildingsOnLotLink = "BuildingsOnLotLink";
        public const string noused = "noused";
        public const string CondoFlagText = "CondoFlagText";
        public const string PVacant = "PVacant";
        public const string PropIsn = "PropIsn";
        public const string VCnt = "VCnt";
        public const string VEcbCnt = "VEcbCnt";
        public const string PFinOwnerName = "PFinOwnerName";
        public const string PFinOwnerCorporationName = "PFinOwnerCorporationName";
        public const string PFinOwnerAddress = "PFinOwnerAddress";
        public const string PFinOwnerCityStateZip = "PFinOwnerCityStateZip";
        public const string PFinAvmOwnerName = "PFinAvmOwnerName";
        public const string PFinBldgDim1 = "PFinBldgDim1";
        public const string PFinBldgDim2 = "PFinBldgDim2";
        public const string PFinLotDim1 = "PFinLotDim1";
        public const string PFinLotDim2 = "PFinLotDim2";
        public const string PFinAssessedValue = "PFinAssessedValue";
        public const string ExpPTaxExemptStatus = "ExpPTaxExemptStatus";
        public const string PFinTaxExemptClass = "PFinTaxExemptClass";
        public const string PTotFinStories = "PTotFinStories";
        public const string PFinUpdateDate = "PFinUpdateDate";
        public const string PFinAeuName1 = "PFinAeuName1";
        public const string PFinAeuName2 = "PFinAeuName2";
        public const string PFinAeuAddress1 = "PFinAeuAddress1";
        public const string PFinAeuAddress2 = "PFinAeuAddress2";
        public const string CDispositionFlag = "CDispositionFlag";
        public const string PFinZone1Exp = "PFinZone1Exp";
        public const string PFinZone2Exp = "PFinZone2Exp";
        public const string PFinZone3Exp = "PFinZone3Exp";
        public const string PFinZoneOverlay1Exp = "PFinZoneOverlay1Exp";
        public const string PFinZoneOverlay2Exp = "PFinZoneOverlay2Exp";
        public const string PFinZoneSpecDist1Exp = "PFinZoneSpecDist1Exp";
        public const string PFinZoneSpecDist2Exp = "PFinZoneSpecDist2Exp";
        public const string PEmpty1 = "PEmpty1";
        public const string ShowFineFlag = "ShowFineFlag";
        public const string PFinZoneAsOfDate = "PFinZoneAsOfDate";
        public const string PFinZonePendingFlag = "PFinZonePendingFlag";
        public const string PVacateFlag = "PVacateFlag";
        public const string FirEcbCount = "FirEcbCount";
        public const string AsbEcbCount = "AsbEcbCount";
        public const string PadLockFlag = "PadLockFlag";
        public const string PCEHAFlag = "PCEHAFlag";
        public const string PFWWFlag = "PFWWFlag";
        public const string PTCWFlag = "PTCWFlag";
        public const string TBinInd = "TBinInd";
        public const string PCoolRoofs = "PCoolRoofs";
        public const string PWaterfrontFlag = "PWaterfrontFlag";
        public const string Class1ViolFlag = "Class1ViolFlag";
        public const string PLoftFlagTrans = "PLoftFlagTrans";
        public const string PDotCc = "PDotCc";
        public const string NumStruct = "NumStruct";
        public const string CautionBanner = "CautionBanner";
        public const string PEmpty10 = "PEmpty10";
        public const string PFoilText = "PFoilText";
        public const string PRRPWork = "PRRPWork";
        public const string CompromisedDispText = "CompromisedDispText";
        public const string CompromisedDispDate = "CompromisedDispDate";
        public const string ComplaintIsn = "ComplaintIsn";
        public const string SandyDemoFlag = "SandyDemoFlag";
        public const string PBuildItBackFlag = "PBuildItBackFlag";
        public const string PBuyoutFlag = "PBuyoutFlag";
        public const string IADBlock = "IADBlock";
        public const string SpecialFloodHazardArea = "PFemaFloodZone";
        public const string PAffordableHousing = "PAffordableHousing";
        public const string PScaUpkFlag = "PScaUpkFlag";
        public const string PDHSFacility = "PDHSFacility";
        public const string DHCRFlag = "PDHCRFlag";

    }

    public sealed class PropertyViolationResponseAttributesTags
    {
        //////Address Validation Tags
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string ErrorMsg = "ErrorMsg";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string ECB_WORK_WITHOUT_PERMIT = "ECB-WORK-WITHOUT-PERMIT";
        public const string BIS_WORK_WITHOUT_PERMIT = "BIS-WORK-WITHOUT-PERMIT";    
        public const string OPEN_A1 = "OPEN-A1";
        public const string OPEN_NB = "OPEN-NB";
        public const string P_VACANT_LAND = "P-VACANT-LAND";
        public const string GO_LATITUDE = "GO-LATITUDE";
        public const string GO_LONGITUDE = "GO-LONGITUDE";
        public const string P_SPECIAL_AREA_1 = "P-SPECIAL-AREA-1";
        public const string P_SPECIAL_AREA_2 = "P-SPECIAL-AREA-2";
        public const string P_SPECIAL_AREA_3 = "P-SPECIAL-AREA-3";
        public const string P_SPECIAL_AREA_4 = "P-SPECIAL-AREA-4";
        public const string P_SPECIAL_AREA_5 = "P-SPECIAL-AREA-5";
        public const string P_TA = "P-TA";
        public const string P_FIN_ZONE_SPEC_DIST1 = "P-FIN-ZONE-SPEC-DIST1";
        public const string P_FIN_ZONE_SPEC_DIST2 = "P-FIN-ZONE-SPEC-DIST2";
        public const string P_LOFT_FLAG = "P-LOFT-FLAG";
        public const string FILING_HOLD = "FILING-HOLD";
        public const string APPROVAL_HOLD = "APPROVAL-HOLD";
        public const string PERMIT_HOLD = "PERMIT-HOLD";
        public const string SIGNOFF_HOLD = "SIGNOFF-HOLD";
        public const string WITHDRAWAL_HOLD = "WITHDRAWAL-HOLD";
        public const string OBSOLETE_FLAG = "OBSOLETE-FLAG";
        public const string LittleE = "P-LITTLE-E";
        public const string LandmarkStatus = "P-LANDMARK-STATUS";
        public const string LittleEflag = "P-LITTLE-E-FLAG";
        public const string LittleEEffectiveDate = "P-LITTLE-E-EFFECTIVE-DAT";
        public const string LittleESatisfiedDate = "P-LITTLE-E-SATISFIED-DATE";
        public const string LittleEPartialFlag = "P-LITTLE-E-PARTIAL-FLAG";
        public const string NumberStopWork = "NUM-STOPWORK";
        public const string NumberOfStories = "F-NUM-STORIES";
        public const string NumberVacateFlag = "NUM-VACATE-FLAG";
        public const string PadlockFlag = "PADLOCK-FLAG>";
        public const string NumberClass1Violation = "NUM-CLASS1-VIOL";
        public const string BuyoutFlag = "P-BUYOUT-FLAG";
        public const string NumberSandyDemoFlag = "NUM-SANDY-DEMO-FLAG";
        public const string NumberCompromisedStructure = "NUM-COMPROMISED-STRUCTURE";

    }

    public sealed class BISJobResponseAttributesTags
    {
        ///// Property Profile Tags

        public const string ErrorCode = "MF_RETURN_CODE";
        public const string ErrorMsg = "ErrorMsg";
        public const string Datu = "Datu";
        public const string Pgm = "Pgm";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string J_BIN_NUMBER = "J-BIN-NUMBER";
        public const string J_JOB_NUMBER = "J-JOB-NUMBER";
        public const string J_JOB_DcOCUMENT_NUMBER = "J-JOB-DcOCUMENT_NUMBER";
        public const string J_JOB_TYPE = "J-JOB-TYPE";
        public const string J_JOB_IS_OPEN = "J-JOB-IS-OPEN";
        public const string IsTCOIssued = "TCO-ISSUED";
        public const string IsTCOOpen = "TCO-OPEN";
        public const string IsTCOWithdrawn = "TCO-WITHDRAWN";
        public const string J_HOLD_FLAG = "J-HOLD-FLAG";
        public const string J_JOB_SPECIAL_ACTION_STATUS = "J-JOB-SPECIAL-ACTION-STATUS";
        public const string J_JOB_STATUS = "J-JOB-STATUS";
        


    }

    public sealed class LicenseResponseAttributeTags
    {
        ///// License Tags
        public const string Fin = "Fin";
        public const string ErrorMsg = "ErrorMsg";
        public const string Datu = "Datu";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string L_LICENSE_NUMBER = "L-LICENSE-NUMBER";
        public const string L_LICENSE_TYPE = "L-LICENSE-TYPE";
        public const string L_STATUS = "L-STATUS"; // Status
        public const string L_GLI_REQUIRED_FLAG_AFF1 = "L-GLI-REQUIRED-FLAG-AFF1";
        public const string L_GLI_COMP_NAME_AFF1 = "L-GLI-COMP-NAME-AFF1";
        public const string L_GLI_EXP_DATE_AFF1 = "L-GLI-EXP-DATE-AFF1";
        public const string L_WCI_REQUIRED_FLAG_AFF1 = "L-WCI-REQUIRED-FLAG-AFF1";
        public const string L_WCI_COMP_NAME_AFF1 = "L-WCI-COMP-NAME-AFF1";
        public const string L_WCI_EXP_DATE_AFF1 = "L-WCI-EXP-DATE-AFF1";
        public const string L_DIS_REQUIRED_FLAG_AFF1 = "L-DIS-REQUIRED-FLAG-AFF1";
        public const string L_DIS_COMP_NAME_AFF1 = "L-DIS-COMP-NAME-AFF1";
        public const string L_DIS_EXP_DATE_AFF1 = "L-DIS-EXP-DATE-AFF1";
        public const string L_BUS_NAME_1 = "L-BUS-NAME-1";
        public const string L_BUS_NAME_2 = "L-BUS-NAME-2";
        public const string L_EXPIRE_DATE = "L-EXPIRE-DATE";
        public const string L_GLI_REQUIRED_FLAG_AFF2 = "L-GLI-REQUIRED-FLAG-AFF2";
        public const string L_GLI_COMP_NAME_AFF2 = "L-GLI-COMP-NAME-AFF2";
        public const string L_GLI_EXP_DATE_AFF2 = "L-GLI-EXP-DATE-AFF2";
        public const string L_WCI_REQUIRED_FLAG_AFF2 = "L-WCI-REQUIRED-FLAG-AFF2";
        public const string L_WCI_COMP_NAME_AFF2 = "L-WCI-COMP-NAME-AFF2";
        public const string L_WCI_EXP_DATE_AFF2 = "L-WCI-EXP-DATE-AFF2";
        public const string L_DIS_REQUIRED_FLAG_AFF2 = "L-DIS-REQUIRED-FLAG-AFF2";
        public const string L_DIS_COMP_NAME_AFF2 = "L-DIS-COMP-NAME-AFF2";
        public const string L_DIS_EXP_DATE_AFF2 = "L-DIS-EXP-DATE-AFF2";
        public const string L_APPL_LAST_NAME = "L-APPL-LAST-NAME";
        public const string L_APPL_FIRST_NAME = "L-APPL-FIRST-NAME";
        public const string L_APPL_INITIAL = "L-APPL-INITIAL";
        public const string L_APPL_HOUSE_NUMBER = "L-APPL-HOUSE-NUMBER";
        public const string L_APPL_STREET_NAME = "L-APPL-STREET-NAME";
        public const string L_APPL_CITY = "L-APPL-CITY";
        public const string L_APPL_STATE = "L-APPL-STATE";
        public const string L_APPL_ZIP = "L-APPL-ZIP";
        public const string L_APPL_MOBILE = "L-APPL-MOBILE";
        public const string L_APPL_PHONE = "L-APPL-PHONE";
        public const string L_APPL_FAX = "L-APPL-FAX";
        public const string L_APPL_EMAIL = "L-APPL-EMAIL";
        public const string L_BUS_PHONE = "L-BUS-PHONE";
        public const string L_BUS_FAX = "L-BUS-FAX";
        public const string L_BUS_EMAIL = "L-BUS-EMAIL";
        public const string L_BUS_HOUSE_NUMBER = "L-BUS-HOUSE-NUMBER";
        public const string L_BUS_STREET_NAME = "L-BUS-STREET-NAME";
        public const string L_BUS_ADDR_LINE_2 = "L-BUS-ADDR-LINE-2";
        public const string L_BUS_CITY = "L-BUS-CITY";
        public const string L_BUS_STATE = "L-BUS-STATE";
        public const string L_BUS_ZIP = "L-BUS-ZIP";
        public const string L_GLI_POLICY_AFF1 = "L-GLI-POLICY-AFF1";
        public const string L_GLI_POLICY_AFF2 = "L-GLI-POLICY-AFF2";
        public const string L_WCI_POLICY_AFF1 = "L-WCI-POLICY-AFF1";
        public const string L_WCI_POLICY_AFF2 = "L-WCI-POLICY-AFF2";
        public const string L_DIS_POLICY_AFF1 = "L-DIS-POLICY-AFF1";
        public const string L_DIS_POLICY_AFF2 = "L-DIS-POLICY-AFF2";
        public const string L_LICENSE_CLASS = "L-LICENSE-CLASS";
              

    }

    public sealed class HotListResponseAttributeTags
    {
        public const string Fin = "Fin";
        public const string ErrorMsg = "ErrorMsg";
        public const string Datu = "Datu";
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string NO_CERT = "NO-CERT";
        public const string NO_D14 = "NO-D14";
        public const string NO_ANY = "NO-ANY";
        public const string NO_BOTH = "NO-BOTH";
    }

    public sealed class SampleData
    {
        public const string AddressValidation = @"<string xmlns=""http://BFIRST.buildings.nycnet/""><MXBN_105_CHECK_ADDRESS_AND_GET_BIN_MF> <MF_RETURN_CODE>0</MF_RETURN_CODE> <MF_OVERALL_TEXT></MF_OVERALL_TEXT> <MF_MORE_ERRORS></MF_MORE_ERRORS> <MF_ERROR_TABLE></MF_ERROR_TABLE> <MF_RECORD_INSERTED_FLAG></MF_RECORD_INSERTED_FLAG> <MF_RECORD_UPDATED_FLAG></MF_RECORD_UPDATED_FLAG> <MF_RECORD_DELETED_FLAG></MF_RECORD_DELETED_FLAG> <MF_BIS_CORE_MODIFIED_FLAG></MF_BIS_CORE_MODIFIED_FLAG> <MF_DEBUG_MSG></MF_DEBUG_MSG> <MF_TRANSACTION_ID></MF_TRANSACTION_ID> <MF_DATA> <MF_BIN>1079215</MF_BIN> <MF_SPECIAL_NAME></MF_SPECIAL_NAME> <MF_BORO_CODE>1</MF_BORO_CODE> <MF_FIN_BLDG_CLASS>O9</MF_FIN_BLDG_CLASS> <MF_TAX_BLOCK>00153</MF_TAX_BLOCK> <MF_TAX_LOT>00001</MF_TAX_LOT> <MF_LOFT_FLAG></MF_LOFT_FLAG> <MF_LANDMARK_STATUS>L</MF_LANDMARK_STATUS> <MF_FIN_ZONE1>C6_4</MF_FIN_ZONE1> <MF_FIN_ZONE2></MF_FIN_ZONE2> <MF_FIN_ZONE3></MF_FIN_ZONE3> <MF_FIN_ZONE_SPEC_DIST1></MF_FIN_ZONE_SPEC_DIST1> <MF_FIN_ZONE_SPEC_DIST2></MF_FIN_ZONE_SPEC_DIST2> <MF_FIN_ZONE_OVERLAY1></MF_FIN_ZONE_OVERLAY1> <MF_FIN_ZONE_OVERLAY2></MF_FIN_ZONE_OVERLAY2> <MF_FIN_ZONE_AS_OF_DATE>2010_03_03</MF_FIN_ZONE_AS_OF_DATE> <MF_FIN_ZONE_PENDING_FLAG></MF_FIN_ZONE_PENDING_FLAG> <MF_ADDRESS_TYPE>BLDG SITE</MF_ADDRESS_TYPE> <MF_HOUSE_NUMBER>280</MF_HOUSE_NUMBER> <MF_STREET_NAME>BROADWAY</MF_STREET_NAME> <MF_LOW_HOUSE_NUMBER>274</MF_LOW_HOUSE_NUMBER> <MF_HIGH_HOUSE_NUMBER>286</MF_HIGH_HOUSE_NUMBER> <MF_CROSS_STREET_NUMBER_1>CHAMBERS STREET</MF_CROSS_STREET_NUMBER_1> <MF_CROSS_STREET_NUMBER_2>READE STREET</MF_CROSS_STREET_NUMBER_2> </MF_DATA> </MXBN_105_CHECK_ADDRESS_AND_GET_BIN_MF></string>";


    }

    public sealed class BIS_ControlNumberTags
    {
        public const string ReturnCode = "MF_RETURN_CODE";
        public const string ExteriorWallType = "ExtWallType";
        public const string ExteriorWallTypeRepeatingNodeName = "ExtWallType_ARRAY_CRM";
        public const string ExteriorWallCodeRepeatingNodeName = "F-CODES_ARRAY_CRM";
        public const string ExteriorWallCode = "F-CODES";
    }

    public sealed class ECBValidationInformation
    {
        public const string ReturnCode = "MF_RETURN_CODE";
        public const string ReturnError = "MF_OVERALL_TEXT";
        public const string Date = "Datu";
        public const string Pgm = "Pgm";
        public const string VlNumHous = "F-VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string ElaspedTime = "ElaspedTime";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string ECBNumber = "ECBNumber";
        public const string ActiveFlag = "ActiveFlag";
        public const string Addr = "Addr";
        public const string RespName = "RespName";
        public const string RespAddr = "RespAddr";
        public const string VIssDate = "VIssDate";
        public const string DelivDate = "DelivDate";
        public const string VType = "VType";
        public const string DobVNo = "DobVNo";
        public const string InspId = "InspId";
        public const string TaxLienFlag = "TaxLienFlag";
        public const string DevType = "DevType";
        public const string DevNum = "DevNum";
        public const string ExtHearingDt = "ExtHearingDt";
        public const string HrgTime = "HrgTime";
        public const string AmountImp = "AmountImp";
        public const string AmountPaid = "AmountPaid";
        public const string ExtBalanceDue = "ExtBalanceDue";
        public const string HrgStat = "HrgStat";
        public const string CompStat = "CompStat";
        public const string CompByDate = "CompByDate";
        public const string CompByStipDate = "CompByStipDate";
        public const string CompSeverity = "CompSeverity";
        public const string CurDt = "CurDt";
        public const string ComDt = "ComDt";
        public const string DefDt = "DefDt";
        public const string StipDt = "StipDt";
        public const string AjrDt = "AjrDt";
        public const string AsgDt = "AsgDt";
        public const string WriDt = "WriDt";

        public const string InfrCodeExpArrays = "InfrCodeExpArrays";
        public const string ECB1 = "ECB1";

        public const string InfrCode = "InfrCode";
        public const string StdDesc = "StdDesc";
        public const string SecOfLaw = "SecOfLaw";

        public const string ElevLines = "ElevLines";
        public const string ECB2 = "ECB2";
        public const string LN1 = "LN1";
        public const string LN2 = "LN2";
        public const string LN3 = "LN3";

        public const string ExtAliEventDt = "ExtAliEventDt";
        public const string ExtAldEventDt = "ExtAldEventDt";
        public const string ExtUnitCodeExp = "ExtUnitCodeExp";
        public const string ExtDocEventDt = "ExtDocEventDt";
        public const string CompOnDate = "CompOnDate";
        public const string ExtInfDIssissRsnExp = "ExtInfDIssissRsnExp";
        public const string CureDate = "CureDate";
        public const string ExtMultOffFlgExp = "ExtMultOffFlgExp";
        public const string ExtLiceseNo = "ExtLiceseNo";
        public const string ExtProjNum = "ExtProjNum";
        public const string ExtExhibAtt = "ExtExhibAtt";
        public const string ExtFirstHearingDt = "ExtFirstHearingDt";
        public const string ExtNetAllAdjusts = "ExtNetAllAdjusts";
        public const string ExtWriteOffFlag = "ExtWriteOffFlag";
        public const string ExtReceivedByDate = "ExtReceivedByDate";
        public const string ExtCompStatusDate = "ExtCompStatusDate";
        public const string ExtCMPDate = "ExtCMPDate";
        public const string ExtFaceAmt = "ExtFaceAmt";

        public const string StipHearingDate = "StipHearingDate";
        

    }

    public sealed class BoilerBrowseRequestAttributesTags
    {
        public const string PRM_BOROUGH = "PRM_BOROUGH";
        public const string PRM_COUNT = "PRM_COUNT";
        public const string PRM_REPORTING = "PRM_REPORTING";
        public const string PRM_KEYBOROUGH = "PRM_KEYBOROUGH";
        public const string PRM_READSW = "PRM_READSW";
        public const string PRM_FIN = "PRM_FIN";
        public const string PRM_ALLKEY = "PRM_ALLKEY";
        public const string PRM_ALLEMAILADDRCURRENT = "PRM_ALLEMAILADDRCURRENT"; //newmly added in request for protected address

    }

    public sealed class BoilerBrowseResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MFErrorArray = "MFErrorArray";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string AllNumbhous = "AllNumbhous";
        public const string AllStrt = "AllStrt";
        public const string AllBoro = "AllBoro";
        public const string AllBin = "AllBin";
        public const string AllZip = "AllZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";
        public const string Premise = "Premise";
        public const string TotalRecsQ200 = "TotalRecsQ200";
        public const string PageNumberQ200 = "PageNumberQ200";
        public const string voil1 = "voil1";
        public const string boiler1 = "boiler1";
        public const string md1 = "md1";
        public const string ser1 = "ser1";
        public const string status1 = "status1";
        public const string insp1 = "insp1";
        public const string recv1 = "recv1";
        public const string auth1 = "auth1";
        public const string isn = "isn";
    }

    public sealed class ElectricalPermitRequestAttributesTags
    {
        public const string PRM_CONTROLNUMBER = "PRM_CONTROLNUMBER";
        public const string PRM_BOROUGH = "PRM_BOROUGH";
        public const string PRM_BISWEBREP = "PRM_BISWEBREP";
        public const string PRM_KEYBOROUGH = "PRM_KEYBOROUGH";
        public const string PRM_PAGENO = "PRM_PAGENO";

    }

    public sealed class ElectricalPermitResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string EBin = "EBin";
        public const string EStatus = "EStatus";
        public const string EWorkToDo = "EWorkToDo";
        public const string EFirmNo = "EFirmNo";
       
    }

    public sealed class ElevatorListRequestAttributesTags
    {
        public const string PRM_BIN = "PRM_BIN";
        public const string PRM_COUNT = "PRM_COUNT";
        public const string PRM_PASSRECNUM = "PRM_PASSRECNUM";
        
    }

    public sealed class ElevatorListResponseAttributesTags
    {
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string NumDevices = "NumDevices";
        public const string InDevice = "InDevice";
        public const string DvDeviceNumber = "DvDeviceNumber";
        public const string DvDeviceStatus = "DvDeviceStatus";
        public const string DvDeviceType = "DvDeviceType";

    }

    public sealed class ElevatorRecordsRequestAttributesTags
    {
        public const string PRM_BIN = "PRM_BIN";
        public const string PRM_COUNT = "PRM_COUNT";
       
    }

    public sealed class ElevatorRecordsResponseAttributesTags
    {
        public const string VlNumHous = "VlNumHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumZip = "VlNumZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string VlCommBd = "VlCommBd";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string PageNumberQq30 = "PageNumberQq30";
        public const string TotalRecsQq30 = "TotalRecsQq30";
        public const string DupBin = "DupBin";

        public const string LlRecordNumber = "LlRecordNumber";
        public const string HouseNumber = "HouseNumber";
        public const string StreetName = "StreetName";
        public const string LlNumOfDevices = "LlNumOfDevices";
        public const string InspectCountQq30 = "InspectCountQq30";
        public const string ViolCountQq30 = "ViolCountQq30";

    }

    public sealed class BoilerDetailsRequestAttributesTags
    {
        public const string PRM_ISN = "PRM_ISN";
        public const string PRM_BOROUGH = "PRM_BOROUGH";
        public const string PRM_BISWEBREP = "PRM_BISWEBREP";
        public const string PRM_KEYBOROUGH = "PRM_KEYBOROUGH";
        public const string PRM_READSW = "PRM_READSW";
        public const string PRM_FIN = "PRM_FIN";
        public const string PRM_BOILERID = "PRM_BOILERID";
        public const string PRM_BOILERTYPE = "PRM_BOILERTYPE";
        public const string PRM_BOILERSERIAL = "PRM_BOILERSERIAL";
        public const string PRM_ALLEMAILADDRCURRENT = "PRM_ALLEMAILADDRCURRENT"; //newmly added in request for protected address
    }

    public sealed class BoilerDetailsResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MFErrorArray = "MFErrorArray";
        public const string AllNumbhous = "AllNumbhous";
        public const string AllControlNumber = "AllControlNumber";
        public const string AllStrt = "AllStrt";
        public const string AllBoro = "AllBoro";
        public const string AllBin = "AllBin";
        public const string AllZip = "AllZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";
        public const string Sta = "Sta";
        public const string BBldgLo = "BBldgLo";
        public const string BBoro = "BBoro";
        public const string BCensusTract = "BCensusTract";
        public const string BClass = "BClass";
        public const string BFee = "BFee";
        public const string BHealthArea = "BHealthArea";
        public const string BHorsePower = "BHorsePower";
        public const string BIns = "BIns";
        public const string BLoc = "BLoc";
        public const string BMakeOfBoiler = "BMakeOfBoiler";
        public const string BNumOfBoilers = "BNumOfBoilers";
        public const string BOver6 = "BOver6";
        public const string BPNO = "BPNO";
        public const string BPressure = "BPressure";
        public const string BYr = "BYr";
        public const string BPSer = "BPSer";
        public const string BPType = "BPType";
        public const string BSchool = "BSchool";
        public const string BStreetName = "BStreetName";
        public const string BZip = "BZip";
        public const string BDEPInstallNumber = "BDEPInstallNumber";
        public const string BDEPExpireDate = "BDEPExpireDate";
        public const string BTU = "BTU";
        public const string BIllegalFlag = "BIllegalFlag";
        public const string BoilerBoroBlockLot = "BoilerBoroBlockLot";
        public const string BBoilerKey = "BBoilerKey";
        public const string ElpBoiler = "ElpBoiler";
        public const string ComplEntryDate = "ComplEntryDate";
        public const string ComplInspDate = "ComplInspDate";
        public const string ComplName = "ComplName";
        public const string ComplNumber = "ComplNumber";
        public const string ComplRecvDate = "ComplRecvDate";
        public const string ComplVioFlagResults = "ComplVioFlagResults";
        public const string Source = "Source";
        public const string BoilerModel = "BoilerModel";
    }

    public sealed class BoilerComplianceDetailsRequestAttributesTags
    {
        public const string PRM_ALLKEY = "PRM_ALLKEY";
        public const string PRM_ALLCOUNT = "PRM_ALLCOUNT";
        public const string PRM_BISWEBREP = "PRM_BISWEBREP";
        public const string PRM_KEYBOROUGH = "PRM_KEYBOROUGH";
        public const string PRM_READSW = "PRM_READSW";
        public const string PRM_FIN = "PRM_FIN";
        public const string PRM_ALLEMAILADDRCURRENT = "PRM_ALLEMAILADDRCURRENT"; //newmly added in request for protected address
    }

    public sealed class BoilerComplianceDetailsResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MFErrorArray = "MFErrorArray";
        public const string AllNumbhous = "AllNumbhous";
        public const string AllControlNumber = "AllControlNumber";
        public const string AllStrt = "AllStrt";
        public const string AllBoro = "AllBoro";
        public const string AllBin = "AllBin";
        public const string AllZip = "AllZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";

        public const string ComplEntryDate = "ComplEntryDate";
        public const string ComplInspDate = "ComplInspDate";
        public const string ComplName = "ComplName";
        public const string ComplNumber = "ComplNumber";
        public const string ComplRecvDate = "ComplRecvDate";
        public const string ComplVioFlagResults = "ComplVioFlagResults";
        public const string Source = "Source";
        public const string BnInspType = "BnInspType";
    }

    public sealed class BISTableDetailsResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string Datu = "Datu";
        public const string Pgm = "Pgm";
        public const string GlRecCountN = "GlRecCountN";
        public const string BisTableDefinitions = "BisTableDefinitions";
        public const string BISTBL2 = "BISTBL2";
        public const string BisTableCode = "BisTableCode";
        public const string BisTableDescription = "BisTableDescription";
        public const string TotalRecsTable = "TotalRecsTable";        
    }

    public sealed class PensJobResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string GlJobType = "GlJobType";
        public const string MF_J_JOB_NUMBER = "MF_J_JOB_NUMBER";
        public const string MF_J_JOB_DOCUMENT_NUMBER = "MF_J_JOB_DOCUMENT_NUMBER";
        public const string MF_J_BIN_NUMBER = "MF_J_BIN_NUMBER";
        public const string MF_J_BORO = "MF_J_BORO";
        public const string MF_J_BLOCK = "MF_J_BLOCK";
        public const string MF_J_LOT = "MF_J_LOT";
        public const string MF_J_HOUSE_NUMBER = "MF_J_HOUSE_NUMBER";
        public const string MF_J_STREET_NAME = "MF_J_STREET_NAME";
        public const string MF_J_APT_CONDO_NUMBER = "MF_J_APT_CONDO_NUMBER";
        public const string MF_J_FLOOR = "MF_J_FLOOR";
        public const string MF_J_ZIP5 = "MF_J_ZIP5";
        public const string MF_J_JOB_TYPE = "MF_J_JOB_TYPE";
        public const string MF_J_APP_LAST_NAME = "MF_J_APP_LAST_NAME";
        public const string MF_J_APP_FIRST_NAME = "MF_J_APP_FIRST_NAME";
        public const string MF_J_APP_EMAIL = "MF_J_APP_EMAIL";
        public const string VlCommBd = "VlCommBd";
        public const string MF_J_PLAN_ASSIGNEE_ID = "MF_J_PLAN_ASSIGNEE_ID";
        public const string MF_PLAN_APPOINTMENT_FLAG = "MF_PLAN_APPOINTMENT_FLAG";
    }

    public sealed class WWPViolationECBResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MF_ERROR_TABLE = "MF_ERROR_TABLE";
        public const string NotUsed = "NotUsed";
        public const string AllControlNumber = "AllControlNumber";
        public const string Datu = "Datu";
        public const string Pgm = "Pgm";
        public const string VlNumbHous = "VlNumbHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumbZip = "VlNumbZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";
        public const string ExtActiveFlag = "ExtActiveFlag";
        public const string ExtEcbViolNo = "ExtEcbViolNo";
        public const string ExtRespName = "ExtRespName";
        public const string ExtDobViolNo = "ExtDobViolNo";
        public const string ExtViolType = "ExtViolType";
        public const string ExtStatus = "ExtStatus";
        public const string ExtViolCode1 = "ExtViolCode1";
        public const string ExtViolCode2 = "ExtViolCode2";
        public const string ExtViolCode3 = "ExtViolCode3";
        public const string ExtViolCode4 = "ExtViolCode4";
        public const string ExtViolCode5 = "ExtViolCode5";
        public const string ExtViolCode6 = "ExtViolCode6";
        public const string ExtViolCode7 = "ExtViolCode7";
        public const string ExtViolCode8 = "ExtViolCode8";
        public const string ExtTaxLienExp = "ExtTaxLienExp";
        public const string ExtViolCode1Exp = "ExtViolCode1Exp";
    }

    public sealed class WWPViolationDOBResponseAttributesTags
    {
        public const string MF_RETURN_CODE = "MF_RETURN_CODE";
        public const string MF_OVERALL_TEXT = "MF_OVERALL_TEXT";
        public const string MF_MORE_ERRORS = "MF_MORE_ERRORS";
        public const string MF_ERROR_TABLE = "MF_ERROR_TABLE";
        public const string NotUsed = "NotUsed";
        public const string AllControlNumber = "AllControlNumber";
        public const string Datu = "Datu";
        public const string Pgm = "Pgm";
        public const string VlNumbHous = "VlNumbHous";
        public const string NmStrt = "NmStrt";
        public const string NmBoro = "NmBoro";
        public const string VlBin = "VlBin";
        public const string VlNumbZip = "VlNumbZip";
        public const string VlTaxBlock = "VlTaxBlock";
        public const string VlTaxLot = "VlTaxLot";
        public const string VlCensTract = "VlCensTract";
        public const string VlHlthArea = "VlHlthArea";
        public const string HseLo = "HseLo";
        public const string HseHi = "HseHi";
        public const string GlJobType = "GlJobType";
        public const string GlPageN = "GlPageN";
        public const string GlRecCountN = "GlRecCountN";
        public const string FoilIndicator = "FoilIndicator";
        public const string DebugMsg = "DebugMsg";

        public const string ApplTransText = "ApplTransText";
        public const string ApplNumOcv3 = "ApplNumOcv3";
        public const string ApplStatus = "ApplStatus";
        public const string ApplDate = "ApplDate";
        public const string OvDateTxt = "OvDateTxt";
        public const string OvDisDateN2k = "OvDisDateN2k";
        public const string OvBadgeTxt = "OvBadgeTxt";
        public const string OvDisBadge = "OvDisBadge";
        public const string OvAgncyTxt = "OvAgncyTxt";
        public const string OvDisAgncy = "OvDisAgncy";
        public const string LnoTag = "LnoTag";
        public const string LnoArea = "LnoArea";
        public const string Comment1 = "Comment1";
        public const string Comment2 = "Comment2";
        public const string Isn = "Isn";
        public const string DrillType = "DrillType";
        public const string OAModelExp = "OAModelExp";
        public const string ViDOBNOWIdV3 = "ViDOBNOWIdV3";
    }
}
