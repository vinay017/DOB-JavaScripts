﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_1VI_PC")]
    public class CreateElevatorDOBViolationNumberRequest: BaseRequest
    {
        /*
         <CRMI_1VI_PC>
    <PC_DATA>
        <PC_CRM_VIOLATION_RECORD_ID>20180316001</PC_CRM_VIOLATION_RECORD_ID>
        <PC_CRM_DOB_VIOL_NUMBER_FULL>021518E1234H123456</PC_CRM_DOB_VIOL_NUMBER_FULL>
        <PC_CRM_DOB_VIOL_SEQ_NUMBER>123456</PC_CRM_DOB_VIOL_SEQ_NUMBER>
        <PC_CRM_CEASE_USE>Y</PC_CRM_CEASE_USE>
        <PC_CRM_VIOLATION_TYPE>ELEVATOR</PC_CRM_VIOLATION_TYPE>
        <PC_CRM_BIN>1009090</PC_CRM_BIN>
        <PC_CRM_BORO>1</PC_CRM_BORO>
        <PC_CRM_HOUSE_NUMBER>21</PC_CRM_HOUSE_NUMBER>
        <PC_CRM_STREET_NAME>UNIVERSITY PLACE</PC_CRM_STREET_NAME>
        <PC_CRM_DEVICE_NUMBER>1P123</PC_CRM_DEVICE_NUMBER>
        <PC_CRM_VIOL_ISSUE_DATE>2018-01-01</PC_CRM_VIOL_ISSUE_DATE>
        <PC_CRM_INSPECTION_CATEGORY>P</PC_CRM_INSPECTION_CATEGORY>
        <PC_CRM_BADGE_NUMBER>1234</PC_CRM_BADGE_NUMBER>
        <PC_CRM_VIOL_REMARKS>TEST CREATE VIOL</PC_CRM_VIOL_REMARKS>
        <PC_CUSTOM_PC_INTERFACE_ID>CRMI_1VI</PC_CUSTOM_PC_INTERFACE_ID>
    </PC_DATA>
</CRMI_1VI_PC>
         */

        public CreateElevatorDOBViolationNumberRequestChild PC_DATA = new CreateElevatorDOBViolationNumberRequestChild();

      
    }

    public class CreateElevatorDOBViolationNumberRequestChild : BaseRequest
    {



        private string eventDateTime;



        [XmlElement]
        public string PC_CRM_VIOLATION_RECORD_ID { get; set; }
        [XmlElement]
        public string PC_CRM_DOB_VIOL_NUMBER_FULL { get; set; }
        [XmlElement]
        public string PC_CRM_DOB_VIOL_SEQ_NUMBER { get; set; }
        [XmlElement]
        public string PC_CRM_CEASE_USE { get; set; }
        [XmlElement]
        public string PC_CRM_VIOLATION_TYPE { get; set; }
        [XmlElement]
        public string PC_CRM_BIN { get; set; }
        [XmlElement]
        public string PC_CRM_BORO { get; set; }
        [XmlElement]
        public string PC_CRM_HOUSE_NUMBER { get; set; }
        [XmlElement]
        public string PC_CRM_STREET_NAME { get; set; }
        [XmlElement]
        public string PC_CRM_DEVICE_NUMBER { get; set; }
        [XmlElement]
        public string PC_CRM_VIOL_ISSUE_DATE { get; set; }
        [XmlElement]
        public string PC_CRM_INSPECTION_CATEGORY { get; set; }
        [XmlElement]
        public string PC_CRM_BADGE_NUMBER { get; set; } 
        [XmlElement]
        public string PC_CRM_VIOL_REMARKS { get; set; }
        [XmlElement]
        public string PC_CUSTOM_PC_INTERFACE_ID = "CRMI_1VI";


       
       


    }
}
