﻿using ExternalSystemIntegration.Objects;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration
{
    

    [XmlRoot(ElementName = "MXBI_CRM_JOBDET_PC")]
    public class EXT_GetPAJobsByJobNumber : BaseRequest
    {

    //     <MXBI_CRM_JOBDET_PC>
    //    <PC_DATA>
    //        <PassJobNumber>122232226</PassJobNumber>
    //        <PassDocNumber>01</PassDocNumber>
    //        <BoroughKey>I</BoroughKey>
    //    </PC_DATA>
    //</MXBI_CRM_JOBDET_PC>

        public EXT_PAJobsByJobNumberRequest PC_DATA = new EXT_PAJobsByJobNumberRequest();
    }


    public class EXT_PAJobsByJobNumberRequest
    {

        [XmlElement]
        public string PassJobNumber { get; set; }
        [XmlElement]
        public string PassDocNumber = "01";
        [XmlElement]
        public string BoroughKey = "I";

    }


    [XmlRoot(ElementName = "MXBI_CRM_JOBDET_MF")]
    public class EXT_GetPAJobsByJobNumberResponse
    { 
    //     <MXBI_CRM_JOBDET_MF>
    //<MF_RETURN_CODE>0</MF_RETURN_CODE>
    // <MF_OVERALL_TEXT></MF_OVERALL_TEXT>
    // <MF_MORE_ERRORS></MF_MORE_ERRORS>
    // <MF_ERROR_TABLE></MF_ERROR_TABLE>
    // <NotUsed></NotUsed>
    // <AllControlNumber></AllControlNumber>
    // <Datu></Datu>
    // <Pgm>BXS2EJD1</Pgm>
    // <VlNumbHous>1321</VlNumbHous>
    // <NmStrt>6 AVENUE</NmStrt>
    // <NmBoro>MANHATTAN</NmBoro>
    // <VlBin>1023163</VlBin>
    // <VlNumbZip>10019</VlNumbZip>
    // <VlTaxBlock>01006</VlTaxBlock>
    // <VlTaxLot>07502</VlTaxLot>
    // <VlCensTract>131</VlCensTract>
    // <VlHlthArea>4700</VlHlthArea>
    // <HseLo></HseLo>
    // <HseHi></HseHi>
    // <GlJobType>PA - PLACE OF ASSEMBLY</GlJobType>
    // <GlPageN></GlPageN>
    // <GlRecCountN></GlRecCountN>
    // <FoilIndicator>*</FoilIndicator>
    // <DebugMsg></DebugMsg>
    //    <MF_DATA>
    //     <JJobNumber>122232226</JJobNumber>
    //   <JJobStatus>J</JJobStatus>
    //     <JJobStatusDate>20150108</JJobStatusDate>
    //    <JBinNumber>1023163</JBinNumber>
    //     <JJobDocNumber>01</JJobDocNumber>
    //    <JHouseNumber>1321</JHouseNumber>
    //        <JStreetName>6 AVENUE</JStreetName>
    //      <JPACOLinkDate></JPACOLinkDate>
    //       <JPaRelatedJobNumber>NB178-60</JPaRelatedJobNumber>
    //          <JPaEstabName>HILTON EMPLOYEE CAFETERIA</JPaEstabName>
    //         <Floors>SUB,001</Floors>
    //       <JPrOccupancyClassif>A-2</JPrOccupancyClassif>
    //     <JExJ2Classif></JExJ2Classif>
    //     <JPrJ2Classif></JPrJ2Classif>
    //        <OccClassif1>CAFETERIA</OccClassif1>
    //     <OccClassif2></OccClassif2>
    //             <OccClassif3></OccClassif3>
    //           <JPaIrregFloor>Y</JPaIrregFloor>
    //        <CabaretFlag1>N</CabaretFlag1>
    //     <CabaretFlag2></CabaretFlag2>
    //     <CabaretFlag3></CabaretFlag3>
    //          <JPaNumPersonsA></JPaNumPersonsA>
    //        <JPaAltNumPersons1A></JPaAltNumPersons1A>
    //     <JPaAltNumPersons2A></JPaAltNumPersons2A>
    //        </MF_DATA>
    //          </MXBI_CRM_JOBDET_MF>
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_ERROR_TABLE { get; set; }
        public string NotUsed { get; set; }
        public string AllControlNumber { get; set; }
        public string Datu { get; set; }
        public string Pgm { get; set; }
        public string VlNumbHous { get; set; }
        public string NmStrt { get; set; }
        public string NmBoro { get; set; }
        public string VlBin { get; set; }
        public string VlNumbZip { get; set; }
        public string VlTaxLot { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string HseLo { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string DebugMsg { get; set; }

        public EXT_GetPAJobsByJobNumber_MF_DATA MF_DATA;

    }


    public class EXT_GetPAJobsByJobNumber_MF_DATA
    {
        // <MF_DATA>
        //     <JJobNumber>122232226</JJobNumber>
        //   <JJobStatus>J</JJobStatus>
        //     <JJobStatusDate>20150108</JJobStatusDate>
        //    <JBinNumber>1023163</JBinNumber>
        //     <JJobDocNumber>01</JJobDocNumber>
        //    <JHouseNumber>1321</JHouseNumber>
        //        <JStreetName>6 AVENUE</JStreetName>
        //      <JPACOLinkDate></JPACOLinkDate>
        //       <JPaRelatedJobNumber>NB178-60</JPaRelatedJobNumber>
        //          <JPaEstabName>HILTON EMPLOYEE CAFETERIA</JPaEstabName>
        //         <Floors>SUB,001</Floors>
        //       <JPrOccupancyClassif>A-2</JPrOccupancyClassif>
        //      <JPaAltOcc1></JPaAltOcc1>
        //<JPaAltOcc2></JPaAltOcc2>
        //        <OccClassif1>CAFETERIA</OccClassif1>
        //     <OccClassif2></OccClassif2>
        //             <OccClassif3></OccClassif3>
        //           <JPaIrregFloor>Y</JPaIrregFloor>
        //        <CabaretFlag1>N</CabaretFlag1>
        //     <CabaretFlag2></CabaretFlag2>
        //     <CabaretFlag3></CabaretFlag3>
        //          <JPaNumPersons></JPaNumPersons>
        //        <JPaAltNumPersons1A></JPaAltNumPersons1A>
        //     <JPaAltNumPersons2A></JPaAltNumPersons2A>
        //        </MF_DATA>

        public string JJobNumber { get; set; }
        public string JJobStatus { get; set; }
        public string JJobStatusDate { get; set; }
        public string JBinNumber { get; set; }
        public string JJobDocNumber { get; set; }
        public string JHouseNumber { get; set; }
        public string JStreetName { get; set; }
        public string JPACOLinkDate { get; set; }

        public string JPaRelatedJobNumber { get; set; }
        public string JPaEstabName { get; set; }
        public string Floors { get; set; }
        public string JPrOccupancyClassif { get; set; }
        public string JPaAltOcc1 { get; set; }
        public string JPaAltOcc2 { get; set; }
        public string OccClassif1 { get; set; }
        public string OccClassif2 { get; set; }

        public string OccClassif3 { get; set; }
        public string CabaretFlag1 { get; set; }
        public string CabaretFlag2 { get; set; }
        public string CabaretFlag3 { get; set; }
        public string JPaNumPersons { get; set; }
        public string JPaAltNumPersons1A { get; set; }
        public string JPaAltNumPersons2A { get; set; }
        public string JPaIrregFloor { get; set; }

    }
}
