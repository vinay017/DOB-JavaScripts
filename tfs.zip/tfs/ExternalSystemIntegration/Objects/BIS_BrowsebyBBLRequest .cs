﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BIS_BrowsebyBBLRequest
    {
        public string AllBorough { get; set; }
        public string AllBorough { get; set; }
        public string AllBorough { get; set; }

    }
}
