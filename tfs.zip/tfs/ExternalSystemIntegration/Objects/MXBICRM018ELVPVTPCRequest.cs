﻿
using System.Xml.Serialization;
namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "MXBI_CRM_018_ELV_PVT_PC")]
    public class MXBICRM018ELVPVTPCRequest:BaseRequest
    {
        /*
         <MXBI_CRM_018_ELV_PVT_PC>
    <PC_DATA>
        <AllCount>9001</AllCount>
    </PC_DATA>
</MXBI_CRM_018_ELV_PVT_PC>
         */

        public MXBICRM018ELVPVTPCRequestChild PC_DATA = new MXBICRM018ELVPVTPCRequestChild();
    }

    public class MXBICRM018ELVPVTPCRequestChild:BaseRequest
    {

        [XmlElement]
        public string AllCount { get; set; }
        
    }
}
