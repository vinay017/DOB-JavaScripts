﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_2VI_PC")]
    public class DismissElevatorDOBViolationRequest: BaseRequest
    {
        /*
         <CRMI_2VI_PC>
    <PC_DATA>
        <PC_CRM_VIOLATION_RECORD_ID>20180316001</PC_CRM_VIOLATION_RECORD_ID>
        <PC_CRM_DOB_VIOL_NUMBER_FULL>021518E1234H123456</PC_CRM_DOB_VIOL_NUMBER_FULL>
        <PC_CRM_INSPECTION_CATEGORY>P</PC_CRM_INSPECTION_CATEGORY>
        <PC_CRM_BADGE_NUMBER>1234</PC_CRM_BADGE_NUMBER>
        <PC_CRM_DISMISSAL_DATE>2018-03-16</PC_CRM_DISMISSAL_DATE>
        <PC_CRM_DISMISSAL_REMARKSS>TEST DISMISSAL REMARKS</PC_CRM_DISMISSAL_REMARKSS>
        <PC_CUSTOM_PC_INTERFACE_ID>CRMI_2VI</PC_CUSTOM_PC_INTERFACE_ID>
    </PC_DATA>
</CRMI_2VI_PC>
             */

        public DismissElevatorDOBViolationRequestChild PC_DATA = new DismissElevatorDOBViolationRequestChild();

      
    }
    public class DismissElevatorDOBViolationRequestChild : BaseRequest
    {



        private string eventDateTime;



        [XmlElement]
        public string PC_CRM_VIOLATION_RECORD_ID { get; set; }
        //public string RecordId { get { return this.recordId; } set { this.recordId = string.Format("{0:00000000000000}", Convert.ToInt32(value)); } }
        [XmlElement]
        public string PC_CRM_DOB_VIOL_NUMBER_FULL { get; set; }
        [XmlElement]
        public string PC_CRM_INSPECTION_CATEGORY { get; set; }
        
        [XmlElement]
        public string PC_CRM_BADGE_NUMBER { get; set; }
        [XmlElement]
        public string PC_CRM_DISMISSAL_DATE { get;  set;  }
        [XmlElement]
        public string PC_CRM_DISMISSAL_REMARKSS { get; set; }
        [XmlElement]
        public string PC_CUSTOM_PC_INTERFACE_ID = "CRMI_2VI";


    }
}
