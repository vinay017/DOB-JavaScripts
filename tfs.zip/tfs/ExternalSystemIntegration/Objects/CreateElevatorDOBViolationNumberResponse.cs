﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_1VI_MF")]
    public class CreateElevatorDOBViolationNumberResponse
    {

        /*
         <?xml version="1.0" encoding="utf-16"?>
<CRMI_1VI_MF>
    <MF_RETURN_CODE>0</MF_RETURN_CODE>
    <MF_OVERALL_TEXT>DOB VIOLATION NUMBER 021518E1234 IS ALREADY IN BIS</MF_OVERALL_TEXT>
    <MF_MORE_ERRORS></MF_MORE_ERRORS>
    <MF_ERROR_TABLE>
        <MF_ERROR_ARRAY_LONG>
            <MF_ERROR>
                <MF_ERROR_CODE>DVIOD</MF_ERROR_CODE>
                <MF_ERROR_SUBSTITUTION>021518E1234</MF_ERROR_SUBSTITUTION>
                <MF_ERROR_INDEX></MF_ERROR_INDEX>
            </MF_ERROR>
        </MF_ERROR_ARRAY_LONG>
    </MF_ERROR_TABLE>
    <MF_RECORD_INSERTED_FLAG></MF_RECORD_INSERTED_FLAG>
    <MF_RECORD_UPDATED_FLAG></MF_RECORD_UPDATED_FLAG>
    <MF_RECORD_DELETED_FLAG></MF_RECORD_DELETED_FLAG>
    <MF_BIS_CORE_MODIFIED_FLAG></MF_BIS_CORE_MODIFIED_FLAG>
    <MF_DEBUG_MSG>VIOLATION ALREADY EXISTS</MF_DEBUG_MSG>
    <MF_TRANSACTION_ID></MF_TRANSACTION_ID>
    <MF_DATA>
        <MF_DOB_VIOL_NUMBER_FULL>010118E021518E1234</MF_DOB_VIOL_NUMBER_FULL>
        <MF_VIOLATION_ALREADY_EXISTS>Y</MF_VIOLATION_ALREADY_EXISTS>
        <MF_VIOLATION_ALREADY_DIFFERENT>N</MF_VIOLATION_ALREADY_DIFFERENT>
        <MF_CUSTOM_MF_INTERFACE_ID>CRMI_1VI</MF_CUSTOM_MF_INTERFACE_ID>
    </MF_DATA>
</CRMI_1VI_MF>
             
             */



        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_MORE_ERRORS { get; set; }

        public ViolationNumberErrorTable MF_ERROR_TABLE;
        public string MF_RECORD_INSERTED_FLAG { get; set; }
        public string MF_RECORD_UPDATED_FLAG { get; set; }
        public string MF_RECORD_DELETED_FLAG { get; set; }
        public string MF_BIS_CORE_MODIFIED_FLAG { get; set; }
        public string MF_DEBUG_MSG { get; set; }
        public string MF_TRANSACTION_ID { get; set; }

        public CreateElevatorDOBViolationNumber MF_DATA;


       

    }

    public class CreateElevatorDOBViolationNumber
    {
        public string MF_DOB_VIOL_NUMBER_FULL { get; set; }
        public string MF_VIOLATION_ALREADY_EXISTS { get; set; }
        public string MF_VIOLATION_ALREADY_DIFFERENT { get; set; }
        
        public string MF_CUSTOM_MF_INTERFACE_ID { get; set; }


    }
}
