﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Globalization;


namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_1EL_PC")]
    public class ElectricalBisPaymentRequest : BaseRequest
    {
        public ElectricalBisPaymentRequestChild PC_DATA = new ElectricalBisPaymentRequestChild();
    }

    
    public class ElectricalBisPaymentRequestChild : BaseRequest
    {

        private string eventDateTime;

        private string processingDateTime;

        [XmlElement]
        public string RecordId { get; set; }
            //public string RecordId { get { return this.recordId; } set { this.recordId = string.Format("{0:00000000000000}", Convert.ToInt32(value)); } }
        [XmlElement]
        public string BisControlNum { get; set; }
        [XmlElement]
        public string EventCode { get; set; }
        [XmlElement]
        public string EventDateTime { get { return this.eventDateTime; } set { CultureInfo ci = CultureInfo.InvariantCulture; this.eventDateTime = Convert.ToDateTime(value).ToString("yyyy-MM-dd HH:mm:ss.f", ci); }  }
        [XmlElement]
        public string ProcessingDateTime { get { return this.processingDateTime; } set { CultureInfo ci = CultureInfo.InvariantCulture; this.processingDateTime = Convert.ToDateTime(value).ToString("yyyy-MM-dd HH:mm:ss.f", ci); } }
        [XmlElement]
        public string ConversionFlag { get; set; }
        [XmlElement]
        public string JobStartDate { get; set; }
        [XmlElement]
        public string JobEndDate { get; set; }
        [XmlElement]
        public string LocationType { get; set; }
        [XmlElement]
        public string Boro { get; set; }
        [XmlElement]
        public string Hnum { get; set; }
        [XmlElement]
        public string StName { get; set; }
        [XmlElement]
        public string Bin { get; set; }
        [XmlElement]
        public string Block { get; set; }
        [XmlElement]
        public string Lot { get; set; }
        [XmlElement]
        public string ZipCode { get; set; }
        [XmlElement]
        public string CbNum { get; set; }
        [XmlElement]
        public string BisComplaintNum { get; set; }
        [XmlElement]
        public string BisJobNum { get; set; }
        [XmlElement]
        public string PreBisJobNum { get; set; }
        [XmlElement]
        public string DCARefNum { get; set; }
        [XmlElement]
        public string ElectricalFirmNum1 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicNum1 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicType1 { get; set; }
        [XmlElement]
        public string ElectricalFirmNum2 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicNum2 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicType2 { get; set; }
        [XmlElement]
        public string ElectricalFirmNum3 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicNum3 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicType3 { get; set; }
        [XmlElement]
        public string ElectricalFirmNum4 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicNum4 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicType4 { get; set; }
        [XmlElement]
        public string ElectricalFirmNum5 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicNum5 { get; set; }
        [XmlElement]
        public string ElectricalFirmLicType5 { get; set; }
        [XmlElement]
        public string WorkCategory { get; set; }
        [XmlElement]
        public string IsFeeExempt { get; set; }
        [XmlElement]
        public string IsLegalization { get; set; }
        [XmlElement]
        public int FeeMultiplier { get; set; }
        [XmlElement]
        public decimal InitialFilingFee { get; set; }
        [XmlElement]
        public decimal SignFeeAmount { get; set; }
        [XmlElement]
        public decimal TotalPartsFeeAmount { get; set; }
        [XmlElement]
        public decimal TotalFee { get; set; }
        [XmlElement]
        public decimal TotalFeePaidAmount { get; set; }
        [XmlElement]
        public string PaymentId { get; set; }
        [XmlElement]
        public string PC_LAST_METHOD = "CRMI_1EL";

    }

    [XmlRoot(ElementName = "CRMI_1EL_MF")]
    public class ElectricalBisPaymentResponse : BaseResponse
    {
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_MORE_ERRORS { get; set; }

        public BisPaymentErrorTable MF_ERROR_TABLE;
        public string MF_RECORD_INSERTED_FLAG { get; set; }
        public string MF_RECORD_UPDATED_FLAG { get; set; }
        public string MF_RECORD_DELETED_FLAG { get; set; }
        public string MF_BIS_CORE_MODIFIED_FLAG { get; set; }
        public string MF_DEBUG_MSG { get; set; }
        public string MF_TRANSACTION_ID { get; set; }

        public BisPaymentResponse MF_DATA ;


    }

    public class BisPaymentResponse
    {
        public string RecordId { get; set; }
        public string BisControlNum { get; set; }
        public string PaymentId { get; set; }
        public string BisInvoiceNum { get; set; }
        public string IsTotalFeePaid { get; set; }
        public string TotalFeePaidAmount { get; set; }
        public string ElectricalFirmNum1 { get; set; }
        public string ElectricalFirmLicNum1 { get; set; }
        public string ElectricalFirmLicType1 { get; set; }
        public string ElectricalFirmNum2 { get; set; }
        public string ElectricalFirmLicNum2 { get; set; }
        public string ElectricalFirmLicType2 { get; set; }
        public string ElectricalFirmNum3 { get; set; }
        public string ElectricalFirmLicNum3 { get; set; }
        public string ElectricalFirmLicType3 { get; set; }
        public string ElectricalFirmNum4 { get; set; }
        public string ElectricalFirmLicNum4 { get; set; }
        public string ElectricalFirmLicType4 { get; set; }
        public string ElectricalFirmNum5 { get; set; }
        public string ElectricalFirmLicNum5 { get; set; }
        public string ElectricalFirmLicType5 { get; set; }

    }

   public class BisPaymentErrorTable
    {
        public BisPaymentErrorsShort MF_ERROR_ARRAY_SHORT = new BisPaymentErrorsShort();
    }

    public class BisPaymentErrorsShort
    {
        public List<BisPaymentErrors> MF_ERROR;
    }

    public class BisPaymentErrors
    {
        public string MF_ERROR_CODE { get; set; }

        public string MF_ERROR_INDEX { get; set; }
    }

}
