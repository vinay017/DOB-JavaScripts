﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_0VI_MF")]
    public class ValidateElevatorDOBViolationNumberResponse:BaseResponse
    {

        /*<?xml version = "1.0" encoding="utf-16"?>
<CRMI_0VI_MF>
    <MF_RETURN_CODE>0</MF_RETURN_CODE>
    <MF_OVERALL_TEXT></MF_OVERALL_TEXT>
    <MF_MORE_ERRORS></MF_MORE_ERRORS>
    <MF_ERROR_TABLE></MF_ERROR_TABLE>
    <MF_RECORD_INSERTED_FLAG></MF_RECORD_INSERTED_FLAG>
    <MF_RECORD_UPDATED_FLAG></MF_RECORD_UPDATED_FLAG>
    <MF_RECORD_DELETED_FLAG></MF_RECORD_DELETED_FLAG>
    <MF_BIS_CORE_MODIFIED_FLAG></MF_BIS_CORE_MODIFIED_FLAG>
    <MF_DEBUG_MSG></MF_DEBUG_MSG>
    <MF_TRANSACTION_ID></MF_TRANSACTION_ID>
    <MF_DATA>
        <MF_DOB_VIOL_NUMBER_FULL></MF_DOB_VIOL_NUMBER_FULL>
        <MF_VIOLATION_ALREADY_EXISTS>N</MF_VIOLATION_ALREADY_EXISTS>
        <MF_VIOLATION_ALREADY_DIFFERENT>N</MF_VIOLATION_ALREADY_DIFFERENT>
        <MF_CRM_BIN>CRMI_0V</MF_CRM_BIN>
        <MF_CRM_BORO>I</MF_CRM_BORO>
        <MF_CRM_HOUSE_NUMBER></MF_CRM_HOUSE_NUMBER>
        <MF_CRM_STREET_NAME></MF_CRM_STREET_NAME>
        <MF_CRM_DEVICE_NUMBER></MF_CRM_DEVICE_NUMBER>
        <MF_CUSTOM_MF_INTERFACE_ID></MF_CUSTOM_MF_INTERFACE_ID>
    </MF_DATA>
</CRMI_0VI_MF>*/


       
           public string MF_RETURN_CODE { get; set; }
            public string MF_OVERALL_TEXT { get; set; }
            public string MF_MORE_ERRORS { get; set; }

            public ViolationNumberErrorTable MF_ERROR_TABLE;
            public string MF_RECORD_INSERTED_FLAG { get; set; }
            public string MF_RECORD_UPDATED_FLAG { get; set; }
            public string MF_RECORD_DELETED_FLAG { get; set; }
            public string MF_BIS_CORE_MODIFIED_FLAG { get; set; }
            public string MF_DEBUG_MSG { get; set; }
            public string MF_TRANSACTION_ID { get; set; }

            public DOBViolationNumberResponse MF_DATA;

       

    }
    public class DOBViolationNumberResponse
    {
        public string MF_DOB_VIOL_NUMBER_FULL { get; set; }
        public string MF_VIOLATION_ALREADY_EXISTS { get; set; }
        public string MF_VIOLATION_ALREADY_DIFFERENT { get; set; }
        public string MF_CRM_BIN { get; set; }
        public string MF_CRM_BORO { get; set; }
        public string MF_CRM_HOUSE_NUMBER { get; set; }
        public string MF_CRM_STREET_NAME { get; set; }
        public string MF_CRM_DEVICE_NUMBER { get; set; }
        public string MF_CUSTOM_MF_INTERFACE_ID { get; set; }


    }

    public class ViolationNumberErrorTable
    {
        public ViolationNumberErrorsShort MF_ERROR_ARRAY_SHORT = new ViolationNumberErrorsShort();
    }

    public class ViolationNumberErrorsShort
    {
        public List<ViolationNumberErrors> MF_ERROR;
    }

    public class ViolationNumberErrors
    {
        public string MF_ERROR_CODE { get; set; }

        public string MF_ERROR_INDEX { get; set; }
    }

}
