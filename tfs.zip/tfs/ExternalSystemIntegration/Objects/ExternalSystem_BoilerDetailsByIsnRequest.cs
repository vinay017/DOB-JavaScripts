﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_BoilerDetailsByIsnRequest : BaseRequest
    {
        public string Borough { get; set; }
        public string BiswebReporting { get; set; }
        public string BoroughKey { get; set; }
        public string ReadSw { get; set; }
        public string FinFlag { get; set; }
        public string Isn { get; set; }
        public string AllEmailAddrCurrent { get; set; }
    }
}