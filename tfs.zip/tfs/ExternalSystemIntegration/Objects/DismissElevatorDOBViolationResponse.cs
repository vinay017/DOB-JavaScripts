﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "CRMI_2VI_MF")]
    public class DismissElevatorDOBViolationResponse
    {
        /*
         <?xml version="1.0" encoding="utf-16"?>
<CRMI_2VI_MF>
    <MF_RETURN_CODE>0</MF_RETURN_CODE>
    <MF_OVERALL_TEXT></MF_OVERALL_TEXT>
    <MF_MORE_ERRORS></MF_MORE_ERRORS>
    <MF_ERROR_TABLE></MF_ERROR_TABLE>
    <MF_RECORD_INSERTED_FLAG></MF_RECORD_INSERTED_FLAG>
    <MF_RECORD_UPDATED_FLAG></MF_RECORD_UPDATED_FLAG>
    <MF_RECORD_DELETED_FLAG></MF_RECORD_DELETED_FLAG>
    <MF_BIS_CORE_MODIFIED_FLAG></MF_BIS_CORE_MODIFIED_FLAG>
    <MF_DEBUG_MSG></MF_DEBUG_MSG>
    <MF_TRANSACTION_ID></MF_TRANSACTION_ID>
    <MF_DATA>
        <MF_CRM_VIOLATION_RECORD_ID>CRMI_2VI</MF_CRM_VIOLATION_RECORD_ID>
        <MF_DOB_VIOL_NUMBER_FULL></MF_DOB_VIOL_NUMBER_FULL>
        <MF_CRM_INSPECTION_CATEGORY></MF_CRM_INSPECTION_CATEGORY>
        <MF_CRM_BADGE_NUMBER></MF_CRM_BADGE_NUMBER>
        <MF_CRM_AGENCY_NUMBER></MF_CRM_AGENCY_NUMBER>
        <MF_CRM_DISMISSAL_DATE></MF_CRM_DISMISSAL_DATE>
        <MF_CRM_DISMISSAL_REMARKS></MF_CRM_DISMISSAL_REMARKS>
        <MF_CUSTOM_MF_INTERFACE_ID></MF_CUSTOM_MF_INTERFACE_ID>
    </MF_DATA>
</CRMI_2VI_MF>
         */


        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_MORE_ERRORS { get; set; }

        public ViolationNumberErrorTable MF_ERROR_TABLE;
        public string MF_RECORD_INSERTED_FLAG { get; set; }
        public string MF_RECORD_UPDATED_FLAG { get; set; }
        public string MF_RECORD_DELETED_FLAG { get; set; }
        public string MF_BIS_CORE_MODIFIED_FLAG { get; set; }
        public string MF_DEBUG_MSG { get; set; }
        public string MF_TRANSACTION_ID { get; set; }

        public DismissViolationNumberResponse MF_DATA;


      
    }

    public class DismissViolationNumberResponse
    {
        public string MF_CRM_VIOLATION_RECORD_ID { get; set; }
        public string MF_DOB_VIOL_NUMBER_FULL { get; set; }
        public string MF_CRM_INSPECTION_CATEGORY { get; set; }
        public string MF_CRM_BADGE_NUMBER { get; set; }
        public string MF_CRM_AGENCY_NUMBER { get; set; }
        public string MF_CRM_DISMISSAL_DATE { get; set; }
        public string MF_CRM_DISMISSAL_REMARKS { get; set; }

        public string MF_CUSTOM_MF_INTERFACE_ID { get; set; }


    }
}
