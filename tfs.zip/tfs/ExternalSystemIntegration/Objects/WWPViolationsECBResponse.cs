﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class WWPViolationsECBResponse
    {
        public string ReturnError { get; set; }
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_MORE_ERRORS { get; set; }
        public string MF_ERROR_TABLE { get; set; }
        public string Pgm { get; set; }
        public string VlNumbHous { get; set; }
        public string NmStrt { get; set; }
        public string NmBoro { get; set; }
        public string VlBin { get; set; }
        public string VlNumbZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }

        public List<ECBViolationsWWP> ECBViolationsList = new List<ECBViolationsWWP>();
    }

    public class ECBViolationsWWP
    {
        public string ExtActiveFlag { get; set; }
        public string ExtEcbViolNo { get; set; }
        public string ExtRespName { get; set; }
        public string ExtDobViolNo { get; set; }
        public string ExtViolType { get; set; }
        public string ExtStatus { get; set; }
        public string ExtViolCode1 { get; set; }
        public string ExtViolCode2 { get; set; }
        public string ExtViolCode3 { get; set; }
        public string ExtViolCode4 { get; set; }
        public string ExtViolCode5 { get; set; }
        public string ExtViolCode6 { get; set; }
        public string ExtViolCode7 { get; set; }
        public string ExtViolCode8 { get; set; }
        public string ExtTaxLienExp { get; set; }
        public string ExtViolCode1Exp { get; set; }
    }
}

