﻿using System.Xml.Serialization;

namespace ExternalSystemIntegration.Objects
{
    [XmlRoot(ElementName = "MXBI_CRM_018_ELV_PVT_MF")]
    public class MXBICRM018ELVPVTPCResponse
    {
        /*
         <MXBI_CRM_018_ELV_PVT_MF>
    <MF_RETURN_CODE>0</MF_RETURN_CODE>
    <MF_OVERALL_TEXT></MF_OVERALL_TEXT>
    <Datu>06/12/18</Datu>
    <Pgm>CRM1BDGN</Pgm>
    <VlNumHous></VlNumHous>
    <NmStrt></NmStrt>
    <NmBoro></NmBoro>
    <VlBin></VlBin>
    <VlNumZip></VlNumZip>
    <VlTaxBlock></VlTaxBlock>
    <VlTaxLot></VlTaxLot>
    <VlCensTract></VlCensTract>
    <VlHlthArea></VlHlthArea>
    <ElaspedTime>0</ElaspedTime>
    <VlCommBd></VlCommBd>
    <HseHi>0</HseHi>
    <GlJobType></GlJobType>
    <GlPageN></GlPageN>
    <GlRecCountN></GlRecCountN>
    <FoilIndicator></FoilIndicator>
    <BDGN_ACTIVE>N</BDGN_ACTIVE>
    <BDGN_OUT_UNIT>E</BDGN_OUT_UNIT>
    <BDGN_OUT_NAME>AMERICAN ELEVATOR INSPECTION</BDGN_OUT_NAME>
    <BDGN_OUT_TITLE>PRIVATE ELEVATOR CO</BDGN_OUT_TITLE>
    <BDGN_OUT_COMMENT>(AEIS) NO INSP ALOWD</BDGN_OUT_COMMENT>
    <DGN_OUT_BEC_BORO></DGN_OUT_BEC_BORO>
    <BDGN_OUT_BEC_IM></BDGN_OUT_BEC_IM>
    <BDGN_OUT_USER_ID></BDGN_OUT_USER_ID>
</MXBI_CRM_018_ELV_PVT_MF>
         */

        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string Datu { get; set; }
        public string Pgm { get; set; }
        public string VlNumHous { get; set; }
        public string NmStrt { get; set; }
        public string NmBoro { get; set; }
        public string VlBin { get; set; }
        public string VlNumZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string ElaspedTime { get; set; }
        public string VlCommBd { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string BDGN_ACTIVE { get; set; }
        public string BDGN_OUT_UNIT { get; set; }
        public string BDGN_OUT_NAME { get; set; }
        public string BDGN_OUT_TITLE { get; set; }
        public string BDGN_OUT_COMMENT { get; set; }
        public string DGN_OUT_BEC_BORO { get; set; }
        public string BDGN_OUT_BEC_IM { get; set; }
        public string BDGN_OUT_USER_ID { get; set; }
        



    }
}
