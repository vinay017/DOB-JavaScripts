﻿namespace ExternalSystemIntegration.Objects
{
    public class PensBisJobInformationRequest : BaseRequest
    {
        public string BisJobNumber { get; set; }
        public string DocumentNumber { get; set; }
    }

    public class PensBisJobInformationResponse : BaseResponse
    {
        public string OverallText { get; set; }
        public string BisJobNumber { get; set; }
        public string DocumentNumber { get; set; }
        public string JobType { get; set; }
        public string JobBin { get; set; }
        public string JobBorough { get; set; }
        public string JobBlock { get; set; }
        public string JobLot { get; set; }
        public string JobHouseNumber { get; set; }
        public string JobStreetName { get; set; }
        public string JobAptCondoNumber { get; set; }
        public string JobZip { get; set; }
        public string ApplicantFirstName { get; set; }
        public string ApplicantLastName { get; set; }
        public string ApplicantEmail { get; set; }
        public string CommunityBoardNumber { get; set; }
        public string PlanExaminerBisId { get; set; }
        public string AppointmentDurationFlag { get; set; }
    }
}
