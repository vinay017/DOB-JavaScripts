﻿using ExternalSystemIntegration.Objects;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ExternalSystemIntegration
{
    [XmlRoot(ElementName = "MXBI_CRM_POASS_PC")]
    public class EXT_GetPAJobsByBinRequest : BaseRequest
    {

        //<MXBI_CRM_POASS_PC>
        //    <PC_DATA>
        //        <AllBin>1085867</AllBin>
        //        <StCodeKey>PA</StCodeKey>
        //        <AllCount>0001</AllCount>
        //        <BoroughKey>I</BoroughKey>
        //        <ReadSw>D</ReadSw>
        //    </PC_DATA>
        //</MXBI_CRM_POASS_PC>

        public EXT_PAJobsByBinRequest PC_DATA = new EXT_PAJobsByBinRequest();
    }



    public class EXT_PAJobsByBinRequest 
    {

        //<MXBI_CRM_POASS_PC>
        //    <PC_DATA>
        //        <AllBin>1085867</AllBin>
        //        <StCodeKey>PA</StCodeKey>
        //        <AllCount>0001</AllCount>
        //        <BoroughKey>I</BoroughKey>
        //        <ReadSw>D</ReadSw>
        //    </PC_DATA>
        //</MXBI_CRM_POASS_PC>

        [XmlElement]
        public string AllBin { get; set; }
        [XmlElement]
        public string AllCount { get; set; }
        [XmlElement]
        public string StCodeKey = "PA";
        [XmlElement]
        public string BoroughKey = "I";
        [XmlElement]
        public string ReadSw = "D";

    }






    [XmlRoot(ElementName = "MXBI_CRM_POASS_MF")]
    public class EXT_GetPAJobsByBinResponse 


    //        <?xml version="1.0" encoding="utf-16"?>
    //<MXBI_CRM_POASS_MF>
    //    <MF_RETURN_CODE>0</MF_RETURN_CODE>
    //    <MF_OVERALL_TEXT></MF_OVERALL_TEXT>
    //    <MF_MORE_ERRORS></MF_MORE_ERRORS>
    //    <MF_ERROR_TABLE></MF_ERROR_TABLE>
    //    <NotUsed></NotUsed>
    //    <AllControlNumber>11/06/1</AllControlNumber>
    //    <Datu>8</Datu>
    //    <Pgm>BXS1PRA3</Pgm>
    //    <VlNumbHous>251</VlNumbHous>
    //    <NmStrt>VESEY STREET</NmStrt>
    //    <NmBoro>MANHATTAN</NmBoro>
    //    <VlBin>1085867</VlBin>
    //    <VlNumbZip>10282</VlNumbZip>
    //    <VlTaxBlock>00016</VlTaxBlock>
    //    <VlTaxLot>07512</VlTaxLot>
    //    <VlCensTract>31703</VlCensTract>
    //    <VlHlthArea>8900</VlHlthArea>
    //    <HseLo></HseLo>
    //    <HseHi></HseHi>
    //    <GlJobType></GlJobType>
    //    <GlPageN>0001</GlPageN>
    //    <GlRecCountN>0000000077</GlRecCountN>
    //    <FoilIndicator></FoilIndicator>
    //    <DebugMsg></DebugMsg>
    //    <MF_DATA>
    //        <BoroughName></BoroughName>
    //        <NumbHous></NumbHous>
    //        <Strt></Strt>
    //        <TransactionExecuted>BXS1PRA3</TransactionExecuted>
    //        <Lines>
    //            <LinesTBL2>
    //                <Pra3Isn>0002307730</Pra3Isn>
    //                <Fd>06062014</Fd>
    //                <Job>121593702</Job>
    //                <Ap>02</Ap>
    //                <JobType>PA</JobType>
    //                <Demo></Demo>
    //                <FlrInjq>001</FlrInjq>
    //                <Gas></Gas>
    //                <Js>P</Js>
    //                <Jobstatus>APPROVED</Jobstatus>
    //                <Dt>06162014</Dt>
    //                <Applicant>ROCKWELL</Applicant>
    //                <Rep></Rep>
    //                <Jobdes>POST APPROVAL AMENDMENT FOR 01</Jobdes>
    //                <JAppLicNumberDisp></JAppLicNumberDisp>
    //                <JAuditCodeFlag></JAuditCodeFlag>
    //                <DiagramFlag>N</DiagramFlag>
    //                <ZoningDiagramStatus>N</ZoningDiagramStatus>
    //                <ZoningDiagramRecDate></ZoningDiagramRecDate>
    //                <DocType>PA</DocType>
    //                <FoundationAppDate></FoundationAppDate>
    //                <Bin>1085867</Bin>
    //            </LinesTBL2>
    //                </Lines>
    //    </MF_DATA>
    //</MXBI_CRM_POASS_MF>
    {

        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_ERROR_TABLE { get; set; }
        public string NotUsed { get; set; }
        public string AllControlNumber { get; set; }
        public string Datu { get; set; }
        public string Pgm { get; set; }
        public string VlNumbHous { get; set; }
        public string NmStrt { get; set; }
        public string NmBoro { get; set; }
        public string VlBin { get; set; }
        public string VlNumbZip { get; set; }
        public string VlTaxLot { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string HseLo { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string DebugMsg { get; set; }

        public BLines MF_DATA;

    }

    public class BLines
    {
        public List<LinesTBL2> Lines { get; set; }
    }

    public class LinesTBL2
    {
        //public string Pra3Isn
        //        <Fd>06062014</Fd>
        //        <Job>121593702</Job>
        //        <Ap>02</Ap>
        //        <JobType>PA</JobType>
        //        <Demo></Demo>
        //        <FlrInjq>001</FlrInjq>
        //        <Gas></Gas>
        //        <Js>P</Js>
        //        <Jobstatus>APPROVED</Jobstatus>
        //        <Dt>06162014</Dt>
        //        <Applicant>ROCKWELL</Applicant>
        //        <Rep></Rep>
        //        <Jobdes>POST APPROVAL AMENDMENT FOR 01</Jobdes>
        //        <JAppLicNumberDisp></JAppLicNumberDisp>
        //        <JAuditCodeFlag></JAuditCodeFlag>
        //        <DiagramFlag>N</DiagramFlag>
        //        <ZoningDiagramStatus>N</ZoningDiagramStatus>
        //        <ZoningDiagramRecDate></ZoningDiagramRecDate>
        //        <DocType>PA</DocType>
        //        <FoundationAppDate></FoundationAppDate>
        //        <Bin>1085867</Bin>

        public string Pra3Isn { get; set; }
        public string Fd { get; set; }
        public string Ap { get; set; }
        public string Job { get; set; }
        public string JobType { get; set; }
        public string Demo { get; set; }
        public string FlrInjq { get; set; }
        public string Gas { get; set; }

        public string Js { get; set; }
        public string Jobstatus { get; set; }
        public string Dt { get; set; }
        public string Applicant { get; set; }
        public string Rep { get; set; }
        public string Jobdes { get; set; }
        public string JAppLicNumberDisp { get; set; }
        public string JAuditCodeFlag { get; set; }

        public string DiagramFlag { get; set; }
        public string ZoningDiagramStatus { get; set; }
        public string ZoningDiagramRecDate { get; set; }
        public string DocType { get; set; }
        public string FoundationAppDate { get; set; }
        public string Bin { get; set; }
  
    }
}
