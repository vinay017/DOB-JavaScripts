﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_BoilerDetailsByBoilerNumberRequest : BaseRequest
    {
        public string Borough { get; set; }
        public string BiswebReporting { get; set; }
        public string BoroughKey { get; set; }
        public string BoilerType { get; set; }
        public string BoilerSerialNumber { get; set; }
        public string BoilerNumber { get; set; }
        public string AllEmailAddrCurrent { get; set; }
    }
}