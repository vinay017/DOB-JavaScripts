﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class PropertyProfileResponse : BaseResponse
    {
        public string ErrorMsg { get; set; }
        public string Bin { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string Borough { get; set; }
        public string Zipcode { get; set; }
        public string HealthArea { get; set; }
        public string CensusTract { get; set; }
        public string CommunityBoard { get; set; }
        public string BuildingsOnLot { get; set; }
        public string TaxLot { get; set; }
        public string TaxBlock { get; set; }
        public string Condo { get; set; }
        public string Vacant { get; set; }
        public string Street { get; set; }
        public string StreetNumbers { get; set; }
        public string CrossStreet1 { get; set; }
        public string CrossStreet2 { get; set; }
        public string CrossStreet3 { get; set; }
        public string CrossStreet4 { get; set; }
        public string CrossStreet5 { get; set; }
        public string CrossStreet6 { get; set; }
        public string CrossStreet1Numbers { get; set; }
        public string CrossStreet2Numbers { get; set; }
        public string CrossStreet3Numbers { get; set; }
        public string CrossStreet4Numbers { get; set; }
        public string CrossStreet5Numbers { get; set; }
        public string CrossStreet6Numbers { get; set; }
        public string DOBSpecialPlaceName { get; set; }
        public string DOBBuildingRemarks { get; set; }
        public string LandmarkStatus { get; set; }
        public string SpecialStatus { get; set; }
        public string LocalLaw { get; set; }
        public string LoftLaw { get; set; }
        public string SRORestrict { get; set; }
        public string TARestrict { get; set; }
        public string UBRestrict { get; set; }
        public string EnvironmentalRestrictions { get; set; }
        public string GrandfatheredSign { get; set; }
        public string LegalAdultUse { get; set; }
        public string CityOwned { get; set; }
        public string AditionalBINsForbuilding { get; set; }
        public string SpecialDistrict { get; set; }
        public string VlFinaOccpncy { get; set; }
        public string TidalWetlands { get; set; }
        public string FreshwaterWetlands { get; set; }
        public string CoastalErosionHazardArea { get; set; }
        public string SpecialFloodHazardArea { get; set; }
        public string ProtectedProperty { get; set; }

        public List<string> OtherBinsList { get; set; }
        public List<string> streetList { get; set; }

        public List<string> SpecialArea { get; set; }
        public string DotProtectedStreet { get; set; }
        public string AffordableHousing { get; set; }
        public string ScaUpk  { get; set; }
        public string PDHSFacility { get; set; }
        public string Class1ViolFlag { get; set; }
        public string CDispositionFlag { get; set; }
        public string ShowFineFlag { get; set; }
        public string PVacateFlag { get; set; }
        public string PadLockFlag { get; set; }
        public string PBuyoutFlag { get; set; }
        public string SandyDemoFlag { get; set; }
        public string DHCRFlag { get; set; }
        public DOFOwnerInformation DOFOwnerInfo = new DOFOwnerInformation();
        public ZonningSummary ZonningInfo = new ZonningSummary();

    }

    public class ZonningSummary
    {
        public string District1 { get; set; }
        public string District2 { get; set; }
        public string District3 { get; set; }
        public string SpecialDistrict1 { get; set; }
        public string SpecialDistrict2 { get; set; }
        public string CommercialOverlay1 { get; set; }
        public string CommercialOverlay2 { get; set; }
    }

    public class GetPropertyFlagsResponse : BaseResponse
    {
        public AgencyNumberValidationResponse GlobalFlags = new AgencyNumberValidationResponse();
        public List<PropertyFlags> PropertyFlagsList = new List<PropertyFlags>();
    }

    public class PropertyFlags
    {
        public string TaxLot { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string DobLowHouseNumber { get; set; }
        public string DobHighHouseNumber { get; set; }
        public string VerifyType { get; set; }
        public string LandmarkStatus { get; set; }
        public string Bin { get; set; }
        public string BinInd { get; set; }
        public string ObsoleteFlag { get; set; }

    }

    public class DOFOwnerInformation
    {
        public string Name { get; set; }
        public string OwnerCorporationName { get; set; }
        public string Address { get; set; }
        public string CityStateZip { get; set; }
       
    }
}
