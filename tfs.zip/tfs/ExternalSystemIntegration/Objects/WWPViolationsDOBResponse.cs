﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class WWPViolationsDOBResponse
    {
        public string ReturnError { get; set; }
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string MF_MORE_ERRORS { get; set; }
        public string MF_ERROR_TABLE { get; set; }
        public string Pgm { get; set; }
        public string VlNumbHous { get; set; }
        public string NmStrt { get; set; }
        public string NmBoro { get; set; }
        public string VlBin { get; set; }
        public string VlNumbZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }

        public List<DOBViolationsWWP> DOBViolationsList = new List<DOBViolationsWWP>();
    }

    public class DOBViolationsWWP
    {
        public string ApplTransText { get; set; }
        public string ApplNumOcv3 { get; set; }
        public string ApplStatus { get; set; }
        public string ApplDate { get; set; }
        public string OvDateTxt { get; set; }
        public string OvDisDateN2k { get; set; }
        public string OvBadgeTxt { get; set; }
        public string OvDisBadge { get; set; }
        public string OvAgncyTxt { get; set; }
        public string OvDisAgncy { get; set; }
        public string LnoTag { get; set; }
        public string LnoArea { get; set; }
        public string Comment1 { get; set; }
        public string Comment2 { get; set; }
        public string Isn { get; set; }
        public string DrillType { get; set; }
        public string OAModelExp { get; set; }
        public string ViDOBNOWIdV3 { get; set; }
    }
}

