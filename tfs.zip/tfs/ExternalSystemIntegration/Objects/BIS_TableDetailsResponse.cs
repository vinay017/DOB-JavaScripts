﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BIS_TableDetailsResponse 
    {
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string Datu { get; set; }
        public string Pgm { get; set; }
        public string GlRecCountN { get; set; }
        public string TotalRecsTable { get; set; }
        
        public List<string> BisTableDefinitions = new List<string>();
    }

    public class TableValue
    {
        public string BisTableDescription { get; set; }
    }
}

