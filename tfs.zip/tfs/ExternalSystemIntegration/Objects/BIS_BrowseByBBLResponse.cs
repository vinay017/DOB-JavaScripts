﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BIS_BrowseByBBLResponse
    {
        public string MF_RETURN_CODE { get; set; }
        public string MF_OVERALL_TEXT { get; set; }
        public string GlRecCountN { get; set; }
        public List<TaxLotDetials> LotList = new List<TaxLotDetials>();
        
    }

    public class TaxLotDetials
    {
        public string TaxLot { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string Borough { get; set; }
        public string Zipcode { get; set; }
        public string BIN { get; set; }
        public string ObsoleteFlag { get; set; }
    }
}
