﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;


namespace ExternalSystemIntegration
{
    public class ExternalSystem_LicenseValidation
    {
        StringBuilder Trace = new StringBuilder();

        public LicenseValidationReponse GetLicenseDetails(LicenseValidationRequest request)
        {
            LicenseValidationReponse response = new LicenseValidationReponse();
            try
            {
                Trace.AppendLine("GetLicenseDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.LicenseNumber != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CR3.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType);

                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetLicenseDetails", Trace.ToString(), " LicenseValidation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetLicenseDetails", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
                return response;
            }
        }

        internal LicenseValidationReponse GetExternalSystemResponse(string requestObj)
        {
            LicenseValidationReponse response = new LicenseValidationReponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.ErrorMsg = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.ErrorMsg);
                response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlNumHous);
                response.StreetName = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.NmStrt);
                response.Borough = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.NmBoro);
                response.Bin = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlBin);
                response.Zipcode = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlNumZip);
                response.Block = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlTaxBlock);
                response.Lot = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlTaxLot);
                response.CensusTract = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlCensTract);
                response.HealthArea = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.VlHlthArea);
                response.JobType = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.GlJobType);
                response.PageNumber = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.GlPageN);
                response.RecCountNumber = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.FoilIndicator);
                response.LicenseNumber = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_LICENSE_NUMBER);
                response.LicenseType = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_LICENSE_TYPE);
                response.Status = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_STATUS);

                response.BusinessName1 = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_1)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_1).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_1).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_1);

                response.RequiredFlag_GLI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_REQUIRED_FLAG_AFF1);
                response.CompanyName_GLI_1 = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF1)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF1).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF1).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF1);

               // response.CompanyName_GLI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF1);
                response.ExpirationDate_GLI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_EXP_DATE_AFF1);
                response.Policy_GLI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_POLICY_AFF1);

                response.RequiredFlag_WCI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_REQUIRED_FLAG_AFF1);

                response.CompanyName_WCI_1 = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF1)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF1).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF1).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF1);

               // response.CompanyName_WCI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF1);
                response.ExpirationDate_WCI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_EXP_DATE_AFF1);
                response.Policy_WCI_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_POLICY_AFF1);

                response.RequiredFlag_DIS_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_REQUIRED_FLAG_AFF1);

                response.CompanyName_DIS_1 = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF1)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF1).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF1).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF1);

               // response.CompanyName_DIS_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF1);
                response.ExpirationDate_DIS_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_EXP_DATE_AFF1);
                response.Policy_DIS_1 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_POLICY_AFF1);


                response.BusinessName2 = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_2)) &&
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_2).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_2).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_NAME_2);

                response.RequiredFlag_GLI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_REQUIRED_FLAG_AFF2);
                response.CompanyName_GLI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_COMP_NAME_AFF2);
                response.ExpirationDate_GLI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_EXP_DATE_AFF2);
                response.Policy_GLI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_GLI_POLICY_AFF2);

                response.RequiredFlag_WCI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_REQUIRED_FLAG_AFF2);
                response.CompanyName_WCI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_COMP_NAME_AFF2);
                response.ExpirationDate_WCI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_EXP_DATE_AFF2);
                response.Policy_WCI_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_WCI_POLICY_AFF2);

                response.RequiredFlag_DIS_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_REQUIRED_FLAG_AFF2);
                response.CompanyName_DIS_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_COMP_NAME_AFF2);
                response.ExpirationDate_DIS_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_EXP_DATE_AFF2);
                response.Policy_DIS_2 = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_DIS_POLICY_AFF2);

                response.EXPIRE_DATE = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_EXPIRE_DATE);
                response.ApplicantLastName = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_LAST_NAME);
                response.ApplicantFirstName = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_FIRST_NAME);
                response.ApplicantInitial = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_INITIAL);
                response.ApplicantHouseNo = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_HOUSE_NUMBER);
                response.ApplicantStreet = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_STREET_NAME);
                response.ApplicantCity = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_CITY);
                response.ApplicantState = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_STATE);
                response.ApplicantZip = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_ZIP);
                response.ApplicantMobile = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_MOBILE);
                response.ApplicantPhone = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_PHONE);
                response.ApplicantFax = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_FAX);
                response.ApplicantEmail = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_APPL_EMAIL);
                response.BusinessPhone = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_PHONE);
                response.BusinessFax = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_FAX);
                response.BusinessEmail = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_EMAIL);
                response.BusinessHouseNo = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_HOUSE_NUMBER);
                response.BusinessStreetName = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_STREET_NAME);
                response.BusinessAddressLine = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_ADDR_LINE_2);
                response.BusinessCity = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_CITY);
                response.BusinessState = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_STATE);
                response.BusinessZip = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_BUS_ZIP);
                response.LicenseClass = Common.GetAttributeValueFromResponse(responseString, LicenseResponseAttributeTags.L_LICENSE_CLASS);

                Trace.AppendLine("License Status" + response.Status.ToString());
                DOBLogger.WriteCommunicationLog("License Response log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " LicenseValidation trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
            }
        }
    }
}
