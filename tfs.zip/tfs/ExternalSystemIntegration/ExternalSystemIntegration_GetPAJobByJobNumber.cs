﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;
using ExternalSystemIntegration.CommonHandler;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetPAJobByJobNumber : SerializeHandler
    {

        StringBuilder crmTrace = new StringBuilder();

        public T2 GetPAJobsByJobNumber<T1, T2>(T1 request, T2 response, string JobFilingNumber, string SourceChannel, string UserID, string methodName)
        {

            string bisResponseString = string.Empty;
            try
            {
                crmTrace.AppendLine("GetPAJobsByJobNumber - Start");
                string requestString = SerializeObject(request);
                StringBuilder requestStringBuilder = new StringBuilder();
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                
                bisResponseString = GetBisResponse(request, requestString, crmTrace);

                response = DeSerializeXML(bisResponseString, response);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingNumber, SourceChannel, methodName, crmTrace.ToString(), "  Trace log", UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(UserID, SourceChannel, methodName, ex.Message, DOB.Logging.LogLevelL4N.ERROR, UserID, "Exception Details", "ExternalSystemIntegration_GetPAJobByJobNumber Class - GetPAJobsByJobNumber Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
            return response;
        }
    }
}
