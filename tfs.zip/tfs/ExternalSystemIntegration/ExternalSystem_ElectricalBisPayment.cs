﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;
using System.Xml.Serialization;
using System.IO;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_ElectricalBisPayment
    {
        StringBuilder Trace = new StringBuilder();
        public ElectricalBisPaymentResponse GetFirmPaymentInfo(ElectricalBisPaymentRequest request)
        {
            ElectricalBisPaymentResponse response = null;
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("Get Agency number Validation - Start");
                string requestString = SerializeObject(request);
                StringBuilder requestStringBuilder = new StringBuilder();
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                bisResponseString = GetBisResponse(request, requestString);

                response = DeSerializeXML(bisResponseString);
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetAgencyNumberInformation", Trace.ToString(), "Agency Number Information Trace Log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetAgencyNumberInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_AgencyNumberValidation Class - GetAgencyNumberInformation Method Exceptions", "browserinfo");
                return response;
            }
            return response;
        }
        internal string GetBisResponse(ElectricalBisPaymentRequest request, string inputXML)
        {
            try
            {
                //string requestBuilder = MessageStrings.MXBI_CR6.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType).Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count);
                Trace.AppendLine("GetExternalSystemResponse Started!");

                ServiceSoapClient webClient = new ServiceSoapClient();
                string bisResponseString = webClient.CALLBROKERXML(inputXML);
                Trace.AppendLine("GetExternalSystemResponse Ended!");
                return bisResponseString;
            }
            catch (SoapException ex)
            {
                throw ex;
            }

        }


        private string SerializeObject(ElectricalBisPaymentRequest request)
        {
            string inputXML = string.Empty;
            Console.WriteLine("Writing With XmlTextWriter");
            try
            {
                //XmlSerializer serializer = new XmlSerializer(typeof(PC_DATA));
                //using (MemoryStream memStm = new MemoryStream())
                //{
                //    serializer.Serialize(memStm, request);
                //    memStm.Position = 0;
                //    inputXML = new StreamReader(memStm).ReadToEnd();
                //}
                var emptyNamepsaces = new XmlSerializerNamespaces(new[] { XmlQualifiedName.Empty });
                var serializer = new XmlSerializer(typeof(ElectricalBisPaymentRequest));
                var settings = new XmlWriterSettings();
                settings.Indent = true;
                settings.OmitXmlDeclaration = true;

                using (var stream = new StringWriter())
                using (var writer = XmlWriter.Create(stream, settings))
                {
                    serializer.Serialize(writer, request, emptyNamepsaces);
                    return stream.ToString();
                }
            }
            catch (Exception ex)
            {
            }
            return inputXML;
        }

        private ElectricalBisPaymentResponse DeSerializeXML(string xml)
        {
            StringReader strReader = null;
            XmlSerializer serializer = null;
            XmlTextReader xmlReader = null;
            ElectricalBisPaymentResponse response = null;
            try
            {
                strReader = new StringReader(xml);
                serializer = new XmlSerializer(typeof(ElectricalBisPaymentResponse));
                xmlReader = new XmlTextReader(strReader);
                response = (ElectricalBisPaymentResponse)serializer.Deserialize(xmlReader);
            }
            catch (Exception exp)
            {
                throw new Exception("Error in processing the xml. Detail exception :" + exp.Message);
            }
            finally
            {
                if (xmlReader != null)
                {
                    xmlReader.Close();
                }
                if (strReader != null)
                {
                    strReader.Close();
                }
            }
            return response;
        }
    }
}
