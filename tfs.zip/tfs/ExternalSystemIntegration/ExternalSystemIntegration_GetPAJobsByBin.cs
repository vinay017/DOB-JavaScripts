﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;
using System.IO;
using System.Xml.Serialization;
using ExternalSystemIntegration.CommonHandler;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetPAJobsByBin : SerializeHandler
    {
        StringBuilder crmTrace = new StringBuilder();

        public T2 GetPAJobsByBin<T1, T2>(T1 request, T2 response, string JobFilingNumber, string SourceChannel, string UserID, string methodName)
        {

            string bisResponseString = string.Empty;
            try
            {
                crmTrace.AppendLine("Validate Violation Number - Start");
                string requestString = SerializeObject(request);
                StringBuilder requestStringBuilder = new StringBuilder();
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                // string requestString = "<CRMI_0VI_PC><PC_DATA><PC_CRM_DOB_VIOL_NUMBER_FULL>021518E1234H123456</PC_CRM_DOB_VIOL_NUMBER_FULL><PC_CRM_DOB_VIOL_SEQ_NUMBER>123456</PC_CRM_DOB_VIOL_SEQ_NUMBER><PC_CRM_CEASE_USE>Y</PC_CRM_CEASE_USE><PC_CRM_VIOLATION_TYPE>ELEVATOR</PC_CRM_VIOLATION_TYPE><PC_CRM_VIOL_ISSUE_DATE>2018-03-16</PC_CRM_VIOL_ISSUE_DATE><PC_CRM_BADGE_NUMBER>1234</PC_CRM_BADGE_NUMBER><PC_CUSTOM_PC_INTERFACE_ID>CRMI_0VI</PC_CUSTOM_PC_INTERFACE_ID></PC_DATA></CRMI_0VI_PC>";
                //string requestString = "<MXBI_CRM_POASS_PC><PC_DATA><AllBin>1085867</AllBin><StCodeKey>PA</StCodeKey><AllCount>0001</AllCount><BoroughKey>I</BoroughKey><ReadSw>D</ReadSw></PC_DATA></MXBI_CRM_POASS_PC>";

                bisResponseString = GetBisResponse(request, requestString, crmTrace);

                response = DeSerializeXML(bisResponseString, response);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingNumber, SourceChannel, methodName, crmTrace.ToString(), "  Trace log", UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(UserID, SourceChannel, methodName, ex.Message, DOB.Logging.LogLevelL4N.ERROR, UserID, "Exception Details", "ExternalSystem_ValidateElavatorViolationNumbere Class - AllElevatorDOBViolationMethods Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
            return response;
        }
    }
}
