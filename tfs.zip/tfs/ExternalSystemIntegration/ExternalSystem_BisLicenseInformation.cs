﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Xml.Linq;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_BisLicenseInformation
    {
        StringBuilder Trace = new StringBuilder();
        public BisLicenseInformationResponse GetBisLicenseInformation(BisLicenseInformationRequest request)
        {
            BisLicenseInformationResponse response = new BisLicenseInformationResponse();
            try
            {
                Trace.AppendLine("Get Bis License Information!");
                string requestBuilder = string.Empty;
                if (request != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    if (!string.IsNullOrEmpty(request.Email))
                        requestBuilder = MessageStrings.MXBI_CR5.Replace(RequestAttributes.PRM_BUILDNYC_EMAIL, request.Email);
                    if(!string.IsNullOrEmpty(request.LicenseTypeNoSpaceDelimit))
                        requestBuilder = MessageStrings.MXBI_CR8.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENOTYPESPACEDELIMIT, request.LicenseTypeNoSpaceDelimit);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBisLicenseInformation", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBisLicenseInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetBisLicenseInformation Method Exceptions", "browserinfo");
                return response;
            }


        }

        internal BisLicenseInformationResponse GetExternalSystemResponse(string requestObj)
        {
            BisLicenseInformationResponse response = new BisLicenseInformationResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.Fin = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.Fin);
                response.ErrorMessage = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.ErrorMsg);
                response.Date = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.Date);
                response.Pgm = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.Pgm);
                response.VinNumberHours = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlNumHous);
                response.NmStreet = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.NmStrt);
                response.NmBorough = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.NmBoro);
                response.ViZip = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlNumZip);
                response.VitaxBlock = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlTaxBlock);
                response.ViTaxLot = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlTaxLot);
                response.ViCensTract = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlCensTract);
                response.ViHithArea = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlHlthArea);
                response.ElapsedTime = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.ElaspedTime);
                response.ViCommBd = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.VlCommBd);
                response.HseHi = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.HseHi);
                response.GIJobType = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.GlJobType);
                response.GiPageN = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.GlPageN);
                response.GiRecCountN = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.FoilIndicator);

                #region GetListValues
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("CRM");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    LicenseDetails detailsList = new LicenseDetails();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.ReBusName = !string.IsNullOrEmpty(Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_BUS_NAME)) &&
                        Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_BUS_NAME).Contains("&amp;") ?
                        Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_BUS_NAME).Replace("&amp;", "&") :
                        Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_BUS_NAME);

                    detailsList.ReEmailAddress = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_EMAIL_ADDR);
                    detailsList.ReAppType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_APP_TYPE);
                    detailsList.ReAppNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_APP_NUMBER);
                    detailsList.ReLastName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_LAST_NAME);
                    detailsList.ReFirstName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_FIRST_NAME);
                    detailsList.ReStatus = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_STATUS);
                    detailsList.ReStatusDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_STATUS_DATE);
                    detailsList.RePassword = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PASSWORD);
                    detailsList.RePrepAddress = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_ADDRESS);
                    detailsList.RePrepCity = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_CITY);
                    detailsList.RePrepState = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_STATE);
                    detailsList.RePrepZip = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_ZIP);
                    detailsList.RePrepPhone = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_PHONE);
                    detailsList.RePrepMobile = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BisLicenseInformation.RE_PREP_MOBILE);

                    response.detailList.Add(detailsList);
                }
                #endregion EndGetListValues

                response.SustianableLink = Common.GetAttributeValueFromResponse(responseString, BisLicenseInformation.SHOW_SUSTAINABLE_LINK);

                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " Bis License Information trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_BisLicenseInformation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
            }
        }
    }
}
