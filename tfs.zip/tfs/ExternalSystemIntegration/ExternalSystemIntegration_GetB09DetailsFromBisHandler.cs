﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetB09DetailsFromBisHandler
    {
        StringBuilder Trace = new StringBuilder();

        public ExternalSystem_Bo9DetailsFromBisResponse GetBo9DetailsFromBIS(ExternalSystem_Bo9DetailsFromBisRequest request)
        {
            Trace.AppendLine("GetBoilerComplianceDetails Started");
            ExternalSystem_Bo9DetailsFromBisResponse response = new ExternalSystem_Bo9DetailsFromBisResponse();
            try
            {
                Trace.AppendLine("GetElevatorDetails start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.DeviceId != null && request.AllCount != null && request.BoroughKey != null && request.ReadSw != null && request.FinFlag != null && request.BiswebReporting != null)
                {
                    Trace.AppendLine("RequestBuilder Started for GetBo9DetailsFromBIS");
                    requestBuilder = MessageStrings.MXBI_CRM_014_BOL_RES_PC.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_ALLKEY, request.DeviceId);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_ALLCOUNT, request.AllCount);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_KEYBOROUGH, request.BoroughKey);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_BISWEBREP, request.BiswebReporting);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_FIN, request.FinFlag);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_READSW, request.ReadSw);
                    requestBuilder = requestBuilder.Replace(BoilerComplianceDetailsRequestAttributesTags.PRM_ALLEMAILADDRCURRENT, request.AllEmailAddrCurrent);

                    Trace.AppendLine("RequestBuilder Ended for GetBo9DetailsFromBIS");
                    Trace.AppendLine("request for GetBo9DetailsFromBIS :" + requestBuilder);

                    response = GetExternalSystemResponseForBo9ListByDeviceId(requestBuilder);
                }
                Trace.AppendLine("GetBo9DetailsFromBIS End");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBo9DetailsFromBIS", Trace.ToString(), " GetBoilerComplianceDetails trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBo9DetailsFromBIS", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystemIntegration_GetB09DetailsFromBisHandler Class - GetBo9DetailsFromBIS Method Exceptions", "browserinfo");
                return response;
            }
        }

        internal ExternalSystem_Bo9DetailsFromBisResponse GetExternalSystemResponseForBo9ListByDeviceId(string requestObj)
        {
            ExternalSystem_Bo9DetailsFromBisResponse response = new ExternalSystem_Bo9DetailsFromBisResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponseForBo9ListByDeviceId Started");
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.MF_RETURN_CODE);
                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.MF_OVERALL_TEXT);
                response.MoreError = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.MF_MORE_ERRORS);
                response.ErrorArray = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.MFErrorArray);
                response.AllControlNumber = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.AllControlNumber);
                if (response.ReturnCode == "0")
                {
                    response.VlCensTract = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.VlCensTract);
                    response.VlHlthArea = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.VlHlthArea);
                    response.GlJobType = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.GlJobType);
                    response.GlPageN = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.GlPageN);
                    response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.GlRecCountN);
                    response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.FoilIndicator);
                    response.DebugMsg = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.DebugMsg);
                    response.PremisesAddress = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.AllNumbhous) + " " + Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.AllStrt) + " " + Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.AllBoro);
                    response.ZipCode = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.AllZip);
                    response.LocatedBlock = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.VlTaxBlock);
                    response.LocatedLot = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.VlTaxLot);
                    response.HasLow = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.HseLo);
                    response.HasHigh = Common.GetAttributeValueFromResponse(responseString, BoilerComplianceDetailsResponseAttributesTags.HseHi);

                    #region Get Realted Bo9's
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(responseString);
                    XmlElement root = xDoc.DocumentElement;
                    XmlNodeList bo9sListFromBis = root.GetElementsByTagName("Boiler601");

                    if (bo9sListFromBis != null && bo9sListFromBis.Count > 0)
                    {
                        for (int i = 0; i < bo9sListFromBis.Count; i++)
                        {
                            BIS_Bo9Details bisBo9Obj = new BIS_Bo9Details();
                            string innerXmlNodeOfBo9Tag = bo9sListFromBis[i].InnerXml;
                            bisBo9Obj.EntryDate = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplEntryDate);
                            bisBo9Obj.InspectionDate = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplInspDate);
                            bisBo9Obj.RecieveDate = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplRecvDate);
                            bisBo9Obj.Name = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplName);
                            bisBo9Obj.NysCertificate = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplNumber);
                            bisBo9Obj.DefectStatus = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.ComplVioFlagResults);
                            bisBo9Obj.InspectionType = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.BnInspType);
                            bisBo9Obj.Source = Common.GetAttributeValueFromResponse(innerXmlNodeOfBo9Tag, BoilerComplianceDetailsResponseAttributesTags.Source);
                            response.bo9DetailsFromBis.Add(bisBo9Obj);
                        }
                    }
                    #endregion Get Realted Bo9's

                    response.IsSuccess = true;
                }
                else
                {
                    response.IsSuccess = false;
                    return response;
                }
                DOBLogger.WriteCommunicationLog("GetExternalSystemResponseForBo9ListByDeviceId log", Brequest.SourceChannel, "GetExternalSystemResponseForBo9ListByDeviceId", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponseForBo9ListByDeviceId Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponseForBo9ListByDeviceId", Trace.ToString(), " GetExternalSystemResponseForBo9ListByDeviceId trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponseForBo9ListByDeviceId", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystemIntegration_GetB09DetailsFromBisHandler Class - GetExternalSystemResponseForBo9ListByDeviceId Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
            }
        }
    }
}
