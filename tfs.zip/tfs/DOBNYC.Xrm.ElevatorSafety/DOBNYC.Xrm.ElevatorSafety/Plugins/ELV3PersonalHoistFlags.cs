﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// Plugin to set ELV3 Personal Hoist Validation Flags on Submission of ELV3
    /// Register on  Entity
    ///         * Pre-Update Stage - Synchronous - Server - Calling user - Exe order (3) - dobnyc_elv3 (primary)
    /// Date: 12/26/2017
    /// Written By: Mayank 
    /// </summary>
    public class ELV3PersonalHoistFlags : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");

                customTrace.AppendLine("context.Depth : " + context.Depth);
              
                if (context.Depth > 3)
                    return;

                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                    return;

                customTrace.AppendLine("Begin Get Pre-Image..");
                Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;

                if (context.MessageName == PluginHelperStrings.UpdateMessageName 
                    && targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName 
                    && preImage.Contains(ELV3InspectionAttributeNames.ReportType)
                    && targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value==(int)ELV3UserFilingActions.File
                    )
                {
                    DateTime elv3InspectionDate;
                    DateTime elv3SubmissionDate;
                    DateTime? tnfSubmitDate = null;
                    DateTime? tempRenewalExpiryDate = null;

                    elv3InspectionDate = preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate);
                    customTrace.AppendLine("elv3InspectionDate " + elv3InspectionDate.ToShortDateString());
                    elv3SubmissionDate =targetEntity.Contains(ELV3InspectionAttributeNames.SubmissionDate)? targetEntity.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.SubmissionDate) : preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.SubmissionDate);
                    customTrace.AppendLine("elv3SubmissionDate " + elv3SubmissionDate.ToShortDateString());
                    
                    int dateDiff = CalculateBusinessDays(elv3InspectionDate,elv3SubmissionDate );//#bug fix 9604
                    int calendarDaysDiff = 0;
                    customTrace.AppendLine("dateDiff " + dateDiff);
                    if (dateDiff > 1)
                    {
                        customTrace.AppendLine("Inspection date ahead by 1 business day from elv3 submission date");
                        targetEntity[ELV3InspectionAttributeNames.InspectionDateAhead1Day] = true;
                    }

                    if (preImage.Contains(ELV3InspectionAttributeNames.TNFId) && preImage[ELV3InspectionAttributeNames.TNFId] !=null)
                    {
                        customTrace.AppendLine("tnf submitted");
                        targetEntity[ELV3InspectionAttributeNames.TNFSubmitted] = true;
                        EntityReference tnfRef = preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.TNFId);
                        Entity tnf = serviceConnector.Retrieve(ELV36TestNotificationAttributeNames.EntityLogicalName, tnfRef.Id, new ColumnSet(new string[] { ELV36TestNotificationAttributeNames.SubmittedDate }));

                        //tnf 3 business days logic here
                        tnfSubmitDate = tnf.GetAttributeValue<DateTime?>(ELV36TestNotificationAttributeNames.SubmittedDate);
                        customTrace.AppendLine("tnfSubmitDate " + tnfSubmitDate.Value.ToShortDateString());

                        dateDiff = CalculateBusinessDays(tnfSubmitDate.Value, elv3InspectionDate);
                        calendarDaysDiff = Convert.ToInt32((elv3InspectionDate - tnfSubmitDate.Value ).TotalDays);
                        targetEntity[ELV3InspectionAttributeNames.TNFSubmittedAdvanceDays] = calendarDaysDiff;
                        if (dateDiff >= 3)
                        {
                            customTrace.AppendLine("tnf submitted 3 days advance");
                            targetEntity[ELV3InspectionAttributeNames.TNFSubmitted3DaysAdvance] = true;
                        }

                    }
                    if (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportType).Value == 2)
                    {
                        //fetch previous 90 day temp renewal                    
                        QueryByAttribute query = new QueryByAttribute(ElevatorMasterDevice.EntityLogicalName);
                        query.ColumnSet = new ColumnSet(new string[] { ElevatorMasterDevice.PH_TempRenewalExpiry,ElevatorMasterDevice.LatestApplication });
                        query.AddAttributeValue(ElevatorMasterDevice.EntityId, preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id);//90 day temp renewal
                        EntityCollection deviceResults = serviceConnector.RetrieveMultiple(query);
                        if (deviceResults.Entities.Count == 1)
                        {
                            customTrace.AppendLine("PH_TempRenewalExpiry");
                            tempRenewalExpiryDate = deviceResults.Entities[0].GetAttributeValue<DateTime?>(ElevatorMasterDevice.PH_TempRenewalExpiry);
                            customTrace.AppendLine("PH_TempRenewalExpiry1");
                            if (tempRenewalExpiryDate.HasValue)
                            {
                                if (tnfSubmitDate.HasValue)
                                {
                                    customTrace.AppendLine("tnfSubmitDate.HasValue" + tnfSubmitDate.HasValue + " compare " + DateTime.Compare(tempRenewalExpiryDate.Value, tnfSubmitDate.Value));
                                    if (tnfSubmitDate.HasValue && DateTime.Compare(tempRenewalExpiryDate.Value, tnfSubmitDate.Value) < 0)//allow last date also
                                    {
                                        customTrace.AppendLine("Temp Renewal Expired On TNF Submit Date");
                                        targetEntity[ELV3InspectionAttributeNames.TempRenewalExpiredOnTNFSubmitDate] = true;
                                    }
                                }
                               
                                if (DateTime.Compare(tempRenewalExpiryDate.Value, elv3InspectionDate) < 0) //allow last date also
                                {
                                    customTrace.AppendLine("Temp Renewal Expired On Inspection Date");
                                    targetEntity[ELV3InspectionAttributeNames.TempRenewalExpiredOnInspectionDate] = true;
                                }
                            }
                        }
                        //throw new Exception("" + customTrace);
                        #region Check Build Permit Expire Condition
                        if(deviceResults.Entities[0].Contains(ElevatorMasterDevice.LatestApplication) && deviceResults.Entities[0][ElevatorMasterDevice.LatestApplication] !=null)
                        {
                            customTrace.AppendLine("PH_TempRenewalExpiry1");
                            deviceResults = getElevatorPermits(deviceResults.Entities[0].GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestApplication).Id, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate), customTrace, serviceConnector);
                            //if deviceresults >0 that measns we have a valid permit with that inspection date else no valid permit

                            customTrace.AppendLine("Get Permit records: " + deviceResults.Entities.Count);
                            customTrace.AppendLine("if deviceresults >0 that measns we have a valid permit with that inspection date else no valid permit");
                            if(deviceResults.Entities.Count<=0)
                            {
                                customTrace.AppendLine("Permit is expired before inspection date");
                                targetEntity[ELV3InspectionAttributeNames.BuildPermitExpired] = true;
                            }
                        }
                        #endregion



                    }
                }
                
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                crmTracing.Trace(customTrace.ToString());
               // throw ex;
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
               // throw ex;
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                //throw ex;
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3PersonalHoistFlags" + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }


        private  EntityCollection getElevatorPermits(Guid ApplicationID, DateTime InspectionDate,StringBuilder crmTrace, IOrganizationService service)
        {
            EntityCollection records = new EntityCollection();

            try
            {
               
                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='dobnyc_elevatorpermit'>
                                        <attribute name='dobnyc_name' />
                                        <attribute name='createdon' />
                                        <attribute name='dobnyc_elvp_permitdate' />
                                        <attribute name='dobnyc_elvp_elevatortype' />
                                        <attribute name='dobnyc_elvp_elevatorpermitstatus' />
                                        <attribute name='dobnyc_elvp_applicationnumber' />
                                        <attribute name='dobnyc_elp_elevatorexpirydate' />
                                        <attribute name='dobnyc_elevatorpermitid' />
                                        <order attribute='createdon' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_elvp_permitdate' operator='on-or-before' value='{0}' />
                                          <condition attribute='dobnyc_elp_elevatorexpirydate' operator='on-or-after' value='{0}' />
                                          <condition attribute='dobnyc_elv_permitstatus' operator='eq' value='4' />
                                          <condition attribute='dobnyc_elvp_applicationnumber' operator='eq'  uitype='dobnyc_elevatorapplication' value='{1}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                fetchXml = string.Format(fetchXml, InspectionDate.ToString("yyyy-MM-dd"),ApplicationID.ToString());



                if (fetchXml != string.Empty)
                {
                    records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                }

              
            }
            catch (Exception ex)
            {
                DOBLogger.WriteExceptionLog("", "CRM", "ELV3PersonalHoistFlags" + " - CalculateBusinessDays method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            return records;


        }

        private int CalculateBusinessDays(DateTime startDate, DateTime endDate)
        {
            int noOfDays = 0;
            try
            {
                while (DateTime.Compare(startDate, endDate) < 0)
                {
                    if (startDate.DayOfWeek != DayOfWeek.Saturday && startDate.DayOfWeek != DayOfWeek.Sunday)
                    {
                        noOfDays += 1;
                    }
                    startDate = startDate.AddDays(1);
                }
            }            
            catch (Exception ex)
            {
                DOBLogger.WriteExceptionLog("", "CRM", "ELV3PersonalHoistFlags" + " - CalculateBusinessDays method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

            return noOfDays;
        }
    }
}
