﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// Plugin to copy defects from device master and associate with new ELV29 record
    /// Register on  
    ///     * Post-Create Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_elv29 (primary)
    ///    
    /// Date: 1/11/2018
    /// Written By: Mayank 
    /// </summary>
    public class ELV29CopyReportDefects : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity.Contains(ELV29AffirimationAttributeNames.Elv3Lookup))
                {
                    customTrace.AppendLine("ELV3 id" + targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id);
                    //fetch Master defects
                    QueryExpression query = new QueryExpression(ReportDefectEntityAttributeNames.EntityLogicalName);
                    query.ColumnSet = new ColumnSet(new string[] { ReportDefectEntityAttributeNames.ReportDefectId });
                    query.Criteria = new FilterExpression(LogicalOperator.And);
                    query.Criteria.AddCondition(ReportDefectEntityAttributeNames.ELV3, ConditionOperator.Equal, targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id);
                    LinkEntity linkEntityDefect = new LinkEntity()
                    {
                        LinkFromEntityName = ReportDefectEntityAttributeNames.EntityLogicalName,
                        LinkFromAttributeName = ReportDefectEntityAttributeNames.MasterDefectId,
                        LinkToEntityName = DefectEntityAttributeNames.EntityLogicalName,
                        LinkToAttributeName = DefectEntityAttributeNames.DefectId,
                        JoinOperator = JoinOperator.Inner,
                        Columns = new ColumnSet(true),
                        EntityAlias = "MasterDefects",
                        LinkCriteria = new FilterExpression(LogicalOperator.And)
                        {
                            Conditions =
                            {
                                new ConditionExpression("statecode", ConditionOperator.Equal, 0)//change this condition later to custom status field
                                
                            }
                        }
                    };
                    query.LinkEntities.Add(linkEntityDefect);
                    EntityCollection defects = serviceConnector.RetrieveMultiple(query);
                    customTrace.AppendLine("retrieved" + defects.Entities.Count);
                    customTrace.AppendLine("elv29 id" + ((Guid)context.OutputParameters["id"]).ToString());
                    foreach (Entity defect in defects.Entities)
                    {
                        //create report defect
                        Entity reportDefect = new Entity(ReportDefectEntityAttributeNames.EntityLogicalName);
                        reportDefect[ReportDefectEntityAttributeNames.ELV29] = new EntityReference(ELV29AffirimationAttributeNames.EntityLogicalName, (Guid)context.OutputParameters["id"]);
                        reportDefect[ReportDefectEntityAttributeNames.MasterDefectId] = new EntityReference(DefectEntityAttributeNames.EntityLogicalName, (Guid)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.DefectId]).Value));
                        reportDefect[ReportDefectEntityAttributeNames.ElevatorPart] = (OptionSetValue)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.ElevatorPart]).Value);
                        reportDefect[ReportDefectEntityAttributeNames.ElevatorSubPart] = (OptionSetValue)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.ElevatorSubPart]).Value);
                        reportDefect[ReportDefectEntityAttributeNames.SuggestedRemedy] = (OptionSetValue)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.SuggestedRemedy]).Value);
                        reportDefect[ReportDefectEntityAttributeNames.ViolationCondition] = (OptionSetValue)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.ViolationCondition]).Value);
                      //  reportDefect[ReportDefectEntityAttributeNames.Comments] = (string)(((AliasedValue)defect["MasterDefects." + DefectEntityAttributeNames.Comments]).Value); do not copy comments 
                        serviceConnector.Create(reportDefect);
                        customTrace.AppendLine("created");
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV29CopyReportDefects" + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
