﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// 1)Plugin to calculate Filing Fee and 60days Civil Penality fee
    /// 2)This is also used to set the report status of ELV3
    /// 3)Used to Clear the Satement and signatures(Commented)
    /// 4)Creation of Violation Number in PVT QC from BIS when filings has defects associated -Submit Action (Post operattion)
    /// Register on  Entity
    ///     * Pre-Update Stage - Synchronous - Server - Calling user - Exe order (2) - dobnyc_elv3 (primary)
    ///         * Filtering Attributes -UserFilingActions,BuildingType,Feeexempt,InspectionType,InspectionDate,owner type,User Filing Actions
    ///         * Pre Image - All Atttributes
    ///     
    ///     * Post-Update Stage - Synchronous - Server - Calling user - Exe order (2) - dobnyc_elv3 (primary)
    ///         * Filtering Attributes -UserFilingActions,BuildingType,Feeexempt,InspectionType,InspectionDate,owner type,User Filing Actions
    ///          * Pre Image - All Atttributes
    ///  
    /// NRF Calculation procedure:
    /// 1)We will charge NRF fees when user is filing Respective ELV3 for that device (CAT1,CAT3,CAT5)
    /// 2)Once User paid the NRF fee and other amount due up on successful payment passback we will link those NRF filings with the latest paid ELV3 filing and make those NRFs as inactive.
    /// 
    /// Date: 11/21/2017
    /// Written By: Vinay 
    /// </summary>
    public class ELV3FeeCalculationPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            decimal lateFilingFee = 0;
            int deviceStatus;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            ElevatorSafetyFeeCalculationobject feeObject = new ElevatorSafetyFeeCalculationobject();
            EntityCollection numberOfIsPostedNoSPH = new EntityCollection();
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity.LogicalName != ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("-- ERROR::: Target Entity MISMATCH..");
                    return;
                }

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                customTrace.AppendLine("Begin Get Pre-Image..");
                Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;


                #region Pre Operation
                if (context.Stage == 20)
                {
                    #region Create
                    //if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                    //{
                    //    customTrace.AppendLine("Create PLugin Pre-operation Started");
                    //   // Calculate the Fee and set all amount due, Filing fee for Normal Save.
                    //   // If filing is submitted then Calculate Late Filing Fee and update Late filing Fee accordingly
                    //    ELV3FeeCalculationHandler.CalculateELV3FilingFee(serviceConnector, targetEntity, customTrace, context.SharedVariables);
                    //}
                    #endregion
                    #region Update
                    if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {

                        customTrace.AppendLine("Update PLugin Pre-operation Started");
                        //Calculate the Fee and set all amount due ,Filing fee for Normal Save.
                        if (targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.Save) //Normal Save where UserActions is Save
                        {
                            //calculate filing feee only if any one of the following attribute  changes 1)Owner type,fee exempt,inspection type

                            #region unwanted Region (As per New requirements on Submit we have to calculate the Filing Fee and Late Filing Fee so commenting out this block.)
                            //if ((!preImage.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value > 0) || //Owner Type not present in pre image but present in target entity i.e. ownertype entering for the first time
                            //   (preImage[ELV3InspectionAttributeNames.OwnerType] != targetEntity[ELV3InspectionAttributeNames.OwnerType] && targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value > 0) || //user updates the owner type in save
                            //   (!preImage.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity[ELV3InspectionAttributeNames.InspectionType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value > 0) || //InspectionType not present in pre image but present in target entity i.e. ownertype entering for the first time
                            //   (preImage[ELV3InspectionAttributeNames.InspectionType] != targetEntity[ELV3InspectionAttributeNames.InspectionType] && targetEntity.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity[ELV3InspectionAttributeNames.InspectionType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value > 0)  //user updates the InspectionType in save

                            //  ) //preimage null or preimage 1
                            //{
                            //    customTrace.AppendLine("Normal save-CalculateELV3FilingFee Started");
                            //    ELV3FeeCalculationHandler.CalculateELV3FilingFee(serviceConnector, targetEntity, customTrace, context.SharedVariables);
                            //    customTrace.AppendLine("Normal save-CalculateELV3FilingFee Ended");
                            //}
                            #endregion
                            #region Clear Statement and Signatures (Requirement Change)
                            //bool preImageSignature, targetSignature;
                            //string[] colms;
                            //customTrace.AppendLine("Inspecting Agency Inspector Statement check ");
                            //preImageSignature = preImage.Contains(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement) && preImage[ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement] != null ? preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement) : false;
                            //customTrace.AppendLine(" PreImage Inspecting Agency Inspector Statement " + preImageSignature);
                            //targetSignature = targetEntity.Contains(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement) && targetEntity[ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement] != null ? targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement) : false;
                            //customTrace.AppendLine(" targetSignature Inspecting Agency Inspector Statement " + targetSignature);

                            //if (preImageSignature != targetSignature && (!targetSignature)) //user unchecks the Inspector legal statement
                            //{
                            //    //Clear all other statement and signature fields
                            //    colms = new string[] { ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement, ELV3InspectionAttributeNames.inspectingAgencyDirectorSignature, ELV3InspectionAttributeNames.inspectingAgencyDirectorSignatureDate,
                            //                            ELV3InspectionAttributeNames.ownerLegalStatement, ELV3InspectionAttributeNames.ownerSignature, ELV3InspectionAttributeNames.ownerSignatureDate,
                            //                            ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyInspectorSignature, ELV3InspectionAttributeNames.witnessAgencyInspectorSignatureDate,
                            //                            ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyDirectorSignature, ELV3InspectionAttributeNames.witnessAgencyDirectorSignatureDate };
                            //    ELV3FeeCalculationHandler.clearStatementAndSignaturesFields(serviceConnector, targetEntity, colms, customTrace);
                            //    return;
                            //}
                            //customTrace.AppendLine("Inspecting Agency Dircetor Statement check ");
                            //preImageSignature = preImage.Contains(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement) && preImage[ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement] != null ? preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement) : false;
                            //customTrace.AppendLine(" PreImage Inspecting Agency Dircetor Statement " + preImageSignature);
                            //targetSignature = targetEntity.Contains(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement) && targetEntity[ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement] != null ? targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement) : false;
                            //customTrace.AppendLine(" targetSignature Inspecting Agency Dircetor Statement " + targetSignature);
                            //if (preImageSignature!=targetSignature && (!targetSignature)) //user unchecks the Dircetor legal statement
                            //{
                            //    colms = new string[] {
                            //                            ELV3InspectionAttributeNames.ownerLegalStatement, ELV3InspectionAttributeNames.ownerSignature, ELV3InspectionAttributeNames.ownerSignatureDate,
                            //                            ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyInspectorSignature, ELV3InspectionAttributeNames.witnessAgencyInspectorSignatureDate,
                            //                            ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyDirectorSignature, ELV3InspectionAttributeNames.witnessAgencyDirectorSignatureDate };
                            //    ELV3FeeCalculationHandler.clearStatementAndSignaturesFields(serviceConnector, targetEntity, colms, customTrace);
                            //    return;
                            //}
                            //customTrace.AppendLine("Owner Statement check ");
                            //preImageSignature = preImage.Contains(ELV3InspectionAttributeNames.ownerLegalStatement) && preImage[ELV3InspectionAttributeNames.ownerLegalStatement] != null ? preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.ownerLegalStatement) : false;
                            //customTrace.AppendLine(" PreImage Owner Statement " + preImageSignature);
                            //targetSignature = targetEntity.Contains(ELV3InspectionAttributeNames.ownerLegalStatement) && targetEntity[ELV3InspectionAttributeNames.ownerLegalStatement] != null ? targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.ownerLegalStatement) : false;
                            //customTrace.AppendLine(" targetSignature Owner Statement " + targetSignature);
                            //if (preImageSignature != targetSignature && (!targetSignature)) //user unchecks the Owner legal statement
                            //{
                            //    colms = new string[] {
                            //                            ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyInspectorSignature, ELV3InspectionAttributeNames.witnessAgencyInspectorSignatureDate,
                            //                            ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement, ELV3InspectionAttributeNames.witnessAgencyDirectorSignature, ELV3InspectionAttributeNames.witnessAgencyDirectorSignatureDate };
                            //    ELV3FeeCalculationHandler.clearStatementAndSignaturesFields(serviceConnector, targetEntity, colms, customTrace);
                            //    return;
                            //}
                            //customTrace.AppendLine("Witness Agency Inspector Statement check ");
                            //preImageSignature = preImage.Contains(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement) && preImage[ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement] != null ? preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement) : false;
                            //customTrace.AppendLine(" PreImage Witness Agency Inspector Statement " + preImageSignature);
                            //targetSignature = targetEntity.Contains(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement) && targetEntity[ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement] != null ? targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement) : false;
                            //customTrace.AppendLine(" targetSignature Witness Agency Inspector Statement " + targetSignature);
                            //if (preImageSignature != targetSignature && (!targetSignature)) //user unchecks the Witness Inspector legal statement
                            //{
                            //    colms = new string[] {
                            //                            ELV3InspectionAttributeNames.witnessAgencyInspectorSignature, ELV3InspectionAttributeNames.witnessAgencyInspectorSignatureDate, ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement };
                            //    ELV3FeeCalculationHandler.clearStatementAndSignaturesFields(serviceConnector, targetEntity, colms, customTrace);
                            //}
                            #endregion



                        }

                        //If filing is submitted then Calculate Late Filing Fee and update Late filing Fee ,Amount due accordingly
                        else if (targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.CalculateCivilPenality && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value != (int)ELV3ReportStatus.PaymentVerification) //File is submitted to DOB this should not work when No good check is processed so added condition
                        {
                            #region  Associate TNF
                            ///first check if tnf is associated to elv3 or not
                            ///if not passociated. then query submitted TNF's for that device inspectiontype,inspection date
                            ///if results >0 then associate Top TNF 
                            ///
                            if(!(preImage.Contains(ELV3InspectionAttributeNames.TNFId)&& preImage[ELV3InspectionAttributeNames.TNFId]!=null))
                            {
                                customTrace.AppendLine("Start associating TNF -");
                                ELV3FeeCalculationHandler.associateTNF(serviceConnector, targetEntity, preImage, customTrace);

                                customTrace.AppendLine("End associating TNF -");
                            }

                            #endregion


                            //set the fees calculation date to today for reporting purpose
                            customTrace.AppendLine("Set the FeesCalculationDate to today");
                            targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.FeesCalculationDate, DateTime.Today);


                            customTrace.AppendLine("Normal save-CalculateELV3FilingFee Started");
                            feeObject = ELV3FeeCalculationHandler.CalculateELV3FilingFee(serviceConnector, preImage, customTrace, feeObject, context.SharedVariables); //change to preimage  beacuse on submit form will be frozen
                            customTrace.AppendLine("Normal save-CalculateELV3FilingFee Ended" + feeObject.ELV3FilingFee);

                            deviceStatus = ELV3FeeCalculationHandler.GetDeviceStatus(preImage, serviceConnector);
                            //late filing fee is only depended on inspection date and submission date and owner type
                            customTrace.AppendLine("File Submitted-CalculateELV3LateFilingFee Started"); // this cacluation should not be calculated in resubmission from incomplete submission
                            feeObject = ELV3FeeCalculationHandler.CalculateELV3LateFilingFee(serviceConnector, targetEntity, preImage, deviceStatus, targetEntity.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity[ELV3InspectionAttributeNames.InspectionType] != null ? targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value : preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, customTrace, feeObject, context.SharedVariables); //have to get device status from master data that is pending since it is not finalised. for time being passing 1 as default value

                            if (feeObject.AmountDue > 0)
                            {
                                //set the status as Prefiling-Pending payment
                                customTrace.AppendLine("Set the status as Pending Payment");
                                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PrefilingPendingPayment));
                            }



                        }
                        else if ((targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File))
                        {

                            ///Payment Integration will change the status to File such that all amount due is paid 
                            ///Up on this action set amount paid= prev Amount paid+amount due, amountdue=0
                            ///then set the report status of the ELV3.
                            ///
                            #region Set Amount Paid and Amount Due on File
                            decimal prevAmountDue = (preImage.Contains(ELV3InspectionAttributeNames.AmountDue) && preImage[ELV3InspectionAttributeNames.AmountDue] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0) ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0;
                            customTrace.AppendLine("prevAmountDue: " + prevAmountDue.ToString());
                            decimal prevAmountPaid = (preImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && preImage[ELV3InspectionAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0) ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value : 0;
                            customTrace.AppendLine("prevAmountPaid: " + prevAmountPaid.ToString());
                            decimal actualAmountPaid = 0;

                            targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.AmountDue, new Money(0));
                            actualAmountPaid = prevAmountPaid + prevAmountDue;

                            customTrace.AppendLine("actualAmountPaid: " + actualAmountPaid.ToString());
                            targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.AmountPaid, new Money(actualAmountPaid));
                            #endregion

                            #region  commented out- Because of requirement Change Payment calculation moved to submit action
                            //deviceStatus = ELV3FeeCalculationHandler.GetDeviceStatus(targetEntity, serviceConnector);
                            //customTrace.AppendLine("File Submitted-CalculateELV3LateFilingFee Started"); // this cacluation should not be calculated in resubmission from incomplete submission
                            //feeObject = ELV3FeeCalculationHandler.CalculateELV3LateFilingFee(serviceConnector, targetEntity, preImage, deviceStatus, targetEntity.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity[ELV3InspectionAttributeNames.InspectionType] != null ? targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value : preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, customTrace,feeObject, context.SharedVariables); 

                            // if (lateFilingFee == 0) //set the status to Accepted or QA supervisor Review
                            //  {
                            #endregion

                            #region IsSubmit Plugin- Set the report Status


                            if (targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File)// && (targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value != preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value))
                            {
                                customTrace.AppendLine("ELV3 Submit Plugin Started");
                                SubmitHandler.ELV3Submit(serviceConnector, targetEntity, preImage, customTrace, 0);
                                customTrace.AppendLine("ELV3 Submit Plugin Ended");
                            }

                            #endregion

                            #region commented out- Because of requirement Change Payment calculation moved to submit action
                            // }
                            //else
                            //{
                            //    customTrace.AppendLine("Set the IsLateFilingFeePaid ");
                            //    //update the isLateFilingfee since on file we have some late penality to Pay So Updating to No.
                            //    targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.IsLateFilingFeePaid, false);
                            //}
                            #endregion

                        }

                    }
                    #endregion

                }
                #endregion
                #region Post Operation
                if (context.Stage == 40)
                {
                    Guid shadowPaymentHistoryGuid = new Guid();

                    #region Requirement Change- Payment Calculation changed to Submit Action so commented out
                    //if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                    //{
                    //    customTrace.AppendLine("Create PLugin Post-operation Started");
                    //    //Post Opertaion is used to create the Shadow Payment histories for Filing fee -Normal Save
                    //    ////On File if there is any late filing fee then create SPH for late filing fee.
                    //    //if ((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0))
                    //    //{

                    //    //    if ((targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                    //    //       )
                    //    //    {

                    //    //        shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(serviceConnector, targetEntity, (int)PaymentHistoryFeeType.ElevatorsSafetyElv3FilingFee, new Money((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0), customTrace);
                    //    //        ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, shadowPaymentHistoryGuid, serviceConnector, customTrace, null);

                    //    //    }
                    //    //}
                    //}
                    #endregion

                    if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {
                        #region update Message
                        customTrace.AppendLine("Update PLugin Post-operation Started");
                        //Post Opertaion is used to create the Shadow Payment histories for Filing fee -Normal Save
                        customTrace.AppendLine("GUID: " + targetEntity.Id.ToString());

                        #region Requirement Change So commented out - Payment calculation moved to submit
                        //if (targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.Save) //Normal Save where UserActions is Save
                        //{
                        //    //Craete SPH  only if any one of the following attribute  changes 1)shared amountdue >0 we set this field in pre-operation

                        //    //if ((targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private) &&  //Not Fee exempt and amountdue>0
                        //    //     (context.SharedVariables.Contains(ELV3InspectionAttributeNames.sharedAmountDue) && context.SharedVariables[ELV3InspectionAttributeNames.sharedAmountDue] != null && (decimal)context.SharedVariables[ELV3InspectionAttributeNames.sharedAmountDue] > 0)) //this shared field will have value only if pre-operation is executed
                        //    //{
                        //    //    //delete the Previous sph if they are any
                        //    //    ElevatorSafetyFeeCalculationHelper.FeeExemptUpdateSPH(serviceConnector, targetEntity, customTrace);
                        //    //    shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(serviceConnector, targetEntity, (int)PaymentHistoryFeeType.ElevatorsSafetyElv3FilingFee, new Money((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0), customTrace);
                        //    //    ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, shadowPaymentHistoryGuid, serviceConnector, customTrace, null);
                        //    //}
                        //    //else if ((targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value != (int)OwnerType.Private))
                        //    //{
                        //    //    //delete the sph if it is fee exempt
                        //    //    ElevatorSafetyFeeCalculationHelper.FeeExemptUpdateSPH(serviceConnector, targetEntity, customTrace);

                        //    //}


                        //}
                        #endregion

                        //On File if there is any late filing fee then create SPH for late filing fee.
                        if ((targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.CalculateCivilPenality && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value != (int)ELV3ReportStatus.PaymentVerification) //File is Submitted to DOB
                                                                                                                                                                                                                                                                 // || (targetEntity.Contains(ELV3InspectionAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File) //File is Filed to DOB even in File we may have some civil penalty calculated
                           )
                        {
                            //if amount due>0 and it is private then follow normal procedure i amount due =0  and owner type is non-private then update the elv3 userfiling actions to file.
                            if ((context.SharedVariables.Contains(ELV3InspectionAttributeNames.sharedAmountDue) && context.SharedVariables[ELV3InspectionAttributeNames.sharedAmountDue] != null && (decimal)context.SharedVariables[ELV3InspectionAttributeNames.sharedAmountDue] > 0))
                            {

                                numberOfIsPostedNoSPH = ElevatorSafetyFeeCalculationHelper.FeeExemptUpdateSPH(serviceConnector, targetEntity, customTrace);

                                ///if numberOfIsPostedNoSPH >0 that means it has already one sph created so update the existing sph. if numberOfIsPostedNoSPH=0 then create the new one 

                                customTrace.AppendLine("if numberOfIsPostedNoSPH >0 that means it has already one sph created so update the existing sph. if numberOfIsPostedNoSPH=0 then create the new one ");
                                if (numberOfIsPostedNoSPH.Entities.Count == 0)
                                {
                                    customTrace.AppendLine("No SPH Created till now so create a new SPH");
                                    shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(serviceConnector, targetEntity, (int)PaymentHistoryFeeType.ElevatorsSafetyElv3FilingFee, new Money((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0), customTrace);
                                    ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, shadowPaymentHistoryGuid, serviceConnector, customTrace, preImage, preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, context.SharedVariables);
                                }
                                else
                                {
                                    if (numberOfIsPostedNoSPH.Entities[0] != null)
                                    {
                                        ///Update the existing SPH Total Fee and delete the TH and create new TH
                                        ///
                                        customTrace.AppendLine("SPH already Exists so Update the existing one");
                                        Entity updateSPH = new Entity(ShadowPaymentHistoryAttributeNames.EntityLogicalName);
                                        updateSPH.Attributes.Add(ShadowPaymentHistoryAttributeNames.TotalFees, new Money((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0));
                                        updateSPH.Id = numberOfIsPostedNoSPH.Entities[0].Id;
                                        serviceConnector.Update(updateSPH);
                                        #region Delete TH for Current SPH.
                                        ElevatorSafetyFeeCalculationHelper.DeleteAllTHForShadowPaymentHistory(serviceConnector, numberOfIsPostedNoSPH.Entities[0].Id, customTrace);
                                        #endregion
                                        customTrace.AppendLine("Create TH's for updated SPH");
                                        ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, numberOfIsPostedNoSPH.Entities[0].Id, serviceConnector, customTrace, preImage, preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, context.SharedVariables);
                                    }
                                }

                            }
                            else
                            {
                                //set user filing actions to file when amount due =0 irrespective of ownertype and inspection type



                                customTrace.AppendLine("Update the user filing actions to File-Started");
                                Entity updateELV3 = new Entity(ELV3InspectionAttributeNames.EntityLogicalName);
                                updateELV3.SetAttributeValue(ELV3InspectionAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.File));
                                updateELV3.Id = targetEntity.Id;

                                #region Creation Violation Number-Commented out because this piece is moved to integration
                                //if ((preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.PVTInspection || preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.QCInspection) &&//inspection should be PVT or QC
                                //   (preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.IsDefectsExist))//defcts should exists
                                //   )
                                //{
                                //    //create the request for violation number 
                                //    customTrace.AppendLine("Start the Creation BIS parameters");
                                //    CreateElevatorDOBViolationNumberResponse response = ViolationNumberHandler.CreateViolationNumber(serviceConnector, targetEntity, preImage, customTrace);
                                //    if (response.MF_RETURN_CODE == "0")
                                //    {
                                //        //Success from BIS for Creating Violation Request
                                //        customTrace.AppendLine("Success from BIS for Creating Violation Request");
                                //        updateELV3.Attributes.Add(ELV3InspectionAttributeNames.violationNumber, response.MF_DATA.MF_DOB_VIOL_NUMBER_FULL);

                                //    }
                                //    else
                                //    {
                                //        //Error processing the Create Violation Request send email
                                //        customTrace.AppendLine("Start Craete BIS Violation Failure Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                                //        WorkflowHandler.CreateDismissBISViolationFailureEmail(serviceConnector, targetEntity, customTrace, true);
                                //        customTrace.AppendLine("End Craete BIS Violation Failure Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                                //        updateELV3.SetAttributeValue(ELV3InspectionAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.Save));
                                //    }

                                //}
                                #endregion




                                serviceConnector.Update(updateELV3);
                                customTrace.AppendLine("Update the user filing actions to File-End");

                            }
                        }
                        #endregion


                    }
                }
                #endregion




            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}
