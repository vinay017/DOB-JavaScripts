﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
   public  class ELV3TaskCreationPlugin : IPlugin
    {
        /// <summary>
        /// This PLugin is used to associate the document on ELV3 Task Form on Create 
        /// Register on  Elevator Task Entity
        ///     
        ///     * Post-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_elevatorsafetytask (primary)
        /// Date: 12/19/2017
        /// Written By: Vinay 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = null;
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity == null || targetEntity.LogicalName != ElevatorSafetyTaskAttributeNames.EntityLogicalName)
                    return;

                customTrace.AppendLine("targetEntity ");

                #region Post-Create Staging
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) &&
                    context.Stage == 40)
                {
                    #region Associate Document Lists to Boiler Task
                    if (targetEntity.Attributes.Contains(ElevatorSafetyTaskAttributeNames.RegardingObjectId))
                    {

                        EntityReference regardingObject = targetEntity.GetAttributeValue<EntityReference>(ElevatorSafetyTaskAttributeNames.RegardingObjectId);
                        /// task assoiciation 
                        if (regardingObject != null)
                        {
                            customTrace.AppendLine("Start Generating Documents for Task: " + PluginHelperStrings.CreateMessageName);
                            try
                            {
                                ElevatorSafetyDocumentHandler.AssociateDocumentsOnTaskCreation(serviceConnector, targetEntity, regardingObject, customTrace);
                            }
                            catch (FaultException<OrganizationServiceFault> ex)
                            {
                                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "AssociateDocumentsOnTaskCreation - Execute", null, customTrace.ToString(), null, null);
                                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "AssociateDocumentsOnTaskCreation - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                                throw new Exception(ex + " crmTrace: " + customTrace.ToString());
                            }

                            customTrace.AppendLine("End Generating Documents for Task: " + PluginHelperStrings.CreateMessageName);
                        }
                    }
                    #endregion
                }
                #endregion
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3TaskCreationPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}
