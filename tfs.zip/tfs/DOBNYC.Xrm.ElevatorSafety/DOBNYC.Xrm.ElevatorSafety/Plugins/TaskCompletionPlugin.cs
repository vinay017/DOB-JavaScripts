﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using ExternalSystemIntegration.Objects;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    public class TaskCompletionPlugin : IPlugin
    {
        /// Elevator safety Task Update Plugin--used to update the violation dismissal flag on PVT,QC ELV29
        /// Wrote this plugin because externalIntegration DLL can not be called from workflows
        /// Register the Plugin on Elevator safety Task Entity
        ///     * (a) Post-Update Stage - Synchronous - Server - SVC CRMPROXYADMDEV - Exe order (1) - dobnyc_elevatorsafetytask (primary)
        ///         * Filtering Attributes - statuscode
        ///         * pre Image - All attributes  
        /// Date: 03/28/2018
        /// Written By: Vinay
        /// </summary>
        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            int qaClerkAction = 0;
            Entity updateELV29;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                if (targetEntity == null)
                    return;



                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                EntityReference regardingObject = (EntityReference)(preTargetEntity.Attributes[ElevatorSafetyTaskAttributeNames.RegardingObjectId]);
                qaClerkAction = (targetEntity.Contains(ElevatorSafetyTaskAttributeNames.QAclerkAction) && targetEntity[ElevatorSafetyTaskAttributeNames.QAclerkAction] != null) ? targetEntity.GetAttributeValue<OptionSetValue>(ElevatorSafetyTaskAttributeNames.QAclerkAction).Value : (preTargetEntity.Contains(ElevatorSafetyTaskAttributeNames.QAclerkAction) && preTargetEntity[ElevatorSafetyTaskAttributeNames.QAclerkAction] != null) ? preTargetEntity.GetAttributeValue<OptionSetValue>(ElevatorSafetyTaskAttributeNames.QAclerkAction).Value : 0;
                if (regardingObject != null && regardingObject.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("regarding object:" + ELV29AffirimationAttributeNames.EntityLogicalName);

                    if (qaClerkAction == (int)QAClerkActions.CorrectionsAcceptedViolationsDismissed)
                    {
                        customTrace.AppendLine("qaClerkAction :" + qaClerkAction);
                        ///update the dismissal flag  on ELV29 frm regarding object
                        ///

                        updateELV29 = new Entity(ELV29AffirimationAttributeNames.EntityLogicalName);
                        updateELV29.Attributes.Add(ELV29AffirimationAttributeNames.violationDismissFlag, true);
                        updateELV29.Id = regardingObject.Id;
                        serviceConnector.Update(updateELV29);
                    }
                }
                else if (regardingObject != null && regardingObject.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    //check if the QA clerk action is accepted
                    
                    customTrace.AppendLine("regarding object:" + ELV3InspectionAttributeNames.EntityLogicalName);
                    if(qaClerkAction==(int)QAClerkActions.Accepted)
                    {
                        //get the is defects exist flag if false then call the update dismissal flag
                        customTrace.AppendLine("get the is defects exist flag if false then call the update dismissal flag");
                        Entity ELV3 = serviceConnector.Retrieve(ELV3InspectionAttributeNames.EntityLogicalName, regardingObject.Id, new ColumnSet(new string[] { ELV3InspectionAttributeNames.ReportYear, ELV3InspectionAttributeNames.IsDefectsExist,ELV3InspectionAttributeNames.DeviceIdLookup,ELV3InspectionAttributeNames.InspectionType}));
                        if(ELV3!=null && ELV3.Contains(ELV3InspectionAttributeNames.IsDefectsExist)&&ELV3[ELV3InspectionAttributeNames.IsDefectsExist]!=null&&(!ELV3.GetAttributeValue<bool>(ELV3InspectionAttributeNames.IsDefectsExist)))//defects exist should be false

                        {
                            customTrace.AppendLine("call the update dismisal flag to true");
                            ViolationNumberHandler.GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag(serviceConnector, ELV3.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, customTrace);
                        }
                        customTrace.AppendLine("call the NRF violations");
                        ViolationNumberHandler.GetAllNRFViolationsForDevice(serviceConnector, ELV3.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, ELV3.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, ELV3, customTrace);
                    }
                }


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.TaskCompletionPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}
