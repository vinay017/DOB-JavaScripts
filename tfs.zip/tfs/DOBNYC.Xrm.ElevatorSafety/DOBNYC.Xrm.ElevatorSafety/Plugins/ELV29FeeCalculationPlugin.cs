﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    public class ELV29FeeCalculationPlugin : IPlugin
    {
        /// <summary>
        /// Plugin to calculate Filing Fee and 60days Civil Penality fee,120 days Civil Penality
        /// Register on  Entity
        ///     * Pre-Update Stage - Synchronous - Server - Calling user - Exe order (2) - dobnyc_elv29 (primary)
        ///         * Filtering Attributes -UserFilingActions,Feeexempt,AOCInspectionDate,owner type,InitialELV3submissiondate,AOCSubmissionDate
        ///         * Pre Image - All Atttributes
        ///    
        ///     * Post-Update Stage - Synchronous - Server - Calling user - Exe order (2) - dobnyc_elv29 (primary)
        ///         * Filtering Attributes -UserFilingActions,Feeexempt,AOCInspectionDate,owner type,InitialELV3submissiondate,AOCSubmissionDate
        ///          * Pre Image - All Atttributes
        ///    
        /// Date: 12/05/2017
        /// Written By: Vinay 
        /// </summary>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            ElevatorSafetyFeeCalculationobject feeObject = new ElevatorSafetyFeeCalculationobject();
            int deviceStatus;
            StringBuilder customTrace = new StringBuilder();
            EntityCollection numberOfIsPostedNoSPH = new EntityCollection();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity.LogicalName != ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("-- ERROR::: Target Entity MISMATCH..");
                    return;
                }

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;


                #region Pre Operation
                if (context.Stage == 20)
                {
                    #region Create
                    if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                    {

                    }
                    #endregion
                    #region Update
                    if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {

                        customTrace.AppendLine("Update PLugin Pre-operation Started");
                        //Calculate the Fee and set all amount due ,Filing fee for Normal Save.
                        if (targetEntity.Contains(ELV29AffirimationAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.Save) //Normal Save where UserActions is Save
                        {


                        }

                        //If filing is submitted then Calculate Late Filing Fee and update Late filing Fee ,Amount due accordingly
                        else if (targetEntity.Contains(ELV29AffirimationAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.CalculateCivilPenality && preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value != (int)ELV3ReportStatus.PaymentVerification) //File is submitted to DOB fee should not be calculated when preimage report status is payement verification because ity is no good check
                        {

                            //set the fees calculation date to today for reporting purpose
                            customTrace.AppendLine("Set the FeesCalculationDate to today");
                            targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.FeesCalculationDate, DateTime.Today);


                            customTrace.AppendLine("Normal save-CalculateELV3FilingFee Started");
                            feeObject = ELV3FeeCalculationHandler.CalculateELV29FilingFee(serviceConnector, preImage, feeObject, customTrace, context.SharedVariables, ELV3FeeCalculationHandler.GetELV3InspectionType(preImage, serviceConnector)); //change to preimage  beacuse on submit form will be frozen
                            customTrace.AppendLine("Normal save-CalculateELV3FilingFee Ended" + feeObject.ELV29FilingFee);

                            deviceStatus = ELV3FeeCalculationHandler.GetAOCDeviceStatus(preImage, serviceConnector);
                            //late filing fee is only depended on inspection date and submission date and owner type
                            customTrace.AppendLine("File Submitted-CalculateELV3LateFilingFee Started"); // this cacluation should not be calculated in resubmission from incomplete submission

                            //need to change to ELV29 logic for both late fee and submit
                            feeObject = ELV3FeeCalculationHandler.CalculateELV29LateFilingFee(serviceConnector, targetEntity, preImage, deviceStatus, ELV3FeeCalculationHandler.GetELV3InspectionType(preImage, serviceConnector), customTrace, feeObject, context.SharedVariables); //have to get device status from master data that is pending since it is not finalised. for time being passing 1 as default value

                            if (feeObject.AmountDue > 0)
                            {
                                //set the status as Prefiling-Pending payment
                                customTrace.AppendLine("Set the status as Pending Payment");
                                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PrefilingPendingPayment));
                            }



                        }
                        else if ((targetEntity.Contains(ELV29AffirimationAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File))
                        {

                            ///Payment Integration will change the status to File such that all amount due is paid 
                            ///Up on this action set amount paid= prev Amount paid+amount due, amountdue=0
                            ///then set the report status of the ELV3.
                            ///
                            #region Set Amount Paid and Amount Due on File
                            decimal prevAmountDue = (preImage.Contains(ELV29AffirimationAttributeNames.AmountDue) && preImage[ELV29AffirimationAttributeNames.AmountDue] != null && preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value > 0) ? preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value : 0;
                            customTrace.AppendLine("prevAmountDue: " + prevAmountDue.ToString());
                            decimal prevAmountPaid = (preImage.Contains(ELV29AffirimationAttributeNames.AmountPaid) && preImage[ELV29AffirimationAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value > 0) ? preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value : 0;
                            customTrace.AppendLine("prevAmountPaid: " + prevAmountPaid.ToString());
                            decimal actualAmountPaid = 0;

                            targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.AmountDue, new Money(0));
                            actualAmountPaid = prevAmountPaid + prevAmountDue;

                            customTrace.AppendLine("actualAmountPaid: " + actualAmountPaid.ToString());
                            targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.AmountPaid, new Money(actualAmountPaid));
                            #endregion



                            #region IsSubmit Plugin- Set the report Status- Need to change to ELv29


                            if (targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File)// && (targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value != preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value))
                            {
                                customTrace.AppendLine("ELV3 Submit Plugin Started");
                                SubmitHandler.ELV29Submit(serviceConnector, targetEntity, preImage, customTrace, 0, ELV3FeeCalculationHandler.GetELV3InspectionType(preImage, serviceConnector));
                                customTrace.AppendLine("ELV3 Submit Plugin Ended");
                            }

                            #endregion


                            customTrace.AppendLine("Begin Get Pre-Image..");

                            customTrace.AppendLine("Update PLugin Pre-operation Started");
                            //Calculate the Fee and set all amount due ,Filing fee for Normal Save.


                        }
                    }
                    #endregion

                }
                #endregion
                #region Post Operation
                if (context.Stage == 40)
                {
                    Guid shadowPaymentHistoryGuid = new Guid();
                    #region commented out
                    if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                    {
                        //Nothing in Create Postoperatin
                    }
                    #endregion
                    else if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {


                        #region update Message
                        customTrace.AppendLine("Update PLugin Post-operation Started");
                        //Post Opertaion is used to create the Shadow Payment histories for Filing fee -Normal Save
                        customTrace.AppendLine("GUID: " + targetEntity.Id.ToString());



                        //On File if there is any late filing fee then create SPH for late filing fee.
                        if ((targetEntity.Contains(ELV29AffirimationAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.CalculateCivilPenality && preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value != (int)ELV3ReportStatus.PaymentVerification) //File is Submitted to DOB
                                                                                                                                                                                                                                                                                                                                                                                                                      // || (targetEntity.Contains(ELV29AffirimationAttributeNames.UserFilingActions) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.UserFilingActions).Value == (int)ELV3UserFilingActions.File) //File is Filed to DOB even in File we may have some civil penalty calculated
                           )
                        {
                            //if amount due>0 and it is private then follow normal procedure i amount due =0  and owner type is non-private then update the elv3 userfiling actions to file.
                            if ((context.SharedVariables.Contains(ELV29AffirimationAttributeNames.sharedAmountDue) && context.SharedVariables[ELV29AffirimationAttributeNames.sharedAmountDue] != null && (decimal)context.SharedVariables[ELV29AffirimationAttributeNames.sharedAmountDue] > 0))
                            {

                                numberOfIsPostedNoSPH = ElevatorSafetyFeeCalculationHelper.FeeExemptUpdateSPH(serviceConnector, targetEntity, customTrace);

                                ///if numberOfIsPostedNoSPH >0 that means it has already one sph created so update the existing sph. if numberOfIsPostedNoSPH=0 then create the new one 

                                customTrace.AppendLine("if numberOfIsPostedNoSPH >0 that means it has already one sph created so update the existing sph. if numberOfIsPostedNoSPH=0 then create the new one ");
                                if (numberOfIsPostedNoSPH.Entities.Count == 0)
                                {
                                    customTrace.AppendLine("No SPH Created till now so create a new SPH");
                                    shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(serviceConnector, targetEntity, (int)PaymentHistoryFeeType.ElevatorsSafetyElv29, new Money((targetEntity.Contains(ELV29AffirimationAttributeNames.AmountDue) && targetEntity[ELV29AffirimationAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value : 0), customTrace);

                                    ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, shadowPaymentHistoryGuid, serviceConnector, customTrace, preImage, ELV3FeeCalculationHandler.GetELV3InspectionType(preImage, serviceConnector), context.SharedVariables);
                                }
                                else
                                {
                                    if (numberOfIsPostedNoSPH.Entities[0] != null)
                                    {
                                        ///Update the existing SPH Total Fee and delete the TH and create new TH
                                        ///
                                        customTrace.AppendLine("SPH already Exists so Update the existing one");
                                        Entity updateSPH = new Entity(ShadowPaymentHistoryAttributeNames.EntityLogicalName);
                                        updateSPH.Attributes.Add(ShadowPaymentHistoryAttributeNames.TotalFees, new Money((targetEntity.Contains(ELV29AffirimationAttributeNames.AmountDue) && targetEntity[ELV29AffirimationAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value > 0) ? targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value : 0));
                                        updateSPH.Id = numberOfIsPostedNoSPH.Entities[0].Id;
                                        serviceConnector.Update(updateSPH);
                                        #region Delete TH for Current SPH.
                                        ElevatorSafetyFeeCalculationHelper.DeleteAllTHForShadowPaymentHistory(serviceConnector, numberOfIsPostedNoSPH.Entities[0].Id, customTrace);
                                        #endregion
                                        customTrace.AppendLine("Create TH's for updated SPH");
                                        ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, numberOfIsPostedNoSPH.Entities[0].Id, serviceConnector, customTrace, preImage, ELV3FeeCalculationHandler.GetELV3InspectionType(preImage, serviceConnector), context.SharedVariables);
                                    }
                                }

                            }
                            else
                            {
                                //set user filing actions to file when amount due =0 irrespective of ownertype and inspection type

                                // if (!(preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private))
                                // {
                                customTrace.AppendLine("Update the user filing actions to File-Started");
                                Entity updateELV3 = new Entity(ELV29AffirimationAttributeNames.EntityLogicalName);
                                updateELV3.SetAttributeValue(ELV29AffirimationAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.File));
                                updateELV3.Id = targetEntity.Id;
                                serviceConnector.Update(updateELV3);
                                customTrace.AppendLine("Update the user filing actions to File-End");
                                // }
                            }

                        }
                        #endregion


                    }
                }
                #endregion



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //  throw new Exception(ex + customTrace.ToString());
            }
            #endregion

        }
    }
}
