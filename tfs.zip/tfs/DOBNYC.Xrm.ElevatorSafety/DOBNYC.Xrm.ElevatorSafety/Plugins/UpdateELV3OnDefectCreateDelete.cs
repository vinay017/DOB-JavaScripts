﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// Plugin to set ELV3 Defects Flag on create of defect & reset on delete if no defects exist.
    /// Register on  Entity
    ///         * Post-Create Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_elv3_defect (primary)
    ///         * Post-Delete Stage - Synchronous - Server - Calling user - Exe order (1) -  dobnyc_elv3_defect (primary)
    /// Date: 12/26/2017
    /// Written By: Mayank 
    /// </summary>
    public class UpdateELV3OnDefectCreateDelete :IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                {
                    EntityReference targetEntityRef = CommonPluginLibrary.GetEntityReferenceFromContext(context);
                    if (targetEntityRef == null)
                        return;
                    targetEntity = new Entity(targetEntityRef.LogicalName);
                    targetEntity.Id = targetEntityRef.Id;
                }
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                Entity elv3 = new Entity(ELV3InspectionAttributeNames.EntityLogicalName);
                customTrace.AppendLine("Plugin Message: " + context.MessageName);

                #region Create Message
                if (context.MessageName == PluginHelperStrings.CreateMessageName && targetEntity.Contains(ELV3Defect.ELV3Lookup))
                {
                    elv3.Id = targetEntity.GetAttributeValue<EntityReference>(ELV3Defect.ELV3Lookup).Id;
                    //set ELV3 Defects Flag on create of defect 
                    elv3[ELV3InspectionAttributeNames.IsDefectsExist] = true;
                    serviceConnector.Update(elv3);
                    customTrace.AppendLine("Set ELV3 Defects Exists to true");
                }
                #endregion

                #region Delete Message
                else if (context.MessageName == PluginHelperStrings.DeleteMessageName && context.PreEntityImages.Contains(PluginHelperStrings.PreImageName))
                {
                    Entity defectImage = context.PreEntityImages[PluginHelperStrings.PreImageName];
                    elv3.Id = defectImage.GetAttributeValue<EntityReference>(ELV3Defect.ELV3Lookup).Id;

                    QueryByAttribute existingDefectsQuery = new QueryByAttribute(ELV3Defect.EntityLogicalName);
                    existingDefectsQuery.AddAttributeValue(ELV3Defect.ELV3Lookup, elv3.Id);
                    existingDefectsQuery.ColumnSet = new ColumnSet(ELV3Defect.Name);
                    EntityCollection existingDefects = serviceConnector.RetrieveMultiple(existingDefectsQuery);
                    
                    if (existingDefects == null || existingDefects.Entities == null || existingDefects.Entities.Count == 0)
                    {
                        //reset on delete if no defects exist.
                        customTrace.AppendLine("defect count:" + existingDefects.Entities.Count);
                        elv3[ELV3InspectionAttributeNames.IsDefectsExist] = false;
                        serviceConnector.Update(elv3);
                        customTrace.AppendLine("Set ELV3 Defects Exists to false");
                    }
                }
                #endregion
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                crmTracing.Trace(customTrace.ToString());
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "UpdateELV3OnDefectCreateDelete" + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }
    }
}
