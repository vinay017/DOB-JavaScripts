﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
  
    public class NoGoodCheckPlugin : IPlugin
    {
        /// <summary>
        /// Plugin to  create new SPH and new TH's when a check is bounced
        /// Register on  Entity
        ///     
        ///    
        ///     * Post-Update Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_shadowpaymenthistory (primary)
        ///         * Filtering Attributes -isnogoodcheckFlag
        ///          * Pre Image - All Atttributes
        ///    
        /// Date: 12/05/2017
        /// Written By: Vinay 
        /// </summary>
        /// 
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            ElevatorSafetyFeeCalculationobject feeObject = new ElevatorSafetyFeeCalculationobject();
          
            StringBuilder customTrace = new StringBuilder();
            EntityCollection numberOfIsPostedNoSPH = new EntityCollection();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity.LogicalName != ShadowPaymentHistoryAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("-- ERROR::: Target Entity MISMATCH..");
                    return;
                }

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;
                if(preImage==null)
                {
                    customTrace.AppendLine("-- ERROR::: PreImage not Registered");
                    return;
                }

                #region Post Operation
                if (context.Stage == 40)
                {
               
                    #region Update
                    if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {

                        if(targetEntity.Contains(ShadowPaymentHistoryAttributeNames.BoilerNoGoodCheckFlag) && targetEntity[ShadowPaymentHistoryAttributeNames.BoilerNoGoodCheckFlag]!=null && targetEntity.GetAttributeValue<bool>(ShadowPaymentHistoryAttributeNames.BoilerNoGoodCheckFlag))//execute only if nogoodcheck is true
                        {
                            if(preImage.Contains(ShadowPaymentHistoryAttributeNames.ELV3Lookup) && preImage[ShadowPaymentHistoryAttributeNames.ELV3Lookup]!=null&&preImage.GetAttributeValue<EntityReference>(ShadowPaymentHistoryAttributeNames.ELV3Lookup).Id.ToString()!=string.Empty)
                            {
                                ///1)Create a new SPH for ELV3
                                ///2)Clone all old SPH TH's to newly created SPH
                                ///3)Add  a new TH for no good check
                                ///4)set the following attributes on ELV3
                                ///a)Amount Piad= prev Amount paid- old sph fees,b)Amount due= old amount due+old sph fees c)nogoodfee=prevnogoodfee+20
                                ///set the fees for new SPH= amount due(calculated in above step)
                                /// we are not calculating fee again because when user paying fee for no good check since payment date and fees calculation date are different  we have to calculate entire fee again 

                                NoGoodCheckHandler.NoGoodCheckELV3(serviceConnector, preImage, customTrace);
                            }
                            else if (preImage.Contains(ShadowPaymentHistoryAttributeNames.ELV29Lookup) && preImage[ShadowPaymentHistoryAttributeNames.ELV29Lookup] != null && preImage.GetAttributeValue<EntityReference>(ShadowPaymentHistoryAttributeNames.ELV29Lookup).Id.ToString() != string.Empty)
                            {
                                ///1)Create a new SPH for ELV3
                                ///2)Clone all old SPH TH's to newly created SPH
                                ///3)Add  a new TH for no good check
                                ///4)set the following attributes on ELV3
                                ///a)Amount Piad= prev Amount paid- old sph fees,b)Amount due= old amount due+old sph fees c)nogoodfee=prevnogoodfee+20
                                ///set the fees for new SPH= amount due(calculated in above step)
                                /// we are not calculating fee again because when user paying fee for no good check since payment date and fees calculation date are different  we have to calculate entire fee again 
                                /// 
                                NoGoodCheckHandler.NoGoodCheckELV29(serviceConnector, preImage, customTrace);
                            }
                        }

                    }
                    #endregion

                }
                #endregion
             

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.NoGoodCheckPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //  throw new Exception(ex + customTrace.ToString());
            }
            #endregion

        }
    }
}
