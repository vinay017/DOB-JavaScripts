﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using ExternalSystemIntegration.Objects;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{/// <summary>
 /// * Post-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv29 (primary)
 ///           * Filtering Attributes - violation dismissal flag
 ///           * Pre Image - All attributes
 ///           
 /// * Post-Create Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elevatorsafetyviolationnumber (primary) -- used when violations created with dismissal status
 ///           
 /// </summary>
    public class DismissalViolationPlugin : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                if (targetEntity == null)
                    return;



                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                DismissElevatorDOBViolationResponse response;
                
                Entity preTargetEntity = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;
                #region ELV3,ELv29 Entity
                if (context.Stage == 40 && targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName && targetEntity.Contains(ELV29AffirimationAttributeNames.violationDismissFlag) && targetEntity[ELV29AffirimationAttributeNames.violationDismissFlag] != null && targetEntity.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.violationDismissFlag))
                {
                    customTrace.AppendLine("Get the parent ELV3");
                    Entity parentELV3 = serviceConnector.Retrieve(ELV3InspectionAttributeNames.EntityLogicalName, preTargetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id, new ColumnSet(new string[] { ELV3InspectionAttributeNames.Name, ELV3InspectionAttributeNames.violationNumber, ELV3InspectionAttributeNames.InspectionType }));//badge number should added
                    if (parentELV3.Id != null && parentELV3.Contains(ELV3InspectionAttributeNames.violationNumber) && parentELV3[ELV3InspectionAttributeNames.violationNumber] != null)
                    {
                        //compare preimage and targent
                        if ((preTargetEntity[ELV29AffirimationAttributeNames.violationDismissFlag] != targetEntity[ELV29AffirimationAttributeNames.violationDismissFlag]) && targetEntity.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.violationDismissFlag))//execute only when there is a change in target entity
                        {
                            customTrace.AppendLine("call the Dismissal Service-start");
                            response = ViolationNumberHandler.DismissViolation(serviceConnector, targetEntity, parentELV3, customTrace);
                            if (response.MF_RETURN_CODE == "0")
                            {
                                //update the violation status to dismissed
                                customTrace.AppendLine("Violation Status Change Start");
                                ConditionExpression condition1 = new ConditionExpression(ViolationNumberAttributeNmaes.Name, ConditionOperator.Equal, parentELV3.GetAttributeValue<string>(ELV3InspectionAttributeNames.violationNumber));
                                QueryExpression query = new QueryExpression(ViolationNumberAttributeNmaes.EntityLogicalName);
                                query.ColumnSet = new ColumnSet(new string[] { ViolationNumberAttributeNmaes.Name, ViolationNumberAttributeNmaes.ViolationStatus });
                                query.Criteria = new FilterExpression(LogicalOperator.And)
                                {
                                    Conditions =
                            {
                                condition1

                            }
                                };

                                EntityCollection records = serviceConnector.RetrieveMultiple(query);
                                customTrace.AppendLine("Count Records:" + records.Entities.Count);

                                if (records != null && records.Entities.Count > 0)
                                {
                                    records[0].SetAttributeValue(ViolationNumberAttributeNmaes.ViolationStatus, new OptionSetValue(2));//set violation to dismissed
                                    serviceConnector.Update(records[0]);
                                }
                                customTrace.AppendLine("Violation Status Change End");
                            }
                            else
                            {
                                //Error processing the Create Violation Request send email
                                customTrace.AppendLine("Start Dismiss BIS Violation Failure Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                                WorkflowHandler.CreateDismissBISViolationFailureEmail(serviceConnector, targetEntity, customTrace, false);
                                customTrace.AppendLine("End Dismiss BIS Violation Failure Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                                return;
                            }
                        }

                    }


                }
                #endregion

                #region Violation Entity Create Message
                else if (context.Stage == 40 && context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.LogicalName == ViolationNumberAttributeNmaes.EntityLogicalName)
                {
                    if (targetEntity[ViolationNumberAttributeNmaes.ViolationStatus] != null && targetEntity.GetAttributeValue<OptionSetValue>(ViolationNumberAttributeNmaes.ViolationStatus).Value == (int)ViolationStatus.Dismissed)
                    {
                        customTrace.AppendLine("call the Dismissal Service for Violation Number-start");
                        response = ViolationNumberHandler.DismissViolation(serviceConnector, targetEntity, targetEntity, customTrace);
                    }
                }
                #endregion



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.DismissalViolationPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }


    }




}

