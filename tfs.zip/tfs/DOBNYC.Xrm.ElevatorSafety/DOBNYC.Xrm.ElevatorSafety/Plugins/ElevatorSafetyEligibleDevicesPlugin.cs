﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// Plugin to Make Device eligible for CAT1,CAT5 based on the inspection results from Accela to elevators Build 
    /// 
    /// Register on  Entity
    ///     * Pre-Update Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_elevatordevice (primary)
    ///         * Filtering Attributes -Inflight Flag,Device Status
    ///         * Pre Image - All Atttributes
    ///   
    /// Date: 02/20/2018
    /// Written By: Vinay 
    /// </summary>
    public class ElevatorSafetyEligibleDevicesPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity.LogicalName != ElevatorMasterDevice.EntityLogicalName)
                {
                    customTrace.AppendLine("-- ERROR::: Target Entity MISMATCH..");
                    return;
                }

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                customTrace.AppendLine("Begin Get Pre-Image..");
                Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;

                #region Pre Operation
                if (context.Stage == 20)
                {

                    #region Update
                    if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {
                        customTrace.AppendLine("Pre-Update");
                        #region Both inflight and Device Status is changed
                        if (
                          ((targetEntity.Contains(ElevatorMasterDevice.InFlight) && targetEntity[ElevatorMasterDevice.InFlight] != null) && //check inflight is notnull
                           (targetEntity.Contains(ElevatorMasterDevice.DeviceStatus) && targetEntity[ElevatorMasterDevice.DeviceStatus] != null)) ||//check both status and device status changed
                           ((targetEntity.Contains(ElevatorMasterDevice.InFlight) && targetEntity[ElevatorMasterDevice.InFlight] != null)) // only inflight flag is changed
                           )
                        {
                            customTrace.AppendLine("inflight or device status is changed");
                            //check the preimage of inflight flag 
                            bool preImageInflight = (preImage.Contains(ElevatorMasterDevice.InFlight) && preImage[ElevatorMasterDevice.InFlight] != null) ? preImage.GetAttributeValue<bool>(ElevatorMasterDevice.InFlight) : false;
                            customTrace.AppendLine("preImageInflight: " + preImageInflight);
                            bool targetInflight = (targetEntity.Contains(ElevatorMasterDevice.InFlight) && targetEntity[ElevatorMasterDevice.InFlight] != null) ? targetEntity.GetAttributeValue<bool>(ElevatorMasterDevice.InFlight) : false;
                            customTrace.AppendLine("targetInflight: " + targetInflight);
                            if ((preImageInflight != targetInflight) && (!targetInflight))// targetinflight should be false and preimage and target should be different
                            {
                                customTrace.AppendLine("targetinflight should be false and preimage and target should be different");
                                //get the Devicestatus
                                int deviceStatus = (targetEntity.Contains(ElevatorMasterDevice.DeviceStatus) && targetEntity[ElevatorMasterDevice.DeviceStatus] != null) ? targetEntity.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value : (preImage.Contains(ElevatorMasterDevice.DeviceStatus) && preImage[ElevatorMasterDevice.DeviceStatus] != null) ? preImage.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value : (int)ElevatorDeviceStatus.Active;
                                customTrace.AppendLine("deviceStatus: " + deviceStatus);
                                ElevatorSafetyEligibleDeviceHandler.setCAT1CAT5EligibleFlags(serviceConnector, targetEntity, preImage, deviceStatus, customTrace);

                            }
                        }

                        #endregion

                        #region Only Device Status is changed
                        else if (
                               (targetEntity.Contains(ElevatorMasterDevice.DeviceStatus) && targetEntity[ElevatorMasterDevice.DeviceStatus] != null) //check status is not null
                               )
                        {
                            customTrace.AppendLine("deviceStatus is changed " );
                            int preImageDeviceStatus = (preImage.Contains(ElevatorMasterDevice.DeviceStatus) && preImage[ElevatorMasterDevice.DeviceStatus] != null) ? preImage.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value : (int)ElevatorDeviceStatus.Active;
                            customTrace.AppendLine("preImageDeviceStatus: "+ preImageDeviceStatus);
                            int targetDeviceStatus = (targetEntity.Contains(ElevatorMasterDevice.DeviceStatus) && targetEntity[ElevatorMasterDevice.DeviceStatus] != null) ? targetEntity.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value : (int)ElevatorDeviceStatus.Active;
                            customTrace.AppendLine("targetDeviceStatus: " + targetDeviceStatus);
                            if (preImageDeviceStatus != targetDeviceStatus)//device status should be changed then go inside the block
                            {
                                ElevatorSafetyEligibleDeviceHandler.setCAT1CAT5EligibleFlags(serviceConnector, targetEntity, preImage, targetDeviceStatus, customTrace);
                            }
                        }
                        #endregion
                    }
                    #endregion

                }
                #endregion


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyEligibleDevices + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}
