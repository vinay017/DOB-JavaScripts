﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;
using ExternalSystemIntegration.Objects;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// WorkFlowPlugin [Plugin to execute Workflow] [Post Operation] -- 1)Also used to create SPH for ELV3 in adjustment scenario only in Accepted status
    ///                                                                 2) Call Defects Workflow to copt defects to master defects 
    ///                                                                 3) Upadte Master Device Dates when ELV3 is accepted or accepted defects
    ///                                                                 4)Attestation Emails
    ///                                                                
    /// Reporting Dates [Pre Operation] --1) Used to set the adjustment money
    ///                                   2) Set the violation dismissal flag to yes
    /// Register on Entity
    ///     * Post-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv3 (primary)
    ///           * Filtering Attributes - Report status,Inspector attestation, director attestation , Witness inspector attestation ,witness director attestation, property owner attestation
    ///           * Pre Image - All attributes
    ///     * Pre-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv3 (primary)
    ///           * Filtering Attributes - Report status
    ///            * Pre Image - All attributes
    ///            
    ///  * Post-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv29 (primary)
    ///           * Filtering Attributes - Report status,Inspector attestation, director attestation , property owner attestation
    ///           * Pre Image - All attributes
    ///            
    ///  * Pre-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv29 (primary)
    ///           * Filtering Attributes - Report status
    ///            * Pre Image - All attributes
    ///            
    ///  * Post-Update Stage - Synchronous - Server - SVC CRMDEPADMDEV - Exe order (1) - dobnyc_elv36 (primary)
    ///           * Filtering Attributes - Report status
    ///           * Pre Image - All attributes
    ///           
    /// Date: 12/11/2017
    /// Written By: Vinay
    /// </summary>
    /// <param name="serviceProvider"></param>
    /// 
    public class WorkflowPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            bool callReportDefectWF = false;
            ConditionExpression conditionReportLink = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                if (targetEntity == null)
                    return;



                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];

                if (context.Stage == 40)
                {
                    if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                    {
                        customTrace.AppendLine("Start ELV3InspectionAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                        WorkflowHandler.ELV3WorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                        customTrace.AppendLine("End ELV3InspectionAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);

                        #region call report defect workflow on elv3 accepted
                        if (targetEntity.Contains(ELV3InspectionAttributeNames.ReportStatus)
                            && (targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.Accepted || targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.AcceptedDefects|| targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.Received)//received for personal Hoists
                            )
                        {
                            customTrace.AppendLine("ELV3 accepted");
                            callReportDefectWF = true;
                            conditionReportLink = new ConditionExpression(ReportDefectEntityAttributeNames.ELV3, ConditionOperator.Equal, targetEntity.Id);

                            #region Adjustments for NYCHA Owner Type
                            if ((preTargetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && preTargetEntity[ELV3InspectionAttributeNames.OwnerType] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.NYCHA) && //owner type should be NYCHA and Amount Paid should be >0 
                                (preTargetEntity.Contains(ELV3InspectionAttributeNames.AmountPaid) && preTargetEntity[ELV3InspectionAttributeNames.AmountPaid] != null && preTargetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0))
                            {
                                customTrace.AppendLine("Owner Type : NYCHA and AmountPaid>0 start");
                                //create a shadow payment History with Adjustment Transaction History

                                Guid shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreatePaymentHistoryRecord(serviceConnector, preTargetEntity, customTrace);
                                ELV3FeeCalculationHandler.CreateElevatorSafetyTransactionHistoryRecords(targetEntity, shadowPaymentHistoryGuid, serviceConnector, customTrace, preTargetEntity, preTargetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, context.SharedVariables);
                            }
                            #endregion


                            #region Update Elevator Master Device Date Fields
                            WorkflowHandler.UpdateMasterDeviceDates(serviceConnector, targetEntity, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value);
                            #endregion

                        }
                        #endregion
                    }
                    else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                    {
                        customTrace.AppendLine("Start ELV29AffirimationAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                        WorkflowHandler.ELV29WorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                        customTrace.AppendLine("End ELV29AffirimationAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);

                        #region call report defect workflow on elv29 accepted
                        if ((targetEntity.Contains(ELV29AffirimationAttributeNames.ReportStatus) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.Accepted)||
                            (targetEntity.Contains(ELV29AffirimationAttributeNames.ReportStatus) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.AcceptedCorrectionsViolationDismissed)||
                            (targetEntity.Contains(ELV29AffirimationAttributeNames.ReportStatus) && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.AcceptedCorrectionsViolationNotDismissed))
                        {
                            customTrace.AppendLine("ELV29 accepted");
                            callReportDefectWF = true;
                            conditionReportLink = new ConditionExpression(ReportDefectEntityAttributeNames.ELV29, ConditionOperator.Equal, targetEntity.Id);
                        }
                        #endregion "dobnyc_elevatorsafetyfilingactions"

                      

                    }
                    else if (targetEntity.LogicalName == ELV36TestNotificationAttributeNames.EntityLogicalName)
                    {
                        customTrace.AppendLine("Start ELV36TestNotificationAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                        WorkflowHandler.ELV36WorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                        customTrace.AppendLine("End ELV36TestNotificationAttributeNames Workflow handler: " + PluginHelperStrings.UpdateMessageName);

                       
                    }
                    // CALL REPORT DEFECT WORKFLOW
                    if (callReportDefectWF)
                    {
                        customTrace.AppendLine("fetch report defects");
                        QueryExpression query = new QueryExpression(ReportDefectEntityAttributeNames.EntityLogicalName);
                        query.ColumnSet = new ColumnSet(new string[] { ReportDefectEntityAttributeNames.ReportDefectId });
                        query.Criteria = new FilterExpression(LogicalOperator.And)
                        {
                            Conditions =
                            {
                                conditionReportLink
                            }
                        };
                        EntityCollection records = serviceConnector.RetrieveMultiple(query);
                        foreach (var reportDefect in records.Entities)
                        {
                            customTrace.AppendLine("start report defect workflow");
                            WorkflowHandler.ReportDefectsWorkFlow(serviceConnector, reportDefect, customTrace);
                            customTrace.AppendLine("end report defect workflow");
                        }
                    }
                }
                else if (context.Stage == 20)
                {
                    if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                    {
                        #region  Set Report Dates Based on Report Status
                        if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.ReportStatus))
                        {
                            customTrace.AppendLine("Report Status was changed (Verify)...");
                            customTrace.AppendLine("...Get Changed Report Status");
                            OptionSetValue currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus);
                            customTrace.AppendLine(".......Current Report Status: " + currentReportStatus.Value.ToString());

                            customTrace.AppendLine("...Get Original Report Status");
                            OptionSetValue previousReportStatus = preTargetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus);
                            customTrace.AppendLine("......PreviousReportStatus: " + previousReportStatus.Value.ToString());

                            if (previousReportStatus != null && currentReportStatus != null && (currentReportStatus.Value != previousReportStatus.Value))
                            {
                                customTrace.AppendLine("Report Status was changed (confirmed)...");
                                customTrace.AppendLine(" Update Dates on ELV1 ");
                                targetEntity = SubmitHandler.UpdateDateIfApplicable(serviceConnector, targetEntity, preTargetEntity, currentReportStatus, customTrace);
                                customTrace.AppendLine(" ELV3 Updated");
                            }
                        }
                        #endregion
                    }
                    else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                    {
                        #region  Set Report Dates Based on Report Status
                        if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.ReportStatus))
                        {
                            customTrace.AppendLine("Report Status was changed (Verify)...");
                            customTrace.AppendLine("...Get Changed Report Status");
                            OptionSetValue currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus);
                            customTrace.AppendLine(".......Current Report Status: " + currentReportStatus.Value.ToString());

                            customTrace.AppendLine("...Get Original Report Status");
                            OptionSetValue previousReportStatus = preTargetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus);
                            customTrace.AppendLine("......PreviousReportStatus: " + previousReportStatus.Value.ToString());

                            if (previousReportStatus != null && currentReportStatus != null && (currentReportStatus.Value != previousReportStatus.Value))
                            {
                                customTrace.AppendLine("Report Status was changed (confirmed)...");
                                customTrace.AppendLine(" Update Dates on ELV1 ");
                                targetEntity = SubmitHandler.UpdateDateELV29IfApplicable(serviceConnector, targetEntity, preTargetEntity, currentReportStatus, customTrace);
                                customTrace.AppendLine(" ELV3 Updated");
                            }

                            #region Dismiss Violations for PVT QC ELV29 when status is violations Dismissed
                            ///1)report status should be corrections accepted-violations Dismissed
                            ///2)Parent ELv3 should have DOB Elevators Violation Number
                            ///3)After Successful Dismissal of violation set the violation dismissed flag to YES.
                            ///
                            if (targetEntity.Contains(ELV29AffirimationAttributeNames.ReportStatus) && targetEntity[ELV29AffirimationAttributeNames.ReportStatus] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value == (int)ELV3ReportStatus.AcceptedCorrectionsViolationDismissed)
                            {
                                customTrace.AppendLine("Received Success from BIS");

                                targetEntity.Attributes.Add(ELV29AffirimationAttributeNames.violationDismissFlag, true);

                                customTrace.AppendLine("Updated the dismissal flag in ELV29");



                            }



                            #endregion
                        }
                        #endregion
                    }





                }

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.WorkflowPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}