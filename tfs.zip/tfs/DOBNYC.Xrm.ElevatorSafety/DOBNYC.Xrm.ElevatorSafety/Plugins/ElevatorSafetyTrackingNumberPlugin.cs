﻿using System;
using System.Text;
using System.ServiceModel;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.Xrm.ElevatorSafety.Plugins
{
    /// <summary>
    /// This Plugin is used to create tracking numbers for all the entities IN elevator Safety.
    ///   * Pre-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_elv3 (primary)
    ///    * Pre-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_elv29 (primary)
    ///     * Pre-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_elv36 (primary)
    ///     * Pre-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_groupnumber (primary)
    ///   Date: 12/1/2017
    /// Written By: Vinay 
    /// </summary>
    public class ElevatorSafetyTrackingNumberPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (!(targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName || targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName || targetEntity.LogicalName == ELV36TestNotificationAttributeNames.EntityLogicalName||targetEntity.LogicalName==ELV3Defect.EntityLogicalName||targetEntity.LogicalName==GroupNumber.EntityLogicalName))//if it is not elevator safety entity return from plugin.
                {
                    customTrace.AppendLine("-- ERROR::: Target Entity MISMATCH..");
                    return;
                }

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) &&
                   context.Stage == 20)
                {

                    if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                    {
                        #region ELV3 Inspection Number genreration
                        customTrace.AppendLine("ELV3 Inspection Number genreration plugin started ");
                        ElevatorSafetyTrackingNumberHandler.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("ELV3 Inspection Number genreration plugin Ended ");
                        #region ELV3 Property Profile Creation
                        if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.BIN) && (!(targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.PropertyProfileLookup))))//BNR contains BIn number
                        {
                            customTrace.AppendLine("Start Associate Property Profile to BNR");
                            targetEntity = ElevatorSafetyPropertyProfileHandler.AssociatePropertyProfile(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End Associate Property Profile to BNR ");
                        }
                        #endregion
                        #endregion
                    }
                    else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                    {
                        #region ELV29 Affirmation of Correction Number genreration
                        customTrace.AppendLine("ELV29 Affirmation of Correction Number genreration plugin started ");
                        ElevatorSafetyTrackingNumberHandler.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("ELV29 Affirmation of Correction Number genreration plugin Ended ");
                        #endregion

                        #region ELV29 Property Profile Creation
                        if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.BIN) && (!(targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.PropertyProfileLookup))))//BNR contains BIn number
                        {
                            customTrace.AppendLine("Start Associate Property Profile to BNR");
                            targetEntity = ElevatorSafetyPropertyProfileHandler.AssociatePropertyProfile(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End Associate Property Profile to BNR ");
                        }
                        #endregion
                    }
                    else if (targetEntity.LogicalName == ELV36TestNotificationAttributeNames.EntityLogicalName)
                    {
                        #region    ELV36 Test Notification Number genreration
                        customTrace.AppendLine("ELV36 Test Notification Number genreration plugin started ");
                        ElevatorSafetyTrackingNumberHandler.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("ELV36 Test Notification Number genreration plugin Ended ");
                        #endregion
                    }
                    else if(targetEntity.LogicalName==ELV3Defect.EntityLogicalName)
                    {
                        #region    ELV3 Defect Number Generation
                        customTrace.AppendLine("ELV3 Defect Number Generation plugin started ");
                        ElevatorSafetyTrackingNumberHandler.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("ELV3 Defect Number Generation plugin Ended ");
                        #endregion
                    }
                    else if (targetEntity.LogicalName == GroupNumber.EntityLogicalName)
                    {
                        #region    ELV3 Defect Number Generation
                        customTrace.AppendLine("GroupNumber Number Generation plugin started ");
                        ElevatorSafetyTrackingNumberHandler.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("GroupNumber Number Generation plugin Ended ");
                        #endregion
                    }
                }
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method Fault exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw new Exception(ex + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method TimeOut exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(customTrace.ToString());
                //throw new Exception(ex + customTrace.ToString());
            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ElevatorSafetyTrackingNumberPlugin + " - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + customTrace.ToString());
            }
            #endregion
        }
    }
}
