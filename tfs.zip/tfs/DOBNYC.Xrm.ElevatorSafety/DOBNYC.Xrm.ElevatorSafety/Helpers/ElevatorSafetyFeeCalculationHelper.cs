﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DOB.Logging;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using DOBNYC.Xrm.ElevatorSafety.PluginHandlers;
using DOBNYC.Xrm.ElevatorSafety.Common;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.Xrm.ElevatorSafety.Helpers
{
    class ElevatorSafetyFeeCalculationHelper : PluginHandlerBase
    {
        public static EntityCollection RetrieveFee(StringBuilder crmTrace, IOrganizationService service, string formulaeName)
        {
            crmTrace.AppendLine("Start: retrieve fee..");
            ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });

            return (RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName,
                  new string[] { FeeCalculationConfigurationAttributeNames.MinFilingFee, FeeCalculationConfigurationAttributeNames.Tier1CostFee,
                        FeeCalculationConfigurationAttributeNames.CheckBounce, FeeCalculationConfigurationAttributeNames.PaaFee, FeeCalculationConfigurationAttributeNames.InConjunctionJobFee,
                     FeeCalculationConfigurationAttributeNames.Tier1CostFee,FeeCalculationConfigurationAttributeNames.RecordManagementFee,FeeCalculationConfigurationAttributeNames.LegalizationFeeMul }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And));
        }

        public static EntityCollection GetTransactionCodes(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, ConditionExpression condition)
        {
            crmTrace.AppendLine("Get transaction codes");

            EntityCollection transCodesResponse = new EntityCollection();
            try
            {
                #region retrieve Transaction Code Info
                crmTrace.AppendLine("Retrieve the transaction code information : started");
                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource,TransactionCodeAttributeNames.FeeSchemaName,TransactionCodeAttributeNames.TransactionText,
                TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { condition }, LogicalOperator.Or);
                crmTrace.AppendLine("Retrieve the transaction code information : ended");

                #endregion

                return transactioncodeResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static Guid CreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Guid Jobid, Guid PaymentHistoryId, Entity TransCodeId, Money fee)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                Entity transHistory = null;
                if (!string.IsNullOrEmpty(Jobid.ToString()) && !string.IsNullOrEmpty(fee.ToString()))
                {
                    crmTrace.AppendLine("Create Transaction history - Start");
                    transHistory = new Entity();

                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    if (TransCodeId.LogicalName == TransactionCodeAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("CAll from TransactionCodeAttributeNames.EntityLogicalName ");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.ToEntityReference());
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionCodeAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.Attributes[TransactionCodeAttributeNames.TransactionText]);

                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionCodeAttributeNames.TransType]);
                    }
                    // this if block will be executed in EOD handler.
                    else if (TransCodeId.LogicalName == TransactionHistoryAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("CAll from TransactionHistoryAttributeNames.EntityLogicalName ");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.GetAttributeValue<EntityReference>(TransactionHistoryAttributeNames.TransactionCodeId));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode));
                        crmTrace.AppendLine("Create Transaction history - assigned 2 - eod");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionHistoryAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionHistoryAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionHistoryAttributeNames.RevenueSource]);
                        crmTrace.AppendLine("Create Transaction history - assigned 3 more - eod");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionHistoryAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.Attributes[TransactionHistoryAttributeNames.TransactionText]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionHistoryAttributeNames.TransType]);
                    }
                  //  transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.JobNumber));
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.shadowPaymentHistoryLookup, new EntityReference(ShadowPaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId)); //attach TH to SPH
                    crmTrace.AppendLine("Associate to SPH ");
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);
                    
                    Guid Id = service.Create(transHistory);
                    crmTrace.AppendLine("Create Transaction history - end");

                    return Id;
                }
                else
                    return new Guid();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static Guid PHCreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Guid Jobid, Guid PaymentHistoryId, Entity TransCodeId, Money fee)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                Entity transHistory = null;
                if (!string.IsNullOrEmpty(Jobid.ToString()) && !string.IsNullOrEmpty(fee.ToString()))
                {
                    crmTrace.AppendLine("Create Transaction history - Start");
                    transHistory = new Entity();

                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    if (TransCodeId.LogicalName == TransactionCodeAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.ToEntityReference());
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode));
                    }
                    // this if block will be executed in EOD handler.
                    else if (TransCodeId.LogicalName == TransactionHistoryAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.GetAttributeValue<EntityReference>(TransactionHistoryAttributeNames.TransactionCodeId));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode));
                    }
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.JobNumber));
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.PaymentInvoice, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId));

                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionCodeAttributeNames.SubSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.Attributes[TransactionCodeAttributeNames.TransactionText]);

                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionCodeAttributeNames.TransType]);
                    Guid Id = service.Create(transHistory);
                    crmTrace.AppendLine("Create Transaction history - end");

                    return Id;
                }
                else
                    return new Guid();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }


        /// <summary>
        /// Return the Number of SPH with isposted No.
        /// By Vinay 11/10/2016
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="CustomTrace"></param>  
        /// <return></return>
        public static EntityCollection FeeExemptUpdateSPH(IOrganizationServiceConnector service, Entity targetEntity, StringBuilder customTrace)
        {
            EntityCollection allNonePostedSPH = new EntityCollection();

            //get all none posted SPH and delete them
            if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
            {
                allNonePostedSPH = GetAllShadowPaymentHistory(service, targetEntity, 0, 38, customTrace);
                
            }
            else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
            {
                allNonePostedSPH = GetAllShadowPaymentHistory(service, targetEntity, 0, 39, customTrace);
            }

            //if (allNonePostedSPH != null)
            //{

            //    foreach (Entity record in allNonePostedSPH.Entities)
            //    {
            //        service.Delete(record.LogicalName, record.Id);
            //    }
            //}

            return allNonePostedSPH;

        }

        /// <summary>
        /// Get All Not Posted Shadow Payment History
        /// IsPosted = 0 - not posted; IsPosted = 1 - Posted; IsPosted = 2 - Get both post and none-posted
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="targetEntity"></param>
        /// <param name="IsPosted"></param>
        /// <param name="customTrace"></param>
        /// <returns></returns>
        public static EntityCollection GetAllShadowPaymentHistory(IOrganizationServiceConnector serviceConnector, Entity targetEntity, int IsPosted, int FeeType, StringBuilder customTrace)
        {
            EntityCollection result = null;
            try
            {
                customTrace.AppendLine("Start GetAllShadowPaymentHistory ");
                //string  =  @"<condition attribute='dobnyc_isposted' value='"+IsPosted+ @"' operator='eq'/>";
                //string ContainPHLookUpCondition = IsPosted == 0 ? @"<condition attribute='dobnyc_sph_paymenthistory' operator='null' />" :
                //                                                  @"<condition attribute='dobnyc_sph_paymenthistory' operator='not-null' />";
                string FeeTypeCondition = FeeType == 0 ? "" : @" <condition attribute='dobnyc_sph_feetype' operator='eq' value='" + FeeType + @"' />";
                string fetchXML = @"<?xml version='1.0'?>
                                <fetch distinct='false' mapping='logical' no-lock='true' output-format='xml-platform' version='1.0'>
                                  <entity name='dobnyc_shadowpaymenthistory'>
                                    <attribute name='dobnyc_shadowpaymenthistoryid'/>
                                    <attribute name='dobnyc_sph_feetype'/>
                                    <attribute name='dobnyc_sph_totalfee' />
                                    <order attribute='createdon' descending='true' />
                                    <filter type='and'>
                                      <condition attribute='{0}' value='{1}' uitype='{2}' operator='eq'/>
                                      {3}
                                      
                                      <condition attribute='dobnyc_sph_isposted' operator='eq' value='0' />
                                      <condition attribute='dobnyc_sph_boilernogoodcheckflag' operator='eq' value='0' />
                                      
                                    </filter>
                                  </entity>
                                </fetch>";

                string fetchXMLToExecute = string.Empty;

                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {

                    fetchXMLToExecute = IsPosted != 2 ? string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.ELV3Lookup, targetEntity.Id.ToString(), ELV3InspectionAttributeNames.EntityLogicalName, FeeTypeCondition ) :
                                                        string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.ELV3Lookup, targetEntity.Id.ToString(), ELV3InspectionAttributeNames.EntityLogicalName,  FeeTypeCondition);
                }
                else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    fetchXMLToExecute = IsPosted != 2 ? string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.ELV29Lookup, targetEntity.Id.ToString(), ELV29AffirimationAttributeNames.EntityLogicalName, FeeTypeCondition) :
                                                        string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.ELV29Lookup, targetEntity.Id.ToString(), ELV29AffirimationAttributeNames.EntityLogicalName, FeeTypeCondition);
                }
                //else if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                //{
                //    fetchXMLToExecute = IsPosted != 2 ? string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.BoilerCivilPenalties, targetEntity.Id.ToString(), BoilerCivilPenaltiesEntityAttributeName.EntityLogicalName, ContainPHLookUpCondition, FeeTypeCondition) :
                //                                        string.Format(fetchXML, ShadowPaymentHistoryAttributeNames.BoilerCivilPenalties, targetEntity.Id.ToString(), BoilerCivilPenaltiesEntityAttributeName.EntityLogicalName, "", FeeTypeCondition);
                //}

                customTrace.AppendLine("fetchXMLToExecute:  " + fetchXMLToExecute);

                if (fetchXMLToExecute != string.Empty)
                {
                    result = serviceConnector.RetrieveMultiple(new FetchExpression(fetchXMLToExecute));
                }

                customTrace.AppendLine("End GetAllShadowPaymentHistory ");
                return result;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - GetAllShadowPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }

        }

        /// <summary>
        /// Get All TH for the Shadow Payment History
        /// 
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="targetEntity">Guid of SPH</param>
        /// <param name="IsPosted"></param>
        /// <param name="customTrace"></param>
        /// <returns></returns>
        public static EntityCollection DeleteAllTHForShadowPaymentHistory(IOrganizationServiceConnector serviceConnector, Guid targetEntity, StringBuilder customTrace)
        {
            EntityCollection result = null;
            try
            {
                customTrace.AppendLine("Start GetAllTransactionHistory ");
                //string  =  @"<condition attribute='dobnyc_isposted' value='"+IsPosted+ @"' operator='eq'/>";
             
                string fetchXML = @"<?xml version='1.0'?>
                                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_transactionhistory'>
                                    <attribute name='dobnyc_transactionhistoryid' />
                                    <attribute name='dobnyc_name' />
                                    <attribute name='createdon' />
                                    <order attribute='dobnyc_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_th_shadowpaymenthistory' operator='eq'  uitype='dobnyc_shadowpaymenthistory' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                string fetchXMLToExecute = string.Empty;

                fetchXMLToExecute = string.Format(fetchXML, targetEntity.ToString());

               

                customTrace.AppendLine("fetchXMLToExecute:  " + fetchXMLToExecute);

                if (fetchXMLToExecute != string.Empty)
                {
                    result = serviceConnector.RetrieveMultiple(new FetchExpression(fetchXMLToExecute));
                }

                customTrace.AppendLine("End GetAllTransactionHistory : "+ result.Entities.Count);

                if(result!=null && result.Entities.Count>0)
                {
                    foreach (Entity record in result.Entities)
                    {
                        serviceConnector.Delete(record.LogicalName, record.Id);
                    }
                }
                return result;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "ElevatorSafetyFeeCalculationHelper - DeleteAllTHForShadowPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return result;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }

        }


    }
}
