﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using System.Globalization;
using System.Xml.Serialization;
using Microsoft.Xrm.Sdk;
using DOBNYC.Xrm.ElevatorSafety.Common;
namespace DOBNYC.Xrm.ElevatorSafety.Helpers
{
    public static class CommonPluginLibrary
    {
        internal static Entity GetEntityFromContext(IPluginExecutionContext context)
        {

            Entity entity = null;
            if (context.InputParameters.Contains(ParameterName.Target) &&
                context.InputParameters[ParameterName.Target] is Entity)
            {
                entity = (Entity)context.InputParameters[ParameterName.Target];
            }

            return entity;
        }

        internal static EntityReference GetEntityReferenceFromContext(IPluginExecutionContext context)
        {

            EntityReference entityReference = null;
            if (context.InputParameters.Contains(ParameterName.Target) &&
                context.InputParameters[ParameterName.Target] is EntityReference)
            {
                entityReference = (EntityReference)context.InputParameters[ParameterName.Target];
            }

            return entityReference;
        }

        internal static Entity GetEntityFromContextOutputParameters(IPluginExecutionContext context)
        {

            Entity entity = null;
            if (context.OutputParameters.Contains(ParameterName.BusinessEntity) &&
                context.OutputParameters[ParameterName.BusinessEntity] is Entity)
            {
                entity = (Entity)context.OutputParameters[ParameterName.BusinessEntity];
            }

            return entity;
        }

        internal static EntityReference GetEntityMonikerFromContext(IPluginExecutionContext context)
        {
            EntityReference referenceInstance = null;
            if (context.InputParameters.Contains(ParameterName.EntityMoniker) &&
                context.InputParameters[ParameterName.EntityMoniker] is EntityReference)
            {
                referenceInstance = (EntityReference)context.InputParameters[ParameterName.EntityMoniker];
            }

            return referenceInstance;
        }

        internal static IPluginExecutionContext GetContextFromIServiceProvider(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            Microsoft.Xrm.Sdk.IPluginExecutionContext context = (Microsoft.Xrm.Sdk.IPluginExecutionContext)
                serviceProvider.GetService(typeof(Microsoft.Xrm.Sdk.IPluginExecutionContext));

            return context;
        }

        internal static string GetStringFromObject(Entity entity, string key)
        {

            if (!entity.Attributes.Contains(key))
                return string.Empty;

            if (entity.Attributes[key] is KeyValuePair<string, object>)
            {
                KeyValuePair<string, object> temp = (KeyValuePair<string, object>)entity.Attributes[key];

                if (temp.Value is string || temp.Value is Guid)
                {
                    return temp.Value.ToString();
                }
                else if (temp.Value is OptionSetValue)
                {
                    OptionSetValue tempValue = (OptionSetValue)temp.Value;
                    return tempValue.Value.ToString();
                }
                return string.Empty;
            }
            else if (entity.Attributes[key] is OptionSetValue)
            {
                OptionSetValue temp = (OptionSetValue)entity.Attributes[key];
                return temp.Value.ToString();
            }
            else if (entity.Attributes[key] is string)
                return entity.Attributes[key].ToString();

            return string.Empty;

        }

        internal static string GetStringFromInputParameters(IPluginExecutionContext context, string p)
        {
            if (!context.InputParameters.Contains(p))
                return string.Empty;

            if (context.InputParameters[p] is KeyValuePair<string, object>)
            {
                return ((KeyValuePair<string, object>)context.InputParameters[p]).Value.ToString();
            }
            else if (context.InputParameters[p] is string)
                return context.InputParameters[p].ToString();
            else if (context.InputParameters[p] is OptionSetValue)
            {
                OptionSetValue temp = (OptionSetValue)context.InputParameters[p];
                return temp.Value.ToString();
            }

            return string.Empty;

        }


        internal static Entity LoadEntity(Entity entitytobeMerged, string entityLogicalName, IOrganizationService service)
        {
            Entity updatedEntitiy = service.Retrieve(entityLogicalName, entitytobeMerged.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet(true));
            Merge(entitytobeMerged, updatedEntitiy);
            return updatedEntitiy;
        }


        internal static void Merge(Entity entity, Entity loadedEntity)
        {
            if (loadedEntity != null)
            {

                foreach (string key in loadedEntity.Attributes.Keys)
                {
                    if (!entity.Attributes.Contains(key))
                    {
                        entity.Attributes.Add(key, loadedEntity[key]);
                    }
                }
            }
        }


        internal static void SetAttributeValue(this Entity entity, string attributeName, object value)
        {
            if (entity.Attributes.Contains(attributeName))
                entity.Attributes[attributeName] = value;
            else
                entity.Attributes.Add(attributeName, value);
        }
    }
}
