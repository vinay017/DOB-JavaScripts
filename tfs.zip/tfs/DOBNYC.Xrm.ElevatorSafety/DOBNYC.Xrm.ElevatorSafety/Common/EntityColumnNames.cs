﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.Xrm.ElevatorSafety.Common
{
    public sealed class BoroughNames
    {
        public const string Brooklyn = "Brooklyn";
        public const string Manhattan = "Manhattan";
        public const string Queens = "Queens";
        public const string StatenIsland = "Staten Island";
        public const string Bronx = "Bronx";
    }
    public sealed class AnnotationEntityAttributeNames
    {
        public const string ObjectIdFieldName = "objectid";
        public const string NoteTextFieldName = "notetext";
        public const string IsDocumentFieldName = "isdocument";
        public const string SubjectFieldName = "subject";
        public const string FileNameFieldName = "filename";
        public const string DocumentBodyFieldName = "documentbody";
        public const string MimeTypeFieldName = "mimetype";
        public const string ObjectTypeCodeFieldName = "objecttypecode";
        public const string AnnotationId = "annotationid";
        public const string ObjectTypeCode = "objecttypecode";
        public const string Subject = "subject";
        public const string CreatedBy = "createdby";
        public const string CreatedOn = "createdon";
        public const string FileName = "filename";
        public const string DocumentBody = "documentbody";
        public const string MimeType = "mimetype";
    }


    public sealed class PropertyProfileAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_propertyprofile";
        public const string EntityNameField = "dobnyc_name";
        public const string dobnyc_AdditionalBINsforBuilding = "dobnyc_additionalbinsforBuilding";
        public const string dobnyc_Borough = "dobnyc_borough";
        public const string dobnyc_BuildingsonLot = "dobnyc_buildingsonlot";
        public const string dobnyc_CensusTract = "dobnyc_censustract";
        public const string dobnyc_CityOwned = "dobnyc_cityOwned";
        public const string dobnyc_CommunityBoard = "dobnyc_communityBoard";
        public const string dobnyc_Condo = "dobnyc_condo";
        public const string dobnyc_CrossStreet1 = "dobnyc_crossStreet1";
        public const string dobnyc_CrossStreet1Numbers = "dobnyc_CrossStreet1Numbers";
        public const string dobnyc_CrossStreet2 = "dobnyc_CrossStreet2";
        public const string dobnyc_CrossStreet2Numbers = "dobnyc_CrossStreet2Numbers";
        public const string dobnyc_CrossStreet3 = "dobnyc_CrossStreet3";
        public const string dobnyc_CrossStreet3Numbers = "dobnyc_CrossStreet3Numbers";
        public const string dobnyc_CrossStreet4 = "dobnyc_CrossStreet4";
        public const string dobnyc_CrossStreet4Numbers = "dobnyc_CrossStreet4Numbers";
        public const string dobnyc_CrossStreets = "dobnyc_CrossStreets";
        public const string dobnyc_DOBBuildingRemarks = "dobnyc_DOBBuildingRemarks";
        public const string dobnyc_DOBSpecialPlaceName = "dobnyc_DOBSpecialPlaceName";
        public const string dobnyc_EnvironmentalRestrictions = "dobnyc_EnvironmentalRestrictions";
        public const string dobnyc_GrandfatheredSign = "dobnyc_GrandfatheredSign";
        public const string dobnyc_HealthArea = "dobnyc_HealthArea";
        public const string dobnyc_HouseNo = "dobnyc_HouseNo";
        public const string dobnyc_LandmarkStatus = "dobnyc_LandmarkStatus";
        public const string dobnyc_LegalAdultUse = "dobnyc_LegalAdultUse";
        public const string dobnyc_LocalLaw = "dobnyc_LocalLaw";
        public const string dobnyc_LoftLaw = "dobnyc_LoftLaw";
        public const string dobnyc_SpecialDistrict = "dobnyc_SpecialDistrict";
        public const string dobnyc_SpecialStatus = "dobnyc_SpecialStatus";
        public const string dobnyc_SRORestricted = "dobnyc_SRORestricted";
        public const string dobnyc_Street = "dobnyc_Street";
        public const string dobnyc_StreetName = "dobnyc_StreetName";
        public const string dobnyc_StreetNumbers = "dobnyc_StreetNumbers";
        public const string dobnyc_TARestricted = "dobnyc_TARestricted";
        public const string dobnyc_TaxBlock = "dobnyc_TaxBlock";
        public const string dobnyc_TaxLot = "dobnyc_TaxLot";
        public const string dobnyc_UBRestricted = "dobnyc_UBRestricted";
        public const string dobnyc_Vacant = "dobnyc_Vacant";
        public const string dobnyc_Zip = "dobnyc_Zip";
        public const string dobnyc_JobFilingRecord_PP = "dobnyc_JobFilingRecord_PP";
        public const string Latitude = "dobnyc_latitude";
        public const string Longitude = "dobnyc_longitude";
        public const string SpecialArea1 = "dobnyc_specialarea1";
        public const string SpecialArea2 = "dobnyc_specialarea2";
        public const string SpecialArea3 = "dobnyc_specialarea3";
        public const string SpecialArea4 = "dobnyc_specialarea4";
        public const string SpecialArea5 = "dobnyc_specialarea5";
        public const string TransitAuthority = "dobnyc_transitauthority";
        public const string SpecialDistrict1 = "dobnyc_specialdistrict1";
        public const string SpecialDistrict2 = "dobnyc_specialdistrict2";
        public const string LoftFlag = "dobnyc_loftflag";
        public const string TR6Record = "dobnyc_tr6record";
        public const string PropertyProfileId = "dobnyc_propertyprofileid";
        public const string TidalWetlandsMapCheck = "dobnyc_pp_tidalwetlandsmapcheck";
        public const string FreshwaterWetlandsMapCheck = "dobnyc_pp_freshwaterwetlandsmapcheck";
        public const string CoastalErosionHazardAreaMapCheck = "dobnyc_pp_coastalerosionhazardareamapcheck";
        public const string SpecialFloodHazardAreaCheck = "dobnyc_pp_specialfloodhazardareacheck";
        public const string SpecialAreaString = "dobnyc_pp_specialareastring";
        public const string CrossStreet5 = "dobnyc_pp_crossstreet5";
        public const string CrossStreet5Numbers = "dobnyc_pp_crossstreet5number";
        public const string CrossStreet6 = "dobnyc_pp_crossstreet6";
        public const string CrossStreet6Numbers = "dobnyc_pp_crossstreet6numbers";
        public const string CensusTractString = "dobnyc_pp_censustractstring";
        public const string DepartmentofFinanceBuildingClassification = "dobnyc_vlfinaoccupancy";
        public const string CreatedOn = "createdon";


    }


    public sealed class AutoNumberEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_autonumberentity";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string FacadesCounter = "dobnyc_facadescounter";
        public const string FacadesPaddingNumber = "dobnyc_facadespaddingnumber";
        public const string FacadesPaddingCharacter = "dobnyc_facadespaddingcharacter";

    }

    public sealed class ElevatorSafetyBISRequestResponse
    {
        public const string EntityLogicalName = "dobnyc_elevatorsafetybisrequestresponse";
        public const string name = "dobnyc_name";
        public const string overallText = "dobnyc_elsrr_overalltext";
        public const string returnCode = "dobnyc_elsrr_returncode";
        public const string elv3Lookup = "dobnyc_elsrr_elv3lookup";
        public const string elv29Lookup = "dobnyc_elsrr_elv29lookup";
        public const string violationLookup = "dobnyc_elsrr_violationnumberlookup";
        public const string errorMessages="dobnyc_errormessagefrombis";

    }

    //This Class is used to store all the field names of ELV3.
    public sealed class ELV3InspectionAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_elv3";
        public const string dismissViolationsFlag = "dobnyc_elv3_dismissviolations";
        public const string ELV3Id = "dobnyc_elv3id";
        public const string Name = "dobnyc_name";
        public const string AmountPaid = "dobnyc_elv3_amountpaid";
        public const string Adjustment = "dobnyc_elv3_adjustment";
        public const string AmountDue = "dobnyc_elv3_amountdue";
        public const string FilingFee = "dobnyc_elv3_filingfee";
        public const string LateFilingFee = "dobnyc_elv3_latefilingfee";
        public const string ELV3NRFFee = "dobnyc_elv3_elv3nrffee";
        public const string ELV29NRFFee = "dobnyc_elv3_elv29nrffee";
        public const string Totalfee = "dobnyc_elv3_totalfee";
        public const string BIN = "dobnyc_bin";
        public const string Borough= "dobnyc_borough";
        public const string HouseNumber = "dobnyc_housenumber";
        public const string StreetName = "dobnyc_streetname";
        public const string InspectionType = "dobnyc_inspectiontype";
        public const string Issubmitted = "dobnyc_elv3_issubmitted";
        public const string IsFilingFeePaid = "dobnyc_elv3_isfilingfeepaid";
        public const string IsLateFilingFeePaid = "dobnyc_elv3_islatefilingfeepaid";
        public const string InspectionDate = "dobnyc_inspectiontestdate";
        public const string DeviceIdLookup = "dobnyc_elv3_elevatorid";
        public const string OwnerType = "dobnyc_owner_type";
        public const string ReportYear = "dobnyc_filingyear";
        public const string TrackingNumber = "dobnyc_trackingnumber";
        public const string ReportStatus = "dobnyc_elv3_reportstatus";
        public const string RevertedIncompleteSubmission = "dobnyc_revertedtoincompletesubmissionform";
        public const string FilingDate = "dobnyc_elv3_submissiondate";
        public const string QASupervisorReviewDate = "dobnyc_elv3_qasupervisorreviewdate";
        public const string QAReviewDate = "dobnyc_elv3_qareviewdate";
        public const string QAFailedDate = "dobnyc_elv3_qafaileddate";
        public const string AccepetedDAte = "dobnyc_elv3_accepeted";
        public const string AccepetedDefectsDAte = "dobnyc_elv3_accepteddefectsdate";
        public const string FeesCalculationDate = "dobnyc_elv3_feescalculationdate";
        public const string IncompleteSubmissionDate = "dobnyc_elv3_incompletesubmissiondate";
        public const string UserFilingActions = "dobnyc_elv3_userfilingactions";
        public const string ResubmissionDate = "dobnyc_elv3_resubmissiondate";
        public const string PropertyProfileLookup = "dobnyc_elv3_propertyprofile";
        public const string ELV3PaymentMethod = "dobnyc_elv3_paymentmethod";
        public const string sharedAmountDue = "sharedAmountDue"; //used to store amountdue in pre-operation such that if amount due>0 then create the payment history else do not create
        public const string sharedFilingFee = "sharedFilingFee";
        public const string sahredLateFilingFee = "sahredLateFilingFee";
        public const string sahredNoGoodCheckFee = "sahredNoGoodCheckFee";
        public const string sahredELV3NRFFee = "sahredELV3NRFFee";
        public const string sahredELV29NRFFee = "sahredELV29NRFFee";
        public const string sahredELV3NRFRecordCount = "sahredELV3NRFRecordCount";//used to identify how many ELV3 failure to file TH should be added
        public const string sahredELV29NRFRecordCount = "sahredELV29NRFRecordCount";//used to identify how many ELV29 failure to file TH should be added
        public const string IsDefectsExist = "dobnyc_elv3_isdefectsexist";
        public const string ceaseUseFlag = "dobnyc_elv3_ceaseuse";
        public const string TNFId = "dobnyc_elv3_tnfid";
        public const string TNFSubmitted = "dobnyc_tnfsubmitted";
        public const string TNFSubmitted3DaysAdvance = "dobnyc_tnfsubmitted3daysadvance";
        public const string SubmissionDate = "dobnyc_elv3_submissiondate";
        public const string ReSubmissionDate = "dobnyc_elv3_resubmissiondate";
        public const string InspectionDateAhead1Day = "dobnyc_inspectiondateahead1day";
        public const string TempRenewalExpiredOnTNFSubmitDate = "dobnyc_90daysexpiredontnfsubmitdate";
        public const string TempRenewalExpiredOnInspectionDate = "dobnyc_90daysexpiredoninspectiondate";
        public const string ReportType = "dobnyc_reporttype";
        public const string noGoodCheckFee= "dobnyc_elv3_nogoodcheckfee";
        public const string ELV3NRFLookup= "dobnyc_elv3_elv3nrflookup";
        public const string statecode = "statecode";
        public const string statusReason= "statuscode";
        public const string violationDate = "dobnyc_elv3_violationdate";
        public const string violationNumber = "dobnyc_elv3_violation";
        public const string sequenceNumber = "dobnyc_elv3_sequencenumber";
        public const string inspectingAgencyDirectorLegalStatement = "dobnyc_inspectingagency_legalstatement";
        public const string inspectingAgencyDirectorSignature = "dobnyc_inspectingagency_directorname";
        public const string inspectingAgencyDirectorSignatureDate = "dobnyc_inspectingagency_signdate";
        public const string inspectingAgencyInspectorLegalStatement = "dobnyc_inspectingagency_insplegalstatement";
        public const string inspectingAgencyInspectorSignature = "dobnyc_inspectingagency_inspectorsname";
        public const string inspectingAgencyInspectorSignatureDate = "dobnyc_inspectingagency_inspectorsigndate";
        public const string BuildPermitExpired = "dobnyc_elv3_isbuildpermitexpired";
        public const string witnessAgencyDirectorLegalStatement = "dobnyc_witnessingagency_legalstatement";
        public const string witnessAgencyDirectorSignature = "dobnyc_witnessingagency_directorname";
        public const string witnessAgencyDirectorSignatureDate = "dobnyc_witnessingagency_signdate";
        public const string witnessAgencyInspectorLegalStatement = "dobnyc_witnessingagency_insplegalstatement";
        public const string witnessAgencyInspectorSignature = "dobnyc_witnessingagency_inspectorname";
        public const string witnessAgencyInspectorSignatureDate = "dobnyc_witnessingagency_inspectorsigndate";

        public const string ownerLegalStatement = "dobnyc_propertyowner_legalstatement";
        public const string ownerSignature = "dobnyc_propertyowner_name";
        public const string ownerSignatureDate = "dobnyc_propertyowner_signdate";
        public const string TNFSubmittedAdvanceDays = "dobnyc_tnfsubmitteddateadvancedays";
    }


    public sealed class ElevatorSafetyDocumentListEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_elevatorsafetydocumentlist";
        public const string ELV3 = "dobnyc_esdl_elv3";
        public const string ELV29 = "dobnyc_esdl_elv29";

        public const string QASupervisorTask = "dobnyc_esdl_qasupervisortask";
        public const string QAReviewTask = "dobnyc_esdl_qareviewtask";

        public const string DocumentName = "dobnyc_name";
        public const string DocumentStatus = "dobnyc_esdl_documentstatus";
        public const string DocumentType = "dobnyc_esdl_documenttype";
        public const string DocumentumUploadDate = "dobnyc_esdl_documentumuploaddate";
        public const string DocumentSource = "dobnyc_esdl_documentsource";
        public const string DocumentUrl = "dobnyc_esdl_documenturl";
        public const string ParentDocumentList = "dobnyc_esdl_parentdocumentlist";
    }




    public sealed class ElevatorSafetyTaskAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_elevatorsafetytask";
        public const string RegardingObjectId = "regardingobjectid";
        public const string ReportStatus = "dobnyc_est_reportstatus";
        public const string QAclerkAction = "dobnyc_est_elv3qareviewaction";
        public const string QASupervisorDocumentListRelationship = "dobnyc_dobnyc_elevatorsafetytask_dobnyc_elevatorsafetydocumentlist_esdl_QASupervisorTask";
        public const string QAClerkDocumentListRelationship = "dobnyc_dobnyc_elevatorsafetytask_dobnyc_elevatorsafetydocumentlist_esdl_QAReviewTask";
    }


    //This class is used to store all the field names of AOC ELV29
    public sealed class ELV29AffirimationAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_elv29";
        public const string Name = "dobnyc_name";
        public const string DeviceIdLookup = "dobnyc_elv29_deviceid";
        public const string TrackingNumber = "dobnyc_trackingnumber";
        public const string BIN = "dobnyc_bin";
        public const string AmountPaid = "dobnyc_elv29_amountpaid";
        public const string AmountDue = "dobnyc_elv29_amountdue";
        public const string FilingFee = "dobnyc_elv29_filingfee";
        public const string Days60LateFilingFee = "dobnyc_elv29_60dayslatefilingfee";
        public const string Days120LateFilingFee = "dobnyc_elv29_120dayslatefilingfee";
        public const string PropertyProfileLookup = "dobnyc_elv29_propertyprofile";
        public const string Issubmitted = "dobnyc_elv29_issubmitted";
        public const string AOCInspectionDate = "dobnyc_dateofaocinspection";
        public const string DateOfInitialInspection = "dobnyc_dateofinitialinspection";
        public const string OwnerType = "dobnyc_ownertype";
        public const string Elv3Lookup = "dobnyc_elv29_elv3lookup";
        public const string FilingDate = "dobnyc_elv29_filingdate";
        public const string QASupervisorReviewDate = "dobnyc_elv3_qasupervisorreviewdate";
        public const string QAReviewDate = "dobnyc_elv29_qareviewdate";
        public const string QAFailedDate = "dobnyc_elv29_qafaileddate";
        public const string AccepetedDAte = "dobnyc_elv29_accepeteddate";
        public const string RevertedIncompleteSubmission = "dobnyc_elv29_revertedtoincompletesubmission";
        public const string ELV29PaymentMethod= "dobnyc_elv29_paymentmethod";
        public const string ELV3NRFLookup = "dobnyc_elv29_elv3nrfparentlookup";
        public const string statecode = "statecode";
        public const string statusReason = "statuscode";
        public const string noGoodCheckFee = "dobnyc_elv29_nogoodcheckfee";
        public const string hasWorkflow = "dobnyc_elv29__hasworkflow";//used for portal to show workflow status 
        public const string violationDismissFlag = "dobnyc_elv29_isviolationdismissedflag";
        //public const string AccepetedDefectsDAte = "dobnyc_elv3_accepteddefectsdate";
        public const string FeesCalculationDate = "dobnyc_elv29_feescalculationdate";
        public const string IncompleteSubmissionDate = "dobnyc_elv29_incompletesubmissiondate";
        public const string UserFilingActions = "dobnyc_elv29_userfilingactions";
        public const string ResubmissionDate = "dobnyc_elv29_resubmissiondate";
        public const string TotalFees = "dobnyc_elv29_totalfees";
        public const string ReportStatus = "dobnyc_elv29_reportstatus";
        public const string sharedAmountDue = "sharedAmountDue"; //used to store amountdue in pre-operation such that if amount due>0 then create the payment history else do not create
        public const string sharedFilingFee = "sharedFilingFee";
        public const string sahredLateFilingFee = "sahredLateFilingFee";
        public const string sahredNoGoodCheckFee = "sahredNoGoodCheckFee";
        public const string sahredGreatestDate = "sahredGreatestDate"; //used to identify Failure to Correct and Late Filing Fee
        public const string sahredAOCFinalSubmissionDateWithPenalty = "sahredAOCFinalSubmissionDateWithPenalty"; //used to identify Failure to Correct and Late Filing Fee
        public const string PAInspectorAttestation = "dobnyc_painspectorlegalstatement";
        public const string PADirectorAttestation = "dobnyc_performagencylegalstatement";
        public const string PAOwnerrAttestation = "dobnyc_propertyownerlegalstatement";



    }


    public sealed class PaymentHistoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_paymenthistory";
        public const string PaymentHistTransHistRelationShipName = "dobnyc_dobnyc_paymenthistory_dobnyc_transactionh";
        public const string PaymentHistShadowHistRelationShipName = "dobnyc_dobnyc_paymenthistory_dobnyc_shadowpaymenthistory_sph_PaymentHistory";
        public const string PaymentHistoryId = "dobnyc_paymenthistoryid";
        public const string IsPosted = "dobnyc_isposted";
        public const string InvoiceNumber = "dobnyc_invoicenumber";
        public const string FeeType = "dobnyc_feetype";
        public const string TotalFees = "dobnyc_totalfee";
        public const string MerchantAmount = "dobnyc_merchantamount";
        public const string AcrafNumber = "dobnyc_acrafnumber";
        public const string LicenseType = "dobnyc_licensetype";
        public const string SourceChannel = "dobnyc_sourcechannel";
        public const string TR6 = "dobnyc_ph_tr6";
        public const string FISP1 = "dobnyc_ph_fisp1";
        public const string FISP2 = "dobnyc_ph_fisp2";
        public const string NoGoodCheckFlag = "dobnyc_nogoodcheckflag";
        public const string NoGoodCheckTHFlag = "dobnyc_ph_nogoodcheckthflag";
        public const string ECheckRoutingNumber = "dobnyc_echeckroutingnumber";
        public const string Elevator = "dobnyc_elevator";
        public const string ElevatorPermit = "dobnyc_elevatorpermit";
        public const string Name = "dobnyc_jobnumber";
        public const string Amountpaid = "dobnyc_amountpaid";
        public const string ELV3Lookup = "dobnyc_elevatorsafetyelv3lookup";
    }


    //This class is used to store all field names of Test Notification ELV36
    public sealed class ELV36TestNotificationAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_elv36";
        public const string Name = "dobnyc_name";
        public const string DeviceIdLookup = "dobnyc_elv36_deviceid";
        public const string TrackingNumber = "dobnyc_elv36_trackingnumber";
        public const string SubmittedDate = "dobnyc_elv36_submitteddate";//"dobnyc_elv36_submitteddate";
        public const string ReportStatus = "dobnyc_reportstatus";
        public const string InspectionType = "dobnyc_elv36_inspectiontype";
        public const string InspectionDate = "dobnyc_elv36_inspectiondate";
        //public const string Issubmitted = "dobnyc_elv3_issubmitted";
        //public const string InspectionDate = "dobnyc_inspectiontestdate";

    }

    public sealed class ELV3Defect
    {
        public const string EntityLogicalName = "dobnyc_elv3_defect";
        public const string Name = "dobnyc_name";
        public const string ELV3Lookup = "dobnyc_elv3idid";
        public const string ELV29Lookup = "dobnyc_elv29id";
        //   public const string TrackingNumber = "dobnyc_elv36_trackingnumber";



    }

    public sealed class GroupNumber
    {
        public const string EntityLogicalName = "dobnyc_groupnumber";
        public const string Name = "dobnyc_groupnumber";
        public const string safetyFormFor = "dobnyc_grp_elevatorsafetyformfor";
        public const string Borough = "dobnyc_grp_borough";


    }




    public sealed class ElevatorMovingTypeAttributeNames
    {

        public const string TempTarckingNumber = "dobnyc_mv_devicetemptrackingnumber";
        public const string EntityLogicalName = "dobnyc_elv1elevator";
        public const string Name = "dobnyc_name";
        public const string DeviceType = "dobnyc_mv_elevatordevicetype";
        public const string ELV1Filling = "dobnyc_elv_regardingapplication";
        public const string DeviceStatus = "dobnyc_elv_devicestatus";
        public const string DevicePhysicalAddress = "dobnyc_mv_devicephysicaladdress";
        public const string PlungerTypes = "dobnyc_elv_plungertypes";
        public const string GEElevatorPassengerType = "dobnyc_mv_elevatorpassengertype";
        public const string Elv1elevatorid = "dobnyc_elv1elevatorid";
        public const string ElevatorSubDeviceType = "dobnyc_mv_elevatortype";
        public const string AccessbilitySubDeviceType = "dobnyc_mv_accessibilitylift";
        public const string AccessbilityStairwaySubDeviceType = "dobnyc_mv_stairwaychairlifttype";
        public const string AccessbilityPlatformSubDeviceType = "dobnyc_mv_platformlifttype";
        public const string MachineType = "dobnyc_machinetype";
        public const string jackSubType = "dobnyc_mv_jackhydraulictype";
    }


    //This class is used to store all field names of Elevator Master Device
    public sealed class ElevatorMasterDevice
    {
        public const string HouseNo = "dobnyc_housenumber";
        public const string EntityLogicalName = "dobnyc_elevatordevice";
        public const string EntityId = "dobnyc_elevatordeviceid";
        public const string StreetName = "dobnyc_streetname";
        public const string Borough = "dobnyc_borough";
        public const string Lot = "dobnyc_mas_lot";
        public const string Block = "dobnyc_mas_block";
        public const string BIN = "dobnyc_mas_bin";
        public const string Zip = "dobnyc_mas_zipcode";
        public const string FloorFrom = "dobnyc_floorfrom";
        public const string FloorTo = "dobnyc_floorto";
        public const string BISTravelDistance = "dobnyc_bis_traveldistance";
        public const string BISCarEntrances = "dobnyc_bis_carentrances";
        public const string BISSpeed = "dobnyc_bis_speed";
        public const string Capacity = "dobnyc_capacity";
        public const string DeviceNo = "dobnyc_devicenumber";
        public const string DeviceType = "dobnyc_devicetype";
        public const string DeviceStatus = "dobnyc_bis_devicestatus";
        public const string IsCreatedFromNI = "dobnyc_elm_iscreatedfromnewinstallation";
        public const string IsCreatedFromAL = "dobnyc_elm_iscreatedfromalteration";
        public const string DevicePhysicalAddress = "dobnyc_mas_devicephysicaladdress";
        public const string LatestMovingDevice = "dobnyc_latestmovingdeviceversion";
        public const string LatestRollingDevice = "dobnyc_latestrollingdeviceversion";
        public const string LatestApplication = "dobnyc_latestapplication";
        public const string RollingDeviceRelationship = "dobnyc_elevatordevice__elv1escalator_MasterChild";
        public const string MovingDeviceRelationship = "dobnyc_elevatordevice_elv1elevator_MasterChild";
        public const string ApplicationRelationship = "dobnyc_dobnyc_elevatordevice_dobnyc_elevatorappl";
        public const string BISHoistRopesQuantity = "dobnyc_bis_hoistropesquanity";
        public const string BISHoistRopesSize = "dobnyc_bis_hoistropessize";
        public const string BISHoistRopesKind = "dobnyc_bis_hoistropeskind";
        public const string BISCarCounterweightRopesQuantity = "dobnyc_bis_carcounterweightropesquantity";
        public const string BISCarCounterweightRopesSize = "dobnyc_bis_carcounterweightropessize";
        public const string BISCarCounterweightRopesKind = "dobnyc_bis_carcounterweightropeskind";
        public const string BISMachineCounterweightRopesQuantity = "dobnyc_bis_machinecounterweightropesquantity";
        public const string BISMachineCounterweightRopesSize = "dobnyc_bis_machinecounterweightropessize";
        public const string BISMachineCounterweightRopesKind = "dobnyc_bis_machinecounterweightropeskind";
        public const string BISBackdrumRopesQuantity = "dobnyc_bis_backdrumropesquantity";
        public const string BISBackdrumRopesSize = "dobnyc_bis_backdrumropessize";
        public const string BISBackdrumRopesKind = "dobnyc_bis_backdrumropeskind";
        public const string BISGovernorRopesQuantity = "dobnyc_bis_governorropesquantity";
        public const string BISGovernorRopesSize = "dobnyc_bis_governorropessize";
        public const string BISGovernorRopesKind = "dobnyc_bis_governorropeskind";
        public const string BISManufacturer = "dobnyc_bis_manufacturer";
        public const string BISAlterationDate = "dobnyc_bis_alterationdate";

        public const string BISGovernorType = "dobnyc_bis_governortype";
        public const string BISMachineType = "dobnyc_bis_machinetype";
        public const string BISCarBufferType = "dobnyc_bis_carbuffertype";
        public const string BISSafetyType = "dobnyc_bis_safetytype";
        public const string ISDeviceNumberChanged = "dobnyc_mas_isdevicenumberchangedalteration";
        public const string OldBISDeviceNumber = "dobnyc_mas_oldbisnycdeviceid";
        public const string InFlight = "dobnyc_inflight";
        public const string LatestPermitIssuedDate = "dobnyc_latestpermitissueddate";
        public const string IsThisDataMigrationRecord = "dobnyc_mas_isthisdatamigrationrecord";
        public const string IsThisDataMigrationDev = "dobnyc_mas_isthisdatamigrationdev";
        public const string IsCat1Eligible = "dobnyc_els_iscat1eligible";
        public const string IsCat5Eligible = "dobnyc_els_iscat5eligible";

        //add status date (on sign-off) & approval date (on new master device creation); 
        public const string StatusDate = "dobnyc_statusdate";
        public const string ApprovalDate = "dobnyc_approvaldate";
        public const string PH_TempRenewalExpiry = "dobnyc_els_personalhoisttemprenewalexpiry";
        public const string CAT1ReportYear = "dobnyc_els_cat1reportyear";
        public const string CAT1LatestReportFileDate = "dobnyc_els_cat1latestreportfileddate";
        public const string CAT3LatestReportFileDate = "dobnyc_els_cat3latestreportfileddate";
        public const string CAT5LatestReportFileDate = "dobnyc_els_cat5latestreport";
        public const string personalHoistTempRenewal = "dobnyc_els_personalhoisttemprenewalexpiry";
        public const string CAT5NextCycleEndDate = "dobnyc_els_cat5nextcycleenddate";
        public const string ceaseUseFlag = "dobnyc_elv_accelaceaseuseflag";
    }

    public sealed class ViolationNumberAttributeNmaes
    {
        public const string EntityLogicalName = "dobnyc_elevatorsafetyviolationnumber";
        public const string Name = "dobnyc_name";
        public const string ViolationStatus = "dobnyc_esvn_violationstatus";
        public const string InspectionType = "dobnyc_esvn_inspectiontype";
        public const string DeviceGuid = "dobnyc_esvn_deviceid";
        public const string reportYear = "dobnyc_esvn_reportyear";

    }
    public sealed class FeeCalculationConfigurationAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_feecalculationconfigur";
        public const string LegalizationFeeMul = "dobnyc_legalizationfeemultiplier";
        public const string LegalizationMinFee = "dobnyc_legalizationminfee";
        public const string PaaFee = "dobnyc_paafee";
        public const string PermitRenewalFee = "dobnyc_permitrenewalfee";
        public const string RecordManagementFee = "dobnyc_recordmanagementfees";
        public const string Tier1CostFee = "dobnyc_tieronecost";
        public const string Tier2CostFee = "dobnyc_tiertwocost";
        public const string CalculationName = "dobnyc_name";
        public const string MinFilingFee = "dobnyc_minimumfilingfee";
        public const string CheckBounce = "dobnyc_checkbouncefee";
        public const string Days13 = "dobnyc_daysonethree";
        public const string Days46 = "dobnyc_daysfoursix";
        public const string Days79 = "dobnyc_dayssevennine";
        public const string Days1012 = "dobnyc_daystentwelve";
        public const string Days1314 = "dobnyc_daysthirteenfourteen";
        public const string DailyFee = "dobnyc_dailyfee";
        public const string Id = "dobnyc_feecalculationconfigurid";
        //Used for querying the AHV formule from the FeeCalcConfiguration Entity 
        public const string AHVFormulaeName = "After Hour variance";
        public const string InConjunctionJobFee = "dobnyc_inconjunctionfee";

    }

    public sealed class TransactionCodeAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_transactioncode";
        public const string BudgetCode = "dobnyc_budgetcode";
        public const string ReportCategory = "dobnyc_reportcategory";
        public const string RevenueSource = "dobnyc_revenuesource";
        public const string SubSource = "dobnyc_subsource";
        public const string TransactionText = "dobnyc_name";
        public const string TransCode = "dobnyc_transcode";
        public const string TransType = "dobnyc_transtype";
        public const string Id = "dobnyc_transactioncodeid";
        public const string FeeSchemaName = "dobnyc_feeschemaname";
        public const string IsLegalizationFee = "dobnyc_islegalizationfee";
    }

    public sealed class FeeCalculationTransactionCodeIntersect
    {
        public const string EntityLogicalName = "dobnyc_feecalculationconfigur_transcode";

    }

    public sealed class TransactionHistoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_transactionhistory";
        public const string TransactionHistoryId = "dobnyc_transactionhistoryid";
        public const string BudgetCode = "dobnyc_budgetcode";
        public const string ReportCategory = "dobnyc_reportcategory";
        public const string RevenueSource = "dobnyc_revenuesource";
        public const string SubSource = "dobnyc_subsource";
        public const string TransactionText = "dobnyc_name";
        public const string TransCode = "dobnyc_transactioncode";
        //public const string TransCodeLookup = "dobnyc_th_transactioncode";
        public const string TransType = "dobnyc_transactiontype";
        public const string JobNumber = "dobnyc_jobnumber";
        public const string Fees = "dobnyc_fees";
        public const string Id = "dobnyc_transactionhistoryid";
        public const string JobfilingLookup = "dobnyc_jobfilinglookup";
        public const string TransactionCodeId = "dobnyc_th_transactioncode";
        public const string PaymentInvoice = "dobnyc_transactionid";
        public const string shadowPaymentHistoryLookup = "dobnyc_th_shadowpaymenthistory";

    }


    public sealed class EODAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_eodfile";
        public const string Name = "dobnyc_name";
        public const string FrontEndRecordId = "dobnyc_frontendrecordid";
        public const string EcheckReturnFlag = "dobnyc_echeckreturnflag";
    }



    //This Class is used to store all the field names of Shadow Payment History.
    public sealed class ShadowPaymentHistoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_shadowpaymenthistory";
        public const string ShadowPaymentHistoryId = "dobnyc_shadowpaymenthistoryid";
        public const string Name = "dobnyc_name";
        public const string SourceChannel = "dobnyc_sph_sourcechannel";
        public const string FeeType = "dobnyc_sph_feetype";
        public const string TotalFees = "dobnyc_sph_totalfee";
        public const string BO9 = "dobnyc_sph_bo9";
        public const string BO13 = "dobnyc_sph_bo13";
        public const string BO13E = "dobnyc_sph_bo13e";
        public const string Boiler = "dobnyc_sph_boiler";
        public const string BoilerCivilPenalties = "dobnyc_sph_boilercivilpenalty";
        public const string BNR = "dobnyc_sph_bnr";
        public const string NoGoodCheckFee = "dobnyc_sph_nogoodcheckfee";
        public const string IsPosted = "dobnyc_sph_isposted";
        public const string IsSubsequentFlag = "dobnyc_sph_boilernogoodcheckthflag";
        public const string BoilerNoGoodCheckFlag = "dobnyc_sph_boilernogoodcheckflag";
        public const string InvoiceNumber = "dobnyc_sph_paymenthistory";
        public const string IsDuplicate = "dobnyc_sph_isduplicate";
        public const string ELV3Lookup = "dobnyc_sph_elv3lookup";
        public const string ELV29Lookup = "dobnyc_sph_elv29lookup";
    }

    public sealed class SystemUserEntityAttributeNames
    {
        public const string SystemUserIdFieldName = "systemuserid";
        public const string EntityLogicalName = "systemuser";
        public const string FullNameFieldName = "fullname";
        public const string IsDisabledFieldName = "isdisabled";
        public const string EmployeeIdFieldName = "employeeid";
        public const string BusinessUnitFieldName = "businessunitid";
        public const string ParentUserIdFieldName = "parentsystemuserid";
        public const string FirstNameFieldName = "firstname";
        public const string LastNameFieldName = "lastname";
        public const string DomainNameFieldName = "domainname";
        public const string ModifiedOnFieldName = "modifiedon";
        public const string InternalEmail = "internalemailaddress";
        public const string PersonalEmail = "personalemailaddress";
        public const string MobileAlertEmail = "mobilealertemail";
        public const string Tel1 = "address1_telephone1";
        public const string Tel2 = "address1_telephone2";
        public const string HomePhone = "homephone";
        public const string MobilePhone = "mobilephone";
        public const string Fax = "address1_fax";
        public const string IsOutofOffice = "vrp_isoutofoffice";
        public const string DelegateUser = "vrp_delegateuserid";
        public const string Branch = "vrp_branchid";
    }
    public sealed class TeamMembershipEntityAttributeNames
    {
        public const string TeamId = "teamid";
        public const string SystemUserId = "systemuserid";
    }
    public sealed class TeamEntityAttributeNames
    {
        public static string EntityLogicalName = "team";
        public static string NameFieldName = "name";
        public static string TeamIdByFieldName = "teamid";
    }
    public sealed class ReportDefectEntityAttributeNames
    {
        public static string EntityLogicalName = "dobnyc_elv3_defect";
        public static string ReportDefectId = "dobnyc_elv3_defectid";
        public static string NameFieldName = "dobnyc_name";
        public static string ELV3 = "dobnyc_elv3idid";
        public static string ELV29 = "dobnyc_elv29id";
        public static string MasterDefectId = "dobnyc_elavatorsafetydefectid";
        public static string ElevatorPart= "dobnyc_elevatorpart";
        public static string ElevatorSubPart = "dobnyc_elevatorsubpart";
        public static string SuggestedRemedy = "dobnyc_suggestedremedy";
        public static string ViolationCondition = "dobnyc_violationcondition";
        public static string Comments = "dobnyc_comments";
    }

    public sealed class DefectEntityAttributeNames
    {
        public static string EntityLogicalName = "dobnyc_elevatorsafetydefects";
        public static string DefectId = "dobnyc_elevatorsafetydefectsid";
        public static string NameFieldName = "dobnyc_name";
        public static string ElevatorPart = "dobnyc_esd_elevatorpart";
        public static string ElevatorSubPart = "dobnyc_esd_elevatorsubpart";
        public static string SuggestedRemedy = "dobnyc_esd_suggestedremedy";
        public static string ViolationCondition = "dobnyc_esd_violationcondition";
        public static string Comments = "dobnyc_comments";
    }

}
