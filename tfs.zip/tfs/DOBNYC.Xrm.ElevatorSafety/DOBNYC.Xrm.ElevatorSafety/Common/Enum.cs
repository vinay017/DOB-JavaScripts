﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.Xrm.ElevatorSafety.Common
{
    public enum ICrmServiceCredentialType
    {
        ImpersonatedUser = 1,
        Admin = 2,
        SystemAccount = 3
    }


    public class ElevatorSafetyFeeCalculationobject
    {
        public decimal TotalFee = 0;

        public decimal ELV3FilingFee = 0;

        public decimal ELV3LateFilingFee = 0;

        public decimal ELV3NRFFee = 0;

        public decimal ELV29NRFFee = 0;

        public decimal ELV3NoGoodCheckFee = 0;

        public decimal AmountDue = 0;

        public decimal existingamountpaid = 0;

        public decimal ELV29FilingFee = 0;

        public decimal ELV29LateFilingFee = 0;

        public decimal ELV29NoGoodCheckFee = 0;

    }






    public enum PluginStage : int
    {
        PreValidation = 10,
        PreOperation = 20,
        MainOperation = 30,
        PostOperation = 40
    }
    public enum ELV3InspectionType : int
    {
        CAT1 = 1,
        CAT3 = 2,
        CAT5 = 3,
        HoistJumpUP = 4,
        HoistJumpDown = 5,
        NinetyDayTempRenewal = 6,
        PVTInspection = 7,
        QCInspection = 8


    }

    public enum ELV3ReportType : int
    {
        ElevatorTestInspection=1,
        PersonnelHoistTestInspection=2


    }

    public enum OwnerType : int
    {
        Private = 1,
        CityownedNonNYCHA = 2,
        NYCHA = 3,
        State = 4,
        Federal = 5,
        Diplomat = 6,
        NonprofitTaxExempt = 7
    }

    public sealed class ElevatorSafetyTransactionCodes
    {
        public const string CheckBounceFee = "203";
        public const string OVERAGE_PAYMENT = "212";

        public const string ElevatorSafetySample = "740"; //need to Change later

        // Actual Codes
        public const string ElevatorSafetyAOFLateFee = "812";
        public const string ElevatorSafetyAOFFailtoFile = "813";
        public const string ElevatorSafetyCAT3CAT5LateFee = "814";
        public const string ElevatorSafetyCAT3CAT5FailtoFile = "815";
        public const string ElevatorSafetyCAT1LateFilingFee = "816";
        public const string ElevatorSafetyCAT1FailtoFile = "823";
        public const string ElevatorSafetyELV3CAT1FilingFee = "750";
        public const string ElevatorSafetyELV3CAT3CAT5FilingFee = "751";
        public const string ElevatorSafetyAOCFilingFee = "752";
        public const string ElevatorSafetyPVTAOCFilingFee = "754";
        public const string ElevatorSafetyWaiverOfPenalties = "753";


        //Actual Codes
        //public const string ElevatorSafetyAOFLateFee = "740";
        //public const string ElevatorSafetyAOFFailtoFile = "740";
        //public const string ElevatorSafetyCAT3CAT5LateFee = "740";
        //public const string ElevatorSafetyCAT3CAT5FailtoFile = "740";
        //public const string ElevatorSafetyCAT1LateFilingFee = "740";
        //public const string ElevatorSafetyCAT1FailtoFile = "740";
        //public const string ElevatorSafetyELV3CAT1FilingFee = "740";
        //public const string ElevatorSafetyELV3CAT3CAT5FilingFee = "740";
        //public const string ElevatorSafetyAOCFilingFee = "740";
        //public const string ElevatorSafetyPVTAOCFilingFee = "740";
        //public const string ElevatorSafetyWaiverOfPenalties = "740";



    }

    public enum ELV3ReportStatus : int
    {
        Prefiling = 1,
        QASupervisorReview = 2,
        QAReview = 3,
        QAFailed = 4,
        Accepted = 5,
        Incomplete = 6,
        PrefilingPendingPayment = 7,
        AcceptedDefects = 9,
        RejectedFilingDue = 10,
        PaymentVerification = 11,
        NoGoodCheck = 12,
        NRF = 13,
        AcceptedCorrectionsViolationDismissed = 14,
        AcceptedCorrectionsViolationNotDismissed = 15,
        Received=16,
        CorrectionsAccepted=17,





    }


    public enum ElevatorMachineType : int
    {
        Traction = 2,
        Hydraulic = 11,
        RopedHydraulic = 6,
        

    }

    public enum ELV3RevertedFromIncompleteSubmission : int
    {

        QASupervisorReview = 1,
        QAReview = 2,
        None = 3,

    }

    public enum PaymentMethod : int
    {

        Check = 1,
        CreditCard = 2,


    }
    public enum ELV3UserFilingActions : int
    {

        Save = 1,
        CalculateCivilPenality = 2,
        File = 3,

    }

    public enum QAClerkActions : int
    {

        Accepted = 1,
        Rejected = 3,
        QAFailed = 4,
        CorrectionsAcceptedViolationsDismissed=5,
        CorrectionsNotAcceptedViolationsNotDismissed=6
    }

    public enum ViolationStatus : int
    {

        Active = 1,
        Dismissed = 2,
        
    }





    public enum Boroughs : int
    {
        MANHATTAN = 1,
        BRONX = 2,
        BROOKLYN = 3,
        QUEENS = 4,
        STATENISLAND = 5,
       
    }

    public enum ElevatorDeviceStatus : int
    {
        Active = 1,
        Dismantled = 2,
        Removed = 3,
        Deleted = 4,
        Sealed = 5,
        NoJurisdiction = 6,
        HousingAuthority = 7,
        WorkinProgress = 8,
        Withdrawn = 9,
    }
    public enum ElevatorDeviceTypes : int
    {
        Elevator = 1,
        Escalator = 2,
        MovingWalk = 3,
        PersonnelHoist = 4,
        Dumbwaiter = 5,
        AccessibilityLift = 6,
        Conveyor = 7,
        // Sidewalk = 8,
        Manlift = 8,
        Others = 9,
    }

    public enum ElevatorAccessibilityLiftType : int
    {
        PlatformLift = 1,
        StairwayChairlift = 2
    }
    public enum PaymentHistoryFeeType : int
    {
        NoGoodCheck = 4,
        TR6 = 8,
        FISP1 = 9,
        FISP2 = 10,
        BO9FilingFee = 18,
        BO13FilingFee = 19,
        BO13EFilingFee = 20,
        LateFilingFee = 22,
        FailuretoFileFee = 23,
        LateFilingFee180 = 24,
        BCPtotallatefilingfee_Internal = 25,
        BCPtotallatefilingfee180_Internal = 26,
        BCPtotallatefilingfee_External = 27,
        BCPtotallatefilingfee180_External = 28,
        BCPtotallatefilingfee = 29,
        BCPtotallatefilingfee180 = 30,
        BNRFilingFee = 31,
        ElevatorsSafetyElv3FilingFee = 38,
        ElevatorsSafetyElv3LateFilingFee = 40,
        ElevatorsSafetyElv29 = 39


    }
}
