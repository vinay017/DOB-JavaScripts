﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.Xrm.ElevatorSafety.Common
{
    public class PluginSystemExceptionMessages
    {

    }
    public class PluginMessages
    {
        public const string WebServiceCallParameterInfo = "Web service call parameter info : ";
        public const string WebServiceCouldNotBeAccessed = "Web service could not be accessed.";
        public const string ThisIsIOrganizationService = "This web service is a IOrganizationService.";
        public const string CreateWebServiceCallParametersError = "An error occurred while creating web service call parameters.";
    }
}
