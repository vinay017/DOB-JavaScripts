﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.Xrm.ElevatorSafety.Common
{
    public struct PluginHelperStrings
    {
        public static string PreImageName = "PreImage";
        public static string PostImageName = "PostImage";
        public static string PrePostImageName = "TargetImage";
        public const string CreateMessageName = "Create";
        public const string UpdateMessageName = "Update";
        public const string DeleteMessageName = "Delete";


    }

    public struct FeeConfigs
    {
        
        
        //all the configurations for fees
        public static string noGoodCheckConfigFee = "Elevator Safety No Good Check Fee";

        public static string cat1FilingFee = "Elevator Safety CAT1 Filing Fee";

        public static string cat3Cat5FilingFee = "Elevator Safety CAT3 CAT5 Filing Fee";

        public static string cat1AOCFilingFee = "Elevator Safety CAT1 AOC Filing Fee",
                                pvtAOCFilingFee = "Elevator Safety PVT AOC Filing Fee",
                                qcAOCFilingFee = "Elevator Safety QC AOC Filing Fee";

        public static string elv3NoJurisdictionCAT1CAT3CAT5MonthPenalty = "Elevator Safety ELV3 NoJurisdiction CAT1 CAT3 CAT5 Month Penalty",
                                elv3NoJurisdictionCAT1CAT3CAT5YearPenalty = "Elevator Safety ELV3 NoJurisdiction CAT1 CAT3 CAT5 Year Penalty",
                                elv3NoJuridictionCAT1MaxPenalty = "Elevator Safety ELV3 NoJuridiction CAT1 Max Penalty",
                                elv3ActiveSealedCAT1MonthPenalty = "Elevator Safety ELV3 Active Sealed CAT1 Month Penalty",
                                elv3ActiveSealedCAT1YearPenalty = "Elevator Safety ELV3 Active Sealed CAT1 Year Penalty",
                                elv3ActiveSealedCAT1MaxPenalty = "Elevator Safety ELV3 Active Sealed CAT1 Max Penalty",
                                elv3ActiveSealedCAT3CAT5MonthPenalty = "Elevator Safety  ELV3 Active Sealed CAT3 CAT5 Month Penalty",
                                elv3ActiveSealedCAT3CAT5YearPenalty = "Elevator Safety  ELV3 Active Sealed CAT3 CAT5 Year Penalty",
                              
                                elv29NoJurisdictionCAT1AOCMonthPenalty = "Elevator Safety  ELV29 NoJurisdiction CAT1 AOC Month Penalty",
                                elv29NoJurisdictionCAT1AOC18MonthsPenalty = "Elevator Safety  ELV29 NoJurisdiction CAT1 AOC 18Months Penalty",
                                elv29ActiveSealedCAT1AOCMonthPenalty = "Elevator Safety  ELV29 Active Sealed CAT1 AOC Month Penalty",
                                elv29ActiveSealedCAT1AOC18MonthsPenalty = "Elevator Safety  ELV29 Active Sealed CAT1 AOC 18Months Penalty",
                                elv29ActiveSealedCAT1AOCMaxYearPenalty = "Elevator Safety  ELV29 Active Sealed CAT1 AOC Max Penalty",
                                elv29NoJurisdictionCAT1AOCMaxYearPenalty= "Elevator Safety  ELV29 NoJurisdiction CAT1 AOC Max Penalty";
    }

    public static class ParameterName
    {
        public const string Assignee = "Assignee";
        public const string AsyncOperationId = "AsyncOperationId";
        public const string BusinessEntity = "BusinessEntity";
        public const string BusinessEntityCollection = "BusinessEntityCollection";
        public const string CampaignActivityId = "CampaignActivityId";
        public const string CampaignId = "CampaignId";
        public const string ColumnSet = "columnset";
        public const string Context = "context";
        public const string ContractId = "ContractId";
        public const string CreatedBy = "createdby";
        public const string EmailId = "emailid";
        public const string EndpointId = "EndpointId";
        public const string EntityId = "EntityId";
        public const string EntityMoniker = "EntityMoniker";
        public const string ExchangeRate = "ExchangeRate";
        public const string FaxId = "FaxId";
        public const string Id = "id";
        public const string ListId = "ListId";
        public const string OptionalParameters = "OptionalParameters";
        public const string OwnerId = "ownerid";
        public const string PostBusinessEntity = "PostBusinessEntity";
        public const string PostMasterBusinessEntity = "PostMasterBusinessEntity";
        public const string PreBusinessEntity = "PreBusinessEntity";
        public const string PreMasterBusinessEntity = "PreMasterBusinessEntity";
        public const string PreSubordinateBusinessEntity = "PreSubordinateBusinessEntity";
        public const string Query = "Query";
        public const string ReturnDynamicEntities = "ReturnDynamicEntities";
        public const string RouteType = "RouteType";
        public const string Settings = "Settings";
        public const string State = "State";
        public const string Status = "Status";
        public const string SubordinateId = "subordinateid";
        public const string Target = "Target";
        public const string TeamId = "TeamId";
        public const string TemplateId = "TemplateId";
        public const string TriggerAttribute = "TriggerAttribute";
        public const string UpdateContent = "UpdateContent";
        public const string ValidationResult = "ValidationResult";
        public const string Value = "value";
        public const string WorkflowId = "WorkflowId";
        public const string RegardingObjectId = "RegardingObjectId";
    }
    public struct PluginNames
    {
        public const string ELV3FeeCalculationPlugin = "ELV3FeeCalculationPlugin";
        public const string ElevatorSafetyTrackingNumberPlugin= "ElevatorSafetyTrackingNumberPlugin";
        public const string ELV29FeeCalculationPlugin = "ELV29FeeCalculationPlugin";
        public const string IsSubmitPlugin= "IsSubmitPlugin";
        public const string WorkflowPlugin= "WorkflowPlugin";
        public const string ELV3TaskCreationPlugin = "ELV3TaskCreationPlugin";
        public const string NoGoodCheckPlugin = "NoGoodCheckPlugin";
        public const string ElevatorSafetyEligibleDevices= "ElevatorSafetyEligibleDevices";
        public const string TaskCompletionPlugin = "TaskCompletionPlugin";
        public const string DismissalViolationPlugin = "DismissalViolationPlugin";
    }
}
