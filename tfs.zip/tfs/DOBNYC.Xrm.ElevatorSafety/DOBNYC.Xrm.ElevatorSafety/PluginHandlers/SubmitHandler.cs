﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class SubmitHandler : PluginHandlerBase
    {
        /// <summary>
        ///Change the report status of elevator application based on User Filing Actions (Initial submission or Re-submission)
        ///Also set the accepted and accepted defect date for private owner type filings
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="lateFilingFee">Late filing fee will be used to set report status as civil penalty status due</param>
        /// <returns></returns>
        public static Entity ELV3Submit(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, decimal lateFilingFee)
        {
            try
            {
                string[] Column_hv = new string[] { ELV3InspectionAttributeNames.ReportStatus, ELV3InspectionAttributeNames.RevertedIncompleteSubmission, ELV3InspectionAttributeNames.OwnerType };
                int currentRequestStatus = targetEntity.Contains(ELV3InspectionAttributeNames.ReportStatus) ? targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value : preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value;

                crmTrace.AppendLine("currentRequestStatus Completed: " + currentRequestStatus.ToString());
                int revertIncompleteSubmission = (preImage.Contains(ELV3InspectionAttributeNames.RevertedIncompleteSubmission) && preImage[ELV3InspectionAttributeNames.RevertedIncompleteSubmission] != null && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.RevertedIncompleteSubmission).Value > 0) ? preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.RevertedIncompleteSubmission).Value : (int)ELV3RevertedFromIncompleteSubmission.None;
                crmTrace.AppendLine("revertIncompleteSubmission" + revertIncompleteSubmission.ToString());
                crmTrace.AppendLine("currentRequestStatus: " + currentRequestStatus.ToString());

                if (preImage.Contains(ELV3InspectionAttributeNames.InspectionType) && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value > 0)
                {
                    switch (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value)
                    {
                        case (int)ELV3InspectionType.CAT1:
                        case (int)ELV3InspectionType.CAT3:
                        case (int)ELV3InspectionType.CAT5:
                        case (int)ELV3InspectionType.HoistJumpDown:
                        case (int)ELV3InspectionType.HoistJumpUP:
                        case (int)ELV3InspectionType.NinetyDayTempRenewal:
                        case (int)ELV3InspectionType.PVTInspection:
                        case (int)ELV3InspectionType.QCInspection:
                            {
                                #region Normal filing Status- Only Accepted or civil penality
                                if ((preImage.Contains(ELV3InspectionAttributeNames.OwnerType) && preImage[ELV3InspectionAttributeNames.OwnerType] != null && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private) //if owner type is private
                                    || (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.PVTInspection) //if inspection type is PVT or QC Inspections
                                    || (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.QCInspection)
                                    || (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportType).Value == (int)ELV3ReportType.PersonnelHoistTestInspection))
                                {

                                    #region Check Payment Method --Check

                                    if (targetEntity.Contains(ELV3InspectionAttributeNames.ELV3PaymentMethod) && targetEntity[ELV3InspectionAttributeNames.ELV3PaymentMethod] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ELV3PaymentMethod).Value == (int)PaymentMethod.Check)//use target entity because once ELV3 status in Payment verification package will update again user filing actions to file with out payment method  then normal workflow will trigger
                                    {
                                        crmTrace.AppendLine("Payment Done by Check so set the status to payment verification");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PaymentVerification));
                                        crmTrace.AppendLine("set the FilingDate : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.FilingDate, DateTime.Today);
                                    }

                                    #endregion


                                    #region Other than Check Pament and null payment Method
                                    else
                                    {
                                        #region Personal Hoist Inspections

                                        if((preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportType).Value == (int)ELV3ReportType.PersonnelHoistTestInspection))
                                        {
                                            crmTrace.AppendLine("Defects Exist flag is False Set currentRequestStatus as Received : ");
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.Received));
                                            crmTrace.AppendLine("set the AccepetedDAte : ");
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.AccepetedDAte, DateTime.Today);
                                            crmTrace.AppendLine("set the FilingDate : ");
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.FilingDate, DateTime.Today);
                                        }
                                        #endregion

                                        #region Elevator test Isnpections
                                        else
                                        {
                                            crmTrace.AppendLine("Check Defects Flag true or false : ");
                                            //Check if elv3 has defects or not
                                            if (preImage.Contains(ELV3InspectionAttributeNames.IsDefectsExist) && preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.IsDefectsExist))
                                            {
                                                crmTrace.AppendLine("Defects Exist flag is true Set currentRequestStatus as Accepted Defects: ");
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.AcceptedDefects));
                                                crmTrace.AppendLine("set the AccepetedDefectsDAte : ");
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.AccepetedDefectsDAte, DateTime.Today);
                                               
                                            }
                                            else
                                            {
                                                crmTrace.AppendLine("Defects Exist flag is False Set currentRequestStatus as Accepted : ");
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.Accepted));
                                                crmTrace.AppendLine("set the AccepetedDAte : ");
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.AccepetedDAte, DateTime.Today);
                                                #region Dismissal PVT QC Violation
                                               crmTrace.AppendLine("Dismiss all existing PVT QC Violations on that device: ");
                                                ViolationNumberHandler.GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag(service, preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, crmTrace);
                                                #endregion
                                            }


                                            #region 15245 bug fix
                                            if (!(targetEntity.Contains(ELV3InspectionAttributeNames.ELV3PaymentMethod) && targetEntity[ELV3InspectionAttributeNames.ELV3PaymentMethod] != null) && //payment method is null
                                                   (preImage.Contains(ELV3InspectionAttributeNames.FilingDate) && preImage[ELV3InspectionAttributeNames.FilingDate] != null))//preimage already has filing date
                                            {
                                                //do not update the filing date because this we are clearing the check amount
                                            }
                                            else
                                            {
                                                crmTrace.AppendLine("set the FilingDate : ");
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.FilingDate, DateTime.Today);

                                            }

                                            #endregion

                                            #region Dismiss NRF Violation
                                            crmTrace.AppendLine("Dismiss all existing NRF Violations on that device: ");
                                            //CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.dismissViolationsFlag, true);
                                            ViolationNumberHandler.GetAllNRFViolationsForDevice(service, preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value,preImage,crmTrace);

                                            #endregion
                                        }
                                        #endregion



                                        #region set NRF Parent ELv3 Lookup

                                        ///this region will be set the NRF Filings's ELV3 lookup to current ELV3 filing because user paid all the late penalty and NRF fees 
                                        ///deactivate all those NRF Filings after successful payment
                                        ///
                                        //SubmitHandler.getActiveELV3NRFReports(preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, preImage, service, crmTrace, true);
                                        //SubmitHandler.getActiveELV29NRFReports(preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, preImage, service, crmTrace,true);

                                        #endregion

                                    }
                                    #endregion





                                }
                                #endregion
                                #region Fee exempt Filings
                                else//for all fee exempt Filings
                                {


                                    targetEntity = ELV3ManualWorkflow(service, targetEntity, preImage, revertIncompleteSubmission, crmTrace);


                                }
                                #endregion
                                break;
                            }




                    }
                }

                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ElevatorSafetySubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }


        /// <summary>
        ///Change the report status of ELv29 application based on User Filing Actions (Initial submission or Re-submission)
        ///Also set the accepted and accepted defect date for private owner type filings
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="lateFilingFee">Late filing fee will be used to set report status as civil penalty status due</param>
        /// <param name="inspectionType">Based on Inspection type </param>
        /// <returns></returns>
        public static Entity ELV29Submit(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, decimal lateFilingFee, int inspectionType)
        {
            try
            {
                string[] Column_hv = new string[] { ELV29AffirimationAttributeNames.ReportStatus, ELV29AffirimationAttributeNames.RevertedIncompleteSubmission, ELV29AffirimationAttributeNames.OwnerType };
                int currentRequestStatus = targetEntity.Contains(ELV29AffirimationAttributeNames.ReportStatus) ? targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value : preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value;

                crmTrace.AppendLine("currentRequestStatus Completed: " + currentRequestStatus.ToString());
                int revertIncompleteSubmission = (preImage.Contains(ELV29AffirimationAttributeNames.RevertedIncompleteSubmission) && preImage[ELV29AffirimationAttributeNames.RevertedIncompleteSubmission] != null && preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.RevertedIncompleteSubmission).Value > 0) ? preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.RevertedIncompleteSubmission).Value : (int)ELV3RevertedFromIncompleteSubmission.None;
                crmTrace.AppendLine("revertIncompleteSubmission" + revertIncompleteSubmission.ToString());
                crmTrace.AppendLine("currentRequestStatus: " + currentRequestStatus.ToString());
                Guid DeviceId = new Guid();
                EntityCollection CAT1Collection = new EntityCollection();
                EntityCollection AOCCollection = new EntityCollection();
                DateTime CAT1LatestAcceptedInspectionDate = new DateTime(), AOCLatestAcceptedInspectionDate = new DateTime();
                int deviceStatus = ELV3FeeCalculationHandler.GetAOCDeviceStatus(preImage, service);//used in PVT/QC AOC
                bool isCeaseUseActive = false;//used to check the current ceaseuse status on master device
                if (inspectionType > 0)
                {
                    #region Check Payment Method --Check

                    if (targetEntity.Contains(ELV29AffirimationAttributeNames.ELV29PaymentMethod) && targetEntity[ELV29AffirimationAttributeNames.ELV29PaymentMethod] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ELV29PaymentMethod).Value == (int)PaymentMethod.Check)//use target entity because once ELV3 status in Payment verification package will update again user filing actions to file with out payment method  then normal workflow will trigger
                    {
                        crmTrace.AppendLine("Payment Done by Check so set the status to payment verification");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PaymentVerification));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.FilingDate, DateTime.Today);
                    }

                    #endregion

                    #region Payment Method --Other than Check or null
                    else
                    {
                        switch (inspectionType)
                        {
                            case (int)ELV3InspectionType.CAT1:
                                {
                                    //For CAT1 Workflow is based on owner type for private it is accepted ,other than private it is manual workflow
                                    #region Normal filing Status- Only Accepted or civil penality
                                    if (preImage.Contains(ELV29AffirimationAttributeNames.OwnerType) && preImage[ELV29AffirimationAttributeNames.OwnerType] != null && preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                                    {

                                        crmTrace.AppendLine("Defects Exist flag is False Set currentRequestStatus as Accepted : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.CorrectionsAccepted));
                                        crmTrace.AppendLine("set the AccepetedDAte : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.AccepetedDAte, DateTime.Today);

                                        #region 15245 bug fix
                                        if (!(targetEntity.Contains(ELV29AffirimationAttributeNames.ELV29PaymentMethod) && targetEntity[ELV29AffirimationAttributeNames.ELV29PaymentMethod] != null) && //payment method is null
                                               (preImage.Contains(ELV29AffirimationAttributeNames.FilingDate) && preImage[ELV29AffirimationAttributeNames.FilingDate] != null))//preimage already has filing date
                                        {
                                            //do not update the filing date because this we are clearing the check amount
                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("Setting  filing Date as : ");
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.FilingDate, DateTime.Today);

                                        }

                                        #endregion


                                        crmTrace.AppendLine("Setting  Has Workflow : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.hasWorkflow, false);

                                    }
                                    #endregion
                                    #region Fee exempt Filings
                                    else//for all fee exempt Filings
                                    {


                                        targetEntity = ELV29ManualWorkflow(service, targetEntity, revertIncompleteSubmission, crmTrace);

                                        crmTrace.AppendLine("Setting  Has Workflow : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.hasWorkflow, true);
                                    }
                                    #endregion
                                    break;
                                }
                            case (int)ELV3InspectionType.PVTInspection:
                            case (int)ELV3InspectionType.QCInspection:
                                {
                                    ///For PVT,QC Inspection workflow is based on CAT1,Normal AOC inspection date. if CAT1,AOC inspection date is after PVT initial inspection date then there is no workflow else we should have work flow
                                    ///eg1: PVT ELV3 Violation:1,JAN,2018 CAT1 satisfactory or AOC Accepted: 10,JAN,2018. then we should not trigger workflow. directly accept the PVT AOC
                                    ///eg2: PVT ELV3 Violation:10 JAN,2018 CAT1 staisfactory or AOC Accepted: 1 Jan,2018 then we should trigger Manual workflow.
                                    ///eg3: PVT ELV3 Violation:1,JAN,2018 CAT1 Unsatisfactory : 10,JAN,2018. then we should  trigger workflow since CAT1 is unsatisfactory.
                                    ///eg4: PVT ELV3 Violation1:1,JAN,2018,  PVT ELV3 Violation2:3,JAN,2018,. we receive PVT AOC on 10th jan,2018 for Violation1. we have to trigger manual workflow for PVT AOC violation1.
                                    ///     user files PVT AOC on 12,JAN,2018 for violation 2 for this directly we will accept without workflow because we already accepted prev violation
                                    /// eg5:PVT ELV3 Violation1:1,JAN,2018,  PVT ELV3 Violation2:15,JAN,2018,. we receive PVT AOC on 10th jan,2018 for Violation1. we have to trigger manual workflow for PVT AOC violation1.
                                    ///     user files PVT AOC on 20,JAN,2018 for violation 2 we also trigger manual workflow beacuse violation 2  date is greater than PVT AOC Violation1 Date  
                                    ///     If the latestapplication of that device is removal if it is passfinal then we have to dismiss violation Automatically

                                    ///when Aoc is filed 
                                    ///Query Latest CAT1 Satisfactory repot for that device and check the inspection date
                                    ///Query Latest CAT1 AOC Accepted repot for that device and check the inspection date exclude PVT ACOC in results
                                    ///if any one of above inspection dates is greater than PVT File Date  or check the latest device status if the device status is removed then directly change the status to Accepted
                                    ///esle trigger the workflow
                                    ///

                                    DeviceId = preImage.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.DeviceIdLookup).Id;
                                    crmTrace.AppendLine("DeviceId: " + DeviceId);
                                    CAT1Collection = getCAT1AcceptedReports(DeviceId, service);
                                    crmTrace.AppendLine(" CAT1Collection" + CAT1Collection.Entities.Count);
                                    AOCCollection = getELV29AcceptedReports(DeviceId, service);
                                    crmTrace.AppendLine(" AOCCollection" + AOCCollection.Entities.Count);
                                    isCeaseUseActive = getMasterDeviceCeaseUseStatus(DeviceId, service);
                                    crmTrace.AppendLine(" isCeaseUseActive" + isCeaseUseActive.ToString());
                                    //get the latest Device Status 


                                    if (CAT1Collection != null && CAT1Collection.Entities.Count > 0 && CAT1Collection.Entities[0].Id != null)
                                    {
                                        CAT1LatestAcceptedInspectionDate = CAT1Collection.Entities[0].GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate);
                                        crmTrace.AppendLine(" CAT1LatestAcceptedInspectionDate :" + CAT1LatestAcceptedInspectionDate);
                                    }

                                    if (AOCCollection != null && AOCCollection.Entities.Count > 0 && AOCCollection.Entities[0].Id != null)
                                    {
                                        AOCLatestAcceptedInspectionDate = AOCCollection.Entities[0].GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.AOCInspectionDate);
                                        crmTrace.AppendLine(" AOCLatestAcceptedInspectionDate :" + AOCLatestAcceptedInspectionDate);
                                    }

                                    //Get the Violation date from ELv3 Lookup

                                    Entity Elv3 = service.Retrieve(ELV3InspectionAttributeNames.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id, new ColumnSet(new string[] { ELV3InspectionAttributeNames.violationDate,ELV3InspectionAttributeNames.SubmissionDate }));

                                    DateTime violationDate = (Elv3.Contains(ELV3InspectionAttributeNames.violationDate) && Elv3[ELV3InspectionAttributeNames.violationDate] != null) ? Elv3.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.violationDate) : preImage.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.DateOfInitialInspection);//if violation date is null then get the date of initial Inspection

                                    #region Main Logic 
                                    if (
                                        (
                                        (CAT1LatestAcceptedInspectionDate > violationDate) || //check Latest CAT1 Satisfactory repot inspection report
                                        (AOCLatestAcceptedInspectionDate > violationDate) ||//check Latest CAT1 AOC Accepted repot Inspection date
                                        (deviceStatus == (int)ElevatorDeviceStatus.Removed)//Device is in removed state
                                        ) &&
                                        !isCeaseUseActive &&//there should be no cease use active during submission if cease use is active then it should goes for manual workflow
                                        (preImage.Contains(ELV29AffirimationAttributeNames.OwnerType) && preImage[ELV29AffirimationAttributeNames.OwnerType] != null && preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private)//Automatic Dismissal Only for Private feeexempt always manual workflow.
                                        )
                                    {
                                        crmTrace.AppendLine(" CAT1LatestAcceptedInspectionDate,AOCLatestAcceptedInspectionDate greater than Violatiuon initial Inspection so directly accepted :");
                                        crmTrace.AppendLine(" Set currentRequestStatus as Accepted : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.AcceptedCorrectionsViolationDismissed));
                                        crmTrace.AppendLine("set the AccepetedDAte : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.AccepetedDAte, DateTime.Today);
                                        
                                        #region 15245 bug fix
                                        if (!(targetEntity.Contains(ELV29AffirimationAttributeNames.ELV29PaymentMethod) && targetEntity[ELV29AffirimationAttributeNames.ELV29PaymentMethod] != null) && //payment method is null
                                               (preImage.Contains(ELV29AffirimationAttributeNames.FilingDate) && preImage[ELV29AffirimationAttributeNames.FilingDate] != null))//preimage already has filing date
                                        {
                                            //do not update the filing date because this we are clearing the check amount
                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("Setting  filing Date as : ");
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.FilingDate, DateTime.Today);

                                        }

                                        #endregion

                                        crmTrace.AppendLine("Setting  Has Workflow : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.hasWorkflow, false);
                                        #region Dismissal Violation
                                        crmTrace.AppendLine("Update the Dismissal flag to true for dismissing violation: ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.violationDismissFlag, true);
                                        #endregion
                                    }
                                    else
                                    {
                                        targetEntity = ELV29ManualWorkflow(service, targetEntity, revertIncompleteSubmission, crmTrace);
                                        crmTrace.AppendLine("Setting  Has Workflow : ");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.hasWorkflow, true);
                                    }
                                    #endregion
                                    break;
                                }
                           
                        }
                    }
                    #endregion



                }








                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM Testing Purpose", "SubmitHandler - ELV29Submit", null, crmTrace.ToString(), null, null);

                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29Submit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }


        /// <summary>
        /// This Function Will return the CAT1 Accepted reports in desc order of initial inspection when device Id is passed
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static EntityCollection getCAT1AcceptedReports(Guid DeviceId, IOrganizationService service)
        {
            ConditionExpression condition1 = new ConditionExpression(ELV3InspectionAttributeNames.DeviceIdLookup, ConditionOperator.Equal, DeviceId);
            ConditionExpression condition2 = new ConditionExpression(ELV3InspectionAttributeNames.ReportStatus, ConditionOperator.Equal, (int)ELV3ReportStatus.Accepted);
            ConditionExpression condition3 = new ConditionExpression(ELV3InspectionAttributeNames.InspectionType, ConditionOperator.Equal, (int)ELV3InspectionType.CAT1);
            //  OrderExpression order1 = new OrderExpression(ELV3InspectionAttributeNames.InspectionDate, OrderType.Descending);
            QueryExpression query = new QueryExpression(ELV3InspectionAttributeNames.EntityLogicalName);
            query.ColumnSet = new ColumnSet(new string[] { ELV3InspectionAttributeNames.InspectionDate });
            query.Criteria = new FilterExpression(LogicalOperator.And)
            {
                Conditions =
                            {
                                condition1,
                                condition2,
                                condition3
                            }
            };
            query.AddOrder(ELV3InspectionAttributeNames.InspectionDate, OrderType.Descending);
            EntityCollection records = service.RetrieveMultiple(query);
            return records;

        }

        /// <summary>
        /// This Function Will return the CAT1 AOC Accepted reports in desc order of AOC inspection Date when device Id is passed(exclude PVT AOC)
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static EntityCollection getELV29AcceptedReports(Guid DeviceId, IOrganizationService service)
        {
            EntityCollection records = new EntityCollection();
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                    <entity name='dobnyc_elv29'>
                                    <attribute name='dobnyc_name' />
                                    <attribute name='createdon' />
                                    <attribute name='dobnyc_streetname' />
                                    <attribute name='dobnyc_housenumber' />
                                    <attribute name='dobnyc_elv29_filingfee' />
                                    <attribute name='dobnyc_dateofinitialinspection' />
                                    <attribute name='dobnyc_dateofaocinspection' />
                                    <attribute name='dobnyc_borough' />
                                    <attribute name='dobnyc_bin' />
                                    <attribute name='dobnyc_approvedagencydirectorcodirector' />
                                    <attribute name='dobnyc_elv29_reportstatus' />
                                    <attribute name='dobnyc_elv29id' />
                                    <order attribute='dobnyc_dateofaocinspection' descending='true' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_elv29_reportstatus' operator='eq' value='17' />
                                      <condition attribute='dobnyc_elv29_deviceid' operator='eq'  uitype='dobnyc_elevatordevice' value='{0}' />
                                    </filter>
                                    <link-entity name='dobnyc_elv3' from='dobnyc_elv3id' to='dobnyc_elv29_elv3lookup' alias='as'>
                                      <filter type='and'>
                                        <condition attribute='dobnyc_elv3_reportstatus' operator='eq' value='9' />
                                        <condition attribute='dobnyc_inspectiontype' operator='eq' value='1' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            fetchXml = string.Format(fetchXml, DeviceId.ToString());



            if (fetchXml != string.Empty)
            {
                records = service.RetrieveMultiple(new FetchExpression(fetchXml));
            }

            return records;

        }


        /// <summary>
        /// This method is used to get the current ceaseusestatus on the elevator device. returns true if cease use is active else false
        /// </summary>
        /// <param name="DeviceId"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static bool getMasterDeviceCeaseUseStatus(Guid DeviceId, IOrganizationService service)
        {

//            NULL
//Cease Use
//Cease Use Lifted
//Cease Use Not Lifted
//Restore to Service Class 1
//Restore to Service Class 1 Continued
//Service Restored
            Entity elevatorDevice = service.Retrieve(ElevatorMasterDevice.EntityLogicalName, DeviceId, new ColumnSet(new string[] {ElevatorMasterDevice.ceaseUseFlag }));
            string ceaseuseValue = (elevatorDevice.Contains(ElevatorMasterDevice.ceaseUseFlag) && elevatorDevice[ElevatorMasterDevice.ceaseUseFlag] != null) ? elevatorDevice.GetAttributeValue<string>(ElevatorMasterDevice.ceaseUseFlag) : string.Empty;
            if (ceaseuseValue!=string.Empty && (ceaseuseValue== "Cease Use"|| ceaseuseValue == "Cease Use Not Lifted"))
            {
                return true;
            }
            else
            {
                return false;
            }

        }








        /// <summary>
        /// This Function Will return the PVT AOC Accepted reports for private owner type and that particular year ,device
        /// </summary>
        /// <param name="DeviceId"></param>
        /// <param name="preImage">used to get the year of the AOC inspection</param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static EntityCollection getELV29AcceptedPVTQCReports(Guid DeviceId, Entity preImage, IOrganizationService service, StringBuilder crmTrace)
        {
            EntityCollection records = new EntityCollection();
            try
            {


                #region old FetchXML based on AOC Inspection Date (Commented Because of requirement changed to ELv3 file Date)
                /* string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='dobnyc_elv29'>
                                     <attribute name='dobnyc_name' />
                                     <attribute name='createdon' />
                                     <attribute name='dobnyc_streetname' />
                                     <attribute name='dobnyc_housenumber' />
                                     <attribute name='dobnyc_elv29_filingfee' />
                                     <attribute name='dobnyc_dateofinitialinspection' />
                                     <attribute name='dobnyc_dateofaocinspection' />
                                     <attribute name='dobnyc_borough' />
                                     <attribute name='dobnyc_bin' />
                                     <attribute name='dobnyc_approvedagencydirectorcodirector' />
                                     <attribute name='dobnyc_elv29_reportstatus' />
                                     <attribute name='dobnyc_elv29id' />
                                     <order attribute='dobnyc_name' descending='false' />
                                     <filter type='and'>
                                       <condition attribute='dobnyc_elv29_deviceid' operator='eq'  uitype='dobnyc_elevatordevice' value='{0}' />
                                       <condition attribute='dobnyc_ownertype' operator='eq' value='1' />
                                       <filter type='and'>
                                         <condition attribute='dobnyc_dateofaocinspection' operator='on-or-after' value='{1}-01-01' />
                                         <condition attribute='dobnyc_dateofaocinspection' operator='on-or-before' value='{1}-12-31' />
                                       </filter>
                                      <condition attribute='dobnyc_elv29_reportstatus' operator='in'>
                                         <value>5</value>
                                         <value>6</value>
                                         <value>4</value>
                                         <value>3</value>
                                         <value>2</value>
                                         <value>10</value>
                                          <value>14</value>
                                          <value>15</value>
                                       </condition>
                                     </filter>
                                     <link-entity name='dobnyc_elv3' from='dobnyc_elv3id' to='dobnyc_elv29_elv3lookup' alias='ad'>
                                       <filter type='and'>
                                         <condition attribute='dobnyc_inspectiontype' operator='in'>
                                           <value>7</value>
                                           <value>8</value>
                                         </condition>
                                         <condition attribute='dobnyc_elv3_reportstatus' operator='eq' value='9' />
                                       </filter>
                                     </link-entity>
                                   </entity>
                                 </fetch>";*/
                #endregion

                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_elv29'>
                                    <attribute name='dobnyc_name' />
                                    <attribute name='createdon' />
                                    <attribute name='dobnyc_streetname' />
                                    <attribute name='dobnyc_housenumber' />
                                    <attribute name='dobnyc_elv29_filingfee' />
                                    <attribute name='dobnyc_dateofinitialinspection' />
                                    <attribute name='dobnyc_dateofaocinspection' />
                                    <attribute name='dobnyc_borough' />
                                    <attribute name='dobnyc_bin' />
                                    <attribute name='dobnyc_approvedagencydirectorcodirector' />
                                    <attribute name='dobnyc_elv29_reportstatus' />
                                    <attribute name='dobnyc_elv29id' />
                                    <order attribute='dobnyc_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_elv29_deviceid' operator='eq'  uitype='dobnyc_elevatordevice' value='{0}' />
                                      <condition attribute='dobnyc_ownertype' operator='eq' value='1' />
                                      
                                     <condition attribute='dobnyc_elv29_reportstatus' operator='in'>
                                        <value>5</value>
                                        <value>6</value>
                                        <value>4</value>
                                        <value>3</value>
                                        <value>2</value>
                                        <value>10</value>
                                         <value>14</value>
                                         <value>15</value>
                                      </condition>
                                    </filter>
                                    <link-entity name='dobnyc_elv3' from='dobnyc_elv3id' to='dobnyc_elv29_elv3lookup' alias='ad'>
                                      <filter type='and'>
                                        <condition attribute='dobnyc_inspectiontype' operator='in'>
                                          <value>7</value>
                                          <value>8</value>
                                        </condition>
                                        <condition attribute='dobnyc_elv3_reportstatus' operator='eq' value='9' />
                                         <filter type='and'>
                                          <condition attribute='dobnyc_elv3_violationdate' operator='on-or-after' value='{1}-01-01' />
                                          <condition attribute='dobnyc_elv3_violationdate' operator='on-or-before' value='{1}-12-31' />
                                        </filter>
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";


                Entity Elv3 = service.Retrieve(ELV3InspectionAttributeNames.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id, new ColumnSet(new string[] { ELV3InspectionAttributeNames.violationDate, ELV3InspectionAttributeNames.SubmissionDate }));

                DateTime violationDate = (Elv3.Contains(ELV3InspectionAttributeNames.violationDate) && Elv3[ELV3InspectionAttributeNames.violationDate] != null) ? Elv3.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.violationDate) : preImage.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.DateOfInitialInspection);//if violation date is null then get the date of initial Inspection


                fetchXml = string.Format(fetchXml, DeviceId.ToString(), violationDate.Year.ToString());



                if (fetchXml != string.Empty)
                {
                    records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                }

                crmTrace.AppendLine(fetchXml);

                return records;
            }

            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return records;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getELV29AcceptedPVTQCReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            #endregion

        }

        /// <summary>
        /// This Function Will return the ELV3 Active NRF reports when device Id is passed
        /// </summary>
        /// <param name="DeviceId"></param>
        /// <param name="preImage">used to get the inspection type</param>
        /// <param name="service"></param>
        /// /// <param name="Isdeactivate"> flag is used to make ELv29 records deactivate</param>
        /// <returns></returns>
        public static EntityCollection getActiveELV3NRFReports(Guid DeviceId, Entity preImage, IOrganizationService service, StringBuilder crmTrace, bool Isdeactivate)
        {
            EntityCollection records = new EntityCollection();
            try
            {



                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='dobnyc_elv3'>
                                        <attribute name='dobnyc_name' />
                                        <attribute name='createdon' />
                                        <attribute name='dobnyc_owner_type' />
                                        <attribute name='dobnyc_inspectiontestdate' />
                                        <attribute name='dobnyc_inspagency_director' />
                                        <attribute name='dobnyc_filingyear' />
                                        <attribute name='dobnyc_elv3_filingfee' />
                                        <attribute name='dobnyc_reporttype' />
                                        <attribute name='dobnyc_elv3_reportstatus' />
                                        <attribute name='dobnyc_elv3_latefilingfee' />
                                        <attribute name='dobnyc_housenumber' />
                                        <attribute name='dobnyc_borough' />
                                        <attribute name='dobnyc_bin' />
                                        <attribute name='dobnyc_inspectiontype' />
                                        <attribute name='dobnyc_elv3id' />
                                        <order attribute='dobnyc_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='dobnyc_inspectiontype' operator='eq' value='{0}' />
                                          <condition attribute='dobnyc_elv3_reportstatus' operator='eq' value='13' />
                                          <condition attribute='dobnyc_elv3_elevatorid' operator='eq' uitype='dobnyc_elevatordevice' value='{1}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                fetchXml = string.Format(fetchXml, preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value, DeviceId.ToString());



                if (fetchXml != string.Empty)
                {
                    records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                }

                crmTrace.AppendLine(fetchXml);

                #region Deactivate NRF Records
                if (Isdeactivate)
                {
                    crmTrace.AppendLine("Isdeactivate :" + Isdeactivate);
                    if (records != null && records.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("records.Entities.Count :" + records.Entities.Count);
                        foreach (Entity elv3 in records.Entities)
                        {
                            elv3.SetAttributeValue(ELV3InspectionAttributeNames.ELV3NRFLookup, preImage.ToEntityReference());

                            service.Update(elv3);
                            service.Execute(new SetStateRequest
                            {
                                EntityMoniker = new EntityReference(ELV3InspectionAttributeNames.EntityLogicalName, elv3.Id),
                                State = new OptionSetValue(1),
                                Status = new OptionSetValue(2)
                            });
                        }
                        crmTrace.AppendLine("Deactivate End :");
                    }
                }
                #endregion

                return records;
            }

            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return records;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV3NRFReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            #endregion

        }


        /// <summary>
        /// This Function Will return the ELV29 Active NRF reports when device Id is passed
        /// </summary>
        /// <param name="DeviceId"></param>
        /// <param name="preImage">ELV3 entity preimage</param>
        /// <param name="service"></param>
        /// <param name="Isdeactivate"> flag is used to make ELv29 records deactivate</param>
        /// <returns></returns>
        public static EntityCollection getActiveELV29NRFReports(Guid DeviceId, Entity preImage, IOrganizationService service, StringBuilder crmTrace, bool Isdeactivate)
        {
            EntityCollection records = new EntityCollection();
            try
            {



                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_elv29'>
                                    <attribute name='dobnyc_name' />
                                    <attribute name='createdon' />
                                    <attribute name='dobnyc_streetname' />
                                    <attribute name='dobnyc_housenumber' />
                                    <attribute name='dobnyc_elv29_filingfee' />
                                    <attribute name='dobnyc_dateofinitialinspection' />
                                    <attribute name='dobnyc_dateofaocinspection' />
                                    <attribute name='dobnyc_borough' />
                                    <attribute name='dobnyc_bin' />
                                    <attribute name='dobnyc_elv29_120dayslatefilingfee' />
                                    <attribute name='dobnyc_elv29_reportstatus' />
                                    <attribute name='dobnyc_elv29id' />
                                    <order attribute='dobnyc_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='dobnyc_elv29_reportstatus' operator='eq' value='13' />
                                      <condition attribute='dobnyc_elv29_deviceid' operator='eq'  uitype='dobnyc_elevatordevice' value='{0}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                fetchXml = string.Format(fetchXml, DeviceId.ToString());



                if (fetchXml != string.Empty)
                {
                    records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                }

                crmTrace.AppendLine(fetchXml);

                #region Deactivate NRF Records
                if (Isdeactivate)
                {
                    crmTrace.AppendLine("Isdeactivate :" + Isdeactivate);
                    if (records != null && records.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("records.Entities.Count :" + records.Entities.Count);
                        foreach (Entity elv3 in records.Entities)
                        {
                            elv3.SetAttributeValue(ELV29AffirimationAttributeNames.ELV3NRFLookup, preImage.ToEntityReference());

                            service.Update(elv3);

                            service.Execute(new SetStateRequest
                            {
                                EntityMoniker = new EntityReference(ELV29AffirimationAttributeNames.EntityLogicalName, elv3.Id),
                                State = new OptionSetValue(1),
                                Status = new OptionSetValue(2)
                            });
                        }
                        crmTrace.AppendLine("Deactivate End :");
                    }
                }
                #endregion

                return records;
            }

            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return records;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", "SubmitHandler - getActiveELV29NRFReports", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return records;
            }
            #endregion

        }

        /// <summary>
        ///To capture respective dates when report status is changed (except Filing/Resubmission Date)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity UpdateDateIfApplicable(IOrganizationServiceConnector serviceConnector, Entity targetEntity, Entity preImage, OptionSetValue currentReportStatus, StringBuilder customTrace)
        {
            try
            {
                customTrace.AppendLine("Get Filing Status");

                switch (currentReportStatus.Value)
                {


                    case (int)ELV3ReportStatus.QAReview:
                        {
                            customTrace.AppendLine("Report status has been changed to QAReview");

                            // Set PermitEntireSentforInspection Date
                            customTrace.AppendLine("Setting  QAReview Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.QAReviewDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting QAReview Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3ReportStatus.QAFailed:
                        {
                            customTrace.AppendLine("Report status has been changed to QAFailed");

                            // Set SignedOff Date
                            customTrace.AppendLine("Setting QAFailed Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.QAFailedDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting QAFailed Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3ReportStatus.Incomplete:
                        {
                            customTrace.AppendLine("Report status has been changed to Incomplete");

                            // Set IncompleteSubmission Date
                            customTrace.AppendLine("Setting Incomplete Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.IncompleteSubmissionDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting Incomplete Date as : " + DateTime.Today.ToShortDateString());




                            break;
                        }

                    case (int)ELV3ReportStatus.Accepted:
                        {
                            customTrace.AppendLine("Report status has been changed to Accepted");


                            customTrace.AppendLine("Setting Accepted Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.AccepetedDAte, DateTime.Today);
                            customTrace.AppendLine("Completed Setting Accepted Date as : " + DateTime.Today.ToShortDateString());

                            //OwnerType NYCHA,AmountPaid>0 then set the adjustment to Amount paid
                            if ((preImage.Contains(ELV3InspectionAttributeNames.OwnerType) && preImage[ELV3InspectionAttributeNames.OwnerType] != null && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.NYCHA) && //owner type should be NYCHA and Amount Paid should be >0 
                                (preImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && preImage[ELV3InspectionAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0))
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.Adjustment, preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid));
                            }

                            //Dismiss the Violation for the AOC with Accepted Corrections-Violations Not Dismissed written in task completion plugin as external call will not work 
                          
                           
                            break;
                        }


                    case (int)ELV3ReportStatus.AcceptedDefects:
                        {
                            customTrace.AppendLine("Report status has been changed to AcceptedDefects");

                            // Set Objection Date
                            customTrace.AppendLine("Setting Accepted Defects Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.AccepetedDefectsDAte, DateTime.Today);
                            customTrace.AppendLine("Completed Setting Accepted Defects Date as : " + DateTime.Today.ToShortDateString());

                            //OwnerType NYCHA,AmountPaid>0 then set the adjustment to Amount paid
                            if ((preImage.Contains(ELV3InspectionAttributeNames.OwnerType) && preImage[ELV3InspectionAttributeNames.OwnerType] != null && preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.NYCHA) && //owner type should be NYCHA and Amount Paid should be >0 
                                (preImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && preImage[ELV3InspectionAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0))
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.Adjustment, preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid));
                            }
                         
                            break;
                        }

                    default:
                        {
                            break;
                        }
                }

                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }


        /// <summary>
        ///To capture respective dates when ELV29report status is changed (except Filing/Resubmission Date)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity UpdateDateELV29IfApplicable(IOrganizationServiceConnector serviceConnector, Entity targetEntity, Entity preImage, OptionSetValue currentReportStatus, StringBuilder customTrace)
        {
            try
            {
                customTrace.AppendLine("Get Filing Status");

                switch (currentReportStatus.Value)
                {


                    case (int)ELV3ReportStatus.QAReview:
                        {
                            customTrace.AppendLine("Report status has been changed to QAReview");

                            // Set PermitEntireSentforInspection Date
                            customTrace.AppendLine("Setting  QAReview Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.QAReviewDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting QAReview Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3ReportStatus.QAFailed:
                        {
                            customTrace.AppendLine("Report status has been changed to QAFailed");

                            // Set SignedOff Date
                            customTrace.AppendLine("Setting QAFailed Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.QAFailedDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting QAFailed Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3ReportStatus.Incomplete:
                        {
                            customTrace.AppendLine("Report status has been changed to Incomplete");

                            // Set IncompleteSubmission Date
                            customTrace.AppendLine("Setting Incomplete Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.IncompleteSubmissionDate, DateTime.Today);
                            customTrace.AppendLine("Completed Setting Incomplete Date as : " + DateTime.Today.ToShortDateString());

                            //remove the adjustment & deduct the value in amt paid


                            break;
                        }

                    case (int)ELV3ReportStatus.Accepted:
                    case (int)ELV3ReportStatus.AcceptedCorrectionsViolationDismissed:
                    case (int)ELV3ReportStatus.AcceptedCorrectionsViolationNotDismissed:
                    case (int)ELV3ReportStatus.CorrectionsAccepted:
                        {
                            customTrace.AppendLine("Report status has been changed to Accepted");

                            // Set Objection Date
                            customTrace.AppendLine("Setting Accepted Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.AccepetedDAte, DateTime.Today);
                            customTrace.AppendLine("Completed Setting Accepted Date as : " + DateTime.Today.ToShortDateString());

                            //remove the adjustment & deduct the value in amt paid


                            break;
                        }




                    default:
                        {
                            break;
                        }
                }

                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateELV29IfApplicable", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }



        /// <summary>
        ///To Set the correcte status when user submits or resubmits the ELV3 filing
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"> preimage of elv3</param>
        /// <param name="revertIncompleteSubmission">This will determine the resubmission or normal submission</param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity ELV3ManualWorkflow(IOrganizationService service, Entity targetEntity, Entity preImage, int revertIncompleteSubmission, StringBuilder crmTrace)
        {
            try
            {

                #region Payment Method-Check

                if (targetEntity.Contains(ELV3InspectionAttributeNames.ELV3PaymentMethod) && targetEntity[ELV3InspectionAttributeNames.ELV3PaymentMethod] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ELV3PaymentMethod).Value == (int)PaymentMethod.Check)//use target entity because once ELV3 status in Payment verification package will update again user filing actions to file with out payment method  then normal workflow will trigger
                {
                    crmTrace.AppendLine("Payment Done by Check so set the status to payment verification");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PaymentVerification));
                }
                #endregion

                #region Payment Method-Other than check
                else
                {
                    crmTrace.AppendLine("Payment method other than check");
                    switch (revertIncompleteSubmission)
                    {
                        case (int)ELV3RevertedFromIncompleteSubmission.None:
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                                // Set filing Date
                                crmTrace.AppendLine("Setting  filing Date as : " + DateTime.Today.ToShortDateString());
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.FilingDate, DateTime.Today);
                                crmTrace.AppendLine("Completed Setting filing Date as : " + DateTime.Today.ToShortDateString());
                                break;
                            }

                        case (int)ELV3RevertedFromIncompleteSubmission.QASupervisorReview:
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                                // Set Resubmission Date
                                crmTrace.AppendLine("Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ResubmissionDate, DateTime.Today);
                                crmTrace.AppendLine("Completed Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                                break;
                            }

                        case (int)ELV3RevertedFromIncompleteSubmission.QAReview:
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QAReview));
                                // Set Resubmission Date
                                crmTrace.AppendLine("Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ResubmissionDate, DateTime.Today);
                                crmTrace.AppendLine("Completed Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                                break;
                            }

                        default:
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                                // Set filing Date
                                crmTrace.AppendLine("Setting  filing Date as (switch-default): " + DateTime.Today.ToShortDateString());
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.FilingDate, DateTime.Today);
                                crmTrace.AppendLine("Completed Setting filing Date as : " + DateTime.Today.ToShortDateString());
                                break;
                            }
                    }
                    //SubmitHandler.getActiveELV3NRFReports(preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, preImage, service, crmTrace, true);
                    //SubmitHandler.getActiveELV29NRFReports(preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, preImage, service, crmTrace, true);

                }
                #endregion









                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV3ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - UpdateDateIfApplicable", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV3ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV3ManualWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV3ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV3ManualWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }


        /// <summary>
        ///To Set the correcte status when user submits or resubmits the ELV29 filing
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="revertIncompleteSubmission">This will determine the resubmission or normal submission</param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity ELV29ManualWorkflow(IOrganizationService service, Entity targetEntity, int revertIncompleteSubmission, StringBuilder crmTrace)
        {
            try
            {


                switch (revertIncompleteSubmission)
                {
                    case (int)ELV3RevertedFromIncompleteSubmission.None:
                        {
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                            // Set filing Date
                            crmTrace.AppendLine("Setting  filing Date as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.FilingDate, DateTime.Today);
                            crmTrace.AppendLine("Completed Setting filing Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3RevertedFromIncompleteSubmission.QASupervisorReview:
                        {
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                            // Set Resubmission Date
                            crmTrace.AppendLine("Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ResubmissionDate, DateTime.Today);
                            crmTrace.AppendLine("Completed Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    case (int)ELV3RevertedFromIncompleteSubmission.QAReview:
                        {
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QAReview));
                            // Set Resubmission Date
                            crmTrace.AppendLine("Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ResubmissionDate, DateTime.Today);
                            crmTrace.AppendLine("Completed Setting ResubmissionDate as : " + DateTime.Today.ToShortDateString());
                            break;
                        }

                    default:
                        {
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.QASupervisorReview));
                            // Set filing Date
                            crmTrace.AppendLine("Setting  filing Date as (switch-default): " + DateTime.Today.ToShortDateString());
                            CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.FilingDate, DateTime.Today);
                            crmTrace.AppendLine("Completed Setting filing Date as : " + DateTime.Today.ToShortDateString());
                            break;
                        }
                }

                return targetEntity;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "SubmitHandler - ELV29ManualWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }

    }
}
