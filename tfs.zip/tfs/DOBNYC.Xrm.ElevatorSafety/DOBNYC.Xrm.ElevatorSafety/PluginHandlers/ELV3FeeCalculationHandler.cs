﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;
namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class ELV3FeeCalculationHandler : PluginHandlerBase
    {
        /// <summary>
        /// This Function is used to Calculate only Filing Fee for ELV3 and set it to feeObject and also set the shared variables used for creation of transaction Histories
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject">Used to storer the Filing Fee so that it can pass it to latefiling fee method</param>
        /// /// <param name="SharedVariables">Used to store Amount due fee such that we can use in creation of Shadow payment history creation in post operation</param>
        public static ElevatorSafetyFeeCalculationobject CalculateELV3FilingFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, ElevatorSafetyFeeCalculationobject feeObject, ParameterCollection SharedVariables)
        {


            try
            {

                //if(feeexempt) block is missing have to include  everrything which is below should go in else part
                #region Non-Fee exempt Filing fee calculation
                if (targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                {
                    if (targetEntity.Contains(ELV3InspectionAttributeNames.InspectionType) && targetEntity[ELV3InspectionAttributeNames.InspectionType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value > 0)
                    {
                        switch (targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value)
                        {
                            case (int)ELV3InspectionType.CAT1:
                                {
                                    crmTrace.AppendLine("ELV3InspectionType.CAT1 Filing Fee Started");
                                    feeObject.ELV3FilingFee = RetrieveFee(crmTrace,service, FeeConfigs.cat1FilingFee) ;//According to BRD


                                    break;
                                }
                            case (int)ELV3InspectionType.CAT3:
                            case (int)ELV3InspectionType.CAT5:
                                {
                                    crmTrace.AppendLine("ELV3InspectionType.CAT3 or CAT5 Filing Fee Started");
                                    feeObject.ELV3FilingFee = RetrieveFee(crmTrace,service, FeeConfigs.cat3Cat5FilingFee);//According to BRD



                                    break;
                                }


                            case (int)ELV3InspectionType.HoistJumpUP:
                            case (int)ELV3InspectionType.HoistJumpDown:
                            case (int)ELV3InspectionType.NinetyDayTempRenewal:
                                {
                                    //According to BRD All personla Hoists filing fee costs 0
                                    crmTrace.AppendLine("ELV3InspectionType.HoistJumpUP  or HoistJumpDown or NinetyDayTempRenewal Filing Fee Started");
                                    feeObject.ELV3FilingFee = 0;

                                    break;
                                }

                        }

                    }
                }
                #endregion

                #region Fee exempt -Filing Fee calculation
                else
                {
                    feeObject.ELV3FilingFee = 0;//According to BRD

                    crmTrace.AppendLine("Fee Exempt ");

                }
                #endregion

                return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3FilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3FilingFee- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return feeObject;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV3FilingFee- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-CalculateELV3FilingFee- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV3FilingFee- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3FilingFee - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }


        }


        /// <summary>
        /// This Function is used to associate TNF(if present any not associated) to ELV3 on submit 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        /// 
        /// 
        public static void associateTNF(IOrganizationService service,Entity targetEntity, Entity preImage, StringBuilder crmTrace )
        {


            try
            {
                crmTrace.AppendLine("get the TNF -started");
                ConditionExpression condition1 = new ConditionExpression(ELV36TestNotificationAttributeNames.DeviceIdLookup, ConditionOperator.Equal, preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id);
                ConditionExpression condition2 = new ConditionExpression(ELV36TestNotificationAttributeNames.ReportStatus, ConditionOperator.Equal, 2);//2 is for submitted
                ConditionExpression condition3 = new ConditionExpression(ELV36TestNotificationAttributeNames.InspectionType, ConditionOperator.Equal,preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value);
                ConditionExpression condition4 = new ConditionExpression(ELV36TestNotificationAttributeNames.InspectionDate, ConditionOperator.Equal, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate));
                //  OrderExpression order1 = new OrderExpression(ELV3InspectionAttributeNames.InspectionDate, OrderType.Descending);
                QueryExpression query = new QueryExpression(ELV36TestNotificationAttributeNames.EntityLogicalName);
                query.ColumnSet = new ColumnSet(new string[] { ELV36TestNotificationAttributeNames.InspectionDate });
                query.Criteria = new FilterExpression(LogicalOperator.And)
                {
                    Conditions =
                            {
                                condition1,
                                condition2,
                                condition3,
                                condition4
                            }
                };
               
                EntityCollection records = service.RetrieveMultiple(query);
                crmTrace.AppendLine("records TNF:"+ records.Entities.Count);
                if (records!=null && records.Entities.Count>0)
                {
                    crmTrace.AppendLine(" TNF Present id:" + records[0].Id);
                    targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.TNFId, new EntityReference(ELV36TestNotificationAttributeNames.EntityLogicalName, records[0].Id));
                    crmTrace.AppendLine(" Set TNF in target Entity:" + records[0].Id);
                }



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-associateTNF - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-associateTNF- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
               
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-associateTNF- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-associateTNF- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
              

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-associateTNF- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-associateTNF - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                

            }


        }





        /// <summary>
        /// This Function is used to Calculate only Filing Fee for ELV29 based on ELV3 inspection type
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// /// <param name="SharedVariables">Used to store Amount due fee such that we can use in creation of Shadow payment history creation in post operation</param>
        /// <param name="inspectionType"> ELV3 inspection type and determines the filing fee</param>
        public static ElevatorSafetyFeeCalculationobject CalculateELV29FilingFee(IOrganizationService service, Entity targetEntity,ElevatorSafetyFeeCalculationobject feeObject, StringBuilder crmTrace, ParameterCollection SharedVariables, int inspectionType)
        {
            //As per Requirements   Filing Fee should be  $40 for Private Owner type and $0 for remaining owner types --CAT1 AOC
            //For PVT AOC filing fee is 40 default
            //For QC AOC filing fee is 0 default as per BRD

            try
            {


                if (inspectionType > 0)
                {
                    switch (inspectionType)
                    {
                        case (int)ELV3InspectionType.CAT1:
                            {
                                #region Non-Fee exempt Filing fee calculation
                                if (targetEntity.Contains(ELV29AffirimationAttributeNames.OwnerType) && targetEntity[ELV29AffirimationAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                                {
                                    crmTrace.AppendLine("As per Requirements Filing Fee should be  $40 for Private Owner type and $0 for remaining owner types");
                                    feeObject.ELV29FilingFee =RetrieveFee(crmTrace,service, FeeConfigs.cat1AOCFilingFee);

                                }
                                #endregion
                                #region Fee exempt -Filing Fee calculation
                                else
                                {
                                    feeObject.ELV29FilingFee = 0;
                                    crmTrace.AppendLine("Fee Exempt Set Variables End ");
                                }
                                #endregion
                                break;
                            }
                        case (int)ELV3InspectionType.PVTInspection:
                        case (int)ELV3InspectionType.QCInspection:
                            {
                                ///For a given device and a given year charge $40 for the first PVT/QC AOC filing ramaining PVT/QC AOC filings for that year will be free (Business Rule)

                                //check the device id and AOC inspection year 
                                //retreive all PVT/QC AOC's  for that device in that inspection year
                                //if above record count>0 then no fees else $40

                                #region Non-Fee Exempt
                                if (targetEntity.Contains(ELV29AffirimationAttributeNames.OwnerType) && targetEntity[ELV29AffirimationAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                                {
                                   
                                    EntityCollection acceptedPVTQCAOCInspectionYear = SubmitHandler.getELV29AcceptedPVTQCReports(targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.DeviceIdLookup).Id, targetEntity, service, crmTrace);
                                    crmTrace.AppendLine("acceptedPVTQCAOCInspectionYear :" + acceptedPVTQCAOCInspectionYear.Entities.Count);
                                    if(acceptedPVTQCAOCInspectionYear!=null&& acceptedPVTQCAOCInspectionYear.Entities.Count==1)
                                    {
                                        //scenario- Initial filing was fee exempt then  Qa supervisor make incomplete on resubmission owner ype changed to private so charge $40
                                        if(acceptedPVTQCAOCInspectionYear.Entities[0].Id==targetEntity.Id)
                                        {
                                            crmTrace.AppendLine("This PVt/QC Aoc is the first for this inspection year so As per Requirements Filing Fee should be  $40 for PVT/QC AOC");
                                            feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.pvtAOCFilingFee);
                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("Already system has one paid PVT/QC AOC so no filing fee  ");
                                            feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.qcAOCFilingFee); //$0
                                        }
                                    }
                                    else if (acceptedPVTQCAOCInspectionYear != null && acceptedPVTQCAOCInspectionYear.Entities.Count > 0)
                                    {
                                        //Check preimage filing fee and amount paid if any one has >0  value then filing fee =40 else filing fee zero bug#12496
                                        if((targetEntity.Contains(ELV29AffirimationAttributeNames.FilingFee)&& targetEntity[ELV29AffirimationAttributeNames.FilingFee]!=null&& targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.FilingFee).Value>0)||
                                            (targetEntity.Contains(ELV29AffirimationAttributeNames.AmountPaid) && targetEntity[ELV29AffirimationAttributeNames.AmountPaid] != null && targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value > 0)
                                            )
                                        {
                                            crmTrace.AppendLine("Already amount paid or filing fee present");
                                            feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.pvtAOCFilingFee); 
                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("Already system has one paid PVT/QC AOC so no filing fee  ");
                                            feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.qcAOCFilingFee); //$0
                                        }

                                        
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("This PVt/QC Aoc is the first for this inspection year so As per Requirements Filing Fee should be  $40 for PVT/QC AOC");
                                        feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.pvtAOCFilingFee);
                                    }
                                }
                                #endregion

                                #region Fee exempt
                                else
                                {
                                    feeObject.ELV29FilingFee = RetrieveFee(crmTrace, service, FeeConfigs.qcAOCFilingFee); //$0

                                }
                                #endregion




                                break;
                            }

                    }
                }



                crmTrace.AppendLine("ELv29 Filing Fee: " + feeObject.ELV29FilingFee);
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29FilingFee Testing Purpose - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                return feeObject;
                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29FilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29FilingFee- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return feeObject;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV29FilingFee- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + "- ELV3FeeCalculationHandler-CalculateELV29FilingFee- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV29FilingFee- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV29FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29FilingFee - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }


        }
        /// <summary>
        /// This Function Will return device status when ELV3 entity is passed
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static int GetDeviceStatus(Entity targetEntity, IOrganizationService service)
        {
            Guid MasterDeviceId = targetEntity.Contains(ELV3InspectionAttributeNames.DeviceIdLookup) && targetEntity[ELV3InspectionAttributeNames.DeviceIdLookup] != null ? targetEntity.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id : new Guid();
            Entity MasterDevice = service.Retrieve(ElevatorMasterDevice.EntityLogicalName, MasterDeviceId, new ColumnSet(new string[] { ElevatorMasterDevice.DeviceStatus }));
            if (MasterDevice != null && MasterDevice.Id != null)
            {
                if (MasterDevice.Contains(ElevatorMasterDevice.DeviceStatus))
                {
                    return MasterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value;
                }
            }
            else
            {
                return 0;
            }
            return 0;

        }

        /// <summary>
        /// This Function Will return device status when ELV29 entity is passed
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static int GetAOCDeviceStatus(Entity targetEntity, IOrganizationService service)
        {
            Guid MasterDeviceId = targetEntity.Contains(ELV29AffirimationAttributeNames.DeviceIdLookup) && targetEntity[ELV29AffirimationAttributeNames.DeviceIdLookup] != null ? targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.DeviceIdLookup).Id : new Guid();
            Entity MasterDevice = service.Retrieve(ElevatorMasterDevice.EntityLogicalName, MasterDeviceId, new ColumnSet(new string[] { ElevatorMasterDevice.DeviceStatus }));
            if (MasterDevice != null && MasterDevice.Id != null)
            {
                if (MasterDevice.Contains(ElevatorMasterDevice.DeviceStatus))
                {
                    return MasterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value;
                }
            }
            else
            {
                return 0;
            }
            return 0;

        }

        /// <summary>
        /// This Function Will return Inspection Type when ELV29 entity is passed
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <returns></returns>
        public static int GetELV3InspectionType(Entity targetEntity, IOrganizationService service)
        {
            Guid Elv3Id = targetEntity.Contains(ELV29AffirimationAttributeNames.Elv3Lookup) && targetEntity[ELV29AffirimationAttributeNames.Elv3Lookup] != null ? targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.Elv3Lookup).Id : new Guid();

            ///if guid is not present then consider it as cat1
            if (Elv3Id != null && Elv3Id != new Guid())
            {
                Entity ELV3 = service.Retrieve(ELV3InspectionAttributeNames.EntityLogicalName, Elv3Id, new ColumnSet(new string[] { ELV3InspectionAttributeNames.InspectionType }));
                if (ELV3 != null && ELV3.Id != null)
                {
                    if (ELV3.Contains(ELV3InspectionAttributeNames.InspectionType))
                    {
                        return ELV3.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value;
                    }
                }

            }
            else
            {
                return (int)ELV3InspectionType.CAT1;
            }

            return (int)ELV3InspectionType.CAT1;

        }

        /// <summary>
        /// This Function is Used to Calculate Late Filing Fee for ELV3 and set the amount due,filing fee,latefiling fee
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="DeviceStatus">This is the Device Status Housing,NYCHA,NoJudistriction,Active</param>
        /// <param name="inspectionType">CAT1,CAT3,CAT5,Jump Down,Jump Up,Temp Renewal</param>
        /// <param name="feeObject">Used to set amountdue filing fee,late fee and other fee attributes</param>
        /// <param name="SharedVariables">Used to store latefiling fee such that we can use in creation of Shadow payment history creation in post operation</param>
        public static ElevatorSafetyFeeCalculationobject CalculateELV3LateFilingFee(IOrganizationService service, Entity targetEntity, Entity PreImage, int DeviceStatus, int inspectionType, StringBuilder crmTrace, ElevatorSafetyFeeCalculationobject feeObject, ParameterCollection SharedVariables)
        {
            EntityCollection elv3ActiveNRFCollection = new EntityCollection(), elv29ActiveNRFCollection = new EntityCollection();
            DateTime annualInspectionDate = (targetEntity.Contains(ELV3InspectionAttributeNames.InspectionDate) && targetEntity[ELV3InspectionAttributeNames.InspectionDate] != null ? Convert.ToDateTime(targetEntity.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate).ToShortDateString()) : Convert.ToDateTime(PreImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate).ToShortDateString())); //Annual Inspection Date (either from target or Preimage)
            DateTime submissionDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); //Submision Date is today 
            // ((PreImage.Contains(ELV3InspectionAttributeNames.FilingDate) && PreImage[ELV3InspectionAttributeNames.FilingDate] != null) || !PreImage.Contains(ELV3InspectionAttributeNames.FilingDate)) ? Convert.ToDateTime(DateTime.Now.ToShortDateString()) : Convert.ToDateTime(PreImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.FilingDate).ToShortDateString()); //Submision Date is today or if preimage has filing date then take from preimage
            int numberOfDays, numberOfMonths, numberOfYears, penalityMonths;
            DateTime cat1LastSubmissionDate = new DateTime();//this date is used for March1stnextreportyear validation
            string reportYear = (PreImage.Contains(ELV3InspectionAttributeNames.ReportYear) && PreImage[ELV3InspectionAttributeNames.ReportYear] != null && PreImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.ReportYear) != string.Empty) ? PreImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.ReportYear) : string.Empty;
            crmTrace.AppendLine("reportYear: " + reportYear);

            if (reportYear != string.Empty && reportYear != null)
            {
                //set Cat1 last Submission date  to next year march 1st eg: report year= 2016 then CAT1 last Submission date = Mar 1st,2017 we will use this date in late fee calcultion any application after this date will be considered as NRF and we will charge $1000
                //cat1LastSubmissionDate = Convert.ToDateTime(new DateTime((Convert.ToInt32(reportYear) + 1), 3, 1).ToShortDateString()); //using datetime constructor to set the date march1st,nextreportyear
                crmTrace.AppendLine("cat1LastSubmissionDate: " + cat1LastSubmissionDate);
            }

            #region Get Amount Paid,Nogoodcheckfee and Filing Fee from PreImage
            feeObject.ELV3NoGoodCheckFee = PreImage.Contains(ELV3InspectionAttributeNames.noGoodCheckFee) && PreImage[ELV3InspectionAttributeNames.noGoodCheckFee] != null && PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.noGoodCheckFee).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.noGoodCheckFee).Value : 0;
            decimal prevAmountPaid = targetEntity.Contains(ELV3InspectionAttributeNames.AmountPaid) && targetEntity[ELV3InspectionAttributeNames.AmountPaid] != null  ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value :  PreImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && PreImage[ELV3InspectionAttributeNames.AmountPaid] != null && PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value : 0;
            crmTrace.AppendLine("prevAmountPaid: " + prevAmountPaid);
            decimal prevFilingFee = PreImage.Contains(ELV3InspectionAttributeNames.FilingFee) && PreImage[ELV3InspectionAttributeNames.FilingFee] != null && PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.FilingFee).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.FilingFee).Value : 0;
            crmTrace.AppendLine("prevFilingFee: " + prevFilingFee);
            #endregion

            decimal perMonthPenalty = 0, perYearPenalty = 0; //these fields will be determine the monthly penalty,yearly penalty based on device status
            try
            {

                #region All Fee exempt and Non-fee exmpt filings have to pay the late filing fee penalities 
                //  if (targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                // {
                numberOfDays = Convert.ToInt32((submissionDate - annualInspectionDate).TotalDays); //Submission Date is Today - Annual Inspection Date (either from target or Preimage)
                crmTrace.AppendLine("Number Of Days from Annual Inspection Date: " + numberOfDays);
                numberOfMonths = CalculateMonthsInBetween(annualInspectionDate, submissionDate);
                crmTrace.AppendLine("Number Of Months from Annual Inspection Date: " + numberOfMonths);
                numberOfYears = numberOfMonths / 12;
                // amountDue = targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0 ? targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : (PreImage.Contains(ELV3InspectionAttributeNames.AmountDue) && PreImage[ELV3InspectionAttributeNames.AmountDue] != null && PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value : 0); //get the amountdue from target or Preimage
                crmTrace.AppendLine("Number Of Years completed from Annual Inspection Date: " + numberOfYears);
                DateTime addSixtyDaysToAID = annualInspectionDate.AddDays(60);
                crmTrace.AppendLine("Sixth day from Annual Inspection Date is " + addSixtyDaysToAID);
                DateTime addSixtyDaysToAIDLastMonthDate= Convert.ToDateTime(new DateTime(addSixtyDaysToAID.Year,
                                    addSixtyDaysToAID.Month,
                                    DateTime.DaysInMonth(addSixtyDaysToAID.Year,
                                                         addSixtyDaysToAID.Month)).ToShortDateString());

                crmTrace.AppendLine("addSixtyDaysToAIDLastMonthDate: " + addSixtyDaysToAIDLastMonthDate);
                bool addExtraMonth = false;
                if (addSixtyDaysToAID != addSixtyDaysToAIDLastMonthDate)
                {
                    crmTrace.AppendLine("some days left in AOCFinalSubmissionDateWithOutPenalty date month  so add one month extra to calculation");
                    addExtraMonth = true;
                }
                switch (DeviceStatus)
                {
                    case (int)ElevatorDeviceStatus.NoJurisdiction:
                        {
                            switch (inspectionType)
                            {
                                case (int)ELV3InspectionType.CAT1:
                                case (int)ELV3InspectionType.CAT3:
                                case (int)ELV3InspectionType.CAT5:
                                    {
                                        //late filing fee is not applicable for NYCHA OwnerType
                                        if (PreImage.Contains(ELV3InspectionAttributeNames.OwnerType) && PreImage[ELV3InspectionAttributeNames.OwnerType] != null && PreImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                                        {
                                            #region Calculate Late Fee
                                            perMonthPenalty =RetrieveFee(crmTrace,service, FeeConfigs.elv3NoJurisdictionCAT1CAT3CAT5MonthPenalty);
                                            perYearPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv3NoJurisdictionCAT1CAT3CAT5YearPenalty);
                                            if (numberOfDays <= 60)
                                            {
                                                crmTrace.AppendLine(" Number of days <=60 days so No late filing fee charged");
                                                feeObject.ELV3LateFilingFee = 0;
                                            }
                                            else if (inspectionType == 1 && reportYear != string.Empty && cat1LastSubmissionDate != DateTime.MinValue && submissionDate > cat1LastSubmissionDate)
                                            {
                                                //set Cat1 last Submission date  to next year march 1st eg: report year= 2016 then CAT1 last Submission date = Mar 1st,2017 we will use this date in late fee calcultion any application after this date will be considered as NRF and we will charge $1000
                                                crmTrace.AppendLine(" Late Filing fee March1st next year case");
                                                feeObject.ELV3LateFilingFee = perYearPenalty;
                                            }
                                            else if (numberOfDays > 60 && numberOfMonths <= 12)
                                            {
                                                crmTrace.AppendLine(" Number of days > 60 days  but Number of Months <=12 so  late filing fee will be charged for the months from 61st day. $50 per month per device Maximum 500");
                                                penalityMonths = CalculateMonthsInBetween(addSixtyDaysToAID, submissionDate);
                                                crmTrace.AppendLine("Total Penality Months from 60th day is " + penalityMonths);
                                                if (penalityMonths == 0)
                                                {
                                                    feeObject.ELV3LateFilingFee = perMonthPenalty;
                                                }
                                                if (penalityMonths > 0)
                                                {
                                                    if (penalityMonths == 12)
                                                    {
                                                        feeObject.ELV3LateFilingFee = RetrieveFee(crmTrace, service, FeeConfigs.elv3NoJuridictionCAT1MaxPenalty);
                                                    }
                                                    else
                                                    {
                                                        feeObject.ELV3LateFilingFee = penalityMonths * perMonthPenalty;
                                                        if (addExtraMonth)//because we have some days left in  AOCFinalSubmissionDateWithOutPenalty
                                                        {
                                                            crmTrace.AppendLine("Adding Extra month");
                                                            feeObject.ELV3LateFilingFee = feeObject.ELV3LateFilingFee + perMonthPenalty;
                                                        }


                                                    }

                                                }


                                            }
                                            else
                                            {
                                                crmTrace.AppendLine(" Number of days > 365 days so This will be considered as not eligible to file In this case set the amount due to zero and set the user filing actions to save Because on save portal will validate the inspection date is valid or not");
                                                ///1) set the filing fee and late filing fee amount due as zero 
                                                ///2)set the user filing actions as save
                                                ///3)set the report status as Prefiling
                                                ///

                                                validateElv3InspectionDate1YearCondition(targetEntity, PreImage, feeObject, crmTrace);
                                                // feeObject.ELV3LateFilingFee = numberOfYears * perYearPenalty;

                                                ///Inspection Date and Submission date are 1 year apart so it is considered as NRF
                                                ///if it is NRF 1)We should not charge any amount both filing fee,latefiling fee willbe zero
                                                ///2)Set the status to NRF
                                            }

                                            #endregion
                                        }

                                        break;
                                    }




                            }

                            crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV3LateFilingFee);


                            //totalFee = filingFee + lateFilingFee;
                            // crmTrace.AppendLine("Total fee: " + totalFee);
                            break;
                        }
                    case (int)ElevatorDeviceStatus.Active:
                    case (int)ElevatorDeviceStatus.Sealed:
                        {

                            switch (inspectionType)
                            {
                                case (int)ELV3InspectionType.CAT1:
                                    {
                                        //late filing fee is not applicable for NYCHA OwnerType
                                        if (PreImage.Contains(ELV3InspectionAttributeNames.OwnerType) && PreImage[ELV3InspectionAttributeNames.OwnerType] != null && PreImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)

                                        {
                                            #region Calculate Late Fee
                                            perMonthPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT1MonthPenalty);
                                            perYearPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT1YearPenalty);
                                            if (numberOfDays <= 60)
                                            {
                                                crmTrace.AppendLine(" Number of days <=60 days so No late filing fee charged");
                                                feeObject.ELV3LateFilingFee = 0;
                                            }
                                            else if (inspectionType == 1 && reportYear != string.Empty && cat1LastSubmissionDate != DateTime.MinValue && submissionDate > cat1LastSubmissionDate)
                                            {
                                                crmTrace.AppendLine(" Late Filing fee March1st next year case");
                                                feeObject.ELV3LateFilingFee = perYearPenalty;
                                            }
                                            else if (numberOfDays > 60 && numberOfMonths <= 12)
                                            {
                                                crmTrace.AppendLine(" Number of days > 60 days  but Number of Months <=12 so  late filing fee will be charged for the months from 61st day. $150 per month per device Maximum 1800");
                                               
                                                penalityMonths = CalculateMonthsInBetween(addSixtyDaysToAID, submissionDate);
                                                crmTrace.AppendLine("Total Penality Months from 60th day is " + penalityMonths);
                                                if (penalityMonths == 0)
                                                {
                                                    feeObject.ELV3LateFilingFee = perMonthPenalty;
                                                }
                                                if (penalityMonths > 0)
                                                {
                                                    if (penalityMonths == 12)
                                                    {
                                                        feeObject.ELV3LateFilingFee = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT1MaxPenalty);
                                                    }
                                                    else
                                                    {
                                                        feeObject.ELV3LateFilingFee = penalityMonths * perMonthPenalty;
                                                        if (addExtraMonth)//because we have some days left in  AOCFinalSubmissionDateWithOutPenalty
                                                        {
                                                            crmTrace.AppendLine("Adding Extra month");
                                                            feeObject.ELV3LateFilingFee = feeObject.ELV3LateFilingFee + perMonthPenalty;
                                                        }


                                                    }
                                                }


                                            }
                                            else
                                            {
                                                crmTrace.AppendLine(" Number of days > 365 days so This will be considered as NRF In this case set the amount due to zero and set the user filing actions to save Because on save portal will validate the inspection date is valid or not");
                                                ///1) set the filing fee and late filing fee amount due as zero 
                                                ///2)set the user filing actions as save
                                                ///3)set the report status as Prefiling
                                                ///

                                                validateElv3InspectionDate1YearCondition(targetEntity, PreImage, feeObject, crmTrace);



                                                // feeObject.ELV3LateFilingFee = numberOfYears * perYearPenalty;
                                            }

                                            #endregion
                                        }



                                        break;
                                    }
                                case (int)ELV3InspectionType.CAT3:
                                case (int)ELV3InspectionType.CAT5:
                                    {
                                        //late filing fee is not applicable for NYCHA OwnerType
                                        if (PreImage.Contains(ELV3InspectionAttributeNames.OwnerType) && PreImage[ELV3InspectionAttributeNames.OwnerType] != null && PreImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                                        {
                                            #region Calculate Late Fee
                                            perMonthPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT3CAT5MonthPenalty);
                                            perYearPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT3CAT5YearPenalty);
                                            if (numberOfDays <= 60)
                                            {
                                                crmTrace.AppendLine(" Number of days <=60 days so No late filing fee charged");
                                                feeObject.ELV3LateFilingFee = 0;
                                            }
                                            else if (numberOfDays > 60 && numberOfMonths <= 12)
                                            {
                                                crmTrace.AppendLine(" Number of days > 60 days  but Number of Months <=12 so  late filing fee will be charged for the months from 61st day. $250 per month per device Maximum 3000");
                                                penalityMonths = CalculateMonthsInBetween(addSixtyDaysToAID, submissionDate);
                                                crmTrace.AppendLine("Total Penality Months from 60th day is " + penalityMonths);
                                                if (penalityMonths == 0)
                                                {
                                                    feeObject.ELV3LateFilingFee = perMonthPenalty;
                                                }
                                                if (penalityMonths > 0)
                                                {
                                                    if (penalityMonths == 12)
                                                    {
                                                        feeObject.ELV3LateFilingFee = RetrieveFee(crmTrace, service, FeeConfigs.elv3ActiveSealedCAT3CAT5YearPenalty);
                                                    }
                                                    else
                                                    {
                                                        feeObject.ELV3LateFilingFee = penalityMonths * perMonthPenalty;
                                                        if (addExtraMonth)//because we have some days left in  AOCFinalSubmissionDateWithOutPenalty
                                                        {
                                                            crmTrace.AppendLine("Adding Extra month");
                                                            feeObject.ELV3LateFilingFee = feeObject.ELV3LateFilingFee + perMonthPenalty;
                                                        }

                                                    }


                                                }


                                            }
                                            else
                                            {
                                                crmTrace.AppendLine(" Number of days > 365 days so This will be considered as NRF In this case set the amount due to zero and set the user filing actions to save Because on save portal will validate the inspection date is valid or not");
                                                ///1) set the filing fee and late filing fee amount due as zero 
                                                ///2)set the user filing actions as save
                                                ///3)set the report status as Prefiling
                                                ///

                                                validateElv3InspectionDate1YearCondition(targetEntity, PreImage, feeObject, crmTrace);

                                                // feeObject.ELV3LateFilingFee = numberOfYears * perYearPenalty;
                                            }

                                            #endregion
                                        }



                                        break;
                                    }


                            }

                            crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV3LateFilingFee);

                            // totalFee = filingFee + lateFilingFee;
                            //  crmTrace.AppendLine("Total fee: " + totalFee);
                            break;
                        }
                    case (int)ElevatorDeviceStatus.HousingAuthority:
                        {
                            crmTrace.AppendLine("No Late Penalities for Housing Hosuing type");

                            crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV3LateFilingFee);

                            //   totalFee = filingFee + lateFilingFee;
                            //  crmTrace.AppendLine("Total fee: " + totalFee);
                            break;
                        }

                }



                #region NRF Fee Calculation (Commenting out-Requirement Changed)


                //switch (inspectionType)
                //{
                //    case (int)ELV3InspectionType.CAT1:
                //        {
                //            ///get all active ELV3 NRF's records and add latefiling fee 
                //            ///get all active ELv29 NRF's records and add latefiling fee (Only for CAT1 filing)
                //            ///

                //            crmTrace.AppendLine("CAT1 NRF Cal Started");
                //            crmTrace.AppendLine("getActiveELV3NRFReports Satrted");
                //            elv3ActiveNRFCollection = SubmitHandler.getActiveELV3NRFReports(PreImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, PreImage, service, crmTrace,false);
                //            crmTrace.AppendLine("getActiveELV3NRFReports Ended " + elv3ActiveNRFCollection.Entities.Count);
                //            crmTrace.AppendLine("getActiveELV29NRFReports Satrted");
                //            elv29ActiveNRFCollection = SubmitHandler.getActiveELV29NRFReports(PreImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, PreImage, service, crmTrace,false);
                //            crmTrace.AppendLine("getActiveELV29NRFReports Ended" + elv29ActiveNRFCollection.Entities.Count);
                //            crmTrace.AppendLine("CAT1 NRF Cal Ended");

                //            break;
                //        }
                //    case (int)ELV3InspectionType.CAT3:
                //    case (int)ELV3InspectionType.CAT5:
                //        {
                //            ///get all active ELV3 NRF's records and add latefiling fee 
                //            crmTrace.AppendLine("CAT3,5 NRF Cal Started");
                //            crmTrace.AppendLine("getActiveELV3NRFReports Satrted");
                //            elv3ActiveNRFCollection = SubmitHandler.getActiveELV3NRFReports(PreImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, PreImage, service, crmTrace,false);
                //            crmTrace.AppendLine("getActiveELV3NRFReports Ended " + elv3ActiveNRFCollection.Entities.Count);
                //            break;

                //        }
                //}

                //if (elv3ActiveNRFCollection != null && elv3ActiveNRFCollection.Entities.Count > 0)
                //{
                //    foreach (Entity elv3ActiveNRF in elv3ActiveNRFCollection.Entities)
                //    {
                //        feeObject.ELV3NRFFee = feeObject.ELV3NRFFee + elv3ActiveNRF.GetAttributeValue<Money>(ELV3InspectionAttributeNames.LateFilingFee).Value;
                //    }
                //}
                //crmTrace.AppendLine("feeObject.ELV3NRFFee  " + feeObject.ELV3NRFFee);
                //if (elv29ActiveNRFCollection != null && elv29ActiveNRFCollection.Entities.Count > 0)
                //{
                //    foreach (Entity elv29ActiveNRF in elv29ActiveNRFCollection.Entities)
                //    {
                //        feeObject.ELV29NRFFee = feeObject.ELV29NRFFee + elv29ActiveNRF.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.Days120LateFilingFee).Value;
                //    }
                //}
                //crmTrace.AppendLine(" feeObject.ELV29NRFFee " + feeObject.ELV29NRFFee);
                #endregion


                crmTrace.AppendLine("Set lateFilingFee : " + feeObject.ELV3LateFilingFee);
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.LateFilingFee, new Money(feeObject.ELV3LateFilingFee));

                crmTrace.AppendLine("Set Filing Fee : " + feeObject.ELV3FilingFee);
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.FilingFee, new Money(feeObject.ELV3FilingFee));

                crmTrace.AppendLine("Set Filing Fee : " + feeObject.ELV3NoGoodCheckFee);
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.noGoodCheckFee, new Money(feeObject.ELV3NoGoodCheckFee));

                //crmTrace.AppendLine("Set ELV3NRFFee Fee : " + feeObject.ELV3NRFFee);
                //targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.ELV3NRFFee, new Money(feeObject.ELV3NRFFee));

                //crmTrace.AppendLine("Set ELV29NRFFee Fee : " + feeObject.ELV29NRFFee);
                //targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.ELV29NRFFee, new Money(feeObject.ELV29NRFFee));


                feeObject.TotalFee = feeObject.ELV3FilingFee + feeObject.ELV3LateFilingFee + feeObject.ELV3NoGoodCheckFee + feeObject.ELV3NRFFee + feeObject.ELV29NRFFee;
                crmTrace.AppendLine("Set Total Fee : " + feeObject.TotalFee);
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.Totalfee, new Money(feeObject.TotalFee));
                feeObject.AmountDue = feeObject.TotalFee - prevAmountPaid;
                crmTrace.AppendLine("Set AmountDue : " + feeObject.AmountDue);
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.AmountDue, new Money(feeObject.AmountDue)); //amountdue=TotalFee-Amount paid
                SharedVariables.Add(ELV3InspectionAttributeNames.sharedAmountDue, feeObject.AmountDue); // this is used in post-operation to create shadow payment history
                SharedVariables.Add(ELV3InspectionAttributeNames.sharedFilingFee, feeObject.ELV3FilingFee);                                                                                 // }
                SharedVariables.Add(ELV3InspectionAttributeNames.sahredLateFilingFee, feeObject.ELV3LateFilingFee);
                SharedVariables.Add(ELV3InspectionAttributeNames.sahredNoGoodCheckFee, feeObject.ELV3NoGoodCheckFee);
                //SharedVariables.Add(ELV3InspectionAttributeNames.sahredELV3NRFFee, feeObject.ELV3NRFFee);
                //SharedVariables.Add(ELV3InspectionAttributeNames.sahredELV29NRFFee, feeObject.ELV29NRFFee);
                //SharedVariables.Add(ELV3InspectionAttributeNames.sahredELV3NRFRecordCount, elv3ActiveNRFCollection.Entities.Count);
                //SharedVariables.Add(ELV3InspectionAttributeNames.sahredELV29NRFRecordCount, elv29ActiveNRFCollection.Entities.Count);


                #endregion
              //  throw new Exception("" + crmTrace.ToString());
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM-Testing Purpose", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3LateFilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                return feeObject;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3LateFilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3LateFilingFee- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return feeObject;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV3LateFilingFee- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-CalculateELV3LateFilingFee- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV3LateFilingFee- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV3LateFilingFee - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }


        }


        /// <summary>
        /// This method is used to Check inspection date is grater than 1 year at the time of initial submission And for resubmission we have to stop for private owner type
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="PreImage"></param>
        /// <param name="feeObject"></param>
        /// <param name="crmTrace"></param>
        public static void validateElv3InspectionDate1YearCondition( Entity targetEntity, Entity PreImage, ElevatorSafetyFeeCalculationobject feeObject, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("Check inspection date is grater than 1 year only in initial submission");
            if(!(PreImage.Contains(ELV3InspectionAttributeNames.RevertedIncompleteSubmission) && PreImage[ELV3InspectionAttributeNames.RevertedIncompleteSubmission] !=null && PreImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.RevertedIncompleteSubmission).Value>0 && PreImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value != (int)OwnerType.Private))//should work only for initial submission so checking revert incomplete has any value. And for resubmission we have to stop for private owner type
            {
                crmTrace.AppendLine("validateElv3InspectionDate1YearCondition Start");
                feeObject.ELV3FilingFee = 0;
                feeObject.ELV3LateFilingFee = 0;
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.Save));
                targetEntity.SetAttributeValue(ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.Prefiling));
                crmTrace.AppendLine("validateElv3InspectionDate1YearCondition End");
            }

        }





        /// <summary>
        /// This Function is Used to Calculate Late Filing Fee for ELV29 and set the amount due,filing fee,latefiling fee
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="DeviceStatus">This is the Device Status Housing,NYCHA,NoJudistriction,Active</param>
        /// <param name="inspectionType">CAT1,CAT3,CAT5,Jump Down,Jump Up,Temp Renewal</param>
        /// <param name="feeObject">Used to set amountdue filing fee,late fee and other fee attributes</param>
        /// <param name="SharedVariables">Used to store latefiling fee such that we can use in creation of Shadow payment history creation in post operation</param>
        public static ElevatorSafetyFeeCalculationobject CalculateELV29LateFilingFee(IOrganizationService service, Entity targetEntity, Entity PreImage, int DeviceStatus, int inspectionType, StringBuilder crmTrace, ElevatorSafetyFeeCalculationobject feeObject, ParameterCollection SharedVariables)
        {
            int numberOfValidDaysFromInitialInspection = 180;
            int numberOfValidMonthsFromInitialInspection = 18;
            DateTime initialInspectionDate = (targetEntity.Contains(ELV29AffirimationAttributeNames.DateOfInitialInspection) && targetEntity[ELV29AffirimationAttributeNames.DateOfInitialInspection] != null ? Convert.ToDateTime(targetEntity.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.DateOfInitialInspection).ToShortDateString()) : Convert.ToDateTime(PreImage.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.DateOfInitialInspection).ToShortDateString())); //Date of Initial Inspection Date ELV3 (either from target or Preimage)
            crmTrace.AppendLine("initialInspectionDate: "+ initialInspectionDate);
            DateTime AOCInspectionDate = (targetEntity.Contains(ELV29AffirimationAttributeNames.AOCInspectionDate) && targetEntity[ELV29AffirimationAttributeNames.AOCInspectionDate] != null ? Convert.ToDateTime(targetEntity.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.AOCInspectionDate).ToShortDateString()) : Convert.ToDateTime(PreImage.GetAttributeValue<DateTime>(ELV29AffirimationAttributeNames.AOCInspectionDate).ToShortDateString())); //Date of AOC Inspection Date ELV3 (either from target or Preimage)
            crmTrace.AppendLine("AOCInspectionDate: " + AOCInspectionDate);
            DateTime AOCsubmissionDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); //Submision Date is today 
            crmTrace.AppendLine("AOCsubmissionDate: " + AOCsubmissionDate);
            DateTime AOCFinalSubmissionDateWithOutPenalty = initialInspectionDate.AddDays(numberOfValidDaysFromInitialInspection); //Add 180 days from initial Inspection date
            crmTrace.AppendLine("AOCFinalSubmissionDateWithOutPenalty: " + AOCFinalSubmissionDateWithOutPenalty);
            DateTime AOCFinalSubmissionDateWithOutPenaltyLastDateOfMonth= Convert.ToDateTime(new DateTime(AOCFinalSubmissionDateWithOutPenalty.Year,
                                    AOCFinalSubmissionDateWithOutPenalty.Month,
                                    DateTime.DaysInMonth(AOCFinalSubmissionDateWithOutPenalty.Year,
                                                         AOCFinalSubmissionDateWithOutPenalty.Month)).ToShortDateString());

            crmTrace.AppendLine("AOCFinalSubmissionDateWithOutPenaltyLastDateOfMonth: " + AOCFinalSubmissionDateWithOutPenaltyLastDateOfMonth);
            bool addExtraMonth = false;
            if(AOCFinalSubmissionDateWithOutPenalty!= AOCFinalSubmissionDateWithOutPenaltyLastDateOfMonth)
            {
                crmTrace.AppendLine("some days left in AOCFinalSubmissionDateWithOutPenalty date month  so add one month extra to calculation");
                addExtraMonth = true;
            }
            
            DateTime AOCFinalSubmissionDateWithPenalty = initialInspectionDate.AddMonths(numberOfValidMonthsFromInitialInspection); //Add 18 Months from initial Inspection date this will act as final submission date with penalty
            crmTrace.AppendLine("AOCFinalSubmissionDateWithPenalty: " + AOCFinalSubmissionDateWithPenalty);
            DateTime greatestDate = new DateTime();
            //penalityMonths will be updated based on device status



            int penalityMonths, numberOfDaysFromInitialInspection, numberOfDaysFromAOCInspection;

            #region Get Amount Paid and Filing Fee from PreImage

            feeObject.ELV29NoGoodCheckFee = PreImage.Contains(ELV29AffirimationAttributeNames.noGoodCheckFee) && PreImage[ELV29AffirimationAttributeNames.noGoodCheckFee] != null && PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.noGoodCheckFee).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.noGoodCheckFee).Value : 0;
            decimal prevAmountPaid = targetEntity.Contains(ELV29AffirimationAttributeNames.AmountPaid) && targetEntity[ELV29AffirimationAttributeNames.AmountPaid] != null  ? targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value : PreImage.Contains(ELV29AffirimationAttributeNames.AmountPaid) && PreImage[ELV29AffirimationAttributeNames.AmountPaid] != null && PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value : 0;
            crmTrace.AppendLine("prevAmountPaid: " + prevAmountPaid);
            decimal prevFilingFee = PreImage.Contains(ELV29AffirimationAttributeNames.FilingFee) && PreImage[ELV29AffirimationAttributeNames.FilingFee] != null && PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.FilingFee).Value > 0 ? PreImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.FilingFee).Value : 0;
            crmTrace.AppendLine("prevFilingFee: " + prevFilingFee);
            #endregion

            try
            {

                #region All Fee exempt and Non-fee exmpt filings have to pay the late filing fee penalities 
                //  if (targetEntity.Contains(ELV3InspectionAttributeNames.OwnerType) && targetEntity[ELV3InspectionAttributeNames.OwnerType] != null && targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value == (int)OwnerType.Private)
                // {

                numberOfDaysFromInitialInspection = Convert.ToInt32((AOCsubmissionDate - initialInspectionDate).TotalDays);
                numberOfDaysFromAOCInspection = Convert.ToInt32((AOCsubmissionDate - AOCInspectionDate).TotalDays);


                crmTrace.AppendLine("numberOfDaysFromInitialInspection: " + numberOfDaysFromInitialInspection);
                crmTrace.AppendLine("numberOfDaysFromAOCInspection: " + numberOfDaysFromAOCInspection);



                decimal maxAOCPenalty = 0;//this field is used to check late filing fee is greater than max penalty
                decimal perMonthPenalty = 0; //this field value will be cahnged for every device status type
                decimal maxpenaltyAfter18Monts = 0; //this field value will be cahnged for every device status type
                //Late filing fee is only for CAT1 AOC . No late filing fee for PVT,QC AOc's
                if (inspectionType == (int)ELV3InspectionType.CAT1)
                {
                    switch (DeviceStatus)
                    {
                        case (int)ElevatorDeviceStatus.NoJurisdiction:
                            {
                                //Late Penalty only for Cat1 
                                if ((GetELV3InspectionType(PreImage, service) == (int)ELV3InspectionType.CAT1 ) &&//CAt1 only  applicable for Late Filing fee
                                    (PreImage.Contains(ELV29AffirimationAttributeNames.OwnerType) && PreImage[ELV29AffirimationAttributeNames.OwnerType] != null && 
                                    PreImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private) //Late Filing Fee is not applicable for fee exempt Owner Type
                                    )
                                {
                                    #region Calculate Late Fee

                                    perMonthPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv29NoJurisdictionCAT1AOCMonthPenalty);
                                    maxpenaltyAfter18Monts = RetrieveFee(crmTrace, service, FeeConfigs.elv29NoJurisdictionCAT1AOC18MonthsPenalty);
                                    if (numberOfDaysFromInitialInspection <= numberOfValidDaysFromInitialInspection && numberOfDaysFromAOCInspection <= numberOfValidDaysFromInitialInspection && AOCsubmissionDate <= AOCFinalSubmissionDateWithOutPenalty && AOCInspectionDate <= AOCFinalSubmissionDateWithOutPenalty) //date of AOC Submission,date of AOCInspection<180 days from initial inspection 
                                    {
                                        crmTrace.AppendLine(" date of AOC Submission,date of AOCInspection<180 days from initial inspection ");
                                        feeObject.ELV29LateFilingFee = 0;
                                    }

                                    else
                                    {
                                        ///either submission date or AOC Inspection Date is  greater than AOCFinalSubmissionDateWithOutPenalty
                                        ///then find which is greatest date among AOC Inspection Date and AOC Submission Date
                                        ///Considering the greatest date calculate Late Filing Fee
                                        ///

                                        greatestDate = (AOCsubmissionDate > AOCInspectionDate) ? AOCsubmissionDate : AOCInspectionDate;
                                        crmTrace.AppendLine(" greatestDate among AOC submission and AOC Inspection is: " + greatestDate);

                                        ///Check if greatestDate is Greater Than AOCFinalSubmissionDateWithPenalty if yes then consider it as NRF and Charge NRF amount else calculate the number of months from AOCFinalSubmissionDateWithOutPenalty to greatest date and charge accoring to months

                                        if (greatestDate > AOCFinalSubmissionDateWithPenalty)
                                        {
                                            //Charge NRF Fee 
                                            penalityMonths = CalculateMonthsInBetween(AOCFinalSubmissionDateWithOutPenalty, greatestDate);
                                            feeObject.ELV29LateFilingFee = maxpenaltyAfter18Monts;//Based on BRD
                                        }
                                        else
                                        {
                                            penalityMonths = CalculateMonthsInBetween(AOCFinalSubmissionDateWithOutPenalty, greatestDate);
                                            crmTrace.AppendLine("Total Penality Months from 60th day is " + penalityMonths);
                                            if (penalityMonths == 0)//that means user exceeded 180 days but submitted in same month eg: AOCFinalSubmissionDateWithOutPenalty= Jan 1st,2018 ,greatest date= Jan 15th,2018
                                            {
                                                //consider this as 1 month delay and charge $50
                                                feeObject.ELV29LateFilingFee = perMonthPenalty;
                                            }
                                            else
                                            {
                                                feeObject.ELV29LateFilingFee = penalityMonths * perMonthPenalty;
                                                if(addExtraMonth)//because we have some days left in  AOCFinalSubmissionDateWithOutPenalty
                                                {
                                                    crmTrace.AppendLine("Adding Extra month");
                                                    feeObject.ELV29LateFilingFee = feeObject.ELV29LateFilingFee + perMonthPenalty;
                                                }
                                                maxAOCPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv29NoJurisdictionCAT1AOCMaxYearPenalty);
                                                if (feeObject.ELV29LateFilingFee > maxAOCPenalty)
                                                {
                                                    feeObject.ELV29LateFilingFee = maxAOCPenalty;
                                                }
                                            }
                                            crmTrace.AppendLine("feeObject.ELV29LateFilingFee " + feeObject.ELV29LateFilingFee);
                                        }






                                    }


                                    #endregion
                                }




                                crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV3LateFilingFee);

                                break;
                            }
                        case (int)ElevatorDeviceStatus.Active:
                        case (int)ElevatorDeviceStatus.Sealed:
                            {
                                // //Late Penalty only for Cat1

                              
                                if ((GetELV3InspectionType(PreImage, service) == (int)ELV3InspectionType.CAT1) &&//CAT1 only applicable for Late Filing fee
                                    (PreImage.Contains(ELV29AffirimationAttributeNames.OwnerType) && PreImage[ELV29AffirimationAttributeNames.OwnerType] != null &&
                                    PreImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.OwnerType).Value == (int)OwnerType.Private) //Late Filing Fee is not applicable for fee exempt Owner Type
                                    )
                                {
                                    #region Calculate Late Fee

                                    perMonthPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv29ActiveSealedCAT1AOCMonthPenalty);
                                    maxpenaltyAfter18Monts = RetrieveFee(crmTrace, service, FeeConfigs.elv29ActiveSealedCAT1AOC18MonthsPenalty);
                                    if (numberOfDaysFromInitialInspection <= numberOfValidDaysFromInitialInspection && numberOfDaysFromAOCInspection <= numberOfValidDaysFromInitialInspection && AOCsubmissionDate <= AOCFinalSubmissionDateWithOutPenalty && AOCInspectionDate <= AOCFinalSubmissionDateWithOutPenalty) //date of AOC Submission,date of AOCInspection<180 days from initial inspection 
                                    {
                                        crmTrace.AppendLine(" date of AOC Submission,date of AOCInspection<180 days from initial inspection ");
                                        feeObject.ELV29LateFilingFee = 0;
                                    }

                                    else
                                    {
                                        ///either submission date or AOC Inspection Date is  greater than AOCFinalSubmissionDateWithOutPenalty
                                        ///then find which is greatest date among AOC Inspection Date and AOC Submission Date
                                        ///Considering the greatest date calculate Late Filing Fee
                                        ///

                                        greatestDate = (AOCsubmissionDate > AOCInspectionDate) ? AOCsubmissionDate : AOCInspectionDate;
                                        crmTrace.AppendLine(" greatestDate among AOC submission and AOC Inspection is: " + greatestDate);

                                        ///Check if greatestDate is Greater Than AOCFinalSubmissionDateWithPenalty if yes then consider it as NRF and Charge NRF amount else calculate the number of months from AOCFinalSubmissionDateWithOutPenalty to greatest date and charge accoring to months

                                        if (greatestDate > AOCFinalSubmissionDateWithPenalty)
                                        {
                                            //Charge NRF Fee 
                                            penalityMonths = CalculateMonthsInBetween(AOCFinalSubmissionDateWithOutPenalty, greatestDate);
                                            feeObject.ELV29LateFilingFee = maxpenaltyAfter18Monts;//Based on BRD
                                        }
                                        else
                                        {
                                            penalityMonths = CalculateMonthsInBetween(AOCFinalSubmissionDateWithOutPenalty, greatestDate);
                                            crmTrace.AppendLine("Total Penality Months from 60th day is " + penalityMonths);
                                            if (penalityMonths == 0)//that means user exceeded 180 days but submitted in same month eg: AOCFinalSubmissionDateWithOutPenalty= Jan 1st,2018 ,greatest date= Jan 15th,2018
                                            {
                                                //consider this as 1 month delay and charge $50
                                                feeObject.ELV29LateFilingFee = perMonthPenalty;
                                            }
                                            else
                                            {
                                                feeObject.ELV29LateFilingFee = penalityMonths * perMonthPenalty;
                                                if (addExtraMonth)//because we have some days left in  AOCFinalSubmissionDateWithOutPenalty
                                                {
                                                    crmTrace.AppendLine("Adding Extra month");
                                                    feeObject.ELV29LateFilingFee = feeObject.ELV29LateFilingFee + perMonthPenalty;
                                                }
                                                maxAOCPenalty = RetrieveFee(crmTrace, service, FeeConfigs.elv29ActiveSealedCAT1AOCMaxYearPenalty);
                                                crmTrace.AppendLine("maxAOCPenalty" + maxAOCPenalty);
                                                if (feeObject.ELV29LateFilingFee > maxAOCPenalty)
                                                {
                                                    feeObject.ELV29LateFilingFee = maxAOCPenalty;
                                                }
                                            }
                                            crmTrace.AppendLine("feeObject.ELV29LateFilingFee " + feeObject.ELV29LateFilingFee);
                                        }






                                    }


                                    #endregion
                                }



                                crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV29LateFilingFee);


                                break;
                            }
                        case (int)ElevatorDeviceStatus.HousingAuthority:
                            {
                                crmTrace.AppendLine("No Late Penalities for Housing Hosuing type");

                                crmTrace.AppendLine("Late Filing Fees: " + feeObject.ELV29LateFilingFee);


                                break;
                            }

                    }
                }

                crmTrace.AppendLine("Set lateFilingFee : " + feeObject.ELV29LateFilingFee);
                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.Days120LateFilingFee, new Money(feeObject.ELV29LateFilingFee));

                crmTrace.AppendLine("Set Filing Fee : " + feeObject.ELV3FilingFee);
                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.FilingFee, new Money(feeObject.ELV29FilingFee));

                crmTrace.AppendLine("Set ELV29NoGoodCheckFee Fee : " + feeObject.ELV29NoGoodCheckFee);
                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.noGoodCheckFee, new Money(feeObject.ELV29NoGoodCheckFee));

                feeObject.TotalFee = feeObject.ELV29FilingFee + feeObject.ELV29LateFilingFee + feeObject.ELV29NoGoodCheckFee;
                crmTrace.AppendLine("Set Total Fee : " + feeObject.TotalFee);
                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.TotalFees, new Money(feeObject.TotalFee));
                feeObject.AmountDue = feeObject.TotalFee - prevAmountPaid;
                crmTrace.AppendLine("Set AmountDue : " + feeObject.AmountDue);
               
                targetEntity.SetAttributeValue(ELV29AffirimationAttributeNames.AmountDue, new Money(feeObject.AmountDue)); //amountdue=TotalFee-Amount paid
                SharedVariables.Add(ELV29AffirimationAttributeNames.sharedAmountDue, feeObject.AmountDue); // this is used in post-operation to create shadow payment history
                SharedVariables.Add(ELV29AffirimationAttributeNames.sharedFilingFee, feeObject.ELV29FilingFee);                                                                                 // }
                SharedVariables.Add(ELV29AffirimationAttributeNames.sahredLateFilingFee, feeObject.ELV29LateFilingFee);
                SharedVariables.Add(ELV29AffirimationAttributeNames.sahredNoGoodCheckFee, feeObject.ELV29NoGoodCheckFee);
                SharedVariables.Add(ELV29AffirimationAttributeNames.sahredGreatestDate, greatestDate.ToShortDateString()); //this is used to identify late filing fee or Failure to File Fee
                SharedVariables.Add(ELV29AffirimationAttributeNames.sahredAOCFinalSubmissionDateWithPenalty, AOCFinalSubmissionDateWithPenalty.ToShortDateString());//this is used to identify late filing fee or Failure to File Fee

                #endregion
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29LateFilingFee - Execute Testing Purpose", null, crmTrace.ToString(), null, null);
                return feeObject;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29LateFilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29LateFilingFee- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return feeObject;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV29LateFilingFee- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-CalculateELV29LateFilingFee- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CalculateELV29LateFilingFee- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CalculateELV29LateFilingFee - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return feeObject;

            }


        }

        /// <summary>
        /// Based on Formula name fetches the fee and returns the fee
        /// </summary>
        /// <param name="crmTrace"></param>
        /// <param name="service"></param>
        /// <param name="formulaeName"></param>
        /// <returns></returns>
        public static decimal RetrieveFee(StringBuilder crmTrace, IOrganizationService service, string formulaeName)
        {
            crmTrace.AppendLine("Start: retrieve fee..");
            ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });

            EntityCollection collection= RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName,
                  new string[] { FeeCalculationConfigurationAttributeNames.Tier1CostFee,
                        FeeCalculationConfigurationAttributeNames.CheckBounce,  
                       }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
            crmTrace.AppendLine("collection.Entities.Count" + collection.Entities.Count);
            if (collection!=null && collection.Entities.Count>0)
            {
                if(collection[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee) && collection[0][FeeCalculationConfigurationAttributeNames.Tier1CostFee]!=null)
                {
                    return (collection[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee));
                }
            }
            return 0;

        }


        /// <summary>
        /// Calculate the difference between dates and return Number of months as output
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        //private static int CalculateMonthsInBetween(DateTime from, DateTime to)
        //{
        //    //int monthDiff = Math.Abs((to.Year * 12 + (to.Month - 1)) - (from.Year * 12 + (from.Month - 1)));

        //    //if (from.AddMonths(monthDiff) >= to || to.Day <= from.Day)
        //    //{
        //    //    monthDiff = monthDiff - 1;
        //    //}

        //    //return monthDiff;
        //    int monthDiff = 0;
        //    if (to.Day <= from.Day)
        //        monthDiff = ((to.Year - from.Year) * 12) + to.Month - from.Month;
        //    else
        //        monthDiff = ((to.Year - from.Year) * 12) + to.Month - from.Month + 1;

        //    return monthDiff;
        //}

        /// <summary>
        /// Calculate the difference between dates and return Number of months as output
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        private static int CalculateMonthsInBetween(DateTime from, DateTime to)
        {
            //int monthDiff = Math.Abs((to.Year * 12 + (to.Month - 1)) - (from.Year * 12 + (from.Month - 1)));

            //if (from.AddMonths(monthDiff) >= to || to.Day <= from.Day)
            //{
            //    monthDiff = monthDiff - 1;
            //}

            //return monthDiff;
            int monthDiff = 0;
            
            monthDiff = ((to.Year - from.Year) * 12) + to.Month - from.Month;
           

            return monthDiff;
        }


        /// <summary>
        /// This Function is used to Create Shadow payment Histories for all the entites in Elevators Safety Project.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="feeType"></param>
        /// <param name="fee"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Guid CreateShadowPaymentHistory(IOrganizationService service, Entity targetEntity, int feeType, Money fee, StringBuilder crmTrace)
        {
            //As Requirements are not Complete Initially setting Filing Fee to $40 for all cat
            Guid SPHGuid = new Guid();
            try
            {
                Entity shadowPaymentRecord = new Entity(ShadowPaymentHistoryAttributeNames.EntityLogicalName);
                // Set Source Channel as Safety
                crmTrace.AppendLine("Set Source Channel as Safety");
                shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.SourceChannel, new OptionSetValue(2));
                //Set Name
                crmTrace.AppendLine("Set Name");
                shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.Name, "Sample");
                // Set ELV3 lookup
                crmTrace.AppendLine("Set related form lookup");

                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    crmTrace.AppendLine("Set related form ELV3Lookup");
                    shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.ELV3Lookup, targetEntity.ToEntityReference());
                }
                else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    crmTrace.AppendLine("Set related form ELV29Lookup");
                    shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.ELV29Lookup, targetEntity.ToEntityReference());
                }



                // Set feeType
                crmTrace.AppendLine("Set Fee Type Option Set");
                shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.FeeType, new OptionSetValue(feeType));
                // Set Total Fee                    
                crmTrace.AppendLine("Set Totle Fee");
                shadowPaymentRecord.Attributes.Add(ShadowPaymentHistoryAttributeNames.TotalFees, fee);
                SPHGuid = service.Create(shadowPaymentRecord);
                crmTrace.AppendLine("Shadow Payment History Record Created");
                return SPHGuid;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CreateShadowPaymentHistory - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CreateShadowPaymentHistory- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return new Guid();
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CreateShadowPaymentHistory- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-CreateShadowPaymentHistory- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return new Guid();

            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-CreateShadowPaymentHistory- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-CreateShadowPaymentHistory - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return new Guid();
            }


        }

        /// <summary>
        /// This Function is used to Clear the statements and signature fields
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="fields"></param>
        /// 
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static void clearStatementAndSignaturesFields(IOrganizationService service, Entity targetEntity, string[]fields, StringBuilder crmTrace)
        {
           
           
            try
            {
               foreach(string field in fields)
                {
                    crmTrace.AppendLine("Field Name" + field);
                    targetEntity.SetAttributeValue(field, null);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-clearStatementAndSignaturesFields - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-clearStatementAndSignaturesFields- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                
            }
            catch (TimeoutException ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-clearStatementAndSignaturesFields- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ELV3FeeCalculationHandler-clearStatementAndSignaturesFields- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
               

            }
            catch (Exception ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ELV3FeeCalculationHandler-clearStatementAndSignaturesFields- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ELV3FeeCalculationHandler-clearStatementAndSignaturesFields - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                
            }


        }

        /// <summary>
        /// this function will be called only in adjustment scenario
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="Permit"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Guid CreatePaymentHistoryRecord(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                Entity PaymentHistoryRecord = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                // Set Source Channel as Build
                crmTrace.AppendLine("Set Source Channel as Build");
                PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.SourceChannel, new OptionSetValue(1));

                crmTrace.AppendLine("create Payment History  - start");
                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.Name, targetEntity.GetAttributeValue<string>(ELV3InspectionAttributeNames.Name));

                    // Set ElevatorApplication lookup
                    crmTrace.AppendLine("Set ElevatorApplication lookup");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.ELV3Lookup, targetEntity.ToEntityReference());





                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set - Elevator");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.ElevatorsSafetyElv3FilingFee));

                    //adjustment case

                    crmTrace.AppendLine("Set Total Fee - Adjustment");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid));



                }

                crmTrace.AppendLine("creating Payment History");
                Guid paymenthistory = service.Create(PaymentHistoryRecord);
                crmTrace.AppendLine("create Payment History Record - End");

                return paymenthistory;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            #endregion
        }

        /// <summary>
        /// This method is used to create the transaction Histories based on the Elevator Safety entity and fee calcultion (eg:filing fe, civil penality,late filing fee)
        /// </summary>
        /// <param name="SharedVariables"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <param name="InspectionType">Decides the Transaction code for both ELV3 and AOC</param>
        /// <param name="feeObject"></param>

        public static void CreateElevatorSafetyTransactionHistoryRecords(Entity targetEntity, Guid shadowPaymentHistoryId, IOrganizationService service, StringBuilder crmTrace, Entity preImage, int InspectionType, ParameterCollection SharedVariables)
        {
            decimal amountDue = 0, preImageFilingFee = 0, targetFilingFee = 0, diffFilingFee = 0, preImageLateFilingFee = 0, targetLateFilingFee = 0, diffLateFilingFee = 0, preImageElv3NRFFee = 0, targetElv3NRFFee = 0, diffElv3NRFFee = 0, preImageElv29NRFFee = 0, targetElv29NRFFee = 0, diffElv29NRFFee = 0, numberOfNGC = 0, NRFAmount = 0;
            try
            {

                #region ELV3 Transaction Histories  Creation

                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {

                    ///Transaction codes will be created based on Inspection Type ,Filing Fee,Late Filing Fee,Fail to file(Requirement not given yet)
                    ///
                    #region Main Logic for  Creation of TH
                    int reportStatus = (targetEntity.Contains(ELV3InspectionAttributeNames.ReportStatus) && targetEntity[ELV3InspectionAttributeNames.ReportStatus] != null
                            && (targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value > 0)) ? targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value : preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value;
                    int ownerType = preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.OwnerType).Value;
                    decimal amountPaid = (preImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && preImage[ELV3InspectionAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0) ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value : 0;

                    //First Check  is it Adjustment Scenario or normal Scenario
                    //Adjustment Scenario: report status-accepted or ACCEPTED DEFECTS, Owner type =NYCHA, Amount paid>0
                    #region ELV3 Adjustment  Region
                    if ((reportStatus == (int)ELV3ReportStatus.Accepted || reportStatus == (int)ELV3ReportStatus.AcceptedDefects) &&
                        (ownerType == (int)OwnerType.NYCHA) &&
                        (amountPaid > 0)
                        )
                    {
                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                        PHtransactionHistoryHelper(ElevatorSafetyTransactionCodes.OVERAGE_PAYMENT, amountPaid, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                    }
                    #endregion
                    #region Normal Cases
                    else
                    {
                        if ((targetEntity.Contains(ELV3InspectionAttributeNames.AmountDue) && targetEntity[ELV3InspectionAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value > 0))
                        {
                            crmTrace.AppendLine("Filing Has Amount Due");
                            if (InspectionType > 0)
                            {
                                crmTrace.AppendLine("Check the Inspection Type for creating Transaction Code");

                                #region User Paid Some Amount i.e. Amount Paid>0 This Block will execute In Resubmission cases if we have civil penaltes or filing fee due

                                ///if targetFilingFee > preImageFilingFee that means we have filing fee added so we have to create Filing Fee TH.
                                ///add only difference of target and preimage filing fees to Filing Fee TH
                                ///Same above rule applies to Latefiling fee
                                ///if still there is amount due then add it to no good check fee
                                ///

                                if (preImage.Contains(ELV3InspectionAttributeNames.AmountPaid) && preImage[ELV3InspectionAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value > 0)
                                {

                                    #region Variable Set/Get
                                    amountDue = targetEntity.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value;
                                    crmTrace.AppendLine("target entity amount due:" + amountDue);
                                    preImageFilingFee = preImage.Contains(ELV3InspectionAttributeNames.FilingFee) && preImage[ELV3InspectionAttributeNames.FilingFee] != null ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.FilingFee).Value : 0;
                                    crmTrace.AppendLine("preImageFilingFee:" + preImageFilingFee);
                                    targetFilingFee = (decimal)SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee];
                                    crmTrace.AppendLine("targetFilingFee:" + targetFilingFee);
                                    preImageLateFilingFee = preImage.Contains(ELV3InspectionAttributeNames.LateFilingFee) && preImage[ELV3InspectionAttributeNames.LateFilingFee] != null ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.LateFilingFee).Value : 0;
                                    crmTrace.AppendLine("preImageLateFilingFee:" + preImageLateFilingFee);
                                    targetLateFilingFee = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee];
                                    crmTrace.AppendLine("targetLateFilingFee:" + targetFilingFee);

                                    //preImageElv3NRFFee = preImage.Contains(ELV3InspectionAttributeNames.ELV3NRFFee) && preImage[ELV3InspectionAttributeNames.ELV3NRFFee] != null ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.ELV3NRFFee).Value : 0;
                                    //crmTrace.AppendLine("preImageElv3NRFFee:" + preImageElv3NRFFee);
                                    //targetElv3NRFFee = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee];
                                    //crmTrace.AppendLine("targetElv3NRFFee:" + targetElv3NRFFee);
                                    //preImageElv29NRFFee = preImage.Contains(ELV3InspectionAttributeNames.ELV29NRFFee) && preImage[ELV3InspectionAttributeNames.ELV29NRFFee] != null ? preImage.GetAttributeValue<Money>(ELV3InspectionAttributeNames.ELV29NRFFee).Value : 0;
                                    //crmTrace.AppendLine("preImageElv29NRFFee:" + preImageElv29NRFFee);
                                    //targetElv29NRFFee = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFFee];
                                    //crmTrace.AppendLine("targetLateFilingFee:" + targetElv29NRFFee);
                                    #endregion

                                    #region Calculation of Differences between preimage and target

                                    if (targetFilingFee > preImageFilingFee)
                                    {
                                        diffFilingFee = targetFilingFee - preImageFilingFee;
                                        amountDue = amountDue - diffFilingFee;
                                        crmTrace.AppendLine("diffFilingFee:" + diffFilingFee);
                                    }
                                    if (targetLateFilingFee > preImageLateFilingFee)
                                    {
                                        diffLateFilingFee = targetLateFilingFee - preImageLateFilingFee;
                                        amountDue = amountDue - diffLateFilingFee;
                                        crmTrace.AppendLine("diffLateFilingFee:" + diffLateFilingFee);
                                    }
                                    //if (targetElv3NRFFee > preImageElv3NRFFee)
                                    //{
                                    //    diffElv3NRFFee = targetElv3NRFFee - preImageElv3NRFFee;
                                    //    amountDue = amountDue - diffElv3NRFFee;
                                    //    crmTrace.AppendLine("diffElv3NRFFee:" + diffElv3NRFFee);
                                    //}
                                    //if (targetElv29NRFFee > preImageElv29NRFFee)
                                    //{
                                    //    diffElv29NRFFee = targetElv29NRFFee - preImageElv29NRFFee;
                                    //    amountDue = amountDue - diffElv29NRFFee;
                                    //    crmTrace.AppendLine("diffElv29NRFFee:" + diffElv29NRFFee);
                                    //}
                                    #endregion

                                    #region Filing Fee TH
                                    crmTrace.AppendLine("check whether we have to add Filing fee TH");
                                    if (diffFilingFee > 0) //check filing fee condition first then go for late filing fee
                                    {
                                        crmTrace.AppendLine("Add Filing fee TH start amount paid>0");
                                        //this means we have to add filing fee TH
                                        switch (InspectionType)
                                        {
                                            case (int)ELV3InspectionType.CAT1:
                                                {

                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyELV3CAT1FilingFee, diffFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");

                                                    break;
                                                }
                                            case (int)ELV3InspectionType.CAT3:
                                            case (int)ELV3InspectionType.CAT5:
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyELV3CAT3CAT5FilingFee, diffFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    break;
                                                }
                                        }

                                    }
                                    #endregion

                                    #region Late Filing fee TH
                                    if (diffLateFilingFee > 0) //Late Filing Fee
                                    {
                                        crmTrace.AppendLine("Add Late Filing fee TH start amount paid>0");
                                        switch (InspectionType)
                                        {
                                            case (int)ELV3InspectionType.CAT1:
                                                {

                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT1LateFilingFee, diffLateFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");






                                                    break;
                                                }
                                            case (int)ELV3InspectionType.CAT3:
                                            case (int)ELV3InspectionType.CAT5:
                                                {
                                                    ///for CAT3,CAT5 there is no AOC failure to file
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT3CAT5LateFee, diffLateFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");



                                                    break;
                                                }
                                        }
                                    }
                                    #endregion

                                    #region ELV3 NRF's for all inspection type but separate Transaction codes

                                    if (diffElv3NRFFee > 0)
                                    {
                                        /// Create ELV3 NRF's count failure to File TH 
                                        /// divide elv3NRF amount/NRFCount and then loop and add those many failure to file TH's 
                                        /// 
                                        NRFAmount = diffElv3NRFFee / (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount];

                                        for (int i = 0; i < (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount]; i++)
                                        {
                                            if (InspectionType == (int)ELV3InspectionType.CAT1)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT1FailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }
                                            else if (InspectionType == (int)ELV3InspectionType.CAT3 || InspectionType == (int)ELV3InspectionType.CAT5)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT3CAT5FailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }

                                        }

                                    }

                                    #endregion

                                    #region ELV29 NRF's only for CAT1

                                    if (diffElv29NRFFee > 0)
                                    {
                                        /// Create ELV3 NRF's count failure to File TH 
                                        /// divide elv3NRF amount/NRFCount and then loop and add those many failure to file TH's 
                                        /// 
                                        NRFAmount = diffElv29NRFFee / (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFRecordCount];

                                        for (int i = 0; i < (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount]; i++)
                                        {
                                            if (InspectionType == (int)ELV3InspectionType.CAT1)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOFFailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }

                                        }

                                    }

                                    #endregion

                                    #region NGC TH
                                    if (amountDue > 0)//Still amount due >0 then it is either No good check 
                                    {
                                        #region ELV3 No Good Check TH


                                        /// No Good Check TH should always hold only $20 (Business Rule)
                                        /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                        /// 

                                        numberOfNGC = amountDue / 20;

                                        for (int i = 0; i < numberOfNGC; i++)
                                        {
                                            crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                            transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                            crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                        }



                                        #endregion
                                    }
                                    #endregion


                                }

                                #endregion

                                #region user Did Not Pay Any amount i.e. Amount Paid=0. This Block will execute in the first submission  or when fee exempt filing changed to non fee exempt or paying penalty fee for No good check 
                                else
                                {
                                    switch (InspectionType)
                                    {


                                        case (int)ELV3InspectionType.CAT1:
                                            {
                                                #region ELV3 CAT1 Filing Fee TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sharedFilingFee) && SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee] > 0)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyELV3CAT1FilingFee, (decimal)SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                                #endregion

                                                #region ELV3 CAT1 Late Filing Fee TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredLateFilingFee) && SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee] > 0)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT1LateFilingFee, (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                                #endregion

                                                #region ELV3 No Good Check TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredNoGoodCheckFee) && SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] > 0)
                                                {
                                                    /// No Good Check TH should always hold only $20 (Business Rule)
                                                    /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                                    /// 
                                                    numberOfNGC = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] / 20;

                                                    for (int i = 0; i < numberOfNGC; i++)
                                                    {
                                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    }

                                                }

                                                #endregion

                                                #region ELV3 NRF's

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredELV3NRFFee) && SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] > 0)
                                                {
                                                    /// Create ELV3 NRF's count failure to File TH 
                                                    /// divide elv3NRF amount/NRFCount and then loop and add those many failure to file TH's 
                                                    /// 
                                                    crmTrace.AppendLine("ELV3 NRFs Entered");
                                                    NRFAmount = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] / (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount];
                                                    crmTrace.AppendLine("NRFAmount" + NRFAmount);
                                                    for (int i = 0; i < (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount]; i++)
                                                    {
                                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT1FailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    }

                                                }

                                                #endregion

                                                #region ELV29 NRF's

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredELV29NRFFee) && SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFFee] > 0)
                                                {
                                                    /// Create ELV3 NRF's count failure to File TH 
                                                    /// divide elv3NRF amount/NRFCount and then loop and add those many failure to file TH's 
                                                    /// 
                                                    NRFAmount = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFFee] / (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV29NRFRecordCount];

                                                    for (int i = 0; i < (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount]; i++)
                                                    {
                                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOFFailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    }

                                                }

                                                #endregion

                                                break;
                                            }
                                        //Both CAT3 and CAT5 shares same Transaction codes
                                        case (int)ELV3InspectionType.CAT3:
                                        case (int)ELV3InspectionType.CAT5:
                                            {
                                                #region ELV3 CAT3,CAT5 Filing Fee TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sharedFilingFee) && SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee] > 0)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyELV3CAT3CAT5FilingFee, (decimal)SharedVariables[ELV3InspectionAttributeNames.sharedFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                                #endregion

                                                #region ELV3 CAT3,CAT5 Late Filing Fee TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredLateFilingFee) && SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee] > 0)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT3CAT5LateFee, (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredLateFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                                #endregion

                                                #region ELV3 No Good Check TH

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredNoGoodCheckFee) && SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] > 0)
                                                {
                                                    /// No Good Check TH should always hold only $20 (Business Rule)
                                                    /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                                    /// 
                                                    numberOfNGC = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredNoGoodCheckFee] / 20;

                                                    for (int i = 0; i < numberOfNGC; i++)
                                                    {
                                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    }

                                                }

                                                #endregion

                                                #region ELV3 NRF's

                                                if (SharedVariables.Contains(ELV3InspectionAttributeNames.sahredELV3NRFFee) && SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] != null && (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] > 0)
                                                {
                                                    /// Create ELV3 NRF's count failure to File TH 
                                                    /// divide elv3NRF amount/NRFCount and then loop and add those many failure to file TH's 
                                                    /// 
                                                    NRFAmount = (decimal)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFFee] / (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount];

                                                    for (int i = 0; i < (int)SharedVariables[ELV3InspectionAttributeNames.sahredELV3NRFRecordCount]; i++)
                                                    {
                                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyCAT3CAT5FailtoFile, NRFAmount, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                    }

                                                }

                                                #endregion

                                                break;
                                            }


                                    }
                                }
                                #endregion

                            }

                        }
                    }
                    #endregion




                    #endregion




                }

                #endregion

                #region ELV29 Transaction Histories  Creation
                else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {

                    ///Transaction codes will be created based on Inspection Type ,Filing Fee,Late Filing Fee,Fail to file(Requirement not given yet)
                    ///
                    #region Main Logic for  Creation of TH
                    if ((targetEntity.Contains(ELV29AffirimationAttributeNames.AmountDue) && targetEntity[ELV29AffirimationAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value > 0))
                    {
                        crmTrace.AppendLine("Filing Has Amount Due"); //have to get the inspection type of ELV3 because PVT/QC has different transaction codes
                        if (InspectionType > 0)
                        {
                            #region User Paid Some Amount i.e. Amount Paid>0. This Block will execute In Resubmission cases if we have civil penaltes or filing fee due
                            ///if targetFilingFee > preImageFilingFee that means we have filing fee added so we have to create Filing Fee TH.
                            ///add only difference of target and preimage filing fees to Filing Fee TH
                            ///then subtract that difference  from amount due. 
                            ///same rule applies to Late Filing Fee
                            /// if still amount due>0 all the remaining amount due is NGC or NRF
                            if (preImage.Contains(ELV29AffirimationAttributeNames.AmountPaid) && preImage[ELV29AffirimationAttributeNames.AmountPaid] != null && preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value > 0)
                            {
                                #region Variables Set/Get
                                amountDue = targetEntity.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value;
                                crmTrace.AppendLine("target entity amount due:" + amountDue);
                                preImageFilingFee = preImage.Contains(ELV29AffirimationAttributeNames.FilingFee) && preImage[ELV29AffirimationAttributeNames.FilingFee] != null ? preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.FilingFee).Value : 0;
                                crmTrace.AppendLine("preImageFilingFee:" + preImageFilingFee);
                                targetFilingFee = (decimal)SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee];
                                crmTrace.AppendLine("targetFilingFee:" + targetFilingFee);
                                preImageLateFilingFee = preImage.Contains(ELV29AffirimationAttributeNames.Days120LateFilingFee) && preImage[ELV29AffirimationAttributeNames.Days120LateFilingFee] != null ? preImage.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.Days120LateFilingFee).Value : 0;
                                crmTrace.AppendLine("preImageLateFilingFee:" + preImageLateFilingFee);
                                targetLateFilingFee = (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee];
                                crmTrace.AppendLine("targetLateFilingFee:" + targetFilingFee);
                                #endregion

                                #region Difference Calculations
                                if (targetFilingFee > preImageFilingFee)
                                {
                                    diffFilingFee = targetFilingFee - preImageFilingFee;
                                    amountDue = amountDue - diffFilingFee;
                                    crmTrace.AppendLine("diffFilingFee:" + diffFilingFee);
                                }

                                if (targetLateFilingFee > preImageLateFilingFee)
                                {
                                    diffLateFilingFee = targetLateFilingFee - preImageLateFilingFee;
                                    amountDue = amountDue - diffLateFilingFee;
                                    crmTrace.AppendLine("diffLateFilingFee:" + diffLateFilingFee);
                                }
                                #endregion

                                #region AOC Filing Fee TH
                                crmTrace.AppendLine("check whether we have to add Filing fee TH");
                                if (diffFilingFee > 0) //check filing fee condition first then go for late filing fee
                                {
                                    crmTrace.AppendLine("Add Filing fee TH start amount paid>0");
                                    //this means we have to add filing fee TH
                                    switch (InspectionType)
                                    {
                                        case (int)ELV3InspectionType.CAT1:
                                            {

                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOCFilingFee, diffFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");

                                                break;
                                            }
                                        case (int)ELV3InspectionType.PVTInspection:
                                       // case (int)ELV3InspectionType.QCInspection:
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyPVTAOCFilingFee, diffFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                break;
                                            }
                                    }

                                }
                                #endregion

                                #region AOC Late Filing TH
                                if (diffLateFilingFee > 0) //we already set the amount due in starting of this block
                                {


                                    #region Late Fee (submission date greater than 180 days but less than 18 months of initial Inspection)

                                    crmTrace.AppendLine("Add Late Filing fee TH start amount paid>0");
                                    switch (InspectionType)
                                    {
                                        case (int)ELV3InspectionType.CAT1:
                                            {

                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOFLateFee, diffLateFilingFee, targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");

                                                break;
                                            }
                                        case (int)ELV3InspectionType.PVTInspection:
                                        case (int)ELV3InspectionType.QCInspection:
                                            {
                                                //No Late Filing fee  as of now

                                                break;
                                            }
                                    }

                                    #endregion



                                }

                                #endregion

                                #region AOC NGC TH
                                if (amountDue > 0)//Still amount due >0 then it is either No good check or NRF fee(as of now NRF is not implemented otherwise first store NRF fee on field then check NGC) 
                                {
                                    #region ELV29 No Good Check TH


                                    /// No Good Check TH should always hold only $20 (Business Rule)
                                    /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                    /// 
                                    numberOfNGC = amountDue / 20;

                                    for (int i = 0; i < numberOfNGC; i++)
                                    {
                                        crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                        transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                        crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                    }



                                    #endregion
                                }
                                #endregion

                            }

                            #endregion

                            #region user Did Not Pay Any amount i.e. Amount Paid=0. This Block will execute in the first submission  or when fee exempt filing changed to non fee exempt. 
                            else
                            {
                                crmTrace.AppendLine("Check the Inspection Type for creating Transaction Code");
                                switch (InspectionType)
                                {
                                    case (int)ELV3InspectionType.CAT1:
                                        {
                                            #region AOC Filing Fee TH

                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sharedFilingFee) && SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee] > 0)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOCFilingFee, (decimal)SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }

                                            #endregion

                                            #region AOC Late Filing Fee TH

                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sahredLateFilingFee) && SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee] > 0)
                                            {

                                                #region Late Fee (submission date greater than 180 days but less than 18 months of initial Inspection)

                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOFLateFee, (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");

                                                #endregion

                                            }

                                            #endregion

                                            #region AOC No Good Check TH

                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sahredNoGoodCheckFee) && SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] > 0)
                                            {
                                                /// No Good Check TH should always hold only $20 (Business Rule)
                                                /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                                /// 
                                                numberOfNGC = (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] / 20;

                                                for (int i = 0; i < numberOfNGC; i++)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                            }

                                            #endregion

                                            break;
                                        }

                                    case (int)ELV3InspectionType.PVTInspection:
                                    case (int)ELV3InspectionType.QCInspection:
                                        {
                                            #region PVT QC AOC Filing Fee

                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sharedFilingFee) && SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee] > 0)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyPVTAOCFilingFee, (decimal)SharedVariables[ELV29AffirimationAttributeNames.sharedFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }

                                            #endregion

                                            #region PVT QC AOC Late Filing Fee 
                                            //PVT QC AOC doesnot have late filing fee
                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sahredLateFilingFee) && SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee] > 0)
                                            {
                                                crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                transactionHistoryHelper(ElevatorSafetyTransactionCodes.ElevatorSafetyAOFLateFee, (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredLateFilingFee], targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                            }

                                            #endregion

                                            #region AOC No Good Check TH

                                            if (SharedVariables.Contains(ELV29AffirimationAttributeNames.sahredNoGoodCheckFee) && SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] != null && (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] > 0)
                                            {
                                                /// No Good Check TH should always hold only $20 (Business Rule)
                                                /// divide no good check amount/20 and then loop and add those many no good check TH's 
                                                /// 
                                                numberOfNGC = (decimal)SharedVariables[ELV29AffirimationAttributeNames.sahredNoGoodCheckFee] / 20;

                                                for (int i = 0; i < numberOfNGC; i++)
                                                {
                                                    crmTrace.AppendLine("Condition Expression for Elevator Safety");
                                                    transactionHistoryHelper(ElevatorSafetyTransactionCodes.CheckBounceFee, RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee), targetEntity, shadowPaymentHistoryId, service, crmTrace);
                                                    crmTrace.AppendLine("Create Transaction History for Elevator Safety-End");
                                                }

                                            }

                                            #endregion
                                            break;
                                        }


                                }
                            }
                            #endregion


                        }

                    }
                    #endregion




                }
                #endregion



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - CreateElevatorSafetyTransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }


        }

        /// <summary>
        /// this function is used to create transaction history based on transcode passed
        /// </summary>
        /// <param name="elevatorSafetyTranscodes"></param>
        /// <param name="transFee"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        public static void transactionHistoryHelper(string elevatorSafetyTranscodes, decimal transFee, Entity targetEntity, Guid shadowpaymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("COndition expression for" + elevatorSafetyTranscodes);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { elevatorSafetyTranscodes });
                crmTrace.AppendLine("get transaction code for" + elevatorSafetyTranscodes);
                EntityCollection transactioncodeResponse = ElevatorSafetyFeeCalculationHelper.GetTransactionCodes(service, targetEntity, crmTrace, condition);
                if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                {

                    crmTrace.AppendLine("create transaction history for" + elevatorSafetyTranscodes);
                    Guid transHistoryGuids = (ElevatorSafetyFeeCalculationHelper.CreateTransactionHistory(crmTrace, service, targetEntity.Id, shadowpaymentHistoryId, transactioncodeResponse.Entities[0], new Money(transFee)));
                    crmTrace.AppendLine("create transaction history for" + elevatorSafetyTranscodes);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }

        }

        public static void PHtransactionHistoryHelper(string elevatorSafetyTranscodes, decimal transFee, Entity targetEntity, Guid shadowpaymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("COndition expression for" + elevatorSafetyTranscodes);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { elevatorSafetyTranscodes });
                crmTrace.AppendLine("get transaction code for" + elevatorSafetyTranscodes);
                EntityCollection transactioncodeResponse = ElevatorSafetyFeeCalculationHelper.GetTransactionCodes(service, targetEntity, crmTrace, condition);
                if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                {

                    crmTrace.AppendLine("create transaction history for" + elevatorSafetyTranscodes);
                    Guid transHistoryGuids = (ElevatorSafetyFeeCalculationHelper.PHCreateTransactionHistory(crmTrace, service, targetEntity.Id, shadowpaymentHistoryId, transactioncodeResponse.Entities[0], new Money(transFee)));
                    crmTrace.AppendLine("create transaction history for" + elevatorSafetyTranscodes);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ELV3FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }

        }

    }
}
