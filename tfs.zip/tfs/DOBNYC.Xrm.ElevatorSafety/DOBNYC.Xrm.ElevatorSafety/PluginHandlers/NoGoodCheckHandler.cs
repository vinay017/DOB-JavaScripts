﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class NoGoodCheckHandler : PluginHandlerBase
    {
        public static void NoGoodCheckELV3(IOrganizationService service, Entity SPHPreImage, StringBuilder crmTrace)
        {

            EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
            Entity entityObject = new Entity();
            Guid elevatorSafetyEntityID = new Guid();

            Entity elevatorSafetyApplication = new Entity();
            decimal existingAmountPaid = 0;
            decimal existingAdjustment = 0;

            decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
            decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
            decimal totalAmountDue = 0;
            decimal noGoodCheckfeeConfig = ELV3FeeCalculationHandler.RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee);




            try
            {

                crmTrace.AppendLine("retrieve payment history record details");
                // retrieve from old payment history--Merchant Amount,Existing Amount Paid,ELV1 app

                crmTrace.AppendLine("Check if payment history not null");
                if (SPHPreImage != null && SPHPreImage.Contains(ShadowPaymentHistoryAttributeNames.ELV3Lookup) && SPHPreImage[ShadowPaymentHistoryAttributeNames.ELV3Lookup] != null)
                {

                    // retrieve amount due and adjustment from elevator application 
                    crmTrace.AppendLine("set elevatorSafetyEntityID");
                    elevatorSafetyEntityID = SPHPreImage.GetAttributeValue<EntityReference>(ShadowPaymentHistoryAttributeNames.ELV3Lookup).Id;
                    crmTrace.AppendLine(" Retrieve Elevator application details");
                    string[] ColumnNames_ElevatorSafety = new string[] { ELV3InspectionAttributeNames.Name, ELV3InspectionAttributeNames.AmountDue, ELV3InspectionAttributeNames.noGoodCheckFee, ELV3InspectionAttributeNames.Adjustment, ELV3InspectionAttributeNames.ReportStatus, ELV3InspectionAttributeNames.RevertedIncompleteSubmission, ELV3InspectionAttributeNames.AmountPaid, ELV3InspectionAttributeNames.Totalfee, ELV3InspectionAttributeNames.UserFilingActions };// added amount paid column.
                    elevatorSafetyApplication = Retrieve(service, ColumnNames_ElevatorSafety, elevatorSafetyEntityID, ELV3InspectionAttributeNames.EntityLogicalName);

                    // get amount paid from shadow payment history to update the elevator application
                    crmTrace.AppendLine("set AmountPaid");
                    existingAmountPaid = SPHPreImage.GetAttributeValue<Money>(ShadowPaymentHistoryAttributeNames.TotalFees).Value;

                    // get Adjustment from Elevator application
                    crmTrace.AppendLine("set Adjustment");
                    if (elevatorSafetyApplication.Attributes.Contains(ELV3InspectionAttributeNames.Adjustment))
                        existingAdjustment = elevatorSafetyApplication.GetAttributeValue<Money>(ELV3InspectionAttributeNames.Adjustment).Value;
                    #region Added Amount Due, No goodcheck
                    crmTrace.AppendLine("set ExistingAmountDue");
                    if (elevatorSafetyApplication.Attributes.Contains(ELV3InspectionAttributeNames.AmountDue))
                        existingAmountDue = elevatorSafetyApplication.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountDue).Value;
                    crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                    crmTrace.AppendLine("set Nogoodcheck");
                    if (elevatorSafetyApplication.Attributes.Contains(ELV3InspectionAttributeNames.noGoodCheckFee))
                        existingNogoodCheck = elevatorSafetyApplication.GetAttributeValue<Money>(ELV3InspectionAttributeNames.noGoodCheckFee).Value;
                    crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                    #endregion


                    crmTrace.AppendLine("Get check bounce fee transaction code");

                    crmTrace.AppendLine("Create new Shadow payment history");

                    Guid shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(service, elevatorSafetyApplication, (int)PaymentHistoryFeeType.ElevatorsSafetyElv3FilingFee, new Money(0), crmTrace);


                    //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                    EntityCollection Oldthresponse = getTransactionHistoriesforSPH(service, crmTrace, SPHPreImage.Id);

                    crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);

                    if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                    {
                        foreach (Entity oldthhistory in Oldthresponse.Entities)
                        {
                            #region Add oldthhistory to Global TH's
                            allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                            #endregion

                        }
                    }
                    #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                    if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                    {
                        foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                        {
                            crmTrace.AppendLine("create new transaction history for new payment history");
                            ElevatorSafetyFeeCalculationHelper.CreateTransactionHistory(crmTrace, service, elevatorSafetyEntityID, shadowPaymentHistoryGuid, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                        }

                    }
                    #endregion


                    if (noGoodCheckfeeConfig >= 0)
                    {
                        #region create Transaction history

                        //Add amount due attribute to SPHPreImage object as CreateTransactionHistory uses this to set the Fee attribute value
                        crmTrace.AppendLine("Create transaction history for check bounce - start");
                        ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { ElevatorSafetyTransactionCodes.CheckBounceFee });
                        EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                        //added Payment History Id attribute while creating Transaction history record itself to associate
                        Guid tHistoryId = ElevatorSafetyFeeCalculationHelper.CreateTransactionHistory(crmTrace, service, elevatorSafetyEntityID, shadowPaymentHistoryGuid, transactioncodeResponse[0],
                                                                                            new Money(noGoodCheckfeeConfig));

                        #endregion

                        if (tHistoryId != new Guid())
                        {
                            #region Update Elevator Safety  application entity
                            crmTrace.AppendLine("update Elevator appplication");
                            entityObject = new Entity(ELV3InspectionAttributeNames.EntityLogicalName);
                            entityObject.Id = elevatorSafetyEntityID;

                            if (existingAmountPaid > 0)
                            {
                                totalAmountDue = existingAmountPaid + noGoodCheckfeeConfig + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                entityObject.Attributes.Add(ELV3InspectionAttributeNames.AmountDue, new Money(totalAmountDue));
                                entityObject.Attributes.Add(ELV3InspectionAttributeNames.noGoodCheckFee, new Money((existingNogoodCheck + noGoodCheckfeeConfig)));//Nogoodcheck=existingnogoodcheck+20
                                entityObject.Attributes.Add(ELV3InspectionAttributeNames.AmountPaid, new Money((elevatorSafetyApplication.GetAttributeValue<Money>(ELV3InspectionAttributeNames.AmountPaid).Value - existingAmountPaid)));//amount paid=previous elevator amount paid- merchant amount
                                crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                            }



                            // Set Report status 

                            if (elevatorSafetyApplication.Contains(ELV3InspectionAttributeNames.ReportStatus))
                            {
                                crmTrace.AppendLine("check if elevatorSafetyApplication contains report status - start");
                                if (((OptionSetValue)elevatorSafetyApplication.Attributes[ELV3InspectionAttributeNames.ReportStatus]).Value > 0)
                                {


                                    crmTrace.AppendLine("Check if status is prefiling and add prefiling-no goodcheck status to report status");
                                    entityObject.Attributes.Add(ELV3InspectionAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PrefilingPendingPayment));


                                }
                                crmTrace.AppendLine("check if elevatorSafetyApplication contains report status - End");
                            }
                            //update all fee fields in Elevator application
                            entityObject.Attributes.Add(ELV3InspectionAttributeNames.Totalfee, new Money((elevatorSafetyApplication.GetAttributeValue<Money>(ELV3InspectionAttributeNames.Totalfee).Value + noGoodCheckfeeConfig))); // tota fee= prevtotalfee+20
                            entityObject.Attributes.Add(ELV3InspectionAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.CalculateCivilPenality));
                            service.Update(entityObject);
                            #endregion

                            #region Update Shadow PaymentHistory - reusing/replacing the same entity object
                            crmTrace.AppendLine("update the payment history - start");
                            entityObject = new Entity(ShadowPaymentHistoryAttributeNames.EntityLogicalName);
                            //pass new payment historyid(front end record id)
                            entityObject.Id = shadowPaymentHistoryGuid;
                            crmTrace.AppendLine("Set total fee in payment history");

                            entityObject.SetAttributeValue(ShadowPaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                            crmTrace.AppendLine("Update Isposted to flase");
                            entityObject.Attributes.Add(ShadowPaymentHistoryAttributeNames.IsPosted, false);
                            crmTrace.AppendLine("set no good check flage to true");
                            entityObject.Attributes.Add(ShadowPaymentHistoryAttributeNames.BoilerNoGoodCheckFlag, false);

                            //Payment history record updated for flags
                            service.Update(entityObject);
                            crmTrace.AppendLine("update the payment history - end");
                            #endregion
                        }
                        else
                        {
                            crmTrace.AppendLine("Transaction history record creation failed");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Check bounce fee Response has no records");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Payment history Response has no records");
                }




            }
            #region catch
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            #endregion
        }


        public static void NoGoodCheckELV29(IOrganizationService service, Entity SPHPreImage, StringBuilder crmTrace)
        {

            EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
            Entity entityObject = new Entity();
            Guid elevatorSafetyEntityID = new Guid();

            Entity elevatorSafetyApplication = new Entity();
            decimal existingAmountPaid = 0;

            decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
            decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
            decimal totalAmountDue = 0;

            decimal noGoodCheckfeeConfig = ELV3FeeCalculationHandler.RetrieveFee(crmTrace, service, FeeConfigs.noGoodCheckConfigFee);

            try
            {

                crmTrace.AppendLine("retrieve payment history record details");
                // retrieve from old payment history--Merchant Amount,Existing Amount Paid,ELV1 app

                crmTrace.AppendLine("Check if payment history not null");
                if (SPHPreImage != null && SPHPreImage.Attributes.Contains(ShadowPaymentHistoryAttributeNames.ELV29Lookup) && SPHPreImage[ShadowPaymentHistoryAttributeNames.ELV29Lookup] != null)
                {
                    if (elevatorSafetyEntityID.Equals(new Guid()))
                    {
                        // retrieve amount due and adjustment from elevator application 
                        crmTrace.AppendLine("set elevatorSafetyEntityID");
                        elevatorSafetyEntityID = SPHPreImage.GetAttributeValue<EntityReference>(ShadowPaymentHistoryAttributeNames.ELV29Lookup).Id;
                        crmTrace.AppendLine(" Retrieve Elevator application details");
                        string[] ColumnNames_ElevatorSafety = new string[] { ELV29AffirimationAttributeNames.Name, ELV29AffirimationAttributeNames.AmountDue, ELV29AffirimationAttributeNames.noGoodCheckFee, ELV29AffirimationAttributeNames.ReportStatus, ELV29AffirimationAttributeNames.RevertedIncompleteSubmission, ELV29AffirimationAttributeNames.AmountPaid, ELV29AffirimationAttributeNames.TotalFees, ELV29AffirimationAttributeNames.UserFilingActions };// added amount paid column.
                        elevatorSafetyApplication = Retrieve(service, ColumnNames_ElevatorSafety, elevatorSafetyEntityID, ELV29AffirimationAttributeNames.EntityLogicalName);

                        // get amount paid from shadow payment history to update the elevator application
                        crmTrace.AppendLine("set AmountPaid");
                        existingAmountPaid = SPHPreImage.GetAttributeValue<Money>(ShadowPaymentHistoryAttributeNames.TotalFees).Value;

                        // get Adjustment from Elevator application

                        #region Added Amount Due, No goodcheck
                        crmTrace.AppendLine("set ExistingAmountDue");
                        if (elevatorSafetyApplication.Attributes.Contains(ELV29AffirimationAttributeNames.AmountDue))
                            existingAmountDue = elevatorSafetyApplication.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountDue).Value;
                        crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                        crmTrace.AppendLine("set Nogoodcheck");
                        if (elevatorSafetyApplication.Attributes.Contains(ELV29AffirimationAttributeNames.noGoodCheckFee))
                            existingNogoodCheck = elevatorSafetyApplication.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.noGoodCheckFee).Value;
                        crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                        #endregion
                    }

                    crmTrace.AppendLine("Get check bounce fee transaction code");

                    crmTrace.AppendLine("Create new Shadow payment history");

                    Guid shadowPaymentHistoryGuid = ELV3FeeCalculationHandler.CreateShadowPaymentHistory(service, elevatorSafetyApplication, (int)PaymentHistoryFeeType.ElevatorsSafetyElv29, new Money(0), crmTrace);


                    //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                    EntityCollection Oldthresponse = getTransactionHistoriesforSPH(service, crmTrace, SPHPreImage.Id);

                    crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);



                    if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                    {
                        foreach (Entity oldthhistory in Oldthresponse.Entities)
                        {
                            #region Add oldthhistory to Global TH's
                            allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                            #endregion

                        }
                    }
                    #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                    if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                    {
                        foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                        {
                            crmTrace.AppendLine("create new transaction history for new payment history");
                            ElevatorSafetyFeeCalculationHelper.CreateTransactionHistory(crmTrace, service, elevatorSafetyEntityID, shadowPaymentHistoryGuid, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                        }

                    }
                    #endregion


                    if (noGoodCheckfeeConfig >= 0)
                    {
                        #region create Transaction history

                        //Add amount due attribute to SPHPreImage object as CreateTransactionHistory uses this to set the Fee attribute value
                        crmTrace.AppendLine("Create transaction history for check bounce - start");
                        ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { ElevatorSafetyTransactionCodes.CheckBounceFee });
                        EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                        //added Payment History Id attribute while creating Transaction history record itself to associate
                        Guid tHistoryId = ElevatorSafetyFeeCalculationHelper.CreateTransactionHistory(crmTrace, service, elevatorSafetyEntityID, shadowPaymentHistoryGuid, transactioncodeResponse[0],
                                                                                            new Money(noGoodCheckfeeConfig));

                        #endregion

                        if (tHistoryId != new Guid())
                        {
                            #region Update Elevator Safety  application entity
                            crmTrace.AppendLine("update Elevator appplication");
                            entityObject = new Entity(ELV29AffirimationAttributeNames.EntityLogicalName);
                            entityObject.Id = elevatorSafetyEntityID;

                            if (existingAmountPaid > 0)
                            {
                                totalAmountDue = existingAmountPaid + noGoodCheckfeeConfig + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                entityObject.Attributes.Add(ELV29AffirimationAttributeNames.AmountDue, new Money(totalAmountDue));
                                entityObject.Attributes.Add(ELV29AffirimationAttributeNames.noGoodCheckFee, new Money((existingNogoodCheck + noGoodCheckfeeConfig)));//Nogoodcheck=existingnogoodcheck+20
                                entityObject.Attributes.Add(ELV29AffirimationAttributeNames.AmountPaid, new Money((elevatorSafetyApplication.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.AmountPaid).Value - existingAmountPaid)));//amount paid=previous elevator amount paid- merchant amount
                                crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                            }



                            // Set Report status and assign status to reverted from no good check

                            if (elevatorSafetyApplication.Contains(ELV29AffirimationAttributeNames.ReportStatus))
                            {
                                crmTrace.AppendLine("check if elevatorSafetyApplication contains report status - start");
                                if (((OptionSetValue)elevatorSafetyApplication.Attributes[ELV29AffirimationAttributeNames.ReportStatus]).Value > 0)
                                {


                                    crmTrace.AppendLine("Check if status is prefiling and add prefiling-no goodcheck status to report status");
                                    entityObject.Attributes.Add(ELV29AffirimationAttributeNames.ReportStatus, new OptionSetValue((int)ELV3ReportStatus.PrefilingPendingPayment));


                                }
                                crmTrace.AppendLine("check if elevatorSafetyApplication contains report status - End");
                            }
                            //update all fee fields in Elevator application
                            entityObject.Attributes.Add(ELV29AffirimationAttributeNames.TotalFees, new Money((elevatorSafetyApplication.GetAttributeValue<Money>(ELV29AffirimationAttributeNames.TotalFees).Value + noGoodCheckfeeConfig))); // tota fee= prevtotalfee+20
                            entityObject.Attributes.Add(ELV29AffirimationAttributeNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.CalculateCivilPenality));
                            service.Update(entityObject);
                            #endregion

                            #region Update Shadow PaymentHistory - reusing/replacing the same entity object
                            crmTrace.AppendLine("update the payment history - start");
                            entityObject = new Entity(ShadowPaymentHistoryAttributeNames.EntityLogicalName);
                            //pass new payment historyid(front end record id)
                            entityObject.Id = shadowPaymentHistoryGuid;
                            crmTrace.AppendLine("Set total fee in payment history");

                            entityObject.SetAttributeValue(ShadowPaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                            crmTrace.AppendLine("Update Isposted to flase");
                            entityObject.Attributes.Add(ShadowPaymentHistoryAttributeNames.IsPosted, false);
                            crmTrace.AppendLine("set no good check flage to true");
                            entityObject.Attributes.Add(ShadowPaymentHistoryAttributeNames.BoilerNoGoodCheckFlag, false);

                            //Payment history record updated for flags
                            service.Update(entityObject);
                            crmTrace.AppendLine("update the payment history - end");
                            #endregion
                        }
                        else
                        {
                            crmTrace.AppendLine("Transaction history record creation failed");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Check bounce fee Response has no records");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Payment history Response has no records");
                }




            }
            #region catch
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(SPHPreImage.Id.ToString(), "CRM", "NoGoodCheckHandler - NoGoodCheckELV3", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            #endregion
        }



        /// <summary>
        /// This function is used to Count the PH which are is posted false. 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        public static EntityCollection CountOldPaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            EntityCollection OldPhhistory = new EntityCollection();
            try
            {

                //retreive the Job filing application field and Is posted equals to NO and no goodcheck is NO
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_elevator' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_elevatorapplication' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='0' operator='eq'/>
                            <condition attribute='dobnyc_nogoodcheckflag' operator='eq' value='0'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);

                return OldPhhistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return OldPhhistory;
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return OldPhhistory;
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckHandler - CountOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return OldPhhistory;
                //throw ex;
            }
        }

        /// <summary>
        /// This function will return the TH for a given PH guid
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static EntityCollection getTransactionHistoriesforSPH(IOrganizationService service, StringBuilder crmTrace, Guid result)
        {
            crmTrace.AppendLine("Fetch Xml ");
            string fetchXML = @"<?xml version='1.0'?>
                                                        <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                                                        <entity name='dobnyc_transactionhistory'> <attribute name='dobnyc_transactionhistoryid'/><attribute name='dobnyc_name'/>
                                                        <attribute name='createdon'/>
                                                        <attribute name='dobnyc_transactiontype'/>
                                                        <attribute name='dobnyc_transactioncode'/>
                                                        <attribute name='dobnyc_subsource'/>
                                                        <attribute name='dobnyc_revenuesource'/>
                                                        <attribute name='dobnyc_reportcategory'/>
                                                        <attribute name='dobnyc_fees'/>
                                                        <attribute name='dobnyc_budgetcode'/>
                                                        <attribute name='dobnyc_th_transactioncode'/>
                                                        <order descending='false' attribute='dobnyc_name'/>
                                                        <filter type='and'><condition attribute='dobnyc_th_shadowpaymenthistory' value='" + result + @"' uitype='dobnyc_shadowpaymenthistory' operator='eq'/>
                                                        </filter>
                                                        </entity>
                                                        </fetch>";
            crmTrace.AppendLine("End fetch xml for retrieving Oldthresponse ");
            crmTrace.AppendLine("Oldthresponse from FetchXml- Start");
            EntityCollection Oldthresponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
            crmTrace.AppendLine("Oldthresponse from FetchXml- end");
            return Oldthresponse;
        }
    }
}
