﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class ElevatorSafetyEligibleDeviceHandler : PluginHandlerBase
    {
        public static void setCAT1CAT5EligibleFlags(IOrganizationService service, Entity targetEntity, Entity preImage, int deviceStatus, StringBuilder crmTrace)
        {
            try
            {

                switch (deviceStatus)
                {
                    case (int)ElevatorDeviceStatus.Active:
                    case (int)ElevatorDeviceStatus.Sealed:
                    case (int)ElevatorDeviceStatus.NoJurisdiction:
                    case (int)ElevatorDeviceStatus.HousingAuthority:
                        {
                            crmTrace.AppendLine("Entered Devices  eligible staus block");
                            //For the above devices CAT1,CAT5 flags is based on device type
                            switch (preImage.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceType).Value)
                            {
                                case (int)ElevatorDeviceTypes.Elevator:
                                    {
                                        if (deviceStatus != (int)ElevatorDeviceStatus.NoJurisdiction)//no inspections for NO judistriction status
                                        {
                                            crmTrace.AppendLine("Elevator Device Type Entered");
                                            targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                            targetEntity = checkCAT5Eligibility(service, preImage, targetEntity, crmTrace);

                                        }
                                        break;

                                    }
                                case (int)ElevatorDeviceTypes.Escalator:
                                    {
                                        crmTrace.AppendLine("Escalator Device Type Entered");
                                        targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.MovingWalk:
                                    {
                                        crmTrace.AppendLine("MovingWalk Device Type Entered");
                                        targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.Dumbwaiter:
                                    {
                                        if (deviceStatus != (int)ElevatorDeviceStatus.NoJurisdiction)//no inspections for NO judistriction status
                                        {
                                            crmTrace.AppendLine("Dumbwaiter Device Type Entered");
                                            targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                            targetEntity = checkCAT5Eligibility(service, preImage, targetEntity, crmTrace);
                                        }

                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.AccessibilityLift:
                                    {
                                        crmTrace.AppendLine("AccessibilityLift Device Type Entered");
                                        int subType = getAccessibilityLiftSubType(service, preImage, crmTrace);
                                        switch (subType)
                                        {
                                            case (int)ElevatorAccessibilityLiftType.PlatformLift:
                                                {
                                                    if (deviceStatus != (int)ElevatorDeviceStatus.NoJurisdiction)//no inspections for NO judistriction status
                                                    {
                                                        crmTrace.AppendLine("AccessibilityLift  PlatformLift Device Type Entered");
                                                        targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                                        targetEntity = checkCAT5Eligibility(service, preImage, targetEntity, crmTrace);
                                                    }

                                                    break;
                                                }
                                            case (int)ElevatorAccessibilityLiftType.StairwayChairlift:
                                                {
                                                    crmTrace.AppendLine("AccessibilityLift  StairwayChairlift Device Type Entered");
                                                    setCat1Cat5False(service, targetEntity, crmTrace);
                                                    break;
                                                }
                                        }
                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.Manlift:
                                    {
                                        crmTrace.AppendLine("Manlift Device Type Entered");
                                        targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, true);
                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.Conveyor:
                                    {
                                        crmTrace.AppendLine("Conveyor Device Type Entered");
                                        setCat1Cat5False(service, targetEntity, crmTrace);
                                        break;
                                    }
                                case (int)ElevatorDeviceTypes.PersonnelHoist:
                                    {
                                        crmTrace.AppendLine("PersonnelHoist Device Type Entered");
                                        setCat1Cat5False(service, targetEntity, crmTrace);
                                        //set the personalhoist expirey date
                                        targetEntity.SetAttributeValue(ElevatorMasterDevice.PH_TempRenewalExpiry, (targetEntity.Contains(ElevatorMasterDevice.StatusDate) && targetEntity[ElevatorMasterDevice.StatusDate] != null ? targetEntity.GetAttributeValue<DateTime>(ElevatorMasterDevice.StatusDate).AddDays(90) : (preImage.Contains(ElevatorMasterDevice.StatusDate) && preImage[ElevatorMasterDevice.StatusDate] != null ? preImage.GetAttributeValue<DateTime>(ElevatorMasterDevice.StatusDate).AddDays(90) : DateTime.Now.AddDays(90))));
                                        break;
                                    }

                            }
                            break;
                        }
                    case (int)ElevatorDeviceStatus.Deleted:
                    case (int)ElevatorDeviceStatus.Dismantled:
                    case (int)ElevatorDeviceStatus.Removed:
                    case (int)ElevatorDeviceStatus.Withdrawn:
                        {
                            //In above status devices will not be eligible to file CAt1, CAT5 so set them to false
                            setCat1Cat5False(service, targetEntity, crmTrace);
                            break;
                        }
                }

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyEligibleDeviceHandler - setCAT1CAT5EligibleFlags", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }
        /// <summary>
        /// Get the accessibility lift subtype from preimage of master device
        /// </summary>
        /// <param name="service"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static int getAccessibilityLiftSubType(IOrganizationService service, Entity preImage, StringBuilder crmTrace)
        {
            Entity movingEntity = service.Retrieve(ElevatorMovingTypeAttributeNames.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestMovingDevice).Id, new ColumnSet(new string[] { ElevatorMovingTypeAttributeNames.AccessbilitySubDeviceType }));
            if (movingEntity != null && movingEntity.Contains(ElevatorMovingTypeAttributeNames.AccessbilitySubDeviceType) && movingEntity[ElevatorMovingTypeAttributeNames.AccessbilitySubDeviceType] != null)
            {
                return movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.AccessbilitySubDeviceType).Value;
            }
            else
            {
                return 0;
            }

        }


        /// <summary>
        /// check the device machinetype and if it is eligible for cat5 then set flag to true
        /// </summary>
        /// <param name="service"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity checkCAT5Eligibility(IOrganizationService service, Entity preImage, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("get the machine type from preimage start");
            Entity movingEntity = service.Retrieve(ElevatorMovingTypeAttributeNames.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestMovingDevice).Id, new ColumnSet(new string[] { ElevatorMovingTypeAttributeNames.MachineType, ElevatorMovingTypeAttributeNames.DeviceType, ElevatorMovingTypeAttributeNames.jackSubType }));
            if (movingEntity != null && movingEntity.Contains(ElevatorMovingTypeAttributeNames.MachineType) && movingEntity[ElevatorMovingTypeAttributeNames.MachineType] != null)
            {
                if (
                    (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.DeviceType).Value == (int)ElevatorDeviceTypes.Elevator && (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.MachineType).Value == (int)ElevatorMachineType.Traction || (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.MachineType).Value == (int)ElevatorMachineType.Hydraulic && movingEntity[ElevatorMovingTypeAttributeNames.jackSubType] != null && movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.jackSubType).Value == 1)))// Elevator and machine type= traction or roped-hydrualic
                    || (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.DeviceType).Value == (int)ElevatorDeviceTypes.Dumbwaiter)//Device Type Dumbwaiter
                    || (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.DeviceType).Value == (int)ElevatorDeviceTypes.AccessibilityLift && movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.MachineType).Value == (int)ElevatorMachineType.Traction)
                    ) //Accessibility lift and traction
                {
                    crmTrace.AppendLine("Machine type -Traction or Roped Hydrualic so cat5-true");
                    targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat5Eligible, true);
                    if (!(preImage.Contains(ElevatorMasterDevice.CAT5LatestReportFileDate) && preImage[ElevatorMasterDevice.CAT5LatestReportFileDate] != null && preImage.GetAttributeValue<DateTime>(ElevatorMasterDevice.CAT5LatestReportFileDate) != DateTime.MinValue))//first time pass final
                    {
                        targetEntity.SetAttributeValue(ElevatorMasterDevice.CAT5LatestReportFileDate, DateTime.Now);
                        DateTime tempNextCycleEndDate = DateTime.Now.AddYears(5);
                        DateTime CAT5NextCycleEndDate = new DateTime(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month, DateTime.DaysInMonth(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month));//set the end cycle to the last day of that month
                        targetEntity.SetAttributeValue(ElevatorMasterDevice.CAT5NextCycleEndDate, CAT5NextCycleEndDate);
                    }

                }
                else
                {
                    crmTrace.AppendLine("Machine type other than traction ,roped Hydrualic so Cat5-false");
                    targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat5Eligible, false);
                }

            }
            else
            {
                crmTrace.AppendLine("Machine type not present so CAT5-false");
                targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat5Eligible, false);
            }
            return targetEntity;
        }


        /// <summary>
        /// set Cat1, CAT5 flags as false
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity setCat1Cat5False(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("Entered Devices not eligible staus block");
            crmTrace.AppendLine("Set CAT1,CAT5 False-start");
            targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat1Eligible, false);
            targetEntity.SetAttributeValue(ElevatorMasterDevice.IsCat5Eligible, false);
            crmTrace.AppendLine("Set CAT1,CAT5 False-End");
            return targetEntity;
        }
    }
}
