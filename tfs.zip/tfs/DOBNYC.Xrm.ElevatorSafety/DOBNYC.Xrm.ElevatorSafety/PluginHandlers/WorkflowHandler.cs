﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;


namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class WorkflowHandler : PluginHandlerBase
    {
        /// <summary>
        /// This Method is used to call the workflows of ELV3 when there is a report status change
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        public static void ELV3WorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.ReportStatus))
                {
                    int currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("currentFilingStatus: " + currentReportStatus.ToString());
                    int PreviousReportStatus = preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousReportStatus.ToString());

                    // Stop creating task in no good check scenario
                    if (currentReportStatus != PreviousReportStatus)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELevator Safety - ELV3 - Fee Exempt - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #region Atteststation Emails

                #region PA Inspector attestation

                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement))
                {
                    bool currentinspectingAgencyInspectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement);
                    crmTrace.AppendLine("currentFilingStatus: " + currentinspectingAgencyInspectorLegalStatement.ToString());
                    bool PreviousinspectingAgencyInspectorLegalStatement = preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyInspectorLegalStatement);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousinspectingAgencyInspectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentinspectingAgencyInspectorLegalStatement != PreviousinspectingAgencyInspectorLegalStatement && currentinspectingAgencyInspectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV3-Inspecting agency Inspector Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion

                #region PA Director attestation

                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement))
                {
                    bool currentinspectingAgencyDirectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement);
                    crmTrace.AppendLine("currentFilingStatus: " + currentinspectingAgencyDirectorLegalStatement.ToString());
                    bool PreviousinspectingAgencyDirectorLegalStatement = preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.inspectingAgencyDirectorLegalStatement);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousinspectingAgencyDirectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentinspectingAgencyDirectorLegalStatement != PreviousinspectingAgencyDirectorLegalStatement && currentinspectingAgencyDirectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV3-Inspecting agency Director Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion

                #region Witness Inspector attestation
                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement))
                {
                    bool currentwitnessAgencyInspectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement);
                    crmTrace.AppendLine("currentFilingStatus: " + currentwitnessAgencyInspectorLegalStatement.ToString());
                    bool PreviouswitnessAgencyInspectorLegalStatement = preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyInspectorLegalStatement);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviouswitnessAgencyInspectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentwitnessAgencyInspectorLegalStatement != PreviouswitnessAgencyInspectorLegalStatement && currentwitnessAgencyInspectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV3-Witness agency Inspector Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion

                #region Witness Director attestation

                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement))
                {
                    bool currentwitnessAgencyDirectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement);
                    crmTrace.AppendLine("currentFilingStatus: " + currentwitnessAgencyDirectorLegalStatement.ToString());
                    bool PreviouswitnessAgencyDirectorLegalStatement = preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.witnessAgencyDirectorLegalStatement);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviouswitnessAgencyDirectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentwitnessAgencyDirectorLegalStatement != PreviouswitnessAgencyDirectorLegalStatement && currentwitnessAgencyDirectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV3-Witness agency Director Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion
                #region Owner attestation
                if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.ownerLegalStatement))
                {
                    bool currentownerLegalStatement = targetEntity.GetAttributeValue<bool>(ELV3InspectionAttributeNames.ownerLegalStatement);
                    crmTrace.AppendLine("currentFilingStatus: " + currentownerLegalStatement.ToString());
                    bool PreviousownerLegalStatement = preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.ownerLegalStatement);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousownerLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentownerLegalStatement != PreviousownerLegalStatement && currentownerLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV3-Owner Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }
                #endregion

                #endregion

                #region Emails for DP
                //if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.designProfessional))
                //{
                //    crmTrace.AppendLine("ELV3InspectionAttributeNames.designProfessional is present ");
                //    Guid currentApplicant = ((EntityReference)targetEntity[ELV3InspectionAttributeNames.designProfessional]).Id;
                //    if (preImage.Attributes.Contains(ELV3InspectionAttributeNames.designProfessional))
                //    {
                //        Guid previousApplicant = ((EntityReference)preImage[ELV3InspectionAttributeNames.designProfessional]).Id;
                //        if (currentApplicant != previousApplicant)
                //        {
                //            crmTrace.AppendLine("Start Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                //            AssignmentEmails(service, targetEntity, "Elevator-Email Design Professional", crmTrace);
                //            crmTrace.AppendLine("End Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                //        }
                //    }
                //    if (!preImage.Attributes.Contains(ELV3InspectionAttributeNames.designProfessional))
                //    {
                //        crmTrace.AppendLine("Start Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                //        AssignmentEmails(service, targetEntity, "Elevator-Email Design Professional", crmTrace);
                //        crmTrace.AppendLine("End Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                //    }

                //}
                #endregion

                #region Emails for Applicant
                //if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.Applicant))
                //{
                //    crmTrace.AppendLine("ELV3InspectionAttributeNames.Applicant is present ");
                //    Guid currentApplicant = ((EntityReference)targetEntity[ELV3InspectionAttributeNames.Applicant]).Id;
                //    if (preImage.Attributes.Contains(ELV3InspectionAttributeNames.Applicant))
                //    {
                //        Guid previousApplicant = ((EntityReference)preImage[ELV3InspectionAttributeNames.Applicant]).Id;
                //        if (currentApplicant != previousApplicant)
                //        {
                //            crmTrace.AppendLine("Start Applicant Email: " + PluginHelperStrings.UpdateMessageName);
                //            AssignmentEmails(service, targetEntity, "Elevator-Email Applicant", crmTrace);
                //            crmTrace.AppendLine("End Applicant Email: " + PluginHelperStrings.UpdateMessageName);
                //        }
                //    }
                //    if (!preImage.Attributes.Contains(ELV3InspectionAttributeNames.Applicant))
                //    {
                //        crmTrace.AppendLine("Start Applicant Email: " + PluginHelperStrings.UpdateMessageName);
                //        AssignmentEmails(service, targetEntity, "Elevator-Email Applicant", crmTrace);
                //        crmTrace.AppendLine("End Applicant Email: " + PluginHelperStrings.UpdateMessageName);
                //    }

                //}
                #endregion

                #region Emails for Owner
                //if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.Owner))
                //{
                //    crmTrace.AppendLine("ELV3InspectionAttributeNames.Owner is present ");
                //    Guid currentOwner = ((EntityReference)targetEntity[ELV3InspectionAttributeNames.Owner]).Id;
                //    if (preImage.Attributes.Contains(ELV3InspectionAttributeNames.Owner))
                //    {
                //        Guid previousOwner = ((EntityReference)preImage[ELV3InspectionAttributeNames.Owner]).Id;
                //        if (currentOwner != previousOwner)
                //        {
                //            crmTrace.AppendLine("Start Owner Email: " + PluginHelperStrings.UpdateMessageName);
                //            AssignmentEmails(service, targetEntity, "Elevator-Email Owner", crmTrace);
                //            crmTrace.AppendLine("End Owner Email: " + PluginHelperStrings.UpdateMessageName);
                //        }
                //    }
                //    if (!preImage.Attributes.Contains(ELV3InspectionAttributeNames.Owner))
                //    {
                //        crmTrace.AppendLine("Start Owner Email: " + PluginHelperStrings.UpdateMessageName);
                //        AssignmentEmails(service, targetEntity, "Elevator-Email Owner", crmTrace);
                //        crmTrace.AppendLine("End Owner Email: " + PluginHelperStrings.UpdateMessageName);
                //    }

                //}
                #endregion
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ElevatorsWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }


        /// <summary>
        /// This Method is used to call the workflows of ELV29 when there is a report status change
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        public static void ELV29WorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.ReportStatus))
                {
                    int currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("currentFilingStatus: " + currentReportStatus.ToString());
                    int PreviousReportStatus = preImage.GetAttributeValue<OptionSetValue>(ELV29AffirimationAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousReportStatus.ToString());

                    // Stop creating task in no good check scenario
                    if (currentReportStatus != PreviousReportStatus)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Elevator Safety - ELV29 - Fee Exempt - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #region Atteststation Emails

                #region PA Inspector attestation

                if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.PAInspectorAttestation))
                {
                    bool currentinspectingAgencyInspectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PAInspectorAttestation);
                    crmTrace.AppendLine("currentFilingStatus: " + currentinspectingAgencyInspectorLegalStatement.ToString());
                    bool PreviousinspectingAgencyInspectorLegalStatement = preImage.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PAInspectorAttestation);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousinspectingAgencyInspectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentinspectingAgencyInspectorLegalStatement != PreviousinspectingAgencyInspectorLegalStatement && currentinspectingAgencyInspectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "EL29-Inspecting agency Inspector Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion

                #region PA Director attestation

                if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.PADirectorAttestation))
                {
                    bool currentinspectingAgencyDirectorLegalStatement = targetEntity.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PADirectorAttestation);
                    crmTrace.AppendLine("currentFilingStatus: " + currentinspectingAgencyDirectorLegalStatement.ToString());
                    bool PreviousinspectingAgencyDirectorLegalStatement = preImage.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PADirectorAttestation);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousinspectingAgencyDirectorLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentinspectingAgencyDirectorLegalStatement != PreviousinspectingAgencyDirectorLegalStatement && currentinspectingAgencyDirectorLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV29-Inspecting agency Director Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }

                #endregion

             
                #region Owner attestation
                if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.PAOwnerrAttestation))
                {
                    bool currentownerLegalStatement = targetEntity.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PAOwnerrAttestation);
                    crmTrace.AppendLine("currentFilingStatus: " + currentownerLegalStatement.ToString());
                    bool PreviousownerLegalStatement = preImage.GetAttributeValue<bool>(ELV29AffirimationAttributeNames.PAOwnerrAttestation);
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousownerLegalStatement.ToString());

                    // Stop creating task in no good check scenario
                    if (currentownerLegalStatement != PreviousownerLegalStatement && currentownerLegalStatement)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "ELV29-Owner Attestation").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }
                #endregion

                #endregion


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV29WorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }



        /// <summary>
        /// This is used to send emails to DEV team when ever there is a error on BIS services 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="isCreateViolation">used to identify crease service or dismiss service</param>
        public static void CreateDismissBISViolationFailureEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace,bool isCreateViolation)
        {
            try
            {

                if(isCreateViolation)
                {
                    Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Elevator Safety- Bis Integration Create Violation Failure Email").Id.ToString());
                    crmTrace.AppendLine("processId:  " + processId.ToString());
                    ExecuteWorkflow(service, processId, targetEntity.Id);
                }
                else
                {
                    Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Elevator Safety- Dismiss BIS violation failure email").Id.ToString());
                    crmTrace.AppendLine("processId:  " + processId.ToString());
                    ExecuteWorkflow(service, processId, targetEntity.Id);
                }
              
             


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - CreateBISViolationFailureEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }

        /// <summary>
        /// This Method is used to call the workflows of ELV36 when there is a report status change
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        public static void ELV36WorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                if (targetEntity.Attributes.Contains(ELV36TestNotificationAttributeNames.ReportStatus))
                {
                    int currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ELV36TestNotificationAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("currentFilingStatus: " + currentReportStatus.ToString());
                    int PreviousReportStatus = preImage.GetAttributeValue<OptionSetValue>(ELV36TestNotificationAttributeNames.ReportStatus).Value;
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousReportStatus.ToString());

                    // Stop creating task in no good check scenario
                    if (currentReportStatus != PreviousReportStatus)//&& (PreviousReportStatus != (int)ElevatorRequestStatus.OnHoldNoGoodCheck))
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Elevator Safety - ELV36 - Master Workflow (Emails)").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);


                    }
                }


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ELV36WorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            #endregion
        }

        /// <summary>
        /// This method will call the report defect clone workflow
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        public static void ReportDefectsWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                Guid processId = GetProcessId(service, "workflow", "name", "Elevator Safety - Report Defect Is Submitted").Id;
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkFlowHandler - ReportDefectsWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static Entity GetProcessId(IOrganizationService service, string EntityLogicalName, string SearchFieldName, object SearchValue)
        {
            EntityLogicalName = EntityLogicalName.ToLower();
            SearchFieldName = SearchFieldName.ToLower();
            QueryExpression query = new QueryExpression(EntityLogicalName);
            query.ColumnSet = new ColumnSet(true);
            query.NoLock = true;
            query.Criteria.AddCondition(new ConditionExpression(SearchFieldName, ConditionOperator.Equal, SearchValue));
            query.Criteria.AddCondition(new ConditionExpression("type", ConditionOperator.Equal, 1));

            try
            {
                EntityCollection response = service.RetrieveMultiple(query);
                if (response != null && response.Entities.Count > 0)
                    return response.Entities[0];
                else { return null; }
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", null, " customTrace.ToString()", null, null);
                DOBLogger.WriteExceptionLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return null;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", null, "customTrace.ToString()", null, null);
                DOBLogger.WriteExceptionLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return null;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", null, "customTrace.ToString()", null, null);
                DOBLogger.WriteExceptionLog(EntityLogicalName, "CRM", "WorkFlowHandler - GetProcessId", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return null;
            }
            #endregion
        }  // getProcessId ends here

        /// <summary>
        /// This method is used to update the master device dates when ELV3 is accepted or accepted defects
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        /// <param name="lateFilingFee"></param>
        /// <param name="inspectionType"></param>
        /// <returns></returns>
        public static void UpdateMasterDeviceDates(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, int inspectionType)
        {
            try
            {
                ///Get the inspection date,master device Id from preimage
                ///based on Inspection type set the dates
                crmTrace.AppendLine("UpdateMasterDeviceDates Satrt ");
                Entity masterDevice = new Entity(ElevatorMasterDevice.EntityLogicalName);
                bool updateMaster = false;
                if (inspectionType > 0)
                {
                    switch (inspectionType)
                    {
                        case (int)ELV3InspectionType.CAT1:
                            {
                                crmTrace.AppendLine("ELV3InspectionType.CAT1 Satrt ");
                                masterDevice.Attributes.Add(ElevatorMasterDevice.CAT1ReportYear, preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.ReportYear));
                                masterDevice.Attributes.Add(ElevatorMasterDevice.CAT1LatestReportFileDate, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate));

                                updateMaster = true;
                                crmTrace.AppendLine("ELV3InspectionType.CAT1 End ");
                                break;
                            }
                        case (int)ELV3InspectionType.CAT3:
                            {
                                crmTrace.AppendLine("ELV3InspectionType.CAT3 Satrt ");
                                masterDevice.Attributes.Add(ElevatorMasterDevice.CAT3LatestReportFileDate, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate));
                                updateMaster = true;
                                crmTrace.AppendLine("ELV3InspectionType.CAT3 End ");
                                break;
                            }
                        case (int)ELV3InspectionType.CAT5:
                            {
                                crmTrace.AppendLine("ELV3InspectionType.CAT5 Satrt ");
                                Entity masterDeviceDetails = service.Retrieve(ElevatorMasterDevice.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id, new ColumnSet(new string[] { ElevatorMasterDevice.CAT5LatestReportFileDate }));
                                if (preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate) > masterDeviceDetails.GetAttributeValue<DateTime>(ElevatorMasterDevice.CAT5LatestReportFileDate))//check the current inspection date is greater than old inspection date on master device
                                {
                                    masterDevice.Attributes.Add(ElevatorMasterDevice.CAT5LatestReportFileDate, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate));
                                    DateTime tempNextCycleEndDate = preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate).AddYears(5);
                                    DateTime CAT5NextCycleEndDate = new DateTime(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month, DateTime.DaysInMonth(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month));//set the end cycle to the last day of that month
                                    masterDevice.Attributes.Add(ElevatorMasterDevice.CAT5NextCycleEndDate, CAT5NextCycleEndDate);
                                    updateMaster = true;
                                    crmTrace.AppendLine("ELV3InspectionType.CAT5 End ");
                                }

                                break;
                            }
                        case (int)ELV3InspectionType.NinetyDayTempRenewal:
                            {
                                crmTrace.AppendLine("ELV3InspectionType.NinetyDayTempRenewal Satrt ");
                                //add 90 days from initital inspection that will give the expiry
                                masterDevice.Attributes.Add(ElevatorMasterDevice.personalHoistTempRenewal, preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.InspectionDate).AddDays(90));
                                updateMaster = true;
                                crmTrace.AppendLine("ELV3InspectionType.NinetyDayTempRenewal End ");
                                break;
                            }
                    }

                    if (updateMaster)//update master only if true
                    {
                        masterDevice.Id = preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id;
                        service.Update(masterDevice);
                    }
                }











            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "WorkflowHandler - UpdateMasterDeviceDates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }
    }
}
