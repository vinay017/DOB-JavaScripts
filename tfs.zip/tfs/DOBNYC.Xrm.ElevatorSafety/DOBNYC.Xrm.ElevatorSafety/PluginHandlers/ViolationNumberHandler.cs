﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    public class ViolationNumberHandler : PluginHandlerBase
    {
        /// <summary>
        /// This method is used to create the violation number for PVT,QC ELV3 if ELV3 has defects
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> ELV3 Entity</param>
        /// <param name="preImage"> ELV3 preimage</param>
        /// <param name="crmTrace"></param>
        public static CreateElevatorDOBViolationNumberResponse CreateViolationNumber(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            string requestString = string.Empty;
            ExternalSystem_ElavatorViolationNumberMethods svc = new ExternalSystem_ElavatorViolationNumberMethods();
            CreateElevatorDOBViolationNumberRequest request = new CreateElevatorDOBViolationNumberRequest();
            CreateElevatorDOBViolationNumberResponse response = new CreateElevatorDOBViolationNumberResponse();
            try
            {

                crmTrace.AppendLine("Build the request");

                request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.Name);
                crmTrace.AppendLine("PC_CRM_VIOLATION_RECORD_ID :" + request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID);
                request.PC_DATA.PC_CRM_DOB_VIOL_SEQ_NUMBER = (preImage.Contains(ELV3InspectionAttributeNames.sequenceNumber) && preImage[ELV3InspectionAttributeNames.sequenceNumber] != null) ? preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.sequenceNumber) : "1234";
                crmTrace.AppendLine("PC_CRM_DOB_VIOL_SEQ_NUMBER :" + request.PC_DATA.PC_CRM_DOB_VIOL_SEQ_NUMBER);
                if (preImage.GetAttributeValue<bool>(ELV3InspectionAttributeNames.ceaseUseFlag))
                {
                    request.PC_DATA.PC_CRM_CEASE_USE = "Y";
                }
                else
                {
                    request.PC_DATA.PC_CRM_CEASE_USE = "N";
                }
                crmTrace.AppendLine("PC_CRM_CEASE_USE :" + request.PC_DATA.PC_CRM_CEASE_USE);
                request.PC_DATA.PC_CRM_VIOLATION_TYPE = "ELEVATOR";
                request.PC_DATA.PC_CRM_BIN = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.BIN);
                request.PC_DATA.PC_CRM_BORO = preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.Borough).Value.ToString();
                request.PC_DATA.PC_CRM_HOUSE_NUMBER = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.HouseNumber);
                request.PC_DATA.PC_CRM_STREET_NAME = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.StreetName);
                request.PC_DATA.PC_CRM_DEVICE_NUMBER = preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Name;
                crmTrace.AppendLine("PC_CRM_DEVICE_NUMBER :" + preImage.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Name);
                request.PC_DATA.PC_CRM_VIOL_ISSUE_DATE = (preImage.Contains(ELV3InspectionAttributeNames.violationDate) && preImage[ELV3InspectionAttributeNames.violationDate] != null) ? preImage.GetAttributeValue<DateTime>(ELV3InspectionAttributeNames.violationDate).ToString("yyyy-MM-dd") : DateTime.Now.ToString("yyyy-MM-dd");
                crmTrace.AppendLine("PC_CRM_VIOL_ISSUE_DATE :" + request.PC_DATA.PC_CRM_VIOL_ISSUE_DATE);

                if (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.PVTInspection)
                {
                    request.PC_DATA.PC_CRM_INSPECTION_CATEGORY = "P";
                }
                else
                {
                    request.PC_DATA.PC_CRM_INSPECTION_CATEGORY = "Q";
                }
                crmTrace.AppendLine("PC_CRM_INSPECTION_CATEGORY :" + request.PC_DATA.PC_CRM_INSPECTION_CATEGORY);
                request.PC_DATA.PC_CRM_BADGE_NUMBER = "1234";//for temp only

                #region Capture BIS Request in CRM
                crmTrace.AppendLine("XML Serialize start for request");
                requestString = ExternalSystem_ElavatorViolationNumberMethods.SerializeObject(request); //to get the requestin XML
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                crmTrace.AppendLine("XML Serialize End for request");
                Guid requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 1, true, string.Empty,crmTrace);

                #endregion

                #region Capture BIS Responsein CRM


                response = svc.AllElevatorDOBViolationMethods(request, response, request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID, "CRM", "USERID", "Create Violation Number");
                crmTrace.AppendLine("Response from Bis Received");

                crmTrace.AppendLine("XML Serialize start for Response");
                requestString = ExternalSystem_ElavatorViolationNumberMethods.SerializeObject(response); //to get the requestin XML
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                crmTrace.AppendLine("XML Serialize End for Response");
                Guid responseGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 1, false,response.MF_OVERALL_TEXT ,crmTrace);

                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateViolationNumber - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateViolationNumber- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-CreateViolationNumber- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ViolationNumberHandler-CreateViolationNumber- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-CreateViolationNumber- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateViolationNumber - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            return response;




        }

        /// <summary>
        /// Used to log request to BIS and response from BIS in CRM
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> ELV3 or ELV29</param>
        /// <param name="requestString">xml request or xml response</param>
        /// <param name="callfrom">pass values to set elv3 lookup - 1,elv29 - 2,violation number- 3   </param>
        /// <param name="isRequest">to differentiate request and response</param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Guid CreateBISRequestResponseRecord(IOrganizationService service, Entity targetEntity, string requestString, int callfrom, bool isRequest, string errorMessage,StringBuilder crmTrace)
        {
            Entity requestResponse = new Entity(ElevatorSafetyBISRequestResponse.EntityLogicalName);
            try
            {
                crmTrace.AppendLine("CreateBISRequestResponseRecord start");

                requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.overallText, requestString);
                crmTrace.AppendLine("Overall text added");
                if (callfrom==1)//elv3
                {
                    requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.elv3Lookup, targetEntity.ToEntityReference());
                    crmTrace.AppendLine("elv3Lookup");
                }
                else if(callfrom==2)//elv29
                {
                    requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.elv29Lookup, targetEntity.ToEntityReference());
                    crmTrace.AppendLine("elv29Lookup");
                }
                else
                {
                    requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.violationLookup, targetEntity.ToEntityReference());
                    crmTrace.AppendLine("ViolationLookup");
                }

                if (isRequest)
                {
                    requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.name, "CRMRequest");
                    crmTrace.AppendLine("Request");
                }
                else
                {
                    if (!string.IsNullOrEmpty(errorMessage))
                    {
                        requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.errorMessages, errorMessage);
                        crmTrace.AppendLine("Log Error");
                        requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.name, "ErrorCRMResponse");
                        crmTrace.AppendLine("Response");
                    }
                    else
                    {
                        requestResponse.Attributes.Add(ElevatorSafetyBISRequestResponse.name, "CRMResponse");
                        crmTrace.AppendLine("Response");
                    }

                   
                }

               



                    crmTrace.AppendLine("CreateBISRequestResponseRecord End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateBISRequestResponseRecord - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateBISRequestResponseRecord- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-CreateBISRequestResponseRecord- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ViolationNumberHandler-CreateBISRequestResponseRecord- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-CreateBISRequestResponseRecord- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-CreateBISRequestResponseRecord - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            return (service.Create(requestResponse));
        }
        /// <summary>
        /// Update the Dismissal flag to true for all ELV29 for the given device id
        /// </summary>
        /// <param name="service"></param>
        /// <param name="DeviceId"></param>
        /// <param name="crmTrace"></param>
        public static void GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag(IOrganizationService service, Guid DeviceId, StringBuilder crmTrace)
        {
            try
            {
                EntityCollection records = new EntityCollection();
                string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_elv29'>
                                    <attribute name='dobnyc_name' />
                                    <attribute name='createdon' />
                                    <attribute name='dobnyc_streetname' />
                                    <attribute name='dobnyc_housenumber' />
                                    <attribute name='dobnyc_elv29_filingfee' />
                                    <attribute name='dobnyc_dateofinitialinspection' />
                                    <attribute name='dobnyc_dateofaocinspection' />
                                    <attribute name='dobnyc_borough' />
                                    <attribute name='dobnyc_bin' />
                                    <attribute name='dobnyc_approvedagencydirectorcodirector' />
                                    <attribute name='dobnyc_elv29_reportstatus' />
                                    <attribute name='dobnyc_elv29id' />
                                    <attribute name='dobnyc_elv29_elv3lookup' />
                                    <order attribute='dobnyc_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_elv29_deviceid' operator='eq'  uitype='dobnyc_elevatordevice' value='{0}' />
                                      <condition attribute='dobnyc_elv29_reportstatus' operator='in'>
                                        <value>14</value>
                                        <value>15</value>
                                      </condition>
                                      <condition attribute='dobnyc_elv29_isviolationdismissedflag' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";

                fetchXml = string.Format(fetchXml, DeviceId.ToString());



                if (fetchXml != string.Empty)
                {
                    records = service.RetrieveMultiple(new FetchExpression(fetchXml));
                }
                crmTrace.AppendLine("records count :" + records.Entities.Count);
                if (records != null && records.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Update Dismissal Flag  Start :");
                    foreach (Entity updateElV29 in records.Entities)
                    {
                        crmTrace.AppendLine("updateElV29 Id : " + updateElV29.Id);
                        updateElV29.SetAttributeValue(ELV29AffirimationAttributeNames.violationDismissFlag, true);
                        service.Update(updateElV29);
                    }
                    crmTrace.AppendLine("Update Dismissal Flag  End :");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetALLELV29WithViolationsNotDismissedAndUpdateDismissalFlag - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }



        }

        /// <summary>
        /// Used to get all NRF violations based on inspection type for a given device and make them dismissed status
        /// </summary>
        /// <param name="service"></param>
        /// <param name="DeviceId"> guid of device</param>
        /// <param name="InspectionType">type of inspection</param>
        /// <param name="crmTrace"></param>
        public static void GetAllNRFViolationsForDevice(IOrganizationService service, Guid DeviceId,int InspectionType, Entity preImage,StringBuilder crmTrace)
        {
            try
            {
                DismissElevatorDOBViolationResponse response;
                //update the violation status to dismissed
                if (InspectionType==(int)ELV3InspectionType.CAT1)//only for cat1
                {
                    crmTrace.AppendLine("GetAllNRFViolationsForDevice Start");
                    ConditionExpression condition1 = new ConditionExpression(ViolationNumberAttributeNmaes.DeviceGuid, ConditionOperator.Equal, DeviceId);
                    ConditionExpression condition2 = new ConditionExpression(ViolationNumberAttributeNmaes.InspectionType, ConditionOperator.Equal, InspectionType);
                    ConditionExpression condition3 = new ConditionExpression(ViolationNumberAttributeNmaes.ViolationStatus, ConditionOperator.Equal, (int)ViolationStatus.Active);//Active Violation
                    ConditionExpression condition4 = new ConditionExpression(ViolationNumberAttributeNmaes.reportYear, ConditionOperator.Equal, preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.ReportYear));//dismiss only that report year Violation

                    QueryExpression query = new QueryExpression(ViolationNumberAttributeNmaes.EntityLogicalName);
                    query.ColumnSet = new ColumnSet(new string[] { ViolationNumberAttributeNmaes.Name, ViolationNumberAttributeNmaes.ViolationStatus });
                    query.Criteria = new FilterExpression(LogicalOperator.And)
                    {
                        Conditions =
                            {
                                condition1,
                                condition2,
                                condition3,
                                condition4

                            }
                    };

                    EntityCollection records = service.RetrieveMultiple(query);
                    crmTrace.AppendLine("Count of violation Records:" + records.Entities.Count);
                    
                    #region MAke CRM NRF Violations Dismissed
                    if (records != null && records.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Make violations Dismissed Start");
                        foreach (Entity violationRecord in records.Entities)
                        {
                            crmTrace.AppendLine("Call Dismiss Violation for each violation number:");
                            response = ViolationNumberHandler.DismissViolation(service, violationRecord, violationRecord, crmTrace);
                            crmTrace.AppendLine("Received response:" + response.MF_RETURN_CODE);
                            if (response.MF_RETURN_CODE == "0")
                            {
                                crmTrace.AppendLine("violation ID :" + violationRecord.Id);
                                violationRecord.SetAttributeValue(ViolationNumberAttributeNmaes.ViolationStatus, new OptionSetValue(2));//set dismissed
                                service.Update(violationRecord);
                            }

                                
                        }
                        crmTrace.AppendLine("Make violations Dismissed End");
                    }
                    #endregion
                }
               // throw new Exception("test");

            }


            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetAllNRFViolationsForDevice - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetAllNRFViolationsForDevice- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-GetAllNRFViolationsForDevice- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ViolationNumberHandler-GetAllNRFViolationsForDevice- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-GetAllNRFViolationsForDevice- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(DeviceId.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-GetAllNRFViolationsForDevice - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

        }

        /// <summary>
        /// Dismiss the violation when CAT 1 is accepted  or pvt QC  ELv29 is corrections accepted-violations dismissed
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity">ELV3,ELV29</param>
        /// <param name="preImage"> always PVT,QC ELV3 </param>
        /// <param name="crmTrace"></param>
        public static DismissElevatorDOBViolationResponse DismissViolation(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            string requestString = string.Empty;
            Guid requestGuid = new Guid();
            ExternalSystem_ElavatorViolationNumberMethods svc = new ExternalSystem_ElavatorViolationNumberMethods();
            DismissElevatorDOBViolationRequest request = new DismissElevatorDOBViolationRequest();
            DismissElevatorDOBViolationResponse response = new DismissElevatorDOBViolationResponse();
            try
            {

                #region Violations Dismissal from ELV3,ELV29
                if(targetEntity.LogicalName==ELV3InspectionAttributeNames.EntityLogicalName||targetEntity.LogicalName==ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.Name);
                    request.PC_DATA.PC_CRM_DOB_VIOL_NUMBER_FULL = preImage.GetAttributeValue<string>(ELV3InspectionAttributeNames.violationNumber);
                    if (preImage.GetAttributeValue<OptionSetValue>(ELV3InspectionAttributeNames.InspectionType).Value == (int)ELV3InspectionType.PVTInspection)
                    {
                        request.PC_DATA.PC_CRM_INSPECTION_CATEGORY = "P";
                    }
                    else
                    {
                        request.PC_DATA.PC_CRM_INSPECTION_CATEGORY = "Q";
                    }

                }
                #endregion
                #region Violation Number entity
                else
                {
                    request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID = preImage.GetAttributeValue<string>(ViolationNumberAttributeNmaes.Name);
                    request.PC_DATA.PC_CRM_DOB_VIOL_NUMBER_FULL = preImage.GetAttributeValue<string>(ViolationNumberAttributeNmaes.Name);
                    
                    request.PC_DATA.PC_CRM_INSPECTION_CATEGORY = "1";//for all other elevator type violations
                    
                    

                }
                #endregion
                request.PC_DATA.PC_CRM_BADGE_NUMBER = "DBNW";//for automatic dismissal
                request.PC_DATA.PC_CRM_DISMISSAL_DATE = DateTime.Now.ToString("yyyy-MM-dd");
                #region Record Dismissal Request in CRM
                requestString = ExternalSystem_ElavatorViolationNumberMethods.SerializeObject(request); //to get the requestin XML
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");

                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 1, true,string.Empty ,crmTrace);
                }
                else if(targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 2, true,string.Empty, crmTrace);
                }
                else
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 3, true, string.Empty,crmTrace);
                }
                #endregion
                // crmTrace.AppendLine("Request: " + requestString + "\nTrace: " + crmTrace);
                // throw new Exception("Request: " + requestString +"\nTrace: "+crmTrace);

                #region record Dismissal Response from BIS in CRM

                response = svc.AllElevatorDOBViolationMethods(request, response, request.PC_DATA.PC_CRM_VIOLATION_RECORD_ID, "CRM", "USERID", "Dismiss Violation Number");

                requestString = ExternalSystem_ElavatorViolationNumberMethods.SerializeObject(response); //to get the requestin XML
                requestString = requestString.Replace("\n", "").Replace("\r", "").Replace("\t", "");
                crmTrace.AppendLine("  return code" + response.MF_RETURN_CODE+response.MF_OVERALL_TEXT);
                //   throw new Exception("Test" + requestString + "  return code"+response.MF_RETURN_CODE );

                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 1, false, response.MF_OVERALL_TEXT, crmTrace);
                }
                else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 2, false, response.MF_OVERALL_TEXT, crmTrace);
                }
                else
                {
                    requestGuid = ViolationNumberHandler.CreateBISRequestResponseRecord(service, targetEntity, requestString, 3, false, response.MF_OVERALL_TEXT, crmTrace);
                }

                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-DismissViolation - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-DismissViolation- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-DismissViolation- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "- ViolationNumberHandler-DismissViolation- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + " -ViolationNumberHandler-DismissViolation- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", PluginNames.ELV3FeeCalculationPlugin + "-ViolationNumberHandler-DismissViolation - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;

            }
            return response;
        }
    }
}
