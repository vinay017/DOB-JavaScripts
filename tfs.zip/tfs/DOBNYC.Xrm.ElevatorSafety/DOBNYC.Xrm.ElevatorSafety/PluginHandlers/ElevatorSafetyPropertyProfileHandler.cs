﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;
using System.Collections.Generic;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
   public class ElevatorSafetyPropertyProfileHandler:PluginHandlerBase
    {
        /// <summary>
        /// Call this method to associate on Create (Pre-operation) of Elevator Safety Applications
        /// By Vinay 12/19/2017
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="customTrace"></param>
        public static Entity AssociatePropertyProfile(IOrganizationService service, Entity targetEntity, StringBuilder customTrace)
        {

            try
            {
                #region ELV3 Property Profile
                //Update Property Profile ID on look up of Boiler 
                if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("targetEntity.LogicalName: " + ELV3InspectionAttributeNames.EntityLogicalName);
                    if (targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.BIN))
                    {
                        if (!targetEntity.Attributes.Contains(ELV3InspectionAttributeNames.PropertyProfileLookup))
                        {
                            string BIN = targetEntity.GetAttributeValue<string>(ELV3InspectionAttributeNames.BIN);
                            customTrace.AppendLine("BIN: " + BIN);
                            EntityCollection existingPropertyProfiles = GetPropertyProfile(service, BIN, customTrace);
                            customTrace.AppendLine("existingPropertyProfiles Count: " + existingPropertyProfiles.Entities.Count);

                            if (existingPropertyProfiles != null && existingPropertyProfiles.Entities.Count > 0)
                            {
                                Entity propertyProfile = existingPropertyProfiles.Entities[0];
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.PropertyProfileLookup, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, propertyProfile.Id));
                            }
                            else
                            {

                                customTrace.AppendLine("No existing Property Profiles found for BIN: " + BIN);
                                Guid PropertyProfileGuid = CreatePropertyProfile(service, BIN, customTrace);
                                customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                if (PropertyProfileGuid != Guid.Empty)
                                {
                                    customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.PropertyProfileLookup, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, PropertyProfileGuid));
                                }
                            }
                        }

                    }
                }
                #endregion

                #region ELV29 Property Profile
                //Update Property Profile ID on look up of BNR
                if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("targetEntity.LogicalName: " + ELV29AffirimationAttributeNames.EntityLogicalName);
                    if (targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.BIN))
                    {
                        if (!targetEntity.Attributes.Contains(ELV29AffirimationAttributeNames.PropertyProfileLookup))
                        {
                            string BIN = targetEntity.GetAttributeValue<string>(ELV29AffirimationAttributeNames.BIN);
                            customTrace.AppendLine("BIN: " + BIN);
                            EntityCollection existingPropertyProfiles = GetPropertyProfile(service, BIN, customTrace);
                            customTrace.AppendLine("existingPropertyProfiles Count: " + existingPropertyProfiles.Entities.Count);

                            if (existingPropertyProfiles != null && existingPropertyProfiles.Entities.Count > 0)
                            {
                                Entity propertyProfile = existingPropertyProfiles.Entities[0];
                                CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.PropertyProfileLookup, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, propertyProfile.Id));
                            }
                            else
                            {

                                customTrace.AppendLine("No existing Property Profiles found for BIN: " + BIN);
                                Guid PropertyProfileGuid = CreatePropertyProfile(service, BIN, customTrace);
                                customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                if (PropertyProfileGuid != Guid.Empty)
                                {
                                    customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.PropertyProfileLookup, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, PropertyProfileGuid));
                                }
                            }
                        }

                    }
                }
                #endregion

                #region BO13E Property Profile
                //Update Property Profile ID on look up of BNR 
                //if (targetEntity.LogicalName == BO13EEntityAttributeName.EntityLogicalName)
                //{
                //    customTrace.AppendLine("targetEntity.LogicalName: " + BO13EEntityAttributeName.EntityLogicalName);
                //    if (targetEntity.Attributes.Contains(BO13EEntityAttributeName.Bin))
                //    {
                //        if (!targetEntity.Attributes.Contains(BO13EEntityAttributeName.PropertyProfile))
                //        {
                //            string BIN = targetEntity.GetAttributeValue<string>(BO13EEntityAttributeName.Bin);
                //            customTrace.AppendLine("BIN: " + BIN);
                //            EntityCollection existingPropertyProfiles = GetPropertyProfile(service, BIN, customTrace);
                //            customTrace.AppendLine("existingPropertyProfiles Count: " + existingPropertyProfiles.Entities.Count);

                //            if (existingPropertyProfiles != null && existingPropertyProfiles.Entities.Count > 0)
                //            {
                //                Entity propertyProfile = existingPropertyProfiles.Entities[0];
                //                CommonPluginLibrary.SetAttributeValue(targetEntity, BO13EEntityAttributeName.PropertyProfile, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, propertyProfile.Id));
                //            }
                //            else
                //            {

                //                customTrace.AppendLine("No existing Property Profiles found for BIN: " + BIN);
                //                Guid PropertyProfileGuid = CreatePropertyProfile(service, BIN, customTrace);
                //                customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                //                if (PropertyProfileGuid != Guid.Empty)
                //                {
                //                    customTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                //                    CommonPluginLibrary.SetAttributeValue(targetEntity, BO13EEntityAttributeName.PropertyProfile, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, PropertyProfileGuid));
                //                }
                //            }
                //        }

                //    }
                //}
                #endregion

                return targetEntity;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - AssociatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
        }

        public static EntityCollection GetPropertyProfile(IOrganizationService service, string BIN, StringBuilder crmTrace)
        {
            EntityCollection response = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start Getting Existing PropertyProfiles");
                ConditionExpression propertyCondition = CreateConditionExpression(PropertyProfileAttributeNames.EntityNameField, ConditionOperator.Equal, new string[] { BIN });
                response = RetrieveMultiple(service, PropertyProfileAttributeNames.EntityLogicalName, new string[] { PropertyProfileAttributeNames.dobnyc_Borough }, new ConditionExpression[] { propertyCondition }, LogicalOperator.And, PropertyProfileAttributeNames.CreatedOn, OrderType.Descending, 1);
                crmTrace.AppendLine("End Getting Existing PropertyProfiles");
                return response;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN, "CRM", "ElevatorSafetyPropertyProfileHandler - GetPropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }

        }

        public static Guid CreatePropertyProfile(IOrganizationService service, string BIN, StringBuilder crmTrace)
        {
            Byte[] bytes = new Byte[16];
            Guid newGuid = new Guid(bytes);
            try
            {
                crmTrace.AppendLine("CreatePropertyProfile started");
                crmTrace.AppendLine("newGuid: " + newGuid.ToString());
                #region Get Property Violation flags

                PropertyViolationRequest propertyViolationRequest = new PropertyViolationRequest();
                PropertyViolationResponse propertyViolationResponse = new PropertyViolationResponse();
                crmTrace.AppendLine("PropertyViolationRequest started");
                ExternalSystem_PropertyViolation svcPropertyViolation = new ExternalSystem_PropertyViolation();
                propertyViolationRequest.Bin = BIN;
                propertyViolationRequest.SourceChannel = "CRM";
                crmTrace.AppendLine("svcPropertyProfileRequestViolation started");
                propertyViolationResponse = svcPropertyViolation.GetPropertyViolation(propertyViolationRequest);
                crmTrace.AppendLine("svcPropertyProfileViolationRequest Ended");

                #endregion

                #region Property Profile
                PropertyProfileRequest propertyRequest = new PropertyProfileRequest();
                PropertyProfileResponse propertyResponse = new PropertyProfileResponse();
                crmTrace.AppendLine("PropertyProfileRequest started");
                ExternalSystem_PropertyProfile svcProperty = new ExternalSystem_PropertyProfile();
                propertyRequest.Bin = BIN;
                propertyRequest.SourceChannel = "CRM";
                crmTrace.AppendLine("svcPropertyProfileRequest started");
                propertyResponse = svcProperty.GetPropertyProfile(propertyRequest);
                crmTrace.AppendLine("svcPropertyProfileRequest Ended");
                crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                if (propertyResponse != null)
                {
                    if (string.IsNullOrEmpty(propertyResponse.ReturnError))
                    {
                        Entity propertyProfile = new Entity(PropertyProfileAttributeNames.EntityLogicalName);
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.EntityNameField.ToLower(), propertyResponse.Bin);
                        crmTrace.AppendLine("propertyResponse.Bin:" + propertyResponse.Bin);

                        if (propertyResponse.OtherBinsList != null && propertyResponse.OtherBinsList.Count > 0)
                        {
                            crmTrace.AppendLine("propertyResponse.OtherBinsList.Count:" + propertyResponse.OtherBinsList.Count);
                            List<string> otherBINS = propertyResponse.OtherBinsList;
                            string otherBINSString = string.Join(" ", otherBINS.ToArray());
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_AdditionalBINsforBuilding.ToLower(), otherBINSString);
                            crmTrace.AppendLine("propertyResponse.AditionalBINsForbuilding:" + otherBINSString);
                        }


                        if (propertyResponse.streetList != null && propertyResponse.streetList.Count > 0)
                        {
                            crmTrace.AppendLine("propertyResponse.streetList.Count:" + propertyResponse.streetList.Count);
                            List<string> streetList = propertyResponse.streetList;
                            string streetListString = string.Join(", ", streetList.ToArray());
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreets.ToLower(), streetListString);
                            crmTrace.AppendLine("propertyResponse.streetList:" + streetListString);
                        }


                        if (propertyResponse.SpecialArea != null && propertyResponse.SpecialArea.Count > 0)
                        {
                            crmTrace.AppendLine("propertyResponse.SpecialArea.Count" + propertyResponse.SpecialArea.Count);
                            List<string> specialAreaList = propertyResponse.SpecialArea;
                            string specialAreaListString = string.Join(", ", specialAreaList.ToArray());
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialAreaString.ToLower(), specialAreaListString);
                            crmTrace.AppendLine("propertyResponse.SpecialArea:" + specialAreaListString);
                        }

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Borough.ToLower(), new OptionSetValue(propertyResponse.Borough.ToLower() == BoroughNames.Bronx ? 2 : propertyResponse.Borough.ToLower() == BoroughNames.Brooklyn ? 3 : propertyResponse.Borough.ToLower() == BoroughNames.Manhattan ? 1 : propertyResponse.Borough.ToLower() == BoroughNames.Queens ? 4 : propertyResponse.Borough.ToLower() == BoroughNames.StatenIsland ? 5 : 1));
                        crmTrace.AppendLine("propertyResponse.Borough:" + propertyResponse.Borough);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CityOwned.ToLower(), propertyResponse.CityOwned);
                        crmTrace.AppendLine("propertyResponse.CityOwned:" + propertyResponse.CityOwned);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Condo.ToLower(), propertyResponse.Condo);
                        crmTrace.AppendLine("propertyResponse.Condo:" + propertyResponse.Condo);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1.ToLower(), propertyResponse.CrossStreet1);
                        crmTrace.AppendLine("propertyResponse.CrossStreet1:" + propertyResponse.CrossStreet1);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1Numbers.ToLower(), propertyResponse.CrossStreet1Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet1Numbers:" + propertyResponse.CrossStreet1Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2.ToLower(), propertyResponse.CrossStreet2);
                        crmTrace.AppendLine("propertyResponse.CrossStreet2:" + propertyResponse.CrossStreet2);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2Numbers.ToLower(), propertyResponse.CrossStreet2Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet2Numbers:" + propertyResponse.CrossStreet2Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3.ToLower(), propertyResponse.CrossStreet3);
                        crmTrace.AppendLine("propertyResponse.CrossStreet3:" + propertyResponse.CrossStreet3);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3Numbers.ToLower(), propertyResponse.CrossStreet3Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet3Numbers:" + propertyResponse.CrossStreet3Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4.ToLower(), propertyResponse.CrossStreet4);
                        crmTrace.AppendLine("propertyResponse.CrossStreet4:" + propertyResponse.CrossStreet4);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4Numbers.ToLower(), propertyResponse.CrossStreet4Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet4Numbers:" + propertyResponse.CrossStreet4Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet5.ToLower(), propertyResponse.CrossStreet5);
                        crmTrace.AppendLine("propertyResponse.CrossStreet5:" + propertyResponse.CrossStreet5);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet5Numbers.ToLower(), propertyResponse.CrossStreet5Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet5Numbers:" + propertyResponse.CrossStreet5Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet6.ToLower(), propertyResponse.CrossStreet6);
                        crmTrace.AppendLine("propertyResponse.CrossStreet6:" + propertyResponse.CrossStreet6);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet6Numbers.ToLower(), propertyResponse.CrossStreet6Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet6Numbers:" + propertyResponse.CrossStreet6Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBBuildingRemarks.ToLower(), propertyResponse.DOBBuildingRemarks);
                        crmTrace.AppendLine("propertyResponse.DOBBuildingRemarks:" + propertyResponse.DOBBuildingRemarks);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBSpecialPlaceName.ToLower(), propertyResponse.DOBSpecialPlaceName);
                        crmTrace.AppendLine("propertyResponse.DOBSpecialPlaceName:" + propertyResponse.DOBSpecialPlaceName);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower(), propertyResponse.EnvironmentalRestrictions);
                        crmTrace.AppendLine("propertyResponse.EnvironmentalRestrictions:" + propertyResponse.EnvironmentalRestrictions);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_GrandfatheredSign.ToLower(), propertyResponse.GrandfatheredSign);
                        crmTrace.AppendLine("propertyResponse.GrandfatheredSign:" + propertyResponse.GrandfatheredSign);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HouseNo.ToLower(), propertyResponse.HouseNumber);
                        crmTrace.AppendLine("propertyResponse.HouseNumber:" + propertyResponse.HouseNumber);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower(), propertyResponse.LandmarkStatus);
                        crmTrace.AppendLine("propertyResponse.LandmarkStatus:" + propertyResponse.LandmarkStatus);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LegalAdultUse.ToLower(), propertyResponse.LegalAdultUse);
                        crmTrace.AppendLine("propertyResponse.LegalAdultUse:" + propertyResponse.LegalAdultUse);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LocalLaw.ToLower(), propertyResponse.LocalLaw);
                        crmTrace.AppendLine("propertyResponse.LocalLaw:" + propertyResponse.LocalLaw);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LoftLaw.ToLower(), propertyResponse.LoftLaw);
                        crmTrace.AppendLine("propertyResponse.LoftLaw:" + propertyResponse.LoftLaw);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialDistrict.ToLower(), propertyResponse.SpecialDistrict);
                        crmTrace.AppendLine("propertyResponse.SpecialDistrict:" + propertyResponse.SpecialDistrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialStatus.ToLower(), propertyResponse.SpecialStatus);
                        crmTrace.AppendLine("propertyResponse.SpecialStatus:" + propertyResponse.SpecialStatus);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower(), propertyResponse.SRORestrict);
                        crmTrace.AppendLine("propertyResponse.SRORestrict:" + propertyResponse.SRORestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Street.ToLower(), propertyResponse.Street);
                        crmTrace.AppendLine("propertyResponse.Street:" + propertyResponse.Street);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetName.ToLower(), propertyResponse.StreetName);
                        crmTrace.AppendLine("propertyResponse.StreetName:" + propertyResponse.StreetName);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetNumbers.ToLower(), propertyResponse.StreetNumbers);
                        crmTrace.AppendLine("propertyResponse.StreetNumbers:" + propertyResponse.StreetNumbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TARestricted.ToLower(), propertyResponse.TARestrict);
                        crmTrace.AppendLine("propertyResponse.TARestrict:" + propertyResponse.TARestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_UBRestricted.ToLower(), propertyResponse.UBRestrict);
                        crmTrace.AppendLine("propertyResponse.UBRestrict:" + propertyResponse.UBRestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Vacant.ToLower(), propertyResponse.Vacant);
                        crmTrace.AppendLine("propertyResponse.Vacant:" + propertyResponse.Vacant);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Zip.ToLower(), propertyResponse.Zipcode);
                        crmTrace.AppendLine("propertyResponse.Zipcode:" + propertyResponse.Zipcode);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Latitude, Convert.ToDouble(propertyViolationResponse.Latitude));
                        crmTrace.AppendLine("propertyViolationResponse.Latitude:" + propertyViolationResponse.Latitude);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Longitude, Convert.ToDouble(propertyViolationResponse.Longitude));
                        crmTrace.AppendLine("propertyViolationResponse.Longitude:" + propertyViolationResponse.Longitude);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea1, Convert.ToString(propertyViolationResponse.PSpecialArea1));
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea1:" + propertyViolationResponse.PSpecialArea1);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea2, propertyViolationResponse.PSpecialArea2);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea2:" + propertyViolationResponse.PSpecialArea2);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea3, propertyViolationResponse.PSpecialArea3);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea3:" + propertyViolationResponse.PSpecialArea3);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea4, propertyViolationResponse.PSpecialArea4);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea4:" + propertyViolationResponse.PSpecialArea4);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea5, propertyViolationResponse.PSpecialArea5);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea5:" + propertyViolationResponse.PSpecialArea5);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.TransitAuthority, propertyViolationResponse.TransitAuthority);
                        crmTrace.AppendLine("propertyViolationResponse.TransitAuthority:" + propertyViolationResponse.TransitAuthority);

                        if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict1))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict1, propertyViolationResponse.SpecialDistrict1);
                        if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict2))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict2, propertyViolationResponse.SpecialDistrict2);
                        if (!string.IsNullOrEmpty(propertyViolationResponse.LoftFlag))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.LoftFlag, propertyViolationResponse.LoftFlag);
                        crmTrace.AppendLine("propertyViolationResponse.LoftFlag");
                        if (!string.IsNullOrEmpty(propertyResponse.BuildingsOnLot))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_BuildingsonLot.ToLower(), Convert.ToInt32(propertyResponse.BuildingsOnLot));
                        if (!string.IsNullOrEmpty(propertyResponse.TaxBlock))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxBlock.ToLower(), Convert.ToInt32(propertyResponse.TaxBlock));
                        if (!string.IsNullOrEmpty(propertyResponse.HealthArea))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HealthArea.ToLower(), Convert.ToInt32(propertyResponse.HealthArea));
                        if (!string.IsNullOrEmpty(propertyResponse.CommunityBoard))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CommunityBoard.ToLower(), Convert.ToInt32(propertyResponse.CommunityBoard));
                        crmTrace.AppendLine("propertyResponse.CommunityBoard");
                        if (!string.IsNullOrEmpty(propertyResponse.CensusTract))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CensusTractString.ToLower(), propertyResponse.CensusTract);
                        if (!string.IsNullOrEmpty(propertyResponse.TaxLot))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxLot.ToLower(), Convert.ToInt32(propertyResponse.TaxLot));

                        if (!string.IsNullOrEmpty(propertyResponse.TidalWetlands))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.TidalWetlandsMapCheck, propertyResponse.TidalWetlands);
                        if (!string.IsNullOrEmpty(propertyResponse.FreshwaterWetlands))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.FreshwaterWetlandsMapCheck, propertyResponse.FreshwaterWetlands);
                        if (!string.IsNullOrEmpty(propertyResponse.CoastalErosionHazardArea))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CoastalErosionHazardAreaMapCheck, propertyResponse.CoastalErosionHazardArea);
                        if (!string.IsNullOrEmpty(propertyResponse.SpecialFloodHazardArea))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialFloodHazardAreaCheck, propertyResponse.SpecialFloodHazardArea);
                        if (!string.IsNullOrEmpty(propertyResponse.VlFinaOccpncy))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.DepartmentofFinanceBuildingClassification, propertyResponse.VlFinaOccpncy);

                        crmTrace.AppendLine("PropertyProfileRequest Create Started : " + propertyResponse.Bin);
                        newGuid = service.Create(propertyProfile);
                        crmTrace.AppendLine("PropertyProfile Guid: " + newGuid.ToString());
                        crmTrace.AppendLine("PropertyProfileRequest Create End: " + propertyResponse.Bin);
                    }
                    //CommonPluginLibrary.SetAttributeValue(targetEntity, TR6AttributeNames.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, newGuid)); // we are setting value of lookup so next step will be update since we are calling this on post operation
                    //service.Update(targetEntity);
                }
                #endregion
                crmTrace.AppendLine("CreatePropertyProfile End : " + propertyResponse.Bin);
                return newGuid;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(newGuid.ToString(), "CRM", "ElevatorSafetyPropertyProfileHandler - CreatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }

        }

    }
}
