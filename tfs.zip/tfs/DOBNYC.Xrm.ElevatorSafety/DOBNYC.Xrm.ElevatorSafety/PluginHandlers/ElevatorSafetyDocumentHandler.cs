﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
   public class ElevatorSafetyDocumentHandler:PluginHandlerBase
    {
        public static void AssociateDocumentsOnTaskCreation(IOrganizationService service, Entity targetEntity, EntityReference regardingObj, StringBuilder customTrace)
        {
            try
            {
                #region ELV3
                if (regardingObj.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                {
                    ConditionExpression documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.ELV3, ConditionOperator.Equal, new string[] { regardingObj.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.ELV3 }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();
                    customTrace.AppendLine("Got all the documents for the regardingObjectId(ELv3) in task");
                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

                        customTrace.AppendLine("Associated Document with target Elevataor Safety Task based on Status");
                        int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ElevatorSafetyTaskAttributeNames.ReportStatus).Value;
                        if (ReportStatus == (int)ELV3ReportStatus.QASupervisorReview)
                            service.Associate(ElevatorSafetyTaskAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(ElevatorSafetyTaskAttributeNames.QASupervisorDocumentListRelationship), documents);
                        if (ReportStatus == (int)ELV3ReportStatus.QAReview)
                            service.Associate(ElevatorSafetyTaskAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(ElevatorSafetyTaskAttributeNames.QAClerkDocumentListRelationship), documents);
                    }
                }
                #endregion 

                #region ELV29
                if (regardingObj.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                {
                    ConditionExpression documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.ELV29, ConditionOperator.Equal, new string[] { regardingObj.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.ELV29 }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();
                    customTrace.AppendLine("Got all the documents for the regardingObjectId(ELV29) in task");
                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

                        customTrace.AppendLine("Associated Document with target Eleavtor Safety Task based on Status");
                        int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(ElevatorSafetyTaskAttributeNames.ReportStatus).Value;
                        if (ReportStatus == (int)ELV3ReportStatus.QASupervisorReview)
                            service.Associate(ElevatorSafetyTaskAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(ElevatorSafetyTaskAttributeNames.QASupervisorDocumentListRelationship), documents);
                        if (ReportStatus == (int)ELV3ReportStatus.QAReview)
                            service.Associate(ElevatorSafetyTaskAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(ElevatorSafetyTaskAttributeNames.QAClerkDocumentListRelationship), documents);
                        
                    }
                }
                #endregion 

                #region 
                //if (regardingObj.LogicalName == BO13EEntityAttributeName.EntityLogicalName)
                //{
                //    ConditionExpression documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.BO13E, ConditionOperator.Equal, new string[] { regardingObj.Id.ToString() });
                //    EntityCollection documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.BO13E }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                //    EntityReferenceCollection documents = new EntityReferenceCollection();
                //    customTrace.AppendLine("Got all the documents for the regardingObjectId(BO13E) in task");
                //    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                //    {
                //        customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
                //        for (int i = 0; i < documentResponse.Entities.Count; i++)
                //            documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

                //        customTrace.AppendLine("Associated Document with target Boiler Task based on Status");
                //        int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(BoilerTaskEntityAttributeNames.BO13EStatus).Value;
                //        if (ReportStatus == (int)BO13EFilingStatus.QASupervisorReview)
                //            service.Associate(BoilerTaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship("dobnyc_bdl_qastask"), documents);
                //        if (ReportStatus == (int)BO13EFilingStatus.QAReview)
                //            service.Associate(BoilerTaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship("dobnyc_bdl_qatask"), documents);
                //    }
                //}
                #endregion 

                #region HCN
                //if (regardingObj.LogicalName == HCNEntityAttributeName.EntityLogicalName)
                //{
                //    ConditionExpression documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.HCN, ConditionOperator.Equal, new string[] { regardingObj.Id.ToString() });
                //    EntityCollection documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.HCN }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                //    EntityReferenceCollection documents = new EntityReferenceCollection();
                //    customTrace.AppendLine("Got all the documents for the regardingObjectId(HCN) in task");
                //    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                //    {
                //        customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
                //        for (int i = 0; i < documentResponse.Entities.Count; i++)
                //            documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

                //        customTrace.AppendLine("Associated Document with target Boiler Task based on Status");
                //        int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(BoilerTaskEntityAttributeNames.HCNStatus).Value;
                //        if (ReportStatus == (int)HCNFilingStatus.PendingInspection)
                //            service.Associate(BoilerTaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship("dobnyc_bdl_qastask"), documents);
                //        if (ReportStatus == (int)HCNFilingStatus.Inspection)
                //            service.Associate(BoilerTaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship("dobnyc_bdl_inspectiontask"), documents);
                //    }
                //}
                #endregion


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskCreation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }

        }


        //public static void AssociateDocumentsOnTaskComplete(IOrganizationService service, Entity targetEntity, EntityReference regardingObj, StringBuilder customTrace)
        //{
        //    try
        //    {
        //        #region Initiate Variable
        //        ConditionExpression documentCondition = new ConditionExpression();
        //        EntityCollection documentResponse = new EntityCollection();
        //        EntityReferenceCollection documents = new EntityReferenceCollection();
        //        #endregion

        //        #region BO13E
        //        if (regardingObj.LogicalName == BO13EEntityAttributeName.EntityLogicalName)
        //        {
        //            int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(BoilerTaskEntityAttributeNames.BO13EStatus).Value;
        //            if (ReportStatus == (int)BO13EFilingStatus.QASupervisorReview)
        //            {
        //                documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.QASupervisorTask, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
        //                documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.BO13E }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
        //            }
        //            if (ReportStatus == (int)BO13EFilingStatus.QAReview)
        //            {
        //                documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.QAReviewTask, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
        //                documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.BO13E }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);

        //            }
        //            customTrace.AppendLine("Got all the documents in task for the regardingObjectId(BO13E) ");
        //            if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
        //            {
        //                customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
        //                for (int i = 0; i < documentResponse.Entities.Count; i++)
        //                    documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

        //                customTrace.AppendLine("Associated Document with regarding BO13E based");
        //                service.Associate(BO13EEntityAttributeName.EntityLogicalName, regardingObj.Id, new Relationship("dobnyc_dobnyc_bo13e_dobnyc_boilerdocumentlist_bdl_BO13E"), documents);
        //            }
        //        }
        //        #endregion

        //        #region HCN
        //        if (regardingObj.LogicalName == HCNEntityAttributeName.EntityLogicalName)
        //        {
        //            int ReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(BoilerTaskEntityAttributeNames.HCNStatus).Value;
        //            if (ReportStatus == (int)HCNFilingStatus.PendingInspection)
        //            {
        //                documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.QASupervisorTask, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
        //                documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.BO13E }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
        //            }
        //            if (ReportStatus == (int)HCNFilingStatus.Inspection)
        //            {
        //                documentCondition = CreateConditionExpression(ElevatorSafetyDocumentListEntityAttributeNames.InspectorReviewTask, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
        //                documentResponse = RetrieveMultiple(service, ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, new string[] { ElevatorSafetyDocumentListEntityAttributeNames.BO13E }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);

        //            }
        //            customTrace.AppendLine("Got all the documents in task for the regardingObjectId(HCN) ");
        //            if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
        //            {
        //                customTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count.ToString());
        //                for (int i = 0; i < documentResponse.Entities.Count; i++)
        //                    documents.Add(new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, documentResponse.Entities[i].Id));

        //                customTrace.AppendLine("Associated Document with regarding HCN based");
        //                service.Associate(HCNEntityAttributeName.EntityLogicalName, regardingObj.Id, new Relationship("dobnyc_dobnyc_boilerhazardousconditionnotification_dobnyc_boilerdocumentlist_bdl_HCN"), documents);
        //            }
        //        }
        //        #endregion


        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", null, customTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //        //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", null, customTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", null, customTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DocumentListAssociationHandler - AssociateDocumentsOnTaskComplete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
        //    }

        //}


        //public static void CreateDocumentlistVersionsOnUploadToDocumentum(IOrganizationService service, Entity targetEntity, Entity PreImage, StringBuilder customTrace)
        //{

        //    #region Variable Declaration
        //    Entity createDocumentList = null;
        //    #endregion
        //    customTrace.AppendLine("CreateDocumentlistVersionsOnUploadToDocumentum - Start");
        //    if (PreImage.Attributes.Contains(ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl) && targetEntity.Attributes.Contains(ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl))
        //    {
        //        if (!string.Equals(PreImage.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl], targetEntity.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl]))
        //        {
        //            customTrace.AppendLine("Document URL Changed");
        //            createDocumentList = new Entity(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName);
        //            createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.DocumentName, PreImage.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentName].ToString());
        //            createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl, PreImage.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentUrl].ToString());
        //            if (PreImage.Attributes.Contains(ElevatorSafetyDocumentListEntityAttributeNames.DocumentType))
        //                createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.DocumentType, new EntityReference(BoilerDocumentTypeEntityAttributeNames.EntityLogicalName, ((EntityReference)PreImage.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentType]).Id));
        //            createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.DocumentSource, new OptionSetValue(2));
        //            createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.ParentDocumentList, new EntityReference(ElevatorSafetyDocumentListEntityAttributeNames.EntityLogicalName, targetEntity.Id));
        //            createDocumentList.Attributes.Add(ElevatorSafetyDocumentListEntityAttributeNames.DocumentStatus, new OptionSetValue(((OptionSetValue)PreImage.Attributes[ElevatorSafetyDocumentListEntityAttributeNames.DocumentStatus]).Value));
        //            customTrace.AppendLine("Create Document List - Start");
        //            service.Create(createDocumentList);
        //            customTrace.AppendLine("Create Document List - End");
        //        }

        //    }
        //    customTrace.AppendLine("CreateDocumentlistVersionsOnUploadToDocumentum - End");
        //}

    }
}
