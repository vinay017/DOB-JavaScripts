﻿using DOB.Logging;
using DOBNYC.Xrm.ElevatorSafety.Common;
using DOBNYC.Xrm.ElevatorSafety.Helpers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.Xrm.ElevatorSafety.PluginHandlers
{
    class ElevatorSafetyTrackingNumberHandler : PluginHandlerBase
    {
        /// <summary>
        /// This method is used to generate tracking numbers for all Elevator Safety Entities
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity GenerateAutoNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            #region Declare Variable
            string TrackingNumberFormatted = string.Empty;
            decimal facadesAutoNumber = 0;
            int facadesPaddingNumber = 0;
            char facadesPaddingChar = 'X';
            string trackingNumber = "{0}{1}";
            string deviceid = string.Empty;
            #endregion

            try
            {
                crmTrace.AppendLine("Begin: Retrieve Auto Number Entity");
                crmTrace.AppendLine(targetEntity.LogicalName);

                EntityCollection response = GetAutoNumberEntityInfo(service, targetEntity, crmTrace);
                crmTrace.AppendLine(response.Entities.Count.ToString() + " number of auto number record!");
                crmTrace.AppendLine("End: Retrieve Auto Number Entity");
                if (response != null && response.Entities != null && response.Entities.Count > 0)
                {
                    crmTrace.AppendLine("RecievedResponse: Retrieve Auto Number Entity");
                    if (response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesCounter) && response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesPaddingNumber) && response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesPaddingCharacter))
                    {
                        facadesAutoNumber = decimal.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesCounter].ToString());
                        crmTrace.AppendLine("facadesAutoNumber" + facadesAutoNumber);
                        facadesPaddingNumber = int.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesPaddingNumber].ToString());
                        crmTrace.AppendLine("facadesPaddingNumber" + facadesPaddingNumber);
                        facadesPaddingChar = char.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesPaddingCharacter].ToString());
                        crmTrace.AppendLine("facadesPaddingChar" + facadesPaddingChar);
                    }
                    #region Update Counters
                    UpdateCounter(service, facadesAutoNumber, response);
                    #endregion

                    #region ELV3
                    if (targetEntity.LogicalName == ELV3InspectionAttributeNames.EntityLogicalName)
                    {

                        trackingNumber = "{0}-{1}-{2}"; //reportyear-deviceid
                        if (targetEntity.Contains(ELV3InspectionAttributeNames.DeviceIdLookup) && targetEntity[ELV3InspectionAttributeNames.DeviceIdLookup] != null && targetEntity.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup).Id != null)
                        {
                            EntityReference elevatorMasterReference = targetEntity.GetAttributeValue<EntityReference>(ELV3InspectionAttributeNames.DeviceIdLookup);
                            Entity Elevator = Retrieve(service, new string[] { ElevatorMasterDevice.DeviceNo }, elevatorMasterReference.Id, elevatorMasterReference.LogicalName);
                            deviceid = Elevator.Contains(ElevatorMasterDevice.DeviceNo) ? Elevator.GetAttributeValue<string>(ElevatorMasterDevice.DeviceNo) : "No Device Number";
                        }
                        else
                        {
                            deviceid = "No Device Number";
                        }



                        TrackingNumberFormatted = String.Format(trackingNumber, "ELV3", deviceid, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.Name, TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3InspectionAttributeNames.TrackingNumber, TrackingNumberFormatted);
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    #region ELV36 TNF
                    else if (targetEntity.LogicalName == ELV36TestNotificationAttributeNames.EntityLogicalName)
                    {
                        trackingNumber = "{0}-{1}-{2}";
                        if (targetEntity.Contains(ELV36TestNotificationAttributeNames.DeviceIdLookup) && targetEntity[ELV36TestNotificationAttributeNames.DeviceIdLookup] != null && targetEntity.GetAttributeValue<EntityReference>(ELV36TestNotificationAttributeNames.DeviceIdLookup).Id != null)
                        {
                            EntityReference elevatorMasterReference = targetEntity.GetAttributeValue<EntityReference>(ELV36TestNotificationAttributeNames.DeviceIdLookup);
                            Entity Elevator = Retrieve(service, new string[] { ElevatorMasterDevice.DeviceNo }, elevatorMasterReference.Id, elevatorMasterReference.LogicalName);
                            deviceid = Elevator.Contains(ElevatorMasterDevice.DeviceNo) ? Elevator.GetAttributeValue<string>(ElevatorMasterDevice.DeviceNo) : "No Device Number";
                        }
                        else
                        {
                            deviceid = "No Device Number";
                        }

                        //DateTime inspectionDate = targetEntity.GetAttributeValue<DateTime>(BoilerNotRegisteredEntityAttributeName.InspectionDate);


                        TrackingNumberFormatted = String.Format(trackingNumber, "ELV36", deviceid, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV36TestNotificationAttributeNames.Name, TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV36TestNotificationAttributeNames.TrackingNumber, TrackingNumberFormatted);
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    #region ELV29
                    else if (targetEntity.LogicalName == ELV29AffirimationAttributeNames.EntityLogicalName)
                    {


                        trackingNumber = "{0}-{1}-{2}";

                        if (targetEntity.Contains(ELV29AffirimationAttributeNames.DeviceIdLookup) && targetEntity[ELV29AffirimationAttributeNames.DeviceIdLookup] != null && targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.DeviceIdLookup).Id != null)
                        {
                            EntityReference elevatorMasterReference = targetEntity.GetAttributeValue<EntityReference>(ELV29AffirimationAttributeNames.DeviceIdLookup);
                            Entity Elevator = Retrieve(service, new string[] { ElevatorMasterDevice.DeviceNo }, elevatorMasterReference.Id, elevatorMasterReference.LogicalName);
                            deviceid = Elevator.Contains(ElevatorMasterDevice.DeviceNo) ? Elevator.GetAttributeValue<string>(ElevatorMasterDevice.DeviceNo) : "No Device Number";
                        }
                        else
                        {
                            deviceid = "No Device Number";
                        }

                        TrackingNumberFormatted = String.Format(trackingNumber, "ELV29", deviceid, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.Name, TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV29AffirimationAttributeNames.TrackingNumber, TrackingNumberFormatted);
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    #region GroupNumber 
                    else if (targetEntity.LogicalName == GroupNumber.EntityLogicalName)
                    {
                        trackingNumber = "{0}-{1}{2}";//ELV3-Boroughcounter eg:elv3-M000001
                        string Borough = string.Empty;
                        switch(targetEntity.GetAttributeValue<OptionSetValue>(GroupNumber.Borough).Value)
                        {
                            case (int)Boroughs.MANHATTAN:
                                {
                                    Borough = "M";
                                    break;
                                }
                            case (int)Boroughs.BRONX:
                                {
                                    Borough = "X";
                                    break;
                                }
                            case (int)Boroughs.BROOKLYN:
                                {
                                    Borough = "B";
                                    break;
                                }
                            case (int)Boroughs.QUEENS:
                                {
                                    Borough = "Q";
                                    break;
                                }
                            case (int)Boroughs.STATENISLAND:
                                {
                                    Borough = "S";
                                    break;
                                }
                            default:
                                {
                                    Borough = "No Borough";
                                    break;
                                }
                        }



                        TrackingNumberFormatted = String.Format(trackingNumber,targetEntity.FormattedValues[GroupNumber.safetyFormFor].ToString() , Borough,Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, GroupNumber.Name, TrackingNumberFormatted);
                       
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion


                    #region ELV3 Defect
                    else if (targetEntity.LogicalName == ELV3Defect.EntityLogicalName)
                    {


                        trackingNumber = "{0}-{1}-{2}";

                        if (targetEntity.Contains(ELV3Defect.ELV3Lookup) && targetEntity[ELV3Defect.ELV3Lookup] != null && targetEntity.GetAttributeValue<EntityReference>(ELV3Defect.ELV3Lookup).Id != null)
                        {
                            EntityReference ELV3LookupReference = targetEntity.GetAttributeValue<EntityReference>(ELV3Defect.ELV3Lookup);
                            Entity Elevator = Retrieve(service, new string[] { ELV3InspectionAttributeNames.Name }, ELV3LookupReference.Id, ELV3LookupReference.LogicalName);
                            deviceid = Elevator.Contains(ELV3InspectionAttributeNames.Name) ? Elevator.GetAttributeValue<string>(ELV3InspectionAttributeNames.Name) : "No Device Number";
                        }
                        else if (targetEntity.Contains(ELV3Defect.ELV29Lookup) && targetEntity[ELV3Defect.ELV29Lookup] != null && targetEntity.GetAttributeValue<EntityReference>(ELV3Defect.ELV29Lookup).Id != null)
                        {
                            EntityReference ELV29LookupReference = targetEntity.GetAttributeValue<EntityReference>(ELV3Defect.ELV29Lookup);
                            Entity Elevator = Retrieve(service, new string[] { ELV29AffirimationAttributeNames.Name }, ELV29LookupReference.Id, ELV29LookupReference.LogicalName);
                            deviceid = Elevator.Contains(ELV29AffirimationAttributeNames.Name) ? Elevator.GetAttributeValue<string>(ELV29AffirimationAttributeNames.Name) : "No Device Number";
                        }
                        else
                        {
                            deviceid = "No Device Number";
                        }

                        TrackingNumberFormatted = String.Format(trackingNumber, "Defect", deviceid, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ELV3Defect.Name, TrackingNumberFormatted);

                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    //#region Defect
                    //if (targetEntity.LogicalName == DefectEntityAttributeName.EntityLogicalName)
                    //{
                    //    TrackingNumberFormatted = String.Format(trackingNumber, "D", Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                    //    crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, DefectEntityAttributeName.DefectID, TrackingNumberFormatted);
                    //    crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    //}
                    //#endregion

                    //#region Report Defect
                    //if (targetEntity.LogicalName == ReportDefectEntityAttributeName.EntityLogicalName)
                    //{
                    //    TrackingNumberFormatted = String.Format(trackingNumber, "RD", Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                    //    crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, ReportDefectEntityAttributeName.Id, TrackingNumberFormatted);
                    //    crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    //}
                    //#endregion

                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
                //throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
                //  throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GenerateAutoNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
                //throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            return targetEntity;
        }

        public static EntityCollection GetAutoNumberEntityInfo(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression autoNumberCondition = CreateConditionExpression(AutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { targetEntity.LogicalName });
                crmTrace.AppendLine(autoNumberCondition.AttributeName + " " + autoNumberCondition.ToString() + " " + autoNumberCondition.Operator);
                crmTrace.AppendLine(AutoNumberEntityAttribute.EntityLogicalName);
                EntityCollection response = RetrieveMultiple(service, AutoNumberEntityAttribute.EntityLogicalName, new string[] { AutoNumberEntityAttribute.FacadesCounter, AutoNumberEntityAttribute.FacadesPaddingNumber, AutoNumberEntityAttribute.FacadesPaddingCharacter }, new ConditionExpression[] { autoNumberCondition }, LogicalOperator.And);
                crmTrace.AppendLine(response.Entities.Count.ToString());
                return response;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }

        }

        public static void UpdateCounter(IOrganizationService service, decimal facadesAutoNumber, EntityCollection response)
        {
            try
            {
                Entity autoNumber = new Entity();
                autoNumber.LogicalName = AutoNumberEntityAttribute.EntityLogicalName;
                autoNumber.Attributes.Add(AutoNumberEntityAttribute.FacadesCounter, (facadesAutoNumber + 1));
                autoNumber.Id = response.Entities[0].Id;
                UpdateEntity(service, autoNumber);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "ElevatorSafetyTrackingNumberHandler - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex.ToString());
            }
        }


    }
}

