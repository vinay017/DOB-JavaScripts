﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_PropertyProfile
    {
        StringBuilder Trace = new StringBuilder();

        public PropertyProfileResponse GetPropertyProfile(PropertyProfileRequest request)
        {
            PropertyProfileResponse response = new PropertyProfileResponse();

            try
            {
                Trace.AppendLine("GetPropertyProfile Started!");
                string requestBuilder = string.Empty;
                if (request != null)
                {
                    if (!string.IsNullOrEmpty(request.Bin) && string.IsNullOrEmpty(request.Borough) && string.IsNullOrEmpty(request.HouseNumber) && string.IsNullOrEmpty(request.StreetName))
                    {
                        Trace.AppendLine("RequestBuilder Started!");
                        requestBuilder = MessageStrings.MXBI_BIS_PROPERTY_DATA_PC.Replace(RequestAttributes.PRM_BUILDNYC_BIN, request.Bin.Trim());
                        Trace.AppendLine("RequestBuilder End");
                        Trace.AppendLine("RequestBuilder: " + requestBuilder);
                        response = GetExternalSystemResponse(requestBuilder);
                    }
                
                if (string.IsNullOrEmpty(request.Bin) && !string.IsNullOrEmpty(request.Borough) && !string.IsNullOrEmpty(request.HouseNumber) && !string.IsNullOrEmpty(request.StreetName))
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_BIS_PROPERTY_DATA_PC_ADDRESS.Replace(RequestAttributes.PRM_BUILDNYC_BOROUGH, request.Borough.Trim());
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_BUILDNYC_HOUSENO, request.HouseNumber.Trim());
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_BUILDNYC_STREET, request.StreetName.Trim());
                   Trace.AppendLine("RequestBuilder End");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder);
                    response = GetExternalSystemResponse(requestBuilder);
                }
            }

                Trace.AppendLine("GetPropertyProfile End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetPropertyProfile", Trace.ToString(), " Property Profile trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetPropertyProfile", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_PropertyProfile Class - GetPropertyProfile Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }

        }

        internal PropertyProfileResponse GetExternalSystemResponse(string requestObj)
        {
            PropertyProfileResponse response = new PropertyProfileResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj); // SampleData.AddressValidation; //string.Empty;

                if (Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.ErrorCode) == "P")
                {
                    response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.ErrorCode);
                    response.ReturnError = "Protected Property";
                    return response;
                }
                    response.ReturnError = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.ErrorMsg);
                    response.Bin = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlBin);
                    response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumbHous);
                    response.StreetName = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.NmStrt);
                    response.Borough = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.NmBoro);
                    response.Zipcode = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumbZip);
                    response.HealthArea = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlHlthArea); //Need to convert Number format

                    string censusTractUnformatted = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlCensTract);
                    if (censusTractUnformatted.Length <= 3)
                    {
                        response.CensusTract = censusTractUnformatted; //No formatting needed
                    }
                    else
                    {
                    response.CensusTract = censusTractUnformatted.Replace(",", "").Insert(censusTractUnformatted.Length-2, ".");
                    }


                    response.CommunityBoard = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlCommBoard);
                    response.BuildingsOnLot = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.NumStruct);
                    response.TaxLot = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlTaxLot);
                    response.TaxBlock = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlTaxBlock); //Need to convert Number format
                    response.Condo = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.CondoFlagText);
                    response.Vacant = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PVacant);
                    response.Street = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet1);
                    #region Format VlNumber - May come formate like 0000000000XX+00000000YY
                    string st = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber1);
                    string st1 = null;
                    string st2 = null;
                    if (st.IndexOf("+") != -1)
                    {
                        st1 = st.Substring(0, st.IndexOf("+"));
                        st2 = st.Substring(st.IndexOf("+") + 1);
                        response.StreetNumbers = Convert.ToInt32(st1) + " - " + Convert.ToInt32(st2);
                    }
                    else
                    {
                        response.StreetNumbers = st;
                    }
                    #endregion
                    response.CrossStreet1 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet1);
                    response.CrossStreet2 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet2);
                    response.CrossStreet3 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet3);
                    response.CrossStreet4 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet4);
                    response.CrossStreet5 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet5);
                    response.CrossStreet6 = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlStreet6);
                    //Assign formatted value from VlNumber1
                    response.CrossStreet1Numbers = response.StreetNumbers;// Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber1);
                    response.CrossStreet2Numbers = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber2);
                    response.CrossStreet3Numbers = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber3);
                    response.CrossStreet4Numbers = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber4);
                    response.CrossStreet5Numbers = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber5);
                    response.CrossStreet6Numbers = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlNumber6);
                    response.DOBSpecialPlaceName = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.NmSpclPlace);
                    response.DOBBuildingRemarks = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PBuildingRemarks);
                    response.LandmarkStatus = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.StLandMark);

                    response.SpecialStatus = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PSpecialStatus);
                    if (response.SpecialStatus.Equals("BIN"))
                    {
                        response.SpecialStatus = "BIN OBSOLETE";
                    }
                    response.LocalLaw = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PLocalLawTrans);
                    response.LoftLaw = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PLoftFlagTransOld) + " " + Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PEmpty1);
                    response.SRORestrict = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PSroTrans);

                    string taRestrict = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PTaTrans);
                    response.TARestrict = taRestrict.Equals("7") ? "7-line extension" : taRestrict;

                    response.UBRestrict = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PUbTrans);
                    response.DotProtectedStreet = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PUbTrans).Equals("N") ? "N/A" : "YES";
                    response.AffordableHousing = DescYNCode(Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PAffordableHousing));
                    response.ScaUpk = DescYNCode(Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PScaUpkFlag));
                    response.PDHSFacility = DescYNCode(Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PDHSFacility));

                    response.EnvironmentalRestrictions = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PLittleE);
                    response.GrandfatheredSign = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.GrandSign);
                    response.LegalAdultUse = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PAdultUseFlagTrans);
                    response.CityOwned = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PCityOwnedFlagTrans);
                    //response.AditionalBINsForbuilding =  Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.bi 
                    response.SpecialDistrict = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PFinZoneSpecDist1Exp);
                    response.VlFinaOccpncy = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.VlFinaOccpncy);
                    response.SpecialFloodHazardArea = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.SpecialFloodHazardArea);
                    response.CoastalErosionHazardArea = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PCEHAFlag);
                    response.FreshwaterWetlands = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PFWWFlag);
                    response.TidalWetlands = Common.GetAttributeValueFromResponse(responseString, PropertyProfileResponseAttributesTags.PTCWFlag);

                    Trace.AppendLine("Response BIN: " + response.Bin.ToString());
                    XmlDocument xDoc = new XmlDocument();

                    xDoc.LoadXml(responseString);
                    XmlElement root = xDoc.DocumentElement;
                    //XmlNodeList lotArrayTagList = root.GetElementsByTagName("LotArray");
                    XmlNodeList otherBinsTagList = root.GetElementsByTagName("OtherBin");
                    XmlNodeList outCrossTagList = root.GetElementsByTagName("Street");

                    if (otherBinsTagList.Count > 0)
                    {
                        if (otherBinsTagList[0].InnerXml != "NONE")
                        {
                            response.OtherBinsList = new System.Collections.Generic.List<string>();
                            for (int i = 0; i < otherBinsTagList.Count; i++)
                            {
                                response.OtherBinsList.Add(otherBinsTagList[i].InnerXml.Replace(",", ""));
                            }
                        }
                    }

                    if (outCrossTagList.Count > 0)
                    {
                        if (outCrossTagList[0].InnerXml != "NONE")
                        {
                            response.streetList = new System.Collections.Generic.List<string>();
                            for (int i = 0; i < outCrossTagList.Count; i++)
                            {
                                response.streetList.Add(outCrossTagList[i].InnerXml.Replace(",", ""));
                            }
                        }
                    }

                XmlNodeList specialAreaTagList = root.GetElementsByTagName("PSpecArea");
                if (specialAreaTagList.Count > 0)
                {
                    if (specialAreaTagList[0].InnerXml != "NONE")
                    {
                        response.SpecialArea = new System.Collections.Generic.List<string>();
                        for (int i = 0; i < specialAreaTagList.Count; i++)
                        {
                            response.SpecialArea.Add(specialAreaTagList[i].InnerXml.Replace(",", ""));
                        }
                    }
                }


                DOBLogger.WriteCommunicationLog("Property Profile Response log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                    Trace.AppendLine("GetExternalSystemResponse End");
                    return response;
                
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " Property Profile trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_PropertyProfile Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
        }

        public static string DescYNCode(string st)
        {
            if ("Y".Equals(st)) { return "Yes"; }
            if ("N".Equals(st)) { return "No"; }
            return "";
        }

    }

}
