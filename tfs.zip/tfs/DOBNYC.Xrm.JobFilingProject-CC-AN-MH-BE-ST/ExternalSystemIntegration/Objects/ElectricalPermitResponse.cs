﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ElectricalPermitResponse : BaseResponse
    {
        public string EStatus { get; set; }
        public string EBin { get; set; }
        public string EFirmNo { get; set; }
        public string EWorkToDo1 { get; set; }
       
    }
}
