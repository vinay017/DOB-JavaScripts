﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BISJobRequest : BaseRequest
    {

        public string BISJobNumber { get; set; }

        public string BISDocNumber { get; set; }

    }
}
