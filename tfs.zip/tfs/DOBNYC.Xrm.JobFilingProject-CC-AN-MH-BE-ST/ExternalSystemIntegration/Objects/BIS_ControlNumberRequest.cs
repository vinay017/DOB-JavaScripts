﻿
namespace ExternalSystemIntegration.Objects
{
    public class BIS_ControlNumberRequest
    {
        public string ControlNumber { get; set; }
    }
}
