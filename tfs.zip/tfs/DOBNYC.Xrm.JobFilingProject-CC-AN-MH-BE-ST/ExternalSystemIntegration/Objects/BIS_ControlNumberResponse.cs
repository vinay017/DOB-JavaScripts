﻿using System.Collections.Generic;

namespace ExternalSystemIntegration.Objects
{
    public class BIS_ControlNumberResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }

        public string ErrorDescription { get; set; }

        public List<ExteriorWallType> exteriorWallTypes = new List<ExteriorWallType>();
    }

    public class ExteriorWallType
    {
        public string WallType { get; set; }

        public string WallCode { get; set; }
    }
}
