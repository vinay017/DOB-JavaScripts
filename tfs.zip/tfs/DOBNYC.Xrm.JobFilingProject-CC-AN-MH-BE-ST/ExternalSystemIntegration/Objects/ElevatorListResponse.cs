﻿using System.Collections.Generic;

namespace ExternalSystemIntegration.Objects
{
    public class ElevatorListResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }
        public string ErrorDescription { get; set; }

        public string Prem_HouseNumber { get; set; }
        public string Prem_StreetName { get; set; }
        public string NmBoro { get; set; }
        public string Prem_Bin { get; set; }
        public string VlNumZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string VlCommBd { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string NumDevices { get; set; }
        public string InDevice { get; set; }

        public List<Elevator> Elevator = new List<Elevator>();
    }

    public class Elevator
    {
        public string DvDeviceNumber { get; set; }
        public string DvDeviceStatus { get; set; }
        public string DvDeviceType { get; set; }

    }
}
