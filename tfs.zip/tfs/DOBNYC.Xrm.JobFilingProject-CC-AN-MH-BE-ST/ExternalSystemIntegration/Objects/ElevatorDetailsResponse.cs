﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ElevatorDetailsResponse : BaseResponse
    {
        public string ErrorMsg { get; set; }
        public string Prem_Bin { get; set; }
        public string Prem_HouseNumber { get; set; }
        public string Prem_StreetName { get; set; }
        public string Borough { get; set; }
        public string Zipcode { get; set; }
        public string HealthArea { get; set; }
        public string JobType { get; set; }
        public string PageNumber { get; set; }
        public string RecCount { get; set; }
        public string FoilIndicator { get; set; }
        public string DeviceNo { get; set; }
        public string StatusDate { get; set; }
        public string LawRecordNo { get; set; }
        public string ExactLocation { get; set; }
        public string ApprovalDate { get; set; }
        public string AlterationDate { get; set; }
        public string FloorFrom { get; set; }
        public string TravDist { get; set; }
        public string WorkingPresurePSI { get; set; }
        public string FloorTo { get; set; }
        public string CensusTract { get; set; }
        public string CommunityBoard { get; set; }
        public string TaxLot { get; set; }
        public string TaxBlock { get; set; }
        public string SpeedFpm { get; set; }
        public string CapacityLbs { get; set; }
        public string CarEntrance { get; set; }
        public string Manufacturer { get; set; }
        public string HropeQty { get; set; }
        public string CropeQty { get; set; }
        public string MropeQty { get; set; }
        public string BropeQty { get; set; }
        public string HropeSize { get; set; }
        public string CropeSize { get; set; }
        public string MropeSize { get; set; }
        public string BropeSize { get; set; }
        public string HropeKind { get; set; }
        public string CropeKind { get; set; }
        public string MropeKind { get; set; }
        public string BropeKind { get; set; }
        public string GovernorType { get; set; }
        public string SafetyType { get; set; }
        public string GropeQty { get; set; }
        public string MachineType { get; set; }
        public string ModeOperation { get; set; }
        public string GropeSize { get; set; }
        public string CarBufferType { get; set; }
        public string FiremanService { get; set; }
        public string GropeKind { get; set; }
        public string LastperInspDate { get; set; }
        public string LastperInspDisp { get; set; }
        public string LastperInspBadgeNo { get; set; }
        public string CeaseUse { get; set; }
        public string AlterDateService { get; set; }
        public string ApplicationNoArray { get; set; }
        public string Filed_Bin { get; set; }
        public string Filed_HouseNumber { get; set; }
        public string Filed_StreetName { get; set; }
        public string CarBufferTypeExp { get; set; }
        public string CarEntrancesExp { get; set; }
        public string GovernorTypeExp { get; set; }
        public string MachineTypeExp { get; set; }
        public string ModeOperationExp { get; set; }
        public string HRopeKindExp { get; set; }
        public string CropeKindExp { get; set; }
        public string MropeKindExp { get; set; }
        public string BropeKindExp { get; set; }
        public string GropeKindExp { get; set; }
        public string SafetyTypeExp { get; set; }
        public string DeviceStatus { get; set; }
        public string DeviceType { get; set; }
        public string ElpElevator { get; set; }

    }
    
    
}
