﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
   public class LicenseValidationRequest : BaseRequest
    {

       public string LicenseNumber { get; set; }
       public string LicenseType { get; set; }

    }
}
