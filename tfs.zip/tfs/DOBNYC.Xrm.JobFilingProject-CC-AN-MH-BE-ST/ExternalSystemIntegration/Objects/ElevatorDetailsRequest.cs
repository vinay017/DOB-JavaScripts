﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ElevatorDetailsRequest : BaseRequest
    {

        public string Bin { get; set; }
        public string RecordNumber { get; set; }
        public string DeviceNumber { get; set; }

    }
}
