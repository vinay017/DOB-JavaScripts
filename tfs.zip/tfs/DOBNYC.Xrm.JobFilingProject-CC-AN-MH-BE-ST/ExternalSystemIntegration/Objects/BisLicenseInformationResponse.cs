﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BisLicenseInformationResponse : BaseResponse
    {
        public string Fin { get; set; }
        public string ErrorMessage { get; set; }
        public string Date { get; set; }
        public string Pgm { get; set; }
        public string VinNumberHours { get; set; }
        public string NmStreet { get; set; }
        public string NmBorough { get; set; }
        public string ViBin { get; set; }
        public string ViZip { get; set; }
        public string VitaxBlock { get; set; }
        public string ViTaxLot { get; set; }
        public string ViCensTract { get; set; }
        public string ViHithArea { get; set; }
        public string ElapsedTime { get; set; }
        public string ViCommBd { get; set; }
        public string HseHi { get; set; }
        public string GIJobType { get; set; }
        public string GiPageN { get; set; }
        public string GiRecCountN { get; set; }
        public string FoilIndicator { get; set; }

        public List<LicenseDetails> detailList = new List<LicenseDetails>();

        public string SustianableLink { get; set; }
    }

    public class LicenseDetails
    {
        //Start list
        public string ReBusName { get; set; }
        public string ReEmailAddress { get; set; }
        public string ReAppType { get; set; }
        public string ReAppNumber { get; set; }
        public string ReLastName { get; set; }
        public string ReFirstName { get; set; }
        public string ReStatus { get; set; }
        public string ReStatusDate { get; set; }
        public string RePassword { get; set; }
        public string RePrepAddress { get; set; }
        public string RePrepCity { get; set; }
        public string RePrepState { get; set; }
        public string RePrepZip { get; set; }
        public string RePrepPhone { get; set; }
        public string RePrepMobile { get; set; }
        //End List
    }
}
