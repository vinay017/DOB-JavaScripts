﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class LicenseValidationReponse : BaseResponse
    {
        public string ErrorMsg { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string Borough { get; set; }
        public string Bin { get; set; }
        public string Zipcode { get; set; }
        public string Block { get; set; }
        public string Lot { get; set; }
        public string CensusTract { get; set; }
        public string HealthArea { get; set; }
        public string JobType { get; set; }
        public string PageNumber { get; set; }
        public string RecCountNumber { get; set; }
        public string FoilIndicator { get; set; }
        public string LicenseNumber { get; set; }
        public string LicenseType { get; set; }
        public string Status { get; set; } // Status
        public string BusinessName1 { get; set; } // Business 1
        public string RequiredFlag_GLI_1 { get; set; }
        public string CompanyName_GLI_1 { get; set; }
        public string ExpirationDate_GLI_1 { get; set; }
        public string Policy_GLI_1 { get; set; }
        public string RequiredFlag_WCI_1 { get; set; }
        public string CompanyName_WCI_1 { get; set; }
        public string ExpirationDate_WCI_1 { get; set; }
        public string Policy_WCI_1{ get; set; }
        public string RequiredFlag_DIS_1 { get; set; }
        public string CompanyName_DIS_1 { get; set; }
        public string ExpirationDate_DIS_1 { get; set; }
        public string Policy_DIS_1 { get; set; }
        public string BusinessName2 { get; set; } // Business 2
        public string RequiredFlag_GLI_2 { get; set; }
        public string CompanyName_GLI_2 { get; set; }
        public string ExpirationDate_GLI_2 { get; set; }
        public string Policy_GLI_2 { get; set; }
        public string RequiredFlag_WCI_2 { get; set; }
        public string CompanyName_WCI_2 { get; set; }
        public string ExpirationDate_WCI_2 { get; set; }
        public string Policy_WCI_2 { get; set; }
        public string RequiredFlag_DIS_2 { get; set; }
        public string CompanyName_DIS_2 { get; set; }
        public string ExpirationDate_DIS_2 { get; set; }
        public string Policy_DIS_2 { get; set; }
        public string EXPIRE_DATE { get; set; }
        public string ApplicantLastName { get; set; }
        public string ApplicantFirstName { get; set; }
        public string ApplicantInitial { get; set; }
        public string ApplicantHouseNo { get; set; }
        public string ApplicantStreet { get; set; }
        public string ApplicantCity { get; set; }
        public string ApplicantState { get; set; }
        public string ApplicantZip { get; set; }
        public string ApplicantMobile { get; set; }
        public string ApplicantPhone { get; set; }
        public string ApplicantFax { get; set; }
        public string ApplicantEmail { get; set; }
        public string BusinessPhone { get; set; }
        public string BusinessFax { get; set; }
        public string BusinessEmail { get; set; }
        public string BusinessHouseNo { get; set; }
        public string BusinessStreetName{ get; set; }
        public string BusinessAddressLine { get; set; }
        public string BusinessCity { get; set; }
        public string BusinessState { get; set; }
        public string BusinessZip { get; set; }
        
        
    }
}
