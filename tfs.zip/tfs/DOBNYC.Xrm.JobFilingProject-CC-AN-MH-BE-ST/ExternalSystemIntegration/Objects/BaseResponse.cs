﻿
namespace ExternalSystemIntegration.Objects
{
    public class BaseResponse
    {
        public string ReturnCode { get; set; }
        public string ReturnError { get; set; }
        public string MoreError { get; set; }
        public string ErrorArray { get; set; }
    }
}
