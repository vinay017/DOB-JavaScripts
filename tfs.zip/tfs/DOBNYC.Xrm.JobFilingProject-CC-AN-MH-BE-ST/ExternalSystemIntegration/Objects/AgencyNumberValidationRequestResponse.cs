﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class AgencyNumberValidationRequest : BaseRequest
    {
        public string LicenseType;
        public string LicenseNumber;
        
        internal string Count = "0001";
    }

    public class EndorsementDetails
    {
        public string EndorsementFlag;
        public string EndorsementType;
        public string EndorsementTypeExp;
        public string EndorsementNumber;
        public string EndorsementDesc;
        public string EndorsementCodeRef1;
        public string EndorsementAddDate;
        public string EndorsementDelDate;


    }

    public class AgencyNumberValidationResponse : BaseResponse
    {
        public string ErrorCode;
        public string ErrorMessage;
        public string ErrorTable;
        public string NotUsed;
        public string AllControlNumber;
        public string Date;
        public string HouseNumber;
        public string StreetName;
        public string BoroughName;
        public string Bin;
        public string Zip;
        public string TaxBlock;
        public string TaxLot;
        public string CensTract;
        public string HealthArea;
        public string HseLow;
        public string HseHi;
        public string JobType;
        public string GlPageN;
        public string TotalRecordCount;
        public string FoilIndicator;
        public string DebugMsg;

        public List<EndorsementDetails> endorsementList = new List<EndorsementDetails>();
    }
}
