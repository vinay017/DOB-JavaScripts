﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class SIALicensingRequest : BaseRequest
    {
        public string LicenseNumber { get; set; }
        public string LicenseType { get; set; }
    }


    public class SIALicensingResponse : BaseResponse
    {
        public string LicenseNumber { get; set; }
        public string LicenseType { get; set; }
        public string Status { get; set; }
        public string Statusdate { get; set; }
        public string Transcode { get; set; }
        public string DocketNumber { get; set; }
        public string LicenseClass { get; set; }
        public string LicenseEntryDate { get; set; }
        public string LicenseClassType { get; set; }
        public string DocketNumber2 { get; set; }
        public string TransDate { get; set; }
        public string OperId { get; set; }
        public string RenewDate { get; set; }
        public string Expiredate { get; set; }
        public string IssueDate { get; set; }
        public string LicenseUse1 { get; set; }
        public string LicenseUse2 { get; set; }
        public string NoselfCert { get; set; }
        public string Exec298Flag { get; set; }
        public string Exec298Date { get; set; }
        public string RsLtrFlag { get; set; }
        public string CityEmployee { get; set; }
        public string Respforboiler { get; set; }
        public string GrandFather1 { get; set; }
        public string Grandfather2 { get; set; }
        public string TestCementFlag { get; set; }
        public string PERANumber { get; set; }
        public string FirmNumber { get; set; }
        public string FirmResponsibleRep { get; set; }
        public string Pin { get; set; }
        public string RegistrationFlag { get; set; }
        public string RegistrationDate { get; set; }
        public string BlockFlag { get; set; }
        public string BlockBeginDate { get; set; }
        public string BlockEndDate { get; set; }
        public string BlockComment { get; set; }
        public string Journeymen { get; set; }
        public string Apprentices { get; set; }
        public string Helpers { get; set; }
        public string Keytext { get; set; }
        public string ApplSsn { get; set; }
        public string ApplBirthDate { get; set; }
        public string ApplLastName { get; set; }
        public string ApplFirstName { get; set; }
        public string ApplInitial { get; set; }
        public string ApplHouseNumber { get; set; }
        public string ApplStreetName { get; set; }
        public string ApplCity { get; set; }
        public string ApplState { get; set; }
        public string ApplZip { get; set; }
        public string ApplMobile { get; set; }
        public string ApplPhone { get; set; }
        public string ApplFax { get; set; }
        public string ApplEmail { get; set; }
        public string BusPhone { get; set; }
        public string busFax { get; set; }
        public string BusEmail { get; set; }
        public string BusHouseNumber { get; set; }
        public string BusStreetName { get; set; }
        public string BusAddrLine2 { get; set; }
        public string BusCity { get; set; }
        public string BusState { get; set; }
        public string BusZip { get; set; }
        public string BusName { get; set; }
        public string BusEin { get; set; }
        public string BusFeeexempt { get; set; }
        public string BusExpid { get; set; }
        public string BusText { get; set; }
        public string Aff1Of1Name { get; set; }
        public string Aff1Of1Title { get; set; }
        public string Aff1Of1License { get; set; }
        public string Aff1Of1Type { get; set; }
        public string Aff1Of1Pct { get; set; }
        public string GC_Comment1 { get; set; }
        public string GC_Comment2 { get; set; }

        public List<DirectorInformationDetails> directorInfo = new List<DirectorInformationDetails>();

    }

    public class DirectorInformationDetails
    {
        public string DirectorLastName { get; set; }
        public string DirectorFirstName { get; set; }
        public string DirectorTitle { get; set; }
        public string DirectoLicenseNumber { get; set; }
        public string DirectorLicensetype { get; set; }
        public string DirectorPCT { get; set; }

    }
}
