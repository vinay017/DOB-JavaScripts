﻿using System.Collections.Generic;

namespace ExternalSystemIntegration.Objects
{
    public class ElevatorRecordNumbersResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }
        public string ErrorDescription { get; set; }

        public string Prem_HouseNumber { get; set; }
        public string Prem_StreetName { get; set; }
        public string NmBoro { get; set; }
        public string Prem_Bin { get; set; }
        public string VlNumZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string VlCommBd { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string PageNumberQq30 { get; set; }
        public string TotalRecsQq30 { get; set; }
        public string DupBin { get; set; }

        public List<ElevatorRecords> ElevatorRecords = new List<ElevatorRecords>();
    }

    public class ElevatorRecords
    {
        public string LlRecordNumber { get; set; }
        public string Filed_HouseNumber { get; set; }
        public string Filed_StreetName { get; set; }
        public string LlNumOfDevices { get; set; }
        public string InspectCountQq30 { get; set; }
        public string ViolCountQq30 { get; set; }
              
    }
}
