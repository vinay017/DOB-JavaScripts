﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BaseRequest
    {
       
            public string JobFilingNumber { get; set; }
            public string UserID { get; set; }
            public string RequestedDate { get; set; }
            public string SourceChannel { get; set; }
               
    }
}
