﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ECBValidationResponse : BaseResponse
    {
     
        public string Date;
        public string Pgm;
        public string HouseNumber;
        public string StreetName;
        public string BoroughName;
        public string Bin;
        public string Zip;
        public string TaxBlock;
        public string TaxLot;
        public string CensTract;
        public string HealthArea;
        public string HseLow;
        public string ElaspedTime;
        public string CommunityBoardNumber;
        public string HseHi;
        public string JobType;
        public string GlPageN;
        public string TotalRecordCount;
        public string FoilIndicator;
        public string DebugMsg;
        public string GlJobType;
        public string GlRecCountN;
        public string ECBNumber;
        public string ActiveFlag;
        public string Addr;
        public string RespName;
        public string RespAddr;
        public string VIssDate;
        public string DelivDate;
        public string VType;
        public string DobVNo;
        public string InspId;
        public string TaxLienFlag;
        public string DevType;
        public string DevNum;
        public string ExtHearingDt;
        public string HrgTime;
        public string AmountImp;
        public string AmountPaid;
        public string ExtBalanceDue;
        public string HrgStat;
        public string CompStat;
        public string CompByDate;
        public string CompByStipDate;
        public string CompSeverity;
        public string CurDt;
        public string ComDt;
        public string DefDt;
        public string StipDt;
        public string AjrDt;
        public string AsgDt;
        public string WriDt;

        public string InfrCodeExpArrays;
        public List<ECB1details> ECB1 = new List<ECB1details>();

        public string ElevLines;
        public List<ECB2details> ECB2 = new List<ECB2details>();

        public string ExtAliEventDt;
        public string ExtAldEventDt;
        public string ExtUnitCodeExp;
        public string ExtDocEventDt;
        public string CompOnDate;
        public string ExtInfDIssissRsnExp;
        public string CureDate;
        public string ExtMultOffFlgExp;
        public string ExtLiceseNo;
        public string ExtProjNum;
        public string ExtExhibAtt;
        public string ExtFirstHearingDt;
        public string ExtNetAllAdjusts;
        public string ExtWriteOffFlag;
        public string ExtReceivedByDate;
        public string ExtCompStatusDate;
        public string ExtCMPDate;
        public string ExtFaceAmt;
        public string StipHearingDate;

        public List<ECB1details> detailList = new List<ECB1details>();

    }

    public class ECB1details
    {
        public string InfrCode;
        public string StdDesc;
        public string SecOfLaw;
    }

    public class ECB2details
    {
        public string LN1;
        public string LN2;
        public string LN3;
    }
}
