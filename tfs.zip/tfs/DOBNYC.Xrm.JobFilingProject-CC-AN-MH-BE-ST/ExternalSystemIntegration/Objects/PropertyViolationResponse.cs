﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class PropertyViolationResponse : BaseResponse
    {
        public string ErrorMsg { get; set; }
        public string Bin { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string Borough { get; set; }
        public string Zipcode { get; set; }
        public string Lot { get; set; }
        public string Block { get; set; }
        public string CensusTract { get; set; }
        public string HealthArea { get; set; }
        public string CommunityBoard { get; set; }
        public string ECBViolation { get; set; }
        public string BISViolation { get; set; }
        public string OpenA1 { get; set; }
        public string OpenNB { get; set; }
        public string VacantLand { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string PSpecialArea1 { get; set; }
        public string PSpecialArea2 { get; set; }
        public string PSpecialArea3 { get; set; }
        public string PSpecialArea4 { get; set; }
        public string PSpecialArea5 { get; set; }
        public string TransitAuthority { get; set; }
        public string SpecialDistrict1 { get; set; }
        public string SpecialDistrict2 { get; set; }
        public string LoftFlag { get; set; }
        public string FilingOnHold { get; set; }
        public string ApprovalOnHold { get; set; }
        public string PermitOnHold { get; set; }
        public string SignOffOnHold { get; set; }
        public string WithdrawalOnHold { get; set; }
        public string ObsoleteFlag { get; set; }
        public string LandmarkStatus { get; set; }
        public string NumberOfStories { get; set; }
        public string LittleE { get; set; }
        /// <summary>
        /// Stop work Flags
        ///  'FN' - STOP WORK ORDER EXISTS ON THIS PROPERTY
        ///  'FC' - STOP WORK ORDER EXISTS ON THIS PROPERTY - DOB CIVIL PENALTIES DUE
        ///  'PN' - PARTIAL STOP WORK ORDER EXISTS ON THIS PROPERTY
        ///  'PC' - PARTIAL STOP WORK ORDER EXISTS ON THIS PROPERTY - DOB CIVIL PENALTIES DUE
        /// </summary>
        public string StopWork { get; set; }
        /// <summary>
        /// 'F' - FULL VACATE ORDER EXISTS ON THIS PROPERTY
        /// 'P' - PARTIAL VACATE ORDER EXISTS ON THIS PROPERTY
        /// </summary>
        public string VacateFlag { get; set; }
        /// <summary>
        /// Y - CLOSURE/PADLOCK ORDER EXISTS ON THIS PROPERTY
        /// </summary>
        public string PadlockFlag { get; set; }
        /// <summary>
        /// Y - VIOLATION FOR FAILURE TO CERTIFY CORRECTION OF CLASS 1 VIOLATION EXISTS ON THIS PROPERTY - DOB CIVIL PENALTIES DUE
        /// </summary>
        public string Class1Violation { get; set; }
        /// <summary>
        /// Y - NY STATE BUYOUT PROGRAM
        /// </summary>
        public string BuyoutFlag { get; set; }
        /// <summary>
        /// Y- LEGALIZATION OF NYC DM / NO ADDITIONAL DM REQUIRED / NB&CO TO PROCEED (SEE ACTIONS)
        /// </summary>
        public string SandyDemoFlag { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string CompromisedStructure { get; set; }
        public List<LittleEDetails> littleEDetailsList = new List<LittleEDetails>();
    }

    public class LittleEDetails
    {
        public string LittleEFlag { get; set; }
        public string LittleEEffectiveDate { get; set; }
        public string LittleESatisfiedDate { get; set; }
        public string LittleEPartialFlag { get; set; }
    }
}
