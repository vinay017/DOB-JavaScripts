﻿using System.Collections.Generic;

namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_GetBoilerIsnResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }
        public string ErrorDescription { get; set; }

        public string AllNumbhous { get; set; }
        public string AllStrt { get; set; }
        public string AllBoro { get; set; }
        public string AllBin { get; set; }
        public string AllZip { get; set; }
        public string VlTaxBlock { get; set; }
        public string VlTaxLot { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string HseLo { get; set; }
        public string HseHi { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string DebugMsg { get; set; }
        public string Premise { get; set; }
        public string TotalRecsQ200 { get; set; }
        public string PageNumberQ200 { get; set; }

        public List<BoilerIsn> boilerIsnList = new List<BoilerIsn>();
    }

    public class BoilerIsn
    {
        public string voil1 { get; set; }
        public string boiler1 { get; set; }
        public string md1 { get; set; }
        public string ser1 { get; set; }
        public string status1 { get; set; }
        public string insp1 { get; set; }
        public string recv1 { get; set; }
        public string auth1 { get; set; }
        public string isn { get; set; }
    }
}
