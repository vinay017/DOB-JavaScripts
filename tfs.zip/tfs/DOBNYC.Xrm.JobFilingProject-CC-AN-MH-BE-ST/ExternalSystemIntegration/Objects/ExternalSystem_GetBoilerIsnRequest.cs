﻿namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_GetBoilerIsnRequest : BaseRequest
    {
        public string AllBorough { get; set; }
        public string AllCount { get; set; }
        public string BiswebReporting { get; set; }
        public string BoroughKey { get; set; }
        public string ReadSw { get; set; }
        public string FinFlag { get; set; }
        public string AllKey1 { get; set; }
    }
}