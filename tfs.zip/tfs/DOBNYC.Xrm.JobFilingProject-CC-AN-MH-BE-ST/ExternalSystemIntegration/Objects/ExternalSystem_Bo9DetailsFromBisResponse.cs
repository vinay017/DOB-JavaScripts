﻿using System.Collections.Generic;

namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_Bo9DetailsFromBisResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }
        public string AllControlNumber { get; set; }
        public string PremisesAddress { get; set; }
        public string ZipCode { get; set; }
        public string LocatedBlock { get; set; }
        public string LocatedLot { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string HasLow { get; set; }
        public string HasHigh { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string DebugMsg { get; set; }
        public List<BIS_Bo9Details> bo9DetailsFromBis = new List<BIS_Bo9Details>();
    }

    public class BIS_Bo9Details
    {
        public string EntryDate { get; set; }
        public string InspectionDate { get; set; }
        public string Name { get; set; }
        public string NysCertificate { get; set; }
        public string RecieveDate { get; set; }
        public string DefectStatus { get; set; }
        public string Source { get; set; }
        public string InspectionType { get; set; }
    }
}
