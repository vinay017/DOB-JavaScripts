﻿namespace ExternalSystemIntegration.Objects
{
    public class ExternalSystem_BoilerDetailsByIsnResponse : BaseResponse
    {
        public bool IsSuccess { get; set; }
        public string ErrorDescription { get; set; }
        public string AllControlNumber { get; set; }
        public string VlCensTract { get; set; }
        public string VlHlthArea { get; set; }
        public string PremisesBorough { get; set; }
        public string PremisesBin { get; set; }
        public string PremisesZipCode { get; set; }
        public string PremisesHouseNumber { get; set; }
        public string PremisesStreet { get; set; }
        public string PremisesLot { get; set; }
        public string PremisesBlock { get; set; }
        public string FiledAtBorough { get; set; }
        public string FiledAtBin { get; set; }
        public string FiledAtZipCode { get; set; }
        public string FiledAtHouseNumber { get; set; }
        public string FiledAtStreet { get; set; }
        public string FiledAtLot { get; set; }
        public string FiledAtBlock { get; set; }
        public string HasHigh { get; set; }
        public string HasLow { get; set; }
        public string GlJobType { get; set; }
        public string GlPageN { get; set; }
        public string GlRecCountN { get; set; }
        public string FoilIndicator { get; set; }
        public string DebugMsg { get; set; }
        public string BoilerStatus { get; set; }
        public string CensusTract { get; set; }
        public string BoilerClass { get; set; }
        public string Fees { get; set; }
        public string HealthArea { get; set; }
        public string HorsePower { get; set; }
        public string Ins { get; set; }
        public string LocatedIn { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string NumberofBoilers { get; set; }
        public string Over6 { get; set; }
        public string BoilerNumber { get; set; }
        public string Pressure { get; set; }
        public string SerialNumber { get; set; }
        public string Type { get; set; }
        public string School { get; set; }
        public string Year { get; set; }
        public string BDEPInstallNumber { get; set; }
        public string BDEPExpireDate { get; set; }
        public string Btu { get; set; }
        public string BIllegalFlag { get; set; }
        public string BoilerBoroBlockLot { get; set; }
        public string BoilerKey { get; set; }
        public string ElpBoiler { get; set; }
    }
}
