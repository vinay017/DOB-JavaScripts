﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ECBValidationRequest : BaseRequest
    {
        public string Bin { get; set; }

        public string ECBNumber { get; set; }
    }
}
