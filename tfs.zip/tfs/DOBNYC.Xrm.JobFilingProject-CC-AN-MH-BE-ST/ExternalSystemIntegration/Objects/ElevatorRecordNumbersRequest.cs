﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ElevatorRecordNumbersRequest : BaseRequest
    {

        public string AllBin { get; set; }
        public string AllCount { get; set; }
        
    }
}