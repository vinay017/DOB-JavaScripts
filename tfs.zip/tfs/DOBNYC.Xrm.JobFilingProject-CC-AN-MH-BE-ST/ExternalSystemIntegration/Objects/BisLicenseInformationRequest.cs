﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class BisLicenseInformationRequest : BaseRequest
    {
        public string Email { get; set; }

        public string LicenseTypeNoSpaceDelimit { get; set; }
    }
}
