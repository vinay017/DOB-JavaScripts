﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class ElectricalPermitRequest : BaseRequest
    {

        public string AllIsn { get; set; }
        public string AllBorough { get; set; }
        public string BiswebReporting { get; set; }
        public string BoroughKey { get; set; }
        public string PageNumber { get; set; }

    }
}
