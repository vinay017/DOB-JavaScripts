﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public class HotListResponse : BaseResponse
    {
        public string ErrorMsg { get; set; }
        public string HouseNumber { get; set; }
        public string StreetName { get; set; }
        public string Borough { get; set; }
        public string Bin { get; set; }
        public string Zipcode { get; set; }
        public string Block { get; set; }
        public string Lot { get; set; }
        public string CensusTract { get; set; }
        public string HealthArea { get; set; }
        public string JobType { get; set; }
        public string PageNumber { get; set; }
        public string RecCountNumber { get; set; }
        public string FoilIndicator { get; set; }
        public string NO_CERT { get; set; }
        public string NO_D14 { get; set; }
        public string NO_ANY { get; set; }
        public string NO_BOTH { get; set; }
        
    }
}
