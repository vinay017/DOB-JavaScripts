﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExternalSystemIntegration.Objects
{
    public static class Common
    {
        public static string GetAttributeValueFromResponse(string response, string attributeTag)
        {
            try
            {
                string attributeValue = string.Empty;
                string attributeTagStart = "<" + attributeTag + ">";
                string attributeTagEnd = "</" + attributeTag + ">";
             
                int start = response.IndexOf(attributeTagStart);
                int end = response.IndexOf(attributeTagEnd, start + attributeTagStart.Length);
                attributeValue = response.Substring(start + attributeTagStart.Length, end - start - attributeTagEnd.Length + 1);
                return attributeValue;

            }

            catch (Exception ex)
            {
                return string.Empty;
                //throw ex;

            }
        }
    }
}
