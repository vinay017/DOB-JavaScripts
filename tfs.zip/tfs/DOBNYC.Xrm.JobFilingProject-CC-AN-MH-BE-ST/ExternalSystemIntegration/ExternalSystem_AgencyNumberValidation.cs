﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_AgencyNumberValidation
    {
        StringBuilder Trace = new StringBuilder();
        int looperVal = 0;
        public AgencyNumberValidationResponse GetAgencyNumberInformation(AgencyNumberValidationRequest request)
        {
            AgencyNumberValidationResponse response = new AgencyNumberValidationResponse();
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("Get Agency number Validation - Start");

                if (request != null && request.LicenseNumber != null && request.LicenseType != null && request.Count != null)
                {

                    bisResponseString = GetBisResponse(request);

                    response.ErrorCode = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.ErrorCode);
                    response.ErrorMessage = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.ErrorMessage);
                    response.ErrorTable = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Date);
                    response.NotUsed = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.NotUsed);
                    response.AllControlNumber = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.AllControlNumber);
                    response.Date = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Date);
                    response.HouseNumber = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HouseNumber);
                    response.StreetName = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.StreetName);
                    response.BoroughName = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.BoroughName);
                    response.Bin = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Bin);
                    response.Zip = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Zip);
                    response.TaxBlock = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TaxBlock);
                    response.TaxLot = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TaxLot);
                    response.CensTract = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.CensTract);
                    response.HealthArea = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HealthArea);
                    response.JobType = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.JobType);
                    response.HseHi = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HseHi);
                    response.HseLow = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HseLow);
                    response.GlPageN = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.GlPageN);
                    response.TotalRecordCount = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TotalRecordCount);
                    response.DebugMsg = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.DebugMsg);
                    
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(bisResponseString);
                    XmlElement root = xDoc.DocumentElement;
                    XmlNodeList crmTagList = root.GetElementsByTagName("LEndorsement_ARRAY_CRM");
                    while (response.endorsementList.Count < Convert.ToInt32(response.TotalRecordCount))
                    {
                        if (Convert.ToInt32(response.TotalRecordCount) <= crmTagList.Count)
                            looperVal = Convert.ToInt32(response.TotalRecordCount);
                        else
                            looperVal = crmTagList.Count;

                        for (int i = 0; i < looperVal; i++)
                        {
                            EndorsementDetails endorsementList = new EndorsementDetails();
                            string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                            endorsementList.EndorsementFlag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementFlag);
                            endorsementList.EndorsementNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementNumber);
                            endorsementList.EndorsementAddDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementAddDate);
                            endorsementList.EndorsementCodeRef1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementCodeRef1);
                            endorsementList.EndorsementDelDate = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementDelDate);
                            endorsementList.EndorsementDesc = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementDesc);
                            endorsementList.EndorsementType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementType);
                            endorsementList.EndorsementTypeExp = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, AgencyNumberInformation.EndorsementTypeExp);

                            response.endorsementList.Add(endorsementList);
                        }

                        if (response.endorsementList.Count < Convert.ToInt32(response.TotalRecordCount))
                        {
                            request.Count = (response.endorsementList.Count + 1).ToString();
                            bisResponseString = GetBisResponse(request);
                        }
                    }
                }
                Trace.AppendLine("Get Agency number Validation - End");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetAgencyNumberInformation", Trace.ToString(), "Agency Number Information Trace Log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetAgencyNumberInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_AgencyNumberValidation Class - GetAgencyNumberInformation Method Exceptions", "browserinfo");
                return response;
            }

        }

        internal string GetBisResponse(AgencyNumberValidationRequest request)
        {
            try
            {
                Trace.AppendLine("RequestBuilder Started!");
                string requestBuilder = MessageStrings.MXBI_CR6.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType).Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count);
                Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                Trace.AppendLine("RequestBuilder Ended!");
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string bisResponseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");
                return bisResponseString;
            }
            catch(SoapException ex)
            {
                throw ex;
            }
            
        }

    }

}