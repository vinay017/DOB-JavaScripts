﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;


namespace ExternalSystemIntegration
{
    public class ExternalSystem_HotList
    {
        StringBuilder Trace = new StringBuilder();
        public HotListResponse GetHotListDetails(HotListRequest request)
        {
            HotListResponse response = new HotListResponse();
            try
            {
                Trace.AppendLine("GetHotListDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.LicenseNumber != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CR4.Replace(RequestAttributes.PRM_BUILDNYC_LICENSENO, request.LicenseNumber).Replace(RequestAttributes.PRM_BUILDNYC_LICENSETYPE, request.LicenseType);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetHotListDetails", Trace.ToString(), " HotList trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetHotListDetails", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_HotList Class - GetHotListDetails Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }


        }

        internal HotListResponse GetExternalSystemResponse(string requestObj)
        {
            HotListResponse response = new HotListResponse();
            BaseRequest Brequest = new BaseRequest();

            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.ErrorMsg = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.ErrorMsg);
                response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlNumHous);
                response.StreetName = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NmStrt);
                response.Borough = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NmBoro);
                response.Bin = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlBin);
                response.Zipcode = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlNumZip);
                response.Block = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlTaxBlock);
                response.Lot = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlTaxLot);
                response.CensusTract = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlCensTract);
                response.HealthArea = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.VlHlthArea);
                response.JobType = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.GlJobType);
                response.PageNumber = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.GlPageN);
                response.RecCountNumber = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.FoilIndicator);
                response.NO_CERT = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NO_CERT);
                response.NO_D14 = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NO_D14);
                response.NO_BOTH = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NO_BOTH);
                response.NO_ANY = Common.GetAttributeValueFromResponse(responseString, HotListResponseAttributeTags.NO_ANY);

                Trace.AppendLine("License Status" + response.NO_D14.ToString());
                DOBLogger.WriteCommunicationLog("HotList Response log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, responseString, Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                Trace.AppendLine("GetExternalSystemResponse End!");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " HotList trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_HotList Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                return response;
                //throw ex;

            }
        }


    } //class ends here
} // namespace ends here
