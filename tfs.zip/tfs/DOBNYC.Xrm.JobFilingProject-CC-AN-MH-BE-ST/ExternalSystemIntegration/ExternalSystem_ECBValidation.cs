﻿using System;
using System.Collections.Generic;
using System.Xml;
using System.Text;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using ExternalSystemIntegration.Objects;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_ECBValidation
    {
        StringBuilder Trace = new StringBuilder();


        public ECBValidationResponse GetECBViolationDetails(ECBValidationRequest request)
        {
            ECBValidationResponse response = new ECBValidationResponse();

            try
            {
                Trace.AppendLine("GetECBViolationDetails Started!");
                string requestBuilder = string.Empty;
                if (request != null && request.Bin != null && request.ECBNumber != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CR11.Replace(RequestAttributes.PRM_BUILDNYC_BIN, request.Bin).Replace(RequestAttributes.PRM_SD_ECB_VOILATIONNUMBER, request.ECBNumber);
                    Trace.AppendLine("RequestBuilder Ended!");
                    Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                    response = GetExternalSystemResponse(requestBuilder, request);
                }
                else
                {
                    response.ReturnError = "Request is not proper. Please verify.";
                    return response;
                }
                Trace.AppendLine("GetLicenseDetails End!");
                return response;

            }
            catch (Exception  ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetECBViolationDetails-External system", Trace.ToString(), "Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetECBViolationDetails-External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_LicenseValidation Class - GetLicenseDetails Method Exceptions", "browserinfo");
            }

            return response;
        }

        internal ECBValidationResponse GetExternalSystemResponse(string requestBuilder, ECBValidationRequest request)
        {
            ECBValidationResponse response = new ECBValidationResponse();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");

                #region Direct tags
                response.Date = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.Date);
                response.Pgm = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.Pgm);
                response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlNumHous);
                response.StreetName = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.NmStrt);
                response.BoroughName = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.NmBoro);
                response.Bin = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlBin);
                response.Zip = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlNumZip);
                response.TaxBlock = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlTaxBlock);
                response.TaxLot = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlTaxLot);
                response.CensTract = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlCensTract);
                response.HealthArea = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlHlthArea);
                response.ElaspedTime = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ElaspedTime);
                response.CommunityBoardNumber = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VlCommBd);
                response.HseHi = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.HseHi);
                response.GlJobType = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.GlJobType);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.FoilIndicator);
                response.ECBNumber = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ECBNumber);
                response.ActiveFlag = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ActiveFlag);
                response.Addr = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.Addr);
                response.RespName = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.RespName);
                response.RespAddr = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.RespAddr);
                response.VIssDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VIssDate);
                response.DelivDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.DelivDate);
                response.VType = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.VType);
                response.DobVNo = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.DobVNo);
                response.InspId = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.InspId);
                response.TaxLienFlag = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.TaxLienFlag);
                response.DevType = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.DevType);
                response.DevNum = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.DevNum);
                response.ExtHearingDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtHearingDt);
                response.HrgTime = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.HrgTime);
                response.AmountImp = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.AmountImp);
                response.AmountPaid = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.AmountPaid);
                response.ExtBalanceDue = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtBalanceDue);
                response.HrgStat = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.HrgStat);
                response.CompStat = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CompStat);
                response.CompByDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CompByDate);
                response.CompByStipDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CompByStipDate);
                response.CompSeverity = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CompSeverity);
                response.CurDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CurDt);
                response.ComDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ComDt);
                response.DefDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.DefDt);
                response.StipDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.StipDt);
                response.AjrDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.AjrDt);
                response.AsgDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.AsgDt);
                response.WriDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.WriDt);
                response.ExtAliEventDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtAliEventDt);
                response.ExtAldEventDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtAldEventDt);
                response.ExtUnitCodeExp = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtUnitCodeExp);
                response.ExtDocEventDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtDocEventDt);
                response.StipHearingDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.StipHearingDate);
                response.CompOnDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CompOnDate);
                response.ExtInfDIssissRsnExp = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtInfDIssissRsnExp);
                response.CureDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.CureDate);
                response.ExtMultOffFlgExp = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtMultOffFlgExp);
                response.ExtLiceseNo = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtLiceseNo);
                response.ExtProjNum = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtProjNum);
                response.ExtExhibAtt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtExhibAtt);
                response.ExtFirstHearingDt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtFirstHearingDt);
                response.ExtNetAllAdjusts = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtNetAllAdjusts);
                response.ExtWriteOffFlag = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtWriteOffFlag);
                response.ExtReceivedByDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtReceivedByDate);
                response.ExtCompStatusDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtCompStatusDate);
                response.ExtCMPDate = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtCMPDate);
                response.ExtFaceAmt = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ExtFaceAmt);
                #endregion

                #region sub tags

                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("ECB1");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    ECB1details detailsList = new ECB1details();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.InfrCode = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.InfrCode);
                    detailsList.StdDesc = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.StdDesc);
                    detailsList.SecOfLaw = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.SecOfLaw);
                   
                    response.ECB1.Add(detailsList);
                }

                XmlNodeList crmTagList2 = root.GetElementsByTagName("ECB2");

                for (int i = 0; i < crmTagList2.Count; i++)
                {
                    ECB2details detailsList = new ECB2details();
                    string innerXmlNodesOfCrmTag = crmTagList2[i].InnerXml;

                    detailsList.LN1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.LN1);
                    detailsList.LN2 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.LN2);
                    detailsList.LN3 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ECBValidationInformation.LN3);

                    response.ECB2.Add(detailsList);
                }
                #endregion

                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ReturnError);
                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, ECBValidationInformation.ReturnCode);


            }
            catch (Exception ex)
            {
                
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetExternalSystemResponse- External system", Trace.ToString(), " Bis License Information trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetExternalSystemResponse- External system", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_ECBValidation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");

            }

            return response;
        }

    }
}
