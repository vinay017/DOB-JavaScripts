﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetElevatorList
    {
        StringBuilder Trace = new StringBuilder();

        public ElevatorListResponse GetElevatorList(ElevatorListRequest request)
        {
            Trace.AppendLine("GetElevatorList Started");
            ElevatorListResponse response = new ElevatorListResponse();
            try
            {
                Trace.AppendLine("GetElevatorList start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.AllBin != null && request.AllCount != null && request.PassRecordNumber != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_BIS_ELE2BR_PC.Replace(ElevatorListRequestAttributesTags.PRM_BIN, request.AllBin);
                    requestBuilder = requestBuilder.Replace(ElevatorListRequestAttributesTags.PRM_COUNT, request.AllCount);
                    requestBuilder = requestBuilder.Replace(ElevatorListRequestAttributesTags.PRM_PASSRECNUM, request.PassRecordNumber);
                   
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("AddressValidation End");
                return response;

            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetElevatorList", Trace.ToString(), " GetElevatorList trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetElevatorList", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystemIntegration_GetElevatorList Class - GetElevatorList Method Exceptions", "browserinfo");
                return response;
                //throw ex; 

            }

        }


        internal ElevatorListResponse GetExternalSystemResponse(string requestObj)
        {
            ElevatorListResponse response = new ElevatorListResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started");
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.Prem_HouseNumber = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlNumHous);
                response.Prem_StreetName = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.NmStrt);
                response.NmBoro = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.NmBoro);
                response.Prem_Bin = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlBin);
                response.VlNumZip = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlNumZip);
                response.VlTaxBlock = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlTaxBlock);
                response.VlTaxLot = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlTaxLot);
                response.VlCensTract = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlCensTract);
                response.VlHlthArea = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlHlthArea);
                response.VlCommBd = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.VlCommBd);
                response.HseHi = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.HseHi);
                response.GlJobType = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.GlJobType);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.FoilIndicator);
                response.NumDevices = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.NumDevices);
                response.InDevice = Common.GetAttributeValueFromResponse(responseString, ElevatorListResponseAttributesTags.InDevice);

                #region GetListValues
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("ELEVBR2");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    Elevator detailsList = new Elevator();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.DvDeviceNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorListResponseAttributesTags.DvDeviceNumber);
                    detailsList.DvDeviceStatus = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorListResponseAttributesTags.DvDeviceStatus);
                    detailsList.DvDeviceType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorListResponseAttributesTags.DvDeviceType);

                    response.Elevator.Add(detailsList);
                }
                #endregion EndGetListValues
                response.IsSuccess = true;



                DOBLogger.WriteCommunicationLog("GetBoilersList log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponse Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetBoilersList trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystemIntegration_GetElevatorList Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
                //throw ex;

            }
        }


    }
}
