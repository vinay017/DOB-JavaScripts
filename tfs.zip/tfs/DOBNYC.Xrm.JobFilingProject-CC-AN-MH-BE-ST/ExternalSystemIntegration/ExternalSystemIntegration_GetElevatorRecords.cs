﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetElevatorRecords
    {
        StringBuilder Trace = new StringBuilder();

        public ElevatorRecordNumbersResponse GetElevatorRecords(ElevatorRecordNumbersRequest request)
        {
            Trace.AppendLine("GetElevatorRecords Started");
            ElevatorRecordNumbersResponse response = new ElevatorRecordNumbersResponse();
            try
            {
                Trace.AppendLine("GetElevatorList start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.AllBin != null && request.AllCount != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_BIS_ELEVBR_PC.Replace(ElevatorListRequestAttributesTags.PRM_BIN, request.AllBin);
                    requestBuilder = requestBuilder.Replace(ElevatorListRequestAttributesTags.PRM_COUNT, request.AllCount);
                   
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("AddressValidation End");
                return response;

            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetElevatorRecords", Trace.ToString(), " GetElevatorRecords trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetElevatorRecords", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystemIntegration_GetElevatorRecords Class - GetElevatorRecords Method Exceptions", "browserinfo");
                return response;
                //throw ex; 

            }

        }


        internal ElevatorRecordNumbersResponse GetExternalSystemResponse(string requestObj)
        {
            ElevatorRecordNumbersResponse response = new ElevatorRecordNumbersResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started");
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.Prem_HouseNumber = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlNumHous);
                response.Prem_StreetName = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.NmStrt);
                response.NmBoro = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.NmBoro);
                response.Prem_Bin = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlBin);
                response.VlNumZip = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlNumZip);
                response.VlTaxBlock = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlTaxBlock);
                response.VlTaxLot = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlTaxLot);
                response.VlCensTract = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlCensTract);
                response.VlHlthArea = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlHlthArea);
                response.VlCommBd = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.VlCommBd);
                response.HseHi = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.HseHi);
                response.GlJobType = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.GlJobType);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.FoilIndicator);
                response.PageNumberQq30 = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.PageNumberQq30);
                response.TotalRecsQq30 = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.TotalRecsQq30);
                response.DupBin = Common.GetAttributeValueFromResponse(responseString, ElevatorRecordsResponseAttributesTags.DupBin);

                #region GetListValues
                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("ELEVBR");

                for (int i = 0; i < crmTagList.Count; i++)
                {
                    ElevatorRecords detailsList = new ElevatorRecords();
                    string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                    detailsList.LlRecordNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.LlRecordNumber);
                    detailsList.Filed_HouseNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.HouseNumber);
                    detailsList.Filed_StreetName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.StreetName);
                    detailsList.LlNumOfDevices = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.LlNumOfDevices);
                    detailsList.InspectCountQq30 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.InspectCountQq30);
                    detailsList.ViolCountQq30 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, ElevatorRecordsResponseAttributesTags.ViolCountQq30);
                    
                    response.ElevatorRecords.Add(detailsList);
                }
                #endregion EndGetListValues
                response.IsSuccess = true;



                DOBLogger.WriteCommunicationLog("GetBoilersList log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponse Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetBoilersList trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystemIntegration_GetElevatorRecords Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
                //throw ex;

            }
        }


    }
}
