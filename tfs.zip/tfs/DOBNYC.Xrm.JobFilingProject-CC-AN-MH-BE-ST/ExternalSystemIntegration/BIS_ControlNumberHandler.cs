﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class BIS_ControlNumberHandler
    {
        StringBuilder Trace = new StringBuilder();

        public BIS_ControlNumberResponse GetInfoOfControlNumber(BIS_ControlNumberRequest controlNumberDeatilsRequest)
        {
            BIS_ControlNumberResponse controlNumberdetailsResponse = new BIS_ControlNumberResponse();
            try
            {
                Trace.AppendLine("GetInfoOfControlNumber Started!");
                string requestBuilder = string.Empty;
                if (controlNumberDeatilsRequest != null && !string.IsNullOrEmpty(controlNumberDeatilsRequest.ControlNumber))
                {
                    Trace.AppendLine("RequestBuilder Started for GetInfoOfControlNumber");
                    requestBuilder = MessageStrings.MXBI_CR9.Replace(RequestAttributes.PRM_FACADES_CONTROLNUMBER , controlNumberDeatilsRequest.ControlNumber);
                    Trace.AppendLine("RequestBuilder Ended for GetInfoOfControlNumber. Request is : " + requestBuilder.ToString());

                    Trace.AppendLine("Staring getting response for onctrol number : " + controlNumberDeatilsRequest.ControlNumber);
                    controlNumberdetailsResponse = GetExternalSystemResponse(requestBuilder , Trace);
                }
                Trace.AppendLine("GetInfoOfControlNumber End!");
                controlNumberdetailsResponse.IsSuccess = true;
                return controlNumberdetailsResponse;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog( controlNumberDeatilsRequest.ControlNumber , "External System Integration", "GetInfoOfControlNumber", null, Trace.ToString(), "" , "" );
                DOBLogger.WriteExceptionLog(controlNumberDeatilsRequest.ControlNumber , "External System Integration" , "GetInfoOfControlNumber", ex.Message, LogLevelL4N.FATAL, "" , (ex.InnerException != null ? ex.InnerException.ToString() : string.Empty), null, "");
                controlNumberdetailsResponse.IsSuccess = false;
                controlNumberdetailsResponse.ErrorDescription = ex.Message;
                return controlNumberdetailsResponse;
            }
        }

        internal BIS_ControlNumberResponse GetExternalSystemResponse(string requestObj , StringBuilder Tarce)
        {
            BIS_ControlNumberResponse response = new BIS_ControlNumberResponse();
            BaseRequest Brequest = new BaseRequest();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started for GetInfoOfControlNumber");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string responseString = webClient.CALLBROKERXML(requestObj);

                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString , BIS_ControlNumberTags.ReturnCode);

                if (response.ReturnCode == "0")
                {
                    #region GetListValues
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(responseString);
                    XmlElement root = xDoc.DocumentElement;
                    XmlNodeList repeatingNodeForExteriorWallType = root.GetElementsByTagName(BIS_ControlNumberTags.ExteriorWallTypeRepeatingNodeName);
                    Trace.AppendLine("Starting looping for node : " + BIS_ControlNumberTags.ExteriorWallTypeRepeatingNodeName);
                    for (int i = 0; i < repeatingNodeForExteriorWallType.Count; i++)
                    {
                        Trace.AppendLine("In loop of Wall Type. Iteration Number : " + i.ToString());
                        ExteriorWallType exteriorWallTypeObj = new ExteriorWallType();
                        exteriorWallTypeObj.WallType = Common.GetAttributeValueFromResponse(repeatingNodeForExteriorWallType[i].InnerXml , BIS_ControlNumberTags.ExteriorWallType);
                        response.exteriorWallTypes.Add(exteriorWallTypeObj);
                    }

                    XmlNodeList repeatingNodeForExteriorWallCode = root.GetElementsByTagName(BIS_ControlNumberTags.ExteriorWallCodeRepeatingNodeName);
                    Trace.AppendLine("Starting looping for node : " + BIS_ControlNumberTags.ExteriorWallCodeRepeatingNodeName);
                    for (int i = 0; i < repeatingNodeForExteriorWallType.Count; i++)
                    {
                        Trace.AppendLine("In loop of Wall code. Iteration Number : " + i.ToString());
                        if(repeatingNodeForExteriorWallType.Count <= repeatingNodeForExteriorWallType.Count)
                            response.exteriorWallTypes[i].WallCode = Common.GetAttributeValueFromResponse(repeatingNodeForExteriorWallCode[i].InnerXml , BIS_ControlNumberTags.ExteriorWallCode);
                    }

                    #endregion GetListValues
                }
                Trace.AppendLine("GetExternalSystemResponse Ended for GetInfoOfControlNumber");
                return response;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
