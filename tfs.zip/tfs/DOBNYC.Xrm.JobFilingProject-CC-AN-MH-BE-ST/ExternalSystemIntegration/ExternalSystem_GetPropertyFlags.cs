﻿using System;
using System.Text;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using DOB.Logging;
using System.Xml;
using System.Web.Services.Protocols;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetPropertyFlags
    {
        StringBuilder Trace = new StringBuilder();
        int looperVal = 0;
        public GetPropertyFlagsResponse GetPropertyFlagsInformation(GetPropertyFlagsRequest request)
        {
            GetPropertyFlagsResponse response = new GetPropertyFlagsResponse();
            string bisResponseString = string.Empty;
            try
            {
                Trace.AppendLine("Get Property Flags - Start");

                if (request != null && !string.IsNullOrEmpty(request.Borough) && !string.IsNullOrEmpty(request.Block))
                {
                    request.Block = string.Format("{0:00000}", Convert.ToInt32(request.Block));

                    if (!string.IsNullOrEmpty(request.Lot))
                        request.Lot = string.Format("{0:00000}", Convert.ToInt32(request.Lot));

                    if(!string.IsNullOrEmpty(request.Count))
                        request.Count = string.Format("{0:0000}", Convert.ToInt32(request.Count));

                    bisResponseString = GetBisResponse(request);

                    response.GlobalFlags.ErrorCode = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.ErrorCode);
                    response.GlobalFlags.ErrorMessage = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.ErrorMessage);
                    response.GlobalFlags.ErrorTable = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Date);
                    response.GlobalFlags.NotUsed = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.NotUsed);
                    response.GlobalFlags.AllControlNumber = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.AllControlNumber);
                    response.GlobalFlags.Date = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Date);
                    response.GlobalFlags.HouseNumber = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HouseNumber);
                    response.GlobalFlags.StreetName = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.StreetName);
                    response.GlobalFlags.BoroughName = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.BoroughName);
                    response.GlobalFlags.Bin = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Bin);
                    response.GlobalFlags.Zip = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.Zip);
                    response.GlobalFlags.TaxBlock = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TaxBlock);
                    response.GlobalFlags.TaxLot = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TaxLot);
                    response.GlobalFlags.CensTract = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.CensTract);
                    response.GlobalFlags.HealthArea = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HealthArea);
                    response.GlobalFlags.JobType = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.JobType);
                    response.GlobalFlags.HseHi = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HseHi);
                    response.GlobalFlags.HseLow = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.HseLow);
                    response.GlobalFlags.GlPageN = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.GlPageN);
                    response.GlobalFlags.TotalRecordCount = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.TotalRecordCount);
                    response.GlobalFlags.DebugMsg = Common.GetAttributeValueFromResponse(bisResponseString, AgencyNumberInformation.DebugMsg);


                    XmlDocument xDoc = new XmlDocument();
                    
                        xDoc.LoadXml(bisResponseString);
                        XmlElement root = xDoc.DocumentElement;
                        //XmlNodeList lotArrayTagList = root.GetElementsByTagName("LotArray");
                        XmlNodeList crmTagList = root.GetElementsByTagName("CRM");
                        if (Convert.ToInt32(response.GlobalFlags.TotalRecordCount.ToString()) <= crmTagList.Count)
                            looperVal = Convert.ToInt32(response.GlobalFlags.TotalRecordCount.ToString());
                        else
                            looperVal = crmTagList.Count;

                        for (int i = 0; i < looperVal; i++)
                        {
                            PropertyFlags propertyFlagsList = new PropertyFlags();
                            string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                            propertyFlagsList.HouseNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.HouseNumber);
                            propertyFlagsList.LandmarkStatus = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.LandmarkStatus);
                            propertyFlagsList.ObsoleteFlag = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.ObsoleteFlag);
                            propertyFlagsList.StreetName = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.StreetName);
                            propertyFlagsList.TaxLot = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.TaxLot);
                            propertyFlagsList.VerifyType = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.VerifyType);
                            propertyFlagsList.Bin = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.Bin);
                            propertyFlagsList.BinInd = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.BinInd);
                            propertyFlagsList.DobHighHouseNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.DobHighHouseNumber);
                            propertyFlagsList.DobLowHouseNumber = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, PropertyFlagInformation.DobLowHouseNumber);

                            response.PropertyFlagsList.Add(propertyFlagsList);
                        }

                        //if (response.PropertyFlagsList.Count < Convert.ToInt32(response.GlobalFlags[0].TotalRecordCount.ToString()))
                        //{
                        //    request.Count = string.Format("{0:0000}", (response.PropertyFlagsList.Count + 1));
                        //    bisResponseString = GetBisResponse(request);
                        //}
                    
                }
                Trace.AppendLine("Get Property Flags- End");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetPropertyFlagsInformation", Trace.ToString(), "Property Flgas Info Trace Log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetPropertyFlagsInformation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_GetPropertyFlags Class - GetPropertyFlagsInformation Method Exceptions", "browserinfo");
                return response;
            }

        }

        internal string GetBisResponse(GetPropertyFlagsRequest request)
        {
            try
            {
                Trace.AppendLine("RequestBuilder Started!");
                string requestBuilder = string.Empty;

                if (string.IsNullOrEmpty(request.Lot))
                {
                    requestBuilder = MessageStrings.MXBI_CR10Optional.Replace(RequestAttributes.PRM_BUILDNYC_BOROUGH, request.Borough).Replace(RequestAttributes.PRM_BUILDNYC_BLOCK, request.Block).
                    Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count);
                }
                else
                {
                    requestBuilder = MessageStrings.MXBI_CR10.Replace(RequestAttributes.PRM_BUILDNYC_BOROUGH, request.Borough).Replace(RequestAttributes.PRM_BUILDNYC_BLOCK, request.Block).
                    Replace(RequestAttributes.PRM_BUILDNYC_PAGINGCOUNT, request.Count).Replace(RequestAttributes.PRM_BUILDNYC_LOT, request.Lot);
                }
                Trace.AppendLine("RequestBuilder: " + requestBuilder.ToString());
                Trace.AppendLine("RequestBuilder Ended!");
                Trace.AppendLine("GetExternalSystemResponse Started!");
                ServiceSoapClient webClient = new ServiceSoapClient();
                string bisResponseString = webClient.CALLBROKERXML(requestBuilder);
                Trace.AppendLine("GetExternalSystemResponse Ended!");
                return bisResponseString;
            }
            catch (SoapException ex)
            {
                throw ex;
            }

        }

    }

}