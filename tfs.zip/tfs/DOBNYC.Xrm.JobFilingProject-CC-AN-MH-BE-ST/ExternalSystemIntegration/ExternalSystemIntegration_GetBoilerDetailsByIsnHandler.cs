﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;

namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetBoilerDetailsByIsnHandler
    {
        StringBuilder Trace = new StringBuilder();

        public ExternalSystem_BoilerDetailsByIsnResponse GetBoilerDetailsByIsn(ExternalSystem_BoilerDetailsByIsnRequest request)
        {
            Trace.AppendLine("GetBoilerDetailsByIsn Started");
            ExternalSystem_BoilerDetailsByIsnResponse response = new ExternalSystem_BoilerDetailsByIsnResponse();
            try
            {
                Trace.AppendLine("GetBoilerDetailsByIsn start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.Isn != null && request.Borough != null && request.BoroughKey != null && request.ReadSw != null && request.FinFlag != null && request.BiswebReporting != null)
                {
                    Trace.AppendLine("RequestBuilder Started for GetBoilerDetailsByIsn!");
                    requestBuilder = MessageStrings.MXBI_CRM_013_BOL_DET_PC.Replace(BoilerDetailsRequestAttributesTags.PRM_ISN, request.Isn);
                    requestBuilder = requestBuilder.Replace(BoilerDetailsRequestAttributesTags.PRM_BOROUGH, request.Borough);
                    requestBuilder = requestBuilder.Replace(BoilerDetailsRequestAttributesTags.PRM_KEYBOROUGH, request.BoroughKey);
                    requestBuilder = requestBuilder.Replace(BoilerDetailsRequestAttributesTags.PRM_BISWEBREP, request.BiswebReporting);
                    requestBuilder = requestBuilder.Replace(BoilerDetailsRequestAttributesTags.PRM_FIN, request.FinFlag);
                    requestBuilder = requestBuilder.Replace(BoilerDetailsRequestAttributesTags.PRM_READSW, request.ReadSw);
                    Trace.AppendLine("RequestBuilder End for GetBoilerDetailsByIsn!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetBoilerDetailsByIsn End");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetBoilerDetailsByIsn", Trace.ToString(), " GetBoilerDetails trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetBoilerDetailsByIsn", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystemIntegration_GetBoilerDetailsByIsn Class - GetBoilerDetailsByIsn Method Exceptions", "browserinfo");
                response.IsSuccess = false;
                response.ReturnCode = ex.Message;
                return response;
            }
        }

        internal ExternalSystem_BoilerDetailsByIsnResponse GetExternalSystemResponse(string requestObj)
        {
            ExternalSystem_BoilerDetailsByIsnResponse response = new ExternalSystem_BoilerDetailsByIsnResponse();
            BaseRequest Brequest = new BaseRequest();
            ServiceSoapClient webClient = new ServiceSoapClient();

            Trace.AppendLine("GetExternalSystemResponse Started");
            string responseString = webClient.CALLBROKERXML(requestObj);
            response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.MF_RETURN_CODE);
            if (response.ReturnCode == "0")
            {
                response.AllControlNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllControlNumber);
                response.VlCensTract = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlCensTract);
                response.VlHlthArea = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlHlthArea);
                response.GlJobType = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.GlJobType);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.FoilIndicator);
                response.DebugMsg = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.DebugMsg);
                response.PremisesBorough = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllBoro);
                response.PremisesBin = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllBin);
                response.PremisesZipCode = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllZip);
                response.PremisesHouseNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllNumbhous);
                response.PremisesStreet = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllStrt);
                response.PremisesLot = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlTaxLot);
                response.PremisesBlock = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlTaxBlock);
                response.FiledAtBorough = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllBoro);
                response.FiledAtBin = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllBin);
                response.FiledAtZipCode = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.AllZip);
                response.FiledAtStreet = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BStreetName);
                response.FiledAtHouseNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BBldgLo);
                response.FiledAtLot = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlTaxLot);
                response.FiledAtBlock = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.VlTaxBlock);
                response.HasHigh = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.HseLo);
                response.HasLow = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.HseHi);
                response.BoilerStatus = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.Sta);
                response.HealthArea = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BHealthArea);
                response.CensusTract = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BCensusTract);
                response.BoilerClass = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BClass);
                response.Fees = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BFee);
                response.HorsePower = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BHorsePower);
                response.Ins = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BIns);
                response.LocatedIn = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BLoc);
                response.Make = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BMakeOfBoiler);
                response.Model = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BoilerModel);
                response.Over6 = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BOver6);
                response.NumberofBoilers = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BNumOfBoilers);
                response.BoilerNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BPNO);
                response.Pressure = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BPressure);
                response.SerialNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BPSer);
                response.Type = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BPType);
                response.School = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BSchool);
                response.Year = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BYr);
                response.BDEPInstallNumber = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BDEPInstallNumber);
                response.BDEPExpireDate = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BDEPExpireDate);
                response.Btu = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BTU);
                response.BIllegalFlag = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BIllegalFlag);
                response.BoilerBoroBlockLot = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BoilerBoroBlockLot);
                response.BoilerKey = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.BBoilerKey);
                response.ElpBoiler = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.ElpBoiler);
            }
            else
            {
                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.MF_OVERALL_TEXT);
                response.MoreError = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.MF_MORE_ERRORS);
                response.ErrorArray = Common.GetAttributeValueFromResponse(responseString, BoilerDetailsResponseAttributesTags.MFErrorArray);
            }
            DOBLogger.WriteCommunicationLog("GetBoilerDetailsByIsn log", Brequest.SourceChannel, "GetBoilerDetailsByIsn", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
            webClient.Close();
            Trace.AppendLine("GetExternalSystemResponse Ended");
            response.IsSuccess = true;
            return response;
        }
    }
}
