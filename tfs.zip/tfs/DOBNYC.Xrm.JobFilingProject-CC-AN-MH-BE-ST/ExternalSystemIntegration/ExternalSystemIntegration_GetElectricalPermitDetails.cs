﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;


namespace ExternalSystemIntegration
{
    public class ExternalSystemIntegration_GetElectricalPermitDetails
    {
        StringBuilder Trace = new StringBuilder();

        public ElectricalPermitResponse GetElectricalPermitDetails(ElectricalPermitRequest request)
        {
            Trace.AppendLine("GetElectricalPermitDetails Started");
            ElectricalPermitResponse response = new ElectricalPermitResponse();
            try
            {
                Trace.AppendLine("GetElectricalPermitDetails start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.AllIsn != null && request.BoroughKey != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_CRM_016_ELE_DTS_PC.Replace(ElectricalPermitRequestAttributesTags.PRM_ISN, request.AllIsn);
                    requestBuilder = requestBuilder.Replace(ElectricalPermitRequestAttributesTags.PRM_BOROUGH, request.AllBorough);
                    requestBuilder = requestBuilder.Replace(ElectricalPermitRequestAttributesTags.PRM_BISWEBREP, request.BiswebReporting);
                    requestBuilder = requestBuilder.Replace(ElectricalPermitRequestAttributesTags.PRM_KEYBOROUGH, request.BoroughKey);
                    requestBuilder = requestBuilder.Replace(ElectricalPermitRequestAttributesTags.PRM_PAGENO, request.PageNumber);
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("GetElectricalPermitDetails End");
                return response;

            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetElectricalPermitDetails", Trace.ToString(), " GetElectricalPermitDetails trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetElectricalPermitDetails", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystemIntegration_GetElectricalPermitDetails Class - GetElectricalPermitDetails Method Exceptions", "browserinfo");
                return response;
                //throw ex; 

            }

        }


        internal ElectricalPermitResponse GetExternalSystemResponse(string requestObj)
        {
            ElectricalPermitResponse response = new ElectricalPermitResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started");
                string responseString = webClient.CALLBROKERXML(requestObj);
                if (Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.MF_RETURN_CODE) != "0")
                {
                    response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.MF_RETURN_CODE);
                    response.ReturnError = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.MF_OVERALL_TEXT);
                    return response;
                }
                response.EBin = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.EBin);
                response.EStatus = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.EStatus);
                response.EWorkToDo1 = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.EWorkToDo1);
                response.EFirmNo = Common.GetAttributeValueFromResponse(responseString, ElectricalPermitResponseAttributesTags.EFirmNo);
                
                DOBLogger.WriteCommunicationLog("GetElectricalPermitDetailsResponse log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponse Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetElectricalPermitDetailsResponse trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_AddressViolation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
                //throw ex;

            }
        }


    }
}
