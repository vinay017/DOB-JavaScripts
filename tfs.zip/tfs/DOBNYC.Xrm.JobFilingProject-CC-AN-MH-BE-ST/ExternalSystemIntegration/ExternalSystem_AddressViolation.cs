﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;


namespace ExternalSystemIntegration
{
    public class ExternalSystem_AddressViolation
    {
        StringBuilder Trace = new StringBuilder();

        public AddressValidationResponse GetAddressValidation(AddressValidationRequest request)
        {
            Trace.AppendLine("AddressValidation Started");
            AddressValidationResponse response = new AddressValidationResponse();
            try
            {
                Trace.AppendLine("AddressValidationStarted start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.Borough != null && request.HouseNumber != null && request.StreetName != null)
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBN_105_CHECK_ADDRESS_AND_GET_BIN_PC.Replace(RequestAttributes.PRM_BUILDNYC_BOROUGH, request.Borough);
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_BUILDNYC_HOUSENO, request.HouseNumber);
                    requestBuilder = requestBuilder.Replace(RequestAttributes.PRM_BUILDNYC_STREET, request.StreetName);
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("AddressValidation End");
                return response;
                
            }
            
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetAddressValidation", Trace.ToString(), " AddressValidation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetAddressValidation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_AddressViolation Class - GetAddressValidation Method Exceptions", "browserinfo");
                return response;
                //throw ex; 

            }

        }


        internal AddressValidationResponse GetExternalSystemResponse(string requestObj)
        {
            AddressValidationResponse response = new AddressValidationResponse();
            BaseRequest Brequest = new BaseRequest();
            
            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started");
                string responseString = webClient.CALLBROKERXML(requestObj); // SampleData.AddressValidation; //string.Empty;
                if (Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_RETURN_CODE) == "P")
                {
                    response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_RETURN_CODE);
                    response.ReturnError = "Protected Property";
                    return response;
                }
                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_RETURN_CODE);
                response.MoreError = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_OVERALL_TEXT);
                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_OVERALL_TEXT);
                response.AddressType = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_ADDRESS_TYPE);
                response.BIN = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_BIN);
                response.Block = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_TAX_BLOCK);
                response.Borough = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_BORO_CODE);
                response.BuildingClass = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_FIN_BLDG_CLASS);
                response.FINZone1 = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_FIN_ZONE_OVERLAY1);
                response.FINZone2 = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_FIN_ZONE_OVERLAY2);
                response.HouseNumber = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_HOUSE_NUMBER);
                response.LandMark = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_LANDMARK_STATUS);
                response.Lot = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_TAX_LOT);
                response.LotFlag = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_LOFT_FLAG);
                response.LowHouseNumber = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_LOW_HOUSE_NUMBER);
                response.SpecialName = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_SPECIAL_NAME);
                response.StreetNumber1 = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_CROSS_STREET_NUMBER_1);
                response.StreetNumber2 = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_CROSS_STREET_NUMBER_2);
                response.StreetName = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_STREET_NAME);

                Trace.AppendLine("Response BIN:" + response.BIN.ToString());

                DOBLogger.WriteCommunicationLog("Address Violation Responce log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponse Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " AddressValidation trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_AddressViolation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
                //throw ex;

            }
        }

        
    }
}
