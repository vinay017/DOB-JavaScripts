﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;
using System.Xml;

namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetBoilersIsnHandler
    {
        StringBuilder Trace = new StringBuilder();

        public ExternalSystem_GetBoilerIsnResponse GetIsnNumberList(ExternalSystem_GetBoilerIsnRequest request)
        {
            Trace.AppendLine("GetIsnNumberList Started");
            ExternalSystem_GetBoilerIsnResponse response = new ExternalSystem_GetBoilerIsnResponse();
            try
            {
                Trace.AppendLine("GetIsnNumberList start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.AllKey1 != null && request.AllBorough != null && request.AllCount != null && request.BoroughKey != null && request.ReadSw != null && request.FinFlag != null)
                {
                    Trace.AppendLine("RequestBuilder Started for GetIsnNumberList!");
                    requestBuilder = MessageStrings.MXBI_CRM_012_BOL_SET_PC.Replace(BoilerBrowseRequestAttributesTags.PRM_ALLKEY, request.AllKey1);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_BOROUGH, request.AllBorough);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_KEYBOROUGH, request.BoroughKey);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_COUNT, request.AllCount);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_FIN, request.FinFlag);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_READSW, request.ReadSw);
                    requestBuilder = requestBuilder.Replace(BoilerBrowseRequestAttributesTags.PRM_REPORTING, request.BiswebReporting);
                    Trace.AppendLine("RequestBuilder End for GetIsnNumberList!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);
                    response = GetExternalSystemResponse(requestBuilder);
                }
                Trace.AppendLine("GetIsnNumberList End");
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetIsnNumberList", Trace.ToString(), " GetIsnNumberList", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetIsnNumberList", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "GetIsnNumberList", "browserinfo");
                response.IsSuccess = false;
                response.ReturnCode = ex.Message;
                return response;
            }
        }

        internal ExternalSystem_GetBoilerIsnResponse GetExternalSystemResponse(string requestObj)
        {
            ExternalSystem_GetBoilerIsnResponse response = new ExternalSystem_GetBoilerIsnResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            Trace.AppendLine("GetExternalSystemResponse Started");
            string responseString = webClient.CALLBROKERXML(requestObj);

            response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.MF_RETURN_CODE);
            if (response.ReturnCode == "0")
            {
                response.AllNumbhous = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.AllNumbhous);
                response.AllStrt = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.AllStrt);
                response.AllBoro = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.AllBoro);
                response.AllBin = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.AllBin);
                response.AllZip = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.AllZip);
                response.VlTaxBlock = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.VlTaxBlock);
                response.VlTaxLot = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.VlTaxLot);
                response.VlCensTract = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.VlCensTract);
                response.VlHlthArea = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.VlHlthArea);
                response.HseLo = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.HseLo);
                response.HseHi = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.HseHi);
                response.GlJobType = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.GlJobType);
                response.GlPageN = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.GlPageN);
                response.GlRecCountN = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.FoilIndicator);
                response.DebugMsg = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.DebugMsg);

                XmlDocument xDoc = new XmlDocument();
                xDoc.LoadXml(responseString);
                XmlElement root = xDoc.DocumentElement;
                XmlNodeList crmTagList = root.GetElementsByTagName("Boiler");
                if (crmTagList != null && crmTagList.Count > 0)
                {
                    for (int i = 0; i < crmTagList.Count; i++)
                    {
                        BoilerIsn detailsList = new BoilerIsn();
                        string innerXmlNodesOfCrmTag = crmTagList[i].InnerXml;

                        detailsList.voil1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.auth1);
                        detailsList.boiler1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.boiler1);
                        detailsList.md1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.md1);
                        detailsList.ser1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.ser1);
                        detailsList.status1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.status1);
                        detailsList.insp1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.insp1);
                        detailsList.recv1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.recv1);
                        detailsList.auth1 = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.auth1);
                        detailsList.isn = Common.GetAttributeValueFromResponse(innerXmlNodesOfCrmTag, BoilerBrowseResponseAttributesTags.isn);
                        response.boilerIsnList.Add(detailsList);
                    }
                }
            }
            else
            {
                response.MoreError = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.MF_MORE_ERRORS);
                response.ReturnError = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.MF_OVERALL_TEXT);
                response.ErrorArray = Common.GetAttributeValueFromResponse(responseString, BoilerBrowseResponseAttributesTags.MFErrorArray);
            }
            webClient.Close();
            DOBLogger.WriteCommunicationLog("GetBoilersList log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
            response.IsSuccess = true;
            return response;
        }
    }
}
