﻿using System;
using System.Text;
using DOB.Logging;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration.Integration_BFIRST;


namespace ExternalSystemIntegration
{
    public class ExternalSystem_GetElevatorDetails
    {
        StringBuilder Trace = new StringBuilder();

        public ElevatorDetailsResponse GetElevatorDetails(ElevatorDetailsRequest request)
        {
            Trace.AppendLine("GetElevatorDetails Started");
            ElevatorDetailsResponse response = new ElevatorDetailsResponse();
            try
            {
                Trace.AppendLine("GetElevatorDetails start trace log");
                string requestBuilder = string.Empty;
                if (request != null && request.DeviceNumber != null )
                {
                    Trace.AppendLine("RequestBuilder Started!");
                    requestBuilder = MessageStrings.MXBI_BIS_ELEV_PC.Replace(ElevatorDetailsRequestAttributesTags.PRM_BUIDLNYC_BIN, request.Bin);
                    requestBuilder = requestBuilder.Replace(ElevatorDetailsRequestAttributesTags.PRM_BUILDNYC_DEVICENO, request.DeviceNumber);
                    requestBuilder = requestBuilder.Replace(ElevatorDetailsRequestAttributesTags.PRM_BUILDNYC_RECORDNO, request.RecordNumber);
                    Trace.AppendLine("RequestBuilder End!");
                    Trace.AppendLine("requestBuilder:" + requestBuilder);

                    response = GetExternalSystemResponse(requestBuilder);
                }

                Trace.AppendLine("AddressValidation End");
                return response;

            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(request.JobFilingNumber, request.SourceChannel, "GetAddressValidation", Trace.ToString(), " AddressValidation trace log", request.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(request.UserID, request.SourceChannel, "GetAddressValidation", ex.Message, DOB.Logging.LogLevelL4N.ERROR, request.UserID, "Exception Details", "ExternalSystem_AddressViolation Class - GetAddressValidation Method Exceptions", "browserinfo");
                return response;
                //throw ex; 

            }

        }


        internal ElevatorDetailsResponse GetExternalSystemResponse(string requestObj)
        {
            ElevatorDetailsResponse response = new ElevatorDetailsResponse();
            BaseRequest Brequest = new BaseRequest();

            ServiceSoapClient webClient = new ServiceSoapClient();
            try
            {
                Trace.AppendLine("GetExternalSystemResponse Started");
                string responseString = webClient.CALLBROKERXML(requestObj); 
                if (Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.MF_RETURN_CODE) == "P")
                {
                    response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, AddresssValidationResponseAttributesTags.MF_RETURN_CODE);
                    response.ReturnError = "Protected Property";
                    return response;
                }
                response.Prem_Bin = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlBin);
                response.Prem_HouseNumber = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlNumHous);
                response.Prem_StreetName = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.NmStrt);
                response.Borough = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.NmBoro);
                response.Zipcode = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlNumZip);
                response.HealthArea = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlHlthArea);
                response.JobType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.GlJobType);
                response.PageNumber = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.GlPageN);
                response.RecCount = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.GlRecCountN);
                response.FoilIndicator = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.FoilIndicator);
                response.DeviceNo = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvDeviceNo);
                response.StatusDate = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvStatusDate);
                response.LawRecordNo = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvLlawRecordNo);
                response.ExactLocation = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvExactLocation);
                response.ApprovalDate = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvApprovalDate);
                response.AlterationDate = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvAlterationDate);
                response.FloorFrom = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvFloorFrom);
                response.TravDist = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvTravDist);
                response.WorkingPresurePSI = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvWorkingPresurePSI);
                response.FloorTo = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvFloorTo);
                response.CensusTract = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlCensTract);
                response.CommunityBoard = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlCommBd);
                response.TaxLot = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlTaxLot);
                response.TaxBlock = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.VlTaxBlock);
                response.SpeedFpm = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvSpeedFpm);
                response.CapacityLbs = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCapacityLbs);
                response.CarEntrance = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCarEntrance);
                response.Manufacturer = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvManufacturer);
                response.HropeQty = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvHropeQty);
                response.CropeQty = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCropeQty);
                response.MropeQty = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvMropeQty);
                response.BropeQty = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvBropeQty);
                response.HropeSize = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvHropeSize);
                response.CropeSize = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCropeSize);
                response.MropeSize = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvMropeSize);
                response.BropeSize = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvBropeSize);
                response.HropeKind = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvHropeKind);
                response.CropeKind = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCropeKind);
                response.MropeKind = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvMropeKind);
                response.BropeKind = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvBropeKind);
                response.GovernorType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGovernorType);
                response.SafetyType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvSafetyType);
                response.GropeQty = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGropeQty);
                response.MachineType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvMachineType);
                response.ModeOperation = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvModeOperation);
                response.GropeSize = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGropeSize);
                response.CarBufferType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCarBufferType);
                response.FiremanService = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvFiremanService);
                response.GropeKind = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGropeKind);
                response.LastperInspDate = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvLastperInspDate);
                response.LastperInspDisp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvLastperInspDisp);
                response.LastperInspBadgeNo = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvLastperInspBadgeNo);
                response.CeaseUse = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCeaseUse);
                response.AlterDateService = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvAlterDateService);
                response.ApplicationNoArray = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvApplicationNoArray);
                response.Filed_Bin = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.LLBin);
                response.Filed_HouseNumber = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.HouseNumber);
                response.Filed_StreetName = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.StreetName);
                response.CarBufferTypeExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCarBufferTypeExp);
                response.CarEntrancesExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCarEntrancesExp);
                response.GovernorTypeExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGovernorTypeExp);
                response.MachineTypeExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.MachineTypeExp);
                response.ModeOperationExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvModeOperationExp);
                response.HRopeKindExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvHRopeKindExp);
                response.CropeKindExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvCropeKindExp);
                response.MropeKindExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvMropeKindExp);
                response.BropeKindExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvBropeKindExp);
                response.GropeKindExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvGropeKindExp);
                response.SafetyTypeExp = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DvSafetyTypeExp);
                response.DeviceStatus = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DeviceStatus);
                response.DeviceType = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.DeviceType);
                response.ElpElevator = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.ElpElevator);
                response.ReturnCode = Common.GetAttributeValueFromResponse(responseString, ElevatorDetailsResponseAttributesTags.MF_RETURN_CODE);


                DOBLogger.WriteCommunicationLog("GetElevatorDetailsResponse log", Brequest.SourceChannel, "GetExternalSystemResponse", true, "Null", "Null", "Address", Brequest.RequestedDate, "response", Brequest.RequestedDate, "additionalinfo", Brequest.UserID, "duration", "userbrowserifo");
                webClient.Close();
                Trace.AppendLine("GetExternalSystemResponse Ended");
                return response;
            }

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Brequest.JobFilingNumber, Brequest.SourceChannel, "GetExternalSystemResponse", Trace.ToString(), " GetElevatorDetailsResponse trace log", Brequest.UserID, "UserBrowserInfo");
                DOBLogger.WriteExceptionLog(Brequest.UserID, Brequest.SourceChannel, "GetExternalSystemResponse", ex.Message, DOB.Logging.LogLevelL4N.ERROR, Brequest.UserID, "Exception Details", "ExternalSystem_AddressViolation Class - GetExternalSystemResponse Method Exceptions", "browserinfo");
                webClient.Close();
                return response;
                //throw ex;

            }
        }


    }
}
