﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System;
using Microsoft.Xrm.Sdk.Query;
using System.ServiceModel;
using System.Text;
using DOBNYC.XRM.JobFiling.PluginHandlers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Helpers
{
    public class Fab4_FeeCalculationHelper : PluginHandlerBase
    {
        public static Guid CreatePaymentHistory(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, ParameterCollection sharedVariables)
        {
            try
            {
                
               // Fab4FeeCalculationobject feeObject = (Fab4FeeCalculationobject)SharedVariables[JobFilingEntityAttributeName.Fab4SharedVariable];
                Entity PaymentHistoryRecord = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                // Set Source Channel as Build
                crmTrace.AppendLine("Set Source Channel as Build");
                PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.SourceChannel, new OptionSetValue(1));

                crmTrace.AppendLine("create Payment History  - start");
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.EntityAttributeName));
                   
                    // Set jobfiling lookup
                    crmTrace.AppendLine("Set Jobfiling Lookup");
                   PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));

                  

                    // Set Total Fee
                    crmTrace.AppendLine("Set Total Fee");
                    if (sharedVariables.Contains(JobFilingEntityAttributeName.sharedAmountdue))
                    {
                      
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money((decimal)sharedVariables[JobFilingEntityAttributeName.sharedAmountdue]));
                    }
                       

                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.filingfee));
                    crmTrace.AppendLine("payment history record...");

                    //adjustment and isposted true

                    if (((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted)==true)||
                            (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted)&&targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted)==true))
                            && sharedVariables.Contains(JobFilingEntityAttributeName.sharedRefund)&& (decimal)sharedVariables[JobFilingEntityAttributeName.sharedRefund]>0)
                    {
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                    }
                        
                }

                Guid paymenthistory = service.Create(PaymentHistoryRecord);
                
                crmTrace.AppendLine("create  Payment History Record - End");
                #region Update PH guid on PW1
                Entity jobFilingEntity = new Entity();
                jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, paymenthistory.ToString());
                if (targetEntity.Id != null)
                {
                    jobFilingEntity.Id = targetEntity.Id;
                }
                   
                service.Update(jobFilingEntity);
                #endregion 
                // throw new Exception("test");
                return paymenthistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4_FeeCalculationHelper - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
        // identifier will identify from which method it is called
        public static string BuildFormualeName(Entity targetEntity, StringBuilder crmTrace, string identifier)
        {
            try
            {
                int buildVal = 0;
                string calcName = string.Empty;
                crmTrace.AppendLine("Enter BuildCalcName Function");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                {
                    buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value;
                }
                crmTrace.AppendLine("Building Type: " + buildVal);

                switch (buildVal)
                {
                    case 1:
                    case 2:
                    case 3:

                        {
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true && identifier==JobFilingEntityAttributeName.FenceIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Construction Fence";
                            }
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true && identifier == JobFilingEntityAttributeName.SidewalkIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Sidewalk Shed";
                            }
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true && identifier==JobFilingEntityAttributeName.ScaffoldIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Supported Scaffold";
                            }
                            
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true && identifier==JobFilingEntityAttributeName.SignIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Sign";
                            }
                            //for electrical
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.isElectricalWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType) == true && identifier == JobFilingEntityAttributeName.ElectricalIdentifier)
                            {
                                calcName = FeeTypeName.ElectricalFilingFee;
                            }
                            break;
                        }

                  
                    case 4:
                        {
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true && identifier == JobFilingEntityAttributeName.FenceIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Construction Fence";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true && identifier == JobFilingEntityAttributeName.SidewalkIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Sidewalk Shed";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true && identifier == JobFilingEntityAttributeName.ScaffoldIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Supported Scaffold";
                            }
                         
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true && identifier == JobFilingEntityAttributeName.SignIdentifier)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Sign";
                            }
                            //for electrical
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.isElectricalWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType) == true && identifier == JobFilingEntityAttributeName.ElectricalIdentifier)
                            {
                                calcName = FeeTypeName.ElectricalFilingFee;
                            }
                            break;
                        }
                }

                crmTrace.AppendLine("Exit BuildCalcName Function " + calcName);
                return calcName;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - CalculateFilingFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - BuildCalcName", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "Fab4_FeeCalculationHelper - BuildCalcName", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static EntityCollection RetrieveFee(StringBuilder crmTrace, IOrganizationService service, string formulaeName)
        {
            crmTrace.AppendLine("Start: retrieve fee..");
            ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });

            return (RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName,
                  new string[] { FeeCalculationConfigurationAttributeNames.MinFilingFee, FeeCalculationConfigurationAttributeNames.Tier1CostFee,
                        FeeCalculationConfigurationAttributeNames.CheckBounce, FeeCalculationConfigurationAttributeNames.PaaFee, FeeCalculationConfigurationAttributeNames.InConjunctionJobFee,
                     FeeCalculationConfigurationAttributeNames.Tier1CostFee,FeeCalculationConfigurationAttributeNames.RecordManagementFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And));
        }

        public static EntityCollection GetTransactionCodes(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, ConditionExpression condition)
        {
            crmTrace.AppendLine("Get transaction codes");
           
            EntityCollection transCodesResponse = new EntityCollection();
            try
            {
                #region retrieve Transaction Code Info
                crmTrace.AppendLine("Retrieve the transaction code information : started");
                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource,TransactionCodeAttributeNames.FeeSchemaName,TransactionCodeAttributeNames.TransactionText,
                TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { condition }, LogicalOperator.Or);
                crmTrace.AppendLine("Retrieve the transaction code information : ended");

                #endregion

                return transactioncodeResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static Guid CreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Guid Jobid, Guid PaymentHistoryId, Entity TransCodeId, Money fee)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                Entity transHistory = null;
                if (!string.IsNullOrEmpty(Jobid.ToString()) && !string.IsNullOrEmpty(fee.ToString()))
                {
                    crmTrace.AppendLine("Create Transaction history - Start");
                    transHistory = new Entity();

                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    if (TransCodeId.LogicalName == TransactionCodeAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.ToEntityReference());
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode));
                    }
                    // this if block will be executed in EOD handler.
                    else if (TransCodeId.LogicalName == TransactionHistoryAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.GetAttributeValue<EntityReference>(TransactionHistoryAttributeNames.TransactionCodeId));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode));
                    }
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.JobNumber));
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.PaymentInvoice, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId));

                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);

                    Guid Id = service.Create(transHistory);
                    crmTrace.AppendLine("Create Transaction history - end");

                    return Id;
                }
                else
                    return new Guid();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void PAAFeeCalculation(StringBuilder crmTrace, IOrganizationService service, Entity targetEntity)
        {

        }

    }
}
    