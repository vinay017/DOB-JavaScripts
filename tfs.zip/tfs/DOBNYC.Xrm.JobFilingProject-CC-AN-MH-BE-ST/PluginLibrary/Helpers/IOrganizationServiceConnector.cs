﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk.Organization;
using Microsoft.Xrm.Sdk.Query;
//using DOBNYC.XRM.JobFiling.Tracing;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.XRM.JobFiling.Helpers
{
    public class IOrganizationServiceConnector : IOrganizationService
    {
        private IOrganizationServiceFactory serviceFactory;
        private IOrganizationService service;

        public IOrganizationServiceConnector(IServiceProvider serviceProvider, IPluginExecutionContext context, ICrmServiceCredentialType credentialType)
        {

            serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));


            //string adminGuid = ConfigurationSettingsHelper.ApplicationConfigurationSettings[ConfigurationKeyStrings.AdminUserGuidKey].ToString();


            switch (credentialType)
            {
                case ICrmServiceCredentialType.ImpersonatedUser:
                    //Use current user id

                    service = serviceFactory.CreateOrganizationService(context.UserId);
                    break;
                case ICrmServiceCredentialType.Admin:

                    //service = serviceFactory.CreateOrganizationService(new Guid(adminGuid));
                    break;
                case ICrmServiceCredentialType.SystemAccount:
                    //Do not use current user id

                    break;
            }
        }


        //public static Guid GetAdminGuid()
        //{
        //    string adminUserGuid = ConfigurationSettingsHelper.ApplicationConfigurationSettings[ConfigurationKeyStrings.AdminUserGuidKey].ToString();
        //    try
        //    {
        //        if (!string.IsNullOrEmpty(adminUserGuid))
        //        {
        //            return new Guid(adminUserGuid);
        //        }
        //    }
        //    catch (Exception ex) { ExceptionMethods.ProcessException(ex); throw ex; }
        //    return Guid.Empty;
        //}

        public void Associate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
            try
            {
                service.Associate(entityName, entityId, relationship, relatedEntities);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entityName : {0}", (string.IsNullOrEmpty(entityName)) ? "entityName IsNullOrEmpty" : entityName.ToString()));
                parameterInfo.Append(String.Format("entityId : {0}", (entityId == Guid.Empty) ? "entityId IsEmptyGuid" : entityId.ToString()));
                parameterInfo.Append(String.Format("relationship : {0}", (relationship == null) ? "relationship IsNull" : relationship.ToString()));
                parameterInfo.Append(String.Format("relatedEntities : {0}", (relatedEntities == null) ? "relatedEntities IsNull" : relatedEntities.ToString()));

                //throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public Guid Create(Entity entity)
        {
            try
            {
                return service.Create(entity);
            }
            catch (InvalidPluginExecutionException ex)
            {
                throw ex;
            }
            catch (Exception exception)
            {

                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entity : {0}", (entity == null) ? "entity IsNull" : (string.IsNullOrEmpty(entity.LogicalName)) ? "entity is null" : entity.LogicalName));
                throw exception;
                //throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());

            }

        }

        public void Delete(string entityName, Guid id)
        {
            try
            {
                service.Delete(entityName, id);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entityName : {0}", (string.IsNullOrEmpty(entityName)) ? "entityName IsNullOrEmpty" : entityName.ToString()));
                parameterInfo.Append(String.Format("id : {0}", (id == Guid.Empty) ? "id IsEmptyGuid" : id.ToString()));

                //throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public void Disassociate(string entityName, Guid entityId, Relationship relationship, EntityReferenceCollection relatedEntities)
        {
            try
            {
                service.Disassociate(entityName, entityId, relationship, relatedEntities);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entityName : {0}", (string.IsNullOrEmpty(entityName)) ? "entityName IsNullOrEmpty" : entityName.ToString()));
                parameterInfo.Append(String.Format("entityId : {0}", (entityId == Guid.Empty) ? "entityId IsEmptyGuid" : entityId.ToString()));
                parameterInfo.Append(String.Format("relationship : {0}", (relationship == null) ? "relationship IsNull" : relationship.ToString()));
                parameterInfo.Append(String.Format("relatedEntities : {0}", (relatedEntities == null) ? "relatedEntities IsNull" : relatedEntities.ToString()));

                //throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public OrganizationResponse Execute(OrganizationRequest request)
        {
            try
            {
                return service.Execute(request);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("request : {0}", (request == null) ? "request IsNull" : request.ToString()));

                throw exception;//.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
        {
            try
            {
                return service.Retrieve(entityName, id, columnSet);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entityName : {0}", (string.IsNullOrEmpty(entityName)) ? "entityName IsNullOrEmpty" : entityName.ToString()));
                parameterInfo.Append(String.Format("id : {0}", (id == Guid.Empty) ? "id IsEmptyGuid" : id.ToString()));
                parameterInfo.Append(String.Format("columnSet : {0}", (columnSet == null) ? "columnSet IsNull" : columnSet.ToString()));

                 throw exception; //ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public EntityCollection RetrieveMultiple(QueryBase query)
        {
            try
            {
                return service.RetrieveMultiple(query);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("query : {0}", (query == null) ? "query IsNull" : query.ToString()));

                throw exception;// ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public void Update(Entity entity)
        {
            try
            {
                service.Update(entity);
            }
            catch (Exception exception)
            {
                StringBuilder parameterInfo = new StringBuilder();
                parameterInfo.Append(String.Format("entity : {0}", (entity == null) ? "entity IsNull" : entity.ToString()));

                // throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
            }
        }

        public IOrganizationService CreateOrganizationService(Guid? userId)
        {
            throw new NotImplementedException();
        }

        #region Web Service Call Parameter Info
        private string webServiceCallParameterInfo;

        public string WebServiceCallParameterInfo
        {
            get
            {
                if (webServiceCallParameterInfo == null)
                {
                    webServiceCallParameterInfo = GenerateWebServiceCallParameterInfo();
                }

                return webServiceCallParameterInfo;
            }
        }

        public string GenerateWebServiceCallParameterInfo()
        {
            StringBuilder webServiceCallParameters = new StringBuilder(PluginMessages.WebServiceCallParameterInfo);
            try
            {
                if (service == null)
                {
                    webServiceCallParameters.Append(PluginMessages.WebServiceCouldNotBeAccessed);
                }
                else
                {
                    webServiceCallParameters.Append(PluginMessages.ThisIsIOrganizationService);
                }
            }
            catch
            {
                webServiceCallParameters.Append(PluginMessages.CreateWebServiceCallParametersError);
                return String.Empty;
            }

            return webServiceCallParameters.ToString();
        }
        #endregion

        //public string CallFetchMethod(string fetchXml)
        //{
        //    try
        //    {
        //        ExecuteFetchRequest fetchRequest = new ExecuteFetchRequest();
        //        fetchRequest.FetchXml = fetchXml;
        //        ExecuteFetchResponse response = (ExecuteFetchResponse)service.Execute(fetchRequest);

        //        return response.FetchXmlResult;
        //    }
        //    catch (Exception exception)
        //    {
        //        StringBuilder parameterInfo = new StringBuilder();
        //        parameterInfo.Append(String.Format("fetchXml : {0}", (fetchXml == null) ? "fetchXml Null" : fetchXml.ToString()));

        //        // throw ExceptionMethods.ProcessWebServiceException(exception, WebServiceCallParameterInfo, parameterInfo.ToString());
        //    }
        //}

    }
}
