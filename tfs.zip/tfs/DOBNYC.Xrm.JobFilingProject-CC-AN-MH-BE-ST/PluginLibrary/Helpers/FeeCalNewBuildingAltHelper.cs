﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Helpers
{
    public class FeeCalNewBuildingAltHelper : PluginHandlerBase
    {
        /* FeeCalNewBuildingAltHelper Flow:
         * []CalculateMultiStakeFilingFee- Calculate Filing Fee and return values
         * []GetMultistakeFeeConfiguration- Retrieve the Fee Configuration Master Data Record based on Job Type
         * []GetTransactionCode- Retrieve Transaction Codes Master Data based on transaction code
         * []CreateTransactionHistory- Create Transaction Histories and return list of created TH GUIDS
         * []GetTransHistoryFee- To get exact fee to be used while creating TH's
         * []CreateUpdatePaymentHistoryRecord- To Create/Update Payment Histories based on variable condition
        */

        public static IFeeCalculationObject CalculateMultiStakeFilingFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                #region Variables
                EntityCollection retrieveFeeCollection = null;
                IFeeCalculationObject fcObject = new GCMHSTFeeCalObject();
                int buildVal = 0;
                int NumofStories = 0;
                double TotalSquarFeet = 0;
                int MultiStakeFeeType = 0;
                int DaysDifference = 0;
                decimal NoGoodCheckFee = 0;
                decimal ExistingNoGoodCheckFee = 0;
                EntityCollection FeeConfigResponse = new EntityCollection();
                EntityCollection NoGoodCheckRecords = new EntityCollection();
                EntityCollection PATPAFeeConfig = new EntityCollection();
                #endregion

                #region FilngType
                if (targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.IF)
                {
                    fcObject.FilingType = (int)FilingTypes.IF;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                {
                    fcObject.FilingType = (int)FilingTypes.PA;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF))
                {
                    fcObject.FilingType = (int)FilingTypes.SF;
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                {
                    fcObject.IsFeeExempt = true;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true))
                {
                    fcObject.IsConjunction = true;
                }

                #endregion

                #region PA/TPA
                if (targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) ||
                    targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))
                {
                    PATPAFeeConfig = GetPATPAFeeConfiguration(crmTrace, service, targetEntity);
                    fcObject.IsPATPA = true;

                }
                #endregion

                #region PL/SP/SD/GC/MH/ST
                //else
                //{
                //    #region Setting Variable values
                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                //        buildVal = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value;

                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) > 0)
                //        NumofStories = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories);

                //    if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true) ||
                //        (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories] == null))
                //        NumofStories = 0;

                  //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) > 0)
                  //  TotalSquarFeet = targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea);

                //    if (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCostLegal).Value > 0)
                //        fcObject.EstimatedCost = Convert.ToDecimal(targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCostLegal).Value.ToString());

                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName) && Convert.ToDecimal(targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName).ToString()) > 0)
                //        TotalSquarFeet = Convert.ToDouble(targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName).ToString());

                //    #endregion

                //    #region Retrieve Fee Config File based on Building Type
                //    if (targetEntity.Contains(JobFilingEntityAttributeName.BuildingTypeAttribute))
                //    {
                //        #region MultiStakeFeeType
                //        if (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.NewBuilings)
                //        {
                //            crmTrace.AppendLine("MultiStakeFeeType: " + MultiStakeFeeType);
                //            MultiStakeFeeType = (int)FeeType.MultiStakeFeeTypeNB;//Used like FeeType in PH
                //            fcObject.JobNBorAltType = (int)JobTypeNBorAlt.NewBuilings;
                //        }
                //        else if (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.BigAlteration)
                //        {
                //            MultiStakeFeeType = (int)FeeType.MultiStakeFeeTypeBigAlt;
                //            fcObject.JobNBorAltType = (int)JobTypeNBorAlt.BigAlteration;
                //        }
                //        else if (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.MajorAlteration)
                //        {
                //            MultiStakeFeeType = (int)FeeType.MultiStakeFeeTypeMajoAlt;
                //            fcObject.JobNBorAltType = (int)JobTypeNBorAlt.MajorAlteration;
                //        }
                //        else if (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.MinorAlteration)
                //        {
                //            MultiStakeFeeType = (int)FeeType.MultiStakeFeeTypeMinorAlt;
                //            fcObject.JobNBorAltType = (int)JobTypeNBorAlt.MinorAlteration;
                //        }
                //        #endregion
                //        crmTrace.AppendLine("New Building Type: " + buildVal);
                //        retrieveFeeCollection = GetMultistakeFeeConfiguration(crmTrace, service, buildVal, NumofStories, (decimal)TotalSquarFeet, MultiStakeFeeType, targetEntity);
                //    }
                //    #endregion

                //}
                #endregion

                ///<summary>
                ///Calculation Flow: FeeExempt,elseif conjunction else IF,PAA,SF -->Return fee object values in each case.
                ///Building Type based formula name--> Used while creating Transaction Histories.
                ///Legalization Calculation
                ///NoGoodCheck Calculation
                ///Total fee Calculation
                /// </summary>

                #region Fee Exempt
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                {
                    #region Setting Fee Exempt Values
                    fcObject.PAAFees = 0;
                    fcObject.RecordManagementFees = 0;
                    fcObject.InConjunctionFee = 0;
                    fcObject.LegalizationFilingFees = 0;
                    fcObject.IsFeeExempt = true;
                    #endregion
                }
                #endregion

                #region Conjuction Fee Calculation
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true))
                {
                    fcObject.PAAFees = 0;
                    fcObject.RecordManagementFees = 0;
                    fcObject.IsConjunction = true;
                    fcObject.InConjunctionFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value > 0)
                    {
                        ExistingNoGoodCheckFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                    }
                    else
                    {
                        ExistingNoGoodCheckFee = 0;
                    }
                    fcObject.NoGoodCheckFee = ExistingNoGoodCheckFee;
                }
                #endregion

                #region Not Fee Exempt and not Conjunction
                else
                {
                    #region PA/TPA
                    if (fcObject.IsPATPA)
                    {
                        fcObject.PATPAFilingFee = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString());
                        #region Place of Assembly Fee Calcualtion
                        if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))))
                        {
                            fcObject.RecordManagementFees = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString());
                        }
                        #endregion
                        #region Temporary Place of Assembly Fee Calcualtion
                         if (((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))))
                        {
                            #region Calculate the Number of Days--TPA (Today's Date - Event Start Date)
                            DaysDifference = GetNoOfDaysTPALateFee(crmTrace, service, targetEntity);
                            crmTrace.AppendLine("DaysDifference :----" + DaysDifference);
                            fcObject.Tier1CostFee = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier1CostFee].ToString());
                            #region Check the No Good Flag -TPA
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag))
                            {
                                Entity Jobfiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(JobFilingEntityAttributeName.NewWorkFilingFee, JobFilingEntityAttributeName.TPALateFees));
                                fcObject.PATPAFilingFee = Jobfiling.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value;
                                fcObject.TPALateFees = Jobfiling.GetAttributeValue<Money>(JobFilingEntityAttributeName.TPALateFees).Value;
                            }
                            #endregion
                            else
                            {
                                if (DaysDifference == -1)
                                {
                                    fcObject.PATPAFilingFee = fcObject.PATPAFilingFee;
                                    fcObject.TPALateFees = 0;
                                }
                                else if (DaysDifference <= 10 && DaysDifference >= 0)
                                {
                                    fcObject.PATPAFilingFee = (10 - DaysDifference) * fcObject.Tier1CostFee + fcObject.PATPAFilingFee;
                                    fcObject.TPALateFees = (10 - DaysDifference) * fcObject.Tier1CostFee;
                                }
                                //else if (DaysDifference < 0 || DaysDifference > 10) // Prod Hot Fix 12/12/2018
                                else if (DaysDifference < 0)
                                {
                                    fcObject.PATPAFilingFee = (10) * fcObject.Tier1CostFee + fcObject.PATPAFilingFee;
                                    fcObject.TPALateFees = (10) * fcObject.Tier1CostFee;

                                }
                            }
                          
                            fcObject.RecordManagementFees = 0;
                            crmTrace.AppendLine("TPA Fee: " + fcObject.PATPAFilingFee);
                            #endregion
                            #region TPA-Filing Fee Calculation  for PAA
                            if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                            {

                                Guid ParentJobGuid = ((EntityReference)targetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                                crmTrace.AppendLine("ParentJobGuid :" + ParentJobGuid);
                                Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid, new ColumnSet(JobFilingEntityAttributeName.NewWorkFilingFee, JobFilingEntityAttributeName.TPALateFees));
                                fcObject.PATPAFilingFee = ((Money)(JF.Attributes[JobFilingEntityAttributeName.NewWorkFilingFee])).Value;
                                fcObject.TPALateFees = ((Money)(JF.Attributes[JobFilingEntityAttributeName.TPALateFees])).Value;
                                crmTrace.AppendLine("PATPAFilingFee  :" + fcObject.PATPAFilingFee);
                                fcObject.PAAFees = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString());
                                fcObject.InConjunctionFee = 0;
                                crmTrace.AppendLine("FilingTypeAttributeName : PAA-TPA");
                            }
                            #endregion
                        }

                        #region Subsequent- Filng Fee calculation
                        if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF))
                        {
                            fcObject.SubsequentNBFee = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.SubsequentFee].ToString().Trim());
                            crmTrace.AppendLine("FilingTypeAttributeName : SF-PA/TPA");
                        }
                        #endregion

                        #region PAA-Filing Fee Calculation
                        if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                        {
                            fcObject.PAAFees = Convert.ToDecimal(PATPAFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString());
                            fcObject.InConjunctionFee = 0;
                            crmTrace.AppendLine("FilingTypeAttributeName : PAA-PA/TPA");
                        }
                        #endregion
                        #endregion
                    }
                    #endregion

                    #region PL/SP/SD/GC/MH/ST
                    //else
                    //{
                    //    #region Estimated Cost
                    //    if (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value > 0)
                    //        fcObject.EstimatedCost = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value;
                    //    #endregion

                    //    #region Setting values to the Fee-Object
                    //    if (retrieveFeeCollection != null && retrieveFeeCollection.Entities.Count > 0)
                    //    {
                    //        crmTrace.AppendLine("retrieveFeeCollection Count : " + retrieveFeeCollection.Entities.Count);
                    //        fcObject.Tier1CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee);
                    //        fcObject.TotalSquarFeet = Convert.ToDecimal(TotalSquarFeet.ToString());
                    //        fcObject.MinFilingFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString().Trim());
                    //        fcObject.MinEstFeeCostException = retrieveFeeCollection.Entities[0].GetAttributeValue<Money>(FeeCalculationConfigurationAttributeNames.MinEstFeeCostException).Value;
                    //        crmTrace.AppendLine("MinEstFeeCostException :" + fcObject.MinEstFeeCostException);
                    //        fcObject.RecordManagementFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString());
                    //        crmTrace.AppendLine("RecordManagementFees :" + fcObject.RecordManagementFees);
                    //        crmTrace.AppendLine("FilingTypeAttributeName : IF");
                    //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value > 0)
                    //        {
                    //            ExistingNoGoodCheckFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                    //        }
                    //        else
                    //        {
                    //            ExistingNoGoodCheckFee = 0;
                    //        }
                    //        crmTrace.AppendLine("ExistingNoGoodCheckFee :" + ExistingNoGoodCheckFee);
                    //        fcObject.NoGoodCheckFee = ExistingNoGoodCheckFee;
                    //    }
                    //    #region Subsequent- Filng Fee calculation
                    //    if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF))
                    //    {
                    //        if (fcObject.JobNBorAltType == (int)JobTypeNBorAlt.NewBuilings || fcObject.JobNBorAltType == (int)JobTypeNBorAlt.BigAlteration)
                    //        {
                    //            fcObject.SubsequentNBFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.SubsequentFee].ToString().Trim());
                    //        }
                    //        else if (fcObject.JobNBorAltType == (int)JobTypeNBorAlt.MajorAlteration || fcObject.JobNBorAltType == (int)JobTypeNBorAlt.MinorAlteration)
                    //        {
                    //            fcObject.SubsequentNBFee = fcObject.FilingFee;
                    //            //Subsequent Legalization as Legalization fields are diff fro estimatedcost and total const.
                    //        }
                    //        crmTrace.AppendLine("FilingTypeAttributeName : SF");
                    //    }
                    //    #endregion

                    //    #region PAA-Filing Fee Calculation
                    //    if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                    //    {
                    //        fcObject.PAAFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString());
                    //        fcObject.RecordManagementFees = 0;
                    //        fcObject.InConjunctionFee = 0;
                    //        crmTrace.AppendLine("FilingTypeAttributeName : PAA");
                    //    }
                    //    #endregion

                    //    #endregion
                    //}
                    #endregion
                }
                #endregion

                #region Legalization Fee Calculation
                //if (targetEntity.Contains(JobFilingEntityAttributeName.IsLegalization) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization))
                //{
                //    crmTrace.AppendLine("IsLegalization :True");
                //    //LegalizationFee is 600 for Bulding Type Family 1 / 2.
                //    //LegalizationFee is 6000 for Building Type Family 3 / 4.
                //    if (buildVal == FAB4BuildingType.familyHouse1 || buildVal == FAB4BuildingType.familyHouse2)
                //    {
                //        fcObject.LegalizationFilingFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationMinFee].ToString());

                //    }
                //    else if (buildVal == FAB4BuildingType.familyHouse3 || buildVal == FAB4BuildingType.familyHouseOther)
                //    {
                //        fcObject.LegalizationFilingFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationMaxFee].ToString());

                //    }
                //}
                #endregion

                #region NoGoodCheckFee Calculation
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag))
                {
                    crmTrace.AppendLine("Retrieve FeeConfigResponse/CheckBounceFee($20) based on Formula Name- Start");
                    FeeConfigResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetCheckBounceFee, FeeConfigName.CheckBounceFeeConfig.ToString())));
                    crmTrace.AppendLine("Retrieve FeeConfigResponse/CheckBounceFee($20) based on Formula Name- End" + FeeConfigResponse.Entities.Count);

                    crmTrace.AppendLine("Retrieve Payment History Records with NoGoodCheck true- Start");
                    NoGoodCheckRecords = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetNoGoodCheckPayments, targetEntity.Id)));
                    crmTrace.AppendLine("Retrieve Payment History Records with NoGoodCheck true- End" + NoGoodCheckRecords.Entities.Count);
                    if (FeeConfigResponse.Entities.Count > 0)
                    {
                        if (NoGoodCheckRecords.Entities.Count > 0)
                        {
                            NoGoodCheckFee = Convert.ToDecimal(FeeConfigResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]) * NoGoodCheckRecords.Entities.Count;
                            fcObject.NoGoodCheckFee = NoGoodCheckFee;
                        }
                    }
                    //Should check if package will update IsNoGoodCheck falg to False on JobFilng once paymentis done after NoGoodCheck.
                }
                else if(targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value > 0)
                {
                    fcObject.NoGoodCheckFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                }
                #endregion
                return fcObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - CalculateMultiStakeFilingFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - CalculateMultiStakeFilingFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - CalculateMultiStakeFilingFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - CalculateMultiStakeFilingFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateMultiStakeFilingFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateMultiStakeFilingFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static int BusinessDaysUntil(DateTime firstDay, DateTime lastDay, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                firstDay = firstDay.Date;
                lastDay = lastDay.Date;
                //if (firstDay > lastDay)
                //    throw new ArgumentException("Incorrect last day " + lastDay);

                TimeSpan span = lastDay - firstDay;
                int businessDays = span.Days + 1;
                int fullWeekCount = businessDays / 7;
                // find out if there are weekends during the time exceedng the full weeks
                if (businessDays > fullWeekCount * 7)
                {
                    // we are here to find out if there is a 1-day or 2-days weekend
                    // in the time interval remaining after subtracting the complete weeks
                    //int firstDayOfWeek = (int)firstDay.DayOfWeek;
                    //int lastDayOfWeek = (int)lastDay.DayOfWeek;

                    int firstDayOfWeek = firstDay.DayOfWeek == DayOfWeek.Sunday ? 7 : (int)firstDay.DayOfWeek;
                    int lastDayOfWeek = lastDay.DayOfWeek == DayOfWeek.Sunday ? 7 : (int)lastDay.DayOfWeek;


                    if (lastDayOfWeek < firstDayOfWeek)
                        lastDayOfWeek += 7;
                    if (firstDayOfWeek <= 6)
                    {
                        if (lastDayOfWeek >= 7)// Both Saturday and Sunday are in the remaining time interval
                            businessDays -= 2;
                        else if (lastDayOfWeek >= 6)// Only Saturday is in the remaining time interval
                            businessDays -= 1;
                    }
                    else if (firstDayOfWeek <= 7 && lastDayOfWeek >= 7)// Only Sunday is in the remaining time interval
                        businessDays -= 1;
                }

                // subtract the weekends during the full weeks in the interval
                businessDays -= fullWeekCount + fullWeekCount;
                return businessDays - 1;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - BusinessDaysUntil", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - BusinessDaysUntil", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - BusinessDaysUntil", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - BusinessDaysUntil", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - BusinessDaysUntil", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - BusinessDaysUntil", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        #region Mechanical Related
        //public static EntityCollection GetMultistakeFeeConfiguration(StringBuilder crmTrace, IOrganizationService service, int buildVal, decimal NumofStories, decimal TotalSquarFeet, int FeeTypeValue, Entity targetEntity)
        //{
        //    try
        //    {
        //        EntityCollection RetreivedRecords = new EntityCollection();
        //        crmTrace.AppendLine("Start: New Buildings retrieve fee..");
        //        if (buildVal == (int)FAB4BuildingType.familyHouse1 || buildVal == (int)FAB4BuildingType.familyHouse2 || buildVal == (int)FAB4BuildingType.familyHouse3)
        //        {
        //            RetreivedRecords = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetMultiStakeFee123ConfigRecords, FeeTypeValue)));
        //        }
        //        else if (buildVal == (int)FAB4BuildingType.familyHouseOther)
        //        {
        //            RetreivedRecords = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetMultiStakeFeeConfigRecords, FeeTypeValue, NumofStories, TotalSquarFeet)));
        //        }
        //        crmTrace.AppendLine("End: New Buildings retrieve fee..");
        //        return RetreivedRecords;

        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetGCMHNBFeeConfiguration", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetGCMHNBFeeConfiguration", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //        throw ex;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetGCMHNBFeeConfiguration", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetGCMHNBFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetGCMHNBFeeConfiguration", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetGCMHNBFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        throw ex;
        //    }
        //}
        #endregion

        public static EntityCollection GetPATPAFeeConfiguration(StringBuilder crmTrace, IOrganizationService service, Entity targetEntity)
        {
            try
            {
                EntityCollection FeeConfigResponse = new EntityCollection();
                crmTrace.AppendLine("Start: PA/TPAs retrieve fee..");
                if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))))
                {
                    FeeConfigResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetFeeConfiForPA, FeeConfigName.PlaceOfAssembly.ToString())));
                }
                else if (((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))))
                {
                    FeeConfigResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetFeeConfiForPA, FeeConfigName.TemporaryPlaceOfAssembly.ToString())));
                }
                crmTrace.AppendLine("End: PA/TPA retrieve fee..");
                return FeeConfigResponse;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetPATPAFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static int GetNoOfDaysTPALateFee(StringBuilder crmTrace, IOrganizationService service, Entity targetEntity)
        {
            try
            {
                DateTime eventStartdate = DateTime.Today;
                DateTime today = DateTime.Today;
                int daysDifference = -1;
                int dobCalenderHolidays = 0;
                crmTrace.AppendLine("Start: TPA GetNoOfDayTPAFee..");
                StringBuilder customTrace = new StringBuilder();
                int businessDaysUntil = 0;

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TemporaryPlaceOfAssemblyLookUp))
                {
                    #region Retrive the Event Start time In TPA 
                    ConditionExpression Condition = CreateConditionExpression(TempororayPlaceOfAssembly.jobfilingLookup, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection Response = RetrieveMultiple(service, TempororayPlaceOfAssembly.EntityLogicalName, new string[] { TempororayPlaceOfAssembly.EventStartdate, TempororayPlaceOfAssembly.EventEnddate }, new ConditionExpression[] { Condition }, LogicalOperator.And);
                    crmTrace.AppendLine("TPA Response count" + Response.Entities.Count);
                    #endregion
                    if (Response != null && Response.Entities.Count > 0)
                    {
                        if (Response.Entities[0].Attributes.Contains(TempororayPlaceOfAssembly.EventStartdate))
                        {
                            eventStartdate = ((DateTime)Response.Entities[0].Attributes[TempororayPlaceOfAssembly.EventStartdate]);
                            crmTrace.AppendLine("Event Startdate --- " + eventStartdate);
                            #region Capture the Number of Business days -Excluding the Weekends Saterday And Sunday
                            crmTrace.AppendLine("Today Date--- " + today);
                            crmTrace.AppendLine("Event Start Date--- " + eventStartdate);
                            businessDaysUntil = BusinessDaysUntil(today, eventStartdate, targetEntity, crmTrace);
                            crmTrace.AppendLine("daysDifference excluding DOB Holidays--- " + businessDaysUntil);
                            #endregion

                            #region Calculate the Number of DOB Holidays from Event Start date and System Date
                            dobCalenderHolidays = GetDOBCalenderHolidaysForTPALateFee(service, today, eventStartdate, targetEntity, crmTrace);
                            crmTrace.AppendLine("DOB Calender Holdays--- " + dobCalenderHolidays);
                            #endregion
                            #region Calculate the Days Difference = Business days given event start date - excluding the DOB holidays
                            daysDifference = businessDaysUntil - dobCalenderHolidays;
                            crmTrace.AppendLine("Day Difference--- " + daysDifference);
                            #endregion
                        }

                        else
                        {
                            #region If the Event start date is null Default to the null
                            daysDifference = -1;
                            crmTrace.AppendLine("Day Difference--- " + daysDifference);
                            #endregion
                        }

                    }
                }
                crmTrace.AppendLine("End: TPA GetNoOfDayTPAFee..");
                return daysDifference;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetPATPAFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetPATPAFeeConfiguration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetPATPAFeeConfiguration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static EntityCollection GetTransactionCode(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, List<string> transCode)
        {
            crmTrace.AppendLine("Get transaction codes");
            try
            {
                EntityCollection transCodesResponse = new EntityCollection();

                #region retrieve Transaction Code Info
                crmTrace.AppendLine("Retrieve the transaction code information : started");
                EntityCollection GCMHNBFeeConfigRecords = new EntityCollection();
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < transCode.Count; i++)
                {
                    sb.Append("<value>" + transCode[i] + "</value>");
                }
                transCodesResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetTransactionCodesNB, sb.ToString())));
                crmTrace.AppendLine("Retrieve the transaction code information : ended");
                #endregion

                return transCodesResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static List<Guid> CreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Entity targetEntity, Entity PreImage, EntityCollection transCodesResponse, Guid PaymentHistoryId)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                List<Guid> transactionList = new List<Guid>();
                decimal Fee = 0;
                if (!string.IsNullOrEmpty(targetEntity.Id.ToString()))
                {
                    foreach (var TransCode in transCodesResponse.Entities)
                    {
                        crmTrace.AppendLine("Create Transaction history - Start");

                        Entity transHistory = new Entity();
                        transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCode.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCode.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCode.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCode.Attributes[TransactionCodeAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCode.Attributes[TransactionCodeAttributeNames.TransactionText]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCode.Attributes[TransactionCodeAttributeNames.TransCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCode.Attributes[TransactionCodeAttributeNames.TransType]);
                        //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, TransCode.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCode.ToEntityReference());
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.PaymentInvoice, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId));
                        if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName) || PreImage.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobNumberAttributeName) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName) : PreImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName));
                        Fee = GetTransHistoryFee(service, crmTrace, targetEntity, TransCode.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode), PreImage);
                        if (Fee > 0)
                        {
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, new Money(Fee));
                            Guid Id = service.Create(transHistory);
                            transactionList.Add(Id);
                        }
                        crmTrace.AppendLine("Create Transaction history - end");
                    }
                }
                return transactionList;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static decimal GetTransHistoryFee(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, string Code, Entity PreImage)
        {
            try
            {
                decimal amountPaid = 0;
                EntityCollection FeeConfigResponse = new EntityCollection();
                //Record Management Code
                if (Code == TransactionCodes.RecordManagement123 || Code == TransactionCodes.RecordManagementOther)
                {
                    return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.RecordManagementFee).Value;
                }
                //Legalization Code
                if (Code == TransactionCodes.Legalization)
                {
                    return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.LegalizationFilingFee).Value;
                }
                //NoGoodCheck Code
                if (Code == TransactionCodes.CheckBounceFee)
                {
                    FeeConfigResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetCheckBounceFee, FeeConfigName.CheckBounceFeeConfig.ToString())));
                    if (FeeConfigResponse.Entities.Count > 0)
                        return Convert.ToDecimal(FeeConfigResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                }
                //PAA Code
                if (Code == TransactionCodes.PAA)
                {
                    return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value;
                }
                //Adjustments Code
                if (Code == TransactionCodes.Adjustment)
                {
                    if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    {
                        EntityCollection response = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetIsPostedCount, targetEntity.Id.ToString())));
                        if (response.Entities.Count > 0)
                        {
                            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                        }
                        else
                        {
                            if (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value <= targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value)
                            {
                                return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value;
                            }
                        }
                    }
                    else
                    {
                        return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                    }
                }
                //FilingBalance Code
                if (Code == TransactionCodes.PATransCode || Code == TransactionCodes.TPATransCode)
                {
                    #region Amount Paid
                    if (PreImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                    {
                        amountPaid = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) && targetEntity[JobFilingEntityAttributeName.AmountPaid] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value :
                            PreImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value;
                    }
                    else
                    {
                        amountPaid = 0;
                    }
                    #endregion

                    #region Legalization- Mechanical Related
                    //if (targetEntity.Contains(JobFilingEntityAttributeName.LegalizationFilingFee) && (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.LegalizationFilingFee).Value) > 0)
                    //{
                    //    EntityCollection response = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetIsPostedCount, targetEntity.Id.ToString())));
                    //    if (response.Entities.Count > 0)
                    //    {
                    //        if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    //        {
                    //            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value;
                    //        }
                    //        else
                    //        {
                    //            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value;
                    //        }
                    //    }
                    //    else
                    //    {
                    //        if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    //        {
                    //            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value - amountPaid - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.LegalizationFilingFeeAttributeName).Value - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value;
                    //        }
                    //        else
                    //        {
                    //            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value - amountPaid - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.LegalizationFilingFeeAttributeName).Value - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.RecordManagementFee).Value;
                    //        }
                    //    }
                    //}
                    #endregion

                    #region PAA
                    if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    {
                        return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value - amountPaid;
                    }
                    #endregion

                    #region Initial/Subsequent
                    else
                    {
                        if (amountPaid == 0)
                        {
                            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value - amountPaid - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.RecordManagementFee).Value;
                        }
                        else
                        {
                            return targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value - amountPaid;
                        }
                    }
                    #endregion                  
                }
                return 0;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateAmonutDue", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static Guid CreateUpdatePaymentHistoryRecord(IOrganizationService service, Entity targetEntity, Entity PreImage, ParameterCollection SharedVariables, StringBuilder crmTrace, decimal AmountDue)
        {
            try
            {
                Guid paymenthistory = new Guid();
                string PHCreateUpdate = string.Empty;
                bool IsPaymentPosted = false;
                if (SharedVariables.Contains(SharedVariableNames.PHCreatUpdate) && SharedVariables[SharedVariableNames.PHCreatUpdate] != null)
                {
                    PHCreateUpdate = SharedVariables[SharedVariableNames.PHCreatUpdate].ToString();
                }
                if (SharedVariables.Contains(SharedVariableNames.IsPaymentPosted) && SharedVariables[SharedVariableNames.IsPaymentPosted] != null)
                {
                    IsPaymentPosted = (bool)SharedVariables[SharedVariableNames.IsPaymentPosted];
                }
                if (PHCreateUpdate == "Create")
                {
                    string jobNumber = string.Empty;
                    Entity paymentHistory = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                    EntityReference jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                        jobNumber = targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();
                    crmTrace.AppendLine("create CreateUpdatePaymentHistoryRecord  - start");
                    paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])).ToString())))
                            paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));
                    if (IsPaymentPosted)
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                    if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    {
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.ParentJobFilng, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])));
                    }
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.BuildingType, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType));
                    }
                    crmTrace.AppendLine("IsPosted : " + paymentHistory.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted));
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                    {
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.EstimatedJobCost, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost));
                    }
                    paymenthistory = service.Create(paymentHistory);
                    targetEntity.SetAttributeValue(JobFilingEntityAttributeName.PaymentHistoryGUID, paymenthistory.ToString());
                }
                else if (PHCreateUpdate == "Update")
                {
                    string PaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : PreImage.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID);
                    Entity ExistingPH = service.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(true));
                    string jobNumber = string.Empty;
                    EntityReference jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                        jobNumber = targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();
                    crmTrace.AppendLine("Update CreateUpdatePaymentHistoryRecord  - start");
                    ExistingPH.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])).ToString())))
                            ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])));
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));

                    if (targetEntity.Attributes.Contains(FeeTypeName.CustomIsPaymentPosted) && targetEntity.GetAttributeValue<bool>(FeeTypeName.CustomIsPaymentPosted))
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.IsPosted, true);
                    }
                    else
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.IsPosted, false);
                    }
                    if (targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                            if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])).ToString())))
                                ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.ParentJobFilng, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])));

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.BuildingType, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType));
                    }

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.EstimatedJobCost, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost));
                    }
                    service.Update(ExistingPH);
                    paymenthistory = new Guid(PaymentHistoryGUID);
                    targetEntity.SetAttributeValue(JobFilingEntityAttributeName.PaymentHistoryGUID, paymenthistory.ToString());
                }
                crmTrace.AppendLine("create  Payment History Record - End");
                return paymenthistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalNewBuildingAltHelper - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static int GetDOBCalenderHolidaysForTPALateFee(IOrganizationService service, DateTime firstDay, DateTime lastDay, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {

                int dobCalenderHolidays = 0;
                crmTrace.AppendLine("Start: TPA GetDOBCalenderHolidaysForTPALateFee..");
                StringBuilder customTrace = new StringBuilder();
                #region Query the Holiday Entitys holiday in between the System Date and Event Start Date
                ConditionExpression Condition = CreateConditionExpression(HolidaysEntityAttributeNames.Date, ConditionOperator.LessThan, new string[] { lastDay.ToString() });
                ConditionExpression Condition1 = CreateConditionExpression(HolidaysEntityAttributeNames.Date, ConditionOperator.GreaterThan, new string[] { firstDay.ToString() });
                EntityCollection Response = RetrieveMultiple(service, HolidaysEntityAttributeNames.EntityLogicalName, new string[] { HolidaysEntityAttributeNames.Name }, new ConditionExpression[] { Condition, Condition1 }, LogicalOperator.And);
                #endregion
                crmTrace.AppendLine("GetDOBCalenderHolidaysForTPALateFee Response count" + Response.Entities.Count);

                if (Response != null && Response.Entities.Count > 0)
                {
                    dobCalenderHolidays = Response.Entities.Count;
                }

                return dobCalenderHolidays;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetDOBCalenderHolidaysForTPALateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetDOBCalenderHolidaysForTPALateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetDOBCalenderHolidaysForTPALateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalNewBuildingAltHelper - GetDOBCalenderHolidaysForTPALateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetDOBCalenderHolidaysForTPALateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetDOBCalenderHolidaysForTPALateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

    }
}
