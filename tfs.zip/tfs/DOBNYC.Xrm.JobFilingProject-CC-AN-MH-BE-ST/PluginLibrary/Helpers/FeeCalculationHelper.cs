﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;

using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Helpers
{
    class FeeCalculationHelper : PluginHandlerBase
    {
        #region Filing Fees Calculation
        public static FeeCalculationObject CalculateFilingFees(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, EntityCollection calcResponse, decimal estJobCost)
        {

            FeeCalculationObject fcObject = new FeeCalculationObject();
            int minFilingFee = 0;
            int recordManFee = 0;
            int legalMin = 0;
            int legalMul = 0;
            decimal tier1Cost = 0;
            decimal tier2Cost = 0;
            decimal totalJobCost = 0;
            decimal diffJobCost = 0;
            decimal interJobCost = 0;
            decimal paaFee = 0;
            decimal legalJobCost = 0;

            if (estJobCost > 5000)
            {
                diffJobCost = Math.Ceiling((estJobCost - 5000) / 1000);

            }

            //crmTrace.AppendLine("Fee Calculation started!");
            //ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
            //EntityCollection calcResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.Tier1CostFee, FeeCalculationConfigurationAttributeNames.Tier2CostFee, FeeCalculationConfigurationAttributeNames.RecordManagementFee, FeeCalculationConfigurationAttributeNames.MinFilingFee, FeeCalculationConfigurationAttributeNames.LegalizationMinFee, FeeCalculationConfigurationAttributeNames.LegalizationFeeMul }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.Or);
            //crmTrace.AppendLine("Entity Collection Completed");
            //crmTrace.AppendLine("Respone count" + calcResponse.Entities.Count);


            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                minFilingFee = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                tier1Cost = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier1CostFee].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier2CostFee))
                tier2Cost = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier2CostFee].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                recordManFee = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationMinFee))
                legalMin = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationMinFee].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationFeeMul))
                legalMul = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationFeeMul].ToString().Trim());

            if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                paaFee = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString().Trim());

            #region Calculation Logic
            //If JobType is NewJob
            try
            {

                switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                {

                    case 1:
                    case 2:
                    case 3:
                        crmTrace.AppendLine("Fee Calculation formulae - ongoing");
                        if (estJobCost <= 5000)
                        {
                            crmTrace.AppendLine("Estimated Job Cost < 5000 - Start");
                            interJobCost = minFilingFee;
                            totalJobCost = interJobCost + recordManFee;
                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_filingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nlFilingFees", interJobCost);
                            crmTrace.AppendLine("Estimated Job Cost < 5000 - End");
                        }

                        if (estJobCost > 5000)
                        {
                            crmTrace.AppendLine("Estimated Job Cost > 5000 - Start");
                            interJobCost = (minFilingFee + (diffJobCost * tier1Cost));
                            totalJobCost = interJobCost + recordManFee;

                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_filingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nlFilingFees", interJobCost);
                            crmTrace.AppendLine("Estimated Job Cost > 5000 - End");
                        }


                        if ((targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.Legal)
                            || (targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.NJLegal))

                        //if ((((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == (int)JobType.Legal) || ((((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == (int)JobType.NJLegal)))
                        {

                            crmTrace.AppendLine("Legal Filing - 123 Family - Start");

                            legalJobCost = legalMul * interJobCost;

                            if (legalJobCost < legalMin)
                            {
                                legalJobCost = legalMin;
                            }

                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_legalizationfilingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_legalizationfilingfees", legalJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nLlegalizationfilingfees", legalJobCost);
                            crmTrace.AppendLine("Legal Filing - 123 Family - End");
                        }
                        break;

                    case 4:
                        if (estJobCost <= 3000)
                        {
                            crmTrace.AppendLine("Estimated Job Cost < 3000 - Start");
                            interJobCost = minFilingFee;
                            totalJobCost = interJobCost + recordManFee;
                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_filingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nlFilingFees", interJobCost);
                            crmTrace.AppendLine("Estimated Job Cost < 3000 - End");
                        }

                        if (estJobCost > 3000 & estJobCost <= 5000)
                        {
                            crmTrace.AppendLine("Estimated Job Cost between 3000 and 5000 - Start");
                            if (estJobCost <= 4000)
                                interJobCost = minFilingFee + tier1Cost;
                            else if (estJobCost > 4000)
                                interJobCost = minFilingFee + (2 * tier1Cost);
                            totalJobCost = interJobCost + recordManFee;
                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_filingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nlFilingFees", interJobCost);
                            crmTrace.AppendLine("Estimated Job Cost between 3000 and 5000 - End");
                        }

                        if (estJobCost > 5000)
                        {
                            crmTrace.AppendLine("Estimated Job Cost > 5000 - Start");
                            interJobCost = minFilingFee + (2 * tier1Cost) + (diffJobCost * tier2Cost);
                            totalJobCost = interJobCost + recordManFee;
                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_filingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nlFilingFees", interJobCost);
                            crmTrace.AppendLine("Estimated Job Cost > 5000 - End");
                        }

                        //if ((((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == (int)JobType.Legal) || ((((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == (int)JobType.NJLegal)))
                        if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.Legal) ||
                           (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.NJLegal))
                        {
                            crmTrace.AppendLine("Legal Other - Start");

                            legalJobCost = legalMul * interJobCost;
                            if (legalJobCost < legalMin)
                            {
                                legalJobCost = legalMin;
                            }
                            if (!calcResponse.Entities[0].Attributes.Contains("dobnyc_legalizationfilingfees"))
                                calcResponse.Entities[0].Attributes.Add("dobnyc_legalizationfilingfees", legalJobCost);
                            else
                                calcResponse.Entities[0].Attributes.Add("dobnyc_nLlegalizationfilingfees", legalJobCost);
                            crmTrace.AppendLine("Legal Other - End");
                        }
                        break;

                }
                crmTrace.AppendLine("Fee Calculation End");
                #endregion

                fcObject.NewWorkFilingFee = interJobCost.ToString();
                fcObject.RecordManagementFee = recordManFee.ToString();
                fcObject.PAAFee = paaFee.ToString();
                fcObject.TotalFee = totalJobCost.ToString();
                fcObject.LegalizationFilingFee = legalJobCost.ToString();

                return fcObject;

            }
            catch (Exception ex)
            {
                crmTrace.AppendLine(ex.Message);
                DOBLogger.WriteTraceLog("CalculateFilingFees", "SourceChannel", "Execute", crmTrace.ToString(), " Execute trace log", "User ID", "FeeCalculationHelper");
                throw new Exception(ex.Message);
            }

        }


        #endregion

        public static EntityCollection GetFeeCalculatorParameters(string formulaeName, IOrganizationService service, StringBuilder Trace)
        {
            Trace.AppendLine("Get Fee Calculation Parameters based on formulae name as input - Start");
            try
            {
                ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
                EntityCollection calcResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.MinFilingFee ,
                FeeCalculationConfigurationAttributeNames.Tier1CostFee,FeeCalculationConfigurationAttributeNames.Tier2CostFee,FeeCalculationConfigurationAttributeNames.RecordManagementFee,
                FeeCalculationConfigurationAttributeNames.LegalizationMinFee,FeeCalculationConfigurationAttributeNames.LegalizationFeeMul, FeeCalculationConfigurationAttributeNames.InConjunctionJobFee,
                    FeeCalculationConfigurationAttributeNames.PaaFee, FeeCalculationConfigurationAttributeNames.CheckBounce,FeeCalculationConfigurationAttributeNames.SubsequentFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                Trace.AppendLine("Get Fee Calculation Parameters based on formulae name as input - End");
                return calcResponse;
            }
            catch (Exception ex)
            {
                Trace.AppendLine(ex.Message);
                DOBLogger.WriteTraceLog("JobFilingPostUpdateOperation", "SourceChannel", "Execute", Trace.ToString(), " Execute trace log", "User ID", "UserBrowserInfo");
                throw new Exception(ex.Message);
            }

        }

        #region Construct Calculation Name from Values from
        public static string BuildCalcName(Entity targetEntity, StringBuilder Trace)
        {
            int buildVal = 0;
            Trace.AppendLine("Enter BuildCalcName Function");
            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value;
            Trace.AppendLine("Building Type: " + buildVal);

            //This method retutns the Calculation Name(formulae name) to retrieve the 
            //appropriate record to calculate the Filing fee from the Filing Fee Calculation Configuration entity
            string calcName = string.Empty;
            try
            {
                switch (buildVal)
                {
                    case 1:
                    case 2:
                    case 3:
                        {
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true)
                            {
                                calcName = "CurbCut " + BuildingTypeName.familyHouse123 + " " + FeeTypeName.FilingFees;
                            }
                            else if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Construction Fence";
                            }
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Sidewalk Shed";
                            }
                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Supported Scaffold";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouse123 + " " + "Sign";
                            }

                            else
                            {
                                calcName = BuildingTypeName.familyHouse123 + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                            }
                            break;
                        }

                    //case 2:
                    //    {
                    //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true)
                    //        {
                    //            calcName = "CurbCut " + BuildingTypeName.familyHouse123 + " " + FeeTypeName.FilingFees;
                    //        }
                    //        else
                    //        {
                    //            calcName = BuildingTypeName.familyHouse123 + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                    //        }
                    //        break;
                    //    }
                    //case 3:
                    //    {
                    //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true)
                    //        {
                    //            calcName = "CurbCut " + BuildingTypeName.familyHouse123 + " " + FeeTypeName.FilingFees;
                    //        }
                    //        else
                    //        {
                    //            calcName = BuildingTypeName.familyHouse123 + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                    //        }
                    //        break;
                    //    }
                    case 4:
                        {
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true)
                            {
                                calcName = "CurbCut " + BuildingTypeName.familyHouseOther + " " + FeeTypeName.FilingFees;
                            }
                            else if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Construction Fence";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Sidewalk Shed";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Supported Scaffold";
                            }

                            else if (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                            {
                                calcName = "Fab4 " + BuildingTypeName.familyHouseOther + " " + "Sign";
                            }
                            else
                            {
                                calcName = BuildingTypeName.familyHouseOther + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                            }
                            break;
                        }
                }

                Trace.AppendLine("Exit BuildCalcName Function " + calcName);
                return calcName;

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("BuildCalcName", "FeeCalculationHelper", "Execute", Trace.ToString(), " Execute trace log", "User ID", "FeeCalculationHelper");
                throw new Exception(ex + " crmTrace: " + Trace.ToString());
            }

        }
        #endregion


        #region Create Transaction History based on Transaction Codes
        public static List<Guid> CreateEntityTransCodes(StringBuilder crmTrace, IOrganizationService service, List<string> transCodes, EntityCollection filingLegalFeeCollection, Entity targetEntity, EntityCollection transCodeCollection, Entity preImage)
        {
            #region Variables
            decimal AmountDue = 0;
            decimal PAAAmount = 0;
            decimal Adjustments = 0;
            #endregion

            crmTrace.AppendLine("Enter Create Transaction History function");
            //  crmTrace.AppendLine("transactionList count " + transCodes.Count.ToString());
            int jobType = 0;
            int filingType = 0;
            Entity jobFilingEntity = new Entity();
            EntityReference jobFilingIdReference = new EntityReference();
            List<Guid> transactionList = new List<Guid>();
            if (targetEntity.Id != null)
                jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
            crmTrace.AppendLine("jobfiling reference id" + jobFilingIdReference);

            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType))
                jobType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value;
            crmTrace.AppendLine("jobfiling jobType " + jobType);

            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
            crmTrace.AppendLine("jobfiling filingType" + filingType);
            Guid thGuid = new Guid();

            try
            {
                foreach (var tcollection in transCodeCollection.Entities)
                {
                    for (int i = 0; i < transCodes.Count; i++)
                    {
                        if (transCodes[i] == tcollection.Attributes[TransactionCodeAttributeNames.TransCode].ToString())
                        {

                            crmTrace.AppendLine("trans Code " + i + "is " + transCodes[i]);
                            Entity transHistory = new Entity();
                            transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                            //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, tcollection.ToEntityReference());
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                            // for curbcut job number will  be there in preimage and we are not merging target entity and preimage for curbcut. So we are getting job number from preimage
                            if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName) || preImage.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                                transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobNumberAttributeName) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName) : preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName));
                            if (tcollection.Contains(TransactionCodeAttributeNames.FeeSchemaName))
                            {
                                // transaction history for curbcut filing 
                                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity[JobFilingEntityAttributeName.CCCheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true))
                                {

                                    #region
                                    crmTrace.AppendLine("check if curbcut check box is true");
                                    // transaction code for curbcut
                                    if (transCodes[i] == "171")
                                    {

                                        crmTrace.AppendLine("Curbcut transaction code");
                                        // curbcut fee calculation is based on the size of cut  so filing fee will be dynamic and can not be fetched from fee calculation config but can be retrieved from target entity
                                        if ((preImage != null && preImage.Contains(JobFilingEntityAttributeName.AmountPaid) && preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value > 0)
                                            || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true))
                                        {
                                            //paa filing - amount not paid && amound due >100 then $100 should go to paa remaining should go to filing fee
                                            crmTrace.AppendLine("if filing type paa");
                                            if (filingType == 2 && !FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value > 100)
                                            {
                                                CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, new Money(targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value - 100));
                                                // CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue));
                                            }
                                            else
                                            {
                                                crmTrace.AppendLine("set amount due");
                                                CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue));
                                            }
                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("set new work filing fee");
                                            CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee));
                                        }

                                    }

                                    // if filing type is paa set paa fee($100)
                                    else if (filingType == 2 && transCodes[i] == "123")
                                    {

                                        // if paa amount due is less than 100 set that to amount due
                                        crmTrace.AppendLine("paa transaction code- start" + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value);
                                        if (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value >= 0 && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value < 100)
                                        {
                                            // if amount due is in between 0 -100 then two transaction histories should be created 1)paa th-100 2)overage(paafee -amountdue)
                                            CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, new Money(new decimal(100)));
                                            transactionList.Add(createPAATransactionHistory(crmTrace, service, targetEntity, TransactionCodes.Adjustment, new Money(100 - targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value)));
                                        }
                                        else
                                            CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee));
                                        crmTrace.AppendLine("paa transaction code- end");
                                    }
                                    //record management fee
                                    else if (transCodes[i] == "198" || transCodes[i] == "199")
                                    {
                                        crmTrace.AppendLine("record management  transaction code- start" + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.RecordManagementFee).Value);
                                        CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.RecordManagementFee));
                                        crmTrace.AppendLine("record management transaction code- end");
                                    }

                                    //for Adjustment check the transaction code and is submitted flag. And set the temporary adjustment to fee in transaction history
                                    else if (transCodes[i] == "212" && ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true) ||
                                        targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true))
                                    {

                                        // if paa and adjustment is there then we have to add two transcation history records 1)PAA TH(100) 2) Adjustment with adjustment value
                                        if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                                        {
                                            transactionList.Add(createPAATransactionHistory(crmTrace, service, targetEntity, TransactionCodes.PAA, new Money(100)));

                                        }
                                        crmTrace.AppendLine("Set adjustment to fee");
                                        CommonPluginLibrary.SetAttributeValue(transHistory, TransactionHistoryAttributeNames.Fees, preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund));
                                        // transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund));
                                    }
                                    #endregion
                                }
                                else
                                {
                                    if (filingLegalFeeCollection.Entities[0].Contains(tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString()))
                                    {
                                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, new Money
                                            (decimal.Parse(filingLegalFeeCollection.Entities[0].Attributes[tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString()].ToString())));
                                    }                        
                                }
                            }
                            if ((transHistory.Attributes.Contains(TransactionHistoryAttributeNames.Fees) && transHistory[TransactionHistoryAttributeNames.Fees] != null && transHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees).Value > 0))
                            {
                                crmTrace.AppendLine("creation of transaction history");
                                thGuid = service.Create(transHistory);
                                transactionList.Add(thGuid);
                                crmTrace.AppendLine("trans history Guid " + thGuid.ToString());
                            }
                            if (filingType == 2 &&
                                (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == false))
                            {
                                jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                if (tcollection.Attributes[TransactionCodeAttributeNames.TransCode].ToString().Trim() == TransactionCodes.PAA)
                                {
                                    if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.TransactionHistoryGUID))
                                        jobFilingEntity.Attributes.Remove(JobFilingEntityAttributeName.TransactionHistoryGUID);
                                    jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.TransactionHistoryGUID, thGuid.ToString());
                                }
                                else
                                {
                                    if (!jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.TransactionHistoryGUID))
                                        jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.TransactionHistoryGUID, string.Empty);
                                }
                                if (targetEntity.Id != null)
                                {
                                    jobFilingEntity.Id = targetEntity.Id;
                                    crmTrace.AppendLine("Job Filing ID " + jobFilingEntity.Id);
                                    service.Update(jobFilingEntity);
                                }
                            }
                            else
                            {
                                if (jobType == 1 || jobType == 3)
                                {
                                    if (tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString().Trim() == "dobnyc_filingfees")
                                    {
                                        jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                        jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.TransactionHistoryGUID, thGuid.ToString());
                                        if (targetEntity.Id != null)
                                            jobFilingEntity.Id = targetEntity.Id;
                                        crmTrace.AppendLine("Job Filing ID " + jobFilingEntity.Id);
                                        service.Update(jobFilingEntity);
                                    }
                                }
                                if (jobType == 2)
                                {
                                    if (tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString().Trim() == "dobnyc_legalizationfilingfees")
                                    {
                                        jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                        jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.TransactionHistoryGUID, thGuid.ToString());
                                        if (targetEntity.Id != null)
                                            jobFilingEntity.Id = targetEntity.Id;
                                        service.Update(jobFilingEntity);
                                    }
                                }
                            }

                        }

                    }

                }
                return transactionList;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("Create Transaction History for Fees", "SourceChannel", "Execute", crmTrace.ToString() + "\n" + ex.Message, " Execute trace log", "User ID", "FeeCalculationHelper");
                throw new Exception(ex.Message);
            }
        }
        #endregion


        #region Create Payment History
        public static void CreatePaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, List<Guid> transHistoryGuids, decimal amountDue)
        {
            Entity paymentHistory = new Entity();
            Guid paymentHistoryId = Guid.Empty;
            string jobNumber = string.Empty;
            Entity jobFilingEntity = new Entity();
            //  List<string> transCodesList = null;
            EntityReferenceCollection tHistory = new EntityReferenceCollection();
            EntityReference jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);

            if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                jobNumber = targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();
            crmTrace.AppendLine("Enter Create Payment History");
            try
            {
                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                    if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])).ToString())))
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])));

                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money(amountDue));

                if (targetEntity.Attributes.Contains(FeeTypeName.CustomIsPaymentPosted))
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);

                if (targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])).ToString())))
                            paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.ParentJobFilng, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])));

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                {
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.BuildingType, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType));
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                {
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.EstimatedJobCost, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost));
                }
                paymentHistoryId = service.Create(paymentHistory);
                crmTrace.AppendLine("Payment History guid Update Done");

                if (transHistoryGuids != null && transHistoryGuids.Count > 0)
                {
                    crmTrace.AppendLine("tHResponse count: " + transHistoryGuids.Count);
                    for (int i = 0; i < transHistoryGuids.Count; i++)
                    {
                        tHistory.Add(new EntityReference(TransactionHistoryAttributeNames.EntityLogicalName, transHistoryGuids[i]));
                    }

                    crmTrace.AppendLine("Start Association for Payment History - Start");
                    service.Associate(PaymentHistoryAttributeNames.EntityLogicalName, paymentHistoryId, new Relationship(PaymentHistoryAttributeNames.PaymentHistTransHistRelationShipName), tHistory);
                    crmTrace.AppendLine("End Association for Payment History - End");

                }
                Entity paymentHistoryEntity = Retrieve(service, new string[] { PaymentHistoryAttributeNames.InvoiceNumber }, paymentHistoryId, PaymentHistoryAttributeNames.EntityLogicalName);

                //Update Job Filing Entity With created payment history record guid
                jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, paymentHistoryId.ToString());
                // jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                if (targetEntity.Id != null)
                    jobFilingEntity.Id = targetEntity.Id;
                service.Update(jobFilingEntity);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("Create Payment History for Fees", "CRM", "Execute", crmTrace.ToString() + "\n" + ex.Message, " Execute trace log", "User ID", "FeeCalculationHelper");
                throw new Exception(ex.Message);
            }
        }

        #endregion


        #region Queryexpression for Retrieving from Transhistory Intersect Entity
        public static EntityCollection RetrieveIntersectEntity(IOrganizationService service, StringBuilder crmTrace, EntityCollection calcResponse, Entity targetEntity)
        {
            crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity - Start");
            EntityCollection transCollection = null;
            try
            {
                QueryExpression query = new QueryExpression()
                {
                    EntityName = TransactionCodeAttributeNames.EntityLogicalName,
                    ColumnSet = new ColumnSet(TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory, TransactionCodeAttributeNames.RevenueSource,
                        TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText, TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.TransType,
                        TransactionCodeAttributeNames.FeeSchemaName,  TransactionCodeAttributeNames.IsLegalizationFee),
                    LinkEntities =
                        {
                            new LinkEntity()
                            {

                                LinkFromEntityName = TransactionCodeAttributeNames.EntityLogicalName,
                                LinkFromAttributeName = TransactionCodeAttributeNames.Id,
                                LinkToEntityName = FeeCalculationTransactionCodeIntersect.EntityLogicalName,
                                LinkToAttributeName = TransactionCodeAttributeNames.Id,
                                LinkCriteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions =
                                    {
                                        new ConditionExpression
                                        {
                                            AttributeName = FeeCalculationConfigurationAttributeNames.Id,
                                            Operator = ConditionOperator.Equal,
                                            Values = { calcResponse.Entities[0].Id }
                                        }
                                    }
                                }
                            }
                        }
                };

                transCollection = service.RetrieveMultiple(query);
                crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity - End");

            }
            catch (Exception ex)
            {
                crmTrace.AppendLine(ex.Message);
                DOBLogger.WriteTraceLog("FeeCalculationPlugin", "SourceChannel", "RetrieveIntesectEntity", crmTrace.ToString(), " Execute trace log", "User ID", "UserBrowserInfo");


            }
            return transCollection;
        }
        #endregion


        #region Transaction History Update in case of estimation job cost change
        public static void TransactionHistoryUpdate(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Guid tHistoryGuid, string fee, Guid pHistoryGuid)
        {
            crmTrace.AppendLine("Udpdate transaction history record - Start");
            Entity tHistroy = new Entity();
            try
            {
                Entity paymentResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, pHistoryGuid, PaymentHistoryAttributeNames.EntityLogicalName);

                if (paymentResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                {
                    if ((bool)paymentResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                    {
                        tHistroy.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                        tHistroy.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);
                        tHistroy.Id = tHistoryGuid;
                        service.Update(tHistroy);
                    }
                }

                crmTrace.AppendLine("Udpdate transaction history record - End");
            }
            catch (Exception ex)
            {
                crmTrace.AppendLine(ex.Message);
                DOBLogger.WriteTraceLog("TransactionHistory Update", "SourceChannel", "Execute", crmTrace.ToString(), "Execute trace log", "User ID", "UserBrowserInfo");
            }
        }
        #endregion


        /* Curb Cut Fee Calculation

            Fee is Independent on Size of cut field in Curb Cut Questionnaire Entity

            Fee exempt:
                Filing fee = 0$ (flat)
                PAA = 0$ (flat)

            Linear foot : $3 - 1,2,3 family
                          $6 - Others 

            Record Management Fee : $45 - 1,2,3 family
                                    $165 - Others

            Filing Fee:
                New Work Filing Fee = Minimum filing fee(130) + (Size of Cut * Linear foot)
                Total Fee = New Work Filing Fee + Record Management Fee

            Inconjunction:
                Total Filing fee = Inconjunction fee = 100$ (flat)
                      
    */

        public static void CurbCutFeeCalculation(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, string MessageName)
        {
            try
            {
                #region Set Fee Parameters

                Entity Curbcut = new Entity();
                string formulaeName = string.Empty;
                decimal minFilingFee = 0;
                int recordManagementFee = 0;
                decimal tier1Cost = 0;
                decimal totalJobCost = 0;
                decimal interJobCost = 0;
                decimal amountDue = 0;
                decimal amountPaid = 0;
                decimal paaamountpaid = 0;
                decimal getRefund = 0;
                decimal totalFee = 0;
                decimal paaFee = 0;
                decimal filingType = 0;
                decimal noGoodcheckFee = 0;

                Entity jobFiling = new Entity();
                FeeCalculationObject fcObject = new FeeCalculationObject();
                List<Guid> transHistoryGuids = new List<Guid>();
                List<string> transCodesList = new List<string>();
                EntityCollection transCodesResponse = new EntityCollection();
                EntityCollection getFeeParameterResponse = new EntityCollection();

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                {

                    amountPaid = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) && targetEntity[JobFilingEntityAttributeName.AmountPaid] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value :
                         preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value;
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Refund))
                {
                    getRefund = ((Money)preImage.Attributes[JobFilingEntityAttributeName.Refund]).Value;
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingFees))
                {
                    totalFee = ((Money)(preImage.Attributes[JobFilingEntityAttributeName.FilingFees])).Value;
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                {
                    // filingType = ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                    filingType = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value :
                        preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;

                }
                if (preImage.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                {
                    noGoodcheckFee = preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                }

                ////set amount paid if paa amount paid has value   
                //amountPaid = amountPaid + paaamountpaid;
                #endregion


                #region Delete old payment history records

                // Delete old payment history's for a record
                crmTrace.AppendLine("Delete old payment history records - Start");
                FeeCalculationHelper.DeleteOldPaymentHistoryCC(service, crmTrace, targetEntity, preImage);
                crmTrace.AppendLine("Delete old payment history records - End");

                #endregion

                #region Is Fee Exempt
                // Is Fee exempt
                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true) &&
                  (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == true))
                {

                    crmTrace.AppendLine("fee exempt - start");
                    FeeCalculationHelper.FeeExemptCC(service, crmTrace, targetEntity, preImage);
                    crmTrace.AppendLine("fee exempt - End");
                }
                #endregion

                #region Curb Cut Fee Calculation
                // Curb cut fee calculation 

                else if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true &&
                         targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == false
                         && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == false
                         && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == false)
                {

                    // Retreive Size of cut field from curbcut Questionnaire Entity
                    crmTrace.AppendLine("Check if curb cut questionnaire contains data and not eqaul to null");
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        EntityReference CCQuestionnaire = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCQuestionnaire) ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.CCQuestionnaire) : preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.CCQuestionnaire);
                        crmTrace.AppendLine("Retrieve the curb cut questionnaire id and Size of cut value- Start");
                        Curbcut = service.Retrieve(CurbCutQuestionnaireAttributeNames.EntityLogicalName, CCQuestionnaire.Id, new ColumnSet(new string[] { CurbCutQuestionnaireAttributeNames.SizeofCut }));
                        crmTrace.AppendLine("Retrieve the curb cut questionnaire id and Size of cut value -End");
                    }

                    //Formulae name for Curbcut
                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);

                    //Get fee calculation configuartion attributes . This collection has all the multipliers and paramters values needed to calculate fee
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);

                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFilingFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString().Trim());
                    crmTrace.AppendLine("Variable Assignments - End" + minFilingFee);

                    if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                        tier1Cost = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier1CostFee].ToString().Trim());
                    crmTrace.AppendLine("Variable Assignments - End" + tier1Cost);

                    if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        recordManagementFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString().Trim());
                    crmTrace.AppendLine("Variable Assignments - End" + recordManagementFee);

                    if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                        paaFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString().Trim());
                    crmTrace.AppendLine("Variable Assignments - End" + paaFee);

                    crmTrace.AppendLine("Variable Assignments - End");

                    //check if curbcut contains size of cut value otherwise don't calculate fee
                    if (Curbcut.Contains(CurbCutQuestionnaireAttributeNames.SizeofCut) && Curbcut[CurbCutQuestionnaireAttributeNames.SizeofCut] != null && Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut) > 0
                        && filingType != 2 && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == false)
                    {
                        //Fee calculation formula for curb cut
                        crmTrace.AppendLine("calculate fee for 123 family - start :" + minFilingFee + " tier1cost:" + tier1Cost + " Size of Cut" + Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut));
                        interJobCost = (minFilingFee + (Convert.ToDecimal(Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut)) * tier1Cost));
                        crmTrace.AppendLine("calculate fee for 123 family - End" + interJobCost);
                        totalJobCost = interJobCost + recordManagementFee + noGoodcheckFee;
                        crmTrace.AppendLine("calculate fee for 123 family - End" + totalJobCost);
                        crmTrace.AppendLine("calculate fee for 123 family - start :" + minFilingFee + " tier1cost:" + tier1Cost + "tc" + totalJobCost + " Size of Cut" + Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut));

                    }
                    // if the filing type is paa 
                    else if (Curbcut.Contains(CurbCutQuestionnaireAttributeNames.SizeofCut) && Curbcut[CurbCutQuestionnaireAttributeNames.SizeofCut] != null && Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut) > 0
                        && filingType == 2)
                    {
                        crmTrace.AppendLine("calculate PAA fee for 123 family - start :" + minFilingFee + " tier1cost:" + tier1Cost + " Size of Cut" + Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut));
                        interJobCost = (minFilingFee + (Convert.ToDecimal(Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut)) * tier1Cost));
                        crmTrace.AppendLine("get the total fee including paa fee- start");
                        // if paa and alt bis job
                        //if (targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                        //{
                        //    totalJobCost = interJobCost + paaFee;
                        //    recordManagementFee = 0;
                        //}
                        //else
                        //{
                        //total job includes paa fee
                        totalJobCost = interJobCost + recordManagementFee + paaFee + noGoodcheckFee;
                        //}
                        crmTrace.AppendLine("get the total fee including paa fee- end" + totalJobCost);
                        //adding paa transaction cosde to list
                        // if is posted yes then not creating payment history records

                        if (!isPostedPaymentHistories(service, crmTrace, targetEntity))
                            transCodesList.Add(TransactionCodes.PAA);
                    }
                    //// Alt bis job condition - record management fee is 0
                    //else if (Curbcut.Contains(CurbCutQuestionnaireAttributeNames.SizeofCut) && Curbcut[CurbCutQuestionnaireAttributeNames.SizeofCut] != null && Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut) > 0 &&
                    //    (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true))
                    //{
                    //    crmTrace.AppendLine("Record Management Fee");
                    //    interJobCost = (minFilingFee + (Convert.ToDecimal(Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut)) * tier1Cost));
                    //    totalJobCost = interJobCost;
                    //    crmTrace.AppendLine("Total Amount" + totalJobCost);
                    //    recordManagementFee = 0;
                    //    crmTrace.AppendLine("record management fee " + recordManagementFee);
                    //    crmTrace.AppendLine("totalPayable ");
                    //}
                    else
                    {
                        recordManagementFee = 0;
                    }

                    crmTrace.AppendLine("if total filing fee is less that amount paid");

                    if (totalJobCost > amountPaid)
                    {
                        fcObject.amountDue = totalJobCost - amountPaid;
                        crmTrace.AppendLine("Build Jobfiling Entity for Update - Populate Amount Due");
                    }
                    else if (totalJobCost < amountPaid)
                    {
                        crmTrace.AppendLine("Job filing Curb cut Entity for Update - Populate Adjustment Amount");
                        fcObject.refund = amountPaid - totalJobCost;

                        // to set amount due to paa fee if estimated cost is increased
                        if (!FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity) && fcObject.refund == 0)
                        {
                            // jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                            fcObject.amountDue = paaFee;
                        }
                        else
                        {
                            // jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(0));
                            fcObject.amountDue = 0;
                        }
                    }
                    else if (totalJobCost == amountPaid && MessageName == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {
                        fcObject.amountDue = 0;
                        fcObject.refund = 0;
                    }
                    // this block will execute only for PAA create
                    if (totalJobCost == amountPaid && MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && filingType == 2)
                    {
                        fcObject.amountDue = paaFee;
                        fcObject.refund = 0;
                    }
                    crmTrace.AppendLine("terst" + totalJobCost + "ap" + amountPaid + "ad" + fcObject.amountDue + "ft" + filingType);
                    crmTrace.AppendLine("calculate amount due");

                    crmTrace.AppendLine("set all fields with respective values - start");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(interJobCost));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(totalJobCost));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(recordManagementFee));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodcheckFee));
                    //CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(fcObject.amountDue));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EstimatedJobCostLegal, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LegalizationFilingFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(fcObject.refund));
                    //Setting paa fee if filing type is paa or else 0.
                    if (filingType == 2)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(paaFee));
                    }
                    else
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(0));
                    }
                    crmTrace.AppendLine("set all fields with respective values - end");
                    //Update target Entity
                    crmTrace.AppendLine("set total fee" + JobFilingEntityAttributeName.TotalFeeAttributeName + "amountDue" + JobFilingEntityAttributeName.AmountDue);

                    service.Update(targetEntity);
                    crmTrace.AppendLine("update completed");

                    #endregion
                    if (fcObject.amountDue > 0)
                    {

                        #region Create Transaction History, Payment History
                        //Get transaction code attributes
                        crmTrace.AppendLine("Get transaction code attributes - start");
                        transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                        crmTrace.AppendLine("Get transaction code attributes - end");
                        if (amountPaid == 0)
                        {
                            // if amount paid equal to 0  then only filing fee transaction code and record management fee codes should be generated.
                            crmTrace.AppendLine("Add filing balance and record management transaction codes to transcode list- start");
                            transCodesList.Add(TransactionCodes.FilingBalanceCurbCut);
                            if (recordManagementFee > 0)
                            {
                                switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                {
                                    case 1:
                                    case 2:
                                    case 3:

                                        transCodesList.Add(TransactionCodes.RecordManagement123);
                                        break;
                                    case 4:
                                        transCodesList.Add(TransactionCodes.RecordManagementOther);
                                        break;
                                }
                            }

                            crmTrace.AppendLine("Add filing balance and record management transaction codes to transcode list- end");

                            // Create Transaction History
                            crmTrace.AppendLine("create transaction history record- Start");
                            transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                            crmTrace.AppendLine("create transaction history record- End");

                            //Create Payment history
                            crmTrace.AppendLine("create payment history record- Start");
                            CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, fcObject.amountDue);
                            crmTrace.AppendLine("create payment history record- End");
                        }
                        else if (amountPaid != 0)
                        {
                            if (!(filingType == 2 && MessageName == PluginHelperStrings.CreateMessageName.ToUpper()))
                            {
                                //paa FILING - amount not paid && amound due >100 then $100 should go to paa remaining should go to filing fee
                                if (!isPostedPaymentHistories(service, crmTrace, targetEntity) && fcObject.amountDue > 100)
                                {
                                    // if amount paid not equal to 0 and if increase in size of cut then only filing fee transaction code should be generated.
                                    transCodesList.Add(TransactionCodes.FilingBalanceCurbCut);
                                }
                                //paa FILING - some amount  paid && amound due >0 then all amount should go to filing fee
                                else if (isPostedPaymentHistories(service, crmTrace, targetEntity) && fcObject.amountDue > 0)
                                {

                                    transCodesList.Add(TransactionCodes.FilingBalanceCurbCut);
                                }
                            }
                            // Create Transaction History
                            crmTrace.AppendLine("create transaction history record- Start");
                            transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                            crmTrace.AppendLine("create transaction history record- End");
                            crmTrace.AppendLine("create payment history record- Start" + fcObject.amountDue);
                            CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, fcObject.amountDue);
                            crmTrace.AppendLine("create payment history record- End");
                        }
                        #endregion
                    }

                }

                #region Is In Conjunction
                else if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true)
                {

                    crmTrace.AppendLine("Is In conjunction - Start");
                    IsInConjunctionCC(service, crmTrace, targetEntity, preImage);
                    crmTrace.AppendLine("Is In conjunction - end");
                }
                #endregion

                #region Set Adjustment

                if ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true)
                    || (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true)
                {

                    crmTrace.AppendLine("set Adjustment - Start");
                    SetAdjustmentCC(service, crmTrace, targetEntity, preImage);
                    crmTrace.AppendLine("set Adjustment -End");
                }
                #endregion
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Job filing fee calcl testing purpose11", null, crmTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CurbCutFeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static bool isPostedPaymentHistories(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            try
            {

                //retreive the Job filing application field and Is posted equals to Yes
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_jobfilinglookup' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_jobfiling' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='1' operator='eq'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                EntityCollection OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                if (OldPhhistory.Entities.Count > 0)
                {
                    return true;
                }
                return false;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - isPostedPaymentHistories", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void DeleteOldPaymentHistoryCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        {
            try
            {

                //retreive the Job filing application field and Is posted equals to NO and No good check flag No
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_jobfilinglookup' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_jobfiling' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='0' operator='eq'/>
                            <condition attribute='dobnyc_nogoodcheckflag' operator='eq' value='0'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                EntityCollection OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                if (OldPhhistory.Entities.Count > 0)
                {
                    foreach (Entity phhistory in OldPhhistory.Entities)
                    {
                        crmTrace.AppendLine("Delete old payment history records -start");
                        service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phhistory.Id);
                        crmTrace.AppendLine("Delete old payment history records-DeleteOldPaymentHistoryCC - end");
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void FeeExemptCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        {
            try
            {
                decimal amountPaid = 0;
                decimal filingType = 0;
                decimal totalFee = 0;
                decimal amountDue = 0;
                string formulaeName = string.Empty;
                List<Guid> transHistoryGuids = new List<Guid>();
                List<string> transCodesList = new List<string>();
                EntityCollection transCodesResponse = new EntityCollection();
                EntityCollection getFeeParameterResponse = new EntityCollection();
                decimal paaFee = 0;

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                {
                    amountPaid = ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                {
                    filingType = ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                }
                //set amount paid if paa paid field has values
                //amountPaid = amountPaid + paaamountPaid;
                //crmTrace.AppendLine("amount paid -fee exempt" + amountPaid);

                crmTrace.AppendLine("formulae Name - fee exempt" + formulaeName);
                formulaeName = BuildCalcName(targetEntity, crmTrace);

                //Get fee calculation configuartion attributes to get paa fee
                crmTrace.AppendLine("get fee calculation configuration attributes -fee exempt");
                getFeeParameterResponse = GetFeeCalculatorParameters(formulaeName, service, crmTrace);

                if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                    paaFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString().Trim());  //added for the bug fix 8631
                    crmTrace.AppendLine("paa fee" + paaFee);


                crmTrace.AppendLine("Filing - is Fee Exempt - Start");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == true)
                {
                    if (amountPaid != 0 && filingType != 2)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(amountPaid));
                    }
                    //if paa set paa fee to total fee
                    if (filingType == 2)
                    {
                        // totalFee = paaFee;
                        //if (!FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity))
                        //{
                        totalFee = paaFee;
                        // }
                        //else
                        //{
                        //    totalFee = 0;
                        //}
                        crmTrace.AppendLine("total fee -fee exempt" + totalFee);
                        // if paid has some value and then fee exempt then refund should be amount paid - paa fee
                        // CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(amountPaid - paaFee));
                    }
                    crmTrace.AppendLine("Update Filing with 0 as Fee exempt");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingFees, new Money(totalFee));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(0));
                    // CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);

                    if (filingType == 2)
                    {

                        //I1 fee exempt and when p1 intializes then amount due should be 100
                        if (!FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity))
                        {

                            if (amountPaid > totalFee)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(amountPaid - paaFee));
                                amountDue = 0;
                            }
                            else
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                                amountDue = paaFee;
                            }
                            //  CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                        }
                        else
                        {
                            //if payment posted and then did fee exempt then amount should go to refund.
                            if (amountPaid > totalFee)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(amountPaid - paaFee));
                            }
                            // I1  non fee exempt and p1 is  fee exempt
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                            amountDue = 0;
                        }
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(paaFee));
                    }
                    else
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                        amountDue = 0;
                    }
                    service.Update(targetEntity);

                    crmTrace.AppendLine(" Set fields to 0 and update target entity - fee exempt");

                    // create transaction history and payment history incase of  paa

                    if (filingType == 2)
                    {
                        crmTrace.AppendLine("retrieve transaction codes -fee exempt");
                        transCodesResponse = RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                        crmTrace.AppendLine("retrieve the paa transaction code from the list");
                        transCodesList.Add(TransactionCodes.PAA);
                        crmTrace.AppendLine("create transaction history for paa - fee exempt -start");
                        if (amountDue > 0)
                        {
                            transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                            crmTrace.AppendLine("create transaction history for paa - fee exempt -end");
                            //amountDue = paaFee;
                            crmTrace.AppendLine("create payment history for paa - fee exempt -start");
                            CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                            crmTrace.AppendLine("create payment history for paa - fee exempt -end");

                        }
                    }

                }
                crmTrace.AppendLine("Filing - is Fee Exempt - End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void FeeExemptElectrical(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        {
            try
            {
                decimal amountPaid = 0;
                decimal filingType = 0;
                decimal totalFee = 0;
                decimal amountDue = 0;
                string formulaeName = string.Empty;
                List<Guid> transHistoryGuids = new List<Guid>();
                List<string> transCodesList = new List<string>();
                EntityCollection transCodesResponse = new EntityCollection();
                EntityCollection getFeeParameterResponse = new EntityCollection();
                decimal paaFee = 0;

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                {
                    amountPaid = ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                {
                    filingType = ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                }

                //set amount paid if paa paid field has values
                //amountPaid = amountPaid + paaamountPaid;
                //crmTrace.AppendLine("amount paid -fee exempt" + amountPaid);

                crmTrace.AppendLine("formulae Name - fee exempt" + formulaeName);
                formulaeName = BuildCalcName(targetEntity, crmTrace);

                //Get fee calculation configuartion attributes to get paa fee
                crmTrace.AppendLine("get fee calculation configuration attributes -fee exempt");
                getFeeParameterResponse = GetFeeCalculatorParameters(formulaeName, service, crmTrace);

                if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                    paaFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString().Trim());
                crmTrace.AppendLine("paa fee" + paaFee);


                crmTrace.AppendLine("Filing - is Fee Exempt - Start");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == true)
                {
                    if (amountPaid != 0 && filingType != 2)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(amountPaid));
                    }
                    //if paa set paa fee to total fee
                    if (filingType == 2)
                    {
                        totalFee = paaFee;
                        crmTrace.AppendLine("total fee -fee exempt" + totalFee);
                    }
                    crmTrace.AppendLine("Update Filing with 0 as Fee exempt");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingFees, new Money(totalFee));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                    if (filingType == 2)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                    }
                    else
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                    }
                    service.Update(targetEntity);

                    crmTrace.AppendLine(" Set fields to 0 and update target entity - fee exempt");

                    // create transaction history and payment history incase of  paa

                    if (filingType == 2)
                    {
                        crmTrace.AppendLine("retrieve transaction codes -fee exempt");
                        transCodesResponse = RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                        crmTrace.AppendLine("retrieve the paa transaction code from the list");
                        transCodesList.Add(TransactionCodes.PAA);
                        crmTrace.AppendLine("create transaction history for paa - fee exempt -start");
                        transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                        crmTrace.AppendLine("create transaction history for paa - fee exempt -end");

                        amountDue = paaFee;
                        crmTrace.AppendLine("create payment history for paa - fee exempt -start");
                        CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                        crmTrace.AppendLine("create payment history for paa - fee exempt -end");
                    }

                }
                crmTrace.AppendLine("Filing - is Fee Exempt - End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - FeeExemptCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void IsInConjunctionCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        {
            try
            {
                decimal inConjunctionJobFee = 0;
                decimal amountDue = 0;
                EntityCollection getFeeParameterResponse = new EntityCollection();
                EntityCollection transCodesResponse = new EntityCollection();
                List<Guid> transHistoryGuids = new List<Guid>();
                string formulaeName = string.Empty;
                List<string> transCodesList = new List<string>();
                decimal totalPayable = 0;
                decimal amountPaid = 0;
                decimal refund = 0;
                decimal filingType = 0;
                decimal paaFee = 0;
                decimal noGoodcheckFee = 0;
                decimal inConjunction = 0;
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                {
                    filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                }
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                {
                    amountPaid = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                }
                if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                {
                    noGoodcheckFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                }

                //amountPaid = amountPaid + paapaidfee;
                crmTrace.AppendLine("amount paid -Inconjunction" + amountPaid);

                crmTrace.AppendLine("check if target entity contains Is conjunction job and if its true");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == false))
                {
                    //Formulae name for Curbcut 
                    crmTrace.AppendLine("formulae Name - Inconjunction" + formulaeName);
                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);

                    //Get fee calculation configuartion attributes
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                    crmTrace.AppendLine("In Conjunction job fee " + getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee]);

                    // get paa fee from fee calculation configuration attributes
                    if (getFeeParameterResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                    {
                        paaFee = int.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString().Trim());
                        crmTrace.AppendLine("Variable Assignments - End" + paaFee);
                    }

                    //Get transaction code attributes
                    crmTrace.AppendLine("Get transaction code attributes for inconjunction - start");
                    transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                    if (getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
                    {
                        crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
                        getFeeParameterResponse.Entities[0].Attributes.Remove(FeeTypeName.FilingFeeSchemaName);
                        getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                        crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
                    }

                    else if (!getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
                    {
                        crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
                        getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                        crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
                    }

                    // if filing type is not paa get inconjunction job fee
                    if (filingType != 2)
                    {
                        inConjunction = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                        inConjunctionJobFee = inConjunction + noGoodcheckFee;
                        crmTrace.AppendLine("get inconjunction fee from fee calculation configuration entity" + inConjunctionJobFee);
                    }
                    // if filing type is paa then add paa fee + inconjunction job fee to inconjunction job fee
                    else if (filingType == 2)
                    {
                        inConjunction = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                        inConjunctionJobFee = inConjunction + paaFee + noGoodcheckFee;
                        //get the transaction code for paa
                        transCodesList.Add(TransactionCodes.PAA);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(paaFee));
                    }

                    if (amountPaid == 0)
                    {
                        crmTrace.AppendLine("transaction code for inconjunction- start");
                        transCodesList.Add(TransactionCodes.FilingBalanceCurbCut);
                        crmTrace.AppendLine("transaction code for inconjunction- end");
                        totalPayable = inConjunctionJobFee;
                        amountDue = inConjunctionJobFee;
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));
                        // CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(paaFee));

                    }
                    else if (amountPaid != 0)
                    {

                        totalPayable = inConjunctionJobFee;

                        if (totalPayable == amountPaid)
                        {
                            crmTrace.AppendLine("if total filing fee is equal to amount paid set amount due to 0");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));

                        }
                        if (totalPayable < amountPaid)
                        {
                            crmTrace.AppendLine("if total filing fee is less than amount paid then set refund");
                            refund = amountPaid - totalPayable;
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(refund));

                        }
                        if (totalPayable > amountPaid)
                        {
                            crmTrace.AppendLine("if total filing fee is less than amount paid then set refund");
                            amountDue = totalPayable - amountPaid;
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                            
                        }
                        
                    }
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingFees, new Money(totalPayable));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodcheckFee));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunction));
                    service.Update(targetEntity);
                    crmTrace.AppendLine("End In Conjunction Job");
                    // payment histroy should be created if amount due is greater than 0.
                    if (amountDue > 0)
                    {
                        //create transaction history record
                        crmTrace.AppendLine("Create Transaction History Records for inconjunction - Start");
                        transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                        crmTrace.AppendLine("Create Transaction History Records for inconjunction - End");

                        //Create Payment history
                        FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                        crmTrace.AppendLine("Created Payment History  and Job filing Update with payment history guid done.");
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        //public static void IsInConjunctionCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        //{
        //    try
        //    {
        //        decimal inConjunctionJobFee = 0;
        //        decimal amountDue = 0;
        //        EntityCollection getFeeParameterResponse = new EntityCollection();
        //        EntityCollection transCodesResponse = new EntityCollection();
        //        List<Guid> transHistoryGuids = new List<Guid>();
        //        string formulaeName = string.Empty;
        //        List<string> transCodesList = new List<string>();
        //        decimal totalPayable = 0;
        //        decimal amountPaid = 0;
        //        decimal refund = 0;
        //        decimal filingType = 0;

        //        if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
        //        {
        //            filingType = ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
        //        }

        //        if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
        //        {
        //            amountPaid = ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
        //        }


        //        crmTrace.AppendLine("check if target entity contains Is conjunction job and if its true");
        //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == false))
        //        {
        //            //Formulae name for Curbcut 
        //            crmTrace.AppendLine("formulae Name - Inconjunction" + formulaeName);
        //            formulaeName = BuildCalcName(targetEntity, crmTrace);

        //            //Get fee calculation configuartion attributes
        //            crmTrace.AppendLine("get fee calculation configuration attributes");
        //            getFeeParameterResponse = GetFeeCalculatorParameters(formulaeName, service, crmTrace);
        //            crmTrace.AppendLine("In Conjunction job fee " + getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee]);

        //            //Get transaction code attributes
        //            crmTrace.AppendLine("Get transaction code attributes for inconjunction - start");
        //            transCodesResponse = RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
        //            if (getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
        //            {
        //                crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
        //                getFeeParameterResponse.Entities[0].Attributes.Remove(FeeTypeName.FilingFeeSchemaName);
        //                getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
        //                crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
        //            }

        //            else if (!getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
        //            {
        //                crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
        //                getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
        //                crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
        //            }

        //            crmTrace.AppendLine("get inconjunction fee from fee calculation configuration entity" + inConjunctionJobFee);
        //            inConjunctionJobFee = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());

        //            if (amountPaid == 0)
        //            {
        //                crmTrace.AppendLine("transaction code for inconjunction- start");
        //                transCodesList.Add(TransactionCodes.FilingBalanceCurbCut);
        //                crmTrace.AppendLine("transaction code for inconjunction- end");

        //                amountDue = inConjunctionJobFee;
        //                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
        //                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));

        //            }
        //            else if (amountPaid != 0)
        //            {
        //                totalPayable = inConjunctionJobFee;
        //                if (totalPayable == amountPaid)
        //                {
        //                    crmTrace.AppendLine("if total filing fee is equal to amount paid set amount due to 0");
        //                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
        //                }
        //                if (totalPayable < amountPaid)
        //                {
        //                    crmTrace.AppendLine("if total filing fee is less than amount paid then set refund");
        //                    refund = amountPaid - totalPayable;
        //                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
        //                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(refund));
        //                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));
        //                }
        //            }
        //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingFees, new Money(inConjunctionJobFee));
        //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(0));
        //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
        //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(0));
        //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(0));

        //            service.Update(targetEntity);
        //            crmTrace.AppendLine("End In Conjunction Job");
        //            //create transaction history record
        //            crmTrace.AppendLine("Create Transaction History Records for inconjunction - Start");
        //            transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
        //            crmTrace.AppendLine("Create Transaction History Records for inconjunction - End");

        //            amountDue = inConjunctionJobFee;
        //            //Create Payment history
        //            CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
        //            crmTrace.AppendLine("Created Payment History  and Job filing Update with payment history guid done.");
        //        }
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //        throw ex;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - IsInConjunction", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        throw ex;
        //    }
        //}

        public static void SetAdjustmentCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage)
        {
            try
            {
                #region Set Variables
                decimal refund = 0;
                decimal getRefund = 0;
                decimal filingType = 0;
                Entity jobFiling = new Entity();
                string formulaeName = string.Empty;
                List<string> transCodesList = null;
                EntityCollection getFeeParameterResponse = new EntityCollection();
                EntityCollection transCodesResponse = new EntityCollection();
                List<Guid> transHistoryGuids = new List<Guid>();

                if ((preImage.Contains(JobFilingEntityAttributeName.Refund) && preImage[JobFilingEntityAttributeName.Refund] != null) || (targetEntity.Contains(JobFilingEntityAttributeName.Refund) && targetEntity[JobFilingEntityAttributeName.Refund] != null))
                {

                    //getRefund = ((Money)preImage.Attributes[JobFilingEntityAttributeName.Refund]).Value;
                    getRefund = preImage.Contains(JobFilingEntityAttributeName.Refund) ? preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value : targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value;

                    crmTrace.AppendLine("get refund" + getRefund);

                }
                #endregion

                crmTrace.AppendLine("get refund" + getRefund + targetEntity.Contains(JobFilingEntityAttributeName.Refund));
                if (refund != 0 || getRefund != 0)
                {

                    if (filingType == 2)
                    {
                        crmTrace.AppendLine("Update Payment history with IsPosted as true in case of PAA- Start ");
                        jobFiling = new Entity();
                        Entity paymentHistory = new Entity();
                        if (!targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                            targetEntity.Attributes.Add(FeeTypeName.IsPaa, true);

                        if (targetEntity.Attributes.Contains(FeeTypeName.CustomPhGuid))
                        {
                            if (refund != 0)
                            {
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(refund));
                                targetEntity.Attributes.Add(FeeTypeName.CustomIsPaymentPosted, true);
                            }
                            if (getRefund != 0 && refund == 0)
                            {
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(getRefund));
                                targetEntity.Attributes.Add(FeeTypeName.CustomIsPaymentPosted, true);
                            }

                            paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                            paymentHistory.Id = new Guid(targetEntity.Attributes[FeeTypeName.CustomPhGuid].ToString());
                            paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                            crmTrace.AppendLine("Update Payment history with IsPosted as true in case of PAA- End ");
                            service.Update(paymentHistory);

                        }

                    }
                    else
                    {

                        transCodesList = new List<string>();
                        jobFiling = new Entity();

                        crmTrace.AppendLine("formulae Name" + formulaeName);
                        formulaeName = BuildCalcName(targetEntity, crmTrace);

                        //Get fee calculation configuartion attributes 
                        crmTrace.AppendLine("get fee calculation configuration attributes");
                        getFeeParameterResponse = GetFeeCalculatorParameters(formulaeName, service, crmTrace);

                        if (refund != 0)
                        {

                            getFeeParameterResponse.Entities[0].Attributes.Add(FeeSchemaNames.NewFilingFeeSchemaName, refund);
                            crmTrace.AppendLine("Add refund to fee schema");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(refund));
                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid - refund));
                            targetEntity.Attributes.Add("CustomePaymentPosted", true);
                        }
                        if (getRefund != 0 && refund == 0)
                        {
                            getFeeParameterResponse.Entities[0].Attributes.Add(FeeSchemaNames.NewFilingFeeSchemaName, getRefund);
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(getRefund));
                            // jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid - getRefund));
                            targetEntity.Attributes.Add("CustomePaymentPosted", true);


                        }

                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Id = targetEntity.Id;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                        service.Update(jobFiling);

                        crmTrace.AppendLine("retrieve transaction codes for Adjustment - Start");
                        transCodesResponse = RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                        crmTrace.AppendLine("Add transaction codes to transcodes collection - Start");
                        transCodesList.Add(TransactionCodes.Adjustment);
                        crmTrace.AppendLine("Add transaction codes to transcodes collection  - End");

                        crmTrace.AppendLine("Create Transaction History for Adjustment - Start");
                        transHistoryGuids = CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);

                        crmTrace.AppendLine("Create Transaction History for Adjustment - End");
                        crmTrace.AppendLine("Create Payment History for Adjustment - Start");
                        CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, 0);
                        crmTrace.AppendLine("Create Payment History for Adjustment - End");
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - SetAdjustmentCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static Guid CreatePaymentHistory_NoGoodCheck(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                Entity PaymentHistoryRecord = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                // Set Source Channel as Build
                crmTrace.AppendLine("Set Source Channel as Build");
                PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.SourceChannel, new OptionSetValue(1));

                crmTrace.AppendLine("create Payment History  - start");
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.EntityAttributeName));

                    //Set Name
                    crmTrace.AppendLine("Set NGCPH Flag");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckPH,true);

                    // Set ElevatorApplication lookup
                    crmTrace.AppendLine("Set Jobfiling Lookup");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, targetEntity.ToEntityReference());

                    // Set Total Fee
                    crmTrace.AppendLine("Set Total Fee");
                    if (targetEntity.Contains(JobFilingEntityAttributeName.AmountDue))
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, targetEntity.Attributes[JobFilingEntityAttributeName.AmountDue]);
                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set");
                    //PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.JobFiling));
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));

                }
                else if(targetEntity.LogicalName==OP49EntityAttributeNames.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(OP49EntityAttributeNames.Name));

                    // Set ElevatorApplication lookup
                    crmTrace.AppendLine("Set Jobfiling Lookup");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.GoToOP49, targetEntity.ToEntityReference());

                    // Set Total Fee
                    crmTrace.AppendLine("Set Total Fee");
                    if (targetEntity.Contains(OP49EntityAttributeNames.AmountDue))
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, targetEntity.Attributes[OP49EntityAttributeNames.AmountDue]);
                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set");
                    //PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.JobFiling));
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));

                }
                else if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber));

                    // Set ElevatorApplication lookup
                    crmTrace.AppendLine("Set Jobfiling Lookup");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.GoToPw2, targetEntity.ToEntityReference());

                    // Set Total Fee
                    crmTrace.AppendLine("Set Total Fee");
                    if (targetEntity.Contains(WorkPermitEntityAttributeName.AmountDue))
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, targetEntity.Attributes[WorkPermitEntityAttributeName.AmountDue]);
                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set");
                    //PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.JobFiling));
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.PermitRenewal));

                }
                else if (targetEntity.LogicalName == PW5AfterHoursAttributeNames.EntityLogicalName)
                {
                    //Set Name
                    crmTrace.AppendLine("Set Name");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(PW5AfterHoursAttributeNames.AHVname));

                    // Set ElevatorApplication lookup
                    crmTrace.AppendLine("Set Jobfiling Lookup");
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.GoToAHV, targetEntity.ToEntityReference());

                    // Set Total Fee
                    crmTrace.AppendLine("Set Total Fee");
                    if (targetEntity.Contains(PW5AfterHoursAttributeNames.AmountDue))
                        PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, targetEntity.Attributes[PW5AfterHoursAttributeNames.AmountDue]);
                    //Set feeType
                    crmTrace.AppendLine("Set Fee Type Option Set");
                    //PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue((int)PaymentHistoryFeeType.JobFiling));
                    PaymentHistoryRecord.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.AHV));

                }




                Guid paymenthistory = service.Create(PaymentHistoryRecord);
                crmTrace.AppendLine("create  Payment History Record - End");

                return paymenthistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        // Create transaction history used in EOD handler
        public static Guid CreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Guid jobFilingid, Guid PaymentHistoryId, Entity TransCodeId, Money fee)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                Entity transHistory = null;
                if (!string.IsNullOrEmpty(jobFilingid.ToString()) && !string.IsNullOrEmpty(fee.ToString()))
                {
                    crmTrace.AppendLine("Create Transaction history - Start");
                    transHistory = new Entity();

                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    if (TransCodeId.LogicalName == TransactionCodeAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("add transaction code id to transaction history");
                        // transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.ToEntityReference());
                        crmTrace.AppendLine("add transaction code to transaction history");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode));
                        // transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransactionText));

                        //Added to resolve Production Bug Task#8200
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionCodeAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionCodeAttributeNames.TransType]);
                    }
                    // this if block will be executed in EOD handler.
                    else if (TransCodeId.LogicalName == TransactionHistoryAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("add transaction code id to transaction history-EOD");
                        // transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.GetAttributeValue<EntityReference>(TransactionHistoryAttributeNames.TransactionCodeId));
                        crmTrace.AppendLine("add transaction code to transaction history -EOD");
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode));
                        //Added to resolve Production Bug #task 8200
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionHistoryAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionHistoryAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionHistoryAttributeNames.RevenueSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionHistoryAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionHistoryAttributeNames.TransType]);

                    }
                    //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, TransCodeId.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                    crmTrace.AppendLine("add job filing job number");
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.JobNumber));
                    crmTrace.AppendLine("add job filing payment invoice");
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.PaymentInvoice, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId));
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransactionText));
                    crmTrace.AppendLine("add job filing payment fee");
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);
                    crmTrace.AppendLine("add job filing payment fee-end");

                    Guid Id = service.Create(transHistory);
                    crmTrace.AppendLine("Create Transaction history - end");

                    return Id;
                }
                else
                    return new Guid();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingid.ToString(), "CRM", "FeeCalculationHelper - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void CreateProgressInspectionCategoryRecordForAntenna(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CreateProgressInspectionCategoryRecordForAntenna method");

                string inspectionComponentName = "Final";
                string ICId = string.Empty;
                string ICCode = string.Empty;

                string fetchXML = @"<?xml version='1.0'?>
                                      <fetch distinct='true' mapping='logical' output-format='xml-platform' version='1.0'>
                                       <entity name='dobnyc_specialinspectionscomponents'>
                                        <attribute name='dobnyc_specialinspectionscomponentsid' />
                                        <attribute name='dobnyc_code' />
                                        <attribute name='dobnyc_inspectioncomponentguid' />                                        
                                        <order attribute='dobnyc_code' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_name' operator='eq' value='" + inspectionComponentName + @"'/>                                          
                                        </filter>
                                      </entity>
                                    </fetch>";

                crmTrace.AppendLine("fetchXML: " + fetchXML);
                EntityCollection ICResponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
                if (ICResponse.Entities != null && ICResponse.Entities.Count > 0)
                {
                    foreach (Entity icresponse in ICResponse.Entities)
                    {
                        ICId = icresponse.Id.ToString();
                        ICCode = icresponse.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);
                    }

                    Entity ProgressInspectionCategory = new Entity();
                    ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(6));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                    service.Create(ProgressInspectionCategory);
                }

                crmTrace.AppendLine("End CreateProgressInspectionCategoryRecordForAntenna method");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Inspection Components - Record Exists for Final: End ", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForAntenna", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static Guid createPAATransactionHistory(StringBuilder crmTrace, IOrganizationService service, Entity targetEntity, string formulaeName, Money fee)
        {
            try
            {
                Entity Paatransactionhistory = new Entity();
                List<Guid> transactionList = new List<Guid>();
                EntityReference jobFilingIdReference = new EntityReference();
                if (targetEntity.Id != null)
                    jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                crmTrace.AppendLine("jobfiling reference id" + jobFilingIdReference);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { formulaeName });

                #region retrieve Transaction Code Info
                crmTrace.AppendLine("Retrieve the transaction code information : started");
                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                               TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                               TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource,TransactionCodeAttributeNames.FeeSchemaName,TransactionCodeAttributeNames.TransactionText,
                                                               TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { condition }, LogicalOperator.Or);
                crmTrace.AppendLine("Retrieve the transaction code information : ended");
                Paatransactionhistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.BudgetCode]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.ReportCategory]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.RevenueSource]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.SubSource]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.TransactionText]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.TransCode]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, transactioncodeResponse.Entities[0].Attributes[TransactionCodeAttributeNames.TransType]);
                Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                    Paatransactionhistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName]);
                CommonPluginLibrary.SetAttributeValue(Paatransactionhistory, TransactionHistoryAttributeNames.Fees, fee);
                crmTrace.AppendLine("created paa transaction history-start");
                Guid phGuid = service.Create(Paatransactionhistory);
                crmTrace.AppendLine("created paa transaction history-end");
                return phGuid;
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.ToString(), "CRM", "FeeCalculationHelper - createPAATransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

    }
}


