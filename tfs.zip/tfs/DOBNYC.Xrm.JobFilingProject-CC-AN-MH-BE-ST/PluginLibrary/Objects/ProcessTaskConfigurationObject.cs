﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xrm.Sdk;
using Vrp.Crm.SalesManagement.Common;

namespace Vrp.Crm.SalesManagement.Objects
{
    public class ProcessTaskConfigurationObject
    {
        public const string CRMEntityName = ProcessTaskConfigurationEntity.SchemaName;
        #region Attributes

        private string _objectId;
        public string ObjectId
        {
            get { return _objectId; }
            set { _objectId = value; }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _taskTitle;
        public string TaskTitle
        {
            get { return _taskTitle; }
            set { _taskTitle = value; }
        }

        private string _taskDescription;
        public string TaskDescription
        {
            get { return _taskDescription; }
            set { _taskDescription = value; }
        }

        private bool _enableFirstLevelEscalation;
        public bool EnableFirstLevelEscalation
        {
            get { return _enableFirstLevelEscalation; }
            set { _enableFirstLevelEscalation = value; }
        }

        private bool _enableSecondLevelEscalation;
        public bool EnableSecondLevelEscalation
        {
            get { return _enableSecondLevelEscalation; }
            set { _enableSecondLevelEscalation = value; }
        }

        private int _expectedCompletionDuration;
        public int ExpectedCompletionDuration
        {
            get { return _expectedCompletionDuration; }
            set { _expectedCompletionDuration = value; }
        }

        private int _customerTATHours;
        public int CustomerTATHours
        {
            get { return _customerTATHours; }
            set { _customerTATHours = value; }
        }

        private bool _resolveWithinWorkingDays;
        public bool ResolveWithinWorkingDays
        {
            get { return _resolveWithinWorkingDays; }
            set { _resolveWithinWorkingDays = value; }
        }

        

        

        

        private string _relatedProcessTemplateId;
        public string RelatedProcessTemplateId
        {
            get { return _relatedProcessTemplateId; }
            set { _relatedProcessTemplateId = value; }
        }

        private string _relatedProcessTemplateName;
        public string RelatedProcessTemplateName
        {
            get { return _relatedProcessTemplateName; }
            set { _relatedProcessTemplateName = value; }
        }

        private string _relatedProcessId;
        public string RelatedProcessId
        {
            get { return _relatedProcessId; }
            set { _relatedProcessId = value; }
        }

        private string _relatedProcessName;
        public string RelatedProcessName
        {
            get { return _relatedProcessName; }
            set { _relatedProcessName = value; }
        }

        private string _defaultTaskQueueId;
        public string DefaultTaskQueueId
        {
            get { return _defaultTaskQueueId; }
            set { _defaultTaskQueueId = value; }
        }

        private string _defaultTaskQueueName;
        public string DefaultTaskQueueName
        {
            get { return _defaultTaskQueueName; }
            set { _defaultTaskQueueName = value; }
        }

        private DefaultTaskOwnerType _defaultOwnerType;
        public DefaultTaskOwnerType DefaultTaskOwnerTypeCode
        {
            get { return _defaultOwnerType; }
            set { _defaultOwnerType = value; }
        }


        private string _defaultTaskOwnerUserId;
        public string DefaultTaskOwnerUserId
        {
            get { return _defaultTaskOwnerUserId; }
            set { _defaultTaskOwnerUserId = value; }
        }

        private string _defaultOwnerUserName;
        public string DefaultTaskOwnerUserName
        {
            get { return _defaultOwnerUserName; }
            set { _defaultOwnerUserName = value; }
        }

        private string _defaultTaskOwnerTeamId;
        public string DefaultTaskOwnerTeamId
        {
            get { return _defaultTaskOwnerTeamId; }
            set { _defaultTaskOwnerTeamId = value; }
        }

        private string _defaultOwnerTeamName;
        public string DefaultCaseOwnerTeamName
        {
            get { return _defaultOwnerTeamName; }
            set { _defaultOwnerTeamName = value; }
        }

        private bool _routeToBranch;
        public bool RouteToBranch
        {
            get { return _routeToBranch; }
            set { _routeToBranch = value; }
        }

        #endregion

        public static ProcessTaskConfigurationObject ParseSdkEntityToObject(Entity taskConfigEntity)
        {
            ProcessTaskConfigurationObject processTaskConfigObject = new ProcessTaskConfigurationObject();
            try
            {
                if (taskConfigEntity != null)
                {
                    processTaskConfigObject.ObjectId = taskConfigEntity.Id.ToString();

                    #region Name Field
                    processTaskConfigObject.Name = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.NameFieldName))
                    {
                        processTaskConfigObject.Name = taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.NameFieldName].ToString();
                    }
                    #endregion

                    #region Task Title Field
                    processTaskConfigObject.TaskTitle = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.TaskTitleFieldName))
                    {
                        processTaskConfigObject.TaskTitle = taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.TaskTitleFieldName].ToString();
                    }
                    #endregion

                    #region Task Description Field
                    processTaskConfigObject.TaskDescription = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.TaskDescriptionFieldName))
                    {
                        processTaskConfigObject.TaskDescription = taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.TaskDescriptionFieldName].ToString();
                    }
                    #endregion

                    #region Expected Completion Duration Field
                    processTaskConfigObject.ExpectedCompletionDuration = 0;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.ExpectedCompletionDurationFieldName))
                    {
                        processTaskConfigObject.ExpectedCompletionDuration = (int)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.ExpectedCompletionDurationFieldName];
                    }
                    #endregion

                    #region Customer TAT Field
                    processTaskConfigObject.CustomerTATHours = 0;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.CustomerTATHoursFieldName))
                    {
                        processTaskConfigObject.CustomerTATHours = (int)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.CustomerTATHoursFieldName];
                    }
                    #endregion

                    #region Related Process Field
                    processTaskConfigObject.RelatedProcessId = String.Empty;
                    processTaskConfigObject.RelatedProcessName = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.RelatedProcessIdFieldName))
                    {
                        processTaskConfigObject.RelatedProcessId = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.RelatedProcessIdFieldName]).Id.ToString();
                        processTaskConfigObject.RelatedProcessName = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.RelatedProcessIdFieldName]).Name.ToString();
                    }
                    #endregion

                    #region Related Template Field
                    processTaskConfigObject.RelatedProcessTemplateId = String.Empty;
                    processTaskConfigObject.RelatedProcessTemplateName = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.ProcessTemplateIdFieldName))
                    {
                        processTaskConfigObject.RelatedProcessTemplateId = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.ProcessTemplateIdFieldName]).Id.ToString();
                        processTaskConfigObject.RelatedProcessTemplateName = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.ProcessTemplateIdFieldName]).Name.ToString();
                    }
                    #endregion

                    #region DefaultTaskOwnerTypeCode Field
                    processTaskConfigObject.DefaultTaskOwnerTypeCode = DefaultTaskOwnerType.Undefined;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.TaskOwnerTypeFieldName))
                    {
                        try
                        {
                            processTaskConfigObject.DefaultTaskOwnerTypeCode = (DefaultTaskOwnerType)((OptionSetValue)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.TaskOwnerTypeFieldName]).Value;
                        }
                        catch
                        {
                            processTaskConfigObject.DefaultTaskOwnerTypeCode = DefaultTaskOwnerType.Undefined;
                        }
                    }
                    #endregion

                    #region DefaultTaskOwnerUser Field
                    processTaskConfigObject.DefaultTaskOwnerUserId = String.Empty;
                    processTaskConfigObject.DefaultTaskOwnerUserName = String.Empty;
                    if (processTaskConfigObject.DefaultTaskOwnerTypeCode == DefaultTaskOwnerType.SpecificUser)
                    {

                        if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerUserIdFieldName))
                        {
                            processTaskConfigObject.DefaultTaskOwnerUserId = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerUserIdFieldName]).Id.ToString();
                            processTaskConfigObject.DefaultTaskOwnerUserName = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerUserIdFieldName]).Name.ToString();
                        }
                    }
                    #endregion

                    #region DefaultTaskOwnerTeam Field
                    processTaskConfigObject.DefaultTaskOwnerTeamId = String.Empty;
                    processTaskConfigObject.DefaultCaseOwnerTeamName = String.Empty;
                    if (processTaskConfigObject.DefaultTaskOwnerTypeCode == DefaultTaskOwnerType.SpecificTeam)
                    {

                        if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerTeamIdFieldName))
                        {
                            processTaskConfigObject.DefaultTaskOwnerTeamId = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerTeamIdFieldName]).Id.ToString();
                            processTaskConfigObject.DefaultCaseOwnerTeamName = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultOwnerTeamIdFieldName]).Name.ToString();
                        }
                    }
                    #endregion

                    #region DefaultTaskQueue
                    processTaskConfigObject.DefaultTaskQueueId = String.Empty;
                    processTaskConfigObject.DefaultTaskQueueName = String.Empty;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.DefaultTaskQueueIdFieldName))
                    {
                        processTaskConfigObject.DefaultTaskQueueId = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultTaskQueueIdFieldName]).Id.ToString();
                        processTaskConfigObject.DefaultTaskQueueName = ((EntityReference)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.DefaultTaskQueueIdFieldName]).Name.ToString();
                    }
                    #endregion

                    #region RouteToBranch
                    processTaskConfigObject.RouteToBranch = false;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.RouteToBranchFieldName))
                    {
                        processTaskConfigObject.RouteToBranch = ((Boolean)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.RouteToBranchFieldName]);
                    }
                    #endregion

                    #region Enable 1st Level Escalation
                    processTaskConfigObject.EnableFirstLevelEscalation = false;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.EnableFirstLevelEscalation))
                    {
                        processTaskConfigObject.EnableFirstLevelEscalation = ((Boolean)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.EnableFirstLevelEscalation]);
                    }
                    #endregion

                    #region Enable 2nd Level Escalation
                    processTaskConfigObject.EnableSecondLevelEscalation = false;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.EnableSecondLevelEscalation))
                    {
                        processTaskConfigObject.EnableSecondLevelEscalation = ((Boolean)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.EnableSecondLevelEscalation]);
                    }
                    #endregion

                    #region Resolve within Working Days
                    processTaskConfigObject.ResolveWithinWorkingDays = false;
                    if (taskConfigEntity.Attributes.Contains(ProcessTaskConfigurationEntityAttributeNames.CloseWithinWorkingDays))
                    {
                        processTaskConfigObject.ResolveWithinWorkingDays = ((Boolean)taskConfigEntity.Attributes[ProcessTaskConfigurationEntityAttributeNames.CloseWithinWorkingDays]);
                    }
                    #endregion

                }
            }
            catch (Exception ex) { ExceptionLibrary.ExceptionMethods.ProcessException(ex); throw ex; }
            return processTaskConfigObject;
        }


    }
}
