﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xrm.Sdk;
using Vrp.Crm.SalesManagement.Common;

namespace Vrp.Crm.SalesManagement.Objects
{
    public class TaskOutcomeReasonObject
    {
        public const string CRMEntityName = ProcessTaskOutcomeReasonEntity.SchemaName;
        #region Attributes

        private string _objectId;
        public string ObjectId
        {
            get { return _objectId; }
            set { _objectId = value; }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        #endregion

        public static TaskOutcomeReasonObject ParseSdkEntityToObject(Entity outcomeReasonEntity)
        {
            TaskOutcomeReasonObject taskOutcomeReasonObject = new TaskOutcomeReasonObject();
            try
            {
                if (outcomeReasonEntity != null)
                {
                    taskOutcomeReasonObject.ObjectId = outcomeReasonEntity.Id.ToString();

                    #region Name Field
                    taskOutcomeReasonObject.Name = String.Empty;
                    if (outcomeReasonEntity.Attributes.Contains(TaskOutcomeReasonEntityAttributeNames.NameFieldName))
                    {
                        taskOutcomeReasonObject.Name = outcomeReasonEntity.Attributes[TaskOutcomeReasonEntityAttributeNames.NameFieldName].ToString();
                    }
                    #endregion

                }
            }
            catch (Exception)
            {
                
                throw;
            }
            
            return taskOutcomeReasonObject;
        }
    }
}
