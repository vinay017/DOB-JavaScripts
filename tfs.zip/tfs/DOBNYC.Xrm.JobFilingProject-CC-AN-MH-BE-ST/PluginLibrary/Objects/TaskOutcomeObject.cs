﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xrm.Sdk;
using Vrp.Crm.SalesManagement.Common;

namespace Vrp.Crm.SalesManagement.Objects
{
    public class TaskOutcomeObject
    {
        public const string CRMEntityName = ProcessTaskOutcomeEntity.SchemaName;
        #region Attributes

        private string _objectId;
        public string ObjectId
        {
            get { return _objectId; }
            set { _objectId = value; }
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _relatedTaskConfigurationId;
        public string RelatedTaskConfigurationId
        {
            get { return _relatedTaskConfigurationId; }
            set { _relatedTaskConfigurationId = value; }
        }

        private string _relatedTaskConfigurationName;
        public string RelatedTaskConfigurationName
        {
            get { return _relatedTaskConfigurationName; }
            set { _relatedTaskConfigurationName = value; }
        }

        private string _nextTaskConfigurationId;
        public string NextTaskConfigurationId
        {
            get { return _nextTaskConfigurationId; }
            set { _nextTaskConfigurationId = value; }
        }

        private string _nextTaskConfigurationName;
        public string NextTaskConfigurationName
        {
            get { return _nextTaskConfigurationName; }
            set { _nextTaskConfigurationName = value; }
        }


        private TaskOutcomePostTaskStatus _postTaskStatus;
        public TaskOutcomePostTaskStatus PostTaskStatus
        {
            get { return _postTaskStatus; }
            set { _postTaskStatus = value; }
        }

        private int _opportunityStatus;
        public int OpportunityStatus
        {
            get { return _opportunityStatus; }
            set { _opportunityStatus = value; }
        }

        private int _opportunityStatusReason;
        public int OpportunityStatusReason
        {
            get { return _opportunityStatusReason; }
            set { _opportunityStatusReason = value; }
        }

        private int _opportunityProbability;
        public int OpportunityProbability
        {
            get { return _opportunityProbability; }
            set { _opportunityProbability = value; }
        }

        private int _opportunityRating;
        public int OpportunityRating
        {
            get { return _opportunityRating; }
            set { _opportunityRating = value; }
        }


        private string _opportunityPipelinPhase;
        public string OpportunityPipelinePhase
        {
            get { return _opportunityPipelinPhase; }
            set { _opportunityPipelinPhase = value; }
        }
        #endregion

        public static TaskOutcomeObject ParseSdkEntityToObject(Entity taskOutcomeEntity)
        {
            TaskOutcomeObject taskOutcomeObject = new TaskOutcomeObject();
            try
            {
                if (taskOutcomeEntity != null)
                {
                    taskOutcomeObject.ObjectId = taskOutcomeEntity.Id.ToString();

                    #region Name Field
                    taskOutcomeObject.Name = String.Empty;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.NameFieldName))
                    {
                        taskOutcomeObject.Name = taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.NameFieldName].ToString();
                    }
                    #endregion

                    #region PostTaskStatus Field
                    taskOutcomeObject.PostTaskStatus = TaskOutcomePostTaskStatus.Undefined;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.PostTaskStatusFieldName))
                    {
                        try
                        {
                            taskOutcomeObject.PostTaskStatus = (TaskOutcomePostTaskStatus)((OptionSetValue)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.PostTaskStatusFieldName]).Value;
                        }
                        catch
                        {
                            taskOutcomeObject.PostTaskStatus = TaskOutcomePostTaskStatus.Undefined;
                        }
                    }
                    #endregion

                    #region RelatedProcessTask Field
                    taskOutcomeObject.RelatedTaskConfigurationId = String.Empty;
                    taskOutcomeObject.RelatedTaskConfigurationName = String.Empty;

                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.RelatedProcessTaskFieldName))
                    {
                        taskOutcomeObject.RelatedTaskConfigurationId = ((EntityReference)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.RelatedProcessTaskFieldName]).Id.ToString();
                        taskOutcomeObject.RelatedTaskConfigurationName = ((EntityReference)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.RelatedProcessTaskFieldName]).Name.ToString();
                    }
                    #endregion

                    #region RelatedProcessTask Field
                    taskOutcomeObject.NextTaskConfigurationId = String.Empty;
                    taskOutcomeObject.NextTaskConfigurationName = String.Empty;

                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.NextProcessTaskFieldName))
                    {
                        taskOutcomeObject.NextTaskConfigurationId = ((EntityReference)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.NextProcessTaskFieldName]).Id.ToString();
                        taskOutcomeObject.NextTaskConfigurationName = ((EntityReference)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.NextProcessTaskFieldName]).Name.ToString();
                    }
                    #endregion

                    #region Opportunity Status Field
                    taskOutcomeObject.OpportunityStatus = -1;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.OpportunityStatusFieldName))
                    {
                        taskOutcomeObject.OpportunityStatus = ((OptionSetValue)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.OpportunityStatusFieldName]).Value;
                    }
                    #endregion

                    #region Opportunity Status Reason Field
                    taskOutcomeObject.OpportunityStatusReason = -1;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.OpportunityStatusReasonFieldName))
                    {
                        taskOutcomeObject.OpportunityStatusReason = ((OptionSetValue)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.OpportunityStatusReasonFieldName]).Value;
                    }
                    #endregion

                    #region Opportunity Rating Field
                    taskOutcomeObject.OpportunityRating = -1;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.OpportunityRatingFieldName))
                    {
                        taskOutcomeObject.OpportunityRating = ((OptionSetValue)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.OpportunityRatingFieldName]).Value;
                    }
                    #endregion

                    #region Opportunity Probability Field
                    taskOutcomeObject.OpportunityProbability = -1;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.OpportunityProbabilityFieldName))
                    {
                        taskOutcomeObject.OpportunityProbability = (int)taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.OpportunityProbabilityFieldName];
                    }
                    #endregion

                    #region Opportunity Pipeline Phase Field
                    taskOutcomeObject.OpportunityPipelinePhase = String.Empty;
                    if (taskOutcomeEntity.Attributes.Contains(TaskOutcomeEntityAttributeNames.OpportunityPipelinePhaseFieldName))
                    {
                        taskOutcomeObject.OpportunityPipelinePhase = taskOutcomeEntity.Attributes[TaskOutcomeEntityAttributeNames.OpportunityPipelinePhaseFieldName].ToString();
                    }
                    #endregion

                }
            }
            catch (Exception ex) { ExceptionLibrary.ExceptionMethods.ProcessException(ex); throw ex; }
            return taskOutcomeObject;
        }
    }
}
