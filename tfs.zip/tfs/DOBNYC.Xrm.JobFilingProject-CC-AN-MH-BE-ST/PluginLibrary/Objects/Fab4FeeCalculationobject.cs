﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Objects
{
    public class Fab4FeeCalculationobject
    {
        public decimal TotalFee { get; set; }

        public decimal NewWorkFilingFee { get; set; }

        public decimal RecordManagementFee { get; set; }

      
        public decimal ConstructionFenceFee = 0;

        public decimal ScaffoldFee = 0;

        public decimal SideWalkShedFee = 0;

        public decimal ElectricalFee = 0;

        public decimal SignFee = 0;

        public int BuildingType = 0;

        public decimal Adjustment = 0;

        public decimal AmountDue = 0;

        public decimal existingamountpaid = 0;

        public decimal Landmarkfee = 0;

        public decimal PaaFee = 0;

        public Guid EntityId = new Guid();


    }
}
