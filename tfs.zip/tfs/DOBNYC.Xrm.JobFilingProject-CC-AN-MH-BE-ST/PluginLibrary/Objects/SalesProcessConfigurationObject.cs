﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xrm.Sdk;
using Vrp.Crm.SalesManagement.Common;

namespace Vrp.Crm.SalesManagement.Objects
{
    public class SalesProcessConfigurationObject
    {
        public static string CRMEntityName = SalesProcessConfigurationEntity.SchemaName;
        public static string ProductRelationshipEntityName = RelationshipNames.SalesProcessConfiguration_Product;
        public static string CorporateSegmentRelationshipEntityName = RelationshipNames.SalesProcessConfiguration_CorporateSegment;
        public static string RetailSegmentRelationshipEntityName = RelationshipNames.SalesProcessConfiguration_RetailSegment;

        #region Attributes

        private string _objectId;
        public string ObjectId
        {
            get { return _objectId; }
            set { _objectId = value; }
        }

        private string _productId;
        public string ProductId
        {
            get { return _productId; }
            set { _productId = value; }
        }

        private string _productName;
        public string ProductName
        {
            get { return _productName; }
            set { _productName = value; }
        }

        private DefaultOpportunityOwnerType _defaultOwnerType;
        public DefaultOpportunityOwnerType DefaultOpportunityOwnerTypeCode
        {
            get { return _defaultOwnerType; }
            set { _defaultOwnerType = value; }
        }

        private bool _enableFirstLevelEscalation;
        public bool EnableFirstLevelEscalation
        {
            get { return _enableFirstLevelEscalation; }
            set { _enableFirstLevelEscalation = value; }
        }

        private bool _enableSecondLevelEscalation;
        public bool EnableSecondLevelEscalation
        {
            get { return _enableSecondLevelEscalation; }
            set { _enableSecondLevelEscalation = value; }
        }

        private int _firstLevelSLAHours;
        public int FirstLevelSLAHours
        {
            get { return _firstLevelSLAHours; }
            set { _firstLevelSLAHours = value; }
        }

        private int _secondLevelSLAHours;
        public int SecondLevelSLAHours
        {
            get { return _secondLevelSLAHours; }
            set { _secondLevelSLAHours = value; }
        }

        private bool _isBusinessHours;
        public bool IsBusinessHours
        {
            get { return _isBusinessHours; }
            set { _isBusinessHours = value; }
        }



        private string _workingStartHour;
        public string WorkingStartHour
        {
            get { return _workingStartHour; }
            set { _workingStartHour = value; }
        }

        private string _workingEndHour;
        public string WorkingEndHour
        {
            get { return _workingEndHour; }
            set { _workingEndHour = value; }
        }

        private string _processTemplateId;
        public string ProcessTemplateId
        {
            get { return _processTemplateId; }
            set { _processTemplateId = value; }
        }

        private string _processTemplateName;
        public string ProcessTemplateName
        {
            get { return _processTemplateName; }
            set { _processTemplateName = value; }
        }

        private string _firstProcessTaskId;
        public string FirstProcessTaskId
        {
            get { return _firstProcessTaskId; }
            set { _firstProcessTaskId = value; }
        }

        private string _firstProcessTaskName;
        public string FirstProcessTaskName
        {
            get { return _firstProcessTaskName; }
            set { _firstProcessTaskName = value; }
        }

        private string _defaultOpportunityQueueId;
        public string DefaultOpportunityQueueId
        {
            get { return _defaultOpportunityQueueId; }
            set { _defaultOpportunityQueueId = value; }
        }

        private string _defaultOpportunityQueueName;
        public string DefaultOpportunityQueueName
        {
            get { return _defaultOpportunityQueueName; }
            set { _defaultOpportunityQueueName = value; }
        }

        private string _defaultOpportunityOwnerUserId;
        public string DefaultOpportunityOwnerUserId
        {
            get { return _defaultOpportunityOwnerUserId; }
            set { _defaultOpportunityOwnerUserId = value; }
        }

        private string _defaultOwnerUserName;
        public string DefaultOpportunityOwnerUserName
        {
            get { return _defaultOwnerUserName; }
            set { _defaultOwnerUserName = value; }
        }

        private string _defaultOpportunityOwnerTeamId;
        public string DefaultOpportunityOwnerTeamId
        {
            get { return _defaultOpportunityOwnerTeamId; }
            set { _defaultOpportunityOwnerTeamId = value; }
        }

        private string _defaultOwnerTeamName;
        public string DefaultOpportunityOwnerTeamName
        {
            get { return _defaultOwnerTeamName; }
            set { _defaultOwnerTeamName = value; }
        }

        private string _salesProcessWorkflowId;
        public string SalesProcessWorkflowId
        {
            get { return _salesProcessWorkflowId; }
            set { _salesProcessWorkflowId = value; }
        }

        private string _salesProcessWorkflowName;
        public string SalesProcessWorkflowName
        {
            get { return _salesProcessWorkflowName; }
            set { _salesProcessWorkflowName = value; }
        }

        private bool _routeToBranch;
        public bool RouteToBranch
        {
            get { return _routeToBranch; }
            set { _routeToBranch = value; }
        }

        private string _productQueue;
        public string ProductQueue
        {
            get { return _productQueue; }
            set { _productQueue = value; }
        }

        #endregion

        public static SalesProcessConfigurationObject ParseSdkEntityToObject(Entity salesProcessConfigEntity)
        {
            SalesProcessConfigurationObject salesProcessConfigObject = new SalesProcessConfigurationObject();
            try
            {
                if (salesProcessConfigEntity != null)
                {
                    salesProcessConfigObject.ObjectId = salesProcessConfigEntity.Id.ToString();
                    #region Product Field
                    salesProcessConfigObject.ProductId = String.Empty;
                    salesProcessConfigObject.ProductName = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.ProductIdFieldName))
                    {
                        salesProcessConfigObject.ProductId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.ProductIdFieldName]).Id.ToString();
                        salesProcessConfigObject.ProductName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.ProductIdFieldName]).Name;
                    }
                    #endregion

                    #region DefaultOpportunityOwnerTypeCode Field
                    salesProcessConfigObject.DefaultOpportunityOwnerTypeCode = DefaultOpportunityOwnerType.Undefined;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerTypeFieldName))
                    {
                        try
                        {
                            salesProcessConfigObject.DefaultOpportunityOwnerTypeCode = (DefaultOpportunityOwnerType)((OptionSetValue)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerTypeFieldName]).Value;
                        }
                        catch
                        {
                            salesProcessConfigObject.DefaultOpportunityOwnerTypeCode = DefaultOpportunityOwnerType.Undefined;
                        }
                    }
                    #endregion

                    #region DefaultOpportunityOwnerUser Field
                    salesProcessConfigObject.DefaultOpportunityOwnerUserId = String.Empty;
                    salesProcessConfigObject.DefaultOpportunityOwnerUserName = String.Empty;
                    if (salesProcessConfigObject.DefaultOpportunityOwnerTypeCode == DefaultOpportunityOwnerType.SpecificUser)
                    {

                        if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerUserFieldName))
                        {
                            salesProcessConfigObject.DefaultOpportunityOwnerUserId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerUserFieldName]).Id.ToString();
                            salesProcessConfigObject.DefaultOpportunityOwnerUserName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerUserFieldName]).Name;
                        }
                    }
                    #endregion

                    #region DefaultOpportunityOwnerTeam Field
                    salesProcessConfigObject.DefaultOpportunityOwnerTeamId = String.Empty;
                    salesProcessConfigObject.DefaultOpportunityOwnerTeamName = String.Empty;
                    if (salesProcessConfigObject.DefaultOpportunityOwnerTypeCode == DefaultOpportunityOwnerType.SpecificTeam)
                    {

                        if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerTeamFieldName))
                        {
                            salesProcessConfigObject.DefaultOpportunityOwnerTeamId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerTeamFieldName]).Id.ToString();
                            salesProcessConfigObject.DefaultOpportunityOwnerTeamName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityOwnerTeamFieldName]).Name;
                        }
                    }
                    #endregion

                    #region RouteToBranch
                    salesProcessConfigObject.RouteToBranch = false;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.RouteToBranchFieldName))
                    {
                        salesProcessConfigObject.RouteToBranch = ((Boolean)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.RouteToBranchFieldName]);
                    }
                    #endregion

                    #region DefaultOpportunityQueue
                    salesProcessConfigObject.DefaultOpportunityQueueId = String.Empty;
                    salesProcessConfigObject.DefaultOpportunityQueueName = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityQueueFieldName))
                    {
                        salesProcessConfigObject.DefaultOpportunityQueueId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityQueueFieldName]).Id.ToString();
                        salesProcessConfigObject.DefaultOpportunityQueueName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.DefaultOpportunityQueueFieldName]).Name;
                    }
                    #endregion

                    #region DefaultProductQueue
                    salesProcessConfigObject.ProductQueue = String.Empty;

                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.ProductQueueFieldName))
                    {
                        salesProcessConfigObject.ProductQueue = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.ProductQueueFieldName]).Id.ToString();

                    }
                    #endregion

                    #region FirstProcessTask
                    salesProcessConfigObject.FirstProcessTaskId = String.Empty;
                    salesProcessConfigObject.FirstProcessTaskName = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.FirstProcessTaskConfigFieldName)
                        && salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.FirstProcessTaskConfigFieldName] != null)
                    {
                        salesProcessConfigObject.FirstProcessTaskId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.FirstProcessTaskConfigFieldName]).Id.ToString();
                        salesProcessConfigObject.FirstProcessTaskName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.FirstProcessTaskConfigFieldName]).Name;
                    }
                    #endregion

                    #region SalesProcessWorkflow
                    salesProcessConfigObject.SalesProcessWorkflowId = String.Empty;
                    salesProcessConfigObject.SalesProcessWorkflowName = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.SalesProcessWorkflowFieldName))
                    {
                        salesProcessConfigObject.SalesProcessWorkflowId = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.SalesProcessWorkflowFieldName]).Id.ToString();
                        salesProcessConfigObject.SalesProcessWorkflowName = ((EntityReference)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.SalesProcessWorkflowFieldName]).Name;
                    }
                    #endregion

                    #region Is Business Hours
                    salesProcessConfigObject.IsBusinessHours = false;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.IsBusinessHours))
                    {
                        salesProcessConfigObject.IsBusinessHours = ((Boolean)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.IsBusinessHours]);
                    }
                    #endregion

                    #region Working Start Hour
                    salesProcessConfigObject.WorkingStartHour = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.WorkingStartHour))
                    {
                        salesProcessConfigObject.WorkingStartHour = salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.WorkingStartHour].ToString();
                    }
                    #endregion

                    #region Working End Hour
                    salesProcessConfigObject.WorkingEndHour = String.Empty;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.WorkingEndHour))
                    {
                        salesProcessConfigObject.WorkingEndHour = salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.WorkingEndHour].ToString();
                    }
                    #endregion

                    #region Enable 1st Level Escalation
                    salesProcessConfigObject.EnableFirstLevelEscalation = false;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.EnableFirstLevelEscalation))
                    {
                        salesProcessConfigObject.EnableFirstLevelEscalation = ((Boolean)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.EnableFirstLevelEscalation]);
                    }
                    #endregion

                    #region 1st Level Escalation Hours
                    salesProcessConfigObject.FirstLevelSLAHours = 0;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.FirstLevelSLAFieldName))
                    {
                        salesProcessConfigObject.FirstLevelSLAHours = int.Parse((salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.FirstLevelSLAFieldName].ToString()));
                    }
                    #endregion

                    #region Enable 2nd Level Escalation
                    salesProcessConfigObject.EnableSecondLevelEscalation = false;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.EnableSecondLevelEscalation))
                    {
                        salesProcessConfigObject.EnableSecondLevelEscalation = ((Boolean)salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.EnableSecondLevelEscalation]);
                    }
                    #endregion

                    #region 2nd Level Escalation Hours
                    salesProcessConfigObject.SecondLevelSLAHours = 0;
                    if (salesProcessConfigEntity.Attributes.Contains(SalesProcessConfigurationEntityAttributeNames.SecondLevelSLAFieldName))
                    {
                        salesProcessConfigObject.SecondLevelSLAHours = int.Parse(salesProcessConfigEntity.Attributes[SalesProcessConfigurationEntityAttributeNames.SecondLevelSLAFieldName].ToString());
                    }
                    #endregion
                }
            }
            catch (Exception ex) { ExceptionLibrary.ExceptionMethods.ProcessException(ex); throw ex; }
            return salesProcessConfigObject;
        }

    }
}
