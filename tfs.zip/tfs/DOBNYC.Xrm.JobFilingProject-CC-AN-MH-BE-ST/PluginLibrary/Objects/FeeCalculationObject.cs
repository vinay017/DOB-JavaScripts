﻿using DOBNYC.XRM.JobFiling.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Objects
{
    public class FeeCalculationObject : IFeeCalculationObject
    {
        //add all worktype flags
        #region Worktype Flags

        public bool IsBE { get; set; } //Boiler
        public bool IsMS { get; set; } //Mechanical
        public bool IsST { get; set; } //Structural
        public bool IsPL { get; set; } //PLSPSD
        public bool IsSP{ get; set; } //PLSPSD
        public bool IsSD { get; set; } //PLSPSD
        public bool IsAN { get; set; } //Antenna
        public bool IsCC { get; set; } //Curbcut
        public bool IsFN { get; set; } //Fence
        public bool IsSH { get; set; } //side walk shed
        public bool IsSF { get; set; } //Supported scaffold
        public bool IsSG { get; set; } //Signs
        public bool IsPA { get; set; } //PA

        public bool IsTPA { get; set; } //TPA
        public bool IsEL { get; set; } //Electrical
        public bool IsGC { get; set; } //GC

        #endregion

        public int jobType { get; set; }
        public bool isAlterationCofoBigAlt { get; set; }
        public string TotalFee { get; set; }

        public string NewWorkFilingFee { get; set; }

        public string FormulaName { get; set; }

        public string LegalizationFilingFee { get; set; }

        public string RecordManagementFee { get; set; }

        public string PAAFee { get; set; }

        public decimal amountDue { get; set; }

        public decimal refund { get; set; }

        public decimal NoGoodCheckFee { get; set; }

        public decimal InConjunctionFee { get; set; }

        public int JobNBorAltType { get; set; }

        public int FilingType { get; set; }
        public int FilingStatus { get; set; }

        public bool IsFeeExempt { get; set; }

        public bool IsConjunction { get; set; }
        public bool IsLegalization { get; set; }
        public bool IsPAA { get; set; }

        public bool IsPATPA { get; set; }

        public decimal PATPAFilingFee { get; set; }

        public decimal Tier1CostFee { get; set; }

        public decimal Tier2CostFee { get; set; }

        public decimal TotalSquarFeet { get; set; }

        public decimal MinFilingFee { get; set; }

        public decimal SubsequentNBFee { get; set; }

        public decimal RecordManagementFees { get; set; }

        public decimal PAAFees { get; set; }

        public decimal LegalizationFilingFees { get; set; }

        public decimal EstimatedCost { get; set; }

        public decimal ExistingAmountPaid { get; set; }

        public decimal MinEstFeeCostException { get; set; }

        public decimal TPALateFees { get; set; }
        //public decimal AmountDue { get; set; }
        public int BuildingType { get; set; }

        public decimal Adjustment { get; set; }

        public int JobStatus { get; set; }
        public int OwnerType { get; set; }

        public decimal BEMSSTFilingfee { get; set; }
        public bool PHPostedFlag { get; set; }//sets to true in adjustment case
        public decimal FilingFee
        {
            get
            {
                if (IsFeeExempt || IsConjunction)
                {
                    return 0;
                }
                if (IsPATPA)
                {
                    if (FilingType == (int)FilingTypes.IF || FilingType == (int)FilingTypes.PA)
                    {
                        return PATPAFilingFee;
                    }
                    else if (FilingType == (int)FilingTypes.SF)
                    {
                        return SubsequentNBFee;
                    }
                }

                #region Mechanical Related
                //else
                //{
                //    switch (JobNBorAltType)
                //    {
                //        case (int)JobTypeNBorAlt.NewBuilings:
                //            {
                //                if (FilingType == (int)FilingTypes.IF || FilingType == (int)FilingTypes.PA)
                //                {
                //                    decimal MinimumCost = Tier1CostFee * TotalSquarFeet;
                //                    if ((MinimumCost) > (MinFilingFee))
                //                    {
                //                        return MinimumCost;
                //                    }
                //                    else
                //                    {
                //                        return MinFilingFee;
                //                    }
                //                }
                //                else if (FilingType == (int)FilingTypes.SF)
                //                {
                //                    return SubsequentNBFee;
                //                }
                //                break;
                //            }
                //        case (int)JobTypeNBorAlt.BigAlteration:
                //            {
                //                if (FilingType == (int)FilingTypes.IF || FilingType == (int)FilingTypes.PA)
                //                {
                //                    decimal MinimumCost = MinFilingFee + (EstimatedCost - MinEstFeeCostException) / 1000 * Tier1CostFee;
                //                    if ((MinimumCost) > (MinFilingFee))
                //                    {
                //                        return MinimumCost;
                //                    }
                //                    else
                //                    {
                //                        return MinFilingFee;
                //                    }
                //                }
                //                else if (FilingType == (int)FilingTypes.SF)
                //                {
                //                    return SubsequentNBFee;
                //                }
                //                break;
                //            }
                //        case (int)JobTypeNBorAlt.MajorAlteration:
                //        case (int)JobTypeNBorAlt.MinorAlteration:
                //            {
                //                if (FilingType == (int)FilingTypes.IF || FilingType == (int)FilingTypes.SF || FilingType == (int)FilingTypes.PA)
                //                {
                //                    decimal MinimumCost = MinFilingFee + (EstimatedCost - MinEstFeeCostException) / 1000 * Tier1CostFee;
                //                    if ((MinimumCost) > (MinFilingFee))
                //                    {
                //                        return MinimumCost;
                //                    }
                //                    else
                //                    {
                //                        return MinFilingFee;
                //                    }
                //                }
                //                break;
                //            }
                //    }
                //}
                #endregion

                return 0;
            }
            
        }

        public decimal TotalFees
        {
            get
            {
                return FilingFee + RecordManagementFees + PAAFees + InConjunctionFee + LegalizationFilingFees + NoGoodCheckFee+ BEMSSTFilingfee;
            }
        }
        public int BoilerEnergySource { get; set; }
    }

    public class BoilerPendingDetails
    {
        public bool BoilerDetailsPending { get; set; } //Boiler
        public bool FBDetailsPending { get; set; } //FB
        public bool FSDetailsPending { get; set; } //FS
        public bool BoilerScope { get; set; } //Boiler
        public bool FBScope { get; set; } //FB
        public bool FSScope { get; set; } //FS
        public bool Nodevicefound { get; set; } //
        public int Existingenrgysource { get; set; } //FS
    }

}
