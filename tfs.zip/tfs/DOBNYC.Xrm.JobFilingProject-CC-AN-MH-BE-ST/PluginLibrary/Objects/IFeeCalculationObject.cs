﻿namespace DOBNYC.XRM.JobFiling.PluginLibrary.Objects
{
    public interface IFeeCalculationObject
    {
        decimal amountDue { get; set; }
        decimal EstimatedCost { get; set; }
        decimal FilingFee { get; }
        int FilingType { get; set; }
        string FormulaName { get; set; }
        decimal InConjunctionFee { get; set; }
        bool IsConjunction { get; set; }
        bool IsFeeExempt { get; set; }
        int JobNBorAltType { get; set; }
        string LegalizationFilingFee { get; set; }
        decimal LegalizationFilingFees { get; set; }
        decimal MinEstFeeCostException { get; set; }
        decimal MinFilingFee { get; set; }
        string NewWorkFilingFee { get; set; }
        decimal NoGoodCheckFee { get; set; }
        string PAAFee { get; set; }
        decimal PAAFees { get; set; }
        string RecordManagementFee { get; set; }
        decimal RecordManagementFees { get; set; }
        decimal refund { get; set; }
        decimal SubsequentNBFee { get; set; }
        decimal Tier1CostFee { get; set; }
        decimal Tier2CostFee { get; set; }
        string TotalFee { get; set; }
        decimal TotalFees { get; }
        decimal TotalSquarFeet { get; set; }
        bool IsPATPA { get; set; }
        decimal PATPAFilingFee { get; set; }
        decimal TPALateFees { get; set; }
        
    }

    public class GCMHSTFeeCalObject : FeeCalculationObject
    {

    }
}