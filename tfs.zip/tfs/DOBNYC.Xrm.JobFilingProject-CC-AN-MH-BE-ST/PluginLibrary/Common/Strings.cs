﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace DOBNYC.XRM.JobFiling.Common
{
    public struct PluginHelperStrings
    {
        public static string PreImageName = "PreImage";
        public static string PostImageName = "PostImage";
        public static string PrePostImageName = "TargetImage";

        public const string CreateMessageName = "Create";
        public const string UpdateMessageName = "Update";
        public const string DeleteMessageName = "Delete";

    
    }

    public struct LicenseType
    {
        public const string PE = "PE";
        public const string RA = "RA";
        public const string LA = "LA";
        public const string PR = "PR";
        public const string GC = "GC";
        public const string P = "P";
        public const string O = "O";
        public const string A = "A";
        public const string F = "F";
        public const string M = "M";
        public const string S = "S";
    }
    public class JF_WorkonFloors
    {
        public List<WFObject> JFWFObjectList = new List<WFObject>();
    }

    public class WFObject
    {
        public string JFID { get; set; }
        public string Location { get; set; }
        public string From { get; set; }
        public string To { get; set; }
    }

    public class TPAEventDateObj
    {
        public List<EventDetail> EventList = new List<EventDetail>();
    }

    public class EventDetail
    {
        public string dateSchema { get; set; }
        public DateTime currentDate { get; set; }
        public DateTime previousDate { get; set; }
       
    }


    public struct MethodNames {
        public const string MergeEntityDataByMapping = "MergeEntityDataByMapping";
        public const string GenerateTaskFromConfigurationObject = "GenerateTaskFromConfigurationObject";
    
    
    }
    public struct PluginNames
    {

        public static string JobFilingAutoNumberGenerator = "JobFilingAutoNumberGenerator";
        public static string JobFilingTaskCreation = "JobFilingTaskCreation";
        public static string JobFilingTaskUpdate = "JobFilingTaskUpdate";
        public static string DocumentItemUploadPlugin = "DocumentItemUploadPlugin";
        public static string FeeCalculation = "JobFilingFeeCalculation";
        public static string JobFilingChangeSetPostUpdate = "JobFilingChangeSetPostUpdate";
        public static string PAAJobFilingChangeSetPostUpdate = "PAAJobFilingChangeSetPostUpdate";
        public static string AfterHourVaraiance = "PW5-AfterHourVariance";
    }
    public struct AutonumberPrefix
    {

        public static string JobPrefix = "JN";
        public static string FilingPrefix = "FN";

    }
    public static class MessageName
    {
        public const string AddItem = "AddItem";
        public const string AddMember = "AddMember";
        public const string AddMembers = "AddMembers";
        public const string AddMembersByFetchXml = "AddMembersByFetchXml";
        public const string Assign = "Assign";
        public const string Book = "Book";
        public const string Clone = "Clone";
        public const string Close = "Close";
        public const string CompoundCreate = "CompoundCreate";
        public const string Create = "Create";
        public const string Delete = "Delete";
        public const string DeliverIncoming = "DeliverIncoming";
        public const string DeliverPromote = "DeliverPromote";
        public const string ExecuteWorkflow = "ExecuteWorkflow";
        public const string GrantAccess = "GrantAccess";
        public const string Handle = "Handle";
        public const string Lose = "Lose";
        public const string Merge = "Merge";
        public const string ModifyAccess = "ModifyAccess";
        public const string RemoveItem = "RemoveItem";
        public const string RemoveMember = "RemoveMember";
        public const string RemoveMembers = "RemoveMembers";
        public const string RemoveMembersByFetchXml = "RemoveMembersByFetchXml";
        public const string Reschedule = "Reschedule";
        public const string Retrieve = "Retrieve";
        public const string RetrieveExchangeRate = "RetrieveExchangeRate";
        public const string RetrieveMultiple = "RetrieveMultiple";
        public const string RetrievePrincipalAccess = "RetrievePrincipalAccess";
        public const string RetrieveSharedPrincipalsAndAccess = "RetrieveSharedPrincipalsAndAccess";
        public const string RevokeAccess = "RevokeAccess";
        public const string Route = "Route";
        public const string Send = "Send";
        public const string SetState = "SetState";
        public const string SetStateDynamicEntity = "SetStateDynamicEntity";
        public const string Update = "Update";
        public const string Win = "Win";
    }

    public static class MessageProcessingStage
    {
        public const int AfterMainOperationOutsideTransaction = 40;
        public const int BeforeMainOperationOutsideTransaction = 20;
        
    }

    public static class ParameterName
    {
        public const string Assignee = "Assignee";
        public const string NoPGL1 = "No PGL1 requirement";
        public const string AsyncOperationId = "AsyncOperationId";
        public const string BusinessEntity = "BusinessEntity";
        public const string BusinessEntityCollection = "BusinessEntityCollection";
        public const string CampaignActivityId = "CampaignActivityId";
        public const string CampaignId = "CampaignId";
        public const string ColumnSet = "columnset";
        public const string Context = "context";
        public const string ContractId = "ContractId";
        public const string CreatedBy = "createdby";
        public const string EmailId = "emailid";
        public const string EndpointId = "EndpointId";
        public const string EntityId = "EntityId";
        public const string EntityMoniker = "EntityMoniker";
        public const string ExchangeRate = "ExchangeRate";
        public const string FaxId = "FaxId";
        public const string Id = "id";
        public const string ListId = "ListId";
        public const string OptionalParameters = "OptionalParameters";
        public const string OwnerId = "ownerid";
        public const string PostBusinessEntity = "PostBusinessEntity";
        public const string PostMasterBusinessEntity = "PostMasterBusinessEntity";
        public const string PreBusinessEntity = "PreBusinessEntity";
        public const string PreMasterBusinessEntity = "PreMasterBusinessEntity";
        public const string PreSubordinateBusinessEntity = "PreSubordinateBusinessEntity";
        public const string Query = "Query";
        public const string ReturnDynamicEntities = "ReturnDynamicEntities";
        public const string RouteType = "RouteType";
        public const string Settings = "Settings";
        public const string State = "State";
        public const string Status = "Status";
        public const string SubordinateId = "subordinateid";
        public const string Target = "Target";
        public const string TeamId = "TeamId";
        public const string TemplateId = "TemplateId";
        public const string TriggerAttribute = "TriggerAttribute";
        public const string UpdateContent = "UpdateContent";
        public const string ValidationResult = "ValidationResult";
        public const string Value = "value";
        public const string WorkflowId = "WorkflowId";
        public const string RegardingObjectId = "RegardingObjectId";
        public const string DEVconnString = "Data Source = msdwvd-dobcrm03.buildings.nycnet; Initial Catalog = DOBCRMDEV_MSCRM; Integrated Security = True";
        public const string TESTconnString = "Data Source = STESMSAP05-2MT.buildings.nycnet; Initial Catalog = DOBCRMTEST_MSCRM; Integrated Security = True";
        public const string STGconnString = "Data Source=STGCRMSQL1-2MT;Initial Catalog = DOBCRMSTG_MSCRM; Integrated Security = True";
        public const string PRODconnString = "Data Source=SPRDCRMSQL1-2MT;Initial Catalog=DOBCRM_MSCRM;Integrated Security=True";
        public const string AutoiNumberSpName = "dobnyc_autonumberentity_retrieve";
        public const string DevOrganisationName = "DOBCRMDEV";
        public const string TestOrganisationName = "DOBCRMTEST";
        public const string StgOrganisationName = "DOBCRMSTG";
        public const string ProdOrganisationName = "DOBCRM";

    }


    public sealed class TeamEntityAttributeNames
    {
        public static string EntityLogicalName = "team";
        public static string NameFieldName = "name";
        public static string TeamIdByFieldName = "teamid";
    }
    public sealed class EntityName
    {
        public static string JobFilingChangeSet = "dobnyc_jobfilingchangeset";
    }

    public sealed class BPF_JobFiling
    {
        public static string FAB4_ProcessId = "cbd48075-b1f7-483a-94d5-fa5c03e48b5c";
        public static string FAB4_StageId = "7a2c0009-7b91-4f39-bab5-773779fb04df";
        public static string PLSPSD_ProcessId = "9d87aba2-9f72-474c-a9e9-9e212733bd20";
        public static string PLSPSD_StageId = "6fb4fd79-6a52-4589-9626-3d77744a49c5";
        public static string ANCC_ProcessId = "43086b33-1474-4a89-a4b0-f477a2fb7f23";
        public static string ANCC_StageId = "afdd8cbe-9be1-44ba-9c75-11cf7bade591";
        public static string GCMHST_ProcessId = "ced52b5d-13b9-44f4-83a4-90144e738601";
        public static string GCMHST_StageId = "3034ca50-8612-4080-b1aa-e760f412793e";
        public static string PAT_PA_ProcessId = "6cc3fa23-49d9-4b67-85e2-15f9044775ae";
        public static string PAT_PA_StageId = "d31676a7-528e-4dd8-b006-76ba70f9a35b";

        public static string BEMSST_ProcessIdV2 = "4d5258d7-3625-4c1d-acc5-94dce7abe134";
        public static string BEMSST_StageIdV2 = "3a737869-c9c1-445b-b989-350d89403bc8";
        public static string ANCC_ProcessIdV2 = "fd62e461-425b-4dc2-a131-a32c3b19f767";
        public static string ANCC_StageIdV2 = "74b92221-97d3-4519-85a8-386f2f8edc37";
        public static string FAB4_ProcessIdV2 = "084eaeea-dced-413b-bb5c-e60ad77fac8a";
        public static string FAB4_StageIdV2 = "42585572-e580-4f79-92fb-00305434f9a4";
        public static string PLSPSD_ProcessIdV2 = "c4160f86-1807-4c14-8ead-832a89b0517f";
        public static string PLSPSD_StageIdV2 = "09825209-96e8-4029-bef6-59728dce0ff9";
        
        public static string PAT_PA_ProcessIdV2 = "6cc3fa23-49d9-4b67-85e2-15f9044775ae";
        public static string PAT_PA_StageIdV2 = "d31676a7-528e-4dd8-b006-76ba70f9a35b";
        public static string BE_StageIdV2 = "90ea63d5-c994-4dfd-9ba5-b7044513a580";
        public static string BE_ProcessV2 = "39337816-933a-4f98-858a-2112b05a92ba";
    }

    public sealed class HTMLAttributes
    {
        public const string PRM_HouseNumber = "PRM_HouseNumber";
        public const string PRM_StreetName = "PRM_StreetName";
        public const string PRM_JobNumber = "PRM_JobNumber";
        public const string PRM_BoroughNYC = "PRM_BoroughNYC";
        public const string PRM_Block = "PRM_Block";
        public const string PRM_Lot = "PRM_Lot";
        public const string PRM_Bin = "PRM_Bin";
        public const string PRM_Owner = "PRM_Owner";
        public const string PRM_Signoff_Date = "PRM_Signoff_Date";
        public const string PRM_Modified_On = "PRM_Modified_On";
        public const string PRM_LOCHeaderSrc = "PRM_LOCHeaderSrc";
        public const string PRM_SignatureSrc = "PRM_SignatureSrc";
        public const string PRM_Applicant = "PRM_Applicant";
        public const string PRM_ApplicantAddress = "PRM_AppAddress";
        public const string PRM_ApplicantCity = "PRM_AppCity";
        public const string PRM_ApplicantState = "PRM_AppState";
        public const string PRM_ApplicantZip = "PRM_AppZip";

    }

    public sealed class PermitEmail_HTMLAttributes
    {
        public const string PRM_PermitNumber = "PRM_PermitNumber";
        public const string PRM_JobNumber = "PRM_JobNumber";
        public const string PRM_FilingNumber = "PRM_FilingNumber";
        public const string PRM_Address = "PRM_Address";
        public const string PRM_EmailBody = "PRM_EmailBody";
        
    }

    public sealed class EmailReferences
    {
        public const string A24 = "A24";
        public const string A101 = "A101";
        public const string A103 = "A103";
        public const string A102 = "A102";
        
    }

    public sealed class TRInspectionType
    {
        public const string Final = "Final";
    }



    public sealed class ColoumnName
    {
        public string[] DocumentList_Coloumns = new string[] { DocumentListEntityAttributeName.DocumentName,
        DocumentListEntityAttributeName.RequestNumber,
        DocumentListEntityAttributeName.RequiredItemNumber,
        DocumentListEntityAttributeName.DocumentListtoJobfiling,
        DocumentListEntityAttributeName.GotoWorkPermit,
        DocumentListEntityAttributeName.GotoAHV,
        DocumentListEntityAttributeName.GotoAHVFeeExempt,
        DocumentListEntityAttributeName.GotoEN2,
        DocumentListEntityAttributeName.GotoSpecialInspection,
        DocumentListEntityAttributeName.GotoProgressInspection,
        DocumentListEntityAttributeName.Documentfor,
        DocumentListEntityAttributeName.CreatedDueto,
        DocumentListEntityAttributeName.DocumentStatus,
        DocumentListEntityAttributeName.PlanExaminerDocumentsid,
        DocumentListEntityAttributeName.ChiefPlanExaminerDocumentsid,
        DocumentListEntityAttributeName.QADocumentsid,
        DocumentListEntityAttributeName.PriortoStatus,
        DocumentListEntityAttributeName.PriortoStage,
        DocumentListEntityAttributeName.DocumentCategory,
        DocumentListEntityAttributeName.GotoWithdrawalRequest,
        DocumentListEntityAttributeName.GotoSupersedingRequest,
        DocumentListEntityAttributeName.DocumentURL,
        DocumentListEntityAttributeName.ParentDocumentList,
        DocumentListEntityAttributeName.ManuallySelected,
        DocumentListEntityAttributeName.UploadedDate,
        DocumentListEntityAttributeName.DocumentSource,
        DocumentListEntityAttributeName.AllowWaiver,
        DocumentListEntityAttributeName.AllowDeferral,
        DocumentListEntityAttributeName.DocumentListId,
        DocumentListEntityAttributeName.DocumentClass,
        DocumentListEntityAttributeName.IsSubmitted,
        DocumentListEntityAttributeName.WaiverRequested,
        DocumentListEntityAttributeName.DeferralRequested,
        DocumentListEntityAttributeName.WaiverRejectCounter,
        DocumentListEntityAttributeName.DeferralRejectCounter,
        DocumentListEntityAttributeName.Comments,
        DocumentListEntityAttributeName.AnyWaiverRequest,
        DocumentListEntityAttributeName.AnyDeferralRequest,
        DocumentListEntityAttributeName.OverrideWaiverSwitch,
        DocumentListEntityAttributeName.OverrideWaiverComments,
        };

    }

    public sealed class TeamNames
    {
        public const string TeamChiefPlanExaminer = "Chief Plan Examiner / ACPE Team";
        public const string TeamBoroughCommissioner = "Borough Commissioner";
        public const string TeamOpsAdmin = "Operations Admin Team";
        public const string TeamProfCertQAAdmin = "Prof-cert QA team";
        public const string TeamQASupervisor = "QA Supervisor Team";

        public const string TeamQAAdmin = "QA Team";        
        public const string TeamProfCertQASupervisor = "Prof-cert QA supervisor Team";

        //MultiStake teams
        public const string ProfCertPAA_QASupervisorTeam = "Prof-Cert PAA - QA Supervisor Team";
        public const string ProfCertWithPW2_QASupervisorTeam = "Permits - QA Supervisor Team";
        public const string ProfCertWithoutPW2_QASupervisorTeam = "Prof-Cert Without PW2 - QA Supervisor Team";

        public const string ProfCertPAA_QAAdminTeam = "Prof-Cert PAA - QA Team";
        public const string ProfCertWithPW2_QAAdminTeam = "Permits - QA Administrators";
        public const string ProfCertWithoutPW2_QAAdminTeam = "Prof-Cert Without PW2 - QA Team";
        public const string QATeam_AHV = "QA Team - AHV";
        public const string QATeam_LOCTechnicalReview = "LOC Technical Review Team";
        public const string QATeam_LOC = "QA Team - LOC";
        public const string TeamQASupervisor_AHV = "QA Supervisor Team - AHV";
        public const string TeamQASupervisor_LOC = "QA Supervisor Team - LOC";



    }

    public struct WorkTypes
    {
        public const string PL = "PL";
        public const string SP = "SP";
        public const string SD = "SD";
        public const string FN = "FN";
        public const string SH = "SH";
        public const string SF = "SF";
        public const string SG = "SG";
        public const string AN = "AN";
        public const string CC = "CC";
        public const string BE = "BE";
        public const string MS = "MS";
        public const string ST = "ST";
        public const string PA = "PA";
        public const string TPA = "TPA";
        public const string GC = "GC";
        public const string L2 = "L2";
    }

    public sealed class DocumentTypeNames
    {
        public const string ConcreteTestingExceptionReport = "CONCRETE TESTING EXCEPTION REPORT";
        public const string DEPVarianceV5Letter = "DEP VARIANCE (V5) LETTER";
        public const string DEPACP20ACP21 = "DEP ACP-20/ACP-21: ASBESTOS PROJECT CONDITIONAL COMPLETION FORM/ASBESTOS PROJECT COMPLETION FORM";
        public const string ChimneyAttestationDocument = "Chimney Attestation Document";
        public const string DEPACP5Asbestos = "DEP ACP-5: Asbestos Assessment Report";
        public const string DPL1SealSignature = "DPL-1: Design Professional Seal & Signature";
    }

    public sealed class CommonStringConstants
    {
        public const string ChimneyAttestationDocument = "BECAD";
        public const string PlansSketchDocumentCategory = "PLANS";
    }
}
