﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DOBNYC.XRM.JobFiling.Common
{
    public sealed class PluginErrorCodes
    {
        
    }

    public class PluginBusinessErrorMessages
    {        
        public const string CouldNotGenerateApplicationNumber = "Could not generate Application Number for JobFiling.";
      
    }

    public class PluginSystemExceptionMessages
    {

    }
    public class PluginMessages
    {
        public const string WebServiceCallParameterInfo = "Web service call parameter info : ";
        public const string WebServiceCouldNotBeAccessed = "Web service could not be accessed.";
        public const string ThisIsIOrganizationService = "This web service is a IOrganizationService.";
        public const string CreateWebServiceCallParametersError = "An error occurred while creating web service call parameters.";
  

        
    }
}
