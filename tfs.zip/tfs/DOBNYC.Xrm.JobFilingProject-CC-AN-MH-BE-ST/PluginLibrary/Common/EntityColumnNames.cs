using System;
using System.Collections.Generic;
using System.Text;

namespace DOBNYC.XRM.JobFiling.Common
{

    public sealed class DOBAddress
    {
        public const string EntityLogicalName = "dobnyc_dobaddress";
        public const string HouseNumber = "dobnyc_addr_housenumber";
        public const string StretName = "dobnyc_addr_streetname";
        public const string Borough = "dobnyc_addr_borough";
        public const string SFLookup = "dobnyc_addr_scaffoldscopeofwork";
        public const string SWSLookup = "dobnyc_f4_addr_sidewalkshedscopeofwork";

    }
    public sealed class PlaceofAssemblySpaceInformation
    {
        public const string EntityLogicalName = "dobnyc_placeofassemblyspaceinformation";
        public const string isTheJobnoprebis = "dobnyc_pas_isthejobnoprebis";
        public const string nba1JobnoEstablishingpa = "dobnyc_pas_nba1jobnoestablishingpa";
        public const string nameOfPAestablishment = "dobnyc_pas_nameofpaestablishment";
        public const string irregularFloorNumbering = "dobnyc_pas_irregularfloornumbering";
        public const string priorPAnoIfApplicable = "dobnyc_pas_priorpanoifapplicable";
        public const string jobFilingID = "dobnyc_jobfilingid";
        public const string partyToRenewThePACOifnotowner = "dobnyc_pas_partytorenewthepacoifnotowner";
        public const string ifPrebisProvideBin = "dobnyc_pas_ifprebisprovidebin";
        public const string partyToRenewPACO = "dobnyc_pas_partytorenewpaco";
        public const string Name = "dobnyc_name";
        public const string alternativePlanCounter = "dobnyc_pas_alternativeplancounter";
        public const string ID = "dobnyc_placeofassemblyspaceinformationid";
        public const string isSubmit = "dobnyc_pas_issubmit";
        public const string PACOreportStatus = "dobnyc_pas_pacorequeststatus";
        public const string IntendToupdatePrimaryPlans = "dobnyc_pas_doyouintendtoupdatetheprimaryplans";
        public const string Prebisprovidebin = "dobnyc_pas_ifprebisprovidebin";
        public const string fdnyopenflamepermitrequired = "dobnyc_pas_fdnyopenflamepermitrequired";
        public const string typeofopenflameused = "dobnyc_pas_typeofopenflameused";
        public const string otherTypeofFlameUsed = "dobnyc_pas_otherdescription";
        public const string FilingDate = "dobnyc_pas_filingdate";
        public const string RequestedDate = "dobnyc_pas_requesteddate";
        public const string IntendtochangeOwnerLessee = "dobnyc_intendtochangeownerlesseeestablishment";
    }
    public sealed class PlaceofAssemblyPlans
    {
        public const string EntityLogicalName = "dobnyc_placeofassemblyplans";
        public const string placeofassemblyspaceinformationLookup = "dobnyc_pap_placeofassemblyspaceinformation";
        public const string Name = "dobnyc_name";
        public const string jobfilingLookup = "dobnyc_pap_gotojobfiling";
        public const string ID = "dobnyc_placeofassemblyplansid";
    }

    public sealed class TempororayPlaceOfAssembly
    {
        public const string EntityLogicalName = "dobnyc_tpa_temporaryplaceofassembly";
        public const string Name = "dobnyc_name";
        public const string jobfilingLookup = "dobnyc_gotojobfiling";
        public const string EventStartdate = "dobnyc_tpa_eventstartdate";
        public const string EventEnddate = "dobnyc_tpa_eventenddate";
        public const string ID = "dobnyc_tpa_temporaryplaceofassemblyid";
        public const string EventDatesChangedAfterFiling = "dobnyc_tpa_eventdateschangedafterfiling";
        public const string RequestPeriodDatesChangedAfterFiling = "dobnyc_tpa_rpdateschangedafterfiling";

    }

    public sealed class TPAEventDates
    {
        public const string EntityLogicalName = "dobnyc_tpaeventdates";
        public const string Name = "dobnyc_name";
        public const string EventEndDate = "dobnyc_tpad_eventenddate";
        public const string EventStartdate = "dobnyc_tpad_eventstartdate";
        public const string TPALookup = "dobnyc_tpad_tpalookup";
        public const string ID = "dobnyc_tpaeventdatesid";

    }
    public sealed class JobFilingEntityAttributeName
    {
        public const string COCSignedOffDate = "dobnyc_cocsignedoffdate";
        public const string zoningCharactersticsLookup = "dobnyc_zoningcharacterisitics";
        public const string NoTR8InspectionCheckbox = "dobnyc_st_notr8inspectionsarerequired";
        public const string RequiredtomeetNewBuilding = "dobnyc_gc_altreqfornb";

        public const string STScopeofworkLookup = "dobnyc_stscopeofwork";
        public const string ScopeofworkQuestionnaireLookup = "dobnyc_sowquestionnaire";
        public const string workTypesTextbox = "dobnyc_ms_dashboardworktypes";
        public const string BEScopeIncludesBL = "dobnyc_be_boilerscopeincludes";
        public const string ANCheckBox = "dobnyc_an_antenna";
        public const string ParentTeam = "dobnyc_ms_assignedcpeacpeteam";
        public const string CCCheckBox = "dobnyc_cc_curbcut";
        public const string NoGoodCheckphGUID = "dobnyc_nogoodcheckphguid";
        public const string IsPAAinProgress = "dobnyc_ispaainprogress";
        public const string CreatePAA = "dobnyc_createpaa";
        public const string BIN = "dobnyc_bin";
        public const string NoGoodCheckFlag = "dobnyc_nogoodcheck";
        public const string NoGoodCheckCount = "dobnyc_nogoodcheckcount";
        public const string NoGoodCheckFee = "dobnyc_nogoodcheckfeefine";
        public const string InvoiceNumber = "dobnyc_invoicenumber";
        public const string IsConjunctionJob = "dobnyc_isconjunctionjob";
        public const string IsJobSubmitted = "dobnyc_isjobsubmitted";
        public const string IsCorrectionCompleted = "dobnyc_iscorrectioncompleted";
        public const string OwnerLeaseHolder = "dobnyc_ownerleaseholder"; //Look up
        public const string SignoffDate = "dobnyc_signoffdate"; //datetime
        public const string Block = "dobnyc_block";
        public const string JobStatus = "dobnyc_jobfiling_jobstatus"; // new optionset for Job Status
        public const string Lot = "dobnyc_lot";
        public const string CPEAssignedDate = "dobnyc_cpeassigneddate";
        public const string ProfCertQASupervisorAssignedDate = "dobnyc_profcertqasupervisorassigneddate";
        public const string ResubmitDate = "dobnyc_resubmitdate";
        public const string RequestNumber = "dobnyc_supersedingdprequestno";
        public const string Zip = "dobnyc_zip";
        public const string CBNo = "dobnyc_cbno";
        public const string CreateWorkTypes = "dobnyc_createworktypes";
        public const string Street = "dobnyc_streetname";
        public const string EntityAttributeName = "dobnyc_name";
        public const string EstimatedCostFinal = "dobnyc_an_estimatednewworkfinalcost";
        public const string HouseNumber = "dobnyc_housenumber";
        public const string WithdrawalCounter = "dobnyc_withdrawalcounter";
        public const string SupersedingCounter = "dobnyc_supersedingcounter";
        public const string FilingStatus = "dobnyc_currentfilingstatus";
        public const string FilingType = "dobnyc_filingstatustype";
        public const string EntityLogicalName = "dobnyc_jobfiling";
        public const string JobNumberAttributeName = "dobnyc_projectnumber";
        public const string FilingNumberAttributeName = "dobnyc_filingnumber";
        public const string ProfessionalCertificate = "dobnyc_professionalcertificate"; //boolean
        public const string RevertedtoDPfrom = "dobnyc_revertedtodpfrom";
        public const string IsPAAbyModifyingPW1Section3or12 = "dobnyc_ispaabymodsec3or12";
        public const string ParentJobFilingAttributeName = "dobnyc_parentjobfiling";
        public const string FilingTypeAttributeName = "dobnyc_filingstatustype";   // New Filing, Subsequest, PAA
        public const string BoroughAttributeName = "dobnyc_boroughnyc";
        public const string ObjectionRelationshipNameOnJobFiling = "dobnyc_dobnyc_jobfiling_dobnyc_objections";
        public const string DocumentListRelationshipNameOnJobFiling = "dobnyc_dobnyc_jobfiling_dobnyc_documentlist";
        public const string EstimatedJobCost = "dobnyc_estimatedjobcost";
        public const string EstimatedJobCostLegal = "dobnyc_estimatelegalizationjobcost";
        public const string BuildingType = "dobnyc_buildingtype";
        public const string TotalJobCost = "dobnyc_totaljobcost";
        public const string FilingDate = "dobnyc_jf_initialfilingdate";
        public const string InConjunctionFee = "dobnyc_inconjunctionfee";
        //public const string DPcheckTR8 = "dobnyc_dpchecktr8";
        public const string FilingFees = "dobnyc_filingfees";
        //public const string FeeReceiptNo = "dobnyc_feereceiptno";
        public const string IsCorrectionInitiated = "dobnyc_iscorrectioninitiated";
        public const string JobType = "dobnyc_jobfiling";
        public const string LatestPAAGuid = "dobnyc_latestpaaguid";
        public const string CCQuestionnaire = "dobnyc_cc_curbcutquestionnaire";
        public const string FeeType = "dobnyc_feetype";
        public const string LittleEorRDSite = "dobnyc_littleeorrdsite"; // Required item list
        public const string AsbestosAbatementCompliance = "dobnyc_asbestosabatementcompliance";
        public const string ErrorMessage = "dobnyc_errormessage";
        public const string PropertProfileId = "dobnyc_jobfiling_relatedpropertyprofile";
        public const string LandMark = "dobnyc_f4_landmark";
        public const string WorkPermitViolation = "dobnyc_workpermitviolation";
        public const string BinOnHold = "dobnyc_binonhold";
        public const string IsJobDescriptionChanged = "dobnyc_isjobdescriptionchanged";
        public const string WithdrawalStatus = "dobnyc_jobfiling_withdrawalstatus";
        public const string Withdrawalof = "dobnyc_jobfiling_withdrawalof";
        public const string SupersedingRequestStatus = "dobnyc_jobfiling_supersedingrequeststatus";
        public const string Status = "statecode";
        public const string StatusReason = "statuscode";
        public const string JobFilingId = "dobnyc_jobfilingid";
        public const string JobDescription = "dobnyc_jobdescription";
        public const string JobDescriptionLeg = "dobnyc_jobdescriptionlegalization";
        public const string ApplicantPerson = "dobnyc_applicantperson"; //lookup
        public const string ApplicantBusiness = "dobnyc_applicantbusinessname";
        //public const string ApplicantType = "dobnyc_chooseone"; // optionset
        //public const string DOBIssuedIDNumber = "dobnyc_dobissuedidnumber";
        //public const string LicenseNumber = "dobnyc_licensenumber";
        public const string WithdrawalRequester = "dobnyc_jobfiling_withdrawalrequester"; // contact lookup
        public const string PlumbingCheckBox = "dobnyc_pl_plumbing";// Work Type Check box
        public const string SprinklerCheckBox = "dobnyc_spsprinkler";// Work Type Check box
        public const string SDCheckBox = "dobnyc_sdstandpipe";// Work Type Check box

        public const string TotalConstructionFloorArea = "dobnyc_totalconstructionfloorarea"; // floating point
        public const string Reviewisrequestedunderwhichbuildingcode = "dobnyc_reviewisrequestedunderwhichbuildingcode"; //optionset
        public const string UnmappedCCOStreet = "dobnyc_unmappedccostreet"; //optionset
        public const string RequestingLegalizationofworkwherenowork = "dobnyc_requestinglegalizationofworkwherenowork";//optionset
        public const string Workincludespermanentremovalofstandpipe = "dobnyc_workincludespermanentremovalofstandpipe";//optionset
        public const string CompliacnewiththeNYCECC = "dobnyc_compliacnewiththenycecc"; // two optionset
        public const string CodeCompliancePath = "dobnyc_codecompliancepath";//  optionset
        public const string EnergyAnalysis = "dobnyc_energyanalysis";//  optionset
        public const string ExemptfromtheNYCECC = "dobnyc_exemptfromnycecc";// two optionset
        public const string ProfessionaljudgementallworkisExempt = "dobnyc_nyceccexemptifyeschooseone";//  optionset
        public const string ExistingFireAlarm = "dobnyc_existingfirealarm";// two optionset
        public const string ProposedFireAlarm = "dobnyc_proposedfirealarm";// two optionset
        public const string ExisitingFireSuppression = "dobnyc_exisitingfiresuppression";// two optionset
        public const string ProposedFireSuppression = "dobnyc_proposedfiresuppression";// two optionset
        public const string ExisitingSprinkler = "dobnyc_exisitingsprinkler";// two optionset
        public const string ProposedSprinkler = "dobnyc_proposedsprinkler";// two optionset
        public const string Mixedusebuilding = "dobnyc_mixedusebuilding";// optionset
        public const string ExisitingBuildingStories = "dobnyc_exisitingbuildingstories";// Whole Number
        public const string ProposeeBuildingStories = "dobnyc_proposeebuildingstoriesft";// Whole Number
        public const string ExistingBuildingHeight = "dobnyc_existingbuildingheight";// Whole Number
        public const string ProposedBuildingHeight = "dobnyc_proposedbuildingheight";// Whole Number
        public const string ExistingDwellingUnits = "dobnyc_existingdwellingunits";// Whole Number
        public const string ProposedDwellingUnits = "dobnyc_proposeddwellingunits";// Whole Number
        public const string EstimatedJobCosthidden = "dobnyc_ejcosthidden";// Whole Number
        public const string PaymentHistoryGUID = "dobnyc_phguid";//string
        public const string TransactionHistoryGUID = "dobnyc_thguid";//string
        public const string SupersedingRequesterId = "dobnyc_jobfiling_supersedingrequester"; //lookup
        public const string IsPlanApproved = "dobnyc_isplanapproved"; // boolean twooptionset
        public const string IsAfterPermitIssued = "dobnyc_jobfiling_isafterpermitissued"; // boolean twooptionset
        public const string SupersedingWorkpermit = "dobnyc_superseding_workpermit"; // lookup
        public const string CreateaWithdrawalRequest = "dobnyc_createawithdrawalrequest";
        public const string IsChangeLocationRequest = "dobnyc_ischangelocationrequest";
        public const string CreateaSupersedingRequest = "dobnyc_jobfiling_createasupersedingrequest";
        public const string IsWithdrawalRequestMade = "dobnyc_iswithdrawalrequestmade";
        public const string RecordManagementFee = "dobnyc_recordmanagementfee";
        public const string NewWorkFilingFee = "dobnyc_newworkfilingfee";
        public const string LegalizationFilingFee = "dobnyc_legalizationfilingfee";
        public const string PAAFee = "dobnyc_paafee";
        public const string PaidPAAFee = "dobnyc_paidpaafee";
        public const string AmountDue = "dobnyc_amountdue";
        public const string AmountPaid = "dobnyc_amountpaid";
        public const string Refund = "dobnyc_adjustmenttemporary";
        public const string AdjustmentFinal = "dobnyc_refund";
        public const string PlanApprovedDate = "dobnyc_planapproveddate";
        public const string FeeExemptionRequestNYCHAHHCNYCAgencyorOwnedOperated = "dobnyc_nychahhcnycagencyorownedoperated";
       // public const string AlternativeMaterialsthatrequire = "dobnyc_st_alternativematerialsrequiredanotcr";

        /////////////////////////////////////////////////////////////// Added all the attributes from PA/TPA

        public const string PACheckBox = "dobnyc_pa_paworktype";
        public const string TPACheckBox = "dobnyc_tpa_tpaworktype";
        public const string TemporaryPlaceOfAssemblyLookUp = "dobnyc_tpa_temporaryplaceofassembly";
        public const string PlaceOfAssemblyLookUp = "dobnyc_pa_placeofassemblyspaceinformation";
        public const string PAFilingReviewType = "dobnyc_pa_filingreviewtype";
        public const string LatestPAApprovedDate = "dobnyc_pa_latestpaapproveddate";
        public const string TPALateFees = "dobnyc_tpa_latefees";
        public const string IsPAAuditInitiated = "dobnyc_pa_ispaaudit"; //Flag to initiate the Place of assembly


        ////////////////////////////////////////////////////////////////// Added all the attributes from Integration


        public const string InConjunctionFlag = "dobnyc_isconjunctionjob";
        public const string BisRelatedJobNumber = "dobnyc_bisrelatedjobnumber";
        public const string AlternateBisRelatedJobNumber = "dobnyc_st_alternatebisrelatedjobnumbers";
        //public const string DpCheckCAF = "dobnyc_dpcheckcaf"; // boolean
        //public const string DpStatementCAP = "dobnyc_designapplicantstatementcaf";

        public const string NonProfitFlag = "dobnyc_isthedeedholderanonprofitorganization";
        public const string JobFilingNumAttribute = "dobnyc_name";
        public const string HouseNumAttribute = "dobnyc_housenumber";
        public const string StreetNameAttribute = "dobnyc_streetname";
        //public const string ApplicantTypeAttribute = "dobnyc_chooseone";
        public const string PlumbingWorkTypeAttributeName = "dobnyc_pl_plumbing";
        public const string SprinklerWorkTypeAttributeName = "dobnyc_spsprinkler";
        public const string BuildingTypeAttribute = "dobnyc_buildingtype";
        public const string ReviewRequestedUnderBuildingCode = "dobnyc_reviewisrequestedunderwhichbuildingcode";
        public const string FilingRepresentativeAttributeName = "dobnyc_filingrepresentative";
        public const string DesignApplicantAttributeName = "dobnyc_applicantperson";
        //public const string ProgressInspectorAttributeName = "dobnyc_progressinspector";
        public const string ProgressInspectionRelationship = "dobnyc_dobnyc_jobfiling_dobnyc_progressinspectio";
        public const string SpecialInspectionRelationship = "dobnyc_dobnyc_jobfiling_dobnyc_specialinspection";

        public const string JobFiling = "dobnyc_jobfiling";
        public const string EstimatedLegalizationJobCostAtributeName = "dobnyc_estimatelegalizationjobcost";
        public const string StateCode = "statuscode";

        //public const string JobFilingStatusCode = "statecode";
        public const string NewWorkFilingFeeAttributeName = "dobnyc_newworkfilingfee";
        public const string LegalizationFilingFeeAttributeName = "dobnyc_legalizationfilingfee";
        public const string RecordManagementFeeAttributeName = "dobnyc_recordmanagementfee";
        public const string PAAFeeAttributeName = "dobnyc_paafee";
        public const string NoGoodCheckFeeFineAttributeName = "dobnyc_nogoodcheckfeefine";

        public const string TotalFeeAttributeName = "dobnyc_filingfees";
        public const string AmountDueAttributeName = "dobnyc_amountdue";
        public const string AmountPaidAttributeName = "dobnyc_amountpaid";
        public const string RefundAttributeName = "dobnyc_refund";
        public const string CreateWithDrawalRequest = "dobnyc_createawithdrawalrequest";

        //public const string FilingType = "dobnyc_filingstatustype";

        public const string ApplicantNameTr1AttributeName = "dobnyc_applicantnametr1";
        public const string ApplicantNameEnergyAttributeName = "dobnyc_applicantnameenergy";
        //public const string ApplicantPersonAttributeName = "dobnyc_applicantperson";
        ////public const string ChooseOneAttributeName = "dobnyc_chooseone";
        public const string ApplicantContractOrTypeAttributeName = "dobnyc_applicantcontractortype";
        public const string AptCondonosAttributeName = "dobnyc_aptcondonos";
        //public const string AsBuiltInformation1AttributeName = "dobnyc_asbuiltinformation1";
        //public const string AsBuiltInformation2AttributeName = "dobnyc_asbuiltinformation2";
        //public const string AsbuiltInformationAAttributeName = "dobnyc_asbuiltinformationa";
        //public const string AsbuiltInformationBAttributeName = "dobnyc_asbuiltinformationb";
        public const string AsbestosAbatementComplianceAttributeName = "dobnyc_asbestosabatementcompliance";
        public const string PlanExaminerAttributeName = "dobnyc_planexaminer";
        public const string AssignedQAClerkAttributeName = "dobnyc_assignedqaclerk";
        public const string AssignedQASupervisorAttributeName = "dobnyc_assignedqasupervisor";
        public const string BackflowPreventerRPZAttributeName = "dobnyc_backflowpreventerrpz";
        public const string BinAttributeName = "dobnyc_bin";
        public const string BlockAttributeName = "dobnyc_block";
        public const string BoilerPilotForOilBurnerAttributeName = "dobnyc_boilerpilotforoilburner";
        public const string BoilersTypeAttributeName = "dobnyc_boilerstype";
        ////public const string BoroughAttributeName = "dobnyc_borough";
        ////public const string BoroughNYCAttributeName = "dobnyc_boroughnyc";
        ////public const string BuidingTypeAttributeName = "dobnyc_buidingtype";
        ////public const string BuidingTypeAttributeName = "dobnyc_buildingtype";
        public const string BusinessAddresStr1AttributeName = "dobnyc_businessaddresstr1";
        public const string BusinessAddresStr8AttributeName = "dobnyc_businessaddresstr8";
        public const string BusinessFaxTr1AttributeName = "dobnyc_businessfaxtr1";
        public const string BusinessFaxTr8AttributeName = "dobnyc_businessfaxtr8";
        public const string BusinessNameTr8AttributeName = "dobnyc_businessnametr8";
        public const string BusinessNameCSAttributeName = "dobnyc_businessnamecs";
        public const string BusinessNamesSManagerAttributeName = "dobnyc_businessnamessmanager";
        public const string BusinessNameTr1AttributeName = "dobnyc_businessnametr1";
        public const string BusinessTelephoneTr1AttributeName = "dobnyc_businesstelephonetr1";
        public const string BusinessTelephoneTr8AttributeName = "dobnyc_businesstelephonetr8";
        public const string CBNoAttributeName = "dobnyc_cbno";

        //Statements and signatures
        public const string MateriallyApplicableStatutory = "dobnyc_gc_materiallyapplicablestatutory";
        public const string AcceptedByDOBApplicableStatutoryCheckbox	="dobnyc_gc_acceptedbydobapplicablestatutory";
        public const string MateriallyEasementAgreement = "dobnyc_gc_materiallyeasementagreement";
        public const string AcceptedByDOBEasementAgreement = "dobnyc_gc_acceptedbydobeasementagreement";
        public const string POC3Checkbox = "dobnyc_poc3checkbox";
        public const string POC3OwnerCheckbox = "dobnyc_poc3ownercheckbox";
        public const string Doesthisbuildingqualify = "dobnyc_gc_doesthisbuildingqualify";
        public const string ApplicantofRecordsStatementandSignaturesECA = "dobnyc_designappstatementsandsignatureseca";
        public const string ApplicantofRecordsStatementandSignaturesECB = "dobnyc_designappstatementsandsignaturesec";
        public const string DpCheckPW1 = "dobnyc_dpcheckpw1";
        public const string OBIorLMPCheckbox = "dobnyc_obiorlmpcheckbox";
        public const string LicenseType = "dobnyc_obiorlmplicensetype";
        public const string RAorPECheckbox = "dobnyc_raorpecheckbox";
        public const string SSLicenseType = "dobnyc_raorpelicensetype";
        public const string FeeExemptionRequestNonProfitOwnedOperated = "dobnyc_feeexemptionrequestnonprofitownedop";
        public const string NYCHAHHCNYCAgencyorOwnedOperated = "dobnyc_nychahhcnycagencyorownedoperated";
        //public const string OwnersCertificationsRegardingOccupiedHousing = "dobnyc_ownerscertificationsregardingoccupied";
        public const string Propertyowner4thTwoOption = "dobnyc_propertyowner4thtwooption";
        public const string NotRequiredToNotifyNYCHomes = "dobnyc_notrequiredtonotifynychomes";
        public const string NotifiedtheNYCHomes = "dobnyc_notifiedthenychomes";
        public const string POCheckPW1 = "dobnyc_pocheckpw1";

        //Text
        public const string POC3Name = "dobnyc_poc3name";
        public const string ApplicantofRecord = "dobnyc_designapplicantnamestatementprint";
        public const string OBIorLMPName = "dobnyc_obiorlmpname";
        public const string RAorPEName = "dobnyc_raorpename";
        public const string OnwerStatmentNamePrintPW1 = "dobnyc_onwerstatmentnameprintpw1";
        //Date
        public const string POC3Date = "dobnyc_poc3date";
        public const string Date = "dobnyc_datedesignapplicantstatement";
        public const string OBIorLMPDate = "dobnyc_obiorlmpdate";
        public const string RAorPEDate = "dobnyc_raorpedate";
        public const string OnwerStatmentDatePrintPW1 = "dobnyc_onwerstatmentdateprintpw1";


        public const string CodeCompliancePathAttributeName = "dobnyc_codecompliancepath";
        public const string CommentsPWAttributeName = "dobnyc_commentspw";

        public const string CompliacneWithTheNYCECCAttributeName = "dobnyc_compliacnewiththenycecc";
        public const string ContructionSuperintendentAttributeName = "dobnyc_contructionsuperintendent";
        public const string CookingAttributeName = "dobnyc_cooking";
        public const string CreatedByAttributeName = "createdby";
        public const string CreatedOnbehalfByAttributeName = "createdonbehalfby";
        public const string CreatedOnAttributeName = "createdon";
        public const string TransactionCurrencyIdAttributeName = "transactioncurrencyid";
        //public const string CurrentAppointmentAttributeName = "dobnyc_currentappointment";
        public const string CurrentStageAttributeName = "dobnyc_currentstage";
        public const string CurrentTaskAttributeName = "dobnyc_currenttask";
        public const string DEPACPControlNoAttributeName = "dobnyc_depacpcontrolno";
        public const string InvestigatorCertificateNumber = "dobnyc_investigatorcertificatenumber";
        public const string Depvariancev5letter = "dobnyc_jf_depvariancev5letter";
        public const string Depacp20acp21asbestos = "dobnyc_jf_depacp20acp21asbestos";

        public const string DesignApplicantCostAffidavitAtrributeName = "dobnyc_designapplicant";
        public const string ChooseTheTypeofApplicantAttributeName = "dobnyc_choosethetypeofapplicant";
        public const string DesignApplicant3A4_Tr8AttributeName = "dobnyc_designapplicant3a4_tr8";
        //public const string DOBIssuedIDNoPW3AttributeName = "dobnyc_dobissuedidnopw3";
        //public const string DOBIssuedIdAttributeName = "dobnyc_dobissuedidnumber";
        public const string EmailAddressAttributeName = "emailaddress";
        public const string EnableRibbonCancelAttributeName = "dobnyc_enableribboncancel";
        public const string EnableRibbonPaymentAttributeName = "dobnyc_enableribbonpayment";
        public const string EnableRibbonSaveAttributeName = "dobnyc_enableribbonsave";
        public const string EnableRibbonSubmitAttributeName = "dobnyc_enableribbonsubmit";
        public const string EnergyAnalysisAttributeName = "dobnyc_energyanalysis";
        //public const string EquipmentAttributeName = "dobnyc_equipment";
        //public const string EquipmentandAlarms_SBAttributeName = "dobnyc_equipmentandalarms_sb";
        public const string EstimatedJobCostAttributeName = "dobnyc_estimatedjobcost";
        public const string EstimatedJobCost_BaseAttributeName = "dobnyc_estimatedjobcost_base";
        public const string ExchangeRateAttributeName = "exchangerate";
        public const string ExcludeConcreteWorkAttributeName = "dobnyc_excludeconcretework";
        public const string ExemptFromNYCECCAttributeName = "dobnyc_exemptfromnycecc";
        public const string ExisitingBuildingStoriesAttributeName = "dobnyc_exisitingbuildingstories";
        public const string ExisitingFireSuppressionAttributeName = "dobnyc_exisitingfiresuppression";
        public const string ExisitingSprinklerAttributeName = "dobnyc_exisitingsprinkler";
        public const string ExistingBuildingHeightAttributeName = "dobnyc_existingbuildingheight";
        public const string ExistingDwellingUnitsAttributeName = "dobnyc_existingdwellingunits";
        public const string ExistingFireAlarmAttributeName = "dobnyc_existingfirealarm";
        //public const string abc101 = "dobnyc_faxcs";
        //public const string FaxcsAttributeName = "dobnyc_faxcs"; //not in use-will be deleted
        //public const string FaxSSManagerAttributeName = "dobnyc_faxssmanager";//not in use-will be deleted
        //public const string FeeReceiptNoAttributeName = "dobnyc_feereceiptno"; //not in use
        public const string FeeSubmittedAttributeName = "dobnyc_feesubmitted";
        //public const string FeeTypeAttributeName = "dobnyc_feetype";
        public const string FilingFeesAttributeName = "dobnyc_filingfees";
        public const string FilingFees_BaseAttributeName = "dobnyc_filingfees_base"; ////not in use
        ////public const string FilingNumberAttributeName = "dobnyc_filingnumber"; //not in use
        //public const string FilingRepresentativeAttributeName = "dobnyc_filingrepresentative";
        public const string FilingRepresentativeName = "dobnyc_filingrepresentative";
        public const string CurrentFilingStatusAttributeName = "dobnyc_currentfilingstatus";
        ////public const string FilingstatusTypeAttributeName = "dobnyc_filingstatustype";
        //public const string FirePlaceAttributeName = "dobnyc_fireplace"; //not inn use
        //public const string FirstNameTR1AttributeName = "dobnyc_firstnametr1";not in use - to be deleted
        // public const string FirstNameTR8AttributeName = "dobnyc_firstnametr8";not in use - to be deleted
        //public const string FirstNameSSManagerAttributeName = "dobnyc_firstnamessmanager";not in use - to be deleted
        //public const string FirstNameCSAttributeName = "dobnyc_firstnamecs"; not in use - to be deleted
        //public const string FloorAttributeName = "dobnyc_floor"; // not in use - to be deleted
        //public const string GasPipingInvolvedAttributeName = "dobnyc_gaspipinginvolved"; //not in use
        //public const string HCP1HCP2AttributeName = "dobnyc_hcp1hcp2"; 
        //public const string HeatAttributeName = "dobnyc_heat"; //not in use
        public const string HouseStreetAttributeName = "dobnyc_housenostr1";
        //public const string HouseNoStr8AttributeName = "dobnyc_housenostr8"; //not in use
        ////public const string NameAttributeName = "dobnyc_name";
        //public const string HVACAttributeName = "dobnyc_hvac";
        //public const string ImportSequenceNumberAttributeName = "importsequencenumber";
        //public const string ExisitingDocumentNumberAttributeName = "dobnyc_exisitingdocumentnumber"; //not in use
        //public const string InitialFiling27pw3AttributeName = "dobnyc_initialfiling27pw3";
        public const string Jobfiling_IsafterPermitIssuedAttributeName = "dobnyc_jobfiling_isafterpermitissued";
        public const string IsChangeLocationRequestAttributeName = "dobnyc_ischangelocationrequest";
        public const string IsInspectionStageAttributeName = "dobnyc_isinspectionstage";
        //public const string IsJobApplicationCompleteAttributeName = "dobnyc_isjobapplicationcomplete";
        //public const string IsJobSubmittedAttributeName = "dobnyc_isjobsubmitted"; not is use--used in BP
        public const string IsMinorPlanChangesAttributeName = "dobnyc_isminorplanchanges";
        public const string IsNewWorktypeAddedAttributeName = "dobnyc_isnewworktypeadded";
        public const string IsPAAbyModSec3or12AttributeName = "dobnyc_ispaabymodsec3or12";
        public const string IsPlanApprovedAttributeName = "dobnyc_isplanapproved";
        public const string IsPlanExaminerStageAttributeName = "dobnyc_isplanexaminerstage";
        public const string IsplanRejectFirstTimeAttributeName = "dobnyc_isplanrejectfirsttime";
        public const string IsSignoffStageAttributeName = "dobnyc_issignoffstage";
        public const string IsWithdrawalRequestMadeAttributeName = "dobnyc_iswithdrawalrequestmade";
        public const string IsWorkPermitAvailableAttributeName = "dobnyc_isworkpermitavailable";
        //ublic const string IsWorkPermitNeededAttributeName = "dobnyc_isworkpermitneeded"; not in use
        public const string JobDescriptionAttributeName = "dobnyc_jobdescription";
        ////public const string JobFilingIdAttributeName = "dobnyc_jobfilingid"; already present
        ////public const string JobFilingAttributeName = "dobnyc_jobfiling"; //not prersent
        public const string ProjectNumberAttributeName = "dobnyc_projectnumber"; //job number in the form
        //public const string JobPAttributeName = "dobnyc_jobp"; //not in use -delete it
        //public const string LandmarkAttributeName = "dobnyc_landmark"; //not on the form
        //public const string LastNamecsAttributeName = "dobnyc_lastnamecs"; //not in use
        //public const string LastNameTr1AttributeName = "dobnyc_lastnametr1"; //not in use
        //public const string LastNameTr8AttributeName = "dobnyc_lastnametr8"; //not in use
        //public const string LastNameSSManagerAttributeName = "dobnyc_lastnamessmanager"; //not in use
        //public const string LiabilityInsuranceAttributeName = "dobnyc_liabilityinsurance"; //not in use
        //public const string abc156 = "dobnyc_licensenumbertr1";
        //public const string LicenseNumberTr1AttributeName = "dobnyc_licensenumbertr1";
        public const string LicenseNumberAttributeName = "dobnyc_licensenumber";
        //public const string LicenseNumberTr8AttributeName = "dobnyc_licensenumbertr8";
        //public const string LicenseNumberProgressInspectorAttributeName = "dobnyc_licensenumberprogressinspector";
        //public const string LicenseTypeProgressInspectorAttributeName = "dobnyc_licensetypeprogressinspector";
        //public const string LicenseTypeTr1AttributeName = "dobnyc_licensetypetr1";
        public const string LittleEOrRdSiteAttributeName = "dobnyc_littleeorrdsite";
        //public const string LocationsFloorAptListallthatapply_RisersAttributeName = "dobnyc_locationsflooraptlistallthatapply_risers";
        //public const string LocationsFloorAptListallthatapply_MetersAttributeName = "dobnyc_locationsflooraptlistallthatapply_meters"; 
        //public const string LoftBoardAttributeName = "dobnyc_loftboard";
        public const string LotAttributeName = "dobnyc_lot";
        public const string MakePaymentAttributeName = "dobnyc_makepayment";
        //public const string MtrsandSubmtrsAttributeName = "dobnyc_mtrsandsubmtrs";
        //public const string MetersTotalAttributeName = "dobnyc_meterstotal";
        // public const string MiddleInitialcsAttributeName = "dobnyc_middleinitialcs"; //delete it
        // public const string MiddleInitialSSManagerAttributeName = "dobnyc_middleinitialssmanager"; //delete it
        //public const string MiddleNameTr1AttributeName = "dobnyc_middlenametr1"; //delete it
        // public const string MiddleNametr8AttributeName = "dobnyc_middlenametr8"; //delete it
        public const string MixedUseBuildingAttributeName = "dobnyc_mixedusebuilding";
        //public const string abc179 = "modifiedby";
        //public const string ModifiedOnbehalfByAttributeName = "modifiedonbehalfby";
        public const string ModifiedOnAttributeName = "modifiedon";
        //public const string NameDesignApplicantStatementtr1AttributeName = "dobnyc_namedesignapplicantstatementtr1";
        public const string NameOnwerStatement4Inspectortr1AttributeName = "dobnyc_nameonwerstatement4inspectortr1";
        //public const string FillingStatusMainAttributeName = "dobnyc_fillingstatusmain"; //delete it
        //public const string NewSupersedingApplicant4aAttributeName = "dobnyc_newsupersedingapplicant4a"; //verify
        //public const string PermitTypeOtherAttributeName = "dobnyc_permittypeother"; //not on form
        //public const string OtherAttributeName = "dobnyc_other"; //not in use
        //public const string OtherChooseoneApplicationInformationAttributeName = "dobnyc_otherchooseoneapplicationinformation";  //not in use
        //public const string OtherTr1AttributeName = "dobnyc_othertr1";  //not in use
        //public const string OtherBuildingTypeAttributeName = "dobnyc_otherbuildingtype";  //not in use
        //public const string OtherGasUsageAttributeName = "dobnyc_othergasusage";   //not in use
        public const string OwnerIdAttributeName = "ownerid"; //hidden field
        public const string OwnerLeaseholderAttributeName = "dobnyc_ownerleaseholder";

        //public const string ProcessIdAttributeName = "processid";--------------------NOT VERIFIED
        public const string ProfessionalCertificateAttributeName = "dobnyc_professionalcertificate";
        public const string NYCeccExemptifyeSchooseOneAttributeName = "dobnyc_nyceccexemptifyeschooseone";
        public const string ProgressInspectionApplicant3bd56_tr8AttributeName = "dobnyc_progressinspectionapplicant3bd56_tr8";
        public const string ProgressInspectionsApplicantAttributeName = "dobnyc_progressinspectionsapplicant";
        //public const string ProgressInspectorAttributeName = "dobnyc_progressinspector";
        public const string ProposedBuildingHeightAttributeName = "dobnyc_proposedbuildingheight";
        public const string ProposedDWellingUnitsAttributeName = "dobnyc_proposeddwellingunits";
        public const string ProposedFireAlarmAttributeName = "dobnyc_proposedfirealarm";
        public const string ProposedFireSuppressionAttributeName = "dobnyc_proposedfiresuppression";
        public const string ProposedSprinklerAttributeName = "dobnyc_proposedsprinkler";
        public const string ProposeeBuildingStoriesftAttributeName = "dobnyc_proposeebuildingstoriesft";
        //public const string Ptaa_OptionsetAttributeName = "dobnyc_ptaa_optionset";
        public const string ReasonforFilingAttributeName = "dobnyc_reasonforfiling";
        //public const string OverriddenCreatedOnAttributeName = "overriddencreatedon"; /inbuilt field
        //public const string RegisterationNumberAttributeName = "dobnyc_registerationnumber";
        //public const string RegisterationNumberCSAttributeName = "dobnyc_registrationnumbercs";
        public const string RegistrationNumberFilingRepresentativeAttributeName = "dobnyc_registrationnumberfilingrepresentative";
        //public const string ReinstatementAttributeName = "dobnyc_reinstatement";
        //public const string ReplaceorRelocateAttributeName = "dobnyc_replaceorrelocate";
        public const string RequestingLegalizationOfWorkWhereNoWorkAttributeName = "dobnyc_requestinglegalizationofworkwherenowork";
        public const string RequirementsabestoscompAttributeName = "dobnyc_requirementsabestoscomp";
        public const string RevertedtoDPFromAttributeName = "dobnyc_revertedtodpfrom";
        ///public const string ReviewisRequestedUnderWhichBuildingCodeAttributeName = "dobnyc_reviewisrequestedunderwhichbuildingcode";

        ////public const string SPSprinklerAttributeName = "dobnyc_spsprinkler";
        public const string SpecialInspectionsApplicant3bd69AttributeName = "dobnyc_specialinspectionsapplicant3bd69";
        public const string TaskURLAttributeName = "dobnyc_taskurl";
        //public const string TelephoneSSManagerAttributeName = "dobnyc_telephonessmanager";
        //public const string TelephoneCSAttributeName = "dobnyc_telephonecs";
        //public const string TimezoneRuleVersionNumberAttributeName = "timezoneruleversionnumber"; //inbuilt field
        public const string TipAttributeName = "dobnyc_tip";
        //public const string TitleOnwerStatement4inspectortr1AttributeName = "dobnyc_titleonwerstatement4inspectortr1";
        //public const string ToObtainSignoffpw3AttributeName = "dobnyc_toobtainsignoffpw3";
        //public const string ToRemoveViolationssSprinklerAttributeName = "dobnyc_toremoveviolationsssprinkler";
        //public const string ToRemoveViolationssPlumbingAttributeName = "dobnyc_toremoveviolationssplumbing";
        public const string TotalConstructionFloorAreaAttributeName = "dobnyc_totalconstructionfloorarea";
        public const string TotalJobCostAttributeName = "dobnyc_totaljobcost";
        public const string TotalJobCost_BaseAttributeName = "dobnyc_totaljobcost_base";
        public const string TotalPlumbingCostAttributeName = "dobnyc_totalplumbingcost";
        public const string TotalPlumbingCost_BaseAttributeName = "dobnyc_totalplumbingcost_base";
        public const string TotalSprinklerCostAttributeName = "dobnyc_totalsprinklercost";
        public const string TotalSprinklerCost_BaseAttributeName = "dobnyc_totalsprinklercost_base";
       // public const string UnmappedCCOStreetAttributeName = "dobnyc_unmappedccostreet";
        ////public const string Jobfiling_WithdrawalofAttributeName = "dobnyc_jobfiling_withdrawalof";
        ////public const string Jobfiling_WithdrawalStatusAttributeName = "dobnyc_jobfiling_withdrawalstatus";
        //public const string Withdrawal_OptionsetAttributeName = "dobnyc_withdrawal_optionset";
        public const string WorkIncludesPermanentRemovalofStandpipeAttributeName = "dobnyc_workincludespermanentremovalofstandpipe";
        //public const string WorkonFloorStr1AttributeName = "dobnyc_workonfloorstr1";
        public const string WorkonFloorsAttributeName = "dobnyc_workonfloors";
        //public const string WorkonFloorStr8AttributeName = "dobnyc_workonfloorstr8";
        //public const string WorkTypesAttributeName = "dobnyc_worktypes"; /not in form

        public const string PlumbingWorkLegalization = "dobnyc_plplumbinglegalization";
        public const string SprinklerWorkLegalization = "dobnyc_spsprinklerlegalization";

        public const string CRMErrorMsg = "dobnyc_errormessage";
        //public const string abc297 = "dobnyc_applicantdescriptionworkpermit";
        //public const string abc298 = "dobnyc_licensetypetr8";
        //public const string abc299 = "dobnyc_noworkpermit";
        //public const string abc300 = "dobnyc_applicantresponsible";
        //public const string abc301 = "dobnyc_ziptr8";
        //public const string abc302 = "dobnyc_zipapplicantinfotr1";
        //public const string abc303 = "dobnyc_zipcs";
        //public const string abc304 = "dobnyc_zipssmanager";
        public const string IsFeeExemptAttributename = "dobnyc_isfeeexempt";
        public const string ZipAttributeName = "dobnyc_zip";
        public const string TotalConstructionAreaLegalizationAttributeName = "dobnyc_totalconstructionarealegalization";
        public const string PlanApprovedDateAttributeName = "dobnyc_planapproveddate";
        public const string JobStatusAttributeName = "dobnyc_jobfiling_jobstatus";
        public const string PreviousFilingStatusAttributeName = "dobnyc_previousfilingstatus";

        //leagal fields
        public const string DateDesignApplicantStatementAttributeName = "dobnyc_datedesignapplicantstatement";
        public const string DesignApplicantNameStatementPrintAttributeName = "dobnyc_designapplicantnamestatementprint";
        public const string FeeExemptionRequestNonProfitOwnedandOperatedAttributeName = "dobnyc_feeexemptionrequestnonprofitownedop";

        public const string OwnersCertificationsRegardingOccupiedHousing = "dobnyc_ownerscertificationsregardingoccupied";
        public const string Thesiteofthebuildingtobealteredordemolished4thcheckbox = "dobnyc_propertyowner4thtwooption";
        public const string AThesiteofthebuildingtobealteredordemolished = "dobnyc_notrequiredtonotifynychomes";
        public const string BNotifiedtheNYCHomes = "dobnyc_notifiedthenychomes";
        public const string ProvideDateNYSHCRNotified = "dobnyc_providedatenyshcrnotified";
        public const string DwellingUnits = "dobnyc_numberofdwellingunits";


        //tr1
        //public const string DateDesignApplicantStatementTr1AttributeName = "dobnyc_datedesignapplicantstatementtr1";
        //public const string DesignApplicantStatementNameTR1 = "dobnyc_designapplicantstatementnametr1";
        //public const string IcertifythattheSpecialInspectionandAttributeName = "dobnyc_icertifythatthespecialinspectionand";
        //public const string IhaveIdentifiedalltheSpecialInspectionsAttributeName = "dobnyc_ihaveidentifiedallthespecialinspections";
        public const string DateOnwerStatement4InspectorTr1AttributeName = "dobnyc_dateonwerstatement4inspectortr1";

        //CAf
        //public const string DateDesignApplicantStatementCAf = "dobnyc_datedesignapplicantstatementcaf";
        //public const string DateOwnerStatementCAf = "dobnyc_dateownerstatementcaf";
        //public const string OnwerNamestatementsCostaffidavit = "dobnyc_onwernamestatementscostaffidavit";
        //enerygy
        public const string DesignApplicantsStatementsandSignaturesECAAttributeName = "dobnyc_designappstatementsandsignatureseca";
        public const string DesignApplicantsStatementsandSignaturesECBAttributeName = "dobnyc_designappstatementsandsignaturesec";
        //public const string DesignApplicantStatementNameTR8 = "dobnyc_designapplicantstatementnametr8";
        //public const string DateDesignapplicantStatementECAttributeName = "dobnyc_datedesignapplicantstatementec";

        //ST Fields
        public const string ApplicableStatSection = "dobnyc_gc_applicablestatutorysection";
        public const string Easementaggrementname = "dobnyc_gc_easementaggrementname";
        public const string Modularconstnystate = "dobnyc_gc_modularconstnystate";
        public const string Modularconstnystatenyc = "dobnyc_gc_modularconstundernyc";
        public const string Buildinggreater = "dobnyc_st_buildinggreater";
        public const string Buildingsgrossfloorarea = "dobnyc_st_buildingsgrossfloorarea";
        public const string Areallaspectratiossixorless = "dobnyc_st_areallaspectratiossixorless";
        public const string Specialseismicenergy = "dobnyc_st_specialseismicenergy";
        public const string Doesthebuildingincludeany = "dobnyc_st_doesthebuildingincludeany";
        public const string Isthebuildingincludedinstructural = "dobnyc_st_isthebuildingincludedinstructural";
        public const string Buildinghavemorethan50000squarefeet = "dobnyc_st_buildinghavemorethan50000squarefeet";
        public const string Doanyelementsexcept = "dobnyc_st_doanyelementsexcept";
        public const string Structuralpeerreview = "dobnyc_st_structuralpeerreview";
        public const string Associatedbuildingsbulletinnumber = "dobnyc_st_associatedbuildingsbulletinnumber";
        public const string NYSPELicenseNumber = "dobnyc_st_enternyspelicensenumber";

        public const string AreallAspectratiossixorless = "dobnyc_st_areallaspectratiossixorless";
        public const string Structuredesignbase = "dobnyc_st_structuredesignbased";
        public const string BuildingsDesign = "dobnyc_st_buildingsdesign";
        public const string Sowrequirethestandpipeservice = "dobnyc_sd_sowrequirethestandpipeservice";
        public const string Sowinvolvemorethan5contiguousfloors = "dobnyc_sp_sowinvolvemorethan5contiguousfloors";
        public const string PLworkimpactthewatersupply = "dobnyc_pl_plworkimpactthewatersupply";

        //Owner26section
        public const string OwnerTypePW1Statement = "dobnyc_ownertypepw1statement";
        public const string Isthedeedholderanonprofitorganization = "dobnyc_isthedeedholderanonprofitorganization";
        public const string NameOwnerTypeStatementsPW1 = "dobnyc_nameownertypestatementspw1";
        public const string RelationshiptoOwner = "dobnyc_relationshiptoowner";
        public const string BusinessNameandAgency = "dobnyc_businessnameandagency";
        public const string StreetAddress = "dobnyc_streetaddress";
        public const string CityPW1statemnt = "dobnyc_citypw1statemnt";
        public const string StatePW1statemnt = "dobnyc_statepw1statemnt";
        public const string FaxPW1statemnt = "dobnyc_faxpw1statemnt";
        public const string ZipPW1statemnt = "dobnyc_zippw1statemnt";
        public const string TelephoneNumberPW1statemnt = "dobnyc_telephonenumberpw1statemnt";
        public const string EmailAddressPW1statemnt = "dobnyc_emailaddresspw1statemnt";
        public const string Date26PW1statemnt = "dobnyc_date26pw1statemnt";

        public const string NameCondoCoOpBoard = "dobnyc_namecondocoopboard";
        public const string StreetAddressCondoCoOpBoard = "dobnyc_streetaddresscondocoopboard";
        public const string TitleCondoCoOpBoard = "dobnyc_titlecondocoopboard";
        public const string TelephoneNumberCondoCoOpBoard = "dobnyc_telephonenumbercondocoopboard";
        public const string StateCondoCoOpBoard = "dobnyc_statecondocoopboard";
        public const string CityCondoCoOpBoard = "dobnyc_citycondocoopboard";
        public const string EmailAddressCondoCoOpBoard = "dobnyc_emailaddresscondocoopboard";
        public const string ZipCondoCoOpBoard = "dobnyc_zipcondocoopboard";
        //public const string FaxCondoCoOpBoard = "dobnyc_faxcondocoopboard";
        public const string DateCondoCoOpBoard = "dobnyc_datecondocoopboard";

        public const string LicenseLookupField = "dobnyc_licenseetype";

        #region standpipe
        public const string StandPipeWorkType = "dobnyc_sdstandpipe";
        //public const string StandPipeLegalizationWorkType = "dobnyc_sdstandpipelegalization";
        public const string CRFNRestrictiveDeclaration = "dobnyc_crfnsrestrictivedeclarationeasement";
        public const string IsFilingtoAddressViolations = "dobnyc_filingtoaddressviolation";
        public const string ListViolationsDOBECB = "dobnyc_listviolationssdoborecb";
        public const string ECBNumbers = "dobnyc_ecbnumbers";
        public const string ComplyingToLocalLaws = "dobnyc_complyingtolocallaws";
        public const string ListOfLawNumbers = "dobnyc_listeachlawnumber";
        public const string ExistingSeismicDesignCategroy = "dobnyc_existingseismicdesigncat";
        public const string ProposedSeismicDesignCategroy = "dobnyc_proposedseismicdesigncat";
        public const string OccupancyClassification = "dobnyc_occupancyclassification";
        public const string ConstructionClassification = "dobnyc_constructionclassification";
        public const string MultipleDwellingClassification = "dobnyc_multipledwellingclassification";

        public const string FireProtectionEquipmentExistingStandPipe = "dobnyc_existingstandpipe";
        public const string FireProtectionEquipmentProposedStandPipe = "dobnyc_proposedstandpipe";
        public const string SiteCharacteristicsTidalWastelands = "dobnyc_tidalwetlands";
        public const string SiteCharacteristicsCoastalErosionHazardArea = "dobnyc_coastalerosionhazardarea";
        public const string SiteCharacteristicsFireDistrict = "dobnyc_firedistrict";
        public const string SiteCharacteristicsFreshwaterWetlands = "dobnyc_freshwaterwetlands";
        public const string SiteCharacteristicsUrbanRenewal = "dobnyc_urbanrenewal";
        public const string SiteCharacteristicsFloodHazardArea = "dobnyc_floodhazardarea";
        public const string LegalAdultUse = "dobnyc_jf_legaladultuse";
        public const string FloodHzAreaIsSubstantialImprovement = "dobnyc_substantialimprovement";
        public const string IsFloodHzAreaSubstantiallyDamaged = "dobnyc_substantiallydamaged";
        public const string FloodHzAreaFloodShieldsProposedWork = "dobnyc_floodshieldspartofproposedwork";
        public const string TotalStandpipeCost = "dobnyc_totalstandpipecost";

        public const string Newstandpipeinstallation = "dobnyc_newstandpipeinstallation";
        public const string Repairtoexistingstandpipe = "dobnyc_repairtoexistingstandpipe";
        public const string Standpipetype = "dobnyc_standpipetype";
        public const string Standpipeclass = "dobnyc_standpipeclass";

        public const string CRFNNumber1 = "dobnyc_crfnnumber1"; //String
        public const string CRFNNumber2 = "dobnyc_crfnnumber2"; //String
        public const string CRFNNumber3 = "dobnyc_crfnnumber3"; //String
        public const string CRFNNumber4 = "dobnyc_crfnnumber4"; //String
        #endregion

        #region Antenna & Curb cut - PW1

        public const string AlternateJobInBISAssociation = "dobnyc_an_alternatejobinbisassociation"; //Two Options
        public const string AntennaWorkType = "dobnyc_an_antennaworktype"; //Option Set
        public const string BSACalendarNumbers = "dobnyc_an_bsacalendarnumbers"; //Two Options
        public const string CPCCalendarNumbers = "dobnyc_an_cpccalendarnumbers"; //Two Options
        public const string Yearforlocallaws = "dobnyc_yearforlocallaws";//string
        public const string CRFNZoningExhibit = "dobnyc_an_crfnzoningexhibit"; //Two Options
        public const string CurbCutWorkType = "dobnyc_cc_curbcutworktype"; //Option Set
        public const string Directive14 = "dobnyc_an_directive14"; //Two Options
        public const string Districts = "dobnyc_an_districts"; //String
        public const string isDistrictsUnkown = "dobnyc_gc_isdistrictunknown"; //Two Options
        public const string ExtendHigherThan6Feet = "dobnyc_an_extendhigherthan6feet"; //Two Options
        public const string HighRiseTeamTrackingNumber = "dobnyc_an_highriseteamtrackingno"; //String
        public const string IsAntennaOneMeterinDiameter = "dobnyc_an_isantennaonemeterindiameter"; //Two Options
        public const string IsStructuralWorkIncluded = "dobnyc_an_isstructuralworkincluded"; //Two Options
        public const string MapNumber = "dobnyc_an_mapnumber"; //String
        public const string OccupyMoreThan5Percent = "dobnyc_an_occupymorethan5percent"; //Two Options
        public const string Overlays = "dobnyc_an_overlays"; //String
        public const string IsOverlaysUnkown = "dobnyc_gc_isoverlaysunknown"; //Two Options
        public const string ProvideBSACalendarNumbers = "dobnyc_an_providebsacalendarnumbers"; //String
        public const string ProvideCPCCalendarNumbers = "dobnyc_an_providecpccalendarnumbers"; //String
        //public const string RelatedAltBISJobNumbers = "dobnyc_an_relatedaltbisjobnumbers"; //String
        public const string RelatedDOBJobNumbers = "dobnyc_an_relateddobjobnumbers"; //String
        public const string SpecialDistricts = "dobnyc_an_specialdistricts"; //String
        public const string isSpecialDistrictsUnkown = "dobnyc_gc_isspecialdistsunknown"; //Two Options
        public const string SizeofCut = "dobnyc_sizeofcutcurbcut";//float
        public const string StructuralStabilityAffected = "dobnyc_an_structuralstabilityaffected"; //Two Options
        public const string WorkIncludesPartialDemolition = "dobnyc_an_workincludespartialdemolition"; //Two Options
        public const string EstimatedNewWorkFinalCost = "dobnyc_an_estimatednewworkfinalcost"; //Currency
        public const string EstimatedLegalWorkFinalCost = "dobnyc_estimatedlegalizationjobcostfinal";
        public const string GoToAntennaScopeofWork = "dobnyc_asw_antennascopeofwork"; //Lookup for Antenna Scope of Work
        public const string GoToAntennaDS1 = "dobnyc_an_ds1"; //Lookup for Antenna DS1
        //public const string GoToAntennaLOC = "dobnyc_loc_gotolocrequest"; //Lookup for Antenna LOC
        public const string GoToCurbCutQuestionnaire = "dobnyc_cc_curbcutquestionnaire"; //Lookup for Curb Cut Questionaire
        public const string IsEstimatedCostsameasFinalCost = "dobnyc_an_isestimatedjobcostsameasfinalcost";// Two Options

        public const string CRFNZoningExhibitNumber1 = "dobnyc_an_crfnzoningexhibitnumber1"; //String
        public const string CRFNZoningExhibitNumber2 = "dobnyc_an_crfnzoningexhibitnumber2"; //String
        public const string CRFNZoningExhibitNumber3 = "dobnyc_an_crfnzoningexhibitnumber3"; //String
        public const string CRFNZoningExhibitNumber4 = "dobnyc_an_crfnzoningexhibitnumber4"; //String

        public const string FacadeAlternation = "dobnyc_an_cc_facadesalternation"; //Two Options
        public const string AdultEstablishment = "dobnyc_adultestablishment"; //Two Options
        public const string QualityHousing = "dobnyc_an_cc_qualityhousing"; //Two Options
        public const string GoToDelegates = "dobnyc_ms_gotodelegates"; //Lookup to Delegates
        public const string islocinitiated = "dobnyc_an_islocinitiated"; //Two Optionsdobnyc_an_islocinitiated

        #endregion

        #region Fab4
        public const string Sign = "dobnyc_f4_signcheckbox";
        public const string SupportedScaffold = "dobnyc_f4_supportedscaffoldcheckbox";
        public const string SidewalkShed = "dobnyc_f4_swssidewalkshed";
        public const string ConstructionFence = "dobnyc_f4_constructionfencecheckbox";
        public const string SizeoftheShed = "dobnyc_f4_sizeoftheshedlinearft";
        public const string Fab4SharedVariable = "Fab4SharedVariable";
        public const string ScaffoldIdentifier = "Scaffold";
        public const string SidewalkIdentifier = "SideWalkShed";
        public const string FenceIdentifier = "ConstructionFence";
        public const string SignIdentifier = "Sign";
        public const string ElectricalIdentifier = "Electrical";
        public const string ScaffoldScopeofWorklookup = "dobnyc_f4_scaffoldscopeofwork";
        public const string SHScopeofWorklookup = "dobnyc_f4_sidewalkshedscopeofwork";
        public const string FenceScopeofWorklookup = "dobnyc_f4_constructionfence";
        public const string LoftBoard = "dobnyc_f4_loftboard";
        public const string SROMultiple = "dobnyc_f4_sromultipledwelling";
        public const string SiteSafetyJob = "dobnyc_f4_sitesafetyjobproject";
        public const string IncludedinLMCC = "dobnyc_f4_includedinlmcc";
        public const string heightFt = "dobnyc_f4_heightft";
        public const string describeOther = "dobnyc_f4_describeother";
        public const string LandmarkFee = "dobnyc_f4_landmarkfee";
        //  public const string constructionMaterial = "dobnyc_f4_constructionmaterial";

        //fab4 shared variables
        public const string sharedCFFee = "CFFee";
        public const string sharedScaffoldFee = "ScaffoldFee";
        public const string sharedElectricalFee = "Electrical";
        public const string sharedSidewalkFee = "SidewalkFee";
        public const string sharedSignFee = "SignFee";
        public const string sharedRecordMgmt = "RecordMgmtFee";
        public const string sharedBuildingType = "BuildingType";
        public const string sharedRefund = "Refund";
        public const string sharedAmountdue = "Amountdue";
        public const string sharedExistingAmountPaid = "ExistingAmountPaid";
        public const string sharedPaaFee = "paaFeeShared";



        //Electrical Worktype Fields
        public const string isElectricalWorkType = "dobnyc_el_iselectricalworktype";
        public const string constructionMaterial = "dobnyc_f4_constructionmaterial";

        public const string BSAMEAOTCRApprovalNumber = "dobnyc_f4_bsameaotcrapprovalnumber";
        public const string fenceConstructionMaterial = "dobnyc_f4_fenceconstructionmaterial";

        #endregion


        public const string JobTypeMultiStake = "dobnyc_jobtype";
        public const string JobNBorAltType = "dobnyc_ms_jobalterationtype";
        public const string IsLegalization = "dobnyc_gc_islegalization";
        public const string IsExistingProdAlterationJob = "dobnyc_ms_existingalterationjob";
        public const string JobFilingPreviousState = "dobnyc_l2_jobfilingpreviousstate";

        #region GC,BE,MS,ST
        //public const string GeneralConstructionWorkType = "dobnyc_gc_generalconstruction";
        //public const string StructuralWorkType = "dobnyc_st_structural";
        //public const string MechanicalWorkType = "dobnyc_gc_mechanical";
        public const string FailedPaymentHistoryGUID = "dobnyc_failedpaymenthistoryguid";
        //public const string HeightAdjBuld = "dobnyc_gc_heightoftallestbuld";
        //public const string NoStoriesAdjBuld = "dobnyc_gc_numberofstoriesajdbuld";
        //public const string IsProposedConsOnLot = "dobnyc_gc_isproposedconstlotline";
        //public const string ExcavationGreaterthn12 = "dobnyc_gc_isrequiresexcavation";
        //public const string PGL1Description = "dobnyc_gc_pgl1description";
        //public const string SiteSafety_LookId = "dobnyc_gc_sitesafety_lookid";
        public const string ProcessId = "processid";
        public const string StageId = "stageid";
        //public const string Openwebsteeljoists = "dobnyc_gc_openwebsteeljoists";
        //public const string Structuralcoldformedsteel = "dobnyc_gc_structuralcoldformedsteel";
        public const string IsHistoricJobFiling = "dobnyc_ishistoricfiling";

        public const string MSWorkIncludesRaisingorMoving = "dobnyc_ms_workincludesraisingormoving";
        public const string STWorkOnInterior = "dobnyc_st_workoninteriorofbuilding";
        public const string STWorkOnExterior = "dobnyc_st_workonexteriorofbuilding";
        public const string STRemovingOneOrMoreStories = "dobnyc_st_removingoneormorestories";
        public const string STDemolishing50OrMore = "dobnyc_st_demolishing50ormoreofthearea";
        public const string STAlternativeMaterialsOTCR = "dobnyc_st_alternativematerialsrequiredanotcr";

        public const string HeatingSystem = "dobnyc_gc_heatingsystem";
        public const string VentilationSystem = "dobnyc_gc_ventilationsystem";
        public const string AirConditioningSystem = "dobnyc_gc_airconditioningsystem";
        public const string Refrigeration = "dobnyc_gc_refrigeration";
        public const string CoolingTowers = "dobnyc_gc_coolingtowers";
        public const string AssociatedDuctsAndPiping = "dobnyc_ms_associatedductsandpiping";
        public const string Generator = "dobnyc_ms_generator";
        public const string Other = "dobnyc_ms_other";
        public const string OtherValues = "dobnyc_ms_othervalues";

        public const string IsPAACreationCompleted = "dobnyc_ispaacreationcompleted";
        #endregion


        #region Boilers Build
        public const string BoilersBuildIdentifier = "BoilersBuild";
        public const string MSIdentifier = "MSIdentifier";
        public const string STIdentifier = "STIdentifier";
        public const string LegalizationViolationNumber = "dobnyc_ms_legalizationviolationnumber";
        public const string LegalizationViolationflag = "dobnyc_ms_isthereexistingviolationrelatedtowor";
        public const string ProposedboilerEnergySource = "dobnyc_proposedboilerenergysource";

        #endregion

    }

    public sealed class CurbCutQuestionnaireAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_curbcutquestionnaire";
        public const string SizeofCut = "dobnyc_cc_sizeofcutwithsplays";
    }
    public sealed class SignCharactersticsAttributeName
    {
        public const string EntityLogicalName = "dobnyc_f4_signscharacteristics";
        public const string isThisProjectingSign = "dobnyc_f4_sc_isthisaprojectingsign";
        public const string signPurpose = "dobnyc__f4_sc_purpose";
        public const string HeightAboveTheCurb = "dobnyc_f4_sc_heightabovethecurb";
        public const string SignProjectsByFt = "dobnyc_f4_sc_signprojectsbyft";
        public const string SignProjectsByIn = "dobnyc_f4_sc_signprojectsbyin";
        public const string HeightAboveTheRoof = "dobnyc_f4_sc_heightabovetheroof";
        public const string IsRoofSignTightClosedSolid = "dobnyc_f4_sc_signtightclosed";
        public const string SignType = "dobnyc_f4_sc_signtype";
        public const string TypeOfIllumination = "dobnyc_f4_sc_typeofillumination";
        public const string MaterialOfTheSign = "dobnyc_f4_sc_materialofthesign";
        public const string EstimatedJobCost = "dobnyc_f4_sc_estimatedjobcost";
        public const string TotalSquareFeet = "dobnyc_f4_sc_totalsquarefeet";
        public const string Weightlbs = "dobnyc_f4_sc_weightlbs";
        public const string TotalZoningLotFrontageFeet = "dobnyc_f4_sc_totalzoninglotfrontagefeet";
        public const string TotalSurfaceAreaofallSignsinZoning = "dobnyc_f4_sc_totalsurfaceareaofallsignsinzoning";
        public const string TotalSurfaceAreaofthisSigninSqft = "dobnyc_f4_sc_totalsurfaceareaofthissigninsqft";
        public const string MaximumAllowableSurfaceAreaonZon = "dobnyc_f4_sc_maximumallowablesurfaceareaonzon";
        public const string IgnDesignedforChangeableCopy = "dobnyc_f4_sc_igndesignedforchangeablecopy";
        public const string DoesAnoaChaveanInterestinThisSign = "dobnyc_f4_sc_doesanoachaveaninterestinthissign";
        public const string OacRegistrationNumber = "dobnyc_f4_sc_oacregistrationnumber";
        public const string SignRegistrationNumber = "dobnyc_f4_sc_signregistrationnumber";
        public const string WithInviewofAnarterialHighway = "dobnyc_f4_sc_withinviewofanarterialhighway";
        public const string DistanceFromarterialHighwayFeet = "dobnyc_f4_sc_distancefromarterialhighwayfeet";
        public const string GistrationNumberHighway = "dobnyc_f4_sc_gistrationnumberhighway";
        public const string Within200AndWithinViewPark = "dobnyc_f4_sc_within200andwithinviewpark";
        public const string DistanceFromPark12AcreorMore = "dobnyc_f4_sc_distancefrompark12acreormore";
        public const string ParkSignRegistrationNumber = "dobnyc_f4_sc_parksignregistrationnumber";
        public const string GotoJobFiling = "dobnyc_f4_sc_gotojobfiling";
        public const string ContactName = "dobnyc_f4_sc_contactname";
        public const string RelationshiptoOwner = "dobnyc_f4_sc_relationshiptoowner";
        public const string SignLocation = "dobnyc_f4_sc_signlocation";
        public const string IsRoofSignTightFlag = "dobnyc_f4_sc_isrrofsigntightflag";
        public const string SignWording = "dobnyc_f4_sc_signwording";
        public const string Signfee = "dobnyc_f4_sc_signfee";
        public const string SignatteStation = "dobnyc_f4_sc_signattestation";
        public const string SignatureDate = "dobnyc_f4_sc_signaturedate";
        public const string SignaturePersonName = "dobnyc_f4_sc_signaturepersonname";
        public const string IsSignFinal = "dobnyc_f4_sc_issignfinal";
        public const string Landmarkfee = "dobnyc_f4_sc_landmarkfee";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }

    public sealed class FenceScopeofWorkAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_fencescopeofwork";
        public const string Name = "dobnyc_name";
        public const string FenceScopeofWorkId = "dobnyc_fencescopeofworkid";
        public const string GotoJobFiling = "dobnyc_f4_fsw_gotojobfiling";

        public const string FenceHeight = "dobnyc_f4_fsw_fenceheight";
        public const string FenceLocation = "dobnyc_f4_cf_fencelocation";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }

    public sealed class SiteSafetyEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_sitesafety";
        public const string Name = "dobnyc_name";
        public const string SiteSafetyProject = "dobnyc_ss_sitesafetyjobproject";
        public const string GotoJobFiling = "dobnyc_ss_gotojobfilling";
    }

    public sealed class ScaffoldScopeofWorkAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_scaffoldscopeofwork";
        public const string Name = "dobnyc_name";
        public const string ScaffoldScopeofWorkId = "dobnyc_scaffoldscopeofworkid";
        public const string GotoJobFiling = "dobnyc_f4_sfsw_gotojobfiling";
        public const string ScaffoldShedType = "dobnyc_f4_sfsw_scaffoldshedtype";
        public const string IsTheSupportedScaffoldGoing = "dobnyc_f4_sfsw_isthesupportedscaffoldgoing";
        public const string HowIsTheScaffoldSupported = "dobnyc_f4_sfsw_howisthescaffoldsupported";
        public const string ScaffoldSupportDescribe = "dobnyc_f4_sfsw_scaffoldsupportdescribe";
        public const string IsThereAnyRelatedConstructione = "dobnyc_f4_sfsw_isthereanyrelatedconstructione";
        public const string SupportedScaffoldThatRest = "dobnyc_f4_sfsw_supportedscaffoldthatrest";
        public const string Walkshed = "dobnyc_f4_sfsw_walkshed";
        public const string SafetyNetting = "dobnyc_f4_sfsw_safetynetting";
        public const string Hoists = "dobnyc_f4_sfsw_hoists";
        public const string Cranes = "dobnyc_f4_sfsw_cranes";
        public const string Chutes = "dobnyc_f4_sfsw_chutes";
        public const string Derricks = "dobnyc_f4_sfsw_derricks";
        public const string DobnowFilingNumber = "dobnyc_f4_sfsw_dobnowfilingnumber";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }

    public sealed class SHScopeofWorkAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_sidewalkshedscopeofwork";
        public const string Name = "dobnyc_name";
        public const string SHScopeofWorkId = "dobnyc_sidewalkshedscopeofworkid";
        public const string GotoJobFiling = "dobnyc_f4_swsw_gotojobfiling";
        public const string shedType = "dobnyc_f4_swsw_shedtype";
        public const string extendPropertyLines = "dobnyc_f4_swsw_extendpropertylines";
        public const string howShedSupported = "dobnyc_f4_swsw_shedsupported";
        public const string sidewalkshedDescribe = "dobnyc_f4_swsw_describe";
        public const string relatedConstruction = "dobnyc_f4_swsw_relatedconstructionequipment";
        public const string restontopofasidewalk = "dobnyc_fab4_swsw_supportedscatfold";
        public const string safetyNetting = "dobnyc_fab4_swsw_safetynetting";
        public const string Hoists = "dobnyc_fab4_swsw_hoists";
        public const string Cranes = "dobnyc_fab4_swsw_cranes";
        public const string Derricks = "dobnyc_fab4_swsw_derricks";
        public const string Chutes = "dobnyc_fab4_swsw_chutes";
        public const string SideWalkVault = "dobnyc_fab4_swsw_sidewalkvault";
        public const string ElectricalVault = "dobnyc_fab4_swsw_electricalvault";
        public const string SiameseConnection = "dobnyc_fab4_swsw_siameseconnection";
        public const string BusStop = "dobnyc_fab4_swsw_busstop";
        public const string LightPole = "dobnyc_fab4_swsw_lightpole";
        public const string Sign = "dobnyc_fab4_swsw_sign";
        public const string Canopy = "dobnyc_fab4_swsw_canopy";
        public const string Other = "dobnyc_fab4_swsw_other";
        public const string ShedModificationDescribe = "dobnyc_fab4_swsw_shedmodificationdescribe";
        public const string EnterBISjobnNmberor = "dobnyc_f4_swsw_enterabisjobnumberor";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }


    public sealed class NumberSequenceEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_numbersequence";
        public const string JobFilingGUID = "dobnyc_jobfilingguid";
        public const string JobFilingNumber = "dobnyc_jobfilingnumber";
        public const string PrimaryNameAttribute = "dobnyc_name";


    }
    public sealed class WithdrawalRequestEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_withdrawalrequest";
        public const string WithdrawalRequestNumber = "dobnyc_name";
        public const string Withdrawalof = "dobnyc_withdrawalrequest_withdrawalof";
        public const string WithdrawalStatus = "dobnyc_withdrawalrequest_withdrawalstatus";
        public const string Requester = "dobnyc_withdrawal_requester";
        public const string GotoJobFiling = "dobnyc_gotojobfiling";
        public const string WorkPermit = "dobnyc_withdrawal_workpermit";
        public const string IsSubmitted = "dobnyc_withdrawal_issubmitted";
        public const string WithdrawalRequestId = "dobnyc_withdrawalrequestid";
        public const string DPCheck = "dobnyc_dpcheck";
        public const string DpName = "dobnyc_dpname";
        public const string DPDate = "dobnyc_dpdate";
        public const string POCheck = "dobnyc_pocheck";
        public const string POName = "dobnyc_poname";
        public const string PODate = "dobnyc_podate";
        public const string InspectionCompleted = "dobnyc_inspectioncompleted";
    }


    public sealed class LicenseTypeEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_licensetype";
    }

    public sealed class LicenseeEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_licensee";
        public const string Name = "dobnyc_name";
    }

    public sealed class ContactEntityAttributeName
    {
        public const string EntityLogicalName = "contact";
        public const string ContactId = "contactid";
        public const string DOBIssuedID = "dobnyc_dobissuedid";
        public const string LicenseNumber = "dobnyc_licensenumber";
        public const string ApplicantType = "dobnyc_applicanttype";
        public const string LastNameContractor = "lastname";
        public const string MiddleInitialContractor = "middlename";
        public const string FirstNameContractor = "firstname";
        public const string BusinessAddressContractor = "address1_line1";
        public const string BusinessFaxContractor = "fax";
        public const string BusinessNameContractor = "dobnyc_businessname";
        public const string LicensenumberContractor = "dobnyc_licensenumber";
        public const string BusinessTelephoneContractor = "telephone1";
        public const string LicenceTypeContractor = "dobnyc_licencetype";
        public const string StateContractor = "address1_stateorprovince";
        public const string MobileTelephoneContractor = "mobilephone";
        public const string CityContractor = "address1_city";
        public const string ZipContractor = "address1_postalcode";
        public const string TaxPayerIDContractor = "dobnyc_taxpayerid";
        public const string EmailContractor = "emailaddress1";
        public const string FullName = "fullname";


    }

    public sealed class ActivityParty
    {
        public const string ActivityPartyEntityLogicalName = "activityparty";
        public const string ActivityPartId = "partyid";
    }

    public sealed class SystemuserEntityAttributeNames
    {
        public const string SystemUserIdFieldName = "systemuserid";
        public const string FullNameFieldName = "fullname";
        public const string IsDisabledFieldName = "isdisabled";
        public const string EmployeeIdFieldName = "employeeid";
        public const string BusinessUnitFieldName = "businessunitid";
        public const string ParentUserIdFieldName = "parentsystemuserid";
        public const string FirstNameFieldName = "firstname";
        public const string LastNameFieldName = "lastname";
        public const string DomainNameFieldName = "domainname";
        public const string ModifiedOnFieldName = "modifiedon";
        public const string InternalEmail = "internalemailaddress";
        public const string PersonalEmail = "personalemailaddress";
        public const string MobileAlertEmail = "mobilealertemail";
        public const string Tel1 = "address1_telephone1";
        public const string Tel2 = "address1_telephone2";
        public const string HomePhone = "homephone";
        public const string MobilePhone = "mobilephone";
        public const string Fax = "address1_fax";
        public const string IsOutofOffice = "dobnyc_isoutofoffice";
        public const string DelegateUser = "dobnyc_delegateuserid";
        public const string EntityName = "systemuser";

    }

    public sealed class EmailEntityAttributeName
    {
        public const string EntityLogicalName = "email";
        public const string From = "from";
        public const string To = "to";
        public const string Cc = "cc";
        public const string Bcc = "bcc";
        public const string Subject = "subject";
        public const string Description = "description";
        public const string Regarding = "regardingobjectid";


    }

    public sealed class WorkPermitEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_workpermit";
        public const string WorkPermitId = "dobnyc_workpermitid";
        public const string TypeofPermit = "dobnyc_wp_typeofpermit"; // optionset
        public const string WorkPermitStatus = "dobnyc_workpermit_status";// optionset
        public const string WorkPermitNumber = "dobnyc_name";
        public const string TrackingNumber = "dobnyc_trackingnumber";
        public const string SequenceNumber = "dobnyc_workpermit_sequencenumber"; // whole Number
        public const string GotoJobFiling = "dobnyc_workpermittojobfilingrelationshid";
        public const string ApplicantContractor = "dobnyc_applicantcontractor";
        public const string NoWorkCheckBox = "dobnyc_wp_noworkpermit";
        public const string LastNameContractor = "dobnyc_wp_lastname";
        public const string MiddleInitialContractor = "dobnyc_wp_middleinitial";
        public const string FirstNameContractor = "dobnyc_wp_firstname";
        public const string BusinessAddressContractor = "dobnyc_wp_businessaddress";
        public const string BusinessFaxContractor = "dobnyc_wp_businessfax";
        public const string BusinessNameContractor = "dobnyc_wp_businessname";
        public const string BusinessNameLookup = "dobnyc_businessname";
        public const string LicensenumberContractor = "dobnyc_wp_licensenumber";
        public const string BusinessTelephoneContractor = "dobnyc_wp_businesstelephone";
        public const string LicenceTypeContractor = "dobnyc_wp_licencetype"; // optionset
        public const string StateContractor = "dobnyc_wp_state";
        public const string MobileTelephoneContractor = "dobnyc_wp_mobiletelephone";
        public const string CityContractor = "dobnyc_wp_city";
        public const string ZipContractor = "dobnyc_wp_zip";
        public const string TaxPayerIDContractor = "dobnyc_wp_taxpayerid";
        public const string EmailContractor = "dobnyc_wp_email";
        public const string DescriptionContractor = "dobnyc_wp_description";
        public const string ApplicantResponsibleforalltheworkContractor = "dobnyc_wp_applicantresponsibleforallthework"; // boolean
        public const string JobFilingRelationshipID = "dobnyc_workpermittojobfilingrelationshid";
        public const string PermitRenewalFee = "dobnyc_permitrenewalfee";
        public const string AmountDue = "dobnyc_amountdue";
        public const string AmountPaid = "dobnyc_amountpaid";
        public const string RenewalPermitWithChanges = "dobnyc_wp_renewalpermitwithchanges";
        public const string RenewalPermitWithOutChanges = "dobnyc_wp_renewalpermitwithoutchanges";
        public const string PaymentHistoryGUID = "dobnyc_phguid";
        public const string IsWorkPermitSubmitted = "dobnyc_isworkpermitsubmitted";
        public const string PermitSubmittedDated = "dobnyc_permitsubmitteddate";
        public const string PermitIssuedDate = "dobnyc_permitissueddate";
        public const string LicenseeType = "dobnyc_licenseetype";
        public const string FilingNumber = "dobnyc_filingnumber";
        public const string PLCheck = "dobnyc_plcheck";
        public const string SPCheck = "dobnyc_spcheck";
        public const string SDCheck = "dobnyc_sdcheck";
        public const string InspectionCompleted = "dobnyc_wp_inspectioncompleted"; //boolean
        public const string InspectionStatus = "dobnyc_inspectionstatus"; //optionset
        public const string InspectionDate = "dobnyc_inspectiondate";
        public const string ProfCertTaskId_QAPermit = "dobnyc_qaworkpermitsid";
        public const string AddedbeforeProfReview = "dobnyc_addedbeforeprofcertreview";
        public const string ContractorLegalCheck = "dobnyc_dpcheckwp";
        public const string ContractorLegalSignature = "dobnyc_nameprintstatement";
        public const string ContractorLegalDate = "dobnyc_datewpstatement";
        public const string JobDescription = "dobnyc_jobdescription";
        public const string PermitExprirationDate = "dobnyc_permitexpirationdate";
        public const string LiabilityInsuranceRequired = "dobnyc_wp_liabilityinsurance";
        public const string LiabilityInsuranceName = "dobnyc_wp_liabilityinsurername";
        public const string LiabilityInsuranceExpDate = "dobnyc_liabilityinsuranceexpirydate";
        public const string WorkerCompInsuranceRequired = "dobnyc_wp_workerscompensationinsurance";
        public const string WorkerCompInsuranceName = "dobnyc_wp_wciinsurername";
        public const string WorkerCompInsuranceExpDate = "dobnyc_wp_wciexpirationdate";
        public const string DisabilityInsuranceRequired = "dobnyc_wp_disabilityinsurance";
        public const string DisabilityInsuranceName = "dobnyc_wp_disabilityinsurername";
        public const string DisabilityInsuranceExpDate = "dobnyc_wp_diexpirationdate";
        public const string AntennaLicenseType = "dobnyc_wp_antennaapplicantlicensetype";
        public const string RenewalInitialPermitNo = "dobnyc_workpermitnumber";
        public const string WorkonFloor = "dobnyc_wp_workonfloor";
        public const string PlanApprovedDate = "dobnyc_planaprroveddate";
        public const string IsRenewalPermit = "dobnyc_isthisrenwalpermit";
        public const string IsTowerCraneUsed = "dobnyc_gc_isatowercranetobeused";
        public const string NoGoodCheckFee = "dobnyc_workpermit_nogoodcheckfee";
        public const string RevertFromNGC = "dobnyc_workpermit_revertedfromnogoodcheck";
        public const string ApplicantLicenseExpirationDate = "dobnyc_wp_applicantlicenseexpirationdate";
        public const string ApplicantLicenseStatus = "dobnyc_wp_applicantlicensestatus";
        public const string IsPermitExpired = "dobnyc_isworkpermitexpired";
    }
    public sealed class SupersedingRequestEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_supersedingrequest";
        public const string SupersedingRequestNumber = "dobnyc_name";
        public const string SupersedingRequestfor = "dobnyc_superseding_supersedingrequestfor";
        public const string SupersedingRequestStatus = "dobnyc_superseding_supersedingrequeststatus";
        public const string Requester = "dobnyc_superseding_requester";
        public const string IsSubmitted = "dobnyc_superseding_issubmitted";
        public const string GotoJobFiling = "dobnyc_superseding_gotojobfiling";


    }

    public sealed class AppointmentAttributeName
    {
        public const string EntityLogicalName = "appointment";
        public const string SubjectAttributeName = "subject";
        public const string RegardingGuidAttributeName = "regardingobjectid";
        public const string StartTimeAttributeName = "scheduledstart";
        public const string EndTimeAttributeName = "scheduledend";
        public const string OwnerAttributeName = "ownerid";
        public const string RequiredAttendees = "requiredattendees";
        public const string organizer = "organizer";
        public const string Pirority = "prioritycode";
        public const string AppointmentStatus = "statuscode";
        public const string statecode = "statecode";
        public const string AppointmentId = "activityid";
        public const string Duration = "scheduleddurationminutes";
        public const string MeetingStatus = "dobnyc_meetingstatus";
        public const string MeetingOutcome = "dobnyc_meetingoutcome";
        public const string IsCompleted = "dobnyc_iscompleted";
        public const string IsReschedule = "dobnyc_isreschedule";
        public const string AppointmentType = "dobnyc_appointmenttype";
    }


    public sealed class AddressChangeRequestsEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_addresschangerequests";
        public const string ChangeAddressrequestNumber = "dobnyc_name";
        public const string HouseNumber = "dobnyc_housenumber";
        public const string NewHouseNumber = "dobnyc_newhousenumber";
        public const string StreetName = "dobnyc_streetname";
        public const string Newstreetname = "dobnyc_newstreetname";
        public const string Bin = "dobnyc_bin";
        public const string Newbin = "dobnyc_newbin";
        public const string Block = "dobnyc_block";
        public const string Newblock = "dobnyc_newblock";
        public const string Aptcondonos = "dobnyc_aptcondonos";
        public const string Newaptcondonos = "dobnyc_newaptcondonos";
        public const string Borough = "dobnyc_boroughnyc";
        public const string Newborough = "dobnyc_newboroughnyc";
        public const string Lot = "dobnyc_lot";
        public const string Newlot = "dobnyc_newlot";
        public const string GotoJobFiling = "dobnyc_jobfilingtochangeaddressrequestid";
        public const string IsSubmitted = "dobnyc_addresschangerequests_issubmitted";
        public const string RequestStatus = "dobnyc_requeststatus";

    }

    public sealed class ProgressInspectionCategoryEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_progressinspectioncategory";
        public const string IdentificationofRequirement = "dobnyc_progressinspection";
        public const string ProgressInspectiontoInspectionComponentRelationshipName = "dobnyc_dobnyc_specialinspectionscomponents_dobnyc_progressinspectioncategory_ProgressInspection";
        public const string IdentificationofResponsibilities = "dobnyc_identificationofresponsibilitiespic";
        public const string CertificateofCompleteInspections = "dobnyc_certificateofcompleteinspectionstests";
        public const string Withdrawresponsibilities = "dobnyc_withdrawresponsibilitiespic";
        public const string CodeSection = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_progressioninspectioncategorytoid";
        public const string ProgressInspectionsrelationId = "dobnyc_progressinspectioncatagoryrelatid";
        public const string ProgressInspectionsrelation_WithdrawalId = "dobnyc_progressinspectionrelationid";
        public const string Withdrawn = "dobnyc_progressinsp_withdrawn";
        public const string Superseded = "dobnyc_progressinps_superseded";
        public const string CreatedFrom = "dobnyc_progressinsp_createdfrom";
        public const string ProgressInspector = "dobnyc_progressinspector";
        public const string LicenseType = "dobnyc_licensetype";
        public const string IReponsibleCheckName = "dobnyc_ireponsiblecheckname";
        public const string ICertifyCheckName = "dobnyc_icertifycheckname";
        public const string IORStatement1 = "dobnyc_iorstatement1";
        public const string ProgressInsFinalStatememt = "dobnyc_progressinsfinalstatememt";
        public const string ProgressResponsibleName = "dobnyc_progressresponsiblename";
        public const string ProgressReponsibleDate = "dobnyc_progressreponsibledate";
        public const string PreTaskCompletionInspectionWaived = "dobnyc_pa_pretaskcompletioninspectionwaived";
        public const string InspectionWaived = "dobnyc_pa_inspectionwaived";
        public const string CertificateOfCompletionStatement = "dobnyc_certificateofcompletionstatement"; //two options
        public const string ProgressCompletionName = "dobnyc_progresscompletionname";
        public const string ProgressCompletionDate = "dobnyc_progresscompletiondate";
        public const string ICertifyCompleteInspectionsTests = "dobnyc_progressicertifycompleteinspections";  //two options
        public const string FilingType = "dobnyc_pic_filingtype";
        public const string IsAutoPopulated = "dobnyc_autopopulated"; //two options
    }

    public sealed class InspectionsComponentsEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_specialinspectionscomponents";
        public const string CodeSection = "dobnyc_code";
        public const string Name = "dobnyc_name";
        public const string InspectionType = "dobnyc_inspectiontype";
        public const string WorkType = "dobnyc_worktype";
        public const string InspectionCode = "dobnyc_inspectioncode";
        public const string ConditionXML = "dobnyc_conditionxml";
        public const string DocumentRequirement = "dobnyc_documentrequirement";
        public const string InspectionsComponentsID = "dobnyc_specialinspectionscomponentsid";
    }

    public sealed class CustomConfigurationEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_customconfigurations";
        public const string Key = "dobnyc_key";
        public const string Name = "dobnyc_name";


    }

    public sealed class ScopeOfWorkEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_scheduleofbuildingsystemsdevices";
        public const string ScopeofWorkId = "dobnyc_scheduleofbuildingsystemsdevicesid"; // Primary Key
        public const string System = "dobnyc_systemsbs"; //lookup for systems
        public const string ScopeOfWorkEntitytoSystemRelationshipName = "dobnyc_dobnyc_buildingsystems_dobnyc_scheduleofbuildingsystemsdevices_SystemSBS";
        public const string WorkTypeCategory = "dobnyc_worktypescategory"; //optionset
        public const string WorkType = "dobnyc_worktype"; // optionset
        public const string GoToJobFiling = "dobnyc_schedulebuildingsystemstojobfilid"; // lookup for jobfiling
        public const string Description = "dobnyc_descriptionsbs";  //string
        public const string UnitLocation = "dobnyc_unitlocation_pl_b_hwh";  //string
        public const string TypeofUnit = "dobnyc_typeofunit_pl_b_hwh"; //string
        public const string TotalInputCapacity = "dobnyc_providetotalinputcapacityinbtuh_b_hwh"; //string
        public const string FilingScope = "dobnyc_filingscope"; // string
        public const string BackFlowPreventerType = "dobnyc_backflowpreventertype"; //optionset
        public const string BackFlowPreventerrpzFloor = "dobnyc_backflowpreventerrpzfloor";// string
        public const string EquipmentType = "dobnyc_equipmenttype";//optionset
        public const string BoilerType = "dobnyc_boilertype";//optionset
        public const string FuelGasType = "dobnyc_fuelgastype";//optionset
        public const string FuelGasUse = "dobnyc_fuelgasuse";//optionset
        public const string PrivateDrainageType = "dobnyc_psstype";//optionset
        public const string PrivateDrainageLocation = "dobnyc_privatedrainagelocation"; // string
        public const string CookingGasUse = "dobnyc_cookinggasuse"; //optionset
        public const string MetersNumber = "dobnyc_metersnumber"; // string
        public const string MetersLocatedAt = "dobnyc_meterslocatedat";
        public const string EquipmentandAlarms = "dobnyc_pl_equipmentandalarms";
        public const string TotalInputCapacityinBTUH = "dobnyc_pl_gwpdm_ea_furnace";
        public const string NumberofUnits = "dobnyc_numberofunits_pl_b_hwh";
        public const string Floor = "dobnyc_floor_pl_b_hwh";
        public const string NumberofUnitsCogenSystems = "dobnyc_numberofunitscogensystems";
        public const string FDNYUtilityApprovals = "dobnyc_fdnyutilityapprovals"; //optionset
        public const string FloorCoGEnSystems = "dobnyc_floorcogensystems"; //string
        public const string FuelGasTypeCogenSystems = "dobnyc_fuelgastypecogensystems"; //optionset
        public const string FuelGasUseCogenSystems = "dobnyc_fuelgasusecogensystems"; //optionset
        public const string MedicalOtherGas = "dobnyc_medicalothergas"; //optionset
        public const string MedicalOtherGasLocatedat = "dobnyc_medicalothergaslocatedat"; //string
        public const string PrivateStorm = "dobnyc_privatestorm"; //optionset
        public const string DryWellWorkType = "dobnyc_drywellworktype"; //optionset
        public const string StormSystems = "dobnyc_stormsystems"; //optionset
        public const string StormSystemsLocatedat = "dobnyc_stormsystemslocatedat"; //string
        public const string PoolType = "dobnyc_pooltype";//optionset
        public const string Describe = "dobnyc_describethereason_workpenetration";// multiple string
        public const string SprinklerSystem = "dobnyc_sprinklersystem";//optionset
        public const string HazardType = "dobnyc_hazardtype"; //optionset
        public const string SystemType = "dobnyc_systemtype"; //optionset
        public const string WaterMain = "dobnyc_watermain"; //optionset
        public const string FDC = "dobnyc_fdc"; //optionset
        public const string Tank = "dobnyc_tank";//optionset
        public const string TypeofPumps = "dobnyc_typeofpumps"; //optionset
        public const string StandardSprinklerHead = "dobnyc_standardsprinklerhead";// two options
        public const string ExtendedCoverageHead = "dobnyc_extendedcoveragehead"; // two options
        public const string WorkRequiresPenetrationofFireRated = "dobnyc_workrequirespenetrationoffirerated";//optionset
        public const string TypeofSprinklerSystem = "dobnyc_typeofsprinklersystem";//optionset
        public const string RiserControlValve = "dobnyc_risercontrolvalve";// two options
        public const string RiserSandBranches = "dobnyc_risersandbranches";// two options
        public const string BoosterPump = "dobnyc_boosterpump";// two options
        public const string FirePump = "dobnyc_firepump"; // two options
        public const string DryPumpValve = "dobnyc_drypumpvalve";// two options
        public const string SpecialServicePump = "dobnyc_specialservicepump";// two options
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";// two options

    }

    public sealed class ScopeOfWorkAttributesNames // Copied from Integration
    {
        public const string SystemLookUpFieldEntityName = "dobnyc_buildingsystems";
        public const string BackflowPreventerRPZFloorAttributeName = "dobnyc_backflowpreventerrpzfloor";
        public const string BackflowPreventerRPZTypeAttributeName = "dobnyc_backflowpreventertype";
        public const string BoilerTypeAttributeName = "dobnyc_boilertype";
        public const string BoosterPumpAttributeName = "dobnyc_boosterpump";
        //public const string CookingGasUseAttributeName = "dobnyc_cookinggasuse";
        public const string Residential_CookingGasUseAttributeName = "dobnyc_residential_cgs";
        public const string Commercial_CookingGasUseAttributeName = "dobnyc_commercial_cgu";
        public const string DescribeAttributeName = "dobnyc_describethereason_workpenetration";
        public const string DescriptionAttributeName = "dobnyc_descriptionsbs";
        public const string DryPumpValveAttributeName = "dobnyc_drypumpvalve";
        public const string DryWellWorkTypeAttributeName = "dobnyc_drywellworktype";
        //public const string EquipmentTypeAttributeName = "dobnyc_equipmenttype";
        public const string Pumps_EquipmentTypeAttributeName = "dobnyc_pumps_et";
        public const string DrinkingFountain_EquipmentTypeAttributeName = "dobnyc_drinkingfountain_et";
        public const string Tanks_EquipmentTypeAttributeName = "dobnyc_tanks_et";
        public const string Filters_EquipmentTypeAttributeName = "dobnyc_filters_et";
        public const string Boilers_EquipmentTypeAttributeName = "dobnyc_boilers_et";
        public const string ExtendedCoverageHeadAttributeName = "dobnyc_extendedcoveragehead";
        public const string FDCAttributeName = "dobnyc_fdc_sp_two_optionset";
        public const string FDNYUtilityApprovalsAttributeName = "dobnyc_fdnyutilityapprovals";
        public const string FilingScopeAttributeName = "dobnyc_filingscope";
        public const string FirePumpAttributeName = "dobnyc_firepump";
        public const string FloorAttributeName = "dobnyc_floor_pl_b_hwh";
        public const string FloorCoGEnSystemsAttributeName = "dobnyc_floorcogensystems";
        //public const string FuelGasTypeAttributeName = "dobnyc_fuelgastype";
        public const string LowPressure_FuelGasTypeAttributeName = "dobnyc_lowpressure_fgt";
        public const string MediumPressure_FuelGasTypeAttributeName = "dobnyc_mediumpressure_fgt";
        public const string FuelGasTypeCoGenSystemsAttributeName = "dobnyc_fuelgastypecogensystems";
        //public const string FuelGasUseAttributeName = "dobnyc_fuelgasuse";
        public const string Cooking_FuelGasUseAttributeName = "dobnyc_cooking_fgu";
        public const string firesuppressionhood_FuelGasUseAttributeName = "dobnyc_firesuppressionhood_fgu";
        public const string Heating_FuelGasUseAttributeName = "dobnyc_heating_fgu";
        public const string HotWater_FuelGasUseAttributeName = "dobnyc_hotwater_fgu";
        public const string otheralternativefireextinguisingsystem_FuelGasUseAttributeName = "dobnyc_otheralternativefireextinguisingsystem";
        //public const string FuelGasUseAttributeName = "dobnyc_fuelgasuse";
        public const string FuelGasUseCoGenSystemsAttributeName = "dobnyc_fuelgasusecogensystems";
        public const string HazardTypeAttributeName = "dobnyc_hazardtype";
        public const string MedicalOtherGasAttributeName = "dobnyc_medicalothergas";
        public const string MedicalOtherGasLocatedatAttributeName = "dobnyc_medicalothergaslocatedat";
        public const string MetersLocatedatAttributeName = "dobnyc_meterslocatedat";
        public const string MetersNumberAttributeName = "dobnyc_metersnumber";
        public const string codeAttributeName = "dobnyc_name";
        public const string NumberofUnitsAttributeName = "dobnyc_numberofunits_pl_b_hwh";
        public const string NumberofUnitsCoGenSystemsAttributeName = "dobnyc_numberofunitscogensystems";
        //public const string EquipmentandAlarmsAttributeName = "dobnyc_pl_equipmentandalarms";
        public const string Burners_EquipmentandAlarmsAttributeName = "dobnyc_burners_ea";
        public const string Dryers_EquipmentandAlarmsAttributeName = "dobnyc_dryers_ea";
        public const string Furnance_EquipmentandAlarmsAttributeName = "dobnyc_furance_ea";
        public const string Generator_EquipmentandAlarmsAttributeName = "dobnyc_generator_ea";
        public const string FirePlace_EquipmentandAlarmsAttributeName = "dobnyc_fireplace_ea";
        public const string ProvidethetotalinputcapacityinBTUhFurnanceAttributeName = "dobnyc_pl_gwpdm_ea_furnace";
        //public const string PoolTypeAttributeName = "dobnyc_pooltype";
        public const string Outdoor_PoolTypeAttributeName = "dobnyc_outdoor_pt";
        public const string Indoor_PoolTypeAttributeName = "dobnyc_indoor_pt";
        public const string PrivateDrainageLocationAttributeName = "dobnyc_privatedrainagelocation";
        public const string PrivateStormAttributeName = "dobnyc_privatestorm";
        public const string ProvidetotalinputcapacityinBTUhHWHAttributeName = "dobnyc_providetotalinputcapacityinbtuh_b_hwh";
        public const string PrivateDrainageTypeAttributeName = "dobnyc_psstype";
        public const string RiserControlValveDistributionPipingAttributeName = "dobnyc_risercontrolvalve";
        public const string RisersandBranchesDistributionPipingAttributeName = "dobnyc_risersandbranches";
        public const string ScheduleBuildingsystemstoJobfilingGUIDAttributeName = "dobnyc_schedulebuildingsystemstojobfilid";
        public const string ScopeOfWorkEntityLogicalAttributeName = "dobnyc_scheduleofbuildingsystemsdevices";
        public const string SpecialServicePumpAttributeName = "dobnyc_specialservicepump";
        public const string SprinklerSystemAttributeName = "dobnyc_sprinklersystem";
        //public const string Proposed_SprinklerSystemAttributeName = "dobnyc_proposed_tss";
        //public const string Existing_SprinklerSystemAttributeName = "dobnyc_existing_tss";
        public const string StandardSprinklerHeadAttributeName = "dobnyc_standardsprinklerhead";
        public const string StormSystemsAttributeName = "dobnyc_stormsystems";
        //public const string DryWellStormSystemsAttributeName = "dobnyc_drywellstromsystem";
        //public const string RetentionStormSystemsAttributeName = "dobnyc_retentionstromsystem";
        //public const string DetentionStormSystemsAttributeName = "dobnyc_detentionstormsystem";
        public const string StormSystemsLocatedatAttributeName = "dobnyc_stormsystemslocatedat";
        public const string SystemAttributeName = "dobnyc_systemsbs";
        public const string SystemTypeAttributeName = "dobnyc_systemtype";
        public const string BuildingSystemEntityName = "dobnyc_buildingsystems";
        public const string TankAttributeName = "dobnyc_tank";
        public const string TypeofPumpsAttributeName = "dobnyc_typeofpumps";
        //public const string Boosterpump_TypeofPumpsAttributeName = "dobnyc_boosterpump_tp";
        //public const string JockeyPump_TypeofPumpsAttributeName = "dobnyc_jockeypump_tp";
        //public const string SpecialServicepump_TypeofPumpsAttributeName = "dobnyc_specialservicepump_tp";
        public const string FireExtinguishingSystemconnectedtoSPAttributename = "dobnyc_fireextinguishingsystemconnectedtosp";
        public const string accountNumberatrributeName = "dobnyc_accountnumber";
        public const string TypeofSprinklerSystemAttributeName = "dobnyc_typeofsprinklersystem";
        public const string TypeofSprinklerSystemSMAttributeName = "dobnyc_typeofsprinklersystem_sm";
        public const string TypeofUnitAttributeName = "dobnyc_typeofunit_pl_b_hwh";
        public const string UnitLocationAttributeName = "dobnyc_unitlocation_pl_b_hwh";
        //public const string WaterMainAttributeName = "dobnyc_watermain";
        public const string RPZ_WaterMainAttributeName = "dobnyc_rpz_wm";
        public const string DDCV_WaterMainAttributeName = "dobnyc_ddcv_wm";
        public const string WorkrequirespenetrationoffireratedassembliesAttributeName = "dobnyc_workrequirespenetrationoffirerated";
        public const string WorkTypeAttributeName = "dobnyc_worktype";
        public const string WorkTypeCategoryAttributeName = "dobnyc_worktypescategory";
        public const string ScheduleofBuildingSystemsDevicesIDAttributeName = "dobnyc_scheduleofbuildingsystemsdevicesid";
        public const string CreatedOnAttributeName = "createdon";
        public const string DistributionPipingAttributeName = "dobnyc_distributionpiping";

        public const string BuildingSystemCategory = "dobnyc_buildingsystemcategory";
        public const string BuildingSystemCategoryWorkTypeAttributeName = "dobnyc_worktype";

        public const string CreatedByAttributeName = "dobnyc_createdby";

    }

    public sealed class EN2EntityAttributeNames
    {
        public const string ProgressInspector = "dobnyc_progressinspector";
        public const string LicenseType = "dobnyc_licensetype";
        public const string FilingType = "dobnyc_filingtype";
        public const string AsBuiltInformation1 = "dobnyc_asbuiltinformation1";
        public const string AsBuiltInformation2 = "dobnyc_asbuitlinformation2";
        public const string AsBuiltInformation2A = "dobnyc_asbuiltinformation2a";
        public const string AsBuiltInformation2B = "dobnyc_asbuiltinformation2b";
        public const string DateEN2 = "dobnyc_dateen2";
        public const string EntityLogicalName = "dobnyc_en2";
        public const string En2Guid = "dobnyc_en2id";
        public const string JobFilingGuid = "dobnyc_jobfiningtoen2id";
        public const string NameLiegalField = "dobnyc_namepleaseprint";
        public const string CreatedOn = "createdon";
        public const string ProgressInspectorStatementCheckBox = "dobnyc_progressinspectorstatementcheckbox";
    }

    public sealed class DocumentListEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_documentlist";
        public const string DocumentName = "dobnyc_documentnamedocumentlist";
        public const string GotoTr3Mix = "dobnyc_dl_gotomix";
        public const string RequestNumber = "dobnyc_requestnumber";
        public const string RequiredItemNumber = "dobnyc_name";
        public const string DocumentListtoJobfiling = "dobnyc_documentlisttojobfilingid";
        public const string GotoWorkPermit = "dobnyc_gotoworkpermit";
        public const string GotoAHV = "dobnyc_gotoahv";
        public const string GotoAHVFeeExempt = "dobnyc_gotoahvfeeexempt";
        public const string GotoEN2 = "dobnyc_gotoen2";
        public const string GotoSpecialInspection = "dobnyc_gotospecialinspection";
        public const string GotoProgressInspection = "dobnyc_gotoprogressinspection";
        public const string Documentfor = "dobnyc_documentfor";
        public const string CreatedDueto = "dobnyc_createddueto";
        public const string DocumentStatus = "dobnyc_documentstatus";
        public const string PlanExaminerDocumentsid = "dobnyc_taskdocumentsid";
        public const string ChiefPlanExaminerDocumentsid = "dobnyc_chiefplanexaminerdocumentsid";
        public const string QADocumentsid = "dobnyc_qadocumentsid";
        public const string PriortoStatus = "dobnyc_documentlist_priortostatus";
        public const string PriortoStage = "dobnyc_priortostage";
        public const string DocumentCategory = "dobnyc_documentcategory";
        public const string GotoWithdrawalRequest = "dobnyc_gotowithdrawalrequest";
        public const string GotoSupersedingRequest = "dobnyc_gotosupersedingrequest";
        public const string DocumentURL = "dobnyc_documenturl";
        public const string ParentDocumentList = "dobnyc_parentdocument";
        public const string ManuallySelected = "dobnyc_manuallyselected";
        public const string RejectionReason = "dobnyc_rejectionreason";
        public const string UploadedDate = "dobnyc_dateuploaded";
        public const string DocumentSource = "dobnyc_documentsource";
        public const string AllowWaiver = "dobnyc_allowwaiver";
        public const string AllowDeferral = "dobnyc_allowdeferral";
        public const string DocumentListId = "dobnyc_documentlistid";
        public const string DocumentClass = "dobnyc_dl_documentclass";
        public const string IsSubmitted = "dobnyc_issubmitted";
        public const string WaiverRequested = "dobnyc_waiverrequested";
        public const string DeferralRequested = "dobnyc_deferralrequested";
        public const string WaiverRejectCounter = "dobnyc_waiverrejectcounter";
        public const string DeferralRejectCounter = "dobnyc_deferralrejectcounter";
        public const string Comments = "dobnyc_comments";
        public const string AnyWaiverRequest = "dobnyc_anywaiverrequest";
        public const string AnyDeferralRequest = "dobnyc_anydeferralrequest";
        public const string OverrideWaiverSwitch = "dobnyc_disableoverridewaiver";
        public const string OverrideWaiverComments = "dobnyc_overridewaivercomments";
        //Multiple Stakeholder Changes: Start
        public const string SecondPlanExaminerDocuments = "dobnyc_ms_spedocument";
        public const string PlanExaminerDocumentsRelationshipName = "dobnyc_task_dobnyc_documentlist";
        public const string DocumentUploadNote = "dobnyc_documentuploadnote";
        public const string CentralAssignerDocumentsId = "dobnyc_centralassignerdocumentsid";
        //Multiple Stakeholder Changes: End
        public const string GoToTR2TechReports = "dobnyc_st_gototr2technicalreports";
        public const string GoToL2Request = "dobnyc_l2_gotol2request";
        public const string GoToTR3TechReports ="dobnyc_dl_gototechnicalreport";
    }

    public sealed class DocumentTypeEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_documenttypes";
        public const string DocumentName = "dobnyc_name";
        public const string RequiredItemNumber = "dobnyc_requireditemnumber";
        public const string RequiredItemStatus = "dobnyc_requireditemstatus";
        public const string RequiredItemTypes = "dobnyc_requireditemtypes";
        public const string PriortoStage = "dobnyc_priortostage";
        public const string ProgramTriggers = "dobnyc_programtriggers";
        public const string DocumentTypestoDocumentListRelationshipName = "dobnyc_dobnyc_documenttypes_dobnyc_documentlist_DocumentNameDocumentList";
        public const string DocumentTypestoDocumentsRequiredConfigurationsRelationshipName = "dobnyc_dobnyc_documenttypes_dobnyc_documentsrequiredconfigurations_DocumentType_Config";
        public const string PriortoStatus = "dobnyc_priortostatus";
        public const string AllowWaiver = "dobnyc_allowwaiver";
        public const string AllowDeferral = "dobnyc_allowdeferral";
        public const string DocumentClass = "dobnyc_dt_documentclass";
        public const string RequiredforWorkTypes = "dobnyc_dt_requiredforworktypes";
        public const string PortalDocumentDescription = "dobnyc_documentdescription";
    }

    public sealed class DocumentsRequiredConfigurationsEntityAttibuteName
    {
        public const string EntityLogicalName = "dobnyc_documentsrequiredconfigurations";
        public const string ConfigurationName = "dobnyc_name";
        public const string DocumentType = "dobnyc_documenttype_config";
        public const string SecondDocumentType = "dobnyc_seconddocumenttype";
        public const string ThirdDocumentType = "dobnyc_thirddocumenttype";
        public const string FieldMapping = "dobnyc_fieldmapping_docconfig";
        public const string FieldType = "dobnyc_fieldtype_docconfig";
        public const string EntitySchema = "dobnyc_entityschema_docconfig";
        public const string FieldValue = "dobnyc_fieldvalue_docconfig";
        public const string OtherfieldMappings = "dobnyc_otherfieldmappings";
        public const string StatusCode = "statuscode";
        public const string DocumentRequirement = "dobnyc_documentrequirement";
        public const string ConditionalXML = "dobnyc_conditionalxml";

    }

    public sealed class AssociatedWorkTypesEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_worktype";
        public const string Name = "dobnyc_name";
        public const string WorkTypeStandard = "dobnyc_worktype";  // Lookup
        public const string WorkTypeStatus = "dobnyc_worktypestatus";  // Filing Status Global
        public const string GotoJobFiling = "dobnyc_awt_gotojobfiling";  // Lookup
        public const string AssociateWorkTypeId = "dobnyc_worktypeid";
        public const string WithdrawalRequestId = "dobnyc_associatedworktypeidid";

    }

    public sealed class StandardWorkTypesEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_standardworktypes";
        public const string Name = "dobnyc_name";
        public const string ConfigurationName = "dobnyc_wt_configurationname";

    }

    public sealed class FieldType
    {
        public const string OptionSet = "Option Set";
        public const string SingleLineofText = "Single Line of Text";
        public const string TwoOptions = "Two Options";
        public const string Image = "Image";
        public const string WholeNumber = " Whole Number";
        public const string FloatingPointNumber = "Floating Point Number";
        public const string DecimalNumber = "Decimal Number";
        public const string Currency = "Currency";
        public const string MultipleLineofText = "Multiple Line of Text";
        public const string DateandTime = "Date and Time";
        public const string Lookup = "Lookup";
        public const string Text = "Text";

    }


    public sealed class JobAutoNumberEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_autonumberentity";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string JobNumberCounterAttribute = "dobnyc_jobnumbercounter";
        public const string JobNumberPaddingAttribute = "dobnyc_jobnumberpadding";
        public const string FilingNumberCounterAttribute = "dobnyc_filingnumbercounter";
        public const string PaddingCharacterAttribute = "dobnyc_paddingcharacter";
        public const string FiscalYear = "dobnyc_fiscalyear";
        public const string AdminCenterNo = "dobnyc_admincenter";
        public const string AcrafSequenceNumber = "dobnyc_acrafsequencenumber";
        public const string InvoiceSequenceNumber = "dobnyc_invoicesequencenumber";
        public const string WithdrawalCounter = "dobnyc_withdrawalcounter";
        public const string WithdrawalPadingNumber = "dobnyc_withdrawalpadingnumber";
        public const string WithdrawalPadingCharacter = "dobnyc_withdrawalpadingcharacter";
        public const string SupersedingCounter = "dobnyc_supersedingcounter";
        public const string SupersedingPaddingChar = "dobnyc_supersedingpaddingchar";
        public const string SupersedingPaddingNumber = "dobnyc_supersedingpaddingnumber";
        public const string LockRecordAttribute = "dobnyc_lockrecord";

    }
    public sealed class AnnotationEntityAttributeNames
    {
        public const string ObjectIdFieldName = "objectid";
        public const string NoteTextFieldName = "notetext";
        public const string IsDocumentFieldName = "isdocument";
        public const string SubjectFieldName = "subject";
        public const string FileNameFieldName = "filename";
        public const string DocumentBodyFieldName = "documentbody";
        public const string MimeTypeFieldName = "mimetype";
        public const string ObjectTypeCodeFieldName = "objecttypecode";

        public const string AnnotationId = "annotationid";
        public const string ObjectTypeCode = "objecttypecode";
        public const string Subject = "subject";
        public const string CreatedBy = "createdby";
        public const string CreatedOn = "createdon";
        public const string FileName = "filename";
        public const string DocumentBody = "documentbody";
        public const string MimeType = "mimetype";
    }

    public sealed class ActivityEntityEntityAttributeNames
    {
        public const string ActivityIdAttributeName = "activityid";
        public const string RegardingObjectIdAttributeName = "regardingobjectid";
        public const string Status = "statuscode";
        public const string OwnerIdFieldName = "ownerid";
        public const string ModifiedOnFieldName = "modifiedon";
        public const string SubjectFieldName = "subject";
        public const string StateCodeFieldName = "statecode";
        public const string ActivityTypeCodeFieldName = "activitytypecode";
    }



    public sealed class TaskEntityAttributeNames
    {
        public const string EntityLogicalName = "task";
        public const string CurrentFilingStatus = "dobnyc_current";
        public const string RegardingObjectId = "regardingobjectid";
        public const string PlanExaminerObjections = "dobnyc_taskobjectionsid";
        public const string CheifPlanExaminerObjections = "dobnyc_chiefplanexaminerobjectionsid";
        public const string CheifPlanExaminerObjectionsRelationShipName = "dobnyc_task_dobnyc_objectionsCPE";
        public const string PlanExaminerObjectionsRelationShipName = "dobnyc_task_dobnyc_objections";
        public const string PlanExaminerDocumentsRelationShipName = "dobnyc_task_dobnyc_documentlist";
        public const string ChiefPlanExaminerDocumentsRelationShipName = "dobnyc_task_dobnyc_documentlistCPE";
        public const string QADocumentsRelationShipName = "dobnyc_task_dobnyc_documentlistQA";
        public const string ProfCertQADocumentsRelationShipName = "dobnyc_task_dobnyc_documentlistProfQA";
        public const string QAJobFilingRelationShipName = "dobnyc_task_dobnyc_jobfiling_CurrentTask";
        public const string QAWorkPermitsRelationShipName = "dobnyc_task_dobnyc_workpermit";
        public const string ModifiedOn = "modifiedon";
        public const string StatusFieldName = "statecode";
        public const string StatusReasonFieldName = "statuscode";
        public const string ReviewAction = "dobnyc_reviewactions";
        public const string IsJobApplicationApproved = "dobnyc_isjobapplicationapproved";
        public const string WithdrawStatus = "dobnyc_task_withdrawstatus";
        public const string ClickheretogotoJobFiling = "dobnyc_task_clickheretogotojobfiling";
        public const string SupersedingRequestStatus = "dobnyc_task_supersedingrequeststatus";
        public const string ClickheretogotoWorkPermit = "dobnyc_task_clickheretogotoworkpermit";
        public const string ClickheretogotoSupersedingRequest = "dobnyc_task_clickheretogotosupersedingrequest";
        public const string ClickheretogotoWithdrawalRequest = "dobnyc_task_clickheretogotowithdrawalrequest";
        public const string WorkPermitStatus = "dobnyc_task_workpermitstatus";
        public const string IsLOCTaskForm = "dobnyc_isloctaskform"; //boolean
        public const string JobNumber = "dobnyc_task_jobnumber";
        public const string IsSupersedingRequestmade = "dobnyc_task_issupersedingrequestmade";
        public const string SupersedingRequestfor = "dobnyc_task_supersedingrequestfor";
        public const string IsWorkPermitAvailable = "dobnyc_task_isworkpermitavailable";
        public const string QADecision = "dobnyc_qadecision";
        public const string Subject = "subject";
        public const string TaskForm = "dobnyc_task_taskform";
        public const string OwnerId = "ownerid";
        public const string FilingNumber = "dobnyc_task_filingnumber";
        public const string PropertyProfile = "dobnyc_task_propertyprofile";
        public const string Address = "dobnyc_task_address";
        //Multiple Stakeholder Changes: Start
        public const string IsSecondaryPETaskForm = "dobnyc_ms_issecondarypetaskform";
        public const string SPEActions = "dobnyc_ms_secondaryplanexamineractions";
        public const string SecondaryPlanExaminerObjections = "dobnyc_ms_secondaryplanexaminerobjectionid";
        public const string SecondaryPlanExaminerObjectionsRelationShipName = "dobnyc_task_dobnyc_objections_MS_SecondaryPlanExaminerObjectionId";
        public const string IsMultiStakesForm = "dobnyc_ms_ismultistakesform";
        public const string CentralAssignerDocumentsId = "dobnyc_centralassignerdocumentsid";
        public const string CentralAssignerDocumentsRelationShipName = "dobnyc_task_dobnyc_documentlistCA";
        public const string SPEDocumentsRelationShipName = "dobnyc_task_dobnyc_documentlist_MS_SPEDocument";
        public const string PrimaryPlanExaminer = "dobnyc_ms_primaryplanexaminer";
        public const string SecondaryPlanExaminer = "dobnyc_ms_secondaryplanexaminer";
        public const string ActivityIdAttributeName = "activityid";
        //Multiple Stakeholder Changes: End
        public const string GoToTR2TechReports = "dobnyc_st_gototr2technicalreports";
        public const string TR2TechReportsDocumentsRelationShipName = "dobnyc_task_dobnyc_documentlist_tr2docs";
        public const string L2PEActions = "dobnyc_l2_peactions";
        public const string IsL2RequestTask = "dobnyc_l2_isl2requesttask";
        public const string GoToL2Request = "dobnyc_l2_gotol2request";

    }

    public sealed class ObjectionsEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_objections";
        public const string ChiefPlanExaminerObjectionsId = "dobnyc_chiefplanexaminerobjectionsid";
        public const string PlanExaminerObjectionsId = "dobnyc_taskobjectionsid";
        public const string JobFilingObjectionsId = "dobnyc_objectionstojobfilingid";
        public const string EntityIdAttributeName = "dobnyc_objectionsid";
        public const string ApprovedObjection = "dobnyc_approvedobjection";
        //Multiple Stakeholder Changes: Start
        public const string SecondPlanExaminerObjections = "dobnyc_ms_secondaryplanexaminerobjectionid";
        public const string Objectionstatus = "dobnyc_task_objectionstatus";
        //Multiple Stakeholder Changes: End
    }

    public sealed class AppointmentEntityAttributeNames
    {
        public const string OwnerIdFieldName = "ownerid";
        public const string ModifiedOnFieldName = "modifiedon";
    }

    public sealed class TeamMembershipEntityAttributeNames
    {
        public const string TeamId = "teamid";
        public const string SystemUserId = "systemuserid";
    }
    public sealed class SystemUserEntityAttributeNames
    {
        public const string SystemUserIdFieldName = "systemuserid";
        public const string EntityLogicalName = "systemuser";
        public const string FullNameFieldName = "fullname";
        public const string IsDisabledFieldName = "isdisabled";
        public const string EmployeeIdFieldName = "employeeid";
        public const string BusinessUnitFieldName = "businessunitid";
        public const string ParentUserIdFieldName = "parentsystemuserid";
        public const string FirstNameFieldName = "firstname";
        public const string LastNameFieldName = "lastname";
        public const string DomainNameFieldName = "domainname";
        public const string ModifiedOnFieldName = "modifiedon";
        public const string InternalEmail = "internalemailaddress";
        public const string PersonalEmail = "personalemailaddress";
        public const string MobileAlertEmail = "mobilealertemail";
        public const string Tel1 = "address1_telephone1";
        public const string Tel2 = "address1_telephone2";
        public const string HomePhone = "homephone";
        public const string MobilePhone = "mobilephone";
        public const string Fax = "address1_fax";
        public const string IsOutofOffice = "vrp_isoutofoffice";
        public const string DelegateUser = "vrp_delegateuserid";
        public const string Branch = "vrp_branchid";
    }

    public sealed class FeeCalculationConfigurationAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_feecalculationconfigur";
        public const string LegalizationFeeMul = "dobnyc_legalizationfeemultiplier";
        public const string LegalizationMinFee = "dobnyc_legalizationminfee";
        public const string LegalizationMaxFee = "dobnyc_legalizationmaxfee";
        public const string PaaFee = "dobnyc_paafee";
        public const string PermitRenewalFee = "dobnyc_permitrenewalfee";
        public const string RecordManagementFee = "dobnyc_recordmanagementfees";
        public const string Tier1CostFee = "dobnyc_tieronecost";
        public const string Tier2CostFee = "dobnyc_tiertwocost";
        public const string CalculationName = "dobnyc_name";
        public const string MinFilingFee = "dobnyc_minimumfilingfee";
        public const string CheckBounce = "dobnyc_checkbouncefee";
        public const string Days13 = "dobnyc_daysonethree";
        public const string Days46 = "dobnyc_daysfoursix";
        public const string Days79 = "dobnyc_dayssevennine";
        public const string Days1012 = "dobnyc_daystentwelve";
        public const string Days1314 = "dobnyc_daysthirteenfourteen";
        public const string DailyFee = "dobnyc_dailyfee";
        public const string Id = "dobnyc_feecalculationconfigurid";
        //Used for querying the AHV formule from the FeeCalcConfiguration Entity 
        public const string AHVFormulaeName = "After Hour variance";
        public const string InConjunctionJobFee = "dobnyc_inconjunctionfee";
        //GCMH based Fields
        public const string BuildingType = "dobnyc_buildingtype";
        public const string BuildingMinStories = "dobnyc_gc_minimumstories";
        public const string BuildingMaxStories = "dobnyc_gc_maximumstories";
        public const string BuildingMinSqFeet = "dobnyc_gc_minsqfeet";
        public const string BuildingMaxSqFeet = "dobnyc_gc_maximumbuildingsquarefeet";
        public const string SubsequentFee = "dobnyc_subsequentfee";
        public const string MinEstFeeCostException = "dobnyc_minimumestimatedcostexception";
    }

    public sealed class TransactionCodeAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_transactioncode";
        public const string BudgetCode = "dobnyc_budgetcode";
        public const string ReportCategory = "dobnyc_reportcategory";
        public const string RevenueSource = "dobnyc_revenuesource";
        public const string SubSource = "dobnyc_subsource";
        public const string TransactionText = "dobnyc_name";
        public const string TransCode = "dobnyc_transcode";
        public const string TransType = "dobnyc_transtype";
        public const string Id = "dobnyc_transactioncodeid";
        public const string FeeSchemaName = "dobnyc_feeschemaname";
        public const string IsLegalizationFee = "dobnyc_islegalizationfee";
        public const string ItemizedFeeType = "dobnyc_transactiontext";
    }

    public sealed class COCAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_certificateofcompliance";

        public const string isFiled = "dobnyc_cocahs_iscocfiled";
        public const string Bin = "dobnyc_cocahs_bin";
        public const string Name = "dobnyc_name";
        public const string GotoJobFiling = "dobnyc_cochs_jobfilingid";
    }




    public sealed class ZoningCharactersticsPW1AttributeNames
    {
        public const string EntityLogicalName = "dobnyc_gc_zoningcharacteristicspw1";
        public const string ZoningCharactersticsId = "dobnyc_gc_zoningcharacteristicspw1id"; // Primary key
        public const string BuildingType = "dobnyc_buildingtype";
        public const string JobFilingGuid = "dobnyc_gc_gotojobfilng";
        public const string IsTR3Required = "dobnyc_st_istr3required";
        public const string IsTR2Required = "dobnyc_st_istr2required";
        public const string IsTR2TR3Exists = "dobnyc_istr2tr3exist";
        public const string PrimaryStructuralSystem = "dobnyc_gc_primarystructuralsystem";
        public const string StructuralOccupancyRiskCat = "dobnyc_gc_structuraloccupancyriskcat";
        public const string ProposedStructuralOccupancyRiskCat = "dobnyc_gc_proposedstructuraloccupancyriskcat";
        public const string SeismicDesignCat = "dobnyc_gc_seismicdesigncat";
        public const string ProposedSeismicDesignCategory = "dobnyc_gc_proposedseismicdesigncategory";
        public const string Doesthe2014Codedesignationsapply	="dobnyc_gc_doesthe2014codedesignationsapply";
        public const string ExistingOccupancyClassification = "dobnyc_gc_existingoccupancyclassification";
        public const string ProposedOccupancyClassification = "dobnyc_gc_proposedoccupancyclassification";
        public const string Doesthe2014CodedesignationsapplyforCC = "dobnyc_doesthe2014codedesignationsapplyforcc";
        public const string ExistingConstructionClassification = "dobnyc_st_existingconstructionclassification";
        public const string ProposedConstructionClassification = "dobnyc_st_proposedconstructionclassification";
        public const string MultipleDwellingClassification = "dobnyc_st_multipledwellingclassification";
        public const string Mixedusebuilding = "dobnyc_mixedusebuilding";
        public const string ProposedBuildingFootprint = "dobnyc_proposedbuildingfootprint";
        public const string ExistingBuildingFootprint = "dobnyc_existingbuildingfootprint";

        public const string ExistingDwellingUnits = "dobnyc_existingdwellingunits";
        public const string ProposedDwellingUnits = "dobnyc_proposeddwellingunits";
        public const string IsbuildingErrected = "dobnyc_gc_isbuildingerrected";
        public const string EarliestCodeBuildiing = "dobnyc_gc_earliestcodebuildiing";
        public const string NumberofStoriesajdbuld = "dobnyc_gc_numberofstoriesajdbuld";
        public const string Isproposedconstlotline = "dobnyc_gc_isproposedconstlotline";
        public const string Heightoftallestbuld = "dobnyc_gc_heightoftallestbuld";
        public const string Isrequiresexcavation = "dobnyc_gc_isrequiresexcavation";

        public const string Exisitingbuildingstories = "dobnyc_exisitingbuildingstories";
        public const string Proposeebuildingstoriesft = "dobnyc_proposeebuildingstoriesft";
        public const string Buildingtype = "dobnyc_buildingtype";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }

    public sealed class FeeCalculationTransactionCodeIntersect
    {
        public const string EntityLogicalName = "dobnyc_feecalculationconfigur_transcode";

    }

    public sealed class TransactionHistoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_transactionhistory";
        public const string TransactionHistoryId = "dobnyc_transactionhistoryid";
        public const string BudgetCode = "dobnyc_budgetcode";
        public const string ReportCategory = "dobnyc_reportcategory";
        public const string RevenueSource = "dobnyc_revenuesource";
        public const string SubSource = "dobnyc_subsource";
        public const string TransactionText = "dobnyc_name";
        public const string TransCode = "dobnyc_transactioncode";
        //public const string TransCodeLookup = "dobnyc_th_transactioncode";
        public const string TransType = "dobnyc_transactiontype";
        public const string JobNumber = "dobnyc_jobnumber";
        public const string Fees = "dobnyc_fees";
        public const string Id = "dobnyc_transactionhistoryid";
        public const string JobfilingLookup = "dobnyc_jobfilinglookup";
        public const string TransactionCodeId = "dobnyc_th_transactioncode";
        public const string PaymentInvoice = "dobnyc_transactionid";
        //public const string ItemizedFeeType = "dobnyc_itemizedfeetype";


    }


    public sealed class EODAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_eodfile";
        public const string Name = "dobnyc_name";
        public const string FrontEndRecordId = "dobnyc_frontendrecordid";
        public const string EcheckReturnFlag = "dobnyc_echeckreturnflag";
        public const string JobFilingLookup = "dobnyc_jobfilingrecord";
        public const string WorkPermitLookup = "dobnyc_workpermitlookup";
        public const string AHVLookup = "dobnyc_ahvlookup";
        public const string OP49Lookup = "dobnyc_op49lookup";
        public const string MerchantAmount = "dobnyc_merchantamount";
    }

    public sealed class PaymentHistoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_paymenthistory";
        public const string JobNumber = "dobnyc_jobnumber";
        public const string PaymentHistTransHistRelationShipName = "dobnyc_dobnyc_paymenthistory_dobnyc_transactionh";
        public const string JobfilingLookup = "dobnyc_jobfilinglookup";
        public const string PaymentHistoryId = "dobnyc_paymenthistoryid";
        public const string IsPosted = "dobnyc_isposted";
        public const string InvoiceNumber = "dobnyc_invoicenumber";
        public const string FeeType = "dobnyc_feetype";
        public const string TotalFees = "dobnyc_totalfee";
        public const string MerchantAmount = "dobnyc_merchantamount";
        public const string AcrafNumber = "dobnyc_acrafnumber";
        public const string LicenseType = "dobnyc_licensetype";
        public const string EntityNameAttribute = "dobnyc_jobnumber";
        public const string ParentJobFilng = "dobnyc_parentjobfiling";
        public const string Amountpaid = "dobnyc_amountpaid";
        public const string NoGoodCheckFlag = "dobnyc_nogoodcheckflag";
        public const string SourceChannel = "dobnyc_sourcechannel";
        public const string BuildingType = "dobnyc_buildingtype";
        public const string EstimatedJobCost = "dobnyc_estimatedjobcost";
        public const string IsRefundCleared = "dobnyc_isrefundcleared";
        public const string ElectricalLookUp = "dobnyc_ed16a";
        public const string CreateUpdatePH = "CreateUpdatePH";
        public const string GoToPw2 = "dobnyc_gotoworkpermitpw2";
        public const string GoToOP49 = "dobnyc_gotoop49";
        public const string GoToAHV = "dobnyc_gotoahv";
        public const string NoGoodCheckPH = "dobnyc_nogoodcheckph";




    }


    public sealed class PW5AfterHoursAttributeNames  // Still is being Used by the AHV Fee Plugin
    {
        public const string EntityLogicalName = "dobnyc_afterhourvariancepw5";
        public const string NumberOfDays = "dobnyc_totalnumberofdaysrequested";
        public const string StatusCode = "statuscode";
        public const string RelatedWorkPermit = "dobnyc_ahv_clickheretogotoworkpermit";
        public const string AHVPermitStatus = "dobnyc_ahvpermitstatus";
        public const string AHVFilingFeeAttributeName = "dobnyc_ahvfilingfee";
        public const string AHVDailyFeeAttributeName = "dobnyc_ahvdailyfee";
        public const string AHVTotalFeeAttributeName = "dobnyc_totalfee";
        public const string AmountDue = "dobnyc_amountdue";
        public const string AmountPaid = "dobnyc_amountpaid";
        public const string TransactionHistoryGuid = "dobnyc_thguid";
        public const string PaymentHistoryGuid = "dobnyc_phguid";
        public const string License = "dobnyc_license";
        public const string JobFilingLookUp = "dobnyc_jobfiling";
        public const string ElectricalLookUp = "dobnyc_ed16ainformation";
        public const string IsFeeExempt = "dobnyc_isahvapplicationfeeexempt";
        public const string AhvRefundAmount = "dobnyc_ahvrefundamount";
        public const string IsSubmitted = "dobnyc_ahv_issubmitted";
        public const string AHVname = "dobnyc_name";
        public const string NoGoodCheckFee = "dobnyc_nogoodcheckfee";
        public const string RevertFromNGC = "dobnyc_revertedfromnogoodcheckahvstatus";
        public const string TypeofPermit = "dobnyc_typeofpermit";
        public const string NumberofDaysInspectorReq = "dobnyc_ahvcn_howmanydaysthedobinspectorrequired";
        public const string CraneNotice = "dobnyc_ahvcn_cnnumber";
    }

    public sealed class AfterHourVarianceAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_afterhourvariancepw5";
        public const string AHVPermitNumber = "dobnyc_name";
        public const string AHVPermitStatus = "dobnyc_ahvpermitstatus";
        public const string ClickheretogotoWorkPermit = "dobnyc_ahv_clickheretogotoworkpermit";
        public const string Borough = "dobnyc_borough";
        public const string IsSubmitted = "dobnyc_ahv_issubmitted";
        public const string JobFiling = "dobnyc_jobfiling";
        public const string VarianceType = "dobnyc_variancetype";
        public const string AllowRenewal = "dobnyc_ahv_allowrenewal";
        public const string IsFeeExempt = "dobnyc_isahvapplicationfeeexempt";
    }
    public sealed class AfterHourVarianceFeeExemptAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_afterhourvariancepw5";
        public const string IsAHVapplicationfeeexempt = "dobnyc_isahvapplicationfeeexempt";
        public const string FeeExemptDocuments = "dobnyc_acceptablefeeexemptdocuments";
        public const string FeeExemptLetterType = "dobnyc_governmentcityownedfeeexemptionletter";
        public const string AHVPermitNumber = "dobnyc_name";


    }

    public sealed class PropertyProfileAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_propertyprofile";
        public const string EntityNameField = "dobnyc_name";
        public const string dobnyc_AdditionalBINsforBuilding = "dobnyc_additionalbinsforBuilding";
        public const string dobnyc_Borough = "dobnyc_borough";
        public const string dobnyc_BuildingsonLot = "dobnyc_buildingsonlot";
        public const string dobnyc_CensusTract = "dobnyc_censustract";
        public const string dobnyc_CityOwned = "dobnyc_cityOwned";
        public const string dobnyc_CommunityBoard = "dobnyc_communityBoard";
        public const string dobnyc_Condo = "dobnyc_condo";
        public const string dobnyc_CrossStreet1 = "dobnyc_crossStreet1";
        public const string dobnyc_CrossStreet1Numbers = "dobnyc_CrossStreet1Numbers";
        public const string dobnyc_CrossStreet2 = "dobnyc_CrossStreet2";
        public const string dobnyc_CrossStreet2Numbers = "dobnyc_CrossStreet2Numbers";
        public const string dobnyc_CrossStreet3 = "dobnyc_CrossStreet3";
        public const string dobnyc_CrossStreet3Numbers = "dobnyc_CrossStreet3Numbers";
        public const string dobnyc_CrossStreet4 = "dobnyc_CrossStreet4";
        public const string dobnyc_CrossStreet4Numbers = "dobnyc_CrossStreet4Numbers";
        public const string dobnyc_CrossStreets = "dobnyc_CrossStreets";
        public const string dobnyc_DOBBuildingRemarks = "dobnyc_DOBBuildingRemarks";
        public const string dobnyc_DOBSpecialPlaceName = "dobnyc_DOBSpecialPlaceName";
        public const string dobnyc_EnvironmentalRestrictions = "dobnyc_EnvironmentalRestrictions";
        public const string dobnyc_GrandfatheredSign = "dobnyc_GrandfatheredSign";
        public const string dobnyc_HealthArea = "dobnyc_HealthArea";
        public const string dobnyc_HouseNo = "dobnyc_HouseNo";
        public const string dobnyc_LandmarkStatus = "dobnyc_LandmarkStatus";
        public const string dobnyc_LegalAdultUse = "dobnyc_LegalAdultUse";
        public const string dobnyc_LocalLaw = "dobnyc_LocalLaw";
        public const string dobnyc_LoftLaw = "dobnyc_LoftLaw";
        public const string dobnyc_SpecialDistrict = "dobnyc_SpecialDistrict";
        public const string dobnyc_SpecialStatus = "dobnyc_SpecialStatus";
        public const string dobnyc_SRORestricted = "dobnyc_SRORestricted";
        public const string dobnyc_Street = "dobnyc_Street";
        public const string dobnyc_StreetName = "dobnyc_StreetName";
        public const string dobnyc_StreetNumbers = "dobnyc_StreetNumbers";
        public const string dobnyc_TARestricted = "dobnyc_TARestricted";
        public const string dobnyc_TaxBlock = "dobnyc_TaxBlock";
        public const string dobnyc_TaxLot = "dobnyc_TaxLot";
        public const string dobnyc_UBRestricted = "dobnyc_UBRestricted";
        public const string dobnyc_Vacant = "dobnyc_Vacant";
        public const string dobnyc_Zip = "dobnyc_Zip";
        public const string dobnyc_JobFilingRecord_PP = "dobnyc_JobFilingRecord_PP";
        public const string Latitude = "dobnyc_latitude";
        public const string Longitude = "dobnyc_longitude";
        public const string SpecialArea1 = "dobnyc_specialarea1";
        public const string SpecialArea2 = "dobnyc_specialarea2";
        public const string SpecialArea3 = "dobnyc_specialarea3";
        public const string SpecialArea4 = "dobnyc_specialarea4";
        public const string SpecialArea5 = "dobnyc_specialarea5";
        public const string TransitAuthority = "dobnyc_transitauthority";
        public const string SpecialDistrict1 = "dobnyc_specialdistrict1";
        public const string SpecialDistrict2 = "dobnyc_specialdistrict2";
        public const string LoftFlag = "dobnyc_loftflag";
        public const string TidalWetlandsMapCheck = "dobnyc_pp_tidalwetlandsmapcheck";
        public const string FreshwaterWetlandsMapCheck = "dobnyc_pp_freshwaterwetlandsmapcheck";
        public const string CoastalErosionHazardAreaMapCheck = "dobnyc_pp_coastalerosionhazardareamapcheck";
        public const string SpecialFloodHazardAreaCheck = "dobnyc_pp_specialfloodhazardareacheck";
        public const string SpecialAreaString = "dobnyc_pp_specialareastring";
        public const string CrossStreet5 = "dobnyc_pp_crossstreet5";
        public const string CrossStreet5Numbers = "dobnyc_pp_crossstreet5number";
        public const string CrossStreet6 = "dobnyc_pp_crossstreet6";
        public const string CrossStreet6Numbers = "dobnyc_pp_crossstreet6numbers";
        public const string CensusTractString = "dobnyc_pp_censustractstring";
        public const string DepartmentofFinanceBuildingClassification = "dobnyc_vlfinaoccupancy";
        public const string DHCRFlag = "dobnyc_pp_dhcrflag";


    }

    public sealed class BoroughNames
    {
        public const string Brooklyn = "brooklyn";
        public const string Manhattan = "manhattan";
        public const string Queens = "queens";
        public const string StatenIsland = "staten island";
        public const string Bronx = "bronx";

    }
    public sealed class FilingChangeSetAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_jobfilingchangeset";
        public const string NewValue = "dobnyc_newvalue";
        public const string OldValue = "dobnyc_oldvalue";
        public const string Name = "dobnyc_name";
        public const string CurrentFilingStatus = "dobnyc_currentfilingstatus"; // optionset
        public const string JobFiling = "dobnyc_jobfiling"; // lookup
        public const string EntityName = "dobnyc_entityname"; // string
        public const string Entity = "dobnyc_entity";
        public const string Field = "dobnyc_field";
        public const string signCharacterstics = "dobnyc_signcharacteristicsid";
        public const string mhScopeOfwork = "dobnyc_jct_mhscopeofwork";
        public const string BoilerBuildDevice = "dobnyc_jct_boilerbuilddevice";
        public const string BoilerScopeofwork = "dobnyc_boilerscopeofwork";
    }

    public sealed class SourceChannel
    {
        public const string CRM = "CRM";
        public static string PaymentIntegrationName = "PAYMENTINTERGRATION";
        public static string ServicesWrapper = "ServicesWrapper";
    }

    public sealed class WorkCostDetailsAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_categoriesofworkdetail";
        public const string WorkCostDetailsId = "dobnyc_categoriesofworkdetailid"; // Primary key
        public const string WorkCategory = "dobnyc_workcategory";// optionset
        public const string WorkScope = "dobnyc_workscope";// optionset
        public const string DescriptionofWork = "dobnyc_descriptionofwork";// string
        public const string UnitCost = "dobnyc_unitcost"; //currency
        public const string AreaUnits = "dobnyc_areaunits_num";// wholenumber
        public const string TotalCost = "dobnyc_totalcost"; //currency
        public const string Name = "dobnyc_name"; // string
        public const string GoToJobFiling = "dobnyc_categoriesofworkid"; //lookup
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";//two options


    }
    public sealed class SpecialInspectionCategoriesAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_specialinspectioncategories";
        public const string SpecialInspectionCategoriesId = "dobnyc_specialinspectioncategoriesid"; // Primary Key
        public const string AddRequirement = "dobnyc_specialinspections"; // lookup inspection components
        public const string FilingScope = "dobnyc_filingscope"; //optionset
        public const string SpecialInspector = "dobnyc_specialinspector"; //lookup contact
        public const string ResponsibilityofIdentifingRequirement = "dobnyc_responsibilityofidentifingrequirement";// two options
        public const string ICertifyCompleteInspectionsTests = "dobnyc_icertifycompleteinspectionstests";  //two options
        public const string IWithdrawResponsibility = "dobnyc_iwithdrawresponsibility"; //two options
        public const string DateForIdentificationofResponsibility = "dobnyc_dateforidentificationofresponsibility"; //DateTime
        public const string DateForCertifyCompleteInspections = "dobnyc_dateforcertifycompleteinspections"; //DateTime
        public const string DateForWithdrawResposibility = "dobnyc_dateforwithdrawresposibility"; //DateTime
        public const string GoToJobFiling = "dobnyc_jobfilingtospecialinspectionscaid"; //lookup
        public const string CodeSection = "dobnyc_name"; //string
        public const string SpecialInspectoinRelationid = "dobnyc_specialinspectioncatagoryrelatiid";
        public const string SpecialInspectoinRelation_Withdrawalid = "dobnyc_specialinspectionrelationid";
        public const string Withdrawn = "dobnyc_specialinps_withdrawn";
        public const string Superseded = "dobnyc_specialinsp_superseded";
        public const string CreatedFrom = "dobnyc_specialinsp_createdfrom";
        public const string LicenseType = "dobnyc_licensetype";
        public const string SpecialInspectionAgencyNo = "dobnyc_specialinspectionagencynumber";
        public const string IORStatement1 = "dobnyc_iorstatement1";
        public const string FinalIOR = "dobnyc_finalior";
        public const string InspectionApplicantNameStatement = "dobnyc_inspectionapplicantname";
        public const string ResponsibleStatementDate = "dobnyc_responsiblestatementdate";
        public const string IResponsibleName = "dobnyc_iresponsiblename";
        public const string ICentifyName = "dobnyc_icentifyname";
        public const string IsCopiedfromPAA = "dobnyc_sic_iscopiedfrompaa";
        public const string CertificateOfCompletionStatement = "dobnyc_certificateofcompletionstatement"; //two options
        public const string InspectionApplicantName = "dobnyc_inspectionapplicantnamecompletionstatemen"; //Text
        public const string CompletionStatementDate = "dobnyc_completionstatementdate"; // Date
        public const string FilingType = "dobnyc_sic_filingtype";
        public const string IsAutoPopulated = "dobnyc_autopopulated";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }
    public sealed class ProgressInspectionCategoryAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_progressinspectioncategory";
        public const string ProgressInspectionCategoryId = "dobnyc_progressinspectioncategoryid"; // Primary key
        public const string AddRequirement = "dobnyc_progressinspection"; // lookup inspection components
        public const string FilingScope = "dobnyc_filingscope"; //optionset
        public const string ProgressInspector = "dobnyc_progressinspector"; //lookup contact
        public const string ResponsibilityofIdentifingRequirement = "dobnyc_progressresponsibilityidentifingrequirm";// two options
        public const string ICertifyCompleteInspectionsTests = "dobnyc_progressicertifycompleteinspections";  //two options
        public const string IWithdrawResponsibility = "dobnyc_progressiwithdrawresponsibility";
        public const string DateForIdentificationofResponsibility = "dobnyc_identificationofresponsibilitiespic"; //DateTime
        public const string DateForCertifyCompleteInspections = "dobnyc_certificateofcompleteinspectionstests"; //DateTime
        public const string DateForWithdrawResposibility = "dobnyc_withdrawresponsibilitiespic"; //DateTime
        public const string GoToJobFiling = "dobnyc_progressioninspectioncategorytoid"; //lookup
        public const string CodeSection = "dobnyc_name"; //string
        public const string InspectionType = "dobnyc_inspectiontype"; // Option Set
        public const string FilingType = "dobnyc_pic_filingtype"; // Option Set
        public const string IsCopiedfromPAA = "dobnyc_iscopiedfrompaa";
        public const string CertificateOfCompletionStatement = "dobnyc_certificateofcompletionstatement"; //two options
        public const string EnergyCodeCerificateofCompletionStattement = "dobnyc_certiofcompletionecins";
        public const string EnergyCodeCerificateofCompletionA = "dobnyc_enerycodecertiofcoma";
        public const string EnergyCodeCerificateofCompletionB = "dobnyc_enerycodecertiofcomb";

        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

        public const string IsAutoPopulated = "dobnyc_autopopulated"; //two options
    }


    public sealed class AcrafConfigurationAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_acrafconfiguration";
        public const string Name = "dobnyc_name";
        public const string CreatedOn = "createdon";
        public const string AcrafCreatedOn = "dobnyc_acrafcreatedon";


    }

    public sealed class BuildingCharacteristicsClassificationsAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_buildingcharacteristicsclassifications";
        public const string Name = "dobnyc_name";
        public const string CreatedOn = "createdon";
        public const string BuildingCharacteristicsClassifications = "dobnyc_buildingcharacteristicsclassificationsid";
        public const string ConstructionClassification = "dobnyc_dobnyc_buildingcharacteristicsclassifications_dobnyc_jobfiling_constructionclassification";
        public const string MultipleDwellingClassification = "dobnyc_dobnyc_buildingcharacteristicsclassifications_dobnyc_jobfiling_multipledwellingclassification";
        public const string OccupancyClassification = "dobnyc_dobnyc_buildingcharacteristicsclassifications_dobnyc_jobfiling_occupancyclassification";
    }

    public sealed class AcrafAutoNumberAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_acrafautonumber";
        public const string AcrafSequenceNumber = "dobnyc_acrafsequencenumber";
        public const string AcrafAdminCenter = "dobnyc_admincenter";
        public const string AcrafFiscalYear = "dobnyc_fiscalyear";
        public const string StartDate = "dobnyc_startdate";
        public const string Name = "dobnyc_name";

    }

    public sealed class GetJobFilingEntityColumnSet
    {
        public string[] ColumnNames = new string[] { JobFilingEntityAttributeName.EntityLogicalName , JobFilingEntityAttributeName.IsJobDescriptionChanged, JobFilingEntityAttributeName.HouseNumAttribute,JobFilingEntityAttributeName.StreetNameAttribute,
                        JobFilingEntityAttributeName.BoroughAttributeName, JobFilingEntityAttributeName.BlockAttributeName, JobFilingEntityAttributeName.LotAttributeName ,JobFilingEntityAttributeName.BinAttributeName,
                        JobFilingEntityAttributeName.ReviewRequestedUnderBuildingCode, JobFilingEntityAttributeName.PlumbingWorkTypeAttributeName,JobFilingEntityAttributeName.SprinklerWorkTypeAttributeName,
                        JobFilingEntityAttributeName.BuildingTypeAttribute, JobFilingEntityAttributeName.AptCondonosAttributeName, JobFilingEntityAttributeName.IsPAAinProgress,
                        JobFilingEntityAttributeName.AsbestosAbatementComplianceAttributeName , JobFilingEntityAttributeName.ApplicantPerson , JobFilingEntityAttributeName.ApplicantBusiness, JobFilingEntityAttributeName.PlanExaminerAttributeName ,
                        JobFilingEntityAttributeName.AssignedQAClerkAttributeName , JobFilingEntityAttributeName.AssignedQASupervisorAttributeName,
                        JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName, JobFilingEntityAttributeName.AdjustmentFinal,JobFilingEntityAttributeName.RecordManagementFee,
                        JobFilingEntityAttributeName.CBNoAttributeName,JobFilingEntityAttributeName.JobStatusAttributeName,JobFilingEntityAttributeName.PreviousFilingStatusAttributeName,
                        JobFilingEntityAttributeName.CodeCompliancePathAttributeName ,JobFilingEntityAttributeName.CommentsPWAttributeName,JobFilingEntityAttributeName.InConjunctionFee,JobFilingEntityAttributeName.NoGoodCheckCount,JobFilingEntityAttributeName.NoGoodCheckFee,
                        JobFilingEntityAttributeName.CompliacneWithTheNYCECCAttributeName, JobFilingEntityAttributeName.CreatedOnAttributeName,
                        JobFilingEntityAttributeName.CurrentStageAttributeName,JobFilingEntityAttributeName.DEPACPControlNoAttributeName,
                        JobFilingEntityAttributeName.ChooseTheTypeofApplicantAttributeName,JobFilingEntityAttributeName.DesignApplicant3A4_Tr8AttributeName,//JobFilingEntityAttributeName.DOBIssuedIDNoPW3AttributeName,
                        //JobFilingEntityAttributeName.DesignApplicantCostAffidavitAtrributeName,
                        JobFilingEntityAttributeName.EstimatedJobCostAttributeName,JobFilingEntityAttributeName.ExemptFromNYCECCAttributeName,JobFilingEntityAttributeName.ExisitingBuildingStoriesAttributeName,
                        JobFilingEntityAttributeName.ExisitingFireSuppressionAttributeName,JobFilingEntityAttributeName.ExisitingSprinklerAttributeName,
                        JobFilingEntityAttributeName.ExistingBuildingHeightAttributeName,JobFilingEntityAttributeName.ExistingDwellingUnitsAttributeName,
                        JobFilingEntityAttributeName.ExistingFireAlarmAttributeName,
                        JobFilingEntityAttributeName.FeeSubmittedAttributeName,JobFilingEntityAttributeName.FilingRepresentativeName,
                        JobFilingEntityAttributeName.CurrentFilingStatusAttributeName,
                        JobFilingEntityAttributeName.Jobfiling_IsafterPermitIssuedAttributeName,JobFilingEntityAttributeName.PACheckBox,JobFilingEntityAttributeName.TPACheckBox,
                        JobFilingEntityAttributeName.IsChangeLocationRequestAttributeName,JobFilingEntityAttributeName.IsInspectionStageAttributeName,
                        JobFilingEntityAttributeName.IsMinorPlanChangesAttributeName,JobFilingEntityAttributeName.IsNewWorktypeAddedAttributeName,
                        JobFilingEntityAttributeName.IsPAAbyModSec3or12AttributeName,JobFilingEntityAttributeName.IsPlanApprovedAttributeName,
                        JobFilingEntityAttributeName.IsplanRejectFirstTimeAttributeName,JobFilingEntityAttributeName.IsSignoffStageAttributeName,
                        JobFilingEntityAttributeName.IsWithdrawalRequestMadeAttributeName,JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName,
                        JobFilingEntityAttributeName.JobDescriptionAttributeName,JobFilingEntityAttributeName.JobNumberAttributeName,JobFilingEntityAttributeName.JobDescriptionLeg,
                        JobFilingEntityAttributeName.LittleEOrRdSiteAttributeName,JobFilingEntityAttributeName.MakePaymentAttributeName,
                        JobFilingEntityAttributeName.MixedUseBuildingAttributeName,//JobFilingEntityAttributeName.NameDesignApplicantStatementtr1AttributeName,
                        JobFilingEntityAttributeName.NameOnwerStatement4Inspectortr1AttributeName,JobFilingEntityAttributeName.OwnerLeaseholderAttributeName,
                        JobFilingEntityAttributeName.ParentJobFilingAttributeName,
                        JobFilingEntityAttributeName.ProfessionalCertificateAttributeName,//JobFilingEntityAttributeName.NYCeccExemptifyeSchooseOneAttributeName,
                        JobFilingEntityAttributeName.ProgressInspectionApplicant3bd56_tr8AttributeName,JobFilingEntityAttributeName.ProgressInspectionsApplicantAttributeName,
                        JobFilingEntityAttributeName.ProposedBuildingHeightAttributeName,
                        JobFilingEntityAttributeName.ProposedDWellingUnitsAttributeName,JobFilingEntityAttributeName.ProposedFireAlarmAttributeName,
                        JobFilingEntityAttributeName.ProposedFireSuppressionAttributeName,JobFilingEntityAttributeName.ProposeeBuildingStoriesftAttributeName,
                        JobFilingEntityAttributeName.ProposedSprinklerAttributeName,JobFilingEntityAttributeName.ReasonforFilingAttributeName,
                        JobFilingEntityAttributeName.RequestingLegalizationOfWorkWhereNoWorkAttributeName,
                        JobFilingEntityAttributeName.RevertedtoDPFromAttributeName,JobFilingEntityAttributeName.SpecialInspectionsApplicant3bd69AttributeName,
                        JobFilingEntityAttributeName.TaskURLAttributeName,JobFilingEntityAttributeName.TipAttributeName,
                        JobFilingEntityAttributeName.TotalConstructionFloorAreaAttributeName,JobFilingEntityAttributeName.TotalJobCostAttributeName,
                        JobFilingEntityAttributeName.TotalPlumbingCostAttributeName,JobFilingEntityAttributeName.TotalSprinklerCostAttributeName,
                        JobFilingEntityAttributeName.WorkonFloorsAttributeName,
                        JobFilingEntityAttributeName.WorkIncludesPermanentRemovalofStandpipeAttributeName,
                        JobFilingEntityAttributeName.EnergyAnalysisAttributeName,JobFilingEntityAttributeName.FilingFeesAttributeName,JobFilingEntityAttributeName.FilingTypeAttributeName,
                        JobFilingEntityAttributeName.JobFiling,JobFilingEntityAttributeName.FilingNumberAttributeName,JobFilingEntityAttributeName.StateCode,JobFilingEntityAttributeName.PlumbingWorkLegalization,
                        JobFilingEntityAttributeName.SprinklerWorkLegalization, JobFilingEntityAttributeName.PaymentHistoryGUID,JobFilingEntityAttributeName.InvoiceNumber,JobFilingEntityAttributeName.IsFeeExemptAttributename,
                        JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName,
                         JobFilingEntityAttributeName.PlanApprovedDateAttributeName, JobFilingEntityAttributeName.ZipAttributeName, JobFilingEntityAttributeName.NewWorkFilingFeeAttributeName,
                         JobFilingEntityAttributeName.LegalizationFilingFeeAttributeName,JobFilingEntityAttributeName.RecordManagementFeeAttributeName,JobFilingEntityAttributeName.PAAFeeAttributeName,
                         JobFilingEntityAttributeName.NoGoodCheckFeeFineAttributeName,JobFilingEntityAttributeName.TotalFeeAttributeName,JobFilingEntityAttributeName.AmountDueAttributeName,
                         JobFilingEntityAttributeName.AmountPaidAttributeName,JobFilingEntityAttributeName.RefundAttributeName,

                         //legal
                         JobFilingEntityAttributeName.DateDesignApplicantStatementAttributeName,JobFilingEntityAttributeName.DesignApplicantNameStatementPrintAttributeName,
                        JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedandOperatedAttributeName,JobFilingEntityAttributeName.FeeExemptionRequestNYCHAHHCNYCAgencyorOwnedOperated,
                        JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing, JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox,
                        JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished, JobFilingEntityAttributeName.BNotifiedtheNYCHomes,JobFilingEntityAttributeName.ProvideDateNYSHCRNotified,
                        JobFilingEntityAttributeName.DateOnwerStatement4InspectorTr1AttributeName,

                        JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName, JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECBAttributeName,

                        JobFilingEntityAttributeName.OwnerTypePW1Statement, JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization, JobFilingEntityAttributeName.RelationshiptoOwner,
                        JobFilingEntityAttributeName.BusinessNameandAgency, JobFilingEntityAttributeName.StreetAddress, JobFilingEntityAttributeName.CityPW1statemnt,JobFilingEntityAttributeName.StatePW1statemnt,JobFilingEntityAttributeName.FaxPW1statemnt,
                        JobFilingEntityAttributeName.ZipPW1statemnt, JobFilingEntityAttributeName.TelephoneNumberPW1statemnt, JobFilingEntityAttributeName.EmailAddressPW1statemnt,JobFilingEntityAttributeName.Date26PW1statemnt,
                        JobFilingEntityAttributeName.TitleCondoCoOpBoard,
                       JobFilingEntityAttributeName.BisRelatedJobNumber,
                        JobFilingEntityAttributeName.LicenseLookupField,

                        JobFilingEntityAttributeName.AlternateJobInBISAssociation,
                        JobFilingEntityAttributeName.AntennaWorkType,
                        JobFilingEntityAttributeName.BSACalendarNumbers,
                        JobFilingEntityAttributeName.CPCCalendarNumbers,
                        JobFilingEntityAttributeName.CRFNZoningExhibit,
                        JobFilingEntityAttributeName.CurbCutWorkType,
                        JobFilingEntityAttributeName.Directive14,
                        JobFilingEntityAttributeName.Districts,
                        JobFilingEntityAttributeName.ExtendHigherThan6Feet,
                        JobFilingEntityAttributeName.HighRiseTeamTrackingNumber,
                        JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter,
                        JobFilingEntityAttributeName.IsStructuralWorkIncluded,
                        JobFilingEntityAttributeName.MapNumber,
                        JobFilingEntityAttributeName.OccupyMoreThan5Percent,
                        JobFilingEntityAttributeName.Overlays,
                        JobFilingEntityAttributeName.ProvideBSACalendarNumbers,
                        JobFilingEntityAttributeName.ProvideCPCCalendarNumbers,
                        JobFilingEntityAttributeName.RelatedDOBJobNumbers,
                        JobFilingEntityAttributeName.SpecialDistricts,
                        JobFilingEntityAttributeName.StructuralStabilityAffected,
                        JobFilingEntityAttributeName.WorkIncludesPartialDemolition,
                        JobFilingEntityAttributeName.EstimatedNewWorkFinalCost,
                        JobFilingEntityAttributeName.GoToAntennaScopeofWork,
                        JobFilingEntityAttributeName.GoToAntennaDS1,
                        //JobFilingEntityAttributeName.GoToAntennaLOC,
                        JobFilingEntityAttributeName.GoToCurbCutQuestionnaire

                        ,JobFilingEntityAttributeName.CRFNZoningExhibitNumber1
                        ,JobFilingEntityAttributeName.CRFNZoningExhibitNumber2
                        ,JobFilingEntityAttributeName.CRFNZoningExhibitNumber3
                        ,JobFilingEntityAttributeName.CRFNZoningExhibitNumber4
                        ,JobFilingEntityAttributeName.FacadeAlternation
                        ,JobFilingEntityAttributeName.AdultEstablishment
                        ,JobFilingEntityAttributeName.QualityHousing
                        ,JobFilingEntityAttributeName.CRFNRestrictiveDeclaration
                        ,JobFilingEntityAttributeName.CRFNNumber1
                        ,JobFilingEntityAttributeName.CRFNNumber2
                        ,JobFilingEntityAttributeName.CRFNNumber3
                        ,JobFilingEntityAttributeName.CRFNNumber4

                        ,JobFilingEntityAttributeName.ComplyingToLocalLaws
                        ,JobFilingEntityAttributeName.ListOfLawNumbers
                        ,JobFilingEntityAttributeName.IsFilingtoAddressViolations
                        ,JobFilingEntityAttributeName.ListViolationsDOBECB
                        ,JobFilingEntityAttributeName.ECBNumbers

                        ,JobFilingEntityAttributeName.IsStructuralWorkIncluded
                        ,JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter
                        ,JobFilingEntityAttributeName.OccupyMoreThan5Percent
                        ,JobFilingEntityAttributeName.ExtendHigherThan6Feet
                        ,JobFilingEntityAttributeName.TotalConstructionFloorArea
                        ,JobFilingEntityAttributeName.IsConjunctionJob
                        ,JobFilingEntityAttributeName.ExemptfromtheNYCECC
                        ,JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt
                        ,JobFilingEntityAttributeName.EnergyAnalysis
                        ,JobFilingEntityAttributeName.CodeCompliancePath
                        ,JobFilingEntityAttributeName.JobDescription
                        ,JobFilingEntityAttributeName.OccupancyClassification
                        ,JobFilingEntityAttributeName.ConstructionClassification
                        ,JobFilingEntityAttributeName.MultipleDwellingClassification
                        //FAB4 Falgs,
                        ,JobFilingEntityAttributeName.ConstructionFence
                        ,JobFilingEntityAttributeName.Sign
                        ,JobFilingEntityAttributeName.SidewalkShed
                        ,JobFilingEntityAttributeName.SupportedScaffold
                        ,JobFilingEntityAttributeName.SROMultiple
                        ,JobFilingEntityAttributeName.LoftBoard
                        ,JobFilingEntityAttributeName.SiteSafetyJob
                        ,JobFilingEntityAttributeName.IncludedinLMCC
                        ,JobFilingEntityAttributeName.heightFt
                        ,JobFilingEntityAttributeName.constructionMaterial
                        ,JobFilingEntityAttributeName.SizeoftheShed
                        ,JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber
                        ,JobFilingEntityAttributeName.fenceConstructionMaterial
                        ,JobFilingEntityAttributeName.describeOther
                        ,JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe
                        ,JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe
                        ,JobFilingEntityAttributeName.LandmarkFee
                        ,JobFilingEntityAttributeName.GoToDelegates,
                        JobFilingEntityAttributeName.OwnerLeaseHolder,
                        JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization, JobFilingEntityAttributeName.PlaceOfAssemblyLookUp,  JobFilingEntityAttributeName.TPALateFees
                        ,JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.workTypesTextbox,   //PW1 Standardization
                        JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization, JobFilingEntityAttributeName.PlaceOfAssemblyLookUp,  JobFilingEntityAttributeName.TPALateFees,JobFilingEntityAttributeName.IsPAAuditInitiated,
            JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands,JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea,JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict,JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands,
            JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal,JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea,JobFilingEntityAttributeName.Yearforlocallaws
            ,JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving,JobFilingEntityAttributeName.STWorkOnInterior,JobFilingEntityAttributeName.STWorkOnExterior,JobFilingEntityAttributeName.STRemovingOneOrMoreStories
            ,JobFilingEntityAttributeName.STDemolishing50OrMore,JobFilingEntityAttributeName.STAlternativeMaterialsOTCR,JobFilingEntityAttributeName.HeatingSystem,JobFilingEntityAttributeName.VentilationSystem
            ,JobFilingEntityAttributeName.AirConditioningSystem,JobFilingEntityAttributeName.Refrigeration,JobFilingEntityAttributeName.CoolingTowers,JobFilingEntityAttributeName.AssociatedDuctsAndPiping,JobFilingEntityAttributeName.Generator
            ,JobFilingEntityAttributeName.Other,JobFilingEntityAttributeName.OtherValues, JobFilingEntityAttributeName.IsPAACreationCompleted
    };

    }

    //Antenna & Curb Cut Changes - Start
    public sealed class AntennaScopeOfWorkEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_antennascopeofwork"; //Entity Name
        public const string AntennaScopeofWorkId = "dobnyc_antennascopeofworkid"; // Primary Key
        public const string AntennastobeModifiedReplaced = "dobnyc_asw_antennastobemodifiedreplaced"; //Whole Number
        public const string AntennastobeRemoved = "dobnyc_asw_antennastoberemoved"; //Whole Number
        public const string ArraystobeModifiedReplaced = "dobnyc_asw_arraystobemodifiedreplaced"; //Whole Number
        public const string ArraystobeRemoved = "dobnyc_asw_arraystoberemoved"; //Whole Number
        public const string Bulkhead = "dobnyc_asw_bulkhead"; //Two Options
        public const string Chimney = "dobnyc_asw_chimney"; //Two Options
        public const string EmergencyPowerSystem = "dobnyc_asw_emergencypowersystem"; //Two Options
        public const string ExistingAntennas = "dobnyc_asw_existingantennas"; //Two Options
        public const string Facade = "dobnyc_asw_facade"; //Two Options
        public const string IsMechanicalWorkProposed = "dobnyc_asw_ismechanicalworkproposed"; //Two Options
        public const string MechanicalandElectricalEquipmentLocation = "dobnyc_asw_mechanicalelectricalequipmentlocation"; //String
        public const string Monopole = "dobnyc_asw_monopole"; //Two Options
        public const string NewAntennasOrArrays = "dobnyc_asw_newantennasorarrays"; //Two Options
        public const string NumberofArrays = "dobnyc_asw_numberofarrays"; //Whole Number
        public const string NumberofExistingAntennas = "dobnyc_asw_numberofexistingantennas"; //Whole Number
        public const string NumberofExistingRRH = "dobnyc_asw_numberofexistingrrh"; //Whole Number
        public const string NumberofNewAntennas = "dobnyc_numberofnewantennas"; //Whole Number
        public const string NumberofNewArrays = "dobnyc_asw_numberofnewarrays"; //Whole Number
        public const string NumberofNewRRH = "dobnyc_asw_numberofnewrrh"; //Whole Number
        public const string NumberofNewSectors = "dobnyc_asw_numberofnewsectors"; //Whole Number
        public const string NumberofSectors = "dobnyc_asw_numberofsectors"; //Whole Number
        public const string OnGrade = "dobnyc_asw_ongrade"; //Two Options
        public const string OtherStructure = "dobnyc_asw_otherstructure"; //Two Options
        public const string Parapet = "dobnyc_asw_parapet"; //Two Options
        public const string Roof = "dobnyc_asw_roof"; //Two Options
        public const string RRHtobeModifiedReplaced = "dobnyc_rrhtobemodifiedreplaced"; //Whole Number
        public const string RRHtobeRemoved = "dobnyc_asw_rrhtoberemoved"; //Whole Number
        public const string SectorstobeModifiedReplaced = "dobnyc_asw_sectorstobemodifiedreplaced"; //Whole Number
        public const string SectorstobeRemoved = "dobnyc_asw_sectorstoberemoved"; //Whole Number
        public const string TypeOfStructuralWork = "dobnyc_asw_typeofstructuralwork"; //Two Options
        public const string WaterTank = "dobnyc_asw_watertank"; //Two Options
        public const string Name = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_asw_gotojobfiling"; //lookup to Job Filing
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    public sealed class AntennaDemolitionSubmittalCertificationEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_demolitionsubmittalcertificationds1"; //Entity Name
        public const string AntennaDS1Id = "dobnyc_demolitionsubmittalcertificationds1id"; // Primary Key

        public const string DemolitionType = "dobnyc_an_demolitiontype"; //Two Options        
        public const string ExteriorWorkGeneralDescription = "dobnyc_an_exteriroworkgeneraldescription"; //String
        public const string IsSigned = "dobnyc_an_issigned"; //Two Options
        public const string NonMechanicalGeneralDescription = "dobnyc_an_nonmechanicalgeneraldescription"; //String
        public const string OtherEquipmentGeneralDescription = "dobnyc_an_otherequipmentgeneraldescription"; //String
        public const string OwnerName = "dobnyc_an_ownername"; //String
        public const string SignedDate = "dobnyc_an_signeddate"; //DateTime
        public const string SubmittalType = "dobnyc_an_submittaltype"; //Two Options
        public const string UseHandheldMechanicals = "dobnyc_an_usehandheldmechanicals"; //Two Options
        public const string UseNonmechanicalMethods = "dobnyc_an_usenonmechanicalmethods"; //Two Options
        public const string UseOtherMechanicals = "dobnyc_an_useothermechanicals"; //Two Options
        public const string WorkOnExteriors = "dobnyc_an_workonexteriors"; //Two Options
        public const string Name = "dobnyc_name";
        public const string Applicant = "dobnyc_an_applicant"; //LookUp to Contact
        public const string GoToJobFiling = "dobnyc_an_gotojobfiling"; //LookUp to Job Filing
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    public sealed class CurbCutQuestionnaireEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_curbcutquestionnaire"; //Entity Name
        public const string CurbCutQuestionnaireId = "dobnyc_curbcutquestionnaireid"; // Primary Key
        public const string Name = "dobnyc_name";
        public const string AgenciesRequiredDocument = "dobnyc_cc_agenciesrequireddocument"; //Option Set
        public const string AttachedGarage = "dobnyc_cc_attachedgarage"; //Two Options
        public const string CurbCutsidenearesttothepropertyline = "dobnyc_cc_sidenearesttopropertyline"; //Option Set
        public const string Curbcutslocatedinfronttoadjoiningproperties = "dobnyc_cc_curbcutslocatedinfronttoadjoining"; //Two Options
        public const string DetachedGarage = "dobnyc_cc_detachedgarage"; //Two Options
        public const string Distancefromnearestpropertyline = "dobnyc_cc_distancefromnearestpropertyline"; //Floating Point
        public const string Distancetonearestcorner = "dobnyc_cc_distancetonearestcorner"; //Floating Point
        public const string Isthecurbcutongrade = "dobnyc_cc_isthecurbcutongrade"; //Two Options
        public const string Isthecurbcutonotherstructure = "dobnyc_cc_isthecurbcutonotherstructure"; //Two Options
        public const string Isthecurbcutoveravault = "dobnyc_cc_isthecurbcutoveravault"; //Two Options
        public const string LoadingBerth = "dobnyc_cc_loadingberth"; //Two Options
        public const string ParkingGarage = "dobnyc_cc_parkinggarage"; //Two Options
        public const string ParkingLot = "dobnyc_cc_parkinglot"; //Two Options
        public const string ParkingPad = "dobnyc_cc_parkingpad"; //Two Options
        public const string PrivateDriveRoad = "dobnyc_cc_privatedriveroad"; //Two Options
        public const string Sideofthestreetiscurbcuton = "dobnyc_cc_sideofthestreetiscurbcuton"; //Option Set
        public const string Sidewalkobstructionstobedestroyedrelocated = "dobnyc_cc_sidewalkobstructionstobedestroyed"; //Two Options
        public const string Sidewalkobstructionswithin8ftofproposedCC = "dobnyc_cc_sidewalkobstructionswithin8ftofcc"; //Two Options
        public const string Sizeofcutwithsplays = "dobnyc_cc_sizeofcutwithsplays"; //Floating Point
        public const string Tostreet = "dobnyc_cc_tostreet"; //String

        public const string GoToJobFiling = "dobnyc_cc_gotojobfiling"; //LookUp to Job Filing
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    public sealed class LOCPW7EntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_locrequest"; //Entity Name
        public const string LOCRequestId = "dobnyc_locrequestid"; // Primary Key
        public const string Name = "dobnyc_name";
        public const string GotoJobFiling = "dobnyc_loc_gotojobfiling";
        public const string InitialFilingDate = "dobnyc_loc_initialfilingdate";
        public const string IsLOCSigned = "dobnyc_loc_islocsigned";
        public const string IsSubmitted = "dobnyc_loc_issubmitted";
        public const string LOCIssuedDate = "dobnyc_loc_locissueddate";
        public const string LOCRejectedDate = "dobnyc_loc_locrejecteddate";
        public const string LOCRequestStatus = "dobnyc_loc_locrequeststatus";
        public const string LOCSignedDate = "dobnyc_loc_locsigneddate";
        public const string QAAssignedDate = "dobnyc_loc_qaassigneddate";
        public const string RejectedFrom = "dobnyc_loc_rejectedfrom";
        public const string ResubmissionDate = "dobnyc_loc_resubmissiondate";
        public const string HasTechnicalDocuments = "dobnyc_loc_arethereanytechnicaldocuments";

        public const string Comments = "dobnyc_loc_comments";
        public const string RequesterSignature = "dobnyc_loc_requestersignature";
        public const string AssignedQAClerk = "dobnyc_loc_assignedqaclerk";
        public const string GoToLOCRequest = "dobnyc_task_gotolocrequest";
        public const string TechnicalReviewDecision = "dobnyc_task_technicalreviewdecision";
        public const string LOCRequester = "dobnyc_loc_locrequester";
        public const string RequesterLicenseType = "dobnyc_loc_requesterlicensetype";
        public const string IsEstimatedJobCostsameasFinalCost = "dobnyc_loc_isestimatedjobcostsameasfinalcost";



    }

    public sealed class WorkOnFloorEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_workonfloor"; //Entity Name
        public const string WorkOnFloorId = "dobnyc_workonfloorid"; // Primary Key
        public const string Name = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_wf_gotojobfiling";
        public const string FloorFrom = "dobnyc_an_floornumberfrom";
        public const string FloorTo = "dobnyc_an_floornumberto";
        public const string Location = "dobnyc_an_codeanddescription";
        public const string initialguid = "dobnyc_plspsdsowrelation";
    }



    //Antenna & Curb Cut Changes - End

    // Waiver & Deferral changes - Start
    public sealed class WaiverDeferralRequestEntityAttributeName
    {
        public const string EntityLogicalName = "dobnyc_waiverdeferraltaskintersect"; //Entity Name
        public const string DocumentListId = "dobnyc_documentlistid";
        public const string Type = "dobnyc_type";
        public const string TaskId = "dobnyc_taskid";
        public const string Name = "dobnyc_name";
        public const string PriorToStatus = "dobnyc_priortostatus";
        public const string Action = "dobnyc_action";
        public const string WaiverDeferralRequestId = "dobnyc_waiverdeferraltaskintersectid";
        public const string RequestorComments = "dobnyc_requestorscomments";
        public const string Role = "dobnyc_role";
        public const string DeferToStage = "dobnyc_defertostage";
        public const string Applicant = "dobnyc_applicant";
        public const string FilingOwner = "dobnyc_filingowner";
        public const string Owner = "ownerid";
        public const string WorkPermit = "dobnyc_jobfilingwp";
        public const string ActionComments = "dobnyc_comments";
        public const string PriorToStage = "dobnyc_priortostage";
        public const string ProfCert = "dobnyc_profcertfiling";
    }
    // Waiver & Deferral changes - End

    public sealed class RelatedFilngs
    {
        public const string EntityLogicalName = "dobnyc_relatedfilings";
        public const string JobNumber = "dobnyc_jobnumber";
        public const string FilingType = "dobnyc_rf_filingtype";
        public const string ED16A = "dobnyc_rf_ed16a";
        public const string ParentGUID = "dobnyc_rf_parentguid";
        public const string SchemaName = "dobnyc_rf_schemaname";
        public const string Counter = "dobnyc_rf_counter";
        public const string Name = "dobnyc_name";
        public const string JobFilingId = "dobnyc_rf_jobfilng";

    }

    public sealed class MHScopeofworkAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_mh_mechanicalscopeofwork";
        public const string MechanicalScopeofworkid = "dobnyc_mh_mechanicalscopeofworkid"; // Primary Key
        public const string ManufacturersName = "dobnyc_mh_manufacturersname"; // SinglelineofText
        public const string ModelName = "dobnyc_mh_modelname"; //SinglelineofText
        public const string CertificationforLISTING = "dobnyc_mh_certificationforlisting"; //SinglelineofText
        public const string GotoJobFiling = "dobnyc_mh_gotojobfiling"; //LookuptoJobFiling
        public const string Bin = "dobnyc_mh_bin";
        public const string isFiled = "dobnyc_mh_isfiled";
        public const string isCoCNeeded = "dobnyc_mh_isacertificateofcomplianceneeded";
        public const string subCategory = "dobnyc_mh_subcategory";//optionset
        public const string itemName = "dobnyc_mh_item";
        public const string itemText = "dobnyc_mh_itemtext";
        public const string Location = "dobnyc_mh_location";
        public const string NumberOfItems = "dobnyc_mh_ofitems";
        public const string capacityNumber = "dobnyc_mh_capacitynumber";
        public const string capacityUnits = "dobnyc_mh_capacityunits";
        public const string equipmentEfficiency = "dobnyc_mh_equipmentefficiencycopseereer";
        public const string equipmentUnits= "dobnyc_mh_equipmentunits";//optionset
        public const string IsinitialFilingScopeOfwork = "dobnyc_mh_isinitialfilingscopeofwork";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }





    //Holidays Entity
    public sealed class HolidaysEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_holidays";
        public const string Name = "dobnyc_name";
        public const string Date = "dobnyc_date";
    }

    //Delegates Entity
    public sealed class DelegatesEntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_delegates"; //Entity Name
        public const string DelegatesId = "dobnyc_delegatesid"; // Primary Key
        public const string Name = "dobnyc_name";

        public const string GoToJobFiling = "dobnyc_ms_gotojobfiling"; //LookUp to Job Filing
        public const string GoToContact = "dobnyc_ms_gotocontact"; //LookUp to Contact
        public const string GoToLicense = "dobnyc_ms_gotolicensee"; //LookUp to License
        public const string Email = "dobnyc_ms_email"; //String
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    //OP49 Entity
    public sealed class OP49EntityAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_op49"; //Entity Name
        public const string Op49Id = "dobnyc_op49id"; // Primary Key
        public const string Name = "dobnyc_name";
        public const string Bin = "dobnyc_op49_bin";
        public const string Block = "dobnyc_op49_block";
        public const string Borough = "dobnyc_op49_borough";
        public const string HouseNumber = "dobnyc_op49_houseno";
        public const string GoToJobFiling = "dobnyc_op49_jobfilingid";
        public const string Lot = "dobnyc_op49_lot";
        public const string OwnerDaytimePhoneNumber = "dobnyc_op49_ownerdayph";
        public const string OwnerEMail = "dobnyc_op49_owneremail";
        public const string FirstName = "dobnyc_op49_ownerfirstname";
        public const string LastName = "dobnyc_op49_ownerlastname";
        public const string OwnerMobileTelephone = "dobnyc_op49_ownermobile";
        public const string StreetName = "dobnyc_op49_streetname";
        public const string Zip = "dobnyc_op49_zip";
        public const string PostDisconnectRemovalInspection = "dobnyc_op494c4eddisconnectremoval";
        public const string DisconnectionProceedto4Cand4E = "dobnyc_op494c4edisconnection";
        public const string RemovalProceedto4Cand4E = "dobnyc_op494c4eremoval";
        public const string Provideactualdateofdisconnectremovalforthis = "dobnyc_op49actualdateofdisconnect";
        public const string BoilerDeviceNumber = "dobnyc_op49boilerdevicenum";
        public const string InspectionDate = "dobnyc_op49boilerinspdate";
        public const string SerialNumber = "dobnyc_op49boilerserialnum";
        public const string Howisbuildingbeingheated = "dobnyc_op49buildingheated";
        public const string Arethereanyactiveboilersremaining = "dobnyc_op49chkactiveboilerlocation";
        public const string SelectIfactivedevicesheatindividualresident = "dobnyc_op49chkactivedevicesbtus";
        public const string SiteIssafeYesNoFlag = "dobnyc_op49chksitesafe";
        public const string EquipmentUseNumberfortheAlternatedevice = "dobnyc_op49equipmentnumdevice";
        public const string BusinessAddress = "dobnyc_op49inspbusaddress";
        public const string BusinessName = "dobnyc_op49inspbusname";
        public const string BusinessTelephone = "dobnyc_op49inspbustel";
        public const string City = "dobnyc_op49inspcity";
        public const string InspectorEMail = "dobnyc_op49inspemail";
        public const string InspectorFirstName = "dobnyc_op49inspfirstname";
        public const string InspectorLastName = "dobnyc_op49insplastname";
        public const string InspectorLicenseNumber = "dobnyc_op49insplicno";
        public const string InspectorMobileTelephone = "dobnyc_op49inspmobile";
        public const string InspectorState = "dobnyc_op49inspstate";
        public const string InspectorZip = "dobnyc_op49inspzip";
        public const string JobNumbersOfAlternatedevices = "dobnyc_op49jobnumaltdevices";
        public const string LicenseType = "dobnyc_op49lictype";
        public const string NonExistingProceedto4E = "dobnyc_op49nonexisting4e";
        public const string OwnerAddress = "dobnyc_op49owneraddress";
        public const string OwnerCity = "dobnyc_op49ownercity";
        public const string OwnerContactPerson = "dobnyc_op49ownercontact";
        public const string OwnerContactEmail = "dobnyc_op49ownercontactemail";
        public const string OwnerContactMobileTelephone = "dobnyc_op49ownercontactmobile";
        public const string OwnerContactPhonenumber = "dobnyc_op49ownercontactph";
        public const string OwnerRegistrationNumber = "dobnyc_op49ownerregno";
        public const string OwnerState = "dobnyc_op49ownerstate";
        public const string OwnerZip = "dobnyc_op49ownerzip";
        public const string PermitNumbersofAlternatedevices = "dobnyc_op49permitnumaltdevices";
        public const string FilingFee = "dobnyc_op49_filingfee";
        public const string LateFee = "dobnyc_op49_latefee";
        public const string AmountPaid = "dobnyc_op49_amountpaid";
        public const string AmountDue = "dobnyc_op49_amountdue";
        public const string OP49InitialFilingFeeConfig = "OP49 Initial Fee Calculation";
        public const string IsSubmitted = "dobnyc_op49_issubmitted";
        public const string ReportStatus = "dobnyc_op49_reportstatus";
        public const string NoGoodCheckFee = "dobnyc_op49_nogoodcheck";
        public const string PhGuid = "dobnyc_op49_paymenthistoryguid";
        public const string RevertedFromNGC = "dobnyc_op49_revertedfromnogoodcheckop49";
        public const string Refund = "dobnyc_op49_temprefund";
        public const string UserfilingActions = "dobnyc_op49_userfilingactions";
    }
    public sealed class AutoNumberEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_autonumberentity";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string FacadesCounter = "dobnyc_facadescounter";
        public const string FacadesPaddingNumber = "dobnyc_facadespaddingnumber";
        public const string FacadesPaddingCharacter = "dobnyc_facadespaddingcharacter";

    }

    public sealed class ManageBoilerRequest
    {
        public const string EntityLogicalName = "dobnyc_manageboilerrequest";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string BoilerDeviceNumber = "dobnyc_mbr_boilerdevicenumber";
        public const string RequestStatus = "dobnyc_mbr_requeststatus";
        public const string Borough = "dobnyc_mbr_borough";
        public const string OccupancyType = "dobnyc_mbr_occupancytype";
        public const string existingBoilerType = "dobnyc_mbr_existingboilertype";
        public const string existingEnergySource = "dobnyc_mbr_existingenergysource";
        public const string BoilerLookup = "dobnyc_mbr_boilerdevice";
        public const string BoilerRating = "dobnyc_mbr_boilerrating";



    }
    public sealed class BoilerBuildDeviceDetailsEntityAttribute
    {
        /*
        





dobnyc_bbd_numberofmodules -string

            Chimney Details on Boiler Build Device Details
dobnyc_bbd_applicanceconnectedtoaventortochi  - Option set
dobnyc_bbd_isnewinstallofachimneyrelatedwork - two options
dobnyc_bbd_pleasechooseoneofthefollowing -Optionset
dobnyc_bbd_whatmaterialisthechimneylinedwith -optionset
dobnyc_bbd_typeofapprovedventingmaterial -optionset
dobnyc_bbd_chimneymaterialother - String
dobnyc_bbd_ventingothermaterial -string
dobnyc_bbd_masonrychimneystatement -two options
dobnyc_bbd_chimneystatementsignature - string
dobnyc_bbd_chimneystatementdate - Date time
        */



        public const string MastergotupdatedfromMBR = "dobnyc_bbd_masterdevicegotupdated";
        public const string ProposedBoilerType = "dobnyc_bbd_boilertype";
        public const string BoilerClassification = "dobnyc_bbd_boilerclassification";
        public const string BoilerRating = "dobnyc_bbd_boilerrating";
        public const string BoilerEnergySource = "dobnyc_bbd_energysource";      
        public const string MaximumAllowableWorkingPressure = "dobnyc_bbd_maximumallowablework";          
        public const string NumberOfModules = "dobnyc_bbd_numberofmodules";





        public const string ChimneyApplianceConnectedTo = "dobnyc_bbd_applicanceconnectedtoaventortochi";
        public const string ChimneyIsNewInstallation = "dobnyc_bbd_isnewinstallofachimneyrelatedwork";
        public const string ChimneyChooseFollowing = "dobnyc_bbd_pleasechooseoneofthefollowing";
        public const string ChimneyMaterialLinedWith = "dobnyc_bbd_whatmaterialisthechimneylinedwith";

        public const string VentApprovedMaterial = "dobnyc_bbd_typeofapprovedventingmaterial";
        public const string ChimneyMaterialOther = "dobnyc_bbd_chimneymaterialother";
        public const string VentMaterialOther = "dobnyc_bbd_ventingothermaterial";
        public const string AssociatedJobNumber = "dobnyc_bbd_associatedjobnumber";
        public const string QuantityofBoilers = "dobnyc_bbd_quantityofboilers";




        public const string FSDeviceNumber = "dobnyc_bbd_fs_boilerdevicenumber";

        public const string EntityLogicalName = "dobnyc_boilerbuilddevicedetails";
        public const string BoilerBuildDeviceDetailsId = "dobnyc_boilerbuilddevicedetailsid";
        public const string existingProposedOptionSet = "dobnyc_bbd_existingproposedoptionset";
        public const string existingBoilerBuildDeviceLookup = "dobnyc_bbd_existingboilerbuilddevicelookup";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string TrackingNumber = "dobnyc_db_trackingumber";
        public const string BoilerScopeofworkid = "dobnyc_bbd_boilersbuildscopeofwork"; // Primary Key
        public const string BoilerDeviceNumber = "dobnyc_bbd_bu_boilerdevicenumber";
        public const string ReplacedBoilerDevice = "dobnyc_bbd_replacedmasterboilerdevice";
        public const string OtherFuelStorageAppliance = "dobnyc_bbd_bu_fuelstorageapplianceother";
        public const string OccupancyType = "dobnyc_bbd_occupancytype"; //LookuptoJobFiling
        public const string SerialNumber = "dobnyc_bbd_serialno";
        public const string constructionMaterial = "dobnyc_bbd_constructionmaterial";
        public const string constructionMaterialOther = "dobnyc_bbd_constructionmaterialother";
        public const string NationalBoardNumber = "dobnyc_bbd_nationalboardno";
        public const string Efficiency = "dobnyc_bbd_efficiency";
        public const string PressureSettingOfreliefValvepsi = "dobnyc_bbd_pressuresettingofreliefvalvepsi";
        public const string InternalAccess = "dobnyc_bbd_bu_internalaccess";
        public const string BTU = "dobnyc_bbd_inputcapacity";
        public const string BoilerManufacturer = "dobnyc_bbd_boilermanufacturer";
        public const string Locatedin = "dobnyc_bbd_bu_boilerlocatedinupdated";
        public const string BoilerModel = "dobnyc_bbd_modelnumber";
        public const string GotoBoiler = "dobnyc_gotoboiler";
        public const string GotoJobFiling = "dobnyc_bbd_gotojobfiling";
        public const string BoilerListingAgencyName = "dobnyc_bbd_bu_listingagencyname";
        public const string BoilerListingAgencyNameOther = "dobnyc_bbd_ulcsaetlothernumber";
        public const string BoilerCertificationNumber = "dobnyc_bbd_bu_certificationnumber";
        public const string ServiceLocationFloor = "dobnyc_bbd_servicinglocationfloor";
        public const string ServiceLocationAddress = "dobnyc_bbd_servicinglocationaddress";
        public const string BoilerDesign = "dobnyc_bbd_design";
        public const string BoilerComments = "dobnyc_bbd_comments";
        public const string BoilerInputCapacity = "dobnyc_bbd_inputcapacity";
        public const string IsAssociatedWithCOGEN = "dobnyc_bbd_istheboilerassociatedwithacogen";
        public const string IsBoilerEquippedWithManholes = "dobnyc_bbd_boilerequippedwithmanholes";
        public const string IsBoilerHeatingaSingleAppartment = "dobnyc_bbd_isthisboilerheatingasingle";
        public const string HowManyInstancesOfBoilers = "dobnyc_bl_howmanyinstancesofthisboilerarethere";
        public const string NewDeviceNumber = "dobnyc_bl_newdevicenumber";
        public const string BoilerPendingDetails = "dobnyc_bbd_ispendingdetails";
        public const string FBPendingDetails = "dobnyc_bbd_isfbdetailspending";
        public const string FSPendingDetails = "dobnyc_bbd_isfsdetailspending";



        #region Burner Details
        public const string IsSameScopeOFWorkForFuelBurner = "dobnyc_bbd_fuelburner";
        public const string BurnerManufacturer = "dobnyc_bbd_bu_burnermanufacturer";
        public const string BurnerApplianceConnectedTo = "dobnyc_bbd_bu_typeofappliance";
        public const string FDNYPermitNumber = "dobnyc_bbd_fs_fdnypermitnumber";
        public const string BurnerModelNumber = "dobnyc_bbd_bu_modelnumber";
        public const string BurnerULCSAETLNumber = "dobnyc_bbd_bu_ulcsaetlothernumber";
       // public const string BurnerProposedEnergySource = "dobnyc_bbd_bu_proposedenergysource";
       // public const string BurnerExistingEnergySource = "dobnyc_bbd_bu_existingenergysource";
        public const string BurnerIsThisExisting = "dobnyc_bbd_bu_sthisanexistingburner";
        public const string BurnerDoesDualCapability = "dobnyc_bbd_bu_burnerhavedualburning";
        public const string BurnerInputCapacity = "dobnyc_bbd_bu_inputcapacitybtu";
        public const string BurnerFiringRate = "dobnyc_bbd_bu_firingrategphapplicableforoil";
        public const string BurnerFiringBTUHour = "dobnyc_bbd_bu_firingbtuhourappli";
        public const string BurnerComments = "dobnyc_bbd_bu_burnercomments";
        public const string BurnerType = "dobnyc_bbd_bu_typeofburner";
        public const string BurnerListingAgencyName = "dobnyc_bbd_br_burnerlistingagencyname";
        public const string BurnerListingAgencyOther = "dobnyc_bbd_br_burnerlistingagencynameother";

        public const string BurnerCertificationNumber = "dobnyc_bbd_bu_burnercertificationnumber";
        public const string ReplacingBurner = "dobnyc_bbd_bu_areyoureplacingtheburner";
        public const string DualBurningCapacity = "dobnyc_bbd_bu_burnerhavedualburning";
        #endregion

        #region Fuel Storage
        public const string IsSameScopeOFWorkForFuelStorage = "dobnyc_bbd_fuelburner2";
        public const string IsSameScopeOFWorkForFuelStorage2 = "dobnyc_bbd_fuelstorage";
        public const string FSComments = "dobnyc_bbd_fs_commentsfs";
       // public const string FSProposedGrdaeOil = "dobnyc_bbd_fs_proposedgradeofoil";
        public const string FSExistingGrdaeOil = "dobnyc_bbd_fs_existinggradeofoil";
        public const string FSLocationOfFS = "dobnyc_bbd_fs_locationoffuelstorage";
        public const string FSExistingStorageTank = "dobnyc_bbd_fs_isthisanexistingfuelstoragetank";
        public const string FSHowTanksInstalled = "dobnyc_bbd_fs_howarethetanksinstalled";
        public const string FSTotalTankCapacity = "dobnyc_bbd_fs_totaltankcapacitygal";
        public const string FSBuildingAdjacentLineOfSubway = "dobnyc_bbd_fs_tankinabuildingadjacentto";
        public const string FSabandedResultOfOiltoGas = "dobnyc_bbd_fs_beingabandonedremovedasares";
        public const string FSApplianceFuelStorage = "dobnyc_bbd_fs_typeofapplianceisthefuelstorage";
        public const string FSFloorNumber = "dobnyc_bbd_fs_floornumber";
        public const string Isabonabandonremovaloftank = "dobnyc_bbd_fs_isthisanabandonremovaloftank";
        #endregion

        #region Task Lookups
        public const string AllTaskFormLookup = "dobnyc_bbd_alltaskforms";
        public const string AllTaskFormLookupRelation = "dobnyc_task_dobnyc_boilerbuilddevicedetails_bbd_AllTaskForms";
        public const string PrimaryPELookup = "dobnyc_bbd_primarypetask";
        public const string PrimaryPELookupRelation = "dobnyc_task_dobnyc_boilerbuilddevicedetails_bbd_PrimaryPETask";
        public const string SecondaryPELookup = "dobnyc_bbd_secondarypetask";
        public const string SecondaryPELookupRelation = "dobnyc_task_dobnyc_boilerbuilddevicedetails_bbd_SecondaryPETask";

        #endregion

        public const string FuelBurnerMasterLookup = "dobnyc_bbd_fuelburnermasterlookup";
        public const string FuelStorageMasterLookup = "dobnyc_bbd_fuelstoragemasterlookup";

        #region Accela Fields
        public const string AccelaBoilerStatus = "dobnyc_accela_boilerstatus";
        public const string AccelaBoilerRating = "dobnyc_accela_boilerratingfromaccela";
        public const string AccelaBoilerClassification = "dobnyc_accela_boilerclassification";
        public const string AccelaBoilerMaxWorkingPressure = "dobnyc_accela_boilermaxworkingaccela";
        public const string AccelaCreateUpdateDeviceFlag = "dobnyc_accela_createupdatedevice";
        #endregion

        public const string ChimneyAttenstation = "dobnyc_bbd_chimneyattestation";
        public const string ChimneyUserLookup = "dobnyc_bbd_bl_sw_masonrychimneyuser";
        public const string ChimneyUserRelationship = "dobnyc_contact_dobnyc_boilerbuilddevicedetails_bbd_bl_sw_masonrychimneyuser";
        public const string ParentBBD = "dobnyc_bbd_parentbbd";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    //Inspection Components Auto Population - PW1 Standardization - Start
    public sealed class STScopeOfWorkEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_stscopeofwork";
        public const string STScopeOfWorkid = "dobnyc_stscopeofworkid"; // Primary Key
        public const string EntityNameAttribute = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_jobfilinglookup";
        public const string PrefabWoodJoists = "dobnyc_prefabwoodsjoists";
        public const string StructuralColdformedSteel = "dobnyc_structuralcoldformedsteel";
        public const string OpenWebSteelPosts = "dobnyc_openwebsteelposts";
        public const string Mechanical = "dobnyc_gc_mechanical";
        public const string PartialDemolition	="dobnyc_gc_partialdemolition";
         public const string Aluminum = "dobnyc_st_aluminum";
        public const string Concrete = "dobnyc_st_concrete";
        public const string HandheldMechanical = "dobnyc_st_handheldmechanical";
        public const string Masonry = "dobnyc_st_masonry";
        public const string NonHandheldMechanical = "dobnyc_st_nonhandheldmechanical";
        public const string OtherMiscellaneous = "dobnyc_st_othermiscellaneous";
        public const string RaisingandMovingofBuildings = "dobnyc_st_raisingandmovingofbuildings";
        public const string SignStructure = "dobnyc_st_signstructure";
        public const string Steel = "dobnyc_st_steel";
        public const string TemporaryStructuralBracing = "dobnyc_st_temporarystructuralbracing";
        public const string Wood = "dobnyc_st_wood";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";



    }



    public sealed class FulelBurnerMaster
    {
        public const string EntityLogicalName = "dobnyc_fuelburnermaster";
        public const string EntityNameAttribute = "dobnyc_name";

        public const string Bin = "dobnyc_bu_bin";
        public const string Block = "dobnyc_bu_block";
        public const string Borough = "dobnyc_bu_borough";
        public const string HouseNumber = "dobnyc_bu_housenumber";
        public const string StreetName = "dobnyc_bu_streetname";
        public const string Lot = "dobnyc_bu_lot";
        public const string Aptno = "dobnyc_bu_aptno";
        public const string Zipcode = "dobnyc_bu_zipcode";
        #region Burner Details
        public const string BurnerManufacturer = "dobnyc_bu_burnermanufacturer";
        public const string BurnerApplianceConnectedTo = "dobnyc_bu_applianceistheburnerconnectedto";

        public const string BurnerModelNumber = "dobnyc_bu_modelnumber";
        public const string BurnerULCSAETLNumber = "dobnyc_bu_ulcsaetlothernumber";
      //  public const string BurnerProposedEnergySource = "dobnyc_bu_proposedenergysourceburner";
      //  public const string BurnerExistingEnergySource = "dobnyc_bu_existingenergysource";
        public const string BurnerIsThisExisting = "dobnyc_bu_isthisanexistingburner";
        public const string BurnerDoesDualCapability = "dobnyc_doesthisburnerhavedualburningcapabiliti";
        public const string BurnerInputCapacity = "dobnyc_bu_inputcapacitybtu";
        public const string BurnerFiringRate = "dobnyc_bu_firingrategph";
        public const string BurnerFiringBTUHour = "dobnyc_bu_firingbtuhour";
        public const string BurnerComments = "dobnyc_bu_commentsburner";
        public const string BurnerType = "dobnyc_bu_typeofburner";
        public const string FuelBurnerSelfLookup = "dobnyc_bu_fuelburnerselflookup";
        public const string BoilerMasterLookup = "dobnyc_bu_boilermasterlookup";
        public const string BurnerListingAgencyName = "dobnyc_bu_burnerlistingagencyname";
        public const string BurnerListingAgencyOther = "dobnyc_bu_burnerlistingagencyother";
        public const string BurnerCertificationNumber = "dobnyc_bu_burnercertificationnumber";
        public const string ReplacingBurner = "dobnyc_bu_areyoureplacingburner";
        public const string DualBurningCapacity = "dobnyc_bu_dualburningcapability";
        public const string FuelBurnerStatus = "dobnyc_bu_fuelburnerstatus";
        #endregion
        public const string LatestBoilerBuildDevice = "dobnyc_fb_latestboilerbuilddevicedetails";//CRM fill this field  if scope includes a)FB  b)if Boiler and scope is same as Boiler
        public const string SourceUpdate = "dobnyc_sourceofupdate";
    }


    public sealed class FulelStorageMaster
    {
        public const string EntityLogicalName = "dobnyc_fuelstoragemaster";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string OtherFuelStorageAppliance = "dobnyc_fl_fuelstorageapplianceother";

        public const string Bin = "dobnyc_fl_bin";
        public const string Block = "dobnyc_fl_block";
        public const string Borough = "dobnyc_fl_borough";
        public const string HouseNumber = "dobnyc_fl_housenumber";
        public const string StreetName = "dobnyc_fl_streetname";
        public const string Lot = "dobnyc_fl_lot";
        public const string Aptno = "dobnyc_fl_aptno";
        public const string Zipcode = "dobnyc_fl_zipcode";
        #region Fuel Storage
        public const string FSComments = "dobnyc_fl_commentsfuelstorage";
      //  public const string FSProposedGrdaeOil = "dobnyc_fl_proposedgradeofoil";
        public const string FSExistingGrdaeOil = "dobnyc_fl_existinggradeofoil";
        public const string FSLocationOfFS = "dobnyc_fl_locationofthefuelstorage";
        public const string FSExistingStorageTank = "dobnyc_fl_isthisanexistingfuelstoragetank";
        public const string FSHowTanksInstalled = "dobnyc_fl_howarethetanksinstalled";
        public const string FSTotalTankCapacity = "dobnyc_fl_totaltankcapacitygal";
        public const string FSBuildingAdjacentLineOfSubway = "dobnyc_fl_buildingadjacenttothelineofasubway";
        public const string FSabandedResultOfOiltoGas = "dobnyc_fl_abandonedremovedasaresultofanoiltoga";
        public const string FSApplianceFuelStorage = "dobnyc_fl_applianceisthefuelstorageequipment";
        public const string FDNYPermitNumber = "dobnyc_fl_fdnypermitnumber";
        public const string JobFilingLookup = "dobnyc_fl_jobfilinglookup";
        public const string FSFloorNumber = "dobnyc_fl_floornumber";
        public const string CreatedOn = "createdon";

        #endregion
        public const string FuelStorageSelfLookup = "dobnyc_fl_fuelstorageselflookup";
        public const string BoilerMasterLookup = "dobnyc_fl_boilermasterlookup";
        public const string LatestBoilerBuildDevice = "dobnyc_fs_latestboilerbuilddevicedetails";//fill this field  if scope inckudes a)FS b)if FB and scope is same as FB c)if Boiler and scope is same as Boiler
        public const string FuelStorageStatus = "dobnyc_fl_fuelstoragestatus";
        public const string SourceUpdate = "dobnyc_sourceofupdate";
    }



    public sealed class BoilerMasterDevice
    {
        public const string EntityLogicalName = "dobnyc_boiler";
        public const string NumberOfModules = "dobnyc_bl_numberofmodules";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string boilerStatus = "dobnyc_bl_boilerstatus";
        public const string boilerNumber = "dobnyc_bl_boilernumber";
        public const string BoilerMasterReplacementLookup = "dobnyc_boilermasterdevice";
        //    public const string OccupancyType = "dobnyc_bbd_occupancytype"; //LookuptoJobFiling
        public const string SerialNumber = "dobnyc_bl_serialnumber";
        public const string constructionMaterial = "dobnyc_bl_constructionmaterial";
        public const string constructionMaterialOther = "dobnyc_bl_constructionmaterialother";
        public const string NationalBoardNumber = "dobnyc_bl_nationalboardno";
        public const string Efficiency = "dobnyc_bl_efficiency";
        public const string PressureSettingOfreliefValvepsi = "dobnyc_bl_pressuresettingofreliefvalvepsi";
        public const string InternalAccess = "dobnyc_bu_internalaccess";
        public const string Bin = "dobnyc_bl_premises_bin";
        public const string Block = "dobnyc_bl_premises_block";
        public const string Borough = "dobnyc_bl_premises_borough";
        public const string HouseNumber = "dobnyc_bl_premises_houseno";
        public const string StreetName = "dobnyc_bl_premises_streetname";
        public const string Lot = "dobnyc_bl_premises_lot";
        public const string Aptno = "dobnyc_bu_aptno";
        public const string Zipcode = "dobnyc_bu_zipcode";
        public const string PermZipcode = "dobnyc_bl_premises_zipcode";
        public const string BoilerRating = "dobnyc_bl_devicetype";
        public const string BoilerClassification = "dobnyc_bis_boilerclassification";
        public const string BoilerClassification1= "dobnyc_bl_boilerclassification";
        public const string BoilerType = "dobnyc_bl_existingboilertype";
        public const string BoilerEnergySource = "dobnyc_bl_existingenergysource";
        public const string BTU = "dobnyc_bl_btu";
        public const string BoilerManufacturer = "dobnyc_bl_boilermake";
        public const string Locatedin = "dobnyc_bl_locatedin";
        public const string BoilerModel = "dobnyc_bl_boilermodel";
        public const string BoilerListingAgencyName = "dobnyc_bl_listingagencyname";
        public const string BoilerCertificationNumber = "dobnyc_bl_certificationnumber";
        public const string ServiceLocationFloor = "dobnyc_bl_servicinglocationfloor";
        public const string BoilerDesign = "dobnyc_bl_design";
        public const string BoilerComments = "dobnyc_bl_comments";
        public const string BoilerListingAgencyOther = "dobnyc_bl_listingagencynameother";
        public const string QuantityofBoilers = "dobnyc_bl_boilersquantity";
        public const string BoilerInputCapacity = "dobnyc_bl_inputcapacity";
        public const string HowManyInstancesOfBoilers = "dobnyc_bl_howmanyinstancesofthisboilerarethere";
        public const string IsAssociatedWithCOGEN = "dobnyc_bl_istheboilerassociatedwithacogen";
        public const string IsBoilerEquippedWithManholes = "dobnyc_bl_istheboilerequippedwithmanholes";
        public const string IsBoilerHeatingaSingleAppartment = "dobnyc_bl_isthisboilerheatingasingleapartment";
        public const string MaximumAllowableWorkingPressure = "dobnyc_bl_maximumallowableworkingpressuremawp";
      //  public const string ProposedBoilerType = "dobnyc_bl_proposedboilertype";
       // public const string ProposedEnergySource = "dobnyc_bl_proposedenergysource";
        public const string IsHistoric = "dobnyc_bl_ishistoric";
        public const string IsDeviceDetailsPending = "dobnyc_bl_isdevicedetailspending";
        public const string occupancyType = "dobnyc_bl_buildingoccupancyclassification";
        public const string SourceUpdate = "dobnyc_sourceofupdate";
        public const string MasterGotupdatedfromMBR = "dobnyc_masterupdatedfrommbr";
        public const string ServicingLocationAddress = "dobnyc_bl_servicinglocationaddress";
        #region Burner Details
        public const string BurnerManufacturer = "dobnyc_bu_burnermanufacturer";
        public const string BurnerApplianceConnectedTo = "dobnyc_bu_applianceistheburnerconnectedto";
        public const string FDNYPermitNumber = "dobnyc_fl_fdnypermitnumber";
        public const string BurnerModelNumber = "dobnyc_bu_modelnumber";
        public const string BurnerULCSAETLNumber = "dobnyc_bu_ulcsaetlothernumber";
        public const string BurnerProposedEnergySource = "dobnyc_bu_proposedenergysourceburner";
        public const string BurnerExistingEnergySource = "dobnyc_bu_existingenergysource";
        public const string BurnerIsThisExisting = "dobnyc_bu_isthisanexistingburner";
        public const string BurnerDoesDualCapability = "dobnyc_doesthisburnerhavedualburningcapabiliti";
        public const string BurnerInputCapacity = "dobnyc_bu_inputcapacitybtu";
        public const string BurnerFiringRate = "dobnyc_bu_firingrategph";
        public const string BurnerFiringBTUHour = "dobnyc_bu_firingbtuhour";
        public const string BurnerComments = "dobnyc_bu_commentsburner";
        public const string BurnerType = "dobnyc_bu_typeofburner";
        #endregion

        #region Fuel Storage
        public const string FSComments = "dobnyc_fl_commentsfuelstorage";
        public const string FSProposedGrdaeOil = "dobnyc_fl_proposedgradeofoil";
        public const string FSExistingGrdaeOil = "dobnyc_fl_existinggradeofoil";
        public const string FSLocationOfFS = "dobnyc_fl_locationofthefuelstorage";
        public const string FSExistingStorageTank = "dobnyc_fl_isthisanexistingfuelstoragetank";
        public const string FSHowTanksInstalled = "dobnyc_fl_howarethetanksinstalled";
        public const string FSTotalTankCapacity = "dobnyc_fl_totaltankcapacitygal";
        public const string FSBuildingAdjacentLineOfSubway = "dobnyc_fl_buildingadjacenttothelineofasubway";
        public const string FSabandedResultOfOiltoGas = "dobnyc_fl_abandonedremovedasaresultofanoiltoga";
        public const string FSApplianceFuelStorage = "dobnyc_fl_applianceisthefuelstorageequipment";

        #endregion


        public const string ChimneyApplianceConnectedTo = "dobnyc_bl_applianceconnectedtoaventortochim";
        public const string ChimneyIsNewInstallation = "dobnyc_ch_newinstallationofachimneyrelated";
        public const string ChimneyChooseFollowing = "dobnyc_bl_pleasechooseoneofthefollowing";
        public const string ChimneyMaterialLinedWith = "dobnyc_bl_whatmaterialisthechimneylinedwith";

        public const string VentApprovedMaterial = "dobnyc_bl_typeofapprovedventingmaterial";
        public const string ChimneyMaterialOther = "dobnyc_bl_chimneymaterialother";
        public const string VentMaterialOther = "dobnyc_bl_ventingothermaterial";
        public const string AssociatedJobNumber = "dobnyc_ch_jobnumberfortheassociatedchimneywork";


        public const string LatestBoilerBuildDevice = "dobnyc_bl_latestboilerbuilddevicedetails"; // Holds the latest Boiler Build device which got permit entire (Scope includes boiler)

        public const string LatestFuelBurnerDevice = "dobnyc_bl_latestfuelburner"; // Holds the latest master Fuel Burner Device

        public const string LatestFuelStorageDevice = "dobnyc_bl_latestfuelstorage"; // Holds the latest master Fuel Storage Device. On removeal and abandonment replace with latest Active Master FS if present any


    }

    

        public sealed class BEScopeOfWorkEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_boilersbuildscopeofwork";
        public const string BoilerScope = "dobnyc_bbd_sw_boilerscope";
        public const string FBScope = "dobnyc_bbd_sw_fuelburnerscope";
        public const string FSScope = "dobnyc_bbd_sw_fuelstoragescope";

        
        public const string EntityNameAttribute = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_bbd_sw_bl_gotojobfiling";
        public const string BESOWId = "dobnyc_boilersbuildscopeofworkid";
        public const string BoilerScopeofworkid = "dobnyc_boilersbuildscopeofworkId"; // Primary Key
        public const string ScopeOfWSorkType = "dobnyc_bbd_sw_bl_scopeofwork";
        public const string GotoJobFiling = "dobnyc_bbd_sw_bl_gotojobfiling"; //LookuptoJobFiling
        public const string existingBoilerNumbers = "dobnyc_bbd_sw_bl_existingboilerdevices";
        public const string BoilerType = "dobnyc_bbd_sw_bl_proposedboilertype";
        public const string BoilerClassification = "dobnyc_bbd_sw_bl_proposedboilerclassification";
        public const string BoilerRating = "dobnyc_bbd_sw_bl_proposedboilerrating";
        public const string BoilerEnergySource = "dobnyc_bbd_sw_bl_proposedenergysource";
        public const string BoilerNames = "dobnyc_bbd_sw_boilernames";
        public const string MaximumAllowableWorkingPressure = "dobnyc_bbd_sw_bl_proposedmaximumallowable";
       // public const string ExistingBoilerType = "dobnyc_bbd_sw_exisintgboilertype";
        public const string ExistingEnergySource = "dobnyc_bbd_sw_bl_existingenergysource";
        public const string CreatedOn = "createdon";
        public const string NoDeviceFound = "dobnyc_bbd_nodevicefound";
        public const string AssociatedDeviceNumbers = "dobnyc_bbd_associateddevicenumbers";
        public const string FuelstorageApplianceConnected = "dobnyc_bbd_sw_fuelstorageapplianceconnected";
        public const string Associatedpljobnumber = "dobnyc_bbd_sw_bl_associatedpljobnumber";
        public const string Heatingcapacitybtuhr = "dobnyc_sw_bl_heatingcapacitybtuhr";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }
    //Inspection Components Auto Population - PW1 Standardization - End
    public sealed class TR3MixEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_tr3_mix";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string GotoTRTechnicalreport = "dobnyc_tr3mix_gototrtechnicalreport";
        public const string MixType = "dobnyc_tr3mix_methodofdeterminingproportions";
        public const string SpecifiedStrength = "dobnyc_tr3mix_specifiedstrength";
        public const string SpecifiedTestAge = "dobnyc_tr3mix_specifiedtestage";
        public const string createdon = "createdon";
        public const string CreatedbeforeBcDbc = "dobnyc_tr3_createdbeforebcdbc";
        public const string SequenceNumber = "dobnyc_sequencenumber";
        public const string IsMixcreatedonPAA = "dobnyc_iscreatedonpaa";

    }
    public sealed class TR3Director
    {
        public const string EntityLogicalName = "dobnyc_tr3technicalreport";
        public const string Name = "dobnyc_name";
        public const string GotoTR3Technicalreport = "dobnyc_tr3maintechnicalreport";
        public const string CPBusinessaddesss = "dobnyc_tr3_concreteproducerbusaddress";
        public const string CPBusinesCity = "dobnyc_tr3_concreteproducerbuscity";
        public const string CPBusinesFax = "dobnyc_tr3_concreteproducerbusfax";
        public const string CPBusinesName = "dobnyc_tr3_concreteproducerbusname";
        public const string CPBusinesNameLookup = "dobnyc_tr3_concreteproducerbusnamelookup";
        public const string CPBusinesState = "dobnyc_tr3_concreteproducerbusstate";
        public const string CPBusinesTelephone = "dobnyc_tr3_concreteproducerbustel";
        public const string CPBusinesZip = "dobnyc_tr3_concreteproducerbuszip";
        public const string CPLicenseLookup = "dobnyc_tr3_concreteproducerlicensee";
        public const string CPName = "dobnyc_tr3_concreteproducername";
        public const string CPNameLookup = "dobnyc_tr3_concreteproducernamelookup";
        public const string CPDate = "dobnyc_tr3_concreteproducerdate";
        public const string GotoJobFiling = "dobnyc_tr3mainjobfilingid";
        public const string NRMCAExpirationDate = "dobnyc_tr3_nrmca";
        public const string designApplicantCheckBox = "dobnyc_tr3_chkboxdesignapplicantsigndirector";
        public const string  TR3TrackingNumber = "dobnyc_tr3_trackingnumber";
    }

    public sealed class TR2TechnicalReport
    {
        public const string EntityLogicalName = "dobnyc_tr2technicalreport";
        public const string Name = "dobnyc_name"; //SinglelineofText
        public const string GotoJobFiling = "dobnyc_tr2_jobfilingid"; //LookuptoJobFiling
        public const string isAllConcreteWorkDone = "dobnyc_st_areallconcretetestworksdone";
        public const string isJobReadyForSignOff = "dobnyc_st_isjobreadyforsignoff";
        public const string TR2TechnicalReportId = "dobnyc_tr2technicalreportid";
        public const string IsBCDBCTaskSubmitted = "dobnyc_isbcdbctasksubmitted";
        public const string DesignApplicantStatementforNoExceptions = "dobnyc_dobnyc_tr2_chkboxdesignapplicantsign";
    }


    public sealed class TR3TechnicalReport
    {
        public const string EntityLogicalName = "dobnyc_tr3maintechnicalreport";
        public const string Name = "dobnyc_name"; //SinglelineofText
        public const string GotoJobFiling = "dobnyc_tr3jobfilingid"; //LookuptoJobFiling
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }

    public sealed class TR2TestReport
    {
        public const string EntityLogicalName = "dobnyc_tr2testreport";
        public const string Name = "dobnyc_name"; //SinglelineofText
                                                  // public const string GotoJobFiling = "dobnyc_tr3jobfilingid"; //LookuptoJobFiling
        public const string SpecifiedStrength = "dobnyc_tr2_specifiedconcretestrengthpsi";
        public const string SpecifiedTestAge = "dobnyc_tr2_testagedays";
        public const string GotoTr3mix = "dobnyc_gototr3mix";
        public const string GotoTr2report = "dobnyc_tr2_gototr2technicalreport";
        public const string NRMCAExpirationDate = "dobnyc_tr2nrmca";
        public const string CPBusinessaddesss = "dobnyc_tr2_concretebusaddesss";
        public const string CPBusinesCity = "dobnyc_tr2_concreteproducerbuscity";
        public const string CPBusinesFax = "dobnyc_tr2_concreteproducerbusfax";
        public const string CPBusinesName = "dobnyc_tr2_concreteproducerbusname";
        public const string CPBusinesNameLookup = "dobnyc_tr2_concretebusnamelookup";
        public const string CPBusinesState = "dobnyc_tr2_concreteproducerbusstate";
        public const string CPBusinesTelephone = "dobnyc_tr2_concreteproducerbustelephone";
        public const string CPBusinesZip = "dobnyc_tr2_concreteproducerbuszip";
        public const string CPLicenseLookup = "dobnyc_tr2_concreteproducerlicense";
        public const string CPName = "dobnyc_tr2_concreteproducername";
        public const string CPNameLookup = "dobnyc_tr2_concreteproducernamelookup";
        public const string CPDate = "dobnyc_tr2_concreteproducer";
        public const string CreatedbeforeBcDbc = "dobnyc_tr2_createdbeforebcdbc";
        public const string TR3TrackingNumber = "dobnyc_tr_tr3trackingnumber";
        public const string SequenceNumber = "dobnyc_sequencenumber";
    }

    public sealed class TR3TechnicalReportEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_tr3technicalreport";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string Tr3MixCounter = "dobnyc_tr3_tr3mixcounter";
        public const string ID = "dobnyc_tr3technicalreportid";
        public const string GotoTR3 = "dobnyc_tr3maintechnicalreport";
        public const string GotoJobFiling = "dobnyc_tr3mainjobfilingid";
        public const string trackingNumber = "dobnyc_tr3_trackingnumber";
    }

    public sealed class SOWCommonWorkTypesEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_scopeofworkforcommonworktype";
        public const string SOWCommonWorkTypesEntityAttributeId = "dobnyc_scopeofworkforcommonworktypeid";
        public const string EntityNameAttribute = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_spsd_commonjobfilinglookup";
        public const string StormSewer = "dobnyc_plstorm_stromsewer";
        public const string CombinedSewer = "dobnyc_plstorm_combinedsewer";
        public const string PrivateDisposal = "dobnyc_plstorm_privatedisposal";
        public const string Isanewormodifiedstreetconnectionproposed	="dobnyc_plstorm_newormodifiedconnection";
        public const string Isanewsystemormodificationstotheprivated = "dobnyc_plstorm_newormodifieddisposal";
        public const string IsdetentionorretentionrequiredbytheDEP	="dobnyc_plstorm_detentionorretention";
        public const string RoofDetention = "dobnyc_plstorm_roofdetention";
        public const string OpenSiteDetention = "dobnyc_plstorm_opensitedetention";
        public const string DetentionTanks = "dobnyc_plstorm_detentiontanks";
        public const string DrainageSump = "dobnyc_plstorm_drainagesumps";
        public const string PrivateSewageTreatmentPlant = "dobnyc_plstorm_privatesewegeplant";
        public const string DryWellRetention = "dobnyc_plstorm_drywellretention";
        public const string AreaYardDrain = "dobnyc_plstorm_areayarddrain";
        public const string RoofDrain = "dobnyc_plstorm_roofdrain";
        public const string SumpPump = "dobnyc_plstorm_sumppump";
        public const string DetentionTank = "dobnyc_plstorm_detentiontank";
        public const string ComponentsDryWellRetention = "dobnyc_plstorm_componentsdrywellretention";
        public const string Other = "dobnyc_plstorm_other";
        public const string GasPipingInvolved = "dobnyc_plgas_gadpipinginvolved";
        public const string Individual = "dobnyc_plgas_individual";
        public const string Common = "dobnyc_plgas_common";
        public const string NA = "dobnyc_plgas_na";
        public const string CookingResidential = "dobnyc_plgas_cookingresidential";
        public const string CookingCommercial = "dobnyc_plgas_cookingcommercial";
        public const string HotWater = "dobnyc_plgas_hotwater";
        public const string Heating = "dobnyc_plgas_heating";
        public const string Burner = "dobnyc_plgas_burner";
        public const string GeneratorCoGeneratorsProcessing = "dobnyc_plgas_generatorprocessing";
        public const string LocationOtherGasAppliancesEquipment = "dobnyc_plgas_locationgasappliances";
        public const string GasBoosterPump = "dobnyc_gasboosterpump";
        public const string CookingEquipmentnonresidential	="dobnyc_plgas_cookingeuipmentnonresidential";
        public const string CookingEquipmentresidential	="dobnyc_plgas_cookingeuipmentresidential";
        public const string GasBoiler350Kfamily	="dobnyc_plgas_gasboiler350k";
        public const string GasBurner = "dobnyc_plgas_gasburner";
        public const string GasBarbeque = "dobnyc_plgas_gasbarbeque";
        public const string GasCombinationUnitHeatHWColl	="dobnyc_plgas_gascombinationunit";
        public const string GasDryer = "dobnyc_plgas_gasdryer";
        public const string GasFurnace = "dobnyc_plgas_gasfurnace";
        public const string GasWaterHeater = "dobnyc_plgas_gaswaterheater";
        public const string NonGasWaterHeater = "dobnyc_plgas_nongaswaterheater";
        public const string EmergencyCoGeneratorMicroturbine	="dobnyc_plgas_emergencymicroturbine";
 public const string EmergencyCoGeneratorEngine	="dobnyc_plgas_emergencyengine";
 public const string EmergencyCoGeneratorFuelcell	="dobnyc_plgas_emergencyfuelcell";
 public const string GasOther = "dobnyc_plgas_other";
        public const string SpecifyTypeofSprinklerSystem = "dobnyc_plsp_typeofsprinklersystem";
        public const string ChoosePrimaryWaterSystem = "dobnyc_plsp_chooseprimarywatersystem";
        public const string NFPA13 = "dobnyc_plsp_nfpa13";
        public const string NFPA13R = "dobnyc_sp_nfpa13r";
        public const string NFPA13D = "dobnyc_plsp_nfpa13d";
        public const string MedicalGasPiping = "dobnyc_plmedical_medicalgaspiping";
        public const string MedicalEquipment = "dobnyc_plmedical_medicalequipment";
        public const string NonflammableMedicalGas	="dobnyc_plmedical_nonflammablegas";
 public const string NonmedicalOxygen	="dobnyc_plmedical_nonmedicaloxygen";
 public const string Domestic = "dobnyc_plwatersanitary_domestic";
        public const string DomesticwithSPtakeoff = "dobnyc_plwatersanitary_domesticwithsptakeoff";
        public const string Sprinklerwithdomestictakeoff = "dobnyc_plwatersanitary_sprinklerwithtakeoff";
        public const string FireService = "dobnyc_plwatersanitary_fireservice";
        public const string Domesticwatertank = "dobnyc_plwatersanitary_domesticwatertank";
        public const string WaterNA = "dobnyc_plwatersanitary_na";
        public const string BackflowPreventerPrimary	="dobnyc_plwatersanitary_backflowprevprimary";
        public const string BackflowPreventerSecondary	="dobnyc_plwatersanitary_backflowprevsecondary";
        public const string WaterHeaterNonGas	="dobnyc_plwatersanitary_waterheaternongas";
        public const string PlumbingFixturesWater = "dobnyc_plwatersanitary_plumbingfixtures";
        public const string Pump = "dobnyc_plwatersanitary_pump";
        public const string WaterComponentsNA	="dobnyc_plwatersanitary_componentna";
 public const string BoosterPump = "dobnyc_plwatersanitary_boosterpump";
        public const string DomesticwaterpumpFillPump	="dobnyc_plwatersanitary_domesticwaterpump";
        public const string SpecifyVolumeofWater = "dobnyc_plstorm_volumeofwater";
        public const string WhatisthetotalNoofsprinklerheadsoffthedom	="dobnyc_plsp_totalnumofsprinklersinbuilding";
 public const string SpecifyDesignCriteria = "dobnyc_plsp_specifydesigncriteria";
        public const string OperatingPressure = "dobnyc_plgas_operatingpressure";
        public const string PlumbingScopeOfWorkCategory = "dobnyc_pl_category";

        public const string Antifreeze = "dobnyc_sp_antifreeze";
        public const string CirculatingClosedLoop = "dobnyc_sp_circulatingclosedloop";
        public const string CombinedDryPipePreaction = "dobnyc_sp_combineddrypipepreaction";
        public const string Deluge = "dobnyc_sp_deluge";
        public const string DryPipe = "dobnyc_sp_drypipe";
        public const string Gridded = "dobnyc_sp_gridded";
        public const string Looped = "dobnyc_sp_looped";
        public const string MultiCycle = "dobnyc_sp_multicycle";
        public const string Preaction = "dobnyc_sp_preaction";
        public const string WetPipe = "dobnyc_sp_wetpipe";
        public const string DryOpenPipe = "dobnyc_sp_dryopenpipe";
        public const string IsaDryPipeValverequired = "dobnyc_sp_isdrypipevalverequired";
        public const string IsthisaCombinedStandpipeSprinklerSystem = "dobnyc_spsd_iscombinedspsdsystem";
        public const string SPSDNFPA13 = "dobnyc_sp_nfpa13";
        public const string SPSDNFPA13D = "dobnyc_sp_nfpa13d";
        public const string SPSDNFPA13R = "dobnyc_plsp_nfpa13r";
        public const string SPSDNFPA20 = "dobnyc_spsd_nfpa20";
        public const string SPSDBoosterPump = "dobnyc_sp_boosterpump";
        public const string SpecialServicePump = "dobnyc_spsd_specialservicepump";
        public const string JockeyPump = "dobnyc_spsd_jockeypump";
        public const string StandpipeFirePump = "dobnyc_sp_standpipefirepump";
        public const string SPSDNA = "dobnyc_spsd_na";
        public const string DryStandpipeSystem = "dobnyc_drystandpipesystem";
        public const string ManualSDsystem = "dobnyc_manualsdsystem";
        public const string Semiautomatic = "dobnyc_semiautomatic";
        public const string WetSDsystemSpecify = "dobnyc_wetsdsystemspecify";
        public const string SPSDNFPA14 = "dobnyc_sd_nfpa14";
        public const string FirePump = "dobnyc_sd_firepump";

        public const string SpecifyClass = "dobnyc_sd_specifyclass";
        public const string SPSDChoosePrimaryWaterSystem = "dobnyc_spsd_chooseprimarywatersystem";
        public const string SPSDChooseSecondaryWaterSystem = "dobnyc_spsd_choosesecondarywatersystem";

        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";


    }
    public sealed class SPSDScopeOfWorkEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_spsdscopeofwork";
        public const string SPSDScopeOfWorkID = "dobnyc_spsdscopeofworkid";
        public const string GoToJobFiling = "dobnyc_spsdjobfilinglookup";
    }
    public sealed class SPSDCommonWorkOnFloorEntityAttribute
        {
        public const string EntityLogicalName = "dobnyc_spsdcommonworkonfloor";
        public const string SPSDCommonWorkonfloorId = "dobnyc_spsdcommonworkonfloorid";
        public const string GoToJobFiling = "dobnyc_spsdwof_wf_gotojobfiling";
        public const string GOTOSPSD = "dobnyc_spsdwof_gotospsd";
}
    public sealed class ScopeOfWorkonFloorEntityAttribute
    {
        public const string EntityLogicalName = "dobnyc_scopeofworkonfloor";
        public const string ScopeOfWorkonFloorID = "dobnyc_scopeofworkonfloorid";
        public const string GoToJobFiling = "dobnyc_jobfilinglookup";
        public const string GoToSPSD = "dobnyc_spsdscopeofworkid";
        public const string Workonfloorlookup = "dobnyc_workonfloorlookup";

    }


    public sealed class ScopeofWorkQuestionnaire
    {
        public const string EntityLogicalName = "dobnyc_scopeofworkquestionnaire";
        public const string Name = "dobnyc_name"; //SinglelineofText
        public const string GotoJobFiling = "dobnyc_common_jobfilingid"; //LookuptoJobFiling
        public const string SOWQuestionnaireId = "dobnyc_scopeofworkquestionnaireid";
        public const string HeatingEquipment= "dobnyc_common_heatingequipmentinputcapacitytotal";
        public const string CoolingEquipment = "dobnyc_common_coolingequipmentinputcapacityto";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";

    }



    public sealed class TR3TechinalReport
    {
        public const string EntityLogicalName = "dobnyc_tr3maintechnicalreport";
        public const string GoToJobFiling = "dobnyc_tr3jobfilingid";
        public const string ApplicantStatementChk = "dobnyc_tr3_chkboxdesignapplicantsign";
        public const string ApplicantStatementName = "dobnyc_tr3_designapplicantsignname";
        public const string ApplicantStatementDate = "dobnyc_tr3_designapplicantsigndate";
        public const string OwnerStatementChk = "dobnyc_tr3_chkbuildingowner";
        public const string OwnerStatementName = "dobnyc_tr3_buildingownername";
        public const string OwnerStatementDate = "dobnyc_tr3_buildingownerdate";

    }
    public sealed class TR3Directors
    {
        public const string EntityLogicalName = "dobnyc_tr3technicalreport";
        public const string GoToTR3 = "dobnyc_tr3technicalreport";
        public const string NRMCACertificationExpirationDate = "dobnyc_tr3_nrmca";
        public const string TR3DirectorEmail = "dobnyc_tr3dircontact_email";
        public const string BusinessName = "dobnyc_tr3_businessname";
        public const string LicenseNumber = "dobnyc_tr3_directorlicensenumber";
        public const string ConcreteProducerName = "dobnyc_tr3_concreteproducernamelookup";
        public const string ConcreteProducerBusinessName = "dobnyc_tr3_concreteproducerbusnamelookup";
        public const string ConcreteProducerLicNum = "dobnyc_tr3_concreteproducerlicensee";
        public const string ConcreteProducerSSName = "dobnyc_tr3_concreteproducername";
        public const string ConcreteProducerSSChk = "dobnyc_tr3_chkconcreteproducer";
        public const string ConcreteProducerSSDate = " dobnyc_tr3_concreteproducerdate";
        public const string ConcreteDirecotQulityManagerSSName = "dobnyc_tr3_concretetestinglabrespname";
        public const string ConcreteDirecotQulityManagerSSchk = "dobnyc_tr3_chkconcretetestinglabresp";
        public const string ConcreteDirecotQulityManagerSSDate = " dobnyc_tr3_concretetestinglabrespdate";
        public const string ModifiedAfterFile = "dobnyc_modifiedafterfile";



    }
    public sealed class TR3Mix
    {
        public const string EntityLogicalName = "dobnyc_tr3_mix";
        public const string ID = "dobnyc_tr3_mixid";
        public const string GoToTR3Directors = "dobnyc_tr3mix_gototrtechnicalreport";
        public const string RequiredStrength = "dobnyc_tr3mix_RequiredStrength";
        public const string SpecifiedStrength = "dobnyc_tr3mix_SpecifiedStrength";
        public const string SpecifiedTestAgeDays = "dobnyc_tr3mix_SpecifiedTestAge";
        public const string Method = "dobnyc_tr3mix_MethodofDeterminingProportions";
        public const string TrialPerformedOn = "dobnyc_tr3mix_datetrialmixtureperformed";
        public const string IsMixcreatedonPAA = "dobnyc_iscreatedonpaa";

    }
    public sealed class TR3MixIngredients
    {
        public const string EntityLogicalName = "dobnyc_tr3mixingredients";
        public const string GoToTR3 = "dobnyc_tr3mix";
        public const string TR3MixIngredientsid = "dobnyc_tr3mixingredientsid";
        public const string ASTMStandard = "dobnyc_tr3mixin_ASTMStandard";
        public const string lbs = "dobnyc_tr3mixin_lbs";
        public const string Materialsource = "dobnyc_tr3mixin_Materialsource";
        public const string MaterialType = "dobnyc_tr3mixin_MaterialType";
        public const string Types = "dobnyc_tr3mixin_Types";

    }

    public sealed class L2RequestAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_l2request";
        public const string Name = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_gotojobfiling"; 
        public const string TrackingNumber = "dobnyc_l2_trackingnumber"; //String
        public const string SequenceNumber = "dobnyc_l2_sequencenumber"; // Whole Number        
        public const string RequestStatus = "dobnyc_l2_requeststatus"; // Option Set
        public const string L2Fee = "dobnyc_l2_fee"; // Option Set
    }

    public sealed class JobFilingAuditAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_jobfilingaudit";
        public const string Name = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_jobfilingnumber";
        public const string AuditSequenceCounter = "dobnyc_auditcounter";

    }

    public sealed class BuildTraceHistory
    {
        public const string EntityLogicalName = "dobnyc_jobfilingtrace";
        public const string Name = "dobnyc_name";
        public const string Currentfilingstatus = "dobnyc_currentfilingstatus";
        public const string Person = "dobnyc_person";
        public const string Action = "dobnyc_jobtraceaction";
        public const string Comments = "dobnyc_comments";
        public const string RegardingAHV = "dobnyc_jt_gotoahv";
        public const string RegardingOP49 = "dobnyc_gotoop49";
        public const string RegardingLOC = "dobnyc_jt_gotoloc";
        public const string RegardingWorkPermit = "dobnyc_jt_gotoworkpermitpw2";
        public const string RegardingjobFiling = "dobnyc_regardingjobid";
        public const string Op49filingstatus = "dobnyc_op49filingstatus";
      
    }

    public sealed class ViolationsCodesAttributeNames
    {
        public const string EntityLogicalName = "dobnyc_violationscodes";
        public const string Name = "dobnyc_name";
        public const string GoToJobFiling = "dobnyc_gotojobfiling"; //Job Filing Lookup
        public const string GoToL2Request = "dobnyc_l2_gotol2request"; //L2 Request Lookup
        public const string ViolationNumber = "dobnyc_l2_violationnumber"; //String
        public const string L2Code = "dobnyc_l2_l2code"; //Option Set
        public const string REDTApplicant = "dobnyc_l2_redtapplicant"; //Contact Lookup
    }
}
