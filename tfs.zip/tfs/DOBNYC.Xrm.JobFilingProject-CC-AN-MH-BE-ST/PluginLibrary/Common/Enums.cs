using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Crm.Sdk;


using Microsoft.Xrm.Sdk;
namespace DOBNYC.XRM.JobFiling.Common
{

    public enum Borough
    {
        M = 1,
        Q = 4,
        S = 5,
        X = 2,
        B = 3

    }

    public enum VarianceType
    {
        Intial = 1,
        Renewal = 2

    }

    public enum ContextStage
    {
        Pre_validation = 10,
        Pre_operation = 20,
        MainOperation = 30,
        Post_operation = 40
    }

    public enum FilingTypes
    {
        IF = 1,
        PA = 2,
        SF = 3

    }

    public sealed class Fab4_TransactionCodes
    {
        public const string CheckBounceFee = "203";// "No Good Check processing Fee";// "203";
        public const string OVERAGE_PAYMENT = "212";//"Overage Payment";// "212";
        public const string ConstructionFence = "177";//"Filing Balance -Construction Fence";// "177";
        public const string SidewalkShed = "178"; // "Filing Balance -Sidewalk Shed";// "178";
        public const string SupportedScaffold = "179"; // "Filing Balance -Supported Scaffold";// "179";
        public const string Signs = "151";// "Filing Balance - Signs";// "151";
        public const string SignsPAA = "152";// "Filing Balance - Signs -PAA";// "152";
        public const string RecordManagement_123family = "198";// "Record management Fee: 1-2-3 family"; //"198"
        public const string RecordManagement_Others = "199";//"Record Management Fee: Other";// "199";
        public const string PAA = "123";// "Filing balance - Alt2 - PAA";// "123";
        public const string Legalization = "LEGALIZATION - 1-2-3 FAMILY";// "808";
        public const string LegalizationOther = "LEGALIZATION OTHER BUILDING";// "808";
        public const string LandmarkFee = "870";// "LANDMARKS COMMISSION FEE";// "870";
        public const string PLSPSD = "121";// "FILING BALANCE - ALTERATION 2";// "121";
        public const string AN = "121";//"FILING BALANCE - ALTERATION 2";// "121";
        public const string CC = "171";//"FILING BALANCE - CURB CUT";//"171";
        public const string BE = "129";// "BOILER FUEL EQUIPMENT & STORAGE";//129
        public const string Legalization12family = "LEGALIZATION - 1, 2 FAMILY"; //808
        public const string Legalization3familyOther = "LEGALIZATION - 3 FAMILY, OTHER"; //808
        public const string Op49Latefee = "854";// "Boiler notification-OP49 Late Penalty Fee"; //854
        public const string Op49FailuretoFile = "855";// "Boiler notification-OP49 Failure to File Penalty Filing Fees";//855
        public const string Op49FilingFee = "743";// "SELF-CERT REMOVAL / DISCONNECT (OP-49)"; //743
        public const string ST = "127";// "FILING BALANCE - ALTERATION TYPE 2"
        public const string MS = "126";// "FILING BALANCE - ALTERATION TYPE 2"
        public const string GC = "126";// "FILING BALANCE - ALTERATION TYPE 2"

    }

    public sealed class Electrical_TransactionCodes
    {
        public const string CheckBounceFee = "203";
        public const string OVERAGE_PAYMENT = "212";
        public const string Electrical = "121";
        public const string RecordManagement_123family = "198";
        public const string RecordManagement_Others = "199";
        public const string PAA = "123";

    }

    public enum RevertedtoDPfrom
    {
        None = 1,
        CPEIncomplete = 2,
        CPEObjections = 3,
        PEObjections = 4,
        QAFailed = 5,
        ProfCertQAFailed = 6
    }

    public enum TypeofPermit
    {
        Plumbing = 1,
        Sprinkler = 2,
        Standpipe = 3,
        Antenna = 4,
        CurbCut = 5,
        Sign = 7,
        SupportedScaffold = 8,
        SideWalkShed = 9,
        ConstructionFence = 10,
        BoilerEquipment = 11,
        Mechanical = 12,
        Structural = 13,
        GCMH = 15,
        GCST = 16,
        GCMHST = 17,
        GeneralConstruction = 14
    }

    public enum TypeofAHVPermit
    {
        CraneNotice = 17,
        OnsiteWaiver = 18,
        MasterRigger = 19
    }

    public enum QADecision
    {
        QAFailed = 1,
        PermitIssued = 2,
        RequiresL2 = 3
    }

    public enum DcoumentClass
    {
        Technical = 1,
        NonTechnical = 2
    }

    public enum ReviewActions : int
    {
        ApproveApplication = 1,
        ApproveObjections = 2,
        ModifiedApproveObjections = 3

    }


    public enum SignLocation : int
    {
        Ground = 1,
        Wall = 2,
        Roof = 3


    }
    public enum  BoilerEnergySource : int
    {
        Oil = 1,
        Gas = 2,
        Electric = 3,
        OilandGas=4



    }
    public enum SignType : int
    {
        Illuminated = 1,
        NonIlluminated = 2,


    }

    public enum Documentfor : int
    {
        JobFiling = 1,
        WorkPermit = 2,
        SpecialInspection = 3,
        ProgressInspection = 4,
        En2 = 5,
        AHV = 6,
        WithdrawalRequest = 7,
        SuprsedingRequest = 8
    }

    public enum DocumentStatus : int
    {
        Required = 1,
        Pending = 2,
        Accepted = 3,
        Rejected = 4,
        Submitted = 5,
        WaiverApproved = 6,
        WaiverRejected = 7,
        DeferralApproved = 14,
        DeferralRejected = 15,
        WaiverPendingPEAssignment = 25
    }

    public enum IsJobApplicationApproved : int
    {
        Approve = 625470000,
        Reject = 625470001,
        ReviewComplete = 1,

    }
    public enum JobStatus : int
    {
        JobinProcess = 1,
        PendingQAAssignmentforLOC = 2,
        QAReviewforLOC = 3,
        LOCIssued = 4,
        ObjectionstoLOC = 5,
        LOCTechnicalReview = 6,
        LOCRequested = 7

    }
    public enum BoilerScopeIncludes : int
    {
        Boiler = 1,
        FuelBurner = 2,
        FuelStorage = 3,


    }
    public enum BoilerScopeOfWorkType : int
    {
        NewInstallation = 1,
        Replacement = 2,
        Modification = 3,
        AbandoningofTank = 4,
        RemovalofTank = 5,
        Active = 6

    }
    public enum BoilerDeviceStatus : int
    {
        active = 1,
        workinprogress = 6,
        activePendingInspections = 7,
        voidRemoved = 4,
        Abandoned=8,
        Removed=9



    }
    public enum ExistingProposedOptionSet : int
    {
        Existing = 1,
        Proposed = 2,
       


    }
    public enum CurrentFilingStatus : int
    {
        PreFiling = 1,
        DesignProfessionalReview = 2,
        PendingPlanExaminer = 3,
        PlanExaminerReview = 4,
        CheifPlanExaminerReview = 5,
        Approved = 6,
        PendingQAAssignment = 7,
        QAReview = 8,
        QAFailed = 9,
        PermitIssued = 10,
        MinorPlanChangesDisapproved = 11,
        MinorPlanChangesApproved = 12,
        UpdatedPermitIssued = 13,
        FilingUpdated = 14,
        AdditionalPermitIssued = 15,
        OnHold = 16,
        Withdrawn = 17,
        SignedOff = 18,
        MinorMajorObjections = 19,
        Incomplete = 20,
        OnHold_NoGoodCheck = 21,
        PermitEntire = 22,
        PendingPlanExaminerReview = 23,
        PendingQAReview = 24,
        PendingProfCertQAAssignment = 25,
        PendingProfCertQAReview = 26,
        ProfCertQAinReview = 27,
        Rejected = 32,
        PendingCPEACPEAssignment = 33,
        PACOIssued = 34,
        PAAApproved = 37,
        PermitEntireBCDBCReview = 47,
        PermitEntireBCDBCReviewObjections=48,
        PendingL2Review = 50,
        L2ApprovedQAReview = 51,
        L2ApprovedProfCertQAReview = 52        
    }

    public enum WorkOnFloorsLocation : int
    {
        Attic = 1,
        balcony = 3,
        Floors = 17,
        Mezzanine = 5,
        Stairwells = 23,
    }

    public enum PACOReportStatus : int
    {
        PACONotRequested = 1,
        PreFiling = 2,
        ProfCertQAAssignment = 3,
        ProfCertQAReview = 4,
        QAFailed = 5,
        PACOIssued = 6,
        PAAApproved = 7

    }

    public enum FilingType : int
    {
        NewJobFiling = 1,
        PAA = 2,
        SubSq = 3
    }

    public enum MeetingStatus : int
    {
        Completed = 1,
        NoShow = 2,
        Canceled = 3
    }

    public enum InspectionStatus : int
    {
        PassFinal = 1,
        FailFinal = 2,
        NoAccessFinal = 3
    }

    public enum WorkpermitStatus : int
    {
        PendingQAAssignment = 1,
        QAReview = 2,
        QAFailed = 3,
        PermitIssued = 4,
        PermitRevoked = 5,
        PermitInactive = 6,
        PermitSignedoff = 7,
        PendingProfCertQAAssignment = 8,
        ProfCertQAReview = 9,
        AccelaWTSignoff = 10,
        PendingQAAssignmentforSignoff = 11,
        QAReviewforSignoff = 12,
        ObjectionstoSignoff = 13,
        PendingforSubmission = 14,
        PendingL2Review = 16,
        L2ApprovedProfCertQAReview = 17,
        L2ApprovedQAReview = 18
    }

    public enum AHVPermitStatus : int
    {
        PendingQAAssignment = 1,
        QAReview = 2,
        OnHold = 3,
        AHVPermitRejected = 4,
        AHVPermitIssued = 5,
        Approved = 6,
        PreFiling = 7,
        OnHoldTechnicalReview = 8,
        OnHoldNoGoodCheck = 9
    }

    public enum WithdrawalStatus : int
    {
        PendingQAAssignment = 1,
        QAReview = 2,
        WithdrawalofJobApproved = 3,
        WithdrawalofWorkTypeApproved = 4,
        WithdrawalofFilingApproved = 5,
        WithdrawalofDesignProfessionalApproved = 6,
        WithdrawalofContractorApproved = 7,
        PendingPlanExaminerAssignment = 8,
        PlanExaminerReview = 9,
        InspectionRequired = 10,
        WithdrawalofPostAprrovalAmendmentApproved = 11,
        QAFailed = 12,
        WithdrawalObjections = 13,
        WithdrawalofSpecialInspectionsApproved = 14,
        WithdrawalofProgressInspectionsApproved = 15,
        PreFiling = 16

    }

    public enum Withdrawalof : int
    {
        Job = 1,
        WorkType = 2,
        Filing = 3,
        PostApprovalAmendment = 4,
        DesignProfessional = 5,
        Contractor = 6,
        ProgressInspector = 7,
        SpecialInspector = 8
    }

    public enum AHVRequestStatus : int
    {
        PendingQAAssignment = 1,
        QAReview = 2,
        OnHold = 3,
        AHVPermitRejected = 4,
        AHVPermitIssued = 5,
        Approved = 6,
        PreFiling = 7
    }

    public enum AddressChangeStatus : int
    {
        PendingQAReview = 1,
        Approved = 2,
        Reject = 3
    }

    public enum PaymentHistoryFeeType : int
    {
        filingfee = 1,
        NoGoodCheck = 4,
        JobFiling = 33
    }

    public enum SupersedingStatus : int
    {
        PendingQAAssignment = 1,
        QAReview = 2,
        SupersedingDesignProfessionalApproved = 3,
        Objections = 4,
        SupersedingApplicantApproved = 5,
        PreFiling = 6,
        SupersedingofProgressInspectorApproved = 7,
        SupersedingofInspectorApproved = 8

    }

    public enum SupersedingRequestFor : int
    {
        DesignProfessional = 1,
        Contractor = 2,
        ProgressInspector = 3,
        SpecialInspector = 4

    }

    public enum ICrmServiceCredentialType
    {
        ImpersonatedUser = 1,
        Admin = 2,
        SystemAccount = 3
    }

    public enum PluginStage : int
    {
        PreValidation = 10,
        PreOperation = 20,
        MainOperation = 30,
        PostOperation = 40
    }

    public enum DefaultOpportunityOwnerType : int
    {
        Undefined = 0,
        CreatingUser = 1,
        SpecificUser = 2,
        SpecificTeam = 3,
        SpecificQueue = 4,
        DefaultAssignmentLogic = 5,
        RuleBased = 6
    }

    public enum DefaultTaskOwnerType : int
    {
        Undefined = 0,
        RegardingObjectOwner = 1,
        SpecificUser = 2,
        SpecificTeam = 3,
        CasePostingUser = 4,
        SpecificQueue = 5,
        ClosureChannel = 6
    }


    public enum OwnerTypeJobFiling : int
    {
        Individual = 1,
        Partnership = 2,
        SpecifNYCHAHHCicUser = 3,
        Corporation = 4,
        OtherGovernment = 5,
        NYCAgency = 6,
        CondoUnitOwnerorCoOpTenantshareholder = 7,
        NonProfit = 8,
        SCA=9
    }


    public enum TaskOutcomePostTaskStatus : int
    {
        Undefined = 0,
        CloseTaskCompleted = 1,
        CloseTaskCancelled = 2,
        NoAction = 3
    }

    public enum CustomerSegmentType : int
    {

        Corporate = 1,
        Retail = 2
    }

    public enum EscalationAuthorityType : int
    {
        USER = 1,
        TEAM = 2,
        QUEUE = 3,
        OWNERSMANAGER = 4
    }

    public sealed class TaskEntitySatus
    {
        public const int Open = 0;
        public const int Completed = 1;
        public const int Canceled = 2;
    }

    public sealed class BuildingType
    {
        public const int familyHouse123 = 1;
        public const int familyHouseOther = 2;

    }
    public sealed class FAB4BuildingType
    {
        public const int familyHouse1 = 1;
        public const int familyHouse2 = 2;
        public const int familyHouse3 = 3;
        public const int familyHouseOther = 4;

    }

    public sealed class JobType
    {
        public const int NewJob = 1;
        public const int Legal = 2;
        public const int NJLegal = 3;

    }

    public sealed class FeeType
    {
        public const int FilingFees = 1;
        public const int PermitRenewal = 2;
        public const int AHV = 3;
        public const int ElectricalAHV = 37;
        public const int CheckBounceFee = 4;
        public const int MultiStakeFeeTypeNB = 44;
        public const int MultiStakeFeeTypeBigAlt = 45;
        public const int MultiStakeFeeTypeMajoAlt = 46;
        public const int MultiStakeFeeTypeMinorAlt = 47;
        public const int OP49Fees = 53;
        public const int CraneAHV = 56;
    }

    public sealed class FeeConfigName
    {
        public const string GCMH_NewBuilding = "GCMH New Building 123";
        public const string GCMH_NB_Other_Less = "GCMH New Building Other -Less than 7 Stories";
        public const string GCMH_NB_Other_More = "GCMH New Building Other -More than 7 Stories";
        public const string PlaceOfAssembly = "Place Of Assembly";
        public const string TemporaryPlaceOfAssembly = "Temporary Place Of Assembly";
        public const string CheckBounceFeeConfig = "Check Bounce Fee";
        public const string BEScopeBoilerOtherFamily = "Boilers Build Boiler Scope Of Work Other Family";
        public const string BEScopeBoiler123Family = "Boilers Build Boiler Scope Of Work 123 Family";
        public const string BEScopeBoiler3Family = "Boilers Build Boiler Scope Of Work 3 Family";
        public const string MSOtherFamilyLessThan7Stories = "MS Other Family Less than 7 Stories";
        public const string MS123FamilyFees = "MS 123 Family Fees";
        public const string MS3FamilyFees = "MS 3 Family Fees";
        public const string MSOtherFamilyMorethan7Stories = "MS Other Family More than 7 Stories";
        public const string STOtherFamilyLessthan7Stories = "ST Build Fee Other Building Less than 7 Stories";
        public const string STOtherFamilyMorethan7Stories = "ST Build Fee Other Building More than 7 Stories";
        public const string ST123FamilyFees = "ST Build Fee 123 Family";
        public const string ST3FamilyFees = "ST Build Fee 3 Family";
        public const string PLSPSD123FamilyFees = "123 ALT2 Filing Fees";
        public const string PLSPSD3FamilyFees = "3 ALT2 Filing Fees";
        public const string PLSPSDOthersFamilyFees = "Other ALT2 Filing Fees";
        public const string CurbCut123FilingFees = "CurbCut 123 Filing Fees";
        public const string CurbCut3FilingFees = "CurbCut 3 Filing Fees";
        public const string CurbCutOtherFilingFees = "CurbCut Other Filing Fees";
        public const string FAB4_3Sign = "Fab4 3 Sign";
        public const string GC123FamilyFees = "ST Build Fee 123 Family";
        public const string GC3FamilyFees = "ST Build Fee 3 Family";
        public const string GCOtherFamilyLessthan7Stories = "ST Build Fee Other Building Less than 7 Stories";
        public const string GCOtherFamilyMorethan7Stories = "ST Build Fee Other Building More than 7 Stories";

    }

    public sealed class SharedVariableNames
    {
        public const string IsFeeExempt = "IsFeeExempt";
        public const string PHCreatUpdate = "PHCreatUpdate";
        public const string IsPaymentPosted = "IsPaymentPosted";
    }

    public sealed class FeeTypeName
    {
        public const string FilingFees = "Filing Fees";
        public const string PermitRenewal = "Permit Renewal";
        public const string AHV = "After Hour Variance";
        public const string CheckBounceFee = "Check Bounce Fee";
        public const string PAAFee = "PAA Fee";
        public const string InConjunctionFee = "In Conjunction Fee";
        public const string FilingFeeSchemaName = "dobnyc_filingfees";
        public const string LegalizationFeeSchemaName = "dobnyc_legalizationfilingfees";
        public const string CustomIsPaymentPosted = "CustomePaymentPosted";
        public const string IsPaa = "IsPaa";
        public const string CustomPhGuid = "CustomPhGUID";
        public const string ElectricalFilingFee = "Electrical Filing Fee";

    }


    public sealed class BuildingTypeName
    {
        public const string familyHouse123 = "123";
        public const string familyHouseOther = "Other";

    }

    public sealed class TransactionCodes
    {
        public const string AHVApplicationFee = "800";
        public const string AHVPermitFee = "801";
        public const string PAA = "123";
        public const string FilingBalance = "121";
        public const string PermitRenewal = "180";
        public const string RecordManagement123 = "198";
        public const string RecordManagementOther = "199";
        public const string CheckBounceFee = "203";
        public const string Legalization = "808";
        public const string Adjustment = "212";
        public const string FilingBalanceCurbCut = "171";
        public const string PATransCode = "161";
        public const string TPATransCode = "215";
    }

    public sealed class FormulaeName
    {
        public const string PAA = "PAA";
        public const string NoGoodCheckFee = "Check Bounce Fee";
        public const string PermitRenewalFee = "Permit Renewal";
        public const string Adjustment = "Adjustment";

    }
    public sealed class FeeSchemaNames
    {
        public const string LegalizationFeeSchemaName = "dobnyc_legalizationfilingfees";
        public const string NewFilingFeeSchemaName = "dobnyc_filingfees";
    }

    public sealed class GenericConstants
    {
        public const int StateCodeInactive = 1;
        public const int StateCodeActive = 0;
        public const int StatusCodeInactive = 2;
        public const int StatusCodeActive = 1;
        public const string StatusCode = "statuscode";

    }

    public enum LOCRequestStatus
    {
        Pre_Filing = 1,
        PendingQAAssignmentforLOC = 2,
        LOCTechnicalReview = 3,
        QAReviewforLOC = 4,
        LOCIssued = 5,
        Reject = 6
    }

    public enum OP49ReportStatus
    {
        Pre_Filing = 1,
        QASupervisorReview = 2,
        QAAdministratorReview = 3,
        Approved = 4,
        Rejected = 5,
        PendingInspections = 6
    }
    public enum LOCRejectedFrom
    {
        None = 1,
        LOCTechnicalReview = 2,
        LOCQAReview = 3
    }

    public enum WaiverDeferralType
    {
        Waiver = 1,
        Deferral = 2
    }

    public enum JobType_MultiStake : int
    {
        Alteration = 1,
        NewBuilings = 2


        ///1- Alteration - All exisitng production filing
        ///  2- Alternation(New) - All new alteration filings 
        ///  3- New Builings
    }

    public enum JobTypeNBorAlt : int
    {
        NewBuilings = 1,
        BigAlteration = 2,
        MajorAlteration = 3,
        MinorAlteration = 4
    }

    public enum NoOfStoriesAdjBuld : int
    {
        Lessthan7 = 1,
        From7to14 = 2,
        Morethan14 = 3
    }

    public enum HeightOfAdjBuld : int
    {
        Lessthan35 = 1,
        From35to75 = 2,
        From76to150 = 3,
        Morethan150 = 4
    }

    public sealed class DelegateEmailConfigKeys
    {
        public const string DelegateEmailSubjectTo = "DelegateEmailSubjectTo";
        public const string DelegateEmailSubject = "DelegateEmailSubject";
        public const string DelegateEmailSubjectCC = "DelegateEmailSubjectCC";
        public const string DelegateEmailSubjectTo_AddInspectors = "DelegateEmailSubjectTo_AddInspectors";
        public const string DelegateEmailSubjectCC_AddInspectors = "DelegateEmailSubjectCC_AddInspectors";
        public const string AddInspectors = "_AddInspectors";
        public const string AddTR3Stakeholders = "_AddTR3StakeHolders";
    }

    public enum InspectionComponentsDocumentRequirement : int
    {
        Conditional = 1,
        Optional = 2,
        Mandatory = 3,
        BE_SOW = 4,
        MS_SOW = 5,
        ST_SOW = 6,
        NA = 7
    }
    public enum UserfilingActionsOP49 : int
    {
        Save=1,
        Submit=2,
        PaytoFile=3
    }

    public enum BuildingTypeForL2
    {
        Family1= 1,
        Family2 = 2,
        Family3 = 3,
        Other = 4
    }

    public enum L2RequestStatus
    {
        PreFiling = 1,
        PendingCPEACPEAssignment = 2,
        PendingPEAssignment = 3,
        PEReview = 4,
        Approved = 5,
        Rejected = 6
    }

    public enum L2PEActions
    {
        Approved = 1,        
        Rejected = 2
    }

    public enum L2FeeValues
    {
        Family123Min = 600,
        FamilyOtherMin = 6000,
        Family123Max = 10000,
        FamilyOtherMax = 15000,
        Family123Times = 6,
        FamilyOtherTimes = 21
    }

    public enum ActualjobType : int
    {
        Alteration = 1,
        NoWork = 2,
        LimitedAlteration = 3,
        AlterationCofo = 4,
        NewBuilding = 5,
    }

    public sealed class L2RequestEmailsConfigKeys
    {
        public const string L2RequestApplicantEmailSubject = "L2RequestApplicantEmailSubject";
    }
}
