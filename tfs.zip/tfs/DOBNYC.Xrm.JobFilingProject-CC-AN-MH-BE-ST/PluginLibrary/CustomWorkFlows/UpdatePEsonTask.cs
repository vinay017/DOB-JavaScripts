﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using System.Activities;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.CustomWorkFlows
{
    public sealed class UpdatePEsonTask : CodeActivity
    {
        [Input("JobFiling")]
        [ReferenceTarget(JobFilingEntityAttributeName.EntityLogicalName)]
        public InArgument<EntityReference> JobFiling { get; set; }

        [Input("PPE")]
        [ReferenceTarget(SystemuserEntityAttributeNames.EntityName)]
        public InArgument<EntityReference> PPE { get; set; }

        [Input("SPE")]
        [ReferenceTarget(SystemuserEntityAttributeNames.EntityName)]
        public InArgument<EntityReference> SPE { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService crmTracing = (ITracingService)executionContext.GetExtension<ITracingService>();
            crmTracing.Trace("Trace - Start");
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;

            try
            {
                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                crmTracing.Trace("context - Start");
                if (context.Depth > 1)
                {
                    crmTracing.Trace("Depth greater than 1.");
                    return;
                }

                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
                crmTracing.Trace("Service - Initiated");
                EntityReference jobFilingNumber = JobFiling.Get<EntityReference>(executionContext);
                crmTracing.Trace("Job Filing Id: " + jobFilingNumber.Id.ToString());
                crmTracing.Trace("Job Filing Name: " + jobFilingNumber.Name.ToString());
                EntityReference primaryPE = PPE.Get<EntityReference>(executionContext);
                crmTracing.Trace("PPE Id: " + primaryPE.Id.ToString());
                crmTracing.Trace("PPE Name: " + primaryPE.Name.ToString());
                EntityReference secondaryPE = SPE.Get<EntityReference>(executionContext);
                crmTracing.Trace("SPE Id: " + secondaryPE.Id.ToString());
                crmTracing.Trace("SPE Name: " + secondaryPE.Name.ToString());

                if (jobFilingNumber == null || primaryPE == null || secondaryPE == null)
                {
                    crmTracing.Trace("Input Values shouldn't be null");
                    throw new Exception("Input Values shouldn't be null");
                }

                crmTracing.Trace("Updating Tasks with changed PE details - Start");
                QueryExpression qe = new QueryExpression();
                qe.EntityName = TaskEntityAttributeNames.EntityLogicalName;
                qe.ColumnSet.AddColumn(TaskEntityAttributeNames.ActivityIdAttributeName);
                qe.ColumnSet.AddColumn(TaskEntityAttributeNames.PrimaryPlanExaminer);
                qe.ColumnSet.AddColumn(TaskEntityAttributeNames.SecondaryPlanExaminer);
                qe.Criteria = new FilterExpression();
                qe.Criteria.AddCondition(TaskEntityAttributeNames.ClickheretogotoJobFiling, ConditionOperator.Equal, new Guid(jobFilingNumber.Id.ToString()));
                qe.Criteria.AddCondition(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, 0); //To Fetch Open Tasks

                EntityCollection taskEntities = service.RetrieveMultiple(qe);

                if (taskEntities.Entities.Count > 0)
                {
                    crmTracing.Trace("taskEntities.Entities.Count: " + taskEntities.Entities.Count);
                    crmTracing.Trace("Tasks found for given Job number.");
                    foreach (Entity taskObj in taskEntities.Entities)
                    {
                        taskObj[TaskEntityAttributeNames.StatusFieldName] = new OptionSetValue(2);
                        taskObj[TaskEntityAttributeNames.StatusReasonFieldName] = new OptionSetValue(-1);
                        crmTracing.Trace("Updating PPE and SPE - Start");
                        taskObj[TaskEntityAttributeNames.PrimaryPlanExaminer] = new EntityReference(SystemuserEntityAttributeNames.EntityName, primaryPE.Id);
                        crmTracing.Trace("Set PPE");
                        taskObj[TaskEntityAttributeNames.SecondaryPlanExaminer] = new EntityReference(SystemuserEntityAttributeNames.EntityName, secondaryPE.Id);
                        crmTracing.Trace("Set SPE");
                        service.Update(taskObj);
                    }                    
                }
                else
                {
                    crmTracing.Trace("No tasks found for given job: "+ jobFilingNumber.Id.ToString());
                }
                crmTracing.Trace("Updating Tasks with changed PE details - End");
                
            }
            catch (Exception ex)
            {
                throw new Exception("Exception found at action: UpdatePEsonTask with custom trace: " + customTrace.ToString() + " and exception: "+ ex.ToString());
            }            
        }
    }
}
