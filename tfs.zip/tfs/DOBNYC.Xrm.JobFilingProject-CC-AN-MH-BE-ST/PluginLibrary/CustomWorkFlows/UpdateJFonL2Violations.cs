﻿using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.CustomWorkFlows
{
    public sealed class UpdateJFonL2Violations : CodeActivity
    {

        [Input("L2Request")]
        [ReferenceTarget(L2RequestAttributeNames.EntityLogicalName)]
        public InArgument<EntityReference> L2Request { get; set; }

        [Input("JobFiling")]
        [ReferenceTarget(JobFilingEntityAttributeName.EntityLogicalName)]
        public InArgument<EntityReference> JobFiling { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            #region Variable Declaration.
            ITracingService crmTracing = context.GetExtension<ITracingService>();
            crmTracing.Trace("Trace - Start");
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = string.Empty;
            #endregion

            try
            {
                #region Context Initialization.
                IWorkflowContext wfContext = context.GetExtension<IWorkflowContext>();
                crmTracing.Trace("Workflow Context - Start");
                if (wfContext.Depth > 1)
                {
                    crmTracing.Trace("Depth greater than 1.");
                    return;
                }

                IOrganizationServiceFactory serviceFacroty = context.GetExtension<IOrganizationServiceFactory>();
                crmTracing.Trace("Service factory initiated.");
                IOrganizationService service = serviceFacroty.CreateOrganizationService(wfContext.UserId);
                crmTracing.Trace("Service initiated.");

                EntityReference l2RequestReference = L2Request.Get<EntityReference>(context);
                EntityReference jobFilingNumber = JobFiling.Get<EntityReference>(context);

                if (l2RequestReference == null)
                {
                    crmTracing.Trace("L2 Request is null");
                    throw new Exception("L2 Request is null. Further details: " + crmTracing);
                }

                crmTracing.Trace("L2 Request Id: " + l2RequestReference.Id);
                crmTracing.Trace("L2 Request Name: " + l2RequestReference.Name);
                #endregion

                #region Get All Violations related to L2 Request.
                QueryExpression qe = new QueryExpression();
                qe.EntityName = ViolationsCodesAttributeNames.EntityLogicalName;
                qe.ColumnSet.AddColumn(ViolationsCodesAttributeNames.ViolationNumber);
                qe.Criteria = new FilterExpression();
                qe.Criteria.AddCondition(ViolationsCodesAttributeNames.GoToL2Request, ConditionOperator.Equal, l2RequestReference.Id);
                EntityCollection violationsCodesEntities = service.RetrieveMultiple(qe);

                crmTracing.Trace("violationsCodesEntities.Entities.Count: " + violationsCodesEntities.Entities.Count);
                #endregion

                #region Update Violations Codes with Job Filing reference.

                if (violationsCodesEntities.Entities.Count > 0)
                {
                    foreach (Entity violationsCodesEntity in violationsCodesEntities.Entities)
                    {
                        crmTracing.Trace("Set Job Filing Reference - Start");
                        violationsCodesEntity[ViolationsCodesAttributeNames.GoToJobFiling] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFilingNumber.Id);
                        crmTracing.Trace("Set Job Filing Reference - End");
                        service.Update(violationsCodesEntity);
                    }
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw new Exception("Fault Exception found at action: UpdateJFonL2Violations with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
            catch (TimeoutException ex)
            {
                throw new Exception("Timeout Exception found at action: UpdateJFonL2Violations with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Exception found at action: UpdateJFonL2Violations with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
        }
        //protected override void Execute(CodeActivityContext context)
        //{
        //    throw new NotImplementedException();
        //}
    }
}
