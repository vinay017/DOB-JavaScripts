﻿using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.CustomWorkFlows
{
    public sealed class CloseJobFilingTasks: CodeActivity
    {
        [Input("JobFiling")]
        [ReferenceTarget(JobFilingEntityAttributeName.EntityLogicalName)]
        public InArgument<EntityReference> JobFiling { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            #region Variable Declaration
            ITracingService crmTracing = context.GetExtension<ITracingService>();
            crmTracing.Trace("Trace - Start");
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = string.Empty;
            #endregion

            try
            {
                #region Context Initialization
                IWorkflowContext wfContext = context.GetExtension<IWorkflowContext>();
                crmTracing.Trace("Workflow Context - Start");
                if (wfContext.Depth > 1)
                {
                    crmTracing.Trace("Depth greater than 1.");
                    return;
                }

                IOrganizationServiceFactory serviceFacroty = context.GetExtension<IOrganizationServiceFactory>();
                crmTracing.Trace("Service factory initiated.");
                IOrganizationService service = serviceFacroty.CreateOrganizationService(wfContext.UserId);
                crmTracing.Trace("Service initiated.");

                EntityReference jobFilingReference = JobFiling.Get<EntityReference>(context);

                if(jobFilingReference == null)
                {
                    crmTracing.Trace("Job Filing is null");
                    throw new Exception("Job filing is null. Further details: " + crmTracing);
                }

                crmTracing.Trace("Job Filing Id: " + jobFilingReference.Id);
                crmTracing.Trace("Job Filing Id: " + jobFilingReference.Name);
                #endregion

                #region Get All Tasks related to Job Filing
                QueryExpression qe = new QueryExpression();
                qe.EntityName = TaskEntityAttributeNames.EntityLogicalName;
                qe.ColumnSet.AddColumn(TaskEntityAttributeNames.ActivityIdAttributeName);
                qe.Criteria = new FilterExpression();
                qe.Criteria.AddCondition(TaskEntityAttributeNames.ClickheretogotoJobFiling, ConditionOperator.Equal, jobFilingReference.Id);
                qe.Criteria.AddCondition(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, 0); // Fetch All open tasks
                EntityCollection taskEntities = new EntityCollection();
                crmTracing.Trace("taskEntities.Entities.Count: " + taskEntities.Entities.Count);
                #endregion

                #region Close all open tasks

                if(taskEntities.Entities.Count > 0)
                {
                    foreach(Entity taskEntity in taskEntities.Entities)
                    {
                        taskEntity[TaskEntityAttributeNames.StatusFieldName] = new OptionSetValue(2);
                        crmTracing.Trace("Set Task statecode to Canceled");
                        taskEntity[TaskEntityAttributeNames.StatusReasonFieldName] = new OptionSetValue(6);
                        crmTracing.Trace("Set Task statuscode to Canceled");
                        service.Update(taskEntity);
                        crmTracing.Trace("Canceled task: " + taskEntity.Id);
                    }
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw new Exception("Fault Exception found at action: CloseJobFilingTasks with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
            catch (TimeoutException ex)
            {
                throw new Exception("Timeout Exception found at action: CloseJobFilingTasks with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                throw new Exception("Exception found at action: CloseJobFilingTasks with custom trace: " + customTrace + " and exception: " + ex.Message);
            }
        }
    }
}
