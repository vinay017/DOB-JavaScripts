﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WaiverDeferralJobFilingPostSubmit : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {
                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity.LogicalName.ToLower() == JobFilingEntityAttributeName.EntityLogicalName.ToLower() 
                    && context.MessageName.ToLower() == PluginHelperStrings.UpdateMessageName.ToLower() 
                    && context.Stage == (int)ContextStage.Post_operation)
                {
                    customTrace.AppendLine("Waiver deferral Job filing post submit");
                    if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted))
                    {
                        Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];

                        Entity imageForWaiverDeferral = (Entity)context.PostEntityImages["WaiverDeferral"];

                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) && !preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted))
                        { 
                            customTrace.AppendLine("Waiver deferral: begin");
                            WaiverDeferralHandler.CreateTasks(serviceConnector, imageForWaiverDeferral, customTrace, false, null);
                            customTrace.AppendLine("Waiver deferral: end");
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralJobFilingPostSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
