﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class DelegatesMailerPlugin : IPlugin
    {
        /// <summary>
        /// Plugin that adds Delegate associates in To or CC list of the emails, based on custom criteria.
        /// Register this plugin as Pre-Operation Synchronous Plug-In on Email Messages entity which is a core entity.
        /// </summary>

        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCRMUserId = string.Empty;
            Entity targetEntity = null;

            try
            {
                customTrace.AppendLine("Begin: Get Context for Delegates Email");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get Context for Delegates Email - Depth: " + context.Depth.ToString());

                currentCRMUserId = context.UserId.ToString();
                customTrace.AppendLine("Current CRM User Id: " + currentCRMUserId);

                customTrace.AppendLine("Begin: Get Service Connector");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End: Get Service Connector");

                customTrace.AppendLine("Begin: Get Entity from Context");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End: Get Entity from Context");

                customTrace.AppendLine("Target entity name: " + targetEntity.LogicalName);
              
                if (targetEntity == null || targetEntity.LogicalName != EmailEntityAttributeName.EntityLogicalName)
                {
                    return;
                }

                EntityReference regardingObject = (EntityReference)(targetEntity.Attributes[EmailEntityAttributeName.Regarding]);
                customTrace.AppendLine("Regarding entity name: " + regardingObject.LogicalName);
              
                if (!(regardingObject.LogicalName == JobFilingEntityAttributeName.EntityLogicalName || regardingObject.LogicalName == TR3MixEntityAttribute.EntityLogicalName || regardingObject.LogicalName == L2RequestAttributeNames.EntityLogicalName))
                {
                    return;
                }
               // throw new Exception("test");
                //Pre-Operational Email Creation
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) && context.Stage == 20)
                {
                    if (regardingObject.LogicalName== JobFilingEntityAttributeName.EntityLogicalName)
                    {
                        customTrace.AppendLine("Starting - Associating Delegates with Job Filing Emails.");
                        targetEntity = DelegatesEmailsHandler.JobFilingEmails_AddDelegates_Inspectors(serviceConnector, targetEntity, regardingObject, customTrace);
                        customTrace.AppendLine("Completed - Associating Delegates with Job Filing Emails.");
                    }
                    else if(regardingObject.LogicalName == TR3MixEntityAttribute.EntityLogicalName)
                    {
                        
                        FeeCalculationObject feeObject = new FeeCalculationObject();
                        EntityCollection ccList = new EntityCollection();
                        Entity TR3Mix = serviceConnector.Retrieve(TR3MixEntityAttribute.EntityLogicalName, regardingObject.Id, new ColumnSet(new string[] {TR3MixEntityAttribute.GotoTRTechnicalreport}));
                        customTrace.AppendLine("get JobFiling details from tr3 mix start");
                      
                        Entity JobFiling = FeeCalculationStandardizationHandler.GetJobfilingDetailsFromTR3Mix(serviceConnector, TR3Mix, customTrace, feeObject);

                        if(JobFiling!=null&& JobFiling.Id!=null)
                        {
                            #region Add Applicant to CC List
                            ccList = targetEntity.GetAttributeValue<EntityCollection>(EmailEntityAttributeName.Cc);
                            if(ccList==null)
                            {
                                ccList = new EntityCollection();
                            }
                            customTrace.AppendLine("ccList " + ccList.Entities.Count);
                            Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                            customTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                            toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, JobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ApplicantPerson).Id);
                            customTrace.AppendLine("Added Guid.");
                            ccList.Entities.Add(toParty);

                            customTrace.AppendLine("ccList " + ccList.Entities.Count);
                            targetEntity.SetAttributeValue(EmailEntityAttributeName.Cc, ccList);
                            

                            customTrace.AppendLine("Added Aplicant to cc.");
                            #endregion
                            #region Add Subject
                            string subject = @"New Attestations required for " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.ProjectNumberAttributeName) + @" / " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName) + @" / " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber) + @" " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.Street);
                            targetEntity[EmailEntityAttributeName.Subject] = subject;
                            customTrace.AppendLine("subject" + subject);
                            #endregion
                            customTrace.AppendLine("Added Guid.");
                            #region Update Body
                            string body= @"This email references " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.ProjectNumberAttributeName) + @" / " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName) + @" / " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber) + @" " + JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.Street) + Environment.NewLine + targetEntity.GetAttributeValue<string>(EmailEntityAttributeName.Description);
                            targetEntity[EmailEntityAttributeName.Description] = body;
                            customTrace.AppendLine("body" + body);
                            #endregion
                          
                            customTrace.AppendLine("Starting - Associating Delegates with Job Filing Emails.");
                           targetEntity = DelegatesEmailsHandler.JobFilingEmails_AddDelegates_Inspectors(serviceConnector, targetEntity, JobFiling.ToEntityReference(), customTrace);
                            customTrace.AppendLine("Completed - Associating Delegates with Job Filing Emails.");
                        }
                    }
                    else if(regardingObject.LogicalName == L2RequestAttributeNames.EntityLogicalName)
                    {
                        customTrace.AppendLine("Associate REDT PE/RA with L2 Applicant Emails - Start.");
                        targetEntity = DelegatesEmailsHandler.AddPERAInL2RequestEmails(serviceConnector, targetEntity, regardingObject, customTrace);
                        customTrace.AppendLine("Associate REDT PE/RA with L2 Applicant Emails - End.");
                    }
                    
                }
                
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception("fault" + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception("TimeoutException" + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception("Exception" + customTrace.ToString());
            }
            #endregion
        }
    }
}
