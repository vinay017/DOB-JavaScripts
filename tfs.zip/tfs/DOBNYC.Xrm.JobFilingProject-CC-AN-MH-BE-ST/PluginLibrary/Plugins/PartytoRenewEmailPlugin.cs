﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;
namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class PartytoRenewEmailPlugin : IPlugin
    {/// <summary>
     /// Register the Plugin on Place of Assembly Space Information
     ///     * (a) Post-Create Stage - Synchronous - Server - calling user - Exe order (1) - dobnyc_placeofassemblyspaceinformation (primary) - This step is used for setting up name of Place of Assembly Space Information
     ///        
     /// Register the Plugin on Place of Assembly Space Information
     ///     * (a) Post-Update Stage - Synchronous - Server - calling user - Exe order (1) - dobnyc_placeofassemblyspaceinformation (primary) - This step is used to Handle the submission of Place of Assembly Space Information applicationa nd setting the status on PACO
     ///           filtered attributes: dobnyc_pas_partytorenewthepacoifnotowner
     ///           preimage
     /// </summary>
     /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null, preImage = null;
            try
            {
                customTrace.AppendLine("Begin: PA/TPA Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End:  PA/TPA  Get context.. Depth: " + context.Depth.ToString());
                if(context.Depth>1)
                {
                    customTrace.AppendLine("End:  PA/TPA  Get context.. Depth: " + context.Depth.ToString());
                    return;
                }
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin  PA/TPA  GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin  PA/TPA GetServiceConnector..");
                customTrace.AppendLine("Begin  PA/TPA GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End  PA/TPA GetEntityFromContext..");
                customTrace.AppendLine("Target  PA/TPA Entity: " + targetEntity.LogicalName);
                if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName))
                    preImage = context.PreEntityImages[PluginHelperStrings.PreImageName];
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) && context.Stage == 40 && targetEntity.LogicalName==PlaceofAssemblySpaceInformation.EntityLogicalName)

                {
                    //if(targetEntity.Contains(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner)&&targetEntity[PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner]!=null)
                    //{
                    //    customTrace.AppendLine("Start partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.CreateMessageName);
                    //    EmailHandler.PACORenewEmail(serviceConnector, targetEntity, customTrace);
                    //    customTrace.AppendLine("End partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.CreateMessageName);
                    //}
                }
                else if(context.MessageName.ToUpper().Equals(PluginHelperStrings.UpdateMessageName.ToUpper()) && context.Stage == 40 && targetEntity.LogicalName == PlaceofAssemblySpaceInformation.EntityLogicalName)
                {
                    if (targetEntity.Attributes.Contains(PlaceofAssemblySpaceInformation.jobFilingID) && targetEntity[PlaceofAssemblySpaceInformation.jobFilingID] != null && (!preImage.Contains(PlaceofAssemblySpaceInformation.jobFilingID) ))
                    {
                        if (preImage.Attributes.Contains(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner))
                        {
                            Guid previousApplicant = ((EntityReference)preImage[PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner]).Id;

                            customTrace.AppendLine("1");
                            customTrace.AppendLine("Start partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);
                            EmailHandler.PACORenewEmail(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);

                        }

                    }
                   else if (targetEntity.Attributes.Contains(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner))
                    {
                        customTrace.AppendLine("PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner is present ");
                        Guid currentApplicant = ((EntityReference)targetEntity[PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner]).Id;
                        if (preImage.Attributes.Contains(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner))
                        {
                            Guid previousApplicant = ((EntityReference)preImage[PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner]).Id;
                            if (currentApplicant != previousApplicant)
                            {
                                customTrace.AppendLine("2");
                                customTrace.AppendLine("Start partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);
                                EmailHandler.PACORenewEmail(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);
                            }
                        }
                        else if (!preImage.Attributes.Contains(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner))
                        {
                            customTrace.AppendLine("3");
                            customTrace.AppendLine("Start partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);
                            EmailHandler.PACORenewEmail(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End partyToRenewThePACOifnotowner Email: " + PluginHelperStrings.UpdateMessageName);
                        }

                    }

                   

                }
                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PartytoRenewEmailPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
