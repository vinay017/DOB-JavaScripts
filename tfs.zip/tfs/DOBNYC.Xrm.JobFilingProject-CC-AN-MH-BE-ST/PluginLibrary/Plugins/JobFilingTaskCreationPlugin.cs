﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    public class JobFilingTaskCreationPlugin : IPlugin
    {
        /// <summary>
        /// Plugin generates the Job and Filing Number
        /// </summary>


        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                //if (context.Depth > 1)
                //    return;

                //customTrace.AppendLine("End GetEntityFromContext..");

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);                
                if (targetEntity == null || targetEntity.LogicalName != TaskEntityAttributeNames.EntityLogicalName)
                    return;


                EntityReference regardingObject = (EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId]);
                customTrace.AppendLine("Regarding Entity: " + regardingObject.LogicalName);
                
                #region Tasks Created for L2 Request
                if (regardingObject != null && regardingObject.LogicalName == L2RequestAttributeNames.EntityLogicalName)
                {

                    customTrace.AppendLine("Removing Task Status information");
                    targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                    targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName);

                    customTrace.AppendLine("AssociateDocumentsOnL2Tasks - Start");
                    JobFilingTaskHandler.AssociateDocumentsOnL2Tasks(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("AssociateDocumentsOnL2Tasks - End");
                    return;
                }
                #endregion

                /// If task is created regarding Job Filing
                if (regardingObject != null || regardingObject.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {

                    customTrace.AppendLine("Regarding Entity is Job Filing: " + targetEntity.LogicalName);

                    //Multiple Stakeholders - Central Assigner Task Creation: Start
                    #region Check the Current Filing Status and populate the document and objections required for Central Assigner Review
                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingCPEACPEAssignment)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName);

                        customTrace.AppendLine("Start Generating Documents for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnCATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Documents for CA: " + PluginHelperStrings.CreateMessageName);
                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);
                    }
                    #endregion
                    //Multiple Stakeholders - Central Assigner Task Creation: End

                    //PW1 Standardization - BCDBC Task Creation: Start
                    #region Check the Current Filing Status and populate the document and objections required for BC/DBC Review
                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PermitEntire) || (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PermitIssued) || (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReview))
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName);

                        customTrace.AppendLine("Start Generating Documents for BCDBC: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnBCDBCTask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Documents for BCDBC: " + PluginHelperStrings.CreateMessageName);
                    }
                    #endregion
                    //PW1 Standardization - BCDBC Task Creation: End

                    #region Check the Current Filing Status and populate the document and objections required for Cheif Plan Examiner Review
                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.CheifPlanExaminerReview || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingPlanExaminer)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Objections: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateObjectionsOnTask(serviceConnector, targetEntity, customTrace, true);
                        customTrace.AppendLine("EndGenerating Objections : " + PluginHelperStrings.CreateMessageName);

                        JobFilingTaskHandler.AssociateDocumentsOnCPETask(serviceConnector, targetEntity, customTrace);

                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);
                    }
                    #endregion

                    #region Check the Current Filing Status and populate the document and objections required for Plan Examiner Review
                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PlanExaminerReview)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Objections: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateObjectionsOnTask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("EndGenerating Objections : " + PluginHelperStrings.CreateMessageName);

                        JobFilingTaskHandler.AssociateDocumentsOnPETask(serviceConnector, targetEntity, customTrace);

                        JobFilingTaskHandler.AssociateDevicesOnPESPE(serviceConnector, targetEntity, customTrace);
                    }
                    #endregion

                    #region Associate Documents on QA Supervisor and QA Clerk Task forms

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PermitEntire || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PermitIssued
                        || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.Approved || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.OnHold)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);
                        //if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.WorkPermitStatus)) && (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value == (int)WorkpermitStatus.PendingQAAssignmentforSignoff || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value == (int)WorkpermitStatus.QAReviewforSignoff))
                        if (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value == (int)WorkpermitStatus.PendingQAAssignmentforSignoff || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value == (int)WorkpermitStatus.QAReviewforSignoff)
                        {
                            //JobFilingTaskHandler.AssociateDocumentsOnQATask_Signoff(serviceConnector, targetEntity, customTrace);
                            JobFilingTaskHandler.AssociateDocumentsOnQATask(serviceConnector, targetEntity, customTrace);
                        }
                        else
                            JobFilingTaskHandler.AssociateDocumentsOnQATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);

                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);

                    }
                    #endregion

                    #region Associate Documents on QA Supervisor and QA Clerk Task forms Superseding DP
                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSupersedingRequestmade) && targetEntity.Attributes.Contains(TaskEntityAttributeNames.SupersedingRequestfor))
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        bool IsSupersedingRequestmade = (bool)targetEntity.Attributes[TaskEntityAttributeNames.IsSupersedingRequestmade];
                        customTrace.AppendLine("IsSupersedingRequestmade: " + IsSupersedingRequestmade.ToString());
                        int supersedingfor = ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.SupersedingRequestfor]).Value;
                        customTrace.AppendLine("supersedingfor: " + supersedingfor.ToString());
                        if (IsSupersedingRequestmade == true && supersedingfor == (int)SupersedingRequestFor.DesignProfessional)
                        {
                            customTrace.AppendLine("Start Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);
                            JobFilingTaskHandler.AssociateDocumentsOnQATask(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);

                        }

                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);
                    }

                    #endregion

                    #region Associate Documents on QA Supervisor and QA Clerk Task forms LOC

                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus)) && (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.SignedOff))
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnQATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);


                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);

                    }
                    #endregion

                    #region Associate Documents on Prof Cert QA Supervisor and Prof Cert QA Clerk Task forms

                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus)) && (((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingProfCertQAReview || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingProfCertQAAssignment || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.ProfCertQAinReview || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview))
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnProfCertQATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);

                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);

                    }
                    #endregion

                    #region Associate WorkPermit on Prof Cert QA Clerk Task forms

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingProfCertQAAssignment || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.PendingProfCertQAReview || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.ProfCertQAinReview || ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating WorkPermit for QA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateWorkPermitsOnQATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating WorkPermit for QA: " + PluginHelperStrings.CreateMessageName);

                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);

                    }
                    #endregion

                    #region Associate Filings on QA LOC Task forms

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsLOCTaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsLOCTaskForm) == true)
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Filings for QA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateJobFilingsOnQATask(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Filings for QA: " + PluginHelperStrings.CreateMessageName);


                        customTrace.AppendLine("Start Generating DEvices for CA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDevicesOnAllTasks(serviceConnector, targetEntity, customTrace);

                    }
                    #endregion
                }

                #region If task is created regarding Withdrawal Request

                if (regardingObject != null || regardingObject.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Regarding Entity is Withdrawal Request: " + targetEntity.LogicalName);

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.WithdrawStatus))
                    {
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances
                        int withdrawalStatus = targetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.WithdrawStatus).Value;
                        customTrace.AppendLine("Start Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnTask_Withdrawal(serviceConnector, targetEntity, customTrace, withdrawalStatus);
                        customTrace.AppendLine("End Generating Documents for QA: " + PluginHelperStrings.CreateMessageName);

                    }

                }
                #endregion

                #region If task is created regarding Superseding Request

                if (regardingObject != null || regardingObject.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Regarding Entity is Superseding Request: " + targetEntity.LogicalName);

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.SupersedingRequestStatus))
                    {
                        int SupersedingRequestStatus = ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.SupersedingRequestStatus]).Value;
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Document: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnTask_Superseding(serviceConnector, targetEntity, customTrace, SupersedingRequestStatus);
                        customTrace.AppendLine("End Generating Document: " + PluginHelperStrings.CreateMessageName);

                    }
                }
                #endregion

                #region If task is created regarding Work Permit Request

                if (regardingObject != null || regardingObject.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Regarding Entity is WorkPermit Request: " + targetEntity.LogicalName);

                    if (targetEntity.Attributes.Contains(TaskEntityAttributeNames.WorkPermitStatus))
                    {
                        int WorkPermitRequestStatus = ((OptionSetValue)targetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value;
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusFieldName);
                        targetEntity.Attributes.Remove(TaskEntityAttributeNames.StatusReasonFieldName); // remove to avoid duplicate WF instances

                        customTrace.AppendLine("Start Generating Document: " + PluginHelperStrings.CreateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnTask_WorkPermit(serviceConnector, targetEntity, customTrace, WorkPermitRequestStatus);
                        customTrace.AppendLine("End Generating Document: " + PluginHelperStrings.CreateMessageName);

                    }
                }
                #endregion

                
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskCreationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }



    }
}
