﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;
using ExternalSystemIntegration.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class UpdateMHScopeofwork : IPlugin
    {
        /// <summary>
        /// When Optional Field's in MHScope of Work Entity are modified this Plugin wil clear checkbox, Signature Name and Date in Special Inspection category Entity.
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            #endregion
            try
            {
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != MHScopeofworkAttributeNames.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop       
              
                Entity preTargetEntity = new Entity(); 
                customTrace.AppendLine("Begin: PreImage MHScopeofwork");
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];

                Entity postTargetEntity = new Entity();
                if (context.PostEntityImages.Contains("PreImage"))
                    postTargetEntity = context.PostEntityImages["PreImage"];
                customTrace.AppendLine("Begin: PostImage MHScopeofwork");
                if (context.Depth > 2)
                    return;
                #endregion
                
                //if (context.MessageName.ToUpper() == "UPDATE")
                //{  
                //    if ((preTargetEntity.Attributes.Contains(MHScopeofworkAttributeNames.CertificationforLISTING)) || (preTargetEntity.Attributes.Contains(MHScopeofworkAttributeNames.ManufacturersName)) ||(preTargetEntity.Attributes.Contains(MHScopeofworkAttributeNames.ModelName)))
                //    {
                //        if ((preTargetEntity.Attributes[MHScopeofworkAttributeNames.ManufacturersName].ToString() != postTargetEntity.Attributes[MHScopeofworkAttributeNames.ManufacturersName].ToString()) || (preTargetEntity.Attributes[MHScopeofworkAttributeNames.CertificationforLISTING].ToString() != postTargetEntity.Attributes[MHScopeofworkAttributeNames.CertificationforLISTING].ToString()) || (preTargetEntity.Attributes[MHScopeofworkAttributeNames.ModelName].ToString() != postTargetEntity.Attributes[MHScopeofworkAttributeNames.ModelName].ToString()))
                //        {
                //            customTrace.AppendLine("UpdateTR1SpecialInspectionFields - Start");
                //            GCMHSTHandler.UpdateTR1SpecialInspectionFields(serviceConnector, targetEntity, customTrace);
                //            customTrace.AppendLine("UpdateTR1SpecialInspectionFields- End");
                //        }
                //    }
                //    }           
                }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "UpdateMHScopeofwork - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
