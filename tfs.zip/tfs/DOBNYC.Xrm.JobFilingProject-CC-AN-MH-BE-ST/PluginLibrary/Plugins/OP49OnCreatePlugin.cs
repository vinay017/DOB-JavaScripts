﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class OP49OnCreatePlugin : PluginHandlerBase, IPlugin
    /// <summary>
    /// OP49 On Creaet Plugin

    /// Register on Op49 Entity on Create
    /// Register on Pre-Create Stage

    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            customTrace.AppendLine("Pre Create OP49 start...");
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                    return;
                if (!targetEntity.LogicalName.Equals(OP49EntityAttributeNames.EntityLogicalName))
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);


                //this part runs for Pre-Create 
                #region Pre-Create Staging
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) &&
                    context.Stage == 20)
                {
                    #region Create Tracking Number
                    customTrace.AppendLine("Begin: Generate Tracking Number..");
                    targetEntity = JobNumberGenerator.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End: Generate Tracking Number..");
                    #endregion

                    //#region Set OP49 Initial Filing Fee
                    //customTrace.AppendLine("Begin: Setting OP49 Filing Fee");
                    //OP49FeeCalculationHandler.SetOP49InitialFee(serviceConnector, targetEntity, customTrace, feeObject);
                    //customTrace.AppendLine("End: Setting OP49 Filing Fee");
                    //#endregion
                    //#region set late Filing Fee and amount due
                    //if (targetEntity.Contains(OP49EntityAttributeNames.InspectionDate) && targetEntity[OP49EntityAttributeNames.InspectionDate] != null)
                    //    OP49FeeCalculationHandler.CalculateOP49LateFilingFee(serviceConnector, targetEntity, targetEntity, customTrace, feeObject);
                    //#endregion


                }
                #endregion

                #region Update Message
                if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                {
                    #region preimage check
                    customTrace.AppendLine("Begin Get Pre-Image..");
                    Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;

                    if (preImage == null)
                    {
                        customTrace.AppendLine("-- ERROR:::  Pre-Image NOT found..");
                        return;
                    }
                    #endregion

                    #region Pre-op-Submit logic -- If Submitted is true Change the Report status to QA SupervisorReview.
                    if (context.Stage == 20)
                    {
                        #region Is Submit Logic
                        if (targetEntity.Attributes.Contains(OP49EntityAttributeNames.IsSubmitted))
                        {

                            bool isSubmitted = targetEntity.GetAttributeValue<bool>(OP49EntityAttributeNames.IsSubmitted);
                            bool previsSubmitted = preImage.GetAttributeValue<bool>(OP49EntityAttributeNames.IsSubmitted);
                            if (isSubmitted && (isSubmitted != previsSubmitted))
                            {
                                customTrace.AppendLine("Update the Report status to QA SupervisorReview :Start");
                                CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.ReportStatus, new OptionSetValue((int)OP49ReportStatus.QASupervisorReview));
                                customTrace.AppendLine("Update the Report status to QA SupervisorReview : End:");
                                SubmitHandler.CreateBuildTrace(serviceConnector, targetEntity, preImage, "Filed", customTrace);

                                #region OP49 - Awaiting QA Admin Assignment
                                customTrace.AppendLine("OP49 - Awaiting QA Admin Assignment");
                                Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "OP49 - Awaiting QA Admin Assignment").Id.ToString());
                                customTrace.AppendLine("processId:  " + processId.ToString());
                                ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);
                                #endregion
                            }
                        }
                        #endregion

                        #region IF status(pre Image = prefiling and target = QA supervisor review) Then RUN workflow(OP49 - Master Workflow) Logic

                        if (targetEntity.Attributes.Contains(OP49EntityAttributeNames.ReportStatus))
                        {
                            int CurrentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(OP49EntityAttributeNames.ReportStatus).Value;
                            int previousReportStatus = preImage.GetAttributeValue<OptionSetValue>(OP49EntityAttributeNames.ReportStatus).Value;
                            if ((previousReportStatus != CurrentReportStatus) )
                            {
                                if (!(context.Depth > 2))
                                {
                                    customTrace.AppendLine("Start OP49 - Master Workflow");
                                    WorkFlowHandler.OP49MasterWorkflow(serviceConnector, targetEntity, customTrace);
                                    customTrace.AppendLine("End Executing OP49 – Master Workflow");
                                }

                                #region Create Build Trace - 4/17/2019
                                if(CurrentReportStatus == (int)OP49ReportStatus.Approved)
                                {
                                    SubmitHandler.CreateBuildTrace(serviceConnector, targetEntity, preImage, "Approved", customTrace);
                                }
                                if (CurrentReportStatus == (int)OP49ReportStatus.Rejected)
                                {
                                    SubmitHandler.CreateBuildTrace(serviceConnector, targetEntity, preImage, "Rejected", customTrace);
                                }
                                #endregion
                            }
                        }
                        #endregion

                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[OP49EntityAttributeNames.InspectorEMail])).Id.ToString())))
                        {

                            customTrace.AppendLine("OP49EntityAttributeNames.InspectorEMail is present ");
                            Guid currentOwner = ((EntityReference)targetEntity[OP49EntityAttributeNames.InspectorEMail]).Id;
                            if (preImage.Attributes.Contains(OP49EntityAttributeNames.InspectorEMail))
                            {
                                customTrace.AppendLine("OP49EntityAttributeNames.InspectorEMail is present for preImage");
                                if (!string.IsNullOrEmpty((((EntityReference)(preImage.Attributes[OP49EntityAttributeNames.InspectorEMail])).Id.ToString())))
                                {
                                    
                                    if (currentOwner != ((EntityReference)(preImage.Attributes[OP49EntityAttributeNames.InspectorEMail])).Id)
                                    {
                                        #region OP49 - Authorized Inspector Assignment
                                        customTrace.AppendLine("OP49 - Authorized Inspector Assignment");
                                        Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "OP49 - Authorized Inspector Assignment").Id.ToString());
                                        customTrace.AppendLine("processId:  " + processId.ToString());
                                        ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);
                                        #endregion
                                    }
                                }
                            }
                        }
                    }
                    #endregion
                  

                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "OP49OnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
