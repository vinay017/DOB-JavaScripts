﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class TR2TR3RequiredCheckPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCRMUserId = String.Empty;
            Entity targetEntity = null;
            Entity preTargetEntity = null;
            #endregion

            try
            {
                customTrace.AppendLine("Begin: Get Context.");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get Context - Depth: " + context.Depth.ToString());

                currentCRMUserId = context.UserId.ToString();
                customTrace.AppendLine("Current CRM User Id: " + currentCRMUserId);

                customTrace.AppendLine("Begin: Get Service Connector");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End: Get Service Connector");

                customTrace.AppendLine("Begin: Get Entity from Context");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End: Get Entity from Context");

                customTrace.AppendLine("Target Entity name: " + targetEntity.LogicalName);

                if (targetEntity == null)
                {
                    customTrace.AppendLine("Blank Target Entity.");
                    return;
                }

                if (context.Depth > 2)
                {
                    customTrace.AppendLine("Depth is greater than 1.");
                    return;
                }
                string MessageName = context.MessageName.ToUpper();

                //return if target entity has process and stageid
                if (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                {
                    customTrace.AppendLine("Update contains Stage and Process IDs.");
                    return;
                }

                if (targetEntity.LogicalName == ZoningCharactersticsPW1AttributeNames.EntityLogicalName)
                {                    
                    if (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper())
                    {
                        if (context.PreEntityImages.Contains("PreImage"))
                        {
                            preTargetEntity = context.PreEntityImages["PreImage"];
                        }
                        string jobFilingGuid = string.Empty;
                        int Filingtype = 0;
                        bool Issubmitted=false;
                        if (preTargetEntity.Contains(ZoningCharactersticsPW1AttributeNames.JobFilingGuid) && preTargetEntity[ZoningCharactersticsPW1AttributeNames.JobFilingGuid] != null)
                        {
                            jobFilingGuid = ((EntityReference)preTargetEntity[ZoningCharactersticsPW1AttributeNames.JobFilingGuid]).Id.ToString();
                            Guid filingguid = ((EntityReference)preTargetEntity[ZoningCharactersticsPW1AttributeNames.JobFilingGuid]).Id;
                            customTrace.AppendLine("JobFilingGuid: " + jobFilingGuid);
                            Entity Jobfiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, filingguid, new ColumnSet(true));

                             Filingtype = Jobfiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                             Issubmitted = Jobfiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted);
                        }
                        if (!string.IsNullOrEmpty(jobFilingGuid))
                        {

                            if ((preTargetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists) && preTargetEntity[ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists] != null) &&
                            (targetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists) && targetEntity[ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists] != null) &&
                            (preTargetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists)) &&
                            !(targetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR2TR3Exists)) && Filingtype == (int)FilingType.PAA)
                            {
                                customTrace.AppendLine("Deleting TR2 records based on the flag value - Start");
                                TR2TR3RequiredCheckHandler.DeleteTR2TR3Records(serviceConnector, jobFilingGuid, customTrace, true, true);
                                customTrace.AppendLine("Deleting TR2 records based on the flag value - End");
                            }

                            else if (Filingtype != (int)FilingType.PAA)
                            {


                                if ((preTargetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR2Required) && preTargetEntity[ZoningCharactersticsPW1AttributeNames.IsTR2Required] != null) &&
                                (targetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR2Required) && targetEntity[ZoningCharactersticsPW1AttributeNames.IsTR2Required] != null) &&
                                (preTargetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR2Required)) &&
                                !(targetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR2Required)))
                                {
                                    customTrace.AppendLine("Deleting TR2 records based on the flag value - Start");
                                    TR2TR3RequiredCheckHandler.DeleteTR2TR3Records(serviceConnector, jobFilingGuid, customTrace, true, false);
                                    customTrace.AppendLine("Deleting TR2 records based on the flag value - End");
                                }

                                if ((preTargetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR3Required) && preTargetEntity[ZoningCharactersticsPW1AttributeNames.IsTR3Required] != null) &&
                                    (targetEntity.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.IsTR3Required) && targetEntity[ZoningCharactersticsPW1AttributeNames.IsTR3Required] != null) &&
                                    (preTargetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR3Required)) &&
                                    !(targetEntity.GetAttributeValue<bool>(ZoningCharactersticsPW1AttributeNames.IsTR3Required)))
                                {
                                    customTrace.AppendLine("Deleting TR3 records based on the flag value - Start");
                                    TR2TR3RequiredCheckHandler.DeleteTR2TR3Records(serviceConnector, jobFilingGuid, customTrace, false, true);
                                    customTrace.AppendLine("Deleting TR3 records based on the flag value - End");
                                }
                            }

                        }
                    }
                }                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Fault Exception"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \n Timeout Exception" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Timeout Exceptipon"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR2TR3RequiredCheckPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \n General Exception" + (ex.InnerException != null ? ex.InnerException.ToString() : "No General Exception"), null);
                throw ex;
            }

        }
    }
}
