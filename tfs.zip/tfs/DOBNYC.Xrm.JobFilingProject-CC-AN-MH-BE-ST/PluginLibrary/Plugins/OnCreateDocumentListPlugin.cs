﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class OnCreateDocumentListPlugin : IPlugin
    {
        /// <summary>
        /// Plugin control DP Review status of Job Filing
        /// Register on Create of DocumentList
        /// </summary>

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                //if (context.Depth > 1)
                //    return;

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                #region On Create Context DP Review Validate
               
                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                   if(targetEntity.Attributes.Contains(DocumentListEntityAttributeName.Documentfor) && targetEntity.Attributes.Contains(DocumentListEntityAttributeName.PriortoStatus))
                    {
                        int documentFor = targetEntity.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.Documentfor).Value;
                        customTrace.AppendLine("documentFor: " + documentFor.ToString());
                        int priortoStatus = targetEntity.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.PriortoStatus).Value;
                        customTrace.AppendLine("priortoStatus: " + priortoStatus.ToString());
                       
                        if (documentFor == (int)Documentfor.JobFiling && priortoStatus == (int)CurrentFilingStatus.Approved)
                        {
                            if (targetEntity.Attributes.Contains(DocumentListEntityAttributeName.DocumentListtoJobfiling))
                            {
                                
                                Guid jobFilingGuid = ((EntityReference)targetEntity[DocumentListEntityAttributeName.DocumentListtoJobfiling]).Id;
                                customTrace.AppendLine("jobFilingGuid: " + jobFilingGuid.ToString());
                                
                                ColumnSet columns = new ColumnSet(JobFilingEntityAttributeName.FilingStatus);
                                Entity JobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, jobFilingGuid, columns);
                                if (JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.DesignProfessionalReview)
                                {
                                    customTrace.AppendLine("Started Updated Filing to prefiling ");
                                    Entity jobFiling = new Entity();
                                    jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PreFiling));
                                    serviceConnector.Update(jobFiling);
                                    customTrace.AppendLine("End Updated Filing to prefiling ");
                                    //throw new Exception("Test");
                                }
                            }

                        }

                    }                 
                   

                }
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OnCreateDocumentListPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
