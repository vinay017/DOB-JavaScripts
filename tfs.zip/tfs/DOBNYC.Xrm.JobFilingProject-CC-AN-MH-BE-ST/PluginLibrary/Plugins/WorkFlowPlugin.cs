﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WorkFlowPlugin : IPlugin
    {
        // Summary  Post Plugin -- needs to be registered on PostUpdate with PreImage.//
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

             
                //if (context.Depth > 2)   Keep it commmented
                //    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];

                 //JobFiling Workflows     // For now handled in FeeCalculation Plugin
                //if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                //{
                    
                //    customTrace.AppendLine("Start JobFiling Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                //    WorkFlowHandler.JobFilingWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                //    DOBLogger.WriteTraceLog("JobFilingWorkFlow", "SourceChannel", "Depth", context.Depth.ToString(), " Depth  trace log", "User ID", "UserBrowserInfo");
                //    customTrace.AppendLine("End JobFiling Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                //}

                // WorkPermit Workflows
                if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start WorkPermit Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.WorkPermitWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End WorkPermit Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

                // Withdrawal Workflows
                if (targetEntity.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start Withdrawal Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.WithdrawalWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End Withdrawal Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

                // Superseding Workflows
                if (targetEntity.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start Superseding Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.SupersedingWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End Superseding Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

                // Address Change Workflows
                if (targetEntity.LogicalName == AddressChangeRequestsEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  Address Change Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.AddressChangeWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End  Address Change Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

                // AHV Workflows
                if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  AHV Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.AHVWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End  AHV Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

                // LOC Workflows
                if (targetEntity.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start LOC Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                    WorkFlowHandler.LOCRequestWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);
                    customTrace.AppendLine("End LOC Workflow handler: " + PluginHelperStrings.UpdateMessageName);
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


    }
}
