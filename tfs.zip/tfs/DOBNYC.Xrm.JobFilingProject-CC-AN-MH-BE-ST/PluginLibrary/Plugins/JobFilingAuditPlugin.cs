﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
   public class JobFilingAuditPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variable Declaration
            //ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            #endregion

            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");

                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;
                customTrace.AppendLine("End GetEntityFromContext..");

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != JobFilingAuditAttributeNames.EntityLogicalName)
                    return;

                Entity preTargetEntity = new Entity();
                if (context.PreEntityImages.Contains("PreImage"))
                {
                    preTargetEntity = context.PreEntityImages["PreImage"];
                }

                #region Tracking Number on Create
                if (context.MessageName == PluginHelperStrings.CreateMessageName &&
                    context.Stage == 20)
                {
                    customTrace.AppendLine("JobFilingAuditNumberGenerator - Start");
                    if (targetEntity.Attributes.Contains(JobFilingAuditAttributeNames.GoToJobFiling))
                    {
                        customTrace.AppendLine("Start Generating Job Filing Audit Request Number: " + PluginHelperStrings.CreateMessageName);
                        JobFilingAuditPluginHandler.GenerateJobFilingAuditRequestNumber(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("End Generating Job Filing Audit  Request  Number: " + PluginHelperStrings.CreateMessageName);
                    }
                    else
                    {
                        customTrace.AppendLine("Job Filing Reference is a required field on Job Filing Audit request creation.");
                    }
                }
                else if (context.MessageName == PluginHelperStrings.UpdateMessageName &&
                    context.Stage == 40)
                {
                    customTrace.AppendLine("Set Job Filing Audit Counter Update - Start");
                    if (preTargetEntity.Attributes.Contains(JobFilingAuditAttributeNames.GoToJobFiling))
                    {
                        customTrace.AppendLine("Start Updating Job Filing Audit Request Number:  " + PluginHelperStrings.UpdateMessageName);
                        JobFilingAuditPluginHandler.GenerateJobFilingAuditRequestNumber(serviceConnector, targetEntity,preTargetEntity, customTrace);
                        customTrace.AppendLine("End Updating Job Filing Audit Request Number: " + PluginHelperStrings.UpdateMessageName);
                    }
                    else
                    {
                        customTrace.AppendLine("Job Filing Reference is a required field on Job Filing Audit request update.");
                    }
                    customTrace.AppendLine("Set Job Filing Audit Counter Update - End");
                }
                customTrace.AppendLine("JobFilingAuditNumberGenerator End");

                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - FaultException", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - TimeoutException", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - Exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAuditNumberGenerator - Execute - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
