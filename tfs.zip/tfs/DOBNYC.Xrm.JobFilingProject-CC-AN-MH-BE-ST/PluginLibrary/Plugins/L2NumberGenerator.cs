﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class L2NumberGenerator : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variable Declaration
            //ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            #endregion

            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");

                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;
                customTrace.AppendLine("End GetEntityFromContext..");

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != L2RequestAttributeNames.EntityLogicalName)
                    return;

                Entity preTargetEntity = new Entity();
                if (context.PreEntityImages.Contains("PreImage"))
                {
                    preTargetEntity = context.PreEntityImages["PreImage"];
                }

                #region Tracking Number on Create
                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    customTrace.AppendLine("L2NumberGenerator - Start");
                    if (targetEntity.Attributes.Contains(L2RequestAttributeNames.GoToJobFiling))
                    {
                        customTrace.AppendLine("Start Generating L2 Request Number: " + PluginHelperStrings.CreateMessageName);
                        L2NumberGeneratorHandler.GenerateL2RequestNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating L2 Request  Number: " + PluginHelperStrings.CreateMessageName);
                    }
                    else
                    {
                        customTrace.AppendLine("Job Filing Reference is a required field on L2 request creation.");
                    }
                }
                else if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                {
                    customTrace.AppendLine("L2 Fee Calculation on L2 Update - Start");
                    if (preTargetEntity.Attributes.Contains(L2RequestAttributeNames.GoToJobFiling))
                    {
                        customTrace.AppendLine("Start updating L2 with fee details: " + PluginHelperStrings.UpdateMessageName);
                        L2NumberGeneratorHandler.SetL2Fee(serviceConnector, preTargetEntity, customTrace);
                        customTrace.AppendLine("End Generating L2 Request  Number: " + PluginHelperStrings.UpdateMessageName);
                    }
                    else
                    {
                        customTrace.AppendLine("Job Filing Reference is a required field on L2 request update.");
                    }
                    customTrace.AppendLine("L2 Fee Calculation on L2 Update - End");
                }
                customTrace.AppendLine("L2NumberGenerator End");
                
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - FaultException", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - TimeoutException", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - Exception", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "L2NumberGenerator - Execute - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
