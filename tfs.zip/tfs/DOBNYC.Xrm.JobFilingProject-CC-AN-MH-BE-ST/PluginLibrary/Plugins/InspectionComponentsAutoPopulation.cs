﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class InspectionComponentsAutoPopulation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCRMUserId = String.Empty;
            Entity targetEntity = null;

            #endregion
            try
            {
                #region Declarations
                customTrace.AppendLine("Begin: Get Context for Auto population of Inspection Components.");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get Context for Auto population of Inspection Components - Depth: " + context.Depth.ToString());

                currentCRMUserId = context.UserId.ToString();
                customTrace.AppendLine("Current CRM User Id: " + currentCRMUserId);

                customTrace.AppendLine("Begin: Get Service Connector");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End: Get Service Connector");

                customTrace.AppendLine("Begin: Get Service");
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                customTrace.AppendLine("End: Get Service");
                

                customTrace.AppendLine("Begin: Get Entity from Context");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End: Get Entity from Context");

                customTrace.AppendLine("Target Entity name: " + targetEntity.LogicalName);
                #endregion

                #region Validations
                if (targetEntity == null)
                {
                    customTrace.AppendLine("Blank Target Entity.");
                    return;
                }

                if (context.Depth > 4)
                {
                    customTrace.AppendLine("Depth is greater than 1." + context.Depth);
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", null, customTrace.ToString(), null, null);
                    return;
                }
                string MessageName = context.MessageName.ToUpper();

                //return if target entity has process and stageid
                if (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                {
                    customTrace.AppendLine("Update contains Stage and Process IDs.");
                    return;
                }
                #endregion

                #region Initial Retrieve
                Entity preTargetEntity = new Entity();
                if (context.PreEntityImages.Contains("PreImage"))
                {
                    preTargetEntity = context.PreEntityImages["PreImage"];
                }

                bool IsHistoricJobFiling = false, isPAACreationCompleted = false, isPAAInProgress = false;

                int filingType = 0;
                bool isPAAFiling = false;
                string strJobFilingId = string.Empty;
                Entity jobFilingRecord = new Entity();
                GetJobFilingEntityColumnSet columnsSet = new GetJobFilingEntityColumnSet();

                //Job Filing Type Check - Start
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null)
                {
                    filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                    customTrace.AppendLine("Target contains Filing Type");
                }
                else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && preTargetEntity[JobFilingEntityAttributeName.FilingType] != null)
                {
                    filingType = ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                    customTrace.AppendLine("PreTarget contains Filing Type");
                }
                //Job Filing Type Check - End

                if (filingType == (int)FilingType.PAA)
                {
                    isPAAFiling = true;
                }
                #endregion

                #region SOWCommonWorkTypesEntityAttribute
                if (targetEntity.LogicalName == SOWCommonWorkTypesEntityAttribute.EntityLogicalName)
                {
                    //Inspections population for PAA - Start
                    if (targetEntity.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GoToJobFiling) && targetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling]).Id.ToString();
                        customTrace.AppendLine("Target contains Job Filing.");
                    }
                    else if (preTargetEntity.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GoToJobFiling) && preTargetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling]).Id.ToString();
                        customTrace.AppendLine("PreTarget contains Filing.");
                    }

                    if (!string.IsNullOrEmpty(strJobFilingId))
                    {
                        jobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(strJobFilingId), new ColumnSet(columnsSet.ColumnNames));
                        if (filingType == 0)
                        {
                            filingType = ((OptionSetValue)jobFilingRecord.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        }

                        if (filingType == (int)FilingType.PAA)
                        {
                            isPAAFiling = true;
                        }

                        if (!isPAACreationCompleted)
                        {
                            isPAACreationCompleted = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted);
                        }

                        if (isPAAInProgress)
                        {
                            isPAAInProgress = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress);
                        }
                    }
                    //Inspections population for PAA - End

                    if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                    {
                        customTrace.AppendLine("Populating Inspection Component Documents based on SOW trigger points - Start");
                        InspectionComponentsAutoPopulationHandler.PopulateBEMSSTInspectionComponents(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("Populating Inspection Component Documents based on SOW trigger points - End");
                    }
                }
                #endregion

                #region STScopeOfWorkEntityAttribute
                if (targetEntity.LogicalName == STScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    //Inspections population for PAA - Start
                    if (targetEntity.Attributes.Contains(STScopeOfWorkEntityAttribute.GoToJobFiling) && targetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                        customTrace.AppendLine("Target contains Job Filing.");
                    }
                    else if (preTargetEntity.Attributes.Contains(STScopeOfWorkEntityAttribute.GoToJobFiling) && preTargetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                        customTrace.AppendLine("PreTarget contains Filing.");
                    }

                    if (!string.IsNullOrEmpty(strJobFilingId))
                    {
                        jobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(strJobFilingId), new ColumnSet(columnsSet.ColumnNames));
                        if (filingType == 0)
                        {
                            filingType = ((OptionSetValue)jobFilingRecord.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        }

                        if (filingType == (int)FilingType.PAA)
                        {
                            isPAAFiling = true;
                        }

                        if (!isPAACreationCompleted)
                        {
                            isPAACreationCompleted = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted);
                        }
                        if (isPAAInProgress)
                        {
                            isPAAInProgress = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress);
                        }
                    }
                    //Inspections population for PAA - End

                    if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                    {
                        customTrace.AppendLine("Populating Inspection Component Documents based on ST SOW trigger points - Start");
                        InspectionComponentsAutoPopulationHandler.PopulateBEMSSTInspectionComponents(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("Populating Inspection Component Documents based on ST SOW trigger points - End");
                    }

                    customTrace.AppendLine("Populating ST SOW Required Document - Start");

                    if (jobFilingRecord.Id != Guid.Empty)
                    {
                        InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, jobFilingRecord, customTrace, false, isPAAFiling, false);
                        customTrace.AppendLine("ST SOW Populating Required Document - Inside End");
                    }
                    customTrace.AppendLine("ST SOW Populating Required Document - End");
                }
                #endregion

                #region MHScopeofworkAttributeNames
                if (targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName)
                {
                    //Inspections population for PAA - Start
                    if (targetEntity.Attributes.Contains(MHScopeofworkAttributeNames.GotoJobFiling) && targetEntity[MHScopeofworkAttributeNames.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[MHScopeofworkAttributeNames.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("Target contains Job Filing.");
                    }
                    else if (preTargetEntity.Attributes.Contains(MHScopeofworkAttributeNames.GotoJobFiling) && preTargetEntity[MHScopeofworkAttributeNames.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[MHScopeofworkAttributeNames.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("PreTarget contains Filing.");
                    }

                    if (!string.IsNullOrEmpty(strJobFilingId))
                    {
                        jobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(strJobFilingId), new ColumnSet(columnsSet.ColumnNames));
                        if (filingType == 0)
                        {
                            filingType = ((OptionSetValue)jobFilingRecord.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        }

                        if (filingType == (int)FilingType.PAA)
                        {
                            isPAAFiling = true;
                        }

                        if (!isPAACreationCompleted)
                        {
                            isPAACreationCompleted = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted);
                        }
                        if (isPAAInProgress)
                        {
                            isPAAInProgress = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress);
                        }
                    }
                    //Inspections population for PAA - End

                    if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                    {
                        customTrace.AppendLine("Populating MH SOW Inspection Component Documents based on MS SOW trigger points - Start");
                        InspectionComponentsAutoPopulationHandler.PopulateBEMSSTInspectionComponents(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("Populating BE SOW Inspection Component Documents based on MS SOW trigger points - End");
                    }

                    customTrace.AppendLine("Populating MS SOW Required Document - Start");

                    if (jobFilingRecord.Id != Guid.Empty)
                    {
                        InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, jobFilingRecord, customTrace, false, isPAAFiling, false);
                        customTrace.AppendLine("MS SOW Populating Required Document - End");
                    }

                }
                #endregion

                #region BEScopeOfWorkEntityAttribute
                if (targetEntity.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    //Inspections population for PAA - Start
                    if (targetEntity.Attributes.Contains(BEScopeOfWorkEntityAttribute.GotoJobFiling) && targetEntity[BEScopeOfWorkEntityAttribute.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[BEScopeOfWorkEntityAttribute.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("Target contains Job Filing.");
                    }
                    else if (preTargetEntity.Attributes.Contains(BEScopeOfWorkEntityAttribute.GotoJobFiling) && preTargetEntity[BEScopeOfWorkEntityAttribute.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[BEScopeOfWorkEntityAttribute.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("PreTarget contains Filing.");
                    }

                    if (!string.IsNullOrEmpty(strJobFilingId))
                    {
                        jobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(strJobFilingId), new ColumnSet(columnsSet.ColumnNames));
                        if (filingType == 0)
                        {
                            filingType = ((OptionSetValue)jobFilingRecord.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        }

                        if (filingType == (int)FilingType.PAA)
                        {
                            isPAAFiling = true;
                        }

                        if (!isPAACreationCompleted)
                        {
                            isPAACreationCompleted = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted);
                        }

                        if (isPAAInProgress)
                        {
                            isPAAInProgress = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress);
                        }
                    }
                    //Inspections population for PAA - End

                    if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                    {
                        customTrace.AppendLine("Populating BE SOW Inspection Component Documents based on BE SOW trigger points - Start");
                        InspectionComponentsAutoPopulationHandler.PopulateBEMSSTInspectionComponents(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("Populating BE SOW Inspection Component Documents based on BE SOW trigger points - End");
                    }

                    customTrace.AppendLine("Populating BE SOW Required Document - Start");

                    if (jobFilingRecord.Id != Guid.Empty)
                    {
                        InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, jobFilingRecord, customTrace, false, isPAAFiling, false);
                        customTrace.AppendLine("BE SOW Populating Required Document - End");
                    }
                }
                #endregion

                #region BoilerBuildDeviceDetailsEntityAttribute
                if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)
                {
                    //Inspections population for PAA - Start
                    if (targetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling) && targetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("Target contains Job Filing.");
                    }
                    else if (preTargetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling) && preTargetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling] != null)
                    {
                        strJobFilingId = ((EntityReference)preTargetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling]).Id.ToString();
                        customTrace.AppendLine("PreTarget contains Filing.");
                    }

                    if (!string.IsNullOrEmpty(strJobFilingId))
                    {
                        jobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(strJobFilingId), new ColumnSet(columnsSet.ColumnNames));
                        if (filingType == 0)
                        {
                            filingType = ((OptionSetValue)jobFilingRecord.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        }

                        if (filingType == (int)FilingType.PAA)
                        {
                            isPAAFiling = true;
                        }

                        if (!isPAACreationCompleted)
                        {
                            isPAACreationCompleted = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted);
                        }

                        if (isPAAInProgress)
                        {
                            isPAAInProgress = jobFilingRecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress);
                        }
                    }
                    //Inspections population for PAA - End

                    if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                        (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                    {
                        customTrace.AppendLine("Populating BE SOW Inspection Component Documents based on BE SOW trigger points - Start");
                        InspectionComponentsAutoPopulationHandler.PopulateBEMSSTInspectionComponents(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("Populating BE SOW Inspection Component Documents based on BE SOW trigger points - End");
                    }

                    customTrace.AppendLine("Populating BE SOW Required Document - Start");

                    if (jobFilingRecord.Id != Guid.Empty)
                    {
                        InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, jobFilingRecord, customTrace, false, isPAAFiling, false);

                        InspectionComponentsAutoPopulationHandler.PopulateBoilerBuildDeviceDocument(serviceConnector, jobFilingRecord, preTargetEntity, targetEntity, customTrace);
                        customTrace.AppendLine("BE SOW Populating Required Document - End");
                    }

                }
                #endregion

                #region TR2TechnicalReport
                if (targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName)
                {
                    customTrace.AppendLine("Populating TR2 Required Document - Start");
                    string JobFilingGuid = string.Empty;

                    if (preTargetEntity.Attributes.Contains(TR2TechnicalReport.GotoJobFiling))
                    {
                        customTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[TR2TechnicalReport.GotoJobFiling]).Id.ToString();
                    }
                    else if (targetEntity.Attributes.Contains(TR2TechnicalReport.GotoJobFiling))
                    {
                        customTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[TR2TechnicalReport.GotoJobFiling]).Id.ToString();
                    }
                    else
                    {
                        customTrace.AppendLine("No JobFiling Guid found.");
                        return;
                    }
                    customTrace.AppendLine("JobFiling Guid: " + JobFilingGuid);

                    bool isBCDBCTaskSubmitted = false;

                    //Is Historic JobFiling Check - Start
                    if (targetEntity.Attributes.Contains(TR2TechnicalReport.IsBCDBCTaskSubmitted) && targetEntity[TR2TechnicalReport.IsBCDBCTaskSubmitted] != null && targetEntity.GetAttributeValue<bool>(TR2TechnicalReport.IsBCDBCTaskSubmitted) == true)
                    {
                        isBCDBCTaskSubmitted = true;
                    }
                    else if (preTargetEntity.Attributes.Contains(TR2TechnicalReport.IsBCDBCTaskSubmitted) && preTargetEntity[TR2TechnicalReport.IsBCDBCTaskSubmitted] != null && preTargetEntity.GetAttributeValue<bool>(TR2TechnicalReport.IsBCDBCTaskSubmitted) == true)
                    {
                        isBCDBCTaskSubmitted = true;
                    }
                    //Is Historic JobFiling Check - End


                    if (!string.IsNullOrEmpty(JobFilingGuid))
                    {
                        if (!isPAAFiling)
                        {
                            isPAAFiling = InspectionComponentsAutoPopulationHandler.IsPAAFiling(serviceConnector, JobFilingGuid, customTrace);
                        }

                        //GetJobFilingEntityColumnSet columnsSet = new GetJobFilingEntityColumnSet();
                        Entity currentJobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid), new ColumnSet(columnsSet.ColumnNames));
                        customTrace.AppendLine("Job Filing Attribute count: " + currentJobFilingRecord.Attributes.Count);

                        InspectionComponentsAutoPopulationHandler.PopulateTR2RequiredDocuments(serviceConnector, currentJobFilingRecord, customTrace, true, isPAAFiling, isBCDBCTaskSubmitted);
                        customTrace.AppendLine("Populating Required Document - End");
                    }

                }
                #endregion

                #region ScopeofWorkQuestionnaire
                if (targetEntity.LogicalName == ScopeofWorkQuestionnaire.EntityLogicalName)
                {
                    customTrace.AppendLine("Populating SOW Required Document - Start");
                    string JobFilingGuid = string.Empty;

                    if (preTargetEntity.Attributes.Contains(ScopeofWorkQuestionnaire.GotoJobFiling))
                    {
                        customTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[ScopeofWorkQuestionnaire.GotoJobFiling]).Id.ToString();
                    }
                    else if (targetEntity.Attributes.Contains(ScopeofWorkQuestionnaire.GotoJobFiling))
                    {
                        customTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[ScopeofWorkQuestionnaire.GotoJobFiling]).Id.ToString();
                    }
                    else
                    {
                        customTrace.AppendLine("No JobFiling Guid found.");
                        return;
                    }
                    customTrace.AppendLine("JobFiling Guid: " + JobFilingGuid);

                    if (!string.IsNullOrEmpty(JobFilingGuid))
                    {
                        if (!isPAAFiling)
                        {
                            isPAAFiling = InspectionComponentsAutoPopulationHandler.IsPAAFiling(serviceConnector, JobFilingGuid, customTrace);
                        }

                        //GetJobFilingEntityColumnSet columnsSet = new GetJobFilingEntityColumnSet();
                        Entity currentJobFilingRecord = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid), new ColumnSet(columnsSet.ColumnNames));
                        customTrace.AppendLine("Job Filing Attribute count: " + currentJobFilingRecord.Attributes.Count);

                        InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, currentJobFilingRecord, customTrace, false, isPAAFiling, false);
                        customTrace.AppendLine("Populating Required Document - End");
                    }

                }
                #endregion

                #region JobFilingEntityAttributeName
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    //Is Historic JobFiling Check - Start
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                    {
                        IsHistoricJobFiling = true;
                        customTrace.AppendLine("Historic Filing");
                    }
                    else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && preTargetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                    {
                        IsHistoricJobFiling = true;
                        customTrace.AppendLine("Historic Filing");
                    }
                    //Is Historic JobFiling Check - End

                    //Is PAA Creation Completed - Start
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsPAACreationCompleted) && targetEntity[JobFilingEntityAttributeName.IsPAACreationCompleted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted) == true)
                    {
                        isPAACreationCompleted = true;
                        customTrace.AppendLine("From Target");
                    }
                    else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsPAACreationCompleted) && preTargetEntity[JobFilingEntityAttributeName.IsPAACreationCompleted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAACreationCompleted) == true)
                    {
                        isPAACreationCompleted = true;
                        customTrace.AppendLine("From PreTarget");
                    }
                    //Is PAA Creation Completed - End

                    //Is PAA In Progress - Start
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsPAAinProgress) && targetEntity[JobFilingEntityAttributeName.IsPAAinProgress] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress) == true)
                    {
                        isPAAInProgress = true;
                        customTrace.AppendLine("From Target");
                    }
                    else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsPAAinProgress) && preTargetEntity[JobFilingEntityAttributeName.IsPAAinProgress] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAinProgress) == true)
                    {
                        isPAAInProgress = true;
                        customTrace.AppendLine("From PreTarget");
                    }
                    //Is PAA In Progress - End

                    if (!IsHistoricJobFiling)
                    {
                        if ((MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && !isPAAFiling) ||
                            (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && !(isPAAFiling) && !(isPAACreationCompleted) && !(isPAAInProgress)) ||
                            (MessageName == PluginHelperStrings.UpdateMessageName.ToUpper() && (isPAAFiling) && (isPAACreationCompleted)))
                        {
                            customTrace.AppendLine("Populating Inspection Component Documents based on JF trigger points - Start");
                            InspectionComponentsAutoPopulationHandler.PopulateInspectionComponents(serviceConnector, targetEntity, filingType, customTrace);
                            customTrace.AppendLine("Populating Inspection Component Documents based on JF trigger points - End");
                        }

                        if (MessageName == PluginHelperStrings.CreateMessageName.ToUpper() && isPAAFiling)
                        {
                            customTrace.AppendLine("Populating Required Documents based on trigger points - Start");
                            InspectionComponentsAutoPopulationHandler.CloneParentDocumentsOnPAA(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("Populating Required Documents based on trigger points - End");
                        }
                        else
                        {
                            customTrace.AppendLine("Populating Required Documents based on trigger points - Start");
                            InspectionComponentsAutoPopulationHandler.PopulateRequiredDocuments(serviceConnector, targetEntity, customTrace, false, isPAAFiling, false);
                            customTrace.AppendLine("Populating Required Documents based on trigger points - End");
                        }

                        #region BCDBC Record Handling

                        //customTrace.AppendLine("targetEntity.Id: " + targetEntity.Id);
                        //bool isBCDBCTaskSubmitted = false;
                        //ColumnSet columns = new ColumnSet(true);
                        //targetEntity = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, columns);
                        
                        //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus) && targetEntity[JobFilingEntityAttributeName.FilingStatus] != null)
                        //{
                        //    if(targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReviewObjections)
                        //    {
                        //        isBCDBCTaskSubmitted = true;
                        //        customTrace.AppendLine("isBCDBCTaskSubmitted: True");
                        //    }                            
                        //}
                                              
                        //InspectionComponentsAutoPopulationHandler.PopulateTR2RequiredDocuments(serviceConnector, targetEntity, customTrace, true, isPAAFiling, isBCDBCTaskSubmitted);
                        //customTrace.AppendLine("Populating Required Document - End");
                        #endregion
                    }
                    else
                    {
                        customTrace.AppendLine("Old filing flow.");
                        return;
                    }
                }
                #endregion

                #region L2 Request  - Violations Codes
                if (targetEntity.LogicalName == ViolationsCodesAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("Populating Documents for L2 Request - Start");                    
                    InspectionComponentsAutoPopulationHandler.PopulateL2Documents(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("Populating Documents for L2 Request - End");
                }
                #endregion

                #region L2 Request
                if (targetEntity.LogicalName == L2RequestAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("Populating Documents for L2 Request - Start");
                    InspectionComponentsAutoPopulationHandler.PopulateL2DocumentsforViolations(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("Populating Documents for L2 Request - End");
                }
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulation - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
        }
    }
}