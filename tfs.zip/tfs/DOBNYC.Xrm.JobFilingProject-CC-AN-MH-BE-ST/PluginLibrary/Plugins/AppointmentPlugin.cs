﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    public class AppointmentPlugin : IPlugin
    {
        /// <summary>
        /// Plugin control Status of Appointments
        /// </summary>


        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != AppointmentAttributeName.EntityLogicalName)
                    return;

                customTrace.AppendLine("context.MessageName: " + PluginHelperStrings.UpdateMessageName);

                #region Is Completed
                if (targetEntity.Attributes.Contains(AppointmentAttributeName.IsCompleted))
                    {
                        bool isCompleted = targetEntity.GetAttributeValue<bool>(AppointmentAttributeName.IsCompleted);
                        if (isCompleted == true)
                        {
                            ColumnSet columns = new ColumnSet(true);
                            Entity response = serviceConnector.Retrieve(AppointmentAttributeName.EntityLogicalName, targetEntity.Id, columns);
                            int meetingStatus = response.GetAttributeValue<OptionSetValue>(AppointmentAttributeName.MeetingStatus).Value;
                            #region Setting Status
                            if (meetingStatus == (int)MeetingStatus.Completed)
                            {
                               SetStateRequest setStateRequest = new SetStateRequest()
                                {
                                    EntityMoniker = new EntityReference
                                    {
                                        Id = targetEntity.Id,
                                        LogicalName = AppointmentAttributeName.EntityLogicalName,
                                    },
                                    State = new OptionSetValue(1),
                                    Status = new OptionSetValue(3)
                                };
                                serviceConnector.Execute(setStateRequest);
                            }
                            if (meetingStatus == (int)MeetingStatus.Canceled || meetingStatus == (int)MeetingStatus.NoShow)
                            {
                                SetStateRequest setStateRequest = new SetStateRequest()
                                {
                                    EntityMoniker = new EntityReference
                                    {
                                        Id = targetEntity.Id,
                                        LogicalName = AppointmentAttributeName.EntityLogicalName,
                                    },
                                    State = new OptionSetValue(2),
                                    Status = new OptionSetValue(4)
                                };
                                serviceConnector.Execute(setStateRequest);
                            }
                            #endregion

                        }

                    }
                #endregion
                if (targetEntity.Attributes.Contains(AppointmentAttributeName.IsReschedule))
                {
                    bool isReschedule = targetEntity.GetAttributeValue<bool>(AppointmentAttributeName.IsReschedule);
                    if (isReschedule == true)
                    {
                         SetStateRequest setStateRequest = new SetStateRequest()
                            {
                                EntityMoniker = new EntityReference
                                {
                                    Id = targetEntity.Id,
                                    LogicalName = AppointmentAttributeName.EntityLogicalName,
                                },
                                State = new OptionSetValue(3),
                                Status = new OptionSetValue(5)
                            };
                            serviceConnector.Execute(setStateRequest);
                    }

                }

                #region Is Reschedule


                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AppointmentPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        } // method ends here

    } //class ends here
}
