﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class BoilerBuildDeviceDetailsOnCreatePlugin : IPlugin
    {
        /// <summary>
        /// BoilerBuildDeviceDetails On Creaet Plugin
        /// Register on BoilerBuildDeviceDetails Entity on Create
        /// FuelBurnerMaster Device  On Create
        /// FuelStorageMasterDevice On Create
        /// Register on Pre-Create Stage

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = null;
            customTrace.AppendLine("Pre Create BoilerBuildDeviceDetailsOnCreatePlugin start...");
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                    return;
                if (!(targetEntity.LogicalName.Equals(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)|| targetEntity.LogicalName.Equals(ManageBoilerRequest.EntityLogicalName)||targetEntity.LogicalName.Equals(FulelBurnerMaster.EntityLogicalName)||targetEntity.LogicalName.Equals(FulelStorageMaster.EntityLogicalName)))
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);


                //this part runs for Pre-Create 
                #region Pre-Create Staging
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) &&
                    context.Stage == 20)
                {
                    #region Create Tracking Number
                    customTrace.AppendLine("Begin: Generate Tracking Number..");
                    targetEntity = JobNumberGenerator.GenerateAutoNumber(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End: Generate Tracking Number..");
                    #endregion
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "BoilerBuildDeviceDetailsOnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}

