﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using System.ServiceModel;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class PAARelatedFilingRecordPlugin : IPlugin
    {
        /// <summary>
        /// Async Post Create of Job Filing
        /// Plugin Handles related filing record creation in case of PL,SP,SD PAA creation.
        /// 11/20/2017
        /// </summary>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;

                customTrace.AppendLine("context.MessageName: " + context.MessageName);


                if (targetEntity.Contains(JobFilingEntityAttributeName.JobFilingNumAttribute) && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                {
                    string JobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                    customTrace.AppendLine("JobNumber: " + JobNumber);
                    string FilingNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                    customTrace.AppendLine("FilingNumber: " + FilingNumber);
                    int filingCount = Convert.ToInt32( FilingNumber.Substring(1, 1));
                    customTrace.AppendLine("filingCount: " + filingCount);
                    int Count = filingCount;
                    Guid ParentJobGuid = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;
                    customTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());
                    int filingType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                    customTrace.AppendLine("filingType: " + filingType);
                    if (filingType != (int)FilingType.PAA)
                        return;
                    // StringBuilder crmTrace = new StringBuilder();
                    FeeCalculationObject targetFCObject = new FeeCalculationObject();
                    FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(targetEntity, targetFCObject, customTrace);

                    //if ((targetEntity.Contains(JobFilingEntityAttributeName.PlumbingCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.SprinklerCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.StandPipeWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))
                    //    || (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox)))

                    // throw new Exception(targetFCObject.IsPL.ToString)

                     if(targetFCObject.IsBE || targetFCObject.IsMS || targetFCObject.IsST || targetFCObject.IsPL || targetFCObject.IsSP || targetFCObject.IsSD || targetFCObject.IsCC || targetFCObject.IsAN || targetFCObject.IsFN || targetFCObject.IsSH || targetFCObject.IsSF || targetFCObject.IsSG || targetFCObject.IsPA || targetFCObject.IsTPA || targetFCObject.IsEL)                  
                    {
                    #region Create Related Filng PAA Record
                    if (context.MessageName == MessageName.Create)
                        {
                            #region Get Counter Value
                            string fetch = "";
                            EntityCollection PAARecords = new EntityCollection();
                            fetch = string.Format(FetchXml.GetPAARecordsCount, JobNumber);
                            customTrace.AppendLine("fetch: " + fetch);
                            if (fetch != null)
                            {
                                PAARecords = serviceConnector.RetrieveMultiple(new FetchExpression(fetch));
                            }
                            if (PAARecords.Entities != null)
                            {
                                customTrace.AppendLine("PAARecords.Entities: " + PAARecords.Entities.Count);
                                Count = PAARecords.Entities.Count > 0 ? Convert.ToInt32(((Microsoft.Xrm.Sdk.AliasedValue)PAARecords.Entities[0].Attributes[RelatedFilngs.Counter]).Value)+1 : filingCount;
                            }
                                #endregion
                                Entity RelatedFilng = new Entity();
                            customTrace.AppendLine("Start Creating Related Filngs Record PAA Type: Start");
                            RelatedFilng.LogicalName = RelatedFilngs.EntityLogicalName;
                            RelatedFilng.Attributes.Add(RelatedFilngs.JobNumber, JobNumber);
                            RelatedFilng.Attributes.Add(RelatedFilngs.Name, JobNumber + "-" + FilingNumber);
                            RelatedFilng.Attributes.Add(RelatedFilngs.FilingType, new OptionSetValue(filingType));
                            RelatedFilng.Attributes[RelatedFilngs.JobFilingId] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                            RelatedFilng.Attributes.Add(RelatedFilngs.ParentGUID, ParentJobGuid.ToString());
                            RelatedFilng.Attributes.Add(RelatedFilngs.SchemaName, JobFilingEntityAttributeName.EntityLogicalName);
                            RelatedFilng.Attributes.Add(RelatedFilngs.Counter, Count);
                            customTrace.AppendLine("test1");
                           // throw new Exception(JobNumber.ToString() + filingType.ToString() + targetEntity.Id.ToString() + "rr" + ParentJobGuid.ToString() + "--" + Count.ToString());
                            serviceConnector.Create(RelatedFilng);
                            customTrace.AppendLine("Start Creating Related Filngs Record PAA Type: End");
                        }
                        #endregion
                    }
                }
                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - TEST", null, customTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAARelatedFilingRecordPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}