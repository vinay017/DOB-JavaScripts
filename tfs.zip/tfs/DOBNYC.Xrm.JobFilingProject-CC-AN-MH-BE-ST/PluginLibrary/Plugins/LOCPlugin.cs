﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class LOCPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                //Entity preImage = new Entity();

                //if (context.PreEntityImages.Contains("PreImage"))
                //    preImage = context.PreEntityImages["PreImage"];

                #region On Create Pre_operation

                if (context.MessageName == PluginHelperStrings.CreateMessageName && context.Stage == (int)ContextStage.Pre_operation)
                {
                    if (targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.GotoJobFiling))
                    {

                        customTrace.AppendLine("Tracking Number Started:" + PluginHelperStrings.CreateMessageName);
                        targetEntity = JobFilingLOCHandler.GenerateLOCNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("Tracking Number end:" + PluginHelperStrings.CreateMessageName);
                    }
                }
                #endregion

                #region Is Submitted Logic
                if (context.MessageName == PluginHelperStrings.UpdateMessageName && context.Stage == (int)ContextStage.Pre_operation)
                {
                    Entity preImage = new Entity();

                    if (context.PreEntityImages.Contains("PreImage"))
                        preImage = context.PreEntityImages["PreImage"];

                    if (targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.IsSubmitted) && preImage.Attributes.Contains(LOCPW7EntityAttributeName.IsSubmitted))
                    {
                        if (targetEntity.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted) != preImage.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted))
                        {
                            bool isSubmitted = targetEntity.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted);
                            if (isSubmitted)
                            {
                                customTrace.AppendLine("Start LOC Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                                targetEntity = SubmitHandler.LOCRequestSubmit(serviceConnector, targetEntity, preImage, customTrace);
                                customTrace.AppendLine("End LOC Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                            }
                        }
                    }
                }
                #endregion

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOCPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString()); ;
            }
        }
    }
}
