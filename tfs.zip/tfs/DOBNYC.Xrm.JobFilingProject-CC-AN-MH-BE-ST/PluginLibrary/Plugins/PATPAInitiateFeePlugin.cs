﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class PATPAInitiateFeePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: PA/TPA Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End:  PA/TPA  Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin  PA/TPA  GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin  PA/TPA GetServiceConnector..");
                customTrace.AppendLine("Begin  PA/TPA GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End  PA/TPA GetEntityFromContext..");
                customTrace.AppendLine("Target  PA/TPA Entity: " + targetEntity.LogicalName);
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) && context.Stage == 40)
                {
                    #region PA/TPA
                    if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox)) ||
                        (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))))
                    {
                        Entity PATPAEntity = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                        customTrace.AppendLine("targetEntity.Id != null" + targetEntity.Id);

                        if (targetEntity.Id != null)
                        {
                            PATPAEntity.Id = targetEntity.Id;
                            customTrace.AppendLine("PATPAEntity.Id: " + PATPAEntity.Id);
                            CommonPluginLibrary.SetAttributeValue(PATPAEntity, JobFilingEntityAttributeName.FilingFees, new Money(0));
                            CommonPluginLibrary.SetAttributeValue(PATPAEntity, JobFilingEntityAttributeName.PAAFee, new Money(0));
                            if(targetEntity.Contains(JobFilingEntityAttributeName.TemporaryPlaceOfAssemblyLookUp))
                            {
                                PATPAEntity.Attributes[JobFilingEntityAttributeName.TemporaryPlaceOfAssemblyLookUp] = new EntityReference(TempororayPlaceOfAssembly.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.TemporaryPlaceOfAssemblyLookUp).Id);
                            }

                            serviceConnector.Update(PATPAEntity);
                        }
                    }
                    #endregion

                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAInitiateFeePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
