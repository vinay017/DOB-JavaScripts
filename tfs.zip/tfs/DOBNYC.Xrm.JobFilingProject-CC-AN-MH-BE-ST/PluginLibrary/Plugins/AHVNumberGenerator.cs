﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    public class AHVNumberGenerator : IPlugin
    {
        /// <summary>
        /// Plugin generates the AHV Number
        /// </summary>


        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != AfterHourVarianceAttributeNames.EntityLogicalName)
                    return;

                customTrace.AppendLine("context.MessageName: " + PluginHelperStrings.UpdateMessageName);
                //if (context.MessageName == PluginHelperStrings.UpdateMessageName)


                //    if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                //    {
                //        Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                //        CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                //        customTrace.AppendLine("preTargetEntity Guid: " + preTargetEntity.Id);
                //    }

                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    if (targetEntity.Attributes.Contains(AfterHourVarianceAttributeNames.Borough))
                    {

                        customTrace.AppendLine("Start Generating AHV Number: " + PluginHelperStrings.UpdateMessageName);
                        targetEntity = AHVNumberHandler.GenerateAHVNumber(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating AHV Number: " + PluginHelperStrings.UpdateMessageName);

                    }
                }

                // Is Submitted Logic

                if (targetEntity.Attributes.Contains(AfterHourVarianceAttributeNames.IsSubmitted))
                {
                    bool isSubmitted = targetEntity.GetAttributeValue<bool>(AfterHourVarianceAttributeNames.IsSubmitted);
                    if (isSubmitted == true)
                    {
                        customTrace.AppendLine("Start Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                        targetEntity = SubmitHandler.AHVSubmit(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                        //throw new Exception("Is Submitted Logic testing");
                    }
                }
                


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberGenerator - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }



    }
}
