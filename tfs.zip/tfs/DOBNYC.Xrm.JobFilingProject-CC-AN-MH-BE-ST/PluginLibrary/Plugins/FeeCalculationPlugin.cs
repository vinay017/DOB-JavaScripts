﻿
using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Threading.Tasks;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class FeeCalculationPlugin : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            Entity preImage = new Entity();
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;

                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();

                if (context.PreEntityImages.Contains("PreImageJobFiling"))
                {
                    preTargetEntity = context.PreEntityImages["PreImageJobFiling"];
                    WorkFlowHandler.JobFilingWorkFlow(serviceConnector, targetEntity, customTrace, preTargetEntity);   // JobFiling Workflows 
                }
                if (context.PreEntityImages.Contains("PostImageJobFiling"))
                    postTargetEntity = context.PostEntityImages["PostImageJobFiling"];


                if (context.Depth > 1)
                    return;


                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                {
                    return;
                }

                //PW1 Standardization: Is Historic JobFiling Check - Start
                bool IsHistoricJobFiling = false;
                
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                {
                    IsHistoricJobFiling = true;
                    customTrace.AppendLine("Historic Filing");
                }
                else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && preTargetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                {
                    IsHistoricJobFiling = true;
                    customTrace.AppendLine("Historic Filing");
                }
                //PW1 Standardization: Is Historic JobFiling Check - End
                //PW1 standardization changes: Start
                if (!IsHistoricJobFiling)
                {
                    customTrace.AppendLine("PW1 Standardization - Start");
                    FeeCalculationObject fcObject = new FeeCalculationObject();
                    FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(targetEntity, fcObject, customTrace);

                    if (context.MessageName == PluginHelperStrings.CreateMessageName)
                    {
                        //Create a Progress Inspection Category record creation if PA/TPA Worktype is selected while filing a new job
                        customTrace.AppendLine("Progress Inspection Category record creation on Job with PA/TPA filing.");
                        if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity[JobFilingEntityAttributeName.PACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA))
                                //|| (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity[JobFilingEntityAttributeName.TPACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA)
                                 )
                        {

                            customTrace.AppendLine("Progress Inspection Category Record - Start");
                            GCMHSTHandler.CreateProgressInspectionCategoryRecordForPA_TPA(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("Progress Inspection Category Record - End");

                        }

                        Entity temp = new Entity(); //Just object to pass in params
                        WorkTypeHandler.CreateAssociatedWorkTypes_Create(serviceConnector, targetEntity, customTrace);
                        //Task<bool> CreateDocs = DocumentItemUploadHandler.CreateRequiredItemstoJobFiling(serviceConnector, targetEntity, temp, customTrace, context);

                        //New Property Profile Logic for Changing Address and not creating Duplicate Property Profiles in System
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN))
                        {
                            customTrace.AppendLine("Start BIS integration: " + PluginHelperStrings.CreateMessageName);
                            targetEntity = BISIntegrationHandler.AssociatePropertyProfile(serviceConnector, targetEntity, true, customTrace);
                            customTrace.AppendLine("End BIS integration: " + PluginHelperStrings.CreateMessageName);

                        }

                        #region DPL1 Document Validation - CC Owner
                        if (targetEntity.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                        {
                            customTrace.AppendLine("Start DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                            SealSignaturesHandler.JobFilingSealandSignatureDocuments(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                        }
                        #endregion

                        // FAB 4 Scope of Works
                        if (fcObject.IsFN || fcObject.IsSH || fcObject.IsSF)
                        {
                            customTrace.AppendLine(" Start FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                            FAB4ScopeofWorkHandlerV2.Adjust_FAB4ScopeofWork(serviceConnector, targetEntity, customTrace, fcObject);
                            customTrace.AppendLine(" End FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                        }

                        //Create a Progress Inspection Category record creation if Antenna is selected while filing a new job
                        customTrace.AppendLine("Progress Inspection Category record creation on Job with Antenna filing.");
                        if (fcObject.IsAN)
                        {
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value != 2)
                            {
                                customTrace.AppendLine("Progress Inspection Category Record - Start");
                                FeeCalculationHelper.CreateProgressInspectionCategoryRecordForAntenna(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("Progress Inspection Category Record - End");
                            }
                        }

                        ////Create a Progress Inspection Category record creation if PA/TPA Worktype is selected while filing a new job
                        //customTrace.AppendLine("Progress Inspection Category record creation on Job with PA/TPA filing.");
                        //if ((fcObject.IsPATPA
                        //    && (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA))
                        //    || (fcObject.IsPATPA
                        //    && (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA)))
                        //{

                        //    customTrace.AppendLine("Progress Inspection Category Record - Start");
                        //    GCMHSTHandler.CreateProgressInspectionCategoryRecordForPA_TPA(serviceConnector, targetEntity, customTrace);
                        //    customTrace.AppendLine("Progress Inspection Category Record - End");

                        //}
                    }

                    //Return if FAB4/GCMH/Electical Filing
                    if (fcObject.IsFN || fcObject.IsSG || fcObject.IsSH || fcObject.IsSF
                                // (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity[JobFilingEntityAttributeName.ConstructionFence] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                                //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity[JobFilingEntityAttributeName.Sign] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                                //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity[JobFilingEntityAttributeName.SidewalkShed] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                                //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity[JobFilingEntityAttributeName.SupportedScaffold] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                                || (targetEntity.Contains(JobFilingEntityAttributeName.isElectricalWorkType) && targetEntity[JobFilingEntityAttributeName.isElectricalWorkType] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType) == true)
                                || (targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity[JobFilingEntityAttributeName.PACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)
                                || (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity[JobFilingEntityAttributeName.TPACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true)
                                 )
                    {
                        return;
                    }





                    ///<summary>
                    /// Check if the job is Alteration Job 
                    ///</summary>
                    //if (context.MessageName == PluginHelperStrings.CreateMessageName)
                    //{

                    //    // check if curb cut check box is true and Is Submitted false
                    //    customTrace.AppendLine("Create Plugin ");

                    //    if (fcObject.IsCC &&
                    //          targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false
                    //          && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    //    {
                    //        customTrace.AppendLine("curbcut fee calculation - start");
                    //        FeeCalculationHelper.CurbCutFeeCalculation(serviceConnector, customTrace, targetEntity, preTargetEntity, context.MessageName.ToUpper());
                    //        customTrace.AppendLine("curbcut fee calculation - End");
                    //    }
                    //    else
                    //    {
                    //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) ||
                    //                targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                    //        {
                    //            if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                    //            && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)))
                    //            {
                    //                //continue not only fab4 flags
                    //                customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.CreateMessageName);
                    //                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType)
                    //                    && targetEntity[JobFilingEntityAttributeName.BuildingType] != null
                    //                    && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value > 0)//added beacuse of Prod Bug
                    //                {
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.CreateMessageName);
                    //                }

                    //            }
                    //        }
                    //    }
                    //}

                    //else
                    //{
                    //    //Update
                    //    customTrace.AppendLine("Update Plugin");

                    //    if (fcObject.IsCC &&
                    //       ((targetEntity.Contains(JobFilingEntityAttributeName.SizeofCut) && targetEntity[JobFilingEntityAttributeName.SizeofCut] != null && preTargetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.SizeofCut) != targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.SizeofCut)) ||
                    //       (targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null && preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value != targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value) ||// plugin execute only if building type is changed
                    //       (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && preTargetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob)) ||
                    //       (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && preTargetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename)) ||
                    //       (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && preTargetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true) ||
                    //       ((targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA) && (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)) ||//this condition is when paa is intiated and none of the above fields change.
                    //       (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true)))
                    //    {

                    //        customTrace.AppendLine("curbcut fee calculation in update - start");
                    //        FeeCalculationHelper.CurbCutFeeCalculation(serviceConnector, customTrace, targetEntity, preTargetEntity, context.MessageName.ToUpper());
                    //        customTrace.AppendLine("curbcut fee calculation in update- End");
                    //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Job filing fee calcl testing purpose", null, customTrace.ToString(), null, null);
                    //    }
                    //    // Job Filing Fee Calculation

                    //    // if the job is Minor Alteration then enter into the block.
                    //    //if (targetEntity.Contains(JobFilingEntityAttributeName.JobTypeMultiStake) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value == 1
                    //    //       && targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.MinorAlteration
                    //    //      )
                    //    else
                    //    {

                    //        if ((fcObject.IsAN || fcObject.IsPL || fcObject.IsSP || fcObject.IsSD)
                    //        && (preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) || targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    //        && (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) || (preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost)))
                    //        || (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                    //        || targetEntity.Contains(JobFilingEntityAttributeName.EstimatedCostFinal)
                    //        )
                    //        {

                    //            customTrace.AppendLine("Checking basic conditions for Update ");
                    //            if (!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) ||
                    //                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobFiling) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobFiling) ||
                    //                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) ||
                    //                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                    //            {
                    //                customTrace.AppendLine("If either buildingtype/estimated/estimated legal job is null in pretarget but has value in target entity - Start ");
                    //                targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                customTrace.AppendLine("If either buildingtype/estimated/estimated legal job is null in pretarget but has value in target entity - End ");

                    //                return;
                    //            }

                    //            //Inconjunction Job
                    //            customTrace.AppendLine("Checking inconjunction job ");
                    //            if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                    //            {
                    //                if (((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob]) == false)
                    //                {
                    //                    customTrace.AppendLine("If IsConjuntion of Pretarget is true and Target is false - Start ");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    customTrace.AppendLine("If IsConjuntion of Pretarget is true and Target is false - End ");
                    //                    return;
                    //                }
                    //            }

                    //            // Fee Exempt
                    //            customTrace.AppendLine("Checking isfee exempt job ");
                    //            if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                    //            {
                    //                if (((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename]) == false)
                    //                {
                    //                    customTrace.AppendLine("If IsFeeExpemtion of Pretarget is true and Target is false - Start");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    customTrace.AppendLine("If IsFeeExpemtion of Pretarget is true and Target is false - End  ");
                    //                    return;
                    //                }
                    //            }

                    //            // If Is Job Submitted or Corrections Completed is true(Adjustment)
                    //            customTrace.AppendLine("checking is job submitted job");
                    //            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted))
                    //            {
                    //                customTrace.AppendLine("Scenario if Is Job submitted or IsCorrection Completed are true ");
                    //                if (((targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null) ||
                    //                    (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null)) &&
                    //                    !(preTargetEntity.Contains(JobFilingEntityAttributeName.FilingStatus) && preTargetEntity[JobFilingEntityAttributeName.FilingStatus] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.OnHold_NoGoodCheck))//should not execute if preimage status is on hold no good check
                    //                {
                    //                    customTrace.AppendLine("Adjustment Process if Job Submitted is True - Start");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    customTrace.AppendLine("Adjustment Process if Job Submitted is True - End");
                    //                    return;
                    //                }
                    //            }

                    //            // No Good Check
                    //            if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFlag] != null)

                    //            {
                    //                customTrace.AppendLine("Scenario if Is NoGoodCheck Flag is true ");
                    //                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                    //                {
                    //                    customTrace.AppendLine("No good Check fee - Start");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    customTrace.AppendLine("No good Check fee - End");
                    //                    return;
                    //                }
                    //            }

                    //            customTrace.AppendLine("check if is inconjunction job and Fee Exemption are part of target entity");
                    //            if (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null)
                    //            {

                    //                customTrace.AppendLine("check if either inconjunction job  is true");
                    //                if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true))
                    //                {
                    //                    customTrace.AppendLine("Either Inconjunction job or fee exemption is true");
                    //                    customTrace.AppendLine("In Conjunction and Fee Exmption");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    return;
                    //                }
                    //            }

                    //            if (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null)
                    //            {
                    //                customTrace.AppendLine("check if either Fee Exemption is true");
                    //                if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true))
                    //                {
                    //                    customTrace.AppendLine("Either Inconjunction job or fee exemption is true");
                    //                    customTrace.AppendLine("In Conjunction and Fee Exmption");
                    //                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                    //                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    return;
                    //                }
                    //            }

                    //            customTrace.AppendLine("In case of first update when building type and estimated job cost is not entered");
                    //            if ((!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))) ||
                    //              (!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)))
                    //            {
                    //                customTrace.AppendLine("In case of first update when building type and estimated job is not entered - Passed 1st condition");
                    //                if ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null) || (targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null))
                    //                {
                    //                    customTrace.AppendLine("pretarget entity estimated and estimated legal are null. But target entity has been in case of Update");
                    //                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                    return;
                    //                }
                    //            }

                    //            customTrace.AppendLine("jobtype");
                    //            CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                    //            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType))
                    //            {

                    //                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 1)
                    //                {

                    //                    customTrace.AppendLine("job type 1");
                    //                    if ((targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && (targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null) && ((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value) ||
                    //                     ((targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)) ||
                    //                     ((targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value)) ||
                    //                     (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedCostFinal) && targetEntity[JobFilingEntityAttributeName.EstimatedCostFinal] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PermitEntire))// when loc intitaed
                    //                                                                                                                                                                                                                                                                                                                                                     /*||((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                    //                    {
                    //                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                    }
                    //                }

                    //                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 2)
                    //                {

                    //                    customTrace.AppendLine("Job type 2");
                    //                    if ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null) && (((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value) ||
                    //                     ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Contains(JobFilingEntityAttributeName.BuildingType)) && (preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && targetEntity[JobFilingEntityAttributeName.BuildingType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value) ||
                    //                     ((preTargetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity.Contains(JobFilingEntityAttributeName.JobType)) && (preTargetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity[JobFilingEntityAttributeName.JobType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value))/*||
                    //              ((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                    //                    {
                    //                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                    }
                    //                }

                    //                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 3)
                    //                {

                    //                    customTrace.AppendLine("Job type 3");
                    //                    if ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null) && (((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value) ||
                    //                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null) && ((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value) ||
                    //                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Contains(JobFilingEntityAttributeName.BuildingType)) && (preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && targetEntity[JobFilingEntityAttributeName.BuildingType] != null) && (((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)) ||
                    //                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity.Contains(JobFilingEntityAttributeName.JobType)) && (preTargetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity[JobFilingEntityAttributeName.JobType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value))/*||
                    //              ((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                    //                    {
                    //                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                    //                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                    //                    }
                    //                }
                    //            }
                    //        }
                    //    }
                    //}

                }
                else
                {
                    //PW1 standardization changes: End

                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    Entity temp = new Entity(); //Just object to pass in params
                    WorkTypeHandler.CreateAssociatedWorkTypes_Create(serviceConnector, targetEntity, customTrace);
                    Task<bool> CreateDocs = DocumentItemUploadHandler.CreateRequiredItemstoJobFiling(serviceConnector, targetEntity, temp, customTrace, context);

                    //New Property Profile Logic for Changing Address and not creating Duplicate Property Profiles in System
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN))
                    {
                        customTrace.AppendLine("Start BIS integration: " + PluginHelperStrings.CreateMessageName);
                        targetEntity = BISIntegrationHandler.AssociatePropertyProfile(serviceConnector, targetEntity, true, customTrace);
                        customTrace.AppendLine("End BIS integration: " + PluginHelperStrings.CreateMessageName);

                    }

                    #region Create SiteSafety
                    //if (targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType))
                    //    GCMHSTHandler.CreateDelete_GCMHSTRelatedEntities(serviceConnector, targetEntity, true, SiteSafetyEntityAttributeNames.EntityLogicalName, customTrace);
                    #endregion

                    #region DPL1 Document Validation - CC Owner
                    if (targetEntity.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                    {
                        customTrace.AppendLine("Start DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                        SealSignaturesHandler.JobFilingSealandSignatureDocuments(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                    }
                    #endregion

                    // FAB 4 Scope of Works
                    if ((targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                    || (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed)))
                    || (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold))))
                    {
                        customTrace.AppendLine(" Start FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                        FAB4ScopeofWorkHandler.Adjust_FAB4ScopeofWork(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine(" End FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                    }



                    //Create a Progress Inspection Category record creation if Antenna is selected while filing a new job
                    customTrace.AppendLine("Progress Inspection Category record creation on Job with Antenna filing.");
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox) == true)
                    {
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value != 2)
                        {
                            customTrace.AppendLine("Progress Inspection Category Record - Start");
                            FeeCalculationHelper.CreateProgressInspectionCategoryRecordForAntenna(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("Progress Inspection Category Record - End");
                        }
                    }

                    //Create a Progress Inspection Category record creation if PA/TPA Worktype is selected while filing a new job
                    customTrace.AppendLine("Progress Inspection Category record creation on Job with PA/TPA filing.");
                    if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true
                        && (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA))
                        //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true
                        //&& (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA))
                        )
                    {

                        customTrace.AppendLine("Progress Inspection Category Record - Start");
                        GCMHSTHandler.CreateProgressInspectionCategoryRecordForPA_TPA(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("Progress Inspection Category Record - End");

                    }
                }

                //Return if FAB4/GCMH/Electical Filing
                if ((
                             (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity[JobFilingEntityAttributeName.ConstructionFence] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                            || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity[JobFilingEntityAttributeName.Sign] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                            || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity[JobFilingEntityAttributeName.SidewalkShed] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                            || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity[JobFilingEntityAttributeName.SupportedScaffold] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                            //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity[JobFilingEntityAttributeName.GeneralConstructionWorkType] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType) == true)
                            //|| (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MechanicalWorkType) && targetEntity[JobFilingEntityAttributeName.MechanicalWorkType] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType) == true)
                            || (targetEntity.Contains(JobFilingEntityAttributeName.isElectricalWorkType) && targetEntity[JobFilingEntityAttributeName.isElectricalWorkType] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType) == true)
                            || (targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity[JobFilingEntityAttributeName.PACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)
                            || (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity[JobFilingEntityAttributeName.TPACheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true)
                             ))
                {
                    return;
                }





                ///<summary>
                /// Check if the job is Alteration Job 
                ///</summary>
                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    #region Commented and mover code above
                    //WorkTypeHandler.CreateAssociatedWorkTypes_Create(serviceConnector, targetEntity, customTrace);
                    //DocumentItemUploadHandler.CreateRequiredItemstoJobFiling(serviceConnector, targetEntity, customTrace, context);

                    ////New Property Profile Logic for Changing Address and not creating Duplicate Property Profiles in System
                    //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN))
                    //{
                    //    customTrace.AppendLine("Start BIS integration: " + PluginHelperStrings.CreateMessageName);
                    //    targetEntity = BISIntegrationHandler.AssociatePropertyProfile(serviceConnector, targetEntity, true, customTrace);
                    //    customTrace.AppendLine("End BIS integration: " + PluginHelperStrings.CreateMessageName);

                    //}

                    //#region DPL1 Document Validation - CC Owner
                    //if (targetEntity.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                    //{
                    //    customTrace.AppendLine("Start DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                    //    SealSignaturesHandler.JobFilingSealandSignatureDocuments(serviceConnector, targetEntity, customTrace);
                    //    customTrace.AppendLine("End DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                    //}
                    //#endregion

                    //// FAB 4 Scope of Works
                    //if ((targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                    //|| (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed)))
                    //|| (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold))))
                    //{
                    //    customTrace.AppendLine(" Start FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                    //    FAB4ScopeofWorkHandler.Adjust_FAB4ScopeofWork(serviceConnector, targetEntity, customTrace);
                    //    customTrace.AppendLine(" End FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                    //}


                    //Create a Progress Inspection Category record creation if Antenna is selected while filing a new job
                    //customTrace.AppendLine("Progress Inspection Category record creation on Job with Antenna filing.");
                    //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox) == true)
                    //{
                    //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value != 2)
                    //    {
                    //        customTrace.AppendLine("Progress Inspection Category Record - Start");
                    //        FeeCalculationHelper.CreateProgressInspectionCategoryRecordForAntenna(serviceConnector, targetEntity, customTrace);
                    //        customTrace.AppendLine("Progress Inspection Category Record - End");
                    //    }
                    //}

                    #endregion

                    // check if curb cut check box is true and Is Submitted false
                    customTrace.AppendLine("Create Plugin ");

                    if ((targetEntity.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true) &&
                          targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false
                          && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        customTrace.AppendLine("curbcut fee calculation - start");
                        FeeCalculationHelper.CurbCutFeeCalculation(serviceConnector, customTrace, targetEntity, preTargetEntity, context.MessageName.ToUpper());
                        customTrace.AppendLine("curbcut fee calculation - End");

                    }

                     //if (targetEntity.Contains(JobFilingEntityAttributeName.JobTypeMultiStake) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value == 1
                     //        && targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.MinorAlteration
                     //       )
                    else
                    {
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) ||
                                targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                        {
                            if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                            && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)))
                            {
                                //continue not only fab4 flags
                                customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.CreateMessageName);
                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType)
                                    && targetEntity[JobFilingEntityAttributeName.BuildingType] != null
                                    && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value > 0)//added beacuse of Prod Bug
                                {
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.CreateMessageName);
                                }

                            }
                        }
                    }
                }

                else
                {
                    //Update
                    customTrace.AppendLine("Update Plugin");

                    if ((targetEntity.Contains(JobFilingEntityAttributeName.CCCheckBox) && targetEntity[JobFilingEntityAttributeName.CCCheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox) == true) &&
                       ((targetEntity.Contains(JobFilingEntityAttributeName.SizeofCut) && targetEntity[JobFilingEntityAttributeName.SizeofCut] != null && preTargetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.SizeofCut) != targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.SizeofCut)) ||
                       (targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null && preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value != targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value) ||// plugin execute only if building type is changed
                       (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && preTargetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob)) ||
                       (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && preTargetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename)) ||
                       (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && preTargetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true) ||
                       ((targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA) && (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)) ||//this condition is when paa is intiated and none of the above fields change.
                       (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && preTargetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true)))
                    {

                        customTrace.AppendLine("curbcut fee calculation in update - start");
                        FeeCalculationHelper.CurbCutFeeCalculation(serviceConnector, customTrace, targetEntity, preTargetEntity, context.MessageName.ToUpper());
                        customTrace.AppendLine("curbcut fee calculation in update- End");
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Job filing fee calcl testing purpose", null, customTrace.ToString(), null, null);
                    }
                    // Job Filing Fee Calculation

                    // if the job is Minor Alteration then enter into the block.
                    //if (targetEntity.Contains(JobFilingEntityAttributeName.JobTypeMultiStake) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value == 1
                    //       && targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value == (int)JobTypeNBorAlt.MinorAlteration
                    //      )
                    else
                    {

                        if (
                        // Verify if the job is of PL/SP/SD/AN work type
                        (
                        (targetEntity.Contains(JobFilingEntityAttributeName.ANCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox) == true) ||
                        (targetEntity.Contains(JobFilingEntityAttributeName.PlumbingCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox) == true) ||
                        (targetEntity.Contains(JobFilingEntityAttributeName.SprinklerCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox) == true) ||
                        (targetEntity.Contains(JobFilingEntityAttributeName.StandPipeWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType) == true)
                        )
                        && (preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) || targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                        && (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) || (preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost)))
                        || (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                        || targetEntity.Contains(JobFilingEntityAttributeName.EstimatedCostFinal)
                        )
                        {

                            customTrace.AppendLine("Checking basic conditions for Update ");
                            if (!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) ||
                                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobFiling) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobFiling) ||
                                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) ||
                                !preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                            {
                                customTrace.AppendLine("If either buildingtype/estimated/estimated legal job is null in pretarget but has value in target entity - Start ");
                                targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                customTrace.AppendLine("If either buildingtype/estimated/estimated legal job is null in pretarget but has value in target entity - End ");

                                return;
                            }

                            //Inconjunction Job
                            customTrace.AppendLine("Checking inconjunction job ");
                            if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                            {
                                if (((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob]) == false)
                                {
                                    customTrace.AppendLine("If IsConjuntion of Pretarget is true and Target is false - Start ");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    customTrace.AppendLine("If IsConjuntion of Pretarget is true and Target is false - End ");
                                    return;
                                }
                            }

                            // Fee Exempt
                            customTrace.AppendLine("Checking isfee exempt job ");
                            if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                            {
                                if (((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename]) == false)
                                {
                                    customTrace.AppendLine("If IsFeeExpemtion of Pretarget is true and Target is false - Start");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    customTrace.AppendLine("If IsFeeExpemtion of Pretarget is true and Target is false - End  ");
                                    return;
                                }
                            }

                            // If Is Job Submitted or Corrections Completed is true(Adjustment)
                            customTrace.AppendLine("checking is job submitted job");
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted))
                            {
                                customTrace.AppendLine("Scenario if Is Job submitted or IsCorrection Completed are true ");
                                if (((targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null) ||
                                    (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null)) &&
                                    !(preTargetEntity.Contains(JobFilingEntityAttributeName.FilingStatus) && preTargetEntity[JobFilingEntityAttributeName.FilingStatus] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.OnHold_NoGoodCheck))//should not execute if preimage status is on hold no good check
                                {
                                    customTrace.AppendLine("Adjustment Process if Job Submitted is True - Start");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    customTrace.AppendLine("Adjustment Process if Job Submitted is True - End");
                                    return;
                                }
                            }

                            // No Good Check
                            if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFlag] != null)

                            {
                                customTrace.AppendLine("Scenario if Is NoGoodCheck Flag is true ");
                                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                {
                                    customTrace.AppendLine("No good Check fee - Start");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    customTrace.AppendLine("No good Check fee - End");
                                    return;
                                }
                            }

                            customTrace.AppendLine("check if is inconjunction job and Fee Exemption are part of target entity");
                            if (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null)
                            {

                                customTrace.AppendLine("check if either inconjunction job  is true");
                                if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true))
                                {
                                    customTrace.AppendLine("Either Inconjunction job or fee exemption is true");
                                    customTrace.AppendLine("In Conjunction and Fee Exmption");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    return;
                                }
                            }

                            if (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null)
                            {
                                customTrace.AppendLine("check if either Fee Exemption is true");
                                if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true))
                                {
                                    customTrace.AppendLine("Either Inconjunction job or fee exemption is true");
                                    customTrace.AppendLine("In Conjunction and Fee Exmption");
                                    targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    return;
                                }
                            }

                            customTrace.AppendLine("In case of first update when building type and estimated job cost is not entered");
                            if ((!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))) ||
                              (!preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)))
                            {
                                customTrace.AppendLine("In case of first update when building type and estimated job is not entered - Passed 1st condition");
                                if ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null) || (targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null))
                                {
                                    customTrace.AppendLine("pretarget entity estimated and estimated legal are null. But target entity has been in case of Update");
                                    JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                    return;
                                }
                            }

                            customTrace.AppendLine("jobtype");
                            CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType))
                            {

                                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 1)
                                {

                                    customTrace.AppendLine("job type 1");
                                    if ((targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && (targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null) && ((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value) ||
                                     ((targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)) ||
                                     ((targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value)) ||
                                     (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedCostFinal) && targetEntity[JobFilingEntityAttributeName.EstimatedCostFinal] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PermitEntire))// when loc intitaed
                                                                                                                                                                                                                                                                                                                                                                     /*||((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                                    {
                                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                                    }
                                }

                                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 2)
                                {

                                    customTrace.AppendLine("Job type 2");
                                    if ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null) && (((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value) ||
                                     ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Contains(JobFilingEntityAttributeName.BuildingType)) && (preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && targetEntity[JobFilingEntityAttributeName.BuildingType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value) ||
                                     ((preTargetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity.Contains(JobFilingEntityAttributeName.JobType)) && (preTargetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity[JobFilingEntityAttributeName.JobType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value))/*||
                                  ((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                                    {
                                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                                    }
                                }

                                if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value == 3)
                                {

                                    customTrace.AppendLine("Job type 3");
                                    if ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCostLegal] != null) && (((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value) ||
                                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost)) && (preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null) && ((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value) ||
                                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.Contains(JobFilingEntityAttributeName.BuildingType)) && (preTargetEntity[JobFilingEntityAttributeName.BuildingType] != null && targetEntity[JobFilingEntityAttributeName.BuildingType] != null) && (((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)) ||
                                      ((preTargetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity.Contains(JobFilingEntityAttributeName.JobType)) && (preTargetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity[JobFilingEntityAttributeName.JobType] != null) && ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value != ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value))/*||
                                  ((preTargetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation)) && (preTargetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) && ((bool)preTargetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]) != ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.AlternateJobInBISAssociation]))*/
                                    {
                                        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);
                                        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, context.MessageName.ToUpper());
                                        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                                    }
                                }
                            }

                        }
                    }

                }
                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "testing purpose  - CalculateFee plugin", null, customTrace.ToString(), null, null);
            }

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
