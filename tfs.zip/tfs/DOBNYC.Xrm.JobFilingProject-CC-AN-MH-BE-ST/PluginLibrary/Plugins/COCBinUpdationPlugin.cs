﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class COCBinUpdationPlugin : PluginHandlerBase, IPlugin
    {

        /// <summary>
        ///  1)This Plugin will be used to update the BIN and iscocfiled fields on MHScopeofZWork entity on the status update of jobfiling (permit issues,approved,permit entire)
        ///  2)This plugin also used for ST worktype when it is permit entire copy the deatils of TR3mix to tr2testreport and BCDBC flag updates
        ///  3)This Plugin also used in Boilers worktype when it is permit entire a new device will be created and device number gets created
        ///  4)This plugin also used in collecting existing Boiler details from user.
        /// Register on JobFiling Entity
        ///       
        ///       * (a) post-Update Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_jobfiling  (primary)
        ///             * Filtering Attributes -reportstatus
        ///             * preimage required
        ///       
        ///             
        ///          
        /// 
        /// 
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables Declaration
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            string PaymentHistoryGUID = string.Empty;
            #endregion
            try
            {
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];


                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 4)
                {
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute " + context.Depth, null, customTrace.ToString(), null, null);
                    return;
                }

                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;

                if ((targetEntity.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling)) || (preTargetEntity.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && preTargetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling)))
                {
                    return;
                }

                #endregion


                #region Get the worktypes in Jobfiling and assign in feeobject
                customTrace.AppendLine("set all the work type flags in fee object-start");
                Entity getWorkTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity : preTargetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && preTargetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? preTargetEntity : targetEntity;
                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(getWorkTypes, feeObject, customTrace);
                customTrace.AppendLine("set all the work type flags in fee object-end");
                #endregion

                int reportStatus = targetEntity.Contains(JobFilingEntityAttributeName.FilingStatus) && targetEntity[JobFilingEntityAttributeName.FilingStatus] != null ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.FilingStatus) && preTargetEntity[JobFilingEntityAttributeName.FilingStatus] != null ? preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : 0;
                int prereportStatus = preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                if ((reportStatus == (int)CurrentFilingStatus.PermitEntire || reportStatus == (int)CurrentFilingStatus.PermitIssued || reportStatus == (int)CurrentFilingStatus.Approved) && feeObject.IsMS)//only for mechanical
                {
                    EntityCollection COCS = new EntityCollection();

                    customTrace.AppendLine("get Coc's");
                    ConditionExpression transactionCodeCondition = CreateConditionExpression(MHScopeofworkAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    COCS = RetrieveMultiple(serviceConnector, MHScopeofworkAttributeNames.EntityLogicalName, new string[] {
                                                                                                       MHScopeofworkAttributeNames.ModelName}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);
                    if (COCS != null && COCS.Entities.Count > 0)
                    {
                        customTrace.AppendLine("Count of COCs : " + COCS.Entities.Count);
                        foreach (Entity COC in COCS.Entities)
                        {
                            customTrace.AppendLine(" start Updating bin and isfiled of COC id: " + COC.Id);
                            COC.SetAttributeValue(MHScopeofworkAttributeNames.Bin, preTargetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString());
                            COC.SetAttributeValue(MHScopeofworkAttributeNames.isFiled, true);
                            serviceConnector.Update(COC);
                            customTrace.AppendLine("End Updating bin and isfiled of COC id: " + COC.Id);
                        }
                    }

                }
                else if (feeObject.IsST && (reportStatus == (int)CurrentFilingStatus.PermitEntire || reportStatus == (int)CurrentFilingStatus.PermitIssued) && (prereportStatus != (int)CurrentFilingStatus.PermitEntireBCDBCReview && prereportStatus != (int)CurrentFilingStatus.PermitEntireBCDBCReviewObjections && prereportStatus!=(int)CurrentFilingStatus.PermitEntire)) // applies for ST.
                {
                    customTrace.AppendLine(" ST Work Type Permit Entire copy Tr3 mix details to tr2testreport ");
                    ///1) Get all tr3 for the jobfiling
                    ///2) loop through each tr3 and get the Tr3 Directors 
                    ///3) loop through each director and get the Tr3 Mixs and store in one collection
                    ///4) get the Tr2 records associated to jobfiling (get Guid)
                    ///5) Create the Tr2testreport on the tr2resport for all the tr3mix's in global collection.
                    ///

                    ConditionExpression Tr3condition = new ConditionExpression();
                    ConditionExpression Tr4condition = new ConditionExpression();
                    EntityCollection TR3s = new EntityCollection();
                    Entity Tr2Record = new Entity();
                    customTrace.AppendLine("4)get the Tr2 record id");

                    TR3s = FeeCalculationStandardizationHandler.GetTR2TechnicalReport(serviceConnector, targetEntity, customTrace, feeObject);
                    if (TR3s != null && TR3s.Entities.Count > 0)
                    {
                        Tr2Record = TR3s.Entities[0];
                    }
                    else
                    {
                        customTrace.AppendLine("No Tr2's found for jobfiling so return");
                        return;

                    }


                    customTrace.AppendLine("1)Get all tr3 for the jobfiling start");

                    customTrace.AppendLine("2) loop through each tr3 and get the Tr3 Directors ");
                  
                    Tr3condition = CreateConditionExpression(TR3Director.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    Tr4condition = new ConditionExpression(TR3Director.designApplicantCheckBox, ConditionOperator.Equal, true); //get TR3 directors only whose attestation is completed.
                    EntityCollection TR3Directors = RetrieveMultiple(serviceConnector, TR3Director.EntityLogicalName, new string[] { TR3Director.Name, TR3Director.CPBusinessaddesss,
                                TR3Director.CPBusinesCity, TR3Director.CPBusinesFax, TR3Director.CPBusinesName, TR3Director.CPBusinesNameLookup, TR3Director.CPBusinesState, TR3Director.CPBusinesTelephone,
                                TR3Director.CPBusinesZip, TR3Director.CPLicenseLookup, TR3Director.CPName, TR3Director.CPNameLookup, TR3Director.CPDate, TR3Director.NRMCAExpirationDate,TR3Director.TR3TrackingNumber }, new ConditionExpression[] { Tr3condition, Tr4condition }, LogicalOperator.And);
                    customTrace.AppendLine("TR3Directors count : " + TR3Directors.Entities.Count);
                    if (TR3Directors != null && TR3Directors.Entities.Count > 0)
                    {
                        customTrace.AppendLine("3) loop through each director and get the Tr3 Mixs and store in one collection ");
                        foreach (Entity Tr3director in TR3Directors.Entities)
                        {
                            Tr3condition = CreateConditionExpression(TR3MixEntityAttribute.GotoTRTechnicalreport, ConditionOperator.Equal, new string[] { Tr3director.Id.ToString() });
                            EntityCollection Tr3mixs = RetrieveMultiple(serviceConnector, TR3MixEntityAttribute.EntityLogicalName, new string[] { TR3MixEntityAttribute.EntityNameAttribute, TR3MixEntityAttribute.MixType, TR3MixEntityAttribute.SpecifiedStrength, TR3MixEntityAttribute.SpecifiedTestAge, TR3MixEntityAttribute.SequenceNumber }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                            customTrace.AppendLine("Tr3mixs count : " + Tr3mixs.Entities.Count);
                            foreach (Entity Tr3mix in Tr3mixs.Entities)
                            {
                                customTrace.AppendLine("5) Create the Tr2testreport on the tr2resport for all the tr3mix's in global collection.");

                                FeeCalculationStandardizationHandler.CreateTR2TestReport(serviceConnector, Tr3mix, Tr3director, Tr2Record, customTrace);


                            }

                        }
                        #region Call Structural -Permit Issued
                        customTrace.AppendLine("Structural -Permit Issued");
                        Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "Structural - Permit Issued Email").Id.ToString());
                        customTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);
                        #endregion
                    }


                }
                else if (feeObject.IsST && (reportStatus == (int)CurrentFilingStatus.PermitEntire)) // applies for ST.
                {

                    FeeCalculationStandardizationHandler.DeactivateExceptionDocument(serviceConnector, targetEntity, customTrace);
                }

                else if (feeObject.IsST && (reportStatus == (int)CurrentFilingStatus.PermitEntireBCDBCReview)) // applies for ST.
                {
                    customTrace.AppendLine(" ST Work Type update bcdbc falg to true for all  Tr3 mix details and  tr2testreports ");

                    //get all tr3mixes for jobfiling  and tr2testReport

                    ConditionExpression Tr3condition = new ConditionExpression();
                    EntityCollection TR3s = new EntityCollection();
                    Entity Tr2Record = new Entity();
                    Entity Temp = new Entity();
                    customTrace.AppendLine("4)get the Tr2 record id");

                    TR3s = FeeCalculationStandardizationHandler.GetTR2TechnicalReport(serviceConnector, targetEntity, customTrace, feeObject);
                    if (TR3s != null && TR3s.Entities.Count > 0)
                    {
                        Tr2Record = TR3s.Entities[0];
                    }


                    #region Update Tr3mix BC/DBC flag
                    customTrace.AppendLine("1)Get all tr3 for the jobfiling start");
                    TR3s = FeeCalculationStandardizationHandler.GetTR3MixassociatedtoJobFiling(serviceConnector, targetEntity, customTrace, feeObject);
                    customTrace.AppendLine("1)Get all tr3 for the jobfiling End ");
                    if (TR3s != null && TR3s.Entities.Count > 0)
                    {
                        customTrace.AppendLine("1)Get all tr3 for the jobfiling End " + TR3s.Entities.Count);
                        customTrace.AppendLine("1)Get all tr3 Mix Update start ");
                        foreach (Entity Tr3mix in TR3s.Entities)
                        {
                            Temp = new Entity(TR3MixEntityAttribute.EntityLogicalName);
                            Temp.Attributes.Add(TR3MixEntityAttribute.CreatedbeforeBcDbc, true);
                            Temp.Id = Tr3mix.Id;
                            serviceConnector.Update(Temp);

                        }
                        customTrace.AppendLine("1)Get all tr3 Mix Update End ");
                    }
                    #endregion

                    #region Update Tr2TestReport  BC/DBC flag
                    customTrace.AppendLine("1)Update Tr2TestReport  BC/DBC flag");
                    if (Tr2Record != null && Tr2Record.Id != null)
                    {
                        customTrace.AppendLine("GetTR2TestReportFromTR2TechnicalReport");
                        TR3s = new EntityCollection();
                        TR3s = FeeCalculationStandardizationHandler.GetTR2TestReportFromTR2TechnicalReport(serviceConnector, Tr2Record, customTrace, feeObject);
                        if (TR3s != null && TR3s.Entities.Count > 0)
                        {
                            customTrace.AppendLine("Update start");
                            foreach (Entity Tr2Test in TR3s.Entities)
                            {
                                Temp = new Entity(TR2TestReport.EntityLogicalName);
                                Temp.Attributes.Add(TR2TestReport.CreatedbeforeBcDbc, true);
                                Temp.Id = Tr2Test.Id;
                                serviceConnector.Update(Temp);

                            }
                            customTrace.AppendLine("Update Tr2test report end");
                        }
                    }

                    #endregion






                }


                else if (feeObject.IsBE && (reportStatus == (int)CurrentFilingStatus.PermitEntire || reportStatus == (int)CurrentFilingStatus.PermitIssued) && (prereportStatus != (int)CurrentFilingStatus.PermitEntireBCDBCReview && prereportStatus != (int)CurrentFilingStatus.PermitEntireBCDBCReviewObjections && prereportStatus != (int)CurrentFilingStatus.PermitEntire))
                   
                {
                    /// check if scope is boiler  and filing type is new installation
                    /// if above both are true then create a number for each device in the application based on the rules
                    /// update the above number on child device
                    /// Create a new master device with the same device number
                    /// 


                    if (preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value > 0)
                    {
                        // if the pw1 is prof cert with pw2 then call existing method first 
                        //to determine Pw1 prof cert with pw2 use procert flag and is work permit availble flag . if both true then it is prof cert with pw2

                        if (preTargetEntity.Contains(JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName) && preTargetEntity[JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName) &&
                           preTargetEntity.Contains(JobFilingEntityAttributeName.ProfessionalCertificate) && preTargetEntity[JobFilingEntityAttributeName.ProfessionalCertificate] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate))
                        {
                            customTrace.AppendLine("Prof cert with pw2 calll existing boiler method first");
                            FeeCalculationStandardizationHandler.BoilerExistingDeviceMainMethod(serviceConnector, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value);
                        }

                        customTrace.AppendLine("Permit entire --call proposed device BoilerMainMethod");
                        FeeCalculationStandardizationHandler.BoilerMainMethod(serviceConnector, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value);
                      
                    }




                }

                else if (feeObject.IsBE && (reportStatus == (int)CurrentFilingStatus.Approved) && (prereportStatus != (int)CurrentFilingStatus.Approved))
                {
                    //get the filing type of jobfiling

                    feeObject.IsPAA = (targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity[JobFilingEntityAttributeName.FilingTypeAttributeName] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA) ? true : (preTargetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && preTargetEntity[JobFilingEntityAttributeName.FilingTypeAttributeName] != null && preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA) ? true : false;


                    if (preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value > 0 && !feeObject.IsPAA) //only should work for I1 and S1
                    {
                        customTrace.AppendLine("Approved I1 --call Existing device BoilerExistingDeviceMainMethod");
                        FeeCalculationStandardizationHandler.BoilerExistingDeviceMainMethod(serviceConnector, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value);

                    }



                }

               DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Testing", null, customTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "COCBinUpdationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
