﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class FAB4FeeCalculationPlugin : IPlugin
    {
        // to do write summary ,filtering attributes
        /// <summary>
        /// Fab4FeeCalculation Handler -  [Plugin generates the Fee Calculation] - Filing fee, PAA fee, Inconjunction fee, Fee exempt.
        /// Register on JobFiling Entity
        ///       * (a) Pre-Create Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_jobfiling (primary)
        ///       * (b) Post-Create Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_jobfiling (primary)
        ///       * (c) Pre-Update Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_jobfiling  (primary)
        ///             * Filtering Attributes -Amount Due,Amount Paid, Building Type,Construction Fence,Is Conjunction Job, Is Job Submitted,Refund, Size of the Shed, Supported Scaffold, SideWlak Shed,
        ///                                     Filing Fees,InConjunction fee,Is Fee Exempt,New Work Filing Fee,No Good Check,PAA Fee,Record Management Fee,Total Job cost, iselectricalworktype
        ///       * (d) Post-Update Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_jobfiling  (primary)
        ///             * Filtering Attributes -Amount Due,Amount Paid, Building Type,Construction Fence,Is Conjunction Job, Is Job Submitted,Refund, Size of the Shed, Supported Scaffold, SideWlak Shed,
        ///                                     Filing Fees,InConjunction fee,Is Fee Exempt,New Work Filing Fee,No Good Check,PAA Fee,Record Management Fee,Total Job cost,iselectricalworktype                             
        ///            
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity preImage = new Entity();
            Entity targetEntity = null;

            try
            {
                #region Initialise Plugin

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());

                customTrace.AppendLine("Return: Depth > 1");
                if (context.Depth > 1)
                    return;

                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");

                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity == null)
                {
                    customTrace.AppendLine("-- ERROR:::  Target Entity NOT found..");
                    return;
                }

                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                {
                    return;
                }
                customTrace.AppendLine("-- Target Entity: " + targetEntity.LogicalName);
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                {
                    preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? context.PreEntityImages[PluginHelperStrings.PreImageName] : null;

                    if (preImage == null)
                    {
                        customTrace.AppendLine("-- ERROR:::  Pre-Image NOT found..");
                        return;
                    }
                }
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                {
                    return;
                }

                #endregion

                Fab4FeeCalculationobject feeObject = new Fab4FeeCalculationobject();
                #region ElectricalFee
                if (targetEntity.Contains(JobFilingEntityAttributeName.isElectricalWorkType) && targetEntity[JobFilingEntityAttributeName.isElectricalWorkType] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType) == true)
                {
                    
                                               

                        customTrace.AppendLine("Stage -  Operation");
                        // to be removed - sign fee condition
                        #region Create Payment/Transaction history records
                      

                        customTrace.AppendLine("Create payment history - plugin -Start");
                        //  Guid paymentHistoryId = Fab4_FeeCalculationHelper.CreatePaymentHistory(serviceConnector, targetEntity, customTrace, context.SharedVariables);

                        #region Electrical Fee Calculation Save
                        //Create Message
                        if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                        {
                            customTrace.AppendLine("Electrical Fee - Create message -Start");
                            Fab4FeeCalculationHandler.ElectricalFee(feeObject, targetEntity, serviceConnector, null, customTrace, context.SharedVariables, context);
                            customTrace.AppendLine("Electrical Fee - Create message -End");
                        }
                        //Update Message
                        else if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                        {

                            customTrace.AppendLine("Electrical Fee - Update message -Start");
                            Fab4FeeCalculationHandler.ElectricalFee(feeObject, targetEntity, serviceConnector, preImage, customTrace, context.SharedVariables, context);
                            customTrace.AppendLine("Electrical Fee - Update message -End");
                        }

                    }                
                #endregion

                #endregion

                #endregion

                // sign condition - to be removed 
                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true) || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed)
                       && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true) || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true
                       || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true
                       ))
                {

                    customTrace.AppendLine("check if building type is not null");
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        //throw new Exception("test" + targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType));
                        #region Pre Operation 
                        if (context.Stage == 20)
                        {
                            customTrace.AppendLine("Stage - Pre Operation");


                            #region  Fee Calculation 


                            #region On Save - isSubmitted NO (Fab4)
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                            {

                                //check Fab4 fee calculation
                                #region Fab4 Fee Calculation Save
                                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true) ||
                                   (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true) ||
                                   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true) ||
                                   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true))
                                {
                                    ///IN Fab4 User can file 3 work types together in single job filing so using 'if' will be useful by doing so we can calculate each work type individually and pass it to second if.
                                    ///By the end of all if's we will have each work type fee in respective feeobject variable. In total fee we add up all individual fees and get the total fee for that job filing

                                    feeObject.BuildingType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value;
                                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                                    {

                                        customTrace.AppendLine("Construction Fence Fee handler - Start");
                                        feeObject = Fab4FeeCalculationHandler.Constructionfence_FeeCalculation(serviceConnector, targetEntity, customTrace, feeObject, context.MessageName.ToUpper());
                                        customTrace.AppendLine("Construction Fence Fee handler - End");
                                    }
                                    if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                                    {
                                        customTrace.AppendLine("SideWalk Fee handler - Start");
                                        feeObject = Fab4FeeCalculationHandler.SideWalk_FeeCalculation(serviceConnector, targetEntity, customTrace, feeObject, context.MessageName.ToUpper());
                                        customTrace.AppendLine("SideWalk Fee handler - End");
                                    }
                                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                                    {
                                        customTrace.AppendLine("Supported Scaffold Fee handler - Start");
                                        feeObject = Fab4FeeCalculationHandler.SupportedScaffold_FeeCalculation(serviceConnector, targetEntity, customTrace, feeObject, context.MessageName.ToUpper());
                                        customTrace.AppendLine("Supported Scaffold Fee handler - End");
                                    }


                                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                                    {
                                        ///1)Retrive all related signs for that application,check landmark from property profile
                                        ///2)Loop through each sign and calculate fee and add it to earlier sign fee
                                        ///3)By the end of the loop we will calculate all signs fee and stored in feeobject
                                        ///


                                        #region retrieve all signs associated to application
                                        customTrace.AppendLine("Get All Signs-Start");
                                        EntityCollection signsCollection = Fab4FeeCalculationHandler.assocaitedSigns(serviceConnector, targetEntity, customTrace, feeObject);

                                        if (signsCollection != null && signsCollection.Entities.Count > 0)
                                        {
                                            customTrace.AppendLine("Get All Signs-End" + signsCollection.Entities.Count);
                                            customTrace.AppendLine("Supported Sign Fee handler - Start");
                                            foreach (Entity sign in signsCollection.Entities)
                                            {
                                                feeObject = Fab4FeeCalculationHandler.Sign_FeeCalculation(serviceConnector, targetEntity, sign, customTrace, feeObject, context.MessageName.ToUpper());
                                            }
                                            customTrace.AppendLine("Supported Sign Fee handler - End");
                                        }

                                        #endregion




                                    }
                                    // In pre operation of create  preimage will be not be available so passing null
                                    if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                                    {
                                        customTrace.AppendLine("Total Fee - create message -Start");
                                        Fab4FeeCalculationHandler.TotalFee(feeObject, targetEntity, serviceConnector, null, customTrace, context.SharedVariables, context);
                                        customTrace.AppendLine("Total Fee -create message -End");
                                    }
                                    else if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper()) //update message
                                    {

                                        customTrace.AppendLine("Total Fee - Update message -Start");
                                        Fab4FeeCalculationHandler.TotalFee(feeObject, targetEntity, serviceConnector, preImage, customTrace, context.SharedVariables, context);
                                        customTrace.AppendLine("Total Fee - Update message -End");
                                    }
                                }
                                #endregion

                            }
                            #endregion

                            #region On File -isSubmitted YES (Fab4)
                            // for setting temporary adjustment to final adjustment on filing
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true)
                            {
                                customTrace.AppendLine("On File FAB4 -Start");
                                #region  Fee Calculation File- Setting Adjustment Values
                                decimal Adjustment = preImage.Attributes.Contains(JobFilingEntityAttributeName.Refund) && preImage[JobFilingEntityAttributeName.Refund] != null && preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value > 0 ? preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value : 0;
                                customTrace.AppendLine("Get Adjustment Final FAB4 :" + Adjustment);

                                if (Adjustment != 0)
                                {
                                    customTrace.AppendLine("On File FAB4 SET Adjustment -Start");
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(Adjustment));
                                    context.SharedVariables.Add(JobFilingEntityAttributeName.sharedRefund, Adjustment); // used in post operation and creation of payment history
                                    customTrace.AppendLine("On File FAB4 SET Adjustment -END");
                                }
                                targetEntity.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                customTrace.AppendLine("On File FAB4 -END");
                                #endregion

                            }
                            #endregion

                            #endregion

                        }
                        #endregion

                        #region Post

                        else if (context.Stage == 40)
                        {

                            //return if target entity has process and stageid
                       


                            customTrace.AppendLine("Stage - Post Operation");
                            // to be removed - sign fee condition
                            #region Create Payment/Transaction history records
                            if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                                || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                                 || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                                 || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                                 )
                            {




                                Guid paymentHistoryId = new Guid();


                                customTrace.AppendLine("Create payment history - plugin -Start");
                                //  Guid paymentHistoryId = Fab4_FeeCalculationHelper.CreatePaymentHistory(serviceConnector, targetEntity, customTrace, context.SharedVariables);

                                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                                {
                                    //delete payment history records which are not posted
                                    customTrace.AppendLine("Delete PHs-start");
                                    Fab4FeeCalculationHandler.DeleteOldPaymentHistory(serviceConnector, customTrace, targetEntity);
                                    customTrace.AppendLine("Delete PHs-End");
                                }
                                ///this creation of payment history only on 3 conditions 1) is submitted no  
                                ///2)issubmitted yes and adjustment has value
                                ///3)AMount due greater than 0
                                ///same applicable to transaction history
                                ///



                                if (((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false) && (context.SharedVariables.Contains(JobFilingEntityAttributeName.sharedAmountdue) && (decimal)context.SharedVariables[JobFilingEntityAttributeName.sharedAmountdue] > 0)) ||
                                    (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && context.SharedVariables.Contains(JobFilingEntityAttributeName.sharedRefund) && (decimal)context.SharedVariables[JobFilingEntityAttributeName.sharedRefund] > 0)
                                     )
                                {
                                    paymentHistoryId = Fab4_FeeCalculationHelper.CreatePaymentHistory(serviceConnector, targetEntity, customTrace, context.SharedVariables);
                                }



                                customTrace.AppendLine("Create payment history -plugin-End");
                                //have to add one condition when amount due is >0
                                #region fab4TransactionHistory
                                //If any error occur in Corrections adjustment TH add iscorrection completed falg in condition
                                if (((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                                 || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                                 || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                                 || (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                                 || (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                                 && (context.SharedVariables.Contains(JobFilingEntityAttributeName.sharedAmountdue) && (decimal)context.SharedVariables[JobFilingEntityAttributeName.sharedAmountdue] > 0)
                                 || (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && context.SharedVariables.Contains(JobFilingEntityAttributeName.sharedRefund) && (decimal)context.SharedVariables[JobFilingEntityAttributeName.sharedRefund] > 0)
                                  )
                                )
                                {
                                    customTrace.AppendLine("Create transaction history - plugin -Start");

                                    Fab4FeeCalculationHandler.CreateFAB4TransactionHistoryRecords(context.SharedVariables, targetEntity, paymentHistoryId, serviceConnector, customTrace, preImage);
                                    customTrace.AppendLine("Create transaction history - plugin -End");
                                }
                                #endregion




                            }
                            #endregion
                        }
                        #endregion

                    }
                }



            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}