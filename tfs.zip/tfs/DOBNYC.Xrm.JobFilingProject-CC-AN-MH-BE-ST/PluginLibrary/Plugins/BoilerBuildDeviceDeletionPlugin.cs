﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class BoilerBuildDeviceDeletionPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = new Entity();

            try
            {
                string currentCrmUserId = String.Empty;
                //Entity targetEntity = null;
                customTrace.AppendLine("Begin: Get context..");
                var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());

                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);

                if (context.Depth > 1)
                    return;

                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is EntityReference))
                {
                    #region On Delete Context
                    if (context.MessageName == PluginHelperStrings.DeleteMessageName)
                    {
                        customTrace.AppendLine("Delete Request");

                        EntityReference entity = (EntityReference)context.InputParameters["Target"];
                        customTrace.AppendLine("targetEntityId: " + entity.Id.ToString());
                        customTrace.AppendLine("Entity Logical Name: " + entity.LogicalName);
                        if (entity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)
                        {
                            Guid targetEntityId = entity.Id;
                            customTrace.AppendLine("targetEntityId: " + targetEntityId.ToString());
                            ColumnSet columns = new ColumnSet(new string[] { BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup, BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation, BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet});
                            targetEntity = service.Retrieve(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, targetEntityId, columns);
                            customTrace.AppendLine("Calling DeleteBoilerBuildDeviceDocument - Start");
                            InspectionComponentsAutoPopulationHandler.DeleteBoilerBuildDeviceDocument(service, targetEntity, customTrace);
                            customTrace.AppendLine("Calling DeleteBoilerBuildDeviceDocument - End");
                        }
                    }
                    #endregion
                }                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout InnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BoilerBuildDeviceDeletionPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                }
        }
    }
}
