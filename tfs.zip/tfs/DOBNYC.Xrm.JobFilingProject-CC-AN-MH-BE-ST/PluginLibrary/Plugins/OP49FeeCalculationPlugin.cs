﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class OP49FeeCalculationPlugin : IPlugin
    {
        /// <summary>
        ///  Post create on op49 to create PH and TH
        ///  Pre Update on op49 with filtering attributes issubmit and inspection date . this plugin will calculate fee and PH creation . preimage required
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables Declaration
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            string PaymentHistoryGUID = string.Empty;
            #endregion

            try
            {
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != OP49EntityAttributeNames.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];


                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 2)
                    return;
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;

                #endregion


                /// NOTE: Feeobject.BEMSSTFilingfee treated as initial filing fee for op49
                /// Feeobject.RecordManagementFees  will be treated as late filing fee


                customTrace.AppendLine("NOTE: Feeobject.BEMSSTFilingfee treated as initial filing fee for op49 . Feeobject.RecordManagementFees  will be treated as late filing fee");


                if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper() && context.Stage == 40) //post create -to create PH and TH
                {
                //    customTrace.AppendLine("Create plugin");
                //    if (targetEntity.Contains(OP49EntityAttributeNames.AmountDue) && targetEntity[OP49EntityAttributeNames.AmountDue] != null && targetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountDue).Value > 0)
                //    {

                //        customTrace.AppendLine("NOTE: set fee object params in post create - start");
                //        feeObject.BEMSSTFilingfee = targetEntity.Contains(OP49EntityAttributeNames.FilingFee) && targetEntity[OP49EntityAttributeNames.FilingFee] != null ? targetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.FilingFee).Value : 0;
                //        feeObject.RecordManagementFees = targetEntity.Contains(OP49EntityAttributeNames.LateFee) && targetEntity[OP49EntityAttributeNames.LateFee] != null ? targetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.LateFee).Value : 0;
                //        feeObject.ExistingAmountPaid = 0;
                //        feeObject.amountDue = targetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountDue).Value;
                //        customTrace.AppendLine("NOTE: set fee object params in post create - end");
                //        FeeCalculationStandardizationHandler.AfterFeeCalculationOP49(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, targetEntity, feeObject);
                //        serviceConnector.Update(targetEntity); //beacuse in post create we have to update ph guid on target entity
                //    }
                }
                else if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && context.Stage == 20) //pre update- both fee calc and PH creation
                {
                    customTrace.AppendLine("Update plugin");
                    if (targetEntity.Contains(OP49EntityAttributeNames.UserfilingActions) && targetEntity[OP49EntityAttributeNames.UserfilingActions] != null)
                    {
                        if (targetEntity.GetAttributeValue<OptionSetValue>(OP49EntityAttributeNames.UserfilingActions).Value == (int)UserfilingActionsOP49.Submit)
                        {
                            //DateTime InspectionDate = targetEntity.Contains(OP49EntityAttributeNames.InspectionDate) && targetEntity[OP49EntityAttributeNames.InspectionDate] != null ? Convert.ToDateTime(targetEntity.GetAttributeValue<DateTime>(OP49EntityAttributeNames.InspectionDate).ToShortDateString()) : preTargetEntity.Contains(OP49EntityAttributeNames.InspectionDate) && preTargetEntity[OP49EntityAttributeNames.InspectionDate] != null ? Convert.ToDateTime(preTargetEntity.GetAttributeValue<DateTime>(OP49EntityAttributeNames.InspectionDate).ToShortDateString()) : null; //Annual Inspection Date (either from target or Preimage)
                            //if (InspectionDate !=null )//if preimage does not contain inspection date
                            //{
                               // throw new Exception("test");

                                customTrace.AppendLine("inspection date changed so Calculate  Fee");
                                #region Set OP49 Initial Filing Fee
                                customTrace.AppendLine("Begin: Setting OP49 Filing Fee");
                                OP49FeeCalculationHandler.SetOP49InitialFee(serviceConnector, targetEntity, customTrace, feeObject);
                                customTrace.AppendLine("End: Setting OP49 Filing Fee");
                                #endregion
                                #region set late Filing Fee and amount due
                                OP49FeeCalculationHandler.CalculateOP49LateFilingFee(serviceConnector, targetEntity, preTargetEntity, customTrace, feeObject);
                                #endregion
                            //}

                        }

                    }
                    #region On File, On Correction completed , On Loc Initiated  -isSubmitted YES 
                    // for setting temporary adjustment to final adjustment on filing
                    customTrace.AppendLine("Boilers Work Type OnFileCorrectionsCompletedOP49 Started");
                    FeeCalculationStandardizationHandler.OnFileCorrectionsCompletedOP49(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);

                    #endregion
                    #region Payment and Transaction History Creation


                    customTrace.AppendLine("AfterFeeCalculationOP49 starting update");
                    FeeCalculationStandardizationHandler.AfterFeeCalculationOP49(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);



                    #endregion



                }
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - testing", null, customTrace.ToString(), null, null);


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
