﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;


namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class EODplugin : IPlugin
    {
        /// <summary>
        /// EODHandler [Plugin generates the No Good Check]
        /// Register on EOD File Entity
        ///     * Post-Create Stage - Synchronous - Server - Calling user - Exe order (1) - dobnyc_eodfile (primary)
        /// </summary>
        /// <param name="serviceProvider"></param>

        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {
                #region Initialise Plugin

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());

                customTrace.AppendLine("Return: Depth Jobfiling > 1");
                if (context.Depth > 1)
                    return;

                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User:Jobfiling " + currentCrmUserId);

                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..Jobfiling");

                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..Jobfiling");

                if (targetEntity == null)
                {
                    customTrace.AppendLine("-- ERROR:::  Target Entity NOT found..Jobfiling");
                    return;
                }
                customTrace.AppendLine("-- Target Entity: Jobfiling" + targetEntity.LogicalName);

                #endregion

                if (targetEntity.GetAttributeValue<bool>(EODAttributeNames.EcheckReturnFlag) == true )
                {
                    customTrace.AppendLine("No Good Check Jobfiling- start");
                    EODHandler.NoGoodCheckCC(serviceConnector, customTrace, targetEntity);
                    customTrace.AppendLine("No Good Check Jobfiling- end");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODplugin - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
        }
    }
}