﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;



namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    [Serializable]
    public class TimeOffCalender : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            StringBuilder messageString = new StringBuilder();
            try
            {

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                Entity targetEntity = null;
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");

                EntityCollection CalendarRule = targetEntity.GetAttributeValue<EntityCollection>("calendarrules");
                int count = CalendarRule.Entities.Count;

                DateTime startdate = CalendarRule.Entities[count - 1].GetAttributeValue<DateTime>("starttime");
                string description = CalendarRule.Entities[count - 1].GetAttributeValue<string>("description");


                customTrace.AppendLine("startdate " + startdate);
                customTrace.AppendLine("description " + description);
                
                if (description == "Time Off Rule")
                {

                    #region Get userId
                    ConditionExpression conditionExpression = new ConditionExpression();
                    conditionExpression.AttributeName = "calendarid";
                    conditionExpression.Operator = ConditionOperator.Equal;
                    conditionExpression.Values.AddRange(targetEntity.Id.ToString());


                    FilterExpression filterExpression = new FilterExpression();
                    filterExpression.Conditions.AddRange(conditionExpression);
                    filterExpression.FilterOperator = LogicalOperator.And;

                    ColumnSet columns = new ColumnSet(true);
                    QueryExpression qe = new QueryExpression();
                    qe.EntityName = SystemuserEntityAttributeNames.EntityName;
                    qe.ColumnSet = new ColumnSet(true);
                    qe.Criteria = filterExpression;
                    qe.NoLock = true;
                    EntityCollection response = serviceConnector.RetrieveMultiple(qe);
                    Entity user = response.Entities[0];
                    Guid userId = user.Id;
                    #endregion

                    customTrace.AppendLine("calendarid response " + response);

                    #region Conditions


                    DateTime StartDate = startdate;
                    DateTime Enddate = StartDate.Date;
                    Enddate = Enddate.AddDays(1);

                    string[] AptColumnNames = new string[] { AppointmentAttributeName.StartTimeAttributeName, AppointmentAttributeName.EndTimeAttributeName, AppointmentAttributeName.RequiredAttendees };
                    ConditionExpression AptOwnerCondition = CreateConditionExpression(AppointmentAttributeName.OwnerAttributeName, ConditionOperator.Equal, new string[] { userId.ToString() });
                    ConditionExpression AptStateCondition = CreateConditionExpression(AppointmentAttributeName.statecode, ConditionOperator.Equal, new object[] { 3 });
                    ConditionExpression AptStatusCondition = CreateConditionExpression(AppointmentAttributeName.AppointmentStatus, ConditionOperator.Equal, new object[] { 5 });
                    ConditionExpression AptDate1Condition = CreateConditionExpression(AppointmentAttributeName.StartTimeAttributeName, ConditionOperator.GreaterThan, new string[] { StartDate.ToString() });
                    ConditionExpression AptDate2Condition = CreateConditionExpression(AppointmentAttributeName.StartTimeAttributeName, ConditionOperator.LessThan, new string[] { Enddate.ToString() });

                    #endregion Conditions

                    #region Filters
                    FilterExpression appointmentFilters = new FilterExpression();
                    appointmentFilters.Conditions.AddRange(AptOwnerCondition);
                    appointmentFilters.Conditions.AddRange(AptStateCondition);
                    appointmentFilters.Conditions.AddRange(AptStatusCondition);
                    appointmentFilters.Conditions.AddRange(AptDate1Condition);
                    appointmentFilters.Conditions.AddRange(AptDate2Condition);
                    appointmentFilters.FilterOperator = LogicalOperator.And;
                    #endregion Filters

                    #region Query Expression
                    QueryExpression qexp = new QueryExpression();
                    qexp.EntityName = AppointmentAttributeName.EntityLogicalName;
                    qexp.Criteria = appointmentFilters;
                    qexp.ColumnSet.AddColumns(AptColumnNames);
                    EntityCollection Apointmentresponse = serviceConnector.RetrieveMultiple(qexp);
                    #endregion Query Expression


                    customTrace.AppendLine("Appointments count " + Apointmentresponse.Entities.Count);
                    if (Apointmentresponse != null && Apointmentresponse.Entities.Count > 0)
                    {
                        messageString.AppendLine("Alert!!");
                        messageString.AppendLine("You have " + Apointmentresponse.Entities.Count + " appointments;");
                        foreach (var appointment in Apointmentresponse.Entities)
                        {
                            string Date = string.Empty;
                            string StartTime = string.Empty;
                            string EndTime = string.Empty;
                            string attendee = string.Empty;

                            if (appointment.Attributes.Contains(AppointmentAttributeName.RequiredAttendees))
                            {

                                var col = ((EntityCollection)appointment.Attributes[AppointmentAttributeName.RequiredAttendees]);
                                var attendeeId = col.Entities[0].Id.ToString();
                            }

                            if (appointment.Attributes.Contains(AppointmentAttributeName.StartTimeAttributeName))
                                Date = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.StartTimeAttributeName).ToShortDateString();

                            if (appointment.Attributes.Contains(AppointmentAttributeName.StartTimeAttributeName))
                                StartTime = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.StartTimeAttributeName).ToLocalTime().ToShortTimeString();

                            if (appointment.Attributes.Contains(AppointmentAttributeName.EndTimeAttributeName))
                                EndTime = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.EndTimeAttributeName).ToLocalTime().ToShortTimeString();

                            messageString.AppendLine("Date: " + Date);
                            messageString.AppendLine("StartTime: " + StartTime);
                            messageString.AppendLine("EndTime: " + EndTime);
                            messageString.AppendLine("******");
                        }
                        messageString.AppendLine("Please cancel the appointments first to take time-off");

                        throw new Exception();
                        
                    }
                }

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("TimeOffCalender", "SourceChannel", "Execute", customTrace.ToString(), " Execute trace log", "User ID", "UserBrowserInfo");
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "Execute", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", "TimeOffCalender Class - Execute Method Exceptions", "browserinfo");
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
                throw new InvalidPluginExecutionException(OperationStatus.Failed, messageString.ToString());
            }
        }

        public static ConditionExpression CreateConditionExpression(string attributeName, ConditionOperator conditionOperator, object[] conditionValues)
        {
            ConditionExpression conditionExpression = new ConditionExpression();
            try
            {
                conditionExpression.AttributeName = attributeName;
                conditionExpression.Operator = conditionOperator;
                if (conditionValues != null && conditionValues.Length > 0)
                {
                    conditionExpression.Values.AddRange(conditionValues);
                }
            }
            catch (Exception ex)
            {
                // ExceptionLibrary.ExceptionMethods.ProcessException(ex); return null;
            }
            return conditionExpression;
        }



    }
}
