﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersPATPARelatedEntities;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class DocumentItemPATPAPlugin : IPlugin
    {
        /// On Creation of Place of Assembly Plans Record is Each document List created 
        /// On Deletion Of Place of Assembly Plan Record the document list is deleted in CRM.
        ///
        /// Register the Plugin on Place of Assembly Space Information
        ///     * (a) Pre-Create Stage - Synchronous - Server - SVC CRMPROXYADMDEV - Exe order (1) - dobnyc_placeofassemblyplans (primary)
        ///     * (b) Pre-Delete Stage - Synchronous - Server - SVC CRMPROXYADMDEV - Exe order (1) - dobnyc_placeofassemblyplans (primary)
        ///           Pre-Image Step Registered 
        ///           Image Name: PreImage
        ///           Entity Ailas: PreImage
        ///           Parameters : All Attributes
        ///                     
        /// Date: 04/18/2018
        /// Written By: Habeeb Mohammad
        /// </summary>

        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debug the plug-in
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                //Check the depth avoid infinite loops
                if (context.Depth > 1)
                    return;

                #region Place of Assembly Plan Documents
                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    if (targetEntity.LogicalName == PlaceofAssemblyPlans.EntityLogicalName)
                    {
                        customTrace.AppendLine("Start  CreateDocumentsPATPA Documents handler: " + PluginHelperStrings.CreateMessageName);
                        string Name = targetEntity.GetAttributeValue<string>(PlaceofAssemblyPlans.Name);
                        customTrace.AppendLine("Name: " + Name);
                        PATPAHandler.CreateDocumentsPA(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End  CreateDocumentsPATPA Documents handler: " + PluginHelperStrings.CreateMessageName);
                    }
                    #endregion
                }

                if (context.MessageName.ToUpper() == PluginHelperStrings.DeleteMessageName.ToUpper())
                {
                    Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];
                    customTrace.AppendLine("Start DeleteDocumentsPATPA Documents handler: " + PluginHelperStrings.DeleteMessageName);
                    DOBLogger.WriteTraceLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", null, customTrace.ToString(), null, null);
                    PATPAHandler.DeleteDocumentsPA(serviceConnector, preTargetEntity, customTrace);
                    customTrace.AppendLine("End  DeleteDocumentsPATPA Documents handler: " + PluginHelperStrings.DeleteMessageName);
                }

                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - TEST", null, customTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "DocumentItemPATPAPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
