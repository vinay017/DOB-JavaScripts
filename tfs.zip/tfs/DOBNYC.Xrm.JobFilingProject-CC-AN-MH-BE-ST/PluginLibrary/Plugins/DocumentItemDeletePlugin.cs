﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class DocumentItemDeletePlugin : IPlugin
    {
        /// <summary>
        /// Plugin Delete the Required item list
        /// </summary>

        public void Execute(IServiceProvider serviceProvider)
        {
            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = new Entity();

            try
            {
                string currentCrmUserId = String.Empty;
                //Entity targetEntity = null;
                customTrace.AppendLine("Begin: Get context..");
                var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
                // Obtain the organization service reference.
                IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = factory.CreateOrganizationService(context.UserId);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                
                if (context.Depth > 1)
                    return;
                if (context.InputParameters.Contains("Target") && (context.InputParameters["Target"] is EntityReference))
                {
                    #region On Delete Context
                    if (context.MessageName == PluginHelperStrings.DeleteMessageName)
                    {
                        customTrace.AppendLine("Delete Request");
                        //entity = CommonPluginLibrary.GetEntityMonikerFromContext(context);
                        EntityReference entity = (EntityReference)context.InputParameters["Target"];
                        customTrace.AppendLine("targetEntityId: " + entity.Id.ToString());
                        customTrace.AppendLine("Entity Logical Name: " + entity.LogicalName);
                        if (entity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName)
                        {
                            Guid targetEntityId = entity.Id;
                            customTrace.AppendLine("targetEntityId: " + targetEntityId.ToString());
                            ColumnSet columns = new ColumnSet(true);
                            targetEntity = service.Retrieve(ScopeOfWorkEntityAttributeName.EntityLogicalName, targetEntityId, columns);
                            DocumentItemUploadHandler.DeleteRequiredItemstoJobFiling_ScopeofWork(service, targetEntity, customTrace, context);
                        }
                        if (entity.LogicalName == ProgressInspectionCategoryEntityAttributeName.EntityLogicalName)
                        {
                            Guid targetEntityId = entity.Id;
                            customTrace.AppendLine("targetEntityId: " + targetEntityId.ToString());
                            ColumnSet columns = new ColumnSet(true);
                            targetEntity = service.Retrieve(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, targetEntityId, columns);
                            DocumentItemUploadHandler.DeleteRequiredItemstoJobFiling_ProgressInspection(service, targetEntity, customTrace, context);
                        }
                    }
                    #endregion
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemDeletePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception("Aqib" + ex + ": " + customTrace);
            }
        }

    }
}
