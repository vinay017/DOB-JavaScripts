﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
   public class PATPATaskCompletionPlugin : IPlugin
    {
        ///
        /// Register the Plugin on task Entity
        ///     * (a) Post-Update Stage - Synchronous - Server - SVC CRMPROXYADMDEV - Exe order (1) - task (primary) - this step is used to update grant waiver flag 
        ///           filtered attributes-statuscode
        ///           preimage-all attributes
        ///     
        /// 
        ///          
        /// Date: 06/26/2018
        /// Written By: Rupal
        /// </summary>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");


                //if (context.Depth > 2)   Keep it commmented
                //    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];
                //Check the depth avoid infinite loops
                if (context.Depth > 2)
                    return;

                // Verify that the target entity represents is task
                if (targetEntity.LogicalName != TaskEntityAttributeNames.EntityLogicalName)
                    return;

                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                {
                    if (context.Stage == 40)
                    {
                        EntityReference regardingObject = (EntityReference)(preTargetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId]);

                        if (regardingObject != null && regardingObject.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                        {

                            customTrace.AppendLine("retrieve job filing details");
                            Entity JobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, regardingObject.Id, new Microsoft.Xrm.Sdk.Query.ColumnSet(new string[] { JobFilingEntityAttributeName.PACheckBox, JobFilingEntityAttributeName.TPACheckBox, JobFilingEntityAttributeName.PAFilingReviewType, JobFilingEntityAttributeName.FilingStatus }));
                            if (JobFiling != null &&
                               ( (JobFiling.Contains(JobFilingEntityAttributeName.PACheckBox) && JobFiling[JobFilingEntityAttributeName.PACheckBox] != null && JobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox)) || (JobFiling.Contains(JobFilingEntityAttributeName.TPACheckBox) && JobFiling[JobFilingEntityAttributeName.TPACheckBox] != null && JobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))  ) && //must be PA or TPA worktype only
                                (JobFiling.Contains(JobFilingEntityAttributeName.PAFilingReviewType) && JobFiling[JobFilingEntityAttributeName.PAFilingReviewType] != null && JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.PAFilingReviewType).Value == 1)&&//for standard plan only
                                (preTargetEntity.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && preTargetEntity[TaskEntityAttributeNames.CurrentFilingStatus]!=null && (preTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.CurrentFilingStatus).Value ==4 || preTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.CurrentFilingStatus).Value == 5))//current filings status should be in PE review or cpe review
                                )
                            {
                                customTrace.AppendLine("retrieve progress Inspection from jobfiling");

                                ConditionExpression condition1 = new ConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, JobFiling.Id);

                                //  OrderExpression order1 = new OrderExpression(ELV3InspectionAttributeNames.InspectionDate, OrderType.Descending);
                                QueryExpression query = new QueryExpression(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName);
                                query.ColumnSet = new ColumnSet(new string[] { ProgressInspectionCategoryEntityAttributeName.PreTaskCompletionInspectionWaived });
                                query.Criteria = new FilterExpression(LogicalOperator.And)
                                {
                                    Conditions =
                                                {
                                                condition1,

                                                }
                                };

                                EntityCollection records = serviceConnector.RetrieveMultiple(query);
                                customTrace.AppendLine("records count:" + records.Entities.Count);
                                if (records != null && records.Entities.Count > 0)
                                {
                                    customTrace.AppendLine("Update ProgressInspectionCategoryEntityAttributeName start");
                                    foreach (Entity progressInspectionCategory in records.Entities)
                                    {
                                        customTrace.AppendLine("set InspectionWaived value:");
                                        progressInspectionCategory.SetAttributeValue(ProgressInspectionCategoryEntityAttributeName.InspectionWaived, progressInspectionCategory.GetAttributeValue<bool>(ProgressInspectionCategoryEntityAttributeName.PreTaskCompletionInspectionWaived));
                                        serviceConnector.Update(progressInspectionCategory);
                                    }
                                    customTrace.AppendLine("Update ProgressInspectionCategoryEntityAttributeName End");
                                }


                            }
                        }



                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPATaskCompletionPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
