﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class SealSignaturesPlugin : IPlugin
    {
        // Summary  Create Plugin -- needs to be registered on Create //
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("context.Depth : " + context.Depth);
                if (context.Depth > 3)
                    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                #region WorkPermit Documents
                if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName && (context.MessageName == MessageName.Create))
                {
                    customTrace.AppendLine("Start WorkPermit Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.WorkPermitDocuments(serviceConnector, targetEntity,  new Entity(), context, customTrace);
                    if(targetEntity.Contains(WorkPermitEntityAttributeName.AntennaLicenseType))
                    SealSignaturesHandler.WorkPermitDocuments_AN(serviceConnector, targetEntity, new Entity(), context, customTrace);
                    customTrace.AppendLine("End WorkPermit Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region AHV Documents

                if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName && context.MessageName == MessageName.Create)
                {
                    #region Return for Crane AHV
                    if (targetEntity.Contains(PW5AfterHoursAttributeNames.TypeofPermit))
                    {
                        int typeofPermit = targetEntity.GetAttributeValue<OptionSetValue>(PW5AfterHoursAttributeNames.TypeofPermit).Value;
                        customTrace.AppendLine("typeofPermit: " + typeofPermit);
                        if (typeofPermit == (int)TypeofAHVPermit.CraneNotice || typeofPermit == (int)TypeofAHVPermit.MasterRigger || typeofPermit == (int)TypeofAHVPermit.OnsiteWaiver)
                        {
                            return;
                        }
                    }
                    #endregion

                    customTrace.AppendLine("Start  AHV Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.AHVDocuments(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  AHV Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region AHV Fee Exempt Document
                //Created On 10/30/2017 for Nov 30 release 
                if (targetEntity.LogicalName== AfterHourVarianceFeeExemptAttributeNames.EntityLogicalName)
                {
                    Entity preImage = null;
                    if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName))
                    {
                        preImage = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                        customTrace.AppendLine("PreImageSet");
                    }
                    else if(context.MessageName != MessageName.Create)
                    {
                        return;
                    }

                    #region Return for Crane AHV
                    if (targetEntity.Contains(PW5AfterHoursAttributeNames.TypeofPermit))
                    {
                        int typeofPermit = targetEntity.GetAttributeValue<OptionSetValue>(PW5AfterHoursAttributeNames.TypeofPermit).Value;
                        customTrace.AppendLine("typeofPermit: " + typeofPermit);
                        if (typeofPermit == (int)TypeofAHVPermit.CraneNotice || typeofPermit == (int)TypeofAHVPermit.MasterRigger || typeofPermit == (int)TypeofAHVPermit.OnsiteWaiver)
                        {
                            return;
                        }
                    }
                    #endregion

                    customTrace.AppendLine("Start  AHV Fee Exempt Documents handler:"+ PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.AHVFeeExemptDocuments(serviceConnector, targetEntity, preImage, context, customTrace);
                    customTrace.AppendLine("End  AHV Fee Exempt Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region SpecialInpection Documents
                if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  SpecialInpection Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.SpecialInspectionDocuments(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  SpecialInpection Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region ProgressInpection Documents
                if (targetEntity.LogicalName == ProgressInspectionCategoryEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  ProgressInpection Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.ProgressInspectionDocuments(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  ProgressInpection Documents handler: " + PluginHelperStrings.CreateMessageName);
                    
                }
                #endregion

                #region EN2 Documents
                if (targetEntity.LogicalName == EN2EntityAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  EN2 Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.En2Documents(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  EN2 Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region Withdrawal Request Documents
                if (targetEntity.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  Withdrawal Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.WithdrawalsDocuments(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  Withdrawal Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

                #region Superseding Request Documents
                if (targetEntity.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Start  Superseding Documents handler: " + PluginHelperStrings.CreateMessageName);
                    SealSignaturesHandler.SupersedingDocuments(serviceConnector, targetEntity, customTrace);
                    customTrace.AppendLine("End  Superseding Documents handler: " + PluginHelperStrings.CreateMessageName);
                }
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


    }
}
