﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Metadata;



namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    [Serializable]
    public class ValidateOpenAppointment : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            StringBuilder messageString = new StringBuilder();
            try
            {

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                Entity targetEntity = null;
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != AppointmentAttributeName.EntityLogicalName)
                    return;

                if (targetEntity.Attributes.Contains(AppointmentAttributeName.StartTimeAttributeName) && targetEntity.Attributes.Contains(AppointmentAttributeName.EndTimeAttributeName) && targetEntity.Attributes.Contains(AppointmentAttributeName.organizer))
                {

                    DateTime StartDate = targetEntity.GetAttributeValue<DateTime>(AppointmentAttributeName.StartTimeAttributeName).ToLocalTime();
                    customTrace.AppendLine("StartDate: " + StartDate.ToString());
                    DateTime Enddate = targetEntity.GetAttributeValue<DateTime>(AppointmentAttributeName.EndTimeAttributeName).ToLocalTime();
                    customTrace.AppendLine("Enddate: " + Enddate.ToString());
                    int appointmentType = targetEntity.GetAttributeValue<OptionSetValue>(AppointmentAttributeName.AppointmentType).Value;
                    string aptType = string.Empty;
                    if (appointmentType == 1)
                        aptType = "Regular Appointment";
                    if (appointmentType == 2)
                        aptType = "Add Break";
                    if (appointmentType == 3)
                        aptType = "Day(s) Off";
                    customTrace.AppendLine("Enddate: " + Enddate.ToString());
                    var organizer = (EntityCollection)targetEntity[AppointmentAttributeName.organizer];
                    var record = (Entity)organizer.Entities[0];
                    Guid userId = ((EntityReference)record["partyid"]).Id;
                    customTrace.AppendLine("userId: " + userId.ToString());

                    #region Got userId
                    string[] AptColumnNames = new string[] { AppointmentAttributeName.StartTimeAttributeName, AppointmentAttributeName.EndTimeAttributeName, AppointmentAttributeName.RequiredAttendees, AppointmentAttributeName.AppointmentType };
                    //ConditionExpression AptOwnerCondition = CreateConditionExpression(AppointmentAttributeName.OwnerAttributeName, ConditionOperator.Equal, new string[] { userId.ToString() });
                    ConditionExpression AptStateCondition = CreateConditionExpression(AppointmentAttributeName.statecode, ConditionOperator.Equal, new object[] { 3 });
                    ConditionExpression AptStatusCondition = CreateConditionExpression(AppointmentAttributeName.AppointmentStatus, ConditionOperator.Equal, new object[] { 5 });
                    ConditionExpression AptTypeCondition = CreateConditionExpression(AppointmentAttributeName.AppointmentType, ConditionOperator.Equal, new object[] { 1 });
                    ConditionExpression AptDate1Condition = CreateConditionExpression(AppointmentAttributeName.StartTimeAttributeName, ConditionOperator.LessThan, new string[] { StartDate.ToString() });
                    ConditionExpression AptDate2Condition = CreateConditionExpression(AppointmentAttributeName.EndTimeAttributeName, ConditionOperator.GreaterThan, new string[] { StartDate.ToString() });
                    ConditionExpression AptDate3Condition = CreateConditionExpression(AppointmentAttributeName.StartTimeAttributeName, ConditionOperator.LessThan, new string[] { Enddate.ToString() });
                    ConditionExpression AptDate4Condition = CreateConditionExpression(AppointmentAttributeName.EndTimeAttributeName, ConditionOperator.GreaterThan, new string[] { Enddate.ToString() });
                    ConditionExpression AptDate5Condition = CreateConditionExpression(AppointmentAttributeName.StartTimeAttributeName, ConditionOperator.GreaterEqual, new string[] { StartDate.ToString() });
                    ConditionExpression AptDate6Condition = CreateConditionExpression(AppointmentAttributeName.EndTimeAttributeName, ConditionOperator.LessEqual, new string[] { Enddate.ToString() });

                    #endregion Conditions

                    #region Filter 1
                    FilterExpression appointmentFilters1 = new FilterExpression();
                    //appointmentFilters1.Conditions.AddRange(AptOwnerCondition);
                    appointmentFilters1.Conditions.AddRange(AptStateCondition);
                    if(appointmentType == 2)
                    {
                        appointmentFilters1.Conditions.AddRange(AptTypeCondition);
                    }
                    appointmentFilters1.Conditions.AddRange(AptStatusCondition);
                    appointmentFilters1.Conditions.AddRange(AptDate1Condition);
                    appointmentFilters1.Conditions.AddRange(AptDate2Condition);
                    appointmentFilters1.FilterOperator = LogicalOperator.And;
                    #endregion Filters

                    #region Filter 2
                    FilterExpression appointmentFilters2 = new FilterExpression();
                    //appointmentFilters2.Conditions.AddRange(AptOwnerCondition);
                    appointmentFilters2.Conditions.AddRange(AptStateCondition);
                    if (appointmentType == 2)
                    {
                        appointmentFilters2.Conditions.AddRange(AptTypeCondition);
                    }
                    appointmentFilters2.Conditions.AddRange(AptStatusCondition);
                    appointmentFilters2.Conditions.AddRange(AptDate3Condition);
                    appointmentFilters2.Conditions.AddRange(AptDate4Condition);
                    appointmentFilters2.FilterOperator = LogicalOperator.And;
                    #endregion Filters

                    #region Filter 3
                    FilterExpression appointmentFilters3 = new FilterExpression();
                    //appointmentFilters3.Conditions.AddRange(AptOwnerCondition);
                    appointmentFilters3.Conditions.AddRange(AptStateCondition);
                    if (appointmentType == 2)
                    {
                        appointmentFilters3.Conditions.AddRange(AptTypeCondition);
                    }
                    appointmentFilters3.Conditions.AddRange(AptStatusCondition);
                    appointmentFilters3.Conditions.AddRange(AptDate5Condition);
                    appointmentFilters3.Conditions.AddRange(AptDate6Condition);
                    appointmentFilters3.FilterOperator = LogicalOperator.And;
                    #endregion Filters


                    #region Query Expression 1
                    QueryExpression qexp1 = new QueryExpression
                    {
                        EntityName = AppointmentAttributeName.EntityLogicalName,
                        Criteria = appointmentFilters1,
                        ColumnSet = new ColumnSet(AppointmentAttributeName.StartTimeAttributeName, AppointmentAttributeName.EndTimeAttributeName, AppointmentAttributeName.RequiredAttendees, AppointmentAttributeName.AppointmentType),
                        LinkEntities =
                        {
                        new LinkEntity
                        {
                            EntityAlias = "ap",
                            JoinOperator = JoinOperator.Inner,
                            LinkFromEntityName = "appointment",
                            LinkFromAttributeName = "activityid",
                            LinkToEntityName = "activityparty",
                            LinkToAttributeName = "activityid",
                            LinkCriteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("partyid", ConditionOperator.Equal ,userId),
                                },
                            },
                        },
                    },
                    };
                    EntityCollection Apointmentresponse1 = serviceConnector.RetrieveMultiple(qexp1);
                    customTrace.AppendLine("Apointmentresponse1 Count: " + Apointmentresponse1.Entities.Count);
                    #endregion Query Expression1

                    #region Query Expression 2
                    QueryExpression qexp2 = new QueryExpression
                    {
                        EntityName = AppointmentAttributeName.EntityLogicalName,
                    Criteria = appointmentFilters2,
                        ColumnSet = new ColumnSet(AppointmentAttributeName.StartTimeAttributeName, AppointmentAttributeName.EndTimeAttributeName, AppointmentAttributeName.RequiredAttendees, AppointmentAttributeName.AppointmentType),
                        LinkEntities =
                        {
                        new LinkEntity
                        {
                            EntityAlias = "ap",
                            JoinOperator = JoinOperator.Inner,
                            LinkFromEntityName = "appointment",
                            LinkFromAttributeName = "activityid",
                            LinkToEntityName = "activityparty",
                            LinkToAttributeName = "activityid",
                            LinkCriteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("partyid", ConditionOperator.Equal ,userId),
                                },
                            },
                        },
                    },

                    };
                    EntityCollection Apointmentresponse2 = serviceConnector.RetrieveMultiple(qexp2);
                    customTrace.AppendLine("Apointmentresponse2 Count: " + Apointmentresponse2.Entities.Count);
                    #endregion Query Expression2

                    #region Query Expression 3
                    QueryExpression qexp3 = new QueryExpression
                    {
                        EntityName = AppointmentAttributeName.EntityLogicalName,
                        Criteria = appointmentFilters3,
                        ColumnSet = new ColumnSet(AppointmentAttributeName.StartTimeAttributeName, AppointmentAttributeName.EndTimeAttributeName, AppointmentAttributeName.RequiredAttendees, AppointmentAttributeName.AppointmentType),
                        LinkEntities =
                        {
                        new LinkEntity
                        {
                            EntityAlias = "ap",
                            JoinOperator = JoinOperator.Inner,
                            LinkFromEntityName = "appointment",
                            LinkFromAttributeName = "activityid",
                            LinkToEntityName = "activityparty",
                            LinkToAttributeName = "activityid",
                            LinkCriteria = new FilterExpression
                            {
                                Conditions =
                                {
                                    new ConditionExpression("partyid", ConditionOperator.Equal ,userId),
                                },
                            },
                        },
                    },

                    };
                    EntityCollection Apointmentresponse3 = serviceConnector.RetrieveMultiple(qexp3);
                    customTrace.AppendLine("Apointmentresponse3 Count: " + Apointmentresponse3.Entities.Count);
                    #endregion Query Expression3

                    EntityCollection Appointment_overlap = new EntityCollection();

                    if (Apointmentresponse1 != null && Apointmentresponse1.Entities.Count > 0)
                    {
                        //messageString.AppendLine("Apointmentresponse1: " + Apointmentresponse1.Entities.Count);
                        foreach (var appointment in Apointmentresponse1.Entities)
                        {
                            bool alreadyadded = CheckalreadyList(Appointment_overlap, appointment);
                            if(alreadyadded == false)
                            Appointment_overlap.Entities.Add(appointment);
                        }

                    }
                    if (Apointmentresponse2 != null && Apointmentresponse2.Entities.Count > 0)
                    {
                        //messageString.AppendLine("Apointmentresponse2: " + Apointmentresponse2.Entities.Count);
                        foreach (var appointment in Apointmentresponse2.Entities)
                        {
                            bool alreadyadded = CheckalreadyList(Appointment_overlap, appointment);
                            if (alreadyadded == false)
                                Appointment_overlap.Entities.Add(appointment);
                         }

                    }
                    if (Apointmentresponse3 != null && Apointmentresponse3.Entities.Count > 0)
                    {
                        //messageString.AppendLine("Apointmentresponse3: " + Apointmentresponse3.Entities.Count);
                        foreach (var appointment in Apointmentresponse3.Entities)
                        {
                            bool alreadyadded = CheckalreadyList(Appointment_overlap, appointment);
                            if (alreadyadded == false)
                                Appointment_overlap.Entities.Add(appointment);
                         }

                    }

                    customTrace.AppendLine("Apointmentresponse Count: " + Appointment_overlap.Entities.Count);
                    //throw new Exception("TEST");
                    if (Appointment_overlap != null && Appointment_overlap.Entities.Count > 0)
                    {
                        customTrace.AppendLine("Apointmentresponse Count: " + Appointment_overlap.Entities.Count);
                        messageString.AppendLine("Alert!!");
                        messageString.AppendLine("You have " + Appointment_overlap.Entities.Count + " appointments;");
                        int counter = 1;
                        foreach (var appointment in Appointment_overlap.Entities)
                        {
                            string Date = string.Empty;
                            string StartTime = string.Empty;
                            string EndTime = string.Empty;
                            string attendee = string.Empty;

                            if (appointment.Attributes.Contains(AppointmentAttributeName.StartTimeAttributeName))
                                Date = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.StartTimeAttributeName).ToShortDateString();

                            if (appointment.Attributes.Contains(AppointmentAttributeName.StartTimeAttributeName))
                                StartTime = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.StartTimeAttributeName).ToLocalTime().ToShortTimeString();

                            if (appointment.Attributes.Contains(AppointmentAttributeName.EndTimeAttributeName))
                                EndTime = appointment.GetAttributeValue<DateTime>(AppointmentAttributeName.EndTimeAttributeName).ToLocalTime().ToShortTimeString();

                            string AppointmentType = appointment.FormattedValues[AppointmentAttributeName.AppointmentType].ToString();

                            messageString.AppendLine("(" + counter + ") "+"AppointmentType: " + AppointmentType);
                            messageString.AppendLine("Date: " + Date);
                            //messageString.AppendLine("Attendee: " + attendee);
                            messageString.AppendLine("StartTime: " + StartTime);
                            messageString.AppendLine("EndTime: " + EndTime);
                            messageString.AppendLine("******" );
                            counter++;
                        }
                        messageString.AppendLine("Please cancel the appointments first for " + aptType + " request!");
                        customTrace.AppendLine("ValidateOpenAppointment Ends");
                        throw new Exception();
                    }
                }
            }


            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("ValidateOpenAppointment", "SourceChannel", "Execute", customTrace.ToString(), " Execute trace log", "User ID", "UserBrowserInfo");
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "Execute", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", "ValidateOpenAppointment Class - Execute Method Exceptions", "browserinfo");

                //throw new Exception(messageString.ToString(),ex.InnerException);
               throw new InvalidPluginExecutionException(OperationStatus.Failed, messageString.ToString());
                //throw new Exception(ex + " crmTrace: " + customTrace.ToString());
            }
        }


        public static ConditionExpression CreateConditionExpression(string attributeName, ConditionOperator conditionOperator, object[] conditionValues)
        {
            ConditionExpression conditionExpression = new ConditionExpression();
            try
            {
                conditionExpression.AttributeName = attributeName;
                conditionExpression.Operator = conditionOperator;
                if (conditionValues != null && conditionValues.Length > 0)
                {
                    conditionExpression.Values.AddRange(conditionValues);
                }
            }
            catch (Exception ex)
            {
                // ExceptionLibrary.ExceptionMethods.ProcessException(ex); return null;
            }
            return conditionExpression;
        }

        public static bool CheckalreadyList(EntityCollection appointment_overlaplist, Entity entity)
        {
            bool isalreadyincluded = false;
            Guid appointmentId = entity.Id;
            foreach (Entity ent in appointment_overlaplist.Entities)
            {
                Guid guid = ent.Id;
                if (guid == appointmentId)
                    isalreadyincluded = true;

            }

            return isalreadyincluded;

        }



    }
}

