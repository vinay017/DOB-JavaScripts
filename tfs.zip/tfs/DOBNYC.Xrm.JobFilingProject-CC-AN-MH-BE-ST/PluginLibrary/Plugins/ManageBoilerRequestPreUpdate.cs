﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class ManageBoilerRequestPreUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");


                //if (context.Depth > 2)   Keep it commmented
                //    return;

                if (targetEntity == null)
                    return;
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];



                // WorkPermit Workflows
                if (targetEntity.LogicalName == ManageBoilerRequest.EntityLogicalName)
                {
                    string trackingnumber = string.Empty;


                    if (targetEntity.Contains(ManageBoilerRequest.RequestStatus) && targetEntity[ManageBoilerRequest.RequestStatus] != null && targetEntity[ManageBoilerRequest.RequestStatus] != preTargetEntity[ManageBoilerRequest.RequestStatus] && targetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.RequestStatus).Value == 2)
                    {
                        trackingnumber = FeeCalculationStandardizationHandler.BoilerNumber(serviceConnector, targetEntity, customTrace, targetEntity.Contains(ManageBoilerRequest.Borough) && targetEntity[ManageBoilerRequest.Borough] != null ? targetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.Borough).Value : preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.Borough).Value, targetEntity.Contains(ManageBoilerRequest.OccupancyType) && targetEntity[ManageBoilerRequest.OccupancyType] != null ? targetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.OccupancyType).Value : preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.OccupancyType).Value);
                        if (trackingnumber != null && trackingnumber != string.Empty)
                        {
                            targetEntity.SetAttributeValue(ManageBoilerRequest.BoilerDeviceNumber, trackingnumber);
                        }

                    }





                    if (targetEntity.Contains(ManageBoilerRequest.RequestStatus) && targetEntity[ManageBoilerRequest.RequestStatus] != null && targetEntity[ManageBoilerRequest.RequestStatus] != preTargetEntity[ManageBoilerRequest.RequestStatus] && targetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.RequestStatus).Value == 3)
                    {
                        //Update Master Boiler existing boiler type and  existing source
                        Entity master = new Entity(BoilerMasterDevice.EntityLogicalName);
                        master.SetAttributeValue(BoilerMasterDevice.BoilerType, new OptionSetValue(preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.existingBoilerType).Value));
                        master.SetAttributeValue(BoilerMasterDevice.BoilerEnergySource, new OptionSetValue(preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.existingEnergySource).Value));
                        master.SetAttributeValue(BoilerMasterDevice.occupancyType, new OptionSetValue(preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.OccupancyType).Value));
                        master.SetAttributeValue(BoilerMasterDevice.BoilerRating, new OptionSetValue(preTargetEntity.GetAttributeValue<OptionSetValue>(ManageBoilerRequest.BoilerRating).Value));
                        master.Id = targetEntity.Contains(ManageBoilerRequest.BoilerLookup) && targetEntity[ManageBoilerRequest.BoilerLookup] != null ? targetEntity.GetAttributeValue<EntityReference>(ManageBoilerRequest.BoilerLookup).Id : preTargetEntity.GetAttributeValue<EntityReference>(ManageBoilerRequest.BoilerLookup).Id;
                        serviceConnector.Update(master);

                    }



                }



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ManageBoilerRequestPreUpdate - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
