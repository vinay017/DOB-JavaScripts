﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    public class JobFilingTaskUpdatePlugin : IPlugin
    {
        /// <summary>
        /// Plugin Task 
        /// </summary>


        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                
                //if (context.Depth > 1)
                //    return;

                //customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity == null || targetEntity.LogicalName != TaskEntityAttributeNames.EntityLogicalName)
                    return;

                //Entity postTargetEntity = (Entity)context.PostEntityImages[PluginHelperStrings.PostImageName];
                Entity postTargetEntity = PluginHandlerBase.Retrieve(serviceConnector, new string[] { TaskEntityAttributeNames.RegardingObjectId, TaskEntityAttributeNames.CurrentFilingStatus, TaskEntityAttributeNames.ReviewAction, TaskEntityAttributeNames.StatusFieldName, TaskEntityAttributeNames.IsJobApplicationApproved, TaskEntityAttributeNames.SupersedingRequestStatus, TaskEntityAttributeNames.WithdrawStatus, TaskEntityAttributeNames.ClickheretogotoJobFiling, TaskEntityAttributeNames.IsWorkPermitAvailable, TaskEntityAttributeNames.QADecision, TaskEntityAttributeNames.SPEActions, TaskEntityAttributeNames.IsSecondaryPETaskForm, TaskEntityAttributeNames.IsMultiStakesForm, TaskEntityAttributeNames.IsL2RequestTask, TaskEntityAttributeNames.GoToL2Request, TaskEntityAttributeNames.L2PEActions }, targetEntity.Id, TaskEntityAttributeNames.EntityLogicalName);

                //CommonPluginLibrary.Merge(targetEntity, postTargetEntity);
                        
                customTrace.AppendLine("prepostTargetEntity Guid: " + postTargetEntity.Id);

                
                EntityReference regardingObject = (EntityReference)(postTargetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId]);

                #region Tasks Created for L2 Request
                if (regardingObject != null && regardingObject.LogicalName == L2RequestAttributeNames.EntityLogicalName)
                {

                    if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.IsL2RequestTask) && postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.L2PEActions))
                    {
                        bool isL2TaskForm = postTargetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsL2RequestTask);
                        customTrace.AppendLine("isL2TaskForm: " + isL2TaskForm);

                        int l2PEAction = postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.L2PEActions).Value;
                        customTrace.AppendLine("l2PEAction: " + l2PEAction);

                        int currentFilingStatus = ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value;
                        customTrace.AppendLine("CurrentFilingStatus: " + currentFilingStatus);

                        if (isL2TaskForm && l2PEAction == (int)L2PEActions.Approved)
                        {
                            customTrace.AppendLine("Start working on Job Filing: Start");
                            JobFilingTaskHandler.UpdateJobFilingStatusOnL2Actions(serviceConnector, postTargetEntity, customTrace);
                            customTrace.AppendLine("End working on Job Filing: End");

                        }

                    }
                    return;
                }
                #endregion


                /// If task is regarding Job Filing
                if (regardingObject != null || regardingObject.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Regarding Entity is Job Filing: " + postTargetEntity.LogicalName);
                   
                    ////////Update Objections in the job filing entity once CPE approved the objections and task
                    if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.StatusFieldName]).Value == TaskEntitySatus.Completed)
                    {
                        int currentFilingStatus = ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.CurrentFilingStatus]).Value;
                        customTrace.AppendLine("CurrentFilingStatus: " + currentFilingStatus);
                                              
                        if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.ReviewAction) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.ReviewAction]).Value != (int)ReviewActions.ApproveApplication)
                        {
                            customTrace.AppendLine("Chief Plan Examiner Objection");
                            customTrace.AppendLine("Start Generating Objections: " + PluginHelperStrings.UpdateMessageName);
                            JobFilingTaskHandler.AssociateObjectionsOnJobFiling(serviceConnector, postTargetEntity, customTrace, currentFilingStatus);
                            customTrace.AppendLine("EndGenerating Objections : " + PluginHelperStrings.UpdateMessageName);
                        }

                        if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.IsJobApplicationApproved) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.IsJobApplicationApproved]).Value == (int)IsJobApplicationApproved.Reject)
                        {
                            customTrace.AppendLine("Plan Examiner Objections");
                            customTrace.AppendLine("Start Generating Objections: " + PluginHelperStrings.UpdateMessageName);
                            JobFilingTaskHandler.AssociateObjectionsOnJobFiling(serviceConnector, postTargetEntity, customTrace, currentFilingStatus);
                            customTrace.AppendLine("EndGenerating Objections : " + PluginHelperStrings.UpdateMessageName);
                        }

                        //Multiple Stakeholders - SPE Task Completion: Start
                        if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.SPEActions) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.SPEActions]).Value == (int)IsJobApplicationApproved.ReviewComplete)
                        {
                            customTrace.AppendLine("Second Plan Examiner Objections.");
                            customTrace.AppendLine("Start Generating SPE Objections: " + PluginHelperStrings.UpdateMessageName);
                            JobFilingTaskHandler.AssociateObjectionsOnJobFiling(serviceConnector, postTargetEntity, customTrace, currentFilingStatus);
                            customTrace.AppendLine("EndGenerating SPE Objections : " + PluginHelperStrings.UpdateMessageName);
                        }
                        //Multiple Stakeholders - SPE Task Completion: End

                        customTrace.AppendLine("Start Generating Documents: " + PluginHelperStrings.UpdateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnJobFiling(serviceConnector, postTargetEntity, customTrace, currentFilingStatus);
                        customTrace.AppendLine("End Generating Documents: " + PluginHelperStrings.UpdateMessageName);

                        if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.IsWorkPermitAvailable) && postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.QADecision))
                        {
                            bool permitAvailable = postTargetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsWorkPermitAvailable);
                            customTrace.AppendLine("permitAvailable: " + permitAvailable);
                            int qADecision = postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.QADecision).Value;
                            customTrace.AppendLine("qADecision: " + qADecision);
                            if(permitAvailable == true && (currentFilingStatus == (int)CurrentFilingStatus.ProfCertQAinReview || currentFilingStatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview))
                            {
                                customTrace.AppendLine("Start working on Permits: " + PluginHelperStrings.UpdateMessageName);
                                JobFilingTaskHandler.UpdateWorkPermits_ProfDecision(serviceConnector, postTargetEntity, customTrace, qADecision);
                                customTrace.AppendLine("End working on Permits : " + PluginHelperStrings.UpdateMessageName);

                            }
                            
                        }

                    }
                  
                    ////////Update Objections in the job filing entity once PE approved the objections and task
                   /* if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.CurrentFilingStatus) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.StatusFieldName]).Value == TaskEntitySatus.Completed)
                    {
                        if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.IsJobApplicationApproved) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.IsJobApplicationApproved]).Value == (int)IsJobApplicationApproved.Reject)
                        {
                       
                            customTrace.AppendLine("Start Generating Objections: " + PluginHelperStrings.UpdateMessageName);
                            JobFilingTaskHandler.AssociateObjectionsOnJobFiling(serviceConnector, postTargetEntity, customTrace);
                            customTrace.AppendLine("EndGenerating Objections : " + PluginHelperStrings.UpdateMessageName);
                        }

                    } */
                }

                /// If task is regarding Withdrawal Request
                if (regardingObject != null || regardingObject.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Task is regarding Withdrawal Request ");
                    if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.WithdrawStatus) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.StatusFieldName]).Value == TaskEntitySatus.Completed)
                    {
                        int WithdrawalStatus = ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.WithdrawStatus]).Value;
                        customTrace.AppendLine("WithdrawalStatus: " + WithdrawalStatus);
                        customTrace.AppendLine("Start Generating Documents: " + PluginHelperStrings.UpdateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnJobFiling_Withdrawal(serviceConnector, postTargetEntity, customTrace, WithdrawalStatus);
                        customTrace.AppendLine("End Generating Documents: " + PluginHelperStrings.UpdateMessageName);

                    }

                }

                /// If task is regarding Superseding Request
                if (regardingObject != null || regardingObject.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Task is regarding Superseding Request ");
                    if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.SupersedingRequestStatus) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.StatusFieldName]).Value == TaskEntitySatus.Completed)
                    {
                        
                        int SupersedingStatus = ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.SupersedingRequestStatus]).Value;
                        customTrace.AppendLine("Start Generating Documents: " + PluginHelperStrings.UpdateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnJobFiling_Superseding(serviceConnector, postTargetEntity, customTrace, SupersedingStatus);
                        customTrace.AppendLine("End Generating Documents: " + PluginHelperStrings.UpdateMessageName);

                    }

                }

                /// If task is regarding Workpermit Request
                if (regardingObject != null || regardingObject.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                {
                    customTrace.AppendLine("Task is regarding Workpermit Request ");
                    if (postTargetEntity.Attributes.Contains(TaskEntityAttributeNames.WorkPermitStatus) && ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.StatusFieldName]).Value == TaskEntitySatus.Completed)
                    {

                        int WorkpermitStatus = ((OptionSetValue)postTargetEntity.Attributes[TaskEntityAttributeNames.WorkPermitStatus]).Value;
                        customTrace.AppendLine("Start Generating Documents: " + PluginHelperStrings.UpdateMessageName);
                        JobFilingTaskHandler.AssociateDocumentsOnJobFiling_WorkPermit(serviceConnector, postTargetEntity, customTrace, WorkpermitStatus);
                        customTrace.AppendLine("End Generating Documents: " + PluginHelperStrings.UpdateMessageName);

                    }

                }

                //throw new Exception("test");
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskUpdatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }



    }
}
