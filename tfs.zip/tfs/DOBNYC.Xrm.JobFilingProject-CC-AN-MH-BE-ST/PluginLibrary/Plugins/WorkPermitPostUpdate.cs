﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WorkPermitPostUpdate : IPlugin
    {
        /// <summary>
        /// This Plugin is used for following
        /// 1)To Trigger Workflow for Work Permit
        /// 2)To check Inspections Complete or not
        /// 3)Boiler Work type Inspection Results- Pass Final- Make Boiler device status active.
        ///
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity == null)
                    return;

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != WorkPermitEntityAttributeName.EntityLogicalName)
                    return;

                Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];

                if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.WorkPermitStatus))
                {
                    int workPermitStatus = ((OptionSetValue)targetEntity.Attributes[WorkPermitEntityAttributeName.WorkPermitStatus]).Value;
                    int previousworkPermitstatus = ((OptionSetValue)preTargetEntity.Attributes[WorkPermitEntityAttributeName.WorkPermitStatus]).Value;
                    customTrace.AppendLine("workPermit Request Status:" + workPermitStatus);
                    // stop plugin when not required based on workPermitStatus Request Status
                    if (workPermitStatus == (int)WorkpermitStatus.PendingQAAssignment || workPermitStatus == (int)WorkpermitStatus.QAReview || workPermitStatus == (int)WorkpermitStatus.PendingProfCertQAAssignment
                        //|| workPermitStatus == (int)WorkpermitStatus.QAFailed
                        )
                    {
                        customTrace.AppendLine("WorkPermit Request is not completed!!");
                        return;
                    }
                    if (workPermitStatus != previousworkPermitstatus)
                    {
                        customTrace.AppendLine("WorkPermitPostUpdate Started: for" + targetEntity.LogicalName);
                        WorkPermitNumberHandler.WorkPermitIssued(serviceConnector, targetEntity, preTargetEntity, customTrace, workPermitStatus);
                        customTrace.AppendLine("WorkPermitPostUpdate Ended: for" + targetEntity.LogicalName);
                    }
                }

                if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.InspectionCompleted))
                {
                    bool InspComp_Current = targetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.InspectionCompleted);
                    customTrace.AppendLine("InspComp_Current:" + InspComp_Current);
                    bool InspComp_Previous = preTargetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.InspectionCompleted);
                    customTrace.AppendLine("InspComp_Previous:" + InspComp_Previous);
                    if (InspComp_Current != InspComp_Previous && InspComp_Current == true)
                    {
                        customTrace.AppendLine("InspectionCompleted Started: for" + targetEntity.LogicalName);
                        WorkPermitNumberHandler.WorkPermit_InspectionComplete(serviceConnector, targetEntity, preTargetEntity, customTrace);
                        customTrace.AppendLine("InspectionCompleted Ended: for" + targetEntity.LogicalName);

                    }

                }

                #region License Type Changes
                if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.LicenseeType))
                {
                    Guid LicenseType_Current = targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.LicenseeType).Id;
                    customTrace.AppendLine("LicenseType_Current: " + LicenseType_Current);
                    Guid LicenseType_Previous = preTargetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.LicenseeType).Id;
                    customTrace.AppendLine("LicenseType_Previous:" + LicenseType_Previous);
                    if (LicenseType_Current != LicenseType_Previous)
                    {
                        customTrace.AppendLine("Delete Permit Required Item Started: for" + targetEntity.LogicalName);
                        //SealSignaturesHandler.DeleteDocuments_RelatedtoPermit(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("Delete Permit Required Item Ended: for" + targetEntity.LogicalName);
                        SealSignaturesHandler.WorkPermitDocuments(serviceConnector, targetEntity, preTargetEntity, context, customTrace);

                    }

                }

                #endregion

                #region AN License Type Changes
                if (targetEntity.Contains(WorkPermitEntityAttributeName.AntennaLicenseType))
                {
                    Guid LicenseType_Current = targetEntity.Attributes[WorkPermitEntityAttributeName.AntennaLicenseType] != null ? targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.AntennaLicenseType).Id : Guid.Empty;
                    customTrace.AppendLine("LicenseType_Current: " + LicenseType_Current);
                    Guid LicenseType_Previous = preTargetEntity.Contains(WorkPermitEntityAttributeName.AntennaLicenseType) ? preTargetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.AntennaLicenseType).Id : Guid.Empty;
                    customTrace.AppendLine("LicenseType_Previous:" + LicenseType_Previous);

                    if (LicenseType_Current != LicenseType_Previous)
                    {
                        SealSignaturesHandler.WorkPermitDocuments_AN(serviceConnector, targetEntity, preTargetEntity, context, customTrace);
                    }

                }

                // #region GC PGL1
                //if(targetEntity.Contains(WorkPermitEntityAttributeName.TypeofPermit))
                //{
                //    int typeofPermit = targetEntity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                //    customTrace.AppendLine("typeofPermit:" + typeofPermit);
                //    if(typeofPermit == (int)TypeofPermit.GeneralConstruction || typeofPermit == (int)TypeofPermit.GCMH || typeofPermit == (int)TypeofPermit.GCST || typeofPermit == (int)TypeofPermit.GCMHST)
                //    {
                //        SealSignaturesHandler.WorkPermitDocuments_PGL1(serviceConnector, targetEntity, preTargetEntity, context, customTrace);
                //    }
                //}
                #endregion

                #region Boiler Work Type Inspection Results

                if (targetEntity.Contains(WorkPermitEntityAttributeName.InspectionStatus) && targetEntity[WorkPermitEntityAttributeName.InspectionStatus] != null && targetEntity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.InspectionStatus).Value==1) //for passfianl only
                {
                    
                    customTrace.AppendLine("Get the Job filing Details");
                    
                    Entity jobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, preTargetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.GotoJobFiling).Id,new ColumnSet(new string[] { JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.BEScopeIncludesBL, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.FilingStatus }));
                   
                    if (jobFiling != null && jobFiling.Id != null)
                    {
                        customTrace.AppendLine("Check if jobfiling is boiler work type");
                        if (jobFiling.Id != null && !(jobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && jobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && jobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true))//work for only new jobfilings only
                   
                        {
                            #region Get the worktypes in Jobfiling and assign in feeobject
                            customTrace.AppendLine("set all the work type flags in fee object-start");
                            FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(jobFiling, feeObject, customTrace);
                            customTrace.AppendLine("set all the work type flags in fee object-end");
                            #endregion
                        }
                        else
                        {
                            customTrace.AppendLine("No Job Filing Found So Return");
                            return;
                        }


                        if(feeObject.IsBE)
                        {
                            customTrace.AppendLine("Boilers Worktype-Boiler Work Type Inspection Results ");                            
                            FeeCalculationStandardizationHandler.BoilerPassFinalResult(serviceConnector, jobFiling, customTrace);
                          
                        }

                    }

                }

                #endregion

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPostUpdate - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


    }
}
