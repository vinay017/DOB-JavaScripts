﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class STSignOffInitiatePlugin : PluginHandlerBase, IPlugin
    {
        /// <summary>
        /// This plugin should be registerd on following entities on post update
        /// a)ProgressInspection
        /// b)Special inspection
        /// c)Tr2Technicalreport
        /// d)JobFiling on Job Status
        /// Preimage should be registed fro all the steps
        /// </summary>
        /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables Declaration
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            string PaymentHistoryGUID = string.Empty;
            #endregion
            try
            {
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || !(targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName || targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName || targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName))
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                Entity preTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];



                if (context.Depth > 2)
                    return;
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;



                #endregion

                ///1)Get the  required Job filing details (filing status,Work type) from the child entities
                ///2)Get required Details of all related entites a)All TR1 Details (is certified,certification of full completion) b) All Tr2 results (is ready to sign off , is concrete inspections done)
                ///
                ///4) after receiveing all the required info then do the validation condition is a) all tr1 are tobe certified  b) all tr2 should be ready to sign off true c)jobfiling should be permit entire d) job status should be in LOC issues

                Entity jobFiling = new Entity();
                Guid jobId = new Guid();
                #region Get JobFiling Guid
                customTrace.AppendLine("Job filing Guid-start");
                if (targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                {
                    jobId = preTargetEntity.GetAttributeValue<EntityReference>(ProgressInspectionCategoryAttributeNames.GoToJobFiling).Id;

                }
                else if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                {
                    jobId = preTargetEntity.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.GoToJobFiling).Id;

                }
                else if (targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName)
                {
                    jobId = preTargetEntity.GetAttributeValue<EntityReference>(TR2TechnicalReport.GotoJobFiling).Id;

                }
                else if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    jobId = targetEntity.Id;
                }
                customTrace.AppendLine("Job filing Guid-End");

                if (jobId != new Guid() && jobId != null)
                {
                    customTrace.AppendLine("1)Get the  required Job filing details (filing status,Work type) from the child entities");
                    jobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, jobId, new ColumnSet(new string[] { JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.FilingStatus }));
                }
                else
                {
                    customTrace.AppendLine("No Job filing Guid Found so return");

                    return;
                }
                #endregion


                #region Get JobFiling Entity Details

                if (jobFiling.Id != null && !(jobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && jobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && jobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)//work for only new jobfilings only
                    )
                {
                    #region Get the worktypes in Jobfiling and assign in feeobject
                    customTrace.AppendLine("set all the work type flags in fee object-start");
                    FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(jobFiling, feeObject, customTrace);
                    customTrace.AppendLine("set all the work type flags in fee object-end");
                    #endregion
                }
                else
                {
                    customTrace.AppendLine("No Job Filing Found So Return");
                    return;
                }

                #endregion

                #region Check ST Sign Off Conditions

                if ((feeObject.IsST || feeObject.IsMS) && jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntire)// work for only ST and MS
                {
                    customTrace.AppendLine("4) after receiveing all the required info then do the validation condition is a) all tr1 are tobe certified  b) all tr2 should be ready to sign off true c)jobfiling should be permit entire ");
                    bool isProgressInspectionsCertified = FeeCalculationStandardizationHandler.IsProgressInspectionsCertified(serviceConnector, jobFiling, customTrace, feeObject);
                    customTrace.AppendLine("Final results for isProgressInspectionsCertified " + isProgressInspectionsCertified);
                    bool isProgressEnergyInspectionsCertified = FeeCalculationStandardizationHandler.IsProgressEnergyCodeInspectionsCertified(serviceConnector, jobFiling, customTrace, feeObject);
                    customTrace.AppendLine("Final results for isProgressInspectionsCertified " + isProgressEnergyInspectionsCertified);


                    bool IsSpecialInspectionsCertified = FeeCalculationStandardizationHandler.IsSpecialInspectionsCertified(serviceConnector, jobFiling, customTrace, feeObject);
                    customTrace.AppendLine("Final results for IsSpecialInspectionsCertified " + IsSpecialInspectionsCertified);
                    bool IsTR2InspectionsReadyforSignoff = FeeCalculationStandardizationHandler.IsTR2InspectionsReadyforSignoff(serviceConnector, jobFiling, customTrace, feeObject);
                    customTrace.AppendLine("Final results for IsTR2InspectionsReadyforSignoff " + IsTR2InspectionsReadyforSignoff);

                    if (isProgressInspectionsCertified && IsSpecialInspectionsCertified && IsTR2InspectionsReadyforSignoff && isProgressEnergyInspectionsCertified)
                    {
                        customTrace.AppendLine("All ST Sign off conditions Met so change the Permit  status to SIgnoff");
                        Entity updateJob = new Entity(WorkPermitEntityAttributeName.EntityLogicalName);


                        customTrace.AppendLine("Get the  all permit entire Work Permits from Jobfiling and make signed off ");

                        ConditionExpression transactionCodeCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFiling.Id.ToString() });
                        ConditionExpression transactionCodeCondition2 = new ConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, (int)WorkpermitStatus.PermitIssued);
                        EntityCollection WorkPermits = RetrieveMultiple(serviceConnector, WorkPermitEntityAttributeName.EntityLogicalName, new string[] {

                          WorkPermitEntityAttributeName.GotoJobFiling},
                            new ConditionExpression[] { transactionCodeCondition, transactionCodeCondition2 }, LogicalOperator.And);

                        if (WorkPermits != null && WorkPermits.Entities.Count > 0)
                        {
                            foreach (Entity Workpermit in WorkPermits.Entities)
                            {
                                updateJob.SetAttributeValue(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitSignedoff));
                                updateJob.Id = Workpermit.Id;
                                serviceConnector.Update(updateJob);
                            }
                        }

                        #region Update Jobfiling COC Signed off date to today
                        if (feeObject.IsMS && FeeCalculationStandardizationHandler.IsCoCNeeded(serviceConnector, jobFiling, customTrace, feeObject))
                        {
                            //get all the scope of works of MS . if any scope of work has loc needed flag yes then set the coc issued date

                            customTrace.AppendLine("Update COC Date on job filing");
                            updateJob = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                            updateJob.SetAttributeValue(JobFilingEntityAttributeName.COCSignedOffDate, DateTime.Now);
                            updateJob.Id = jobFiling.Id;
                            serviceConnector.Update(updateJob);
                        }

                        #endregion


                        customTrace.AppendLine("Job filing Status Updated to Signoff complete");
                    }

                }
                #endregion
                #region Send email When no exceptions found

                if (feeObject.IsST && targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName)
                {
                    if(targetEntity.Attributes.Contains(TR2TechnicalReport.DesignApplicantStatementforNoExceptions) && targetEntity.GetAttributeValue<bool>(TR2TechnicalReport.DesignApplicantStatementforNoExceptions) == true)
                    {
                        Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "Structural - Emails on No Exceptions Found on TR3 Director").Id.ToString());
                        customTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(serviceConnector, processId, jobId);

                    }
                }
                #endregion
                #region On submission change the status
                if (feeObject.IsST && targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName)
                {
                    if (targetEntity.Attributes.Contains(TR2TechnicalReport.IsBCDBCTaskSubmitted) && targetEntity.GetAttributeValue<bool>(TR2TechnicalReport.IsBCDBCTaskSubmitted) == true && preTargetEntity.GetAttributeValue<bool>(TR2TechnicalReport.IsBCDBCTaskSubmitted) == false)
                    {

                        Entity updateJob = new Entity(JobAutoNumberEntityAttribute.EntityLogicalName);

                        customTrace.AppendLine("Update Filing status on job filing");
                        updateJob = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                        updateJob.SetAttributeValue(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntireBCDBCReview));
                        updateJob.Id = jobFiling.Id;
                        serviceConnector.Update(updateJob);
                        //throw new Exception("jobupdated");

                    }
                }
                #endregion
                #region when ready for signoff change the status
                if (feeObject.IsST && targetEntity.LogicalName == TR2TechnicalReport.EntityLogicalName)
                {
                    if (targetEntity.Attributes.Contains(TR2TechnicalReport.isJobReadyForSignOff) && targetEntity.GetAttributeValue<bool>(TR2TechnicalReport.isJobReadyForSignOff) == true && preTargetEntity.GetAttributeValue<bool>(TR2TechnicalReport.isJobReadyForSignOff) == false)
                    {
                        Entity updateJob = new Entity(JobAutoNumberEntityAttribute.EntityLogicalName);

                        customTrace.AppendLine("Update Filing status on job filing");
                        updateJob = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                        updateJob.SetAttributeValue(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntire));
                        updateJob.Id = jobFiling.Id;
                        serviceConnector.Update(updateJob);

                    }
                }
                #endregion
                #region Check AN|FN|SH|SF|SG TR Final Certification - Update Work Permits to Sign off and capture COC date on JF - WORKS for Both Historic and New
                
                if ((feeObject.IsAN || feeObject.IsFN || feeObject.IsSH || feeObject.IsSF || feeObject.IsSG)
                    && jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntire
                    && targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                {
                    customTrace.AppendLine("4) after receiveing all the required info then do the validation condition is a) all tr1 are tobe certified  ");
                    bool isFinalTRCertifiedNow = false;

                    if (preTargetEntity.Contains(ProgressInspectionCategoryAttributeNames.AddRequirement))
                    {
                        string addRequirement = preTargetEntity.GetAttributeValue<EntityReference>(ProgressInspectionCategoryAttributeNames.AddRequirement).Name;
                        if (addRequirement == TRInspectionType.Final)
                        {
                            if (targetEntity.Contains(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests))
                            {
                                bool current = targetEntity.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests);
                                bool previous = preTargetEntity.Contains(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests) ? preTargetEntity.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests) : false;
                                if (current != previous && current)
                                {
                                    isFinalTRCertifiedNow = true;
                                }
                            }
                            if (targetEntity.Contains(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement))
                            {
                                bool current = targetEntity.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement);
                                bool previous = preTargetEntity.Contains(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement) ? preTargetEntity.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement) : false;
                                if (current != previous && current)
                                {
                                    isFinalTRCertifiedNow = true;
                                }
                            }
                        }
                    }

                    #region isFinalTRCertifiedNow
                    if (isFinalTRCertifiedNow)
                    {
                        #region Check if All TR progress inspections including FINAL is Certified Full Completion
                        bool isProgressInspectionsCertified = FeeCalculationStandardizationHandler.IsProgressInspectionsCertified(serviceConnector, jobFiling, customTrace, feeObject);
                        customTrace.AppendLine("Final results for isProgressInspectionsCertified " + isProgressInspectionsCertified);
                        #endregion

                        #region If All ProgressInspectionsCertified - Sign off the Permits and Capture COC date (for portal use)
                        if (isProgressInspectionsCertified)
                        {
                            customTrace.AppendLine("All  Sign off conditions Met so change the Permit  status to SIgnoff");
                            Entity permit = new Entity(WorkPermitEntityAttributeName.EntityLogicalName);


                            customTrace.AppendLine("Get the  all permit entire Work Permits from Jobfiling and make signed off ");

                            ConditionExpression transactionCodeCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFiling.Id.ToString() });
                            ConditionExpression transactionCodeCondition2 = new ConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, (int)WorkpermitStatus.PermitIssued);
                            EntityCollection WorkPermits = RetrieveMultiple(serviceConnector, WorkPermitEntityAttributeName.EntityLogicalName, new string[] {

                          WorkPermitEntityAttributeName.GotoJobFiling},
                                new ConditionExpression[] { transactionCodeCondition, transactionCodeCondition2 }, LogicalOperator.And);

                            if (WorkPermits != null && WorkPermits.Entities.Count > 0)
                            {
                                foreach (Entity Workpermit in WorkPermits.Entities)
                                {
                                    permit.SetAttributeValue(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitSignedoff));
                                    permit.Id = Workpermit.Id;
                                    serviceConnector.Update(permit);
                                }
                            }

                            #region Update Jobfiling COC Signed off date to today
                            customTrace.AppendLine("Update COC Date on job filing");
                            Entity updateJob = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                            updateJob.SetAttributeValue(JobFilingEntityAttributeName.COCSignedOffDate, DateTime.Now);
                            updateJob.Id = jobFiling.Id;
                            serviceConnector.Update(updateJob);
                            #endregion


                            customTrace.AppendLine("Job filing Status Updated to Signoff complete");
                        }
                        #endregion
                    }
                    #endregion

                }
                #endregion
                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Test ing    ------STSignOffInitiatePlugin - Execute", null, customTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "STSignOffInitiatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
