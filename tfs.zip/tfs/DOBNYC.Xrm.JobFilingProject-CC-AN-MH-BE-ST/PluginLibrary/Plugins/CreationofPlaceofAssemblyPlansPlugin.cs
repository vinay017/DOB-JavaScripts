﻿using System;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersPATPARelatedEntities;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class CreationofPlaceofAssemblyPlansPlugin : IPlugin
    {

        ///
        /// Register the Plugin on Place of Assembly Space Information
        ///     * (a) Post-Create Stage - Synchronous - Server - SVC CRMPROXYADMDEV - Exe order (1) - dobnyc_placeofassemblyspaceinformation (primary) - This step is used for Creation of Place of Assembly Space Information, Place of Assembly Plans record is created.
        ///     
        /// Register the Plugin on Place of Assembly Space Information
        ///     * (a) Pre-Create Stage - Synchronous - Server - calling user - Exe order (1) - dobnyc_placeofassemblyspaceinformation (primary) - This step is used for setting up name of Place of Assembly Space Information
        ///        
        /// Register the Plugin on Place of Assembly Space Information
        ///     * (a) Pre-Update Stage - Synchronous - Server - calling user - Exe order (1) - dobnyc_placeofassemblyspaceinformation (primary) - This step is used to Handle the submission of Place of Assembly Space Information applicationa nd setting the status on PACO
        ///           filtered attributes: issubmit
        ///          
        /// Date: 04/11/2018
        /// Written By: Rupal
        /// </summary>
        public void Execute(IServiceProvider serviceProvider)
        {
            //Extract the tracing service for use in debug the plug-in
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            Guid PAGuid = new Guid();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: preImage.");
                if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName))
                    preTargetEntity = context.PreEntityImages[PluginHelperStrings.PreImageName];
                //Check the depth avoid infinite loops
                if (context.Depth > 2)
                    return;

                // Verify that the target entity represents is Place of Assembly Space information or Place of assembly Plans.
                if (targetEntity.LogicalName != PlaceofAssemblySpaceInformation.EntityLogicalName && targetEntity.LogicalName != PlaceofAssemblyPlans.EntityLogicalName)
                    return;

                customTrace.AppendLine("context.MessageName: " + context.MessageName);
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                // Verify that the target entity represents is Place of Assembly Space information 
                if (targetEntity.LogicalName == PlaceofAssemblySpaceInformation.EntityLogicalName)
                {
                    #region Create Message 
                    if (context.MessageName == PluginHelperStrings.CreateMessageName)
                    {
                        #region Pre-Operation-set the name of PlaceofAssemblySpaceInformation
                        if (context.Stage == 20)
                        {
                            customTrace.AppendLine("Setting name for PlaceofAssemblySpaceInformation record- start:");
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.Name, "Certificate Not Issued yet");
                            customTrace.AppendLine("Setting name for PlaceofAssemblySpaceInformation record- end:");
                        }
                        #endregion

                    }
                    #endregion


                    #region Post-op-Update the PAPlans record
                    if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                    {
                        if (context.Stage == 20 && !( context.Depth > 1) )
                        {
                            customTrace.AppendLine("Start Creating the Place of Assembly plan record : " + PluginHelperStrings.UpdateMessageName);
                            if (targetEntity.Contains(PlaceofAssemblySpaceInformation.jobFilingID) && !(preTargetEntity.Contains(PlaceofAssemblySpaceInformation.jobFilingID)))
                            {
                                EntityReference filingObj = targetEntity.GetAttributeValue<EntityReference>(PlaceofAssemblySpaceInformation.jobFilingID);
                                Entity jobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, filingObj.Id, new ColumnSet(new string[] { JobFilingEntityAttributeName.FilingTypeAttributeName, JobFilingEntityAttributeName.FilingStatus }));
                                
                                int filingType = ((OptionSetValue)jobFiling.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                                
                                if (filingType != (int)FilingType.PAA)
                                {
                                    Entity record = new Entity(PlaceofAssemblyPlans.EntityLogicalName);//initialize the Place of Assembly Plans Entity
                                    #region Creation of record logic
                                    record.SetAttributeValue(PlaceofAssemblyPlans.Name, "Primary Plan");
                                    record.SetAttributeValue(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup, targetEntity.ToEntityReference());
                                    serviceConnector.Create(record);
                                    customTrace.AppendLine("End of Creating the Place of Assembly plan record: " + PluginHelperStrings.UpdateMessageName);
                                    #endregion

                                    #region Set the Counter in Place of Assembly space information record logic
                                    customTrace.AppendLine("Start Setting the Counter to 1 in Place of assembly space information record : " + PluginHelperStrings.UpdateMessageName);
                                    targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.alternativePlanCounter, 1);
                                    serviceConnector.Update(targetEntity);
                                    customTrace.AppendLine("End Setting the Counter to 1 in Place of assembly space information record : " + PluginHelperStrings.UpdateMessageName);
                                    #endregion
                                }
                            }
                        }

                    }
                    #endregion


                    #region Update Message
                    if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                    {
                        #region preimage check
                        customTrace.AppendLine("Begin Get Pre-Image..");
                        Entity preImage = context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) ? (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName] : null;

                        if (preImage == null)
                        {
                            customTrace.AppendLine("-- ERROR:::  Pre-Image NOT found..");
                            return;
                        }
                        #endregion

                        #region Pre-op-Submit logic
                        if (context.Stage == 20)
                        {
                            #region Is Submit Logic
                            if (targetEntity.Attributes.Contains(PlaceofAssemblySpaceInformation.isSubmit))
                            {

                                bool isSubmitted = targetEntity.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.isSubmit);
                                bool previsSubmitted = preImage.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.isSubmit);
                                if (isSubmitted && (isSubmitted != previsSubmitted))
                                {
                                    customTrace.AppendLine(" PASpaceInfoSubmit start:");
                                    SubmitHandler.PASpaceInfoSubmit(serviceConnector, targetEntity, preImage, customTrace);
                                    customTrace.AppendLine(" PASpaceInfoSubmit end:");
                                }
                            }
                            #endregion

                            #region PACO Permitted
                            if (targetEntity.Attributes.Contains(PlaceofAssemblySpaceInformation.PACOreportStatus))
                            {

                                int currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value;
                                int previousReportStatus = preImage.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value;
                                if (currentReportStatus != previousReportStatus && currentReportStatus == (int)PACOReportStatus.PACOIssued)
                                {
                                    customTrace.AppendLine("Setting issued name for PlaceofAssemblySpaceInformation record- start:");
                                    string jobfilingNumber = preImage.GetAttributeValue<EntityReference>(PlaceofAssemblySpaceInformation.jobFilingID).Name;
                                    targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.Name, jobfilingNumber + "-PA");
                                    customTrace.AppendLine("Setting issued name for PlaceofAssemblySpaceInformation record- End:");
                                }
                                if (!(context.Depth > 2))
                                {
                                    customTrace.AppendLine("Start Executing PACO – Master Workflow");
                                    WorkFlowHandler.PACORequestWorkFlow(serviceConnector, targetEntity, customTrace, preImage);
                                    customTrace.AppendLine("End Executing PACO – Master Workflow");
                                }
                            }

                            #endregion
                        }
                        #endregion

                    }
                    #endregion
                }

                // Verify that the target entity represents is Place of assembly Plans.
                if (targetEntity.LogicalName == PlaceofAssemblyPlans.EntityLogicalName)
                {
                    if (context.MessageName == PluginHelperStrings.CreateMessageName)

                    {
                        #region Setting the Alternative Plan Counter
                        customTrace.AppendLine("Start--CreateAlternateRecordForPA Handler method End");
                        if (targetEntity.Attributes.Contains(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup) && !targetEntity.Contains(PlaceofAssemblyPlans.Name))
                        {
                            PAGuid = ((EntityReference)targetEntity.Attributes[PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup]).Id;
                            customTrace.AppendLine("guid " + "is " + PAGuid);
                            // Call the CreateAlternateRecordForPA Handler Method 
                            PATPAHandler.CreateAlternateRecordForPA(serviceConnector, targetEntity, PAGuid, customTrace);
                            customTrace.AppendLine("End--CreateAlternateRecordForPA Handler method End");
                            #endregion
                        }
                        
                    }

                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "CreationofPlaceofAssemblyPlansPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }
    }
}
