﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
   public class FeeCalculationPluginStandardization : IPlugin
    {



        /// <summary>
        ///  This Plugin will be used to calculate fee for all the worktypes in jobfiling
        /// Register on JobFiling Entity
        ///       
        ///       * (a) Pre-Update Stage - [Synchronous] - Server - Calling user - Exe order (1) - dobnyc_jobfiling  (primary)
        ///             * Filtering Attributes -Amount Due,Amount Paid, Building Type,,Is Conjunction Job, Is Job Submitted,Refund, 
        ///                                     Filing Fees,InConjunction fee,Is Fee Exempt,New Work Filing Fee,No Good Check,PAA Fee,Record Management Fee,Total Job cost, jobstatus,iselectricalworktype
        ///       
        ///             * Filtering Attributes -Amount Due,Amount Paid, Building Type,Construction Fence,Is Conjunction Job, Is Job Submitted,Refund, Size of the Shed, Supported Scaffold, SideWlak Shed,
        ///                                     Filing Fees,InConjunction fee,Is Fee Exempt,New Work Filing Fee,No Good Check,PAA Fee,Record Management Fee,Total Job cost,jobstatus,iselectricalworktype,filingStatus                             
        ///          
        /// 
        /// 
        /// </summary>
        /// <param name="serviceProvider"></param>
       
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables Declaration
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();
            string PaymentHistoryGUID = string.Empty;
            #endregion

            try
            {

                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];

                if (context.PreEntityImages.Contains("PostImageJobFiling"))
                    postTargetEntity = context.PostEntityImages["PostImageJobFiling"];
                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 2)
                    return;
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;

                if (targetEntity.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling))
                {
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, " ishisotric", null, customTrace.ToString(), null, null);

                    return;
                }

                #endregion

                /// 1)check if it is new job filing or old job filing
                /// 2)if new job filing get the worktype flgs in to fee object
                /// 3)Based on the work types calculate fee (check fee should be calculted method)
                /// 4)For some work types fees will be calculated always(eg:FAB4 combined)  for other worktypes fee calculation will be determined by a method isFeesNeedtoCalculate
                /// 4)create the payment history and transaction history

                #region Get the worktypes and filing status in Jobfiling and assign in feeobject
                customTrace.AppendLine("set all the work type flags in fee object-start");
                Entity getWorkTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity : preTargetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && preTargetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? preTargetEntity : targetEntity;
                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(getWorkTypes, feeObject, customTrace);
                feeObject.FilingStatus = preTargetEntity.Contains(JobFilingEntityAttributeName.FilingStatus) && preTargetEntity[JobFilingEntityAttributeName.FilingStatus] != null ? preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : 1;
                customTrace.AppendLine("set all the work type flags in fee object-end");
                #endregion



                #region  set BuildingType in feeobject
                customTrace.AppendLine("set Building Type Started");
                FeeCalculationStandardizationHandler.GetBuildingTypeZoningcharactersticsInformation(serviceConnector, targetEntity, preTargetEntity,customTrace, feeObject);
                FeeCalculationStandardizationHandler. checkFeeRelatedFalgs(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                FeeCalculationStandardizationHandler. WhichEstimatedCost(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);
                customTrace.AppendLine(" Building Type not present" + feeObject.BuildingType + " " + feeObject.IsPAA);
                if (feeObject.BuildingType<=0 || feeObject.EstimatedCost<=0||feeObject.OwnerType==0||feeObject.jobType==0)
                {
                    customTrace.AppendLine(" Building Type not present" + feeObject.BuildingType +" estimated cost "+ feeObject.EstimatedCost + " ownertype  " + feeObject.OwnerType+" jobType "+ feeObject.jobType);
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, " BDT", null, customTrace.ToString(), null, null);
                    return;
                }
                #endregion


                #region Create Plugin for PAA
                if (context.MessageName == PluginHelperStrings.CreateMessageName && context.Stage==40)
                {
                   
                    if(feeObject.IsPAA && !feeObject.IsFeeExempt)

                    {
                        customTrace.AppendLine(" PAA Create Started");
                        FeeCalculationStandardizationHandler.CalculateFeeStandarization(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                        FeeCalculationStandardizationHandler.AfterFeeCalculation(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);
                        serviceConnector.Update(targetEntity);
                        customTrace.AppendLine(" targetEntity Updated");

                    }
                }
                

                #endregion


                #region Update Plugin
                //  throw new Exception("Building Type " + feeObject.BuildingType +"submitted contains :" + targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) +"value :"+targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted));
                else
                {
                    #region Main region -- Make separate blocks for each work type  and perform its calculations

                    #region Boilers Work Type BE

                    if (feeObject.IsBE)
                    {
                        //FeeCalculationStandardizationHandler.GetBoilerEnergysource(serviceConnector, targetEntity, preTargetEntity, customTrace, feeObject);
                        customTrace.AppendLine("Boilers Work Type Started");
                        feeObject.BoilerEnergySource= targetEntity.Contains(JobFilingEntityAttributeName.ProposedboilerEnergySource) && targetEntity[JobFilingEntityAttributeName.ProposedboilerEnergySource] != null ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.ProposedboilerEnergySource).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.ProposedboilerEnergySource) && preTargetEntity[JobFilingEntityAttributeName.ProposedboilerEnergySource] != null ? preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.ProposedboilerEnergySource).Value : 0;                           
                                             
                        customTrace.AppendLine("Boilers Work Type Started");
                        if (feeObject.BuildingType > 0 && feeObject.BoilerEnergySource > 0)//preimage building type will check in LOC Adjustment case
                        {
                            //throw new Exception("Boilers?" + feeObject.IsBE);
                            #region  Fee Calculation 

                            #region On Save - isSubmitted NO 
                            if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                            {

                                customTrace.AppendLine("(JobFilingEntityAttributeName.IsJobSubmitted) == false");
                                #region  Fee Calculation Save

                                customTrace.AppendLine("Boilers Work Type CalculateFeeStandarization Started");
                                FeeCalculationStandardizationHandler.CalculateFeeStandarization(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                                customTrace.AppendLine("Boilers Work Type CalculateFeeStandarization end");
                                #endregion

                            }
                            #endregion

                            #region On File, On Correction completed , On Loc Initiated  -isSubmitted YES 
                            // for setting temporary adjustment to final adjustment on filing
                            customTrace.AppendLine("Boilers Work Type OnFileCorrectionsCompletedLOCRequested Started");
                            FeeCalculationStandardizationHandler.OnFileCorrectionsCompletedLOCRequested(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);

                            #endregion

                            #endregion

                            #region afterFee Calculation
                            customTrace.AppendLine("Boilers Work Type AfterFeeCalculation Started");
                            FeeCalculationStandardizationHandler.AfterFeeCalculation(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);
                            #endregion

                        }
                    }

                    #endregion

                    #region Mechanical Work Type MS and ST

                    else if (feeObject.IsMS || feeObject.IsST|| feeObject.IsGC) //GC can be filed along with MS and ST
                    {
                        customTrace.AppendLine("Mechanical Work Type Started");
                        if (feeObject.BuildingType > 0)//preimage building type will check in LOC Adjustment case
                        {
                            //throw new Exception("Boilers?" + feeObject.IsBE);
                            #region  Fee Calculation 

                            #region On Save - isSubmitted NO 
                            if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                                || feeObject.FilingStatus == (int)CurrentFilingStatus.PermitEntire)
                            {

                                customTrace.AppendLine("(JobFilingEntityAttributeName.IsJobSubmitted) == false");
                                #region  Fee Calculation Save

                                customTrace.AppendLine("Mechanical Work Type CalculateFeeStandarization Started");
                                FeeCalculationStandardizationHandler.CalculateFeeStandarization(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                                customTrace.AppendLine("Mechanical Work Type CalculateFeeStandarization end");
                                #endregion

                            }
                            #endregion

                            #region On File, On Correction completed , On Loc Initiated  -isSubmitted YES 
                            // for setting temporary adjustment to final adjustment on filing
                            customTrace.AppendLine("Mechanical Work Type OnFileCorrectionsCompletedLOCRequested Started");
                            FeeCalculationStandardizationHandler.OnFileCorrectionsCompletedLOCRequested(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);

                            #endregion

                            #endregion

                            #region afterFee Calculation
                            customTrace.AppendLine("Mechanical Work Type AfterFeeCalculation Started");
                            FeeCalculationStandardizationHandler.AfterFeeCalculation(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);
                            #endregion

                        }
                    }

                    #endregion

                    #region PL SP SD AN WorkType

                    else if (feeObject.IsPL || feeObject.IsSD || feeObject.IsSP || feeObject.IsAN)
                    {
                        customTrace.AppendLine("PLSPSD Work Type Started");
                        if (feeObject.BuildingType > 0)//preimage building type will check in LOC Adjustment case
                        {
                            //throw new Exception("Boilers?" + feeObject.IsBE);
                            #region  Fee Calculation 

                            #region On Save - isSubmitted NO 
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                            {

                                customTrace.AppendLine("(JobFilingEntityAttributeName.IsJobSubmitted) == false");
                                #region  Fee Calculation Save

                                customTrace.AppendLine("PLSPSD Work Type CalculateFeeStandarization Started");
                                FeeCalculationStandardizationHandler.CalculateFeeStandarization(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                                customTrace.AppendLine("PLSPSD Work Type CalculateFeeStandarization end");
                                #endregion

                            }
                            #endregion

                            #region On File, On Correction completed , On Loc Initiated  -isSubmitted YES 
                            // for setting temporary adjustment to final adjustment on filing
                            customTrace.AppendLine("PLSPSD Work Type OnFileCorrectionsCompletedLOCRequested Started");
                            FeeCalculationStandardizationHandler.OnFileCorrectionsCompletedLOCRequested(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);

                            #endregion

                            #endregion

                            #region afterFee Calculation
                            customTrace.AppendLine("PLSPSD Work Type AfterFeeCalculation Started");
                            FeeCalculationStandardizationHandler.AfterFeeCalculation(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);
                            #endregion

                        }
                    }

                    #endregion

                    #region CC WorkType

                    else if (feeObject.IsCC)
                    {
                        customTrace.AppendLine("CC Work Type Started");
                        if (feeObject.BuildingType > 0)
                        {

                            #region  Fee Calculation 

                            #region On Save - isSubmitted NO 
                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false)
                            {

                                customTrace.AppendLine("(JobFilingEntityAttributeName.IsJobSubmitted) == false");
                                #region  Fee Calculation Save

                                customTrace.AppendLine("PLSPSD Work Type CalculateFeeStandarization Started");
                                FeeCalculationStandardizationHandler.CalculateFeeStandarization(serviceConnector, customTrace, targetEntity, preTargetEntity, feeObject);
                                customTrace.AppendLine("PLSPSD Work Type CalculateFeeStandarization end");
                                #endregion

                            }
                            #endregion

                            #region On File, On Correction completed , On Loc Initiated  -isSubmitted YES 
                            // for setting temporary adjustment to final adjustment on filing
                            customTrace.AppendLine("PLSPSD Work Type OnFileCorrectionsCompletedLOCRequested Started");
                            FeeCalculationStandardizationHandler.OnFileCorrectionsCompletedLOCRequested(targetEntity, serviceConnector, customTrace, preTargetEntity, feeObject);

                            #endregion

                            #endregion

                            #region afterFee Calculation
                            customTrace.AppendLine("PLSPSD Work Type AfterFeeCalculation Started");
                            FeeCalculationStandardizationHandler.AfterFeeCalculation(targetEntity, PaymentHistoryGUID, serviceConnector, customTrace, preTargetEntity, feeObject);
                            #endregion

                        }
                    }

                    #endregion

                    #endregion
                }

                #endregion
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, " TEST ----FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", null, customTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginStandardization - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
