﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class DocumentItemPostUpdate : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            Entity targetEntity = null;
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            string JobNumber = string.Empty;
            try
            {

                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity == null)
                    return;

                Entity preTargetEntity = (Entity)context.PreEntityImages["PreImage"];

                if (targetEntity.Attributes.Contains(DocumentListEntityAttributeName.DocumentURL) && !targetEntity.Contains(DocumentListEntityAttributeName.CreatedDueto))
                {

                    string DocumentURL = targetEntity.Attributes[DocumentListEntityAttributeName.DocumentURL].ToString();
                    string PreImageDocumentURL = string.Empty;
                    string PreImageDocumentSource = string.Empty;

                    customTrace.AppendLine("DocumentURL: " + DocumentURL);
                    if (preTargetEntity.Attributes.Contains(DocumentListEntityAttributeName.DocumentURL))
                    {
                        if (!string.IsNullOrEmpty(preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentURL].ToString()))
                            PreImageDocumentURL = preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentURL].ToString();
                    }
                    customTrace.AppendLine("PreImageDocumentURL: " + PreImageDocumentURL);

                    if (preTargetEntity.Attributes.Contains(DocumentListEntityAttributeName.DocumentSource))
                    {
                        if (!string.IsNullOrEmpty(preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentSource].ToString()))
                            PreImageDocumentSource = preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentSource].ToString();
                        customTrace.AppendLine("PreImageDocumentSource: " + PreImageDocumentSource);
                    }

                    if (!string.IsNullOrEmpty(PreImageDocumentURL) && PreImageDocumentSource == "Documentum")
                    {
                        if (String.Compare(DocumentURL, PreImageDocumentURL) != 0)
                        {
                            customTrace.AppendLine("DocumentURL != PreImageDocumentURL ");
                            Guid documentTypeGuid = ((EntityReference)preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentName]).Id;
                            customTrace.AppendLine("Target Entity: documentTypeGuid " + documentTypeGuid);
                            customTrace.AppendLine("Document Name: " + ((EntityReference)preTargetEntity.Attributes[DocumentListEntityAttributeName.DocumentName]).Name);
                            customTrace.AppendLine("Start  CreateDocumentlistVersions ");
                            Entity PreviousVersion = DocumentItemUploadHandler.CreateDocumentlistVersions(serviceConnector, preTargetEntity, documentTypeGuid, "Version", customTrace);
                            customTrace.AppendLine("End  CreateDocumentlistVersions ");

                            if (PreviousVersion != null)
                                serviceConnector.Create(PreviousVersion);

                        }
                    }


                }
                

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemPostUpdate - Execute, JobNumber =" + JobNumber, ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
