﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    /// <summary>
    /// Add No good check transactioin code to fee config.
    /// </summary>
    public class PW5PostOperationPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                //targetEntity = CommonPluginLibrary.Merge(p);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 4)
                    return;

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preImage = new Entity();

                if (context.PreEntityImages.Contains("PreImage"))
                    preImage = context.PreEntityImages["PreImage"];

                if (context.MessageName.ToUpper() == "CREATE")
                {
                    if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays) || targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsFeeExempt))
                    {
                        customTrace.AppendLine("AHV Calculation Start:" + PluginHelperStrings.UpdateMessageName);
                        CommonPluginLibrary.Merge(targetEntity, preImage);
                        PW5AfterHourVarianceFeeCalcHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                        customTrace.AppendLine("AHV Calculation end:" + PluginHelperStrings.UpdateMessageName);
                    }
                }

                //Calculate total cost and update
                if (context.MessageName.ToUpper() == "UPDATE")
                {
                    #region Unwanted Region
                    //if (preImage.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays) && targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays))
                    //{
                    //    customTrace.AppendLine("Check for no.of days - Start");
                    //    if (preImage.Attributes[PW5AfterHoursAttributeNames.NumberOfDays].ToString() == targetEntity.Attributes[PW5AfterHoursAttributeNames.NumberOfDays].ToString())

                    //    {

                    //        if (targetEntity.Contains(PW5AfterHoursAttributeNames.IsSubmitted) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsSubmitted))//OnFiling AHV
                    //        {
                    //            customTrace.AppendLine("AHV Calculation Start:" + PluginHelperStrings.UpdateMessageName);
                    //            CommonPluginLibrary.Merge(targetEntity, preImage);
                    //            PW5AfterHourVarianceFeeCalcHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                    //            customTrace.AppendLine("AHV Calculation end:" + PluginHelperStrings.UpdateMessageName);
                    //        }
                    //        customTrace.AppendLine("Check for no.of days - End");
                    //        return;
                    //    }
                    //}
                    #endregion
                    customTrace.AppendLine("End of first condition statement check");
                    if ((!preImage.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays) && targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays)))
                    {

                        customTrace.AppendLine("If no.of days is not entered in first update - Start");
                        CommonPluginLibrary.Merge(targetEntity, preImage);
                        PW5AfterHourVarianceFeeCalcHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                        customTrace.AppendLine("If no.of days is not entered in first update - End");
                        return;
                    }

                    customTrace.AppendLine("End of Second condition statement check");
                    if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays) || targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.AHVPermitStatus) || (targetEntity.Contains(PW5AfterHoursAttributeNames.IsSubmitted) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsSubmitted)))
                    {

                        customTrace.AppendLine("Check Permit Status" + targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.AHVPermitStatus));
                        CommonPluginLibrary.Merge(targetEntity, preImage);
                        if ((((OptionSetValue)targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVPermitStatus]).Value == (int)AHVPermitStatus.Approved) || (((OptionSetValue)targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVPermitStatus]).Value == (int)AHVPermitStatus.PreFiling) || targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsSubmitted))
                        {

                            customTrace.AppendLine("Check Conditions");
                            #region added AHV Fee Exempt and adjustment Changes
                            if ((targetEntity.Attributes[PW5AfterHoursAttributeNames.NumberOfDays] != preImage.Attributes[PW5AfterHoursAttributeNames.NumberOfDays]) //change in Number of days 
                                || (((OptionSetValue)targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVPermitStatus]).Value != ((OptionSetValue)preImage.Attributes[PW5AfterHoursAttributeNames.AHVPermitStatus]).Value) //Change in AHV Permit status
                                || (targetEntity.Contains(PW5AfterHoursAttributeNames.IsFeeExempt) && preImage.Contains(PW5AfterHoursAttributeNames.IsFeeExempt) && preImage.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsFeeExempt) != targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsFeeExempt)) // User swaps between fee exempt to non fee exempt
                                || (!preImage.Contains(PW5AfterHoursAttributeNames.IsFeeExempt) && targetEntity.Contains(PW5AfterHoursAttributeNames.IsFeeExempt) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsFeeExempt))//Pre image does not have value and user making fee exempt yes
                                || (targetEntity.Contains(PW5AfterHoursAttributeNames.IsSubmitted) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsSubmitted))//OnFiling AHV
                               )
                            {

                                customTrace.AppendLine("AHV Calculation Start:" + PluginHelperStrings.UpdateMessageName);

                                PW5AfterHourVarianceFeeCalcHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                                customTrace.AppendLine("AHV Calculation end:" + PluginHelperStrings.UpdateMessageName);

                            }
                            #endregion


                        }
                    }
                }

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                //  throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                //  throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                //throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5PostOperationPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
