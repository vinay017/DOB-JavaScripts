﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class TR3MixOnCreatePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            Guid TR3Guid = new Guid();
            Entity targetEntity = null;
            Entity preTargetEntity = null;
            customTrace.AppendLine("Pre Create TR3MixOnCreatePlugin start...");
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                    return;
                if (!(targetEntity.LogicalName.Equals(TR3MixEntityAttribute.EntityLogicalName) || targetEntity.LogicalName.Equals(TR3TechnicalReportEntityAttribute.EntityLogicalName)))
                    return;
                customTrace.AppendLine("Target Entity:--- " + targetEntity.LogicalName);
                // Pre-Create TR3 Mix Entity
                if (context.PreEntityImages.Contains("PreImage"))
                    preTargetEntity = context.PreEntityImages["PreImage"];


                #region Pre-Create Staging
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.CreateMessageName.ToUpper()) &&
                    context.Stage == 20)
                {
                    if(targetEntity.LogicalName==TR3MixEntityAttribute.EntityLogicalName)
                    {
                        customTrace.AppendLine("context.MessageName :-- " + PluginHelperStrings.CreateMessageName.ToUpper());
                        if (targetEntity.Attributes.Contains(TR3MixEntityAttribute.GotoTRTechnicalreport) && (targetEntity.Attributes.Contains(TR3MixEntityAttribute.IsMixcreatedonPAA) && !targetEntity.GetAttributeValue<bool>(TR3MixEntityAttribute.IsMixcreatedonPAA)))
                        {
                            TR3Guid = ((EntityReference)targetEntity.Attributes[TR3MixEntityAttribute.GotoTRTechnicalreport]).Id;
                            customTrace.AppendLine("TR3Guid " + "is-- " + TR3Guid);
                            // Call the SetTR3MixNameAndUpdateCounterForTR3Mix Handler Method 
                            TR3MixHandler.SetTR3MixNameAndUpdateCounterForTR3Mix(serviceConnector, targetEntity, TR3Guid, customTrace);
                            customTrace.AppendLine("End-UpdateCounterForTR3Mix Handler method End");
                        }
                    }
                                       
                }
                #endregion
                #region pre-Delete
                if (context.MessageName.ToUpper().Equals(PluginHelperStrings.DeleteMessageName.ToUpper()) 
                 )
                {
                    #region Document Deletion
                    customTrace.AppendLine("Start -Delete TR3 Mix Document Handler method End");
                    TR3MixHandler.DeleteTR3MixDocumentList(serviceConnector, preTargetEntity, customTrace);
                    customTrace.AppendLine("End -Delete TR3 Mix Document Handler method End");
                    #endregion

                    #region Tr2 Test Report Deletion
                    customTrace.AppendLine("Start -Delete TR2 Test report   method End");
                    TR3MixHandler.DeleteTR2TestReport(serviceConnector, preTargetEntity, customTrace);
                    customTrace.AppendLine("End -Delete TR2 Test report method End");
                    #endregion


                }

                #endregion
                // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreatePlugin - Final: End ", null, customTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "TR3MixOnCreatePlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
    

