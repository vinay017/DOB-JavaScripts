﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Collections.Generic;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class JobFilingPostUpdateOperation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                //targetEntity = CommonPluginLibrary.Merge(p);

                customTrace.AppendLine("End GetEntityFromContext..");
                //if (context.Depth > 1)
                //    return;

                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;

                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                if (context.Depth > 3)
                    return;


                //Entity preTargetEntity = (Entity)context.PreEntityImages["PreImageJobFiling"];
                Entity preImage = (Entity)context.PreEntityImages["PreImage"];
                Entity postTargetEntity = (Entity)context.PostEntityImages["PostImageJobFiling"];

                //throw new Exception(((Money)postTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value.ToString()+ "" +  "   " + ((Money)preTargetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value.ToString());
                //Calculate total cost and update
                //if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType)
                //    && preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType)
                //|| targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))

                //{

                //    CommonPluginLibrary.Merge(targetEntity, preTargetEntity);

                //    customTrace.AppendLine(((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value.ToString());
                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                //    {
                //        customTrace.AppendLine("Start Fee Calculation:" + PluginHelperStrings.UpdateMessageName);

                //        //RemoveWorkFlowAttributes(targetEntity);

                //        JobFilingFeeCalc.CalculateFee(serviceConnector, targetEntity, customTrace, preTargetEntity, postTargetEntity);
                //        customTrace.AppendLine("End Finish Calculation:" + PluginHelperStrings.UpdateMessageName);
                //    }
                //}              

                // if Withdrawal Request made
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.WithdrawalStatus))
                //{
                //    int withdrawalStatus = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.WithdrawalStatus]).Value;
                //    customTrace.AppendLine("Withdrawal Request Status:" + withdrawalStatus);
                //    // stop plugin when not required based on Withdrawal Request Status
                //    if (withdrawalStatus == (int)WithdrawalStatus.PendingQAAssignment || withdrawalStatus == (int)WithdrawalStatus.QAReview || withdrawalStatus == (int)WithdrawalStatus.InspectionRequired
                //        || withdrawalStatus == (int)WithdrawalStatus.PendingPlanExaminerAssignment || withdrawalStatus == (int)WithdrawalStatus.PlanExaminerReview || withdrawalStatus == (int)WithdrawalStatus.QAFailed
                //        || withdrawalStatus == (int)WithdrawalStatus.WithdrawalObjections)
                //    {
                //        customTrace.AppendLine("Withdrawal Request is not completed!!");
                //        return;
                //    }
                //    customTrace.AppendLine("Start Withdrawal Request:" + PluginHelperStrings.UpdateMessageName);
                //    JobFilingWithdrawalHandler.Withdrawal(serviceConnector, targetEntity, customTrace, preTargetEntity, withdrawalStatus);
                //    customTrace.AppendLine("End Withdrawal Request:" + PluginHelperStrings.UpdateMessageName);

                //}

                //// JobFiling Change Trace
                customTrace.AppendLine("ChangeSetTrace Started");
                JobFilingChangeTraceHandler.ChangeTrace(serviceConnector, targetEntity, customTrace, preImage);
                customTrace.AppendLine("ChangeSetTrace End");

                //PW1 Standardization: Start
                customTrace.AppendLine("PW1 Standardization - Start");
                FeeCalculationObject targetFCObject = new FeeCalculationObject();
                //FeeCalculationObject preFCObject = new FeeCalculationObject();
                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(targetEntity, targetFCObject, customTrace);
                //FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(preImage, preFCObject, customTrace);
                customTrace.AppendLine("PW1 Standardization - Worktype Set");                
                //PW1 Standardization: End


                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                {
                    int currentFilingStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                    customTrace.AppendLine("currentFilingStatus: " + currentFilingStatus);
                    int previousFilingStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                    customTrace.AppendLine("previousFilingStatus: " + previousFilingStatus);
                    //int jobStatus = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobStatus]).Value;
                    //customTrace.AppendLine("jobStatus" + jobStatus);
                    //if (jobStatus == (int)JobStatus.JobinProcess && currentFilingStatus != previousFilingStatus)
                    if (currentFilingStatus != previousFilingStatus)
                    {
                        customTrace.AppendLine("Start Job LOC Process: " + PluginHelperStrings.UpdateMessageName);
                        // Commented out old LOC Logic 06/07/2017
                        //JobFilingLOCHandler.JobLOCHandler(serviceConnector, targetEntity, customTrace, currentFilingStatus);
                        customTrace.AppendLine("End Job LOC Process: " + PluginHelperStrings.UpdateMessageName);

                        customTrace.AppendLine("Start update Associate Work Type : " + PluginHelperStrings.UpdateMessageName);
                        WorkTypeHandler.UpdateAssociatedWorkTypes(serviceConnector, targetEntity, customTrace, currentFilingStatus);
                        customTrace.AppendLine("End update Associate Work Type: " + PluginHelperStrings.UpdateMessageName);

                        if (currentFilingStatus == (int)CurrentFilingStatus.MinorMajorObjections)
                        {
                            customTrace.AppendLine("Start update Objections : " + PluginHelperStrings.UpdateMessageName);
                            ObjectionHandler.ApprovedObjections(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End update Objections: " + PluginHelperStrings.UpdateMessageName);
                        }

                        #region Create Job Filing Trace - new change 4/16/2019
                        string cFStatus = postTargetEntity.FormattedValues[JobFilingEntityAttributeName.FilingStatus];
                        customTrace.AppendLine("cFStatus:" + cFStatus);
                        List<int> reviewstatus = new List<int>();
                        reviewstatus.Add((int)CurrentFilingStatus.PreFiling);
                        reviewstatus.Add((int)CurrentFilingStatus.DesignProfessionalReview);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingCPEACPEAssignment);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingPlanExaminer);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingPlanExaminerReview);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingProfCertQAAssignment);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingProfCertQAReview);
                        reviewstatus.Add((int)CurrentFilingStatus.PendingQAReview);
                        reviewstatus.Add((int)CurrentFilingStatus.ProfCertQAinReview);
                        reviewstatus.Add((int)CurrentFilingStatus.PlanExaminerReview);
                        reviewstatus.Add((int)CurrentFilingStatus.CheifPlanExaminerReview);
                        reviewstatus.Add((int)CurrentFilingStatus.QAReview);
                        reviewstatus.Add((int)CurrentFilingStatus.PermitEntireBCDBCReview);
                        //reviewstatus.Add((int)CurrentFilingStatus.PendingL2Review);
                        reviewstatus.Add((int)CurrentFilingStatus.L2ApprovedProfCertQAReview);
                        reviewstatus.Add((int)CurrentFilingStatus.L2ApprovedQAReview);

                        if (!reviewstatus.Contains(currentFilingStatus))
                        {
                            SubmitHandler.CreateBuildTrace(serviceConnector, targetEntity, postTargetEntity, cFStatus, customTrace);
                        }
                        #endregion

                        #region Fence PAA Rejection 08/10/2017
                        if (currentFilingStatus == (int)CurrentFilingStatus.Rejected)
                        {
                            if((preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA) && (preImage.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName)))
                            {
                                customTrace.AppendLine("Start update Parent PAA Flags : " + PluginHelperStrings.UpdateMessageName);
                                Guid parent_JFID = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;
                                customTrace.AppendLine("parent_JFID : " + parent_JFID.ToString());
                                Entity parent_jf = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                                parent_jf.Id = parent_JFID;
                                parent_jf.Attributes.Add(JobFilingEntityAttributeName.IsPAAinProgress, false);
                                serviceConnector.Update(parent_jf);
                                customTrace.AppendLine("End update Parent PAA Flags : " + PluginHelperStrings.UpdateMessageName);
                            }
                        }
                        #endregion
                    }

                }

                #region Emails for DP
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ApplicantPerson))
                {
                    customTrace.AppendLine("JobFilingEntityAttributeName.ApplicantPerson is present ");
                    Guid currentApplicant = ((EntityReference)targetEntity[JobFilingEntityAttributeName.ApplicantPerson]).Id;
                    if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicantPerson))
                    {
                        Guid previousApplicant = ((EntityReference)preImage[JobFilingEntityAttributeName.ApplicantPerson]).Id;
                        if (currentApplicant != previousApplicant)
                        {
                            customTrace.AppendLine("Start Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                            EmailHandler.DPEmail(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                        }
                    }
                    if (!preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicantPerson))
                    {
                        customTrace.AppendLine("Start Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                        EmailHandler.DPEmail(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                    }

                }
                #endregion

                #region Emails for Owner
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OwnerLeaseHolder))
                {
                    if (((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder]) != null))
                    {
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id.ToString())))
                        {

                            customTrace.AppendLine("JobFilingEntityAttributeName.OwnerLeaseHolder is present ");
                            Guid currentOwner = ((EntityReference)targetEntity[JobFilingEntityAttributeName.OwnerLeaseHolder]).Id;
                            if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OwnerLeaseHolder))
                            {
                                customTrace.AppendLine("JobFilingEntityAttributeName.OwnerLeaseHolder is present for preImage");
                                if (!string.IsNullOrEmpty((((EntityReference)(preImage.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id.ToString())))
                                {
                                    customTrace.AppendLine("Preimage OwnerLeaseHolder Id: " + ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id.ToString());
                                    customTrace.AppendLine("Preimage OwnerLeaseHolder Id: " + ((EntityReference)(preImage.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id.ToString());
                                    //Guid previousOwner = Guid.Parse(((EntityReference)(preImage.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id.ToString());
                                    if (currentOwner != ((EntityReference)(preImage.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder])).Id)
                                    {
                                        customTrace.AppendLine("Start Owner Email: " + PluginHelperStrings.UpdateMessageName);
                                        EmailHandler.OwnerEmail(serviceConnector, targetEntity, customTrace);
                                        customTrace.AppendLine("End Owner Email: " + PluginHelperStrings.UpdateMessageName);
                                    }
                                }
                            }
                        }
                        if (!preImage.Attributes.Contains(JobFilingEntityAttributeName.OwnerLeaseHolder))
                        {
                            customTrace.AppendLine("Start Owner Email: " + PluginHelperStrings.UpdateMessageName);
                            EmailHandler.OwnerEmail(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End Owner Email: " + PluginHelperStrings.UpdateMessageName);
                        }
                    }

                }
                #endregion
                customTrace.AppendLine("Email for Owner - End");
                #region Emails for Filing Representative
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                {
                    customTrace.AppendLine("EntityReference" + 1);
                    if (((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.FilingRepresentativeAttributeName]) != null))
                    {
                        customTrace.AppendLine("EntityReference" + 2);
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.FilingRepresentativeAttributeName])).Id.ToString())))
                        {
                            customTrace.AppendLine("JobFilingEntityAttributeName.FilingRepresentativeAttributeName is present ");
                            Guid currentFR = ((EntityReference)targetEntity[JobFilingEntityAttributeName.FilingRepresentativeAttributeName]).Id;
                            if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                            {
                                if (!string.IsNullOrEmpty(((EntityReference)(preImage.Attributes[JobFilingEntityAttributeName.FilingRepresentativeAttributeName])).Id.ToString()))
                                {
                                    Guid previousFR = ((EntityReference)preImage[JobFilingEntityAttributeName.FilingRepresentativeAttributeName]).Id;
                                    if (currentFR != previousFR)
                                    {
                                        customTrace.AppendLine("Start Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);
                                        EmailHandler.FREmail(serviceConnector, targetEntity, customTrace);
                                        customTrace.AppendLine("End Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);
                                    }
                                }
                            }
                        }
                    }
                    if (!preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                    {
                        customTrace.AppendLine("Start Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);
                        EmailHandler.FREmail(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);
                    }

                }

                #endregion
                customTrace.AppendLine("Email for FR - End");
                #region Associate WorkTypes
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization) 
                    || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StandPipeWorkType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox)
                    || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold)
                    || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.isElectricalWorkType)
                    //|| targetEntity.Attributes.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MechanicalWorkType)
                    )
                {
                    customTrace.AppendLine("Start Creating/Deleting Associated WorkTypes");
                    //WorkTypeHandler.CreateAssociatedWorkTypes_UpdateAsync(serviceConnector, targetEntity, preImage, customTrace);
                    customTrace.AppendLine("End Creating/Deleting Associated WorkTypes");
                }
                #endregion
                customTrace.AppendLine("Associate WorkTypes - End");
                #region Work Type Grid For Existing Records
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CreateWorkTypes))
                {
                    customTrace.AppendLine("JobFilingEntityAttributeName.CreateWorkTypes is present ");
                    bool CurrentWTFlag = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CreateWorkTypes);
                    customTrace.AppendLine("CurrentWTFlag: " + CurrentWTFlag.ToString());
                    bool PreviousWTFlag = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.CreateWorkTypes);
                    customTrace.AppendLine("PreviousWTFlag: " + PreviousWTFlag.ToString());

                    if (CurrentWTFlag = true && CurrentWTFlag != PreviousWTFlag)
                    {
                        customTrace.AppendLine("Start Creating Associated WorkTypes");
                        WorkTypeHandler.CreateAssociatedWorkTypes(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Creating Associated WorkTypes");
                    }


                }
                customTrace.AppendLine("WorkTypeGrid for Existing Records - End");
                #endregion

                #region Old LOC logic Commented on 06/07/2017

                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobStatus))
                //{
                //    customTrace.AppendLine("JobFilingEntityAttributeName.JobStatus is present ");
                //    int CurrentJobStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                //    customTrace.AppendLine("CurrentJobStatus: " + CurrentJobStatus.ToString());
                //    int PreviousJobStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                //    customTrace.AppendLine("PreviousJobStatus: " + PreviousJobStatus.ToString());

                //    if (CurrentJobStatus != (int)JobStatus.JobinProcess && CurrentJobStatus != PreviousJobStatus)
                //    {
                //        Guid processId = new Guid(GetProcessId(serviceConnector, "workflow", "name", "Job LOC - Master Workflow").Id.ToString());
                //        customTrace.AppendLine("Execute Workflow: Job LOC - Master Workflow ");
                //        ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);
                //    }

                //}

                #endregion

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobStatus))
                {
                    customTrace.AppendLine("JobFilingEntityAttributeName.JobStatus is present ");
                    int CurrentJobStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                    customTrace.AppendLine("CurrentJobStatus: " + CurrentJobStatus.ToString());
                    int PreviousJobStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                    customTrace.AppendLine("PreviousJobStatus: " + PreviousJobStatus.ToString());

                    if (CurrentJobStatus != (int)JobStatus.JobinProcess && CurrentJobStatus != PreviousJobStatus)
                    {
                        int jobStatus = CurrentJobStatus;
                        Guid ParentGuid = targetEntity.GetAttributeValue<Guid>(JobFilingEntityAttributeName.ParentJobFilingAttributeName);
                        //if (jobStatus == (int)JobStatus.LOCIssued || jobStatus == (int)JobStatus.ObjectionstoLOC || jobStatus == (int)JobStatus.PendingQAAssignmentforLOC || jobStatus == (int)JobStatus.QAReviewforLOC)
                        //{
                        //    customTrace.AppendLine("Start Job LOC Process: " + PluginHelperStrings.UpdateMessageName);
                        //    JobFilingLOCHandler.ParentJobtoFilingsLOCStatus(serviceConnector, targetEntity, customTrace, jobStatus);
                        //    customTrace.AppendLine("End Job LOC Process: " + PluginHelperStrings.UpdateMessageName);
                        //} Old LOC logic Commented on 06/07/2017
                        // if (jobStatus == (int)JobStatus.LOCIssued && context.Depth > 1)
                        if (jobStatus == (int)JobStatus.LOCIssued)
                        {
                            customTrace.AppendLine("Start  LOC Email Process: " + PluginHelperStrings.UpdateMessageName);
                            JobFilingLOCHandler.SendEmail(serviceConnector, targetEntity, customTrace);
                            customTrace.AppendLine("End  LOC Email Process: " + PluginHelperStrings.UpdateMessageName);

                        }
                    }

                }

                #region GC SiteSafety
                //if((targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && preImage.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType)))
                //{
                //    customTrace.AppendLine(" Start Site Safety Logic: " + PluginHelperStrings.UpdateMessageName);
                //    GCMHSTHandler.Adjust_SiteSafety_Update(serviceConnector, targetEntity, preImage, customTrace);
                //    customTrace.AppendLine(" End Site Safety Logic: " + PluginHelperStrings.UpdateMessageName);
                //}
                #endregion

                #region FAB 4 Scope of work Logic

                //PW1 standardization changes: Start

                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == false)
                customTrace.AppendLine("FAB4 Check 1- Start");
                if (targetEntity.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] == null)
                {                    
                    if (targetFCObject.IsFN || targetFCObject.IsSH || targetFCObject.IsSF)
                    {                        
                        customTrace.AppendLine("PW1 Standardization - Start FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                        FAB4ScopeofWorkHandlerV2.Adjust_FAB4ScopeofWork_Update(serviceConnector, targetEntity, preImage, customTrace);
                        customTrace.AppendLine("PW1 Standardization - End FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                    }
                }
                else
                {
                    //PW1 Standardization changes: End
                if ((targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence) && preImage.Contains(JobFilingEntityAttributeName.ConstructionFence))
                    || (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && preImage.Contains(JobFilingEntityAttributeName.SidewalkShed))
                    || (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && preImage.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                    )
                {
                    customTrace.AppendLine(" Start FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                    FAB4ScopeofWorkHandler.Adjust_FAB4ScopeofWork_Update(serviceConnector, targetEntity, preImage, customTrace);
                    customTrace.AppendLine(" End FAB 4 Scope of work Logic: " + PluginHelperStrings.UpdateMessageName);
                }

                }
                #endregion

                
                #region DPL1 Document Validation on LicenseType Update
                if (targetEntity.Contains(JobFilingEntityAttributeName.LicenseLookupField) && preImage.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                {
                    Guid Pre_LicenseGuid = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.LicenseLookupField).Id;
                    customTrace.AppendLine(" Pre_LicenseGuid: " + Pre_LicenseGuid.ToString());
                    Guid Current_LicenseGuid = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.LicenseLookupField).Id;
                    customTrace.AppendLine(" Current_LicenseGuid: " + Current_LicenseGuid.ToString());
                    if(Pre_LicenseGuid != Current_LicenseGuid)
                    {
                        customTrace.AppendLine("Start DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                        SealSignaturesHandler.JobFilingSealandSignatureDocuments(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End DPL1 Document Validation: " + PluginHelperStrings.CreateMessageName);
                    }
                }

                #endregion

                #region Check if Corrections completed
                if(targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted))
                {
                    bool iscorrectioncomp = targetEntity.Attributes[JobFilingEntityAttributeName.IsCorrectionCompleted] != null ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) : false;
                    customTrace.AppendLine(" iscorrectioncomp: " + iscorrectioncomp.ToString());
                    bool iscorrectioncomp_pre = (preImage.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && preImage.Attributes[JobFilingEntityAttributeName.IsCorrectionCompleted] != null) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) : false;
                    customTrace.AppendLine(" iscorrectioncomp_pre: " + iscorrectioncomp_pre.ToString());
                    if(iscorrectioncomp != iscorrectioncomp_pre && iscorrectioncomp)
                    {
                        JobFilingTaskHandler.UpdateDocumentsOnTask(serviceConnector, preImage, customTrace);
                    }
                }

                #endregion
                customTrace.AppendLine("PW1 Standardization - Adjust_FAB4ScopeofWork Completed!");
                //throw new Exception(" crmTrace: Aqib is debugging");

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPostUpdateOperation - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void RemoveWorkFlowAttributes(Entity targetEntity)
        {
            //targetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
            targetEntity.Attributes.Remove(JobFilingEntityAttributeName.CreateaWithdrawalRequest);
            targetEntity.Attributes.Remove(JobFilingEntityAttributeName.IsChangeLocationRequest);
            targetEntity.Attributes.Remove(JobFilingEntityAttributeName.CreateaSupersedingRequest);
            targetEntity.Attributes.Remove(JobFilingEntityAttributeName.IsWithdrawalRequestMade);
        }

        public static void ExecuteWorkflow(IOrganizationService connector, Guid workflowId, Guid entityId)
        {
            try
            {
                ExecuteWorkflowRequest request = new ExecuteWorkflowRequest
                {
                    EntityId = entityId,
                    WorkflowId = workflowId
                };

                connector.Execute(request);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private static Entity GetProcessId(IOrganizationService service, string EntityLogicalName, string SearchFieldName, object SearchValue)
        {
            EntityLogicalName = EntityLogicalName.ToLower();
            SearchFieldName = SearchFieldName.ToLower();
            QueryExpression query = new QueryExpression(EntityLogicalName);
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition(new ConditionExpression(SearchFieldName, ConditionOperator.Equal, SearchValue));
            query.Criteria.AddCondition(new ConditionExpression("type", ConditionOperator.Equal, 1));

            try
            {
                EntityCollection response = service.RetrieveMultiple(query);
                if (response != null && response.Entities.Count > 0)
                    return response.Entities[0];
                else { return null; }

            }
            catch (Exception ex)
            {
                //Do error hadling
                throw ex;
            }

        }  // getProcessId ends here


    }
}
