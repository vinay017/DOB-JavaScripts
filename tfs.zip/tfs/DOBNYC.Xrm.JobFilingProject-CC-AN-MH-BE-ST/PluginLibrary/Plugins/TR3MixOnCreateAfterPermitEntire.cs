﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class TR3MixOnCreateAfterPermitEntire : PluginHandlerBase, IPlugin
    {/// <summary>
    /// This pluginshould be registed on TR3 MIX post create
    /// </summary>
    /// <param name="serviceProvider"></param>
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables Declaration
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            FeeCalculationObject feeObject = new FeeCalculationObject();

            EntityCollection TR3s = new EntityCollection();
            Entity Tr2Record = new Entity();
            #endregion
            try
            {
                //this plugin is changed from mix to director 
                //new requirement is when tr3 directors attestation is completed after permit entire of bcdbc review we have to move mixes of that director to test report
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != TR3Director.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();




                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 2)
                    return;



                #endregion

                ///1)Get the TR3 director from Tr3 mix
                ///2)get the TR3 main from Tr3 director
                ///3)Get the job filing from tr3main
                ///4)Get the jobfiling details filing status and it should be permit entire
                ///5)get the TR2 report from jobfiling
                ///5)check conditions to create test report a)jobfiling permit entire b)get the tr2 record from jobfiling 

                customTrace.AppendLine("Get the TR3 director details from Tr3 MIX");
               
                if (targetEntity.Contains(TR3Director.designApplicantCheckBox) && targetEntity[TR3Director.designApplicantCheckBox] != null && targetEntity.GetAttributeValue<bool>(TR3Director.designApplicantCheckBox))
                {
                    Entity Tr3Director = serviceConnector.Retrieve(TR3Director.EntityLogicalName, targetEntity.Id, new ColumnSet(new string[] {TR3Director.Name, TR3Director.CPBusinessaddesss,
                                TR3Director.CPBusinesCity, TR3Director.CPBusinesFax, TR3Director.CPBusinesName, TR3Director.CPBusinesNameLookup, TR3Director.CPBusinesState, TR3Director.CPBusinesTelephone,
                                TR3Director.CPBusinesZip, TR3Director.CPLicenseLookup, TR3Director.CPName, TR3Director.CPNameLookup, TR3Director.CPDate,TR3Director.GotoJobFiling, TR3Director.NRMCAExpirationDate,TR3Director.TR3TrackingNumber }));
                    customTrace.AppendLine("Get the TR3 main details from Tr3 director");
                    if (Tr3Director.Id != null  && Tr3Director[TR3Director.GotoJobFiling] != null)
                    {
                       
                        customTrace.AppendLine("Tr3Director Found ");
                       
                       // Entity Tr3Main = serviceConnector.Retrieve(TR3TechnicalReport.EntityLogicalName, Tr3Director.GetAttributeValue<EntityReference>(TR3Director.GotoTR3Technicalreport).Id, new ColumnSet(new string[] {TR3TechnicalReport.GotoJobFiling
                              ///  }));
                       // customTrace.AppendLine("Get the job filing from tr3main");
                       // if (Tr3Main.Id != null && Tr3Main.Contains(TR3TechnicalReport.GotoJobFiling) && Tr3Main[TR3TechnicalReport.GotoJobFiling] != null)
                        {
                            customTrace.AppendLine("Tr3Main Found ");
                            Entity JobFiling = serviceConnector.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Tr3Director.GetAttributeValue<EntityReference>(TR3Director.GotoJobFiling).Id, new ColumnSet(new string[] {JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.IsHistoricJobFiling,JobFilingEntityAttributeName.FilingStatus
                                }));
                           
                            if (JobFiling.Id != null && !(JobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && JobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && JobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true) && (JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntire|| JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReview) || JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReviewObjections) //Job filing Must be in permit entire
                            {
                               
                                customTrace.AppendLine("JobFiling Found ");
                                #region Get the worktypes in Jobfiling and assign in feeobject
                                customTrace.AppendLine("set all the work type flags in fee object-start");
                                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(JobFiling, feeObject, customTrace);
                                customTrace.AppendLine("set all the work type flags in fee object-end");
                                #endregion
                                
                                if (feeObject.IsST)
                                {
                                    TR3s = FeeCalculationStandardizationHandler.GetTR2TechnicalReport(serviceConnector, JobFiling, customTrace, feeObject);
                                    if (TR3s != null && TR3s.Entities.Count > 0)
                                    {
                                        Tr2Record = TR3s.Entities[0];
                                    }
                                    else
                                    {
                                        customTrace.AppendLine("No Tr2's found for jobfiling so return");
                                        return;

                                    }

                                   ConditionExpression Tr3condition = CreateConditionExpression(TR3MixEntityAttribute.GotoTRTechnicalreport, ConditionOperator.Equal, new string[] { Tr3Director.Id.ToString() });
                                    EntityCollection Tr3mixs = RetrieveMultiple(serviceConnector, TR3MixEntityAttribute.EntityLogicalName, new string[] { TR3MixEntityAttribute.EntityNameAttribute, TR3MixEntityAttribute.MixType, TR3MixEntityAttribute.SpecifiedStrength, TR3MixEntityAttribute.SpecifiedTestAge, TR3MixEntityAttribute.SequenceNumber }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                                    customTrace.AppendLine("Tr3mixs count : " + Tr3mixs.Entities.Count);
                                    
                                    foreach (Entity Tr3mix in Tr3mixs.Entities)
                                    {
                                        
                                        customTrace.AppendLine("Create Tr2Testreport start from tr3Director attesttation complete when jobfiling is permit entire");

                                        FeeCalculationStandardizationHandler.CreateTR2TestReport(serviceConnector, Tr3mix, Tr3Director, Tr2Record, customTrace);


                                    }

                                    if (JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntire)
                                    {
                                        #region Structural - TR2 New Test Results Added Email
                                        customTrace.AppendLine("Structural - TR2 New Test Results Added Email");
                                        Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "Structural - TR2 New Test Results Added Email").Id.ToString());
                                        customTrace.AppendLine("processId:  " + processId.ToString());
                                        ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);

                                        #endregion
                                    }
                                    if (JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReviewObjections)
                                    {
                                        #region Structural - BC/DBC Rejection Response Email
                                        customTrace.AppendLine("Structural - BC/DBC Rejection Response Email");
                                        Guid processId = new Guid(WorkFlowHandler.GetProcessId(serviceConnector, "workflow", "name", "Structural - BC/DBC Rejection Response Email").Id.ToString());
                                        customTrace.AppendLine("processId:  " + processId.ToString());
                                        ExecuteWorkflow(serviceConnector, processId, targetEntity.Id);
                                        #endregion
                                    }
                                }
                            }
                        }




                    }
                }



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixOnCreateAfterPermitEntire - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
