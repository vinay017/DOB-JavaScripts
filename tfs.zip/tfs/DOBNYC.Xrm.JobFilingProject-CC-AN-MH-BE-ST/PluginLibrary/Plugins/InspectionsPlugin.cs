﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class InspectionsPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            //string fetch = "";
            //string CreateCriteriaAttr = "dobnyc_createcriteria";
            //string DeleteCriteriaAttr = "dobnyc_deletecriteria";
            //Guid spid = new Guid();
            #endregion

            ///<summary>
            ///This Plugin is used to add or delete inspections based on list of conditions as part of Mechanical Project
            ///For list of conditions, please review the attachments or description in Task number : 15413
            ///
            ///1. Register Plugin Step on Update Message(Pre Operation) : dobnyc_jobfiling
            ///2. Filtering Attributes:dobnyc_ac_airconditioningsystem,dobnyc_an_directive14,dobnyc_gc_addinfoenlargement,dobnyc_filingstatustype,dobnyc_floodhazardarea,
            ///                         dobnyc_gc_heatingsystem,dobnyc_mh_iscertificatecomplaince,dobnyc_gc_openwebsteeljoists,dobnyc_gc_prefadwoodijoists,dobnyc_gc_stsuracturalcodlformed,dobnyc_an_structuralstabilityaffected,dobnyc_substantialimprovement,dobnyc_substaitiallydamaged,dobnyc_gc_ventilizationsystem
            ///3. PreImage: Name :PreImageJobFiling
            ///4. PreImage Parameters: dobnyc_ac_airconditioningsystem,dobnyc_an_directive14,dobnyc_gc_addinfoenlargement,dobnyc_filingstatustype,dobnyc_floodhazardarea,
            ///                         dobnyc_gc_heatingsystem,dobnyc_mh_iscertificatecomplaince,dobnyc_gc_openwebsteeljoists,dobnyc_gc_prefadwoodijoists,dobnyc_gc_stsuracturalcodlformed,dobnyc_an_structuralstabilityaffected,dobnyc_substantialimprovement,dobnyc_substaitiallydamaged,dobnyc_gc_ventilizationsystem
            /// </summary>

            try
            {

                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImageJobFiling"))
                    preTargetEntity = context.PreEntityImages["PreImageJobFiling"];

                if (context.PreEntityImages.Contains("PostImageJobFiling"))
                    postTargetEntity = context.PostEntityImages["PostImageJobFiling"];
                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 2)
                    return;
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;
                CommonPluginLibrary.Merge(targetEntity, preTargetEntity);
                #endregion

                #region Commented Out GCMHST
                //if (((targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType) == true))
                //   || ((targetEntity.Contains(JobFilingEntityAttributeName.MechanicalWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType) == true)) ||
                //   (targetEntity.Contains(JobFilingEntityAttributeName.StructuralWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralWorkType) == true))
                //{
                //    if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                //    {
                //        Entity JobFiling = serviceConnector.Retrieve("dobnyc_jobfiling", targetEntity.Id, new ColumnSet("dobnyc_filingstatustype", "dobnyc_jobfiling"));

                //        string fetchWorkTypes = string.Format(FetchXml.GetJobFilingRelatedWorkTypes, targetEntity.Id);
                //        EntityCollection collWorkTypes = serviceConnector.RetrieveMultiple(new FetchExpression(fetchWorkTypes));
                //        if (collWorkTypes.Entities.Count > 0)
                //        {
                //            StringBuilder sb = new StringBuilder();
                //            for (int i = 0; i <= collWorkTypes.Entities.Count - 1; i++)
                //            {
                //                sb.Append(" <condition attribute=\"dobnyc_worktype\" operator=\"like\" value=\"%" + collWorkTypes.Entities[i].Attributes["dobnyc_name"].ToString() + "%\"  " + "/>");
                //            }
                //            string fetchstr = string.Format(FetchXml.GetInspConfigurations, sb.ToString());
                //            EntityCollection coll = serviceConnector.RetrieveMultiple(new FetchExpression(fetchstr));
                //            customTrace.AppendLine("sb" + sb.ToString());

                //            if (coll.Entities.Count > 0)
                //            {
                //                for (int i = 0; i <= coll.Entities.Count-1; i++)
                //                {
                //                    #region Create Criteria Check
                //                    if (JobFilingFeeCalucaltionMultiStakeHandler.CompareMatchCriteria(coll[i], serviceConnector, targetEntity, customTrace, preTargetEntity, CreateCriteriaAttr))
                //                    {
                //                        #region Entity Attributes
                //                        Entity Inspection = new Entity(coll[i].Attributes["dobnyc_entitytocreate"].ToString());
                //                        string[] entityAttributes = coll[i].Attributes["dobnyc_entityattributestocreate"].ToString().Split(',');
                //                        for (int x = 0; x <= entityAttributes.Length - 1; x++)
                //                        {
                //                            Inspection.Attributes[entityAttributes[0]] = coll[i].Attributes["dobnyc_inspectioncomponentss"];
                //                            Inspection.Attributes[entityAttributes[1]] = new EntityReference("dobnyc_jobfiling", targetEntity.Id);
                //                            Entity InspectionComp = serviceConnector.Retrieve("dobnyc_specialinspectionscomponents", coll[i].GetAttributeValue<EntityReference>("dobnyc_inspectioncomponentss").Id, new ColumnSet("dobnyc_code"));
                //                            Inspection.Attributes[entityAttributes[2]] = JobFiling.Attributes["dobnyc_jobfiling"];
                //                            Inspection.Attributes[entityAttributes[3]] = InspectionComp.Attributes["dobnyc_code"];
                //                            Inspection.Attributes[entityAttributes[4]] = JobFiling.Attributes["dobnyc_filingstatustype"];
                //                            if (coll[i].Attributes["dobnyc_entitytocreate"].ToString() == "dobnyc_progressinspectioncategory")
                //                            {
                //                                if ((bool)coll[i].Attributes["dobnyc_isenergycode"] == false)
                //                                {
                //                                    Inspection.Attributes[entityAttributes[5]] = new OptionSetValue(1);
                //                                }
                //                                else
                //                                {
                //                                    Inspection.Attributes[entityAttributes[5]] = new OptionSetValue(2);
                //                                }
                //                            }

                //                        }
                //                        #endregion
                //                        spid = serviceConnector.Create(Inspection);
                //                    }
                //                    #endregion

                //                    #region Delete Criteria Check
                //                    else if (JobFilingFeeCalucaltionMultiStakeHandler.CompareMatchCriteria(coll[i], serviceConnector, targetEntity, customTrace, preTargetEntity, DeleteCriteriaAttr))
                //                    {
                //                        #region Fetch Inspectios
                //                        if (coll[i].Attributes["dobnyc_entitytocreate"].ToString() == "dobnyc_specialinspectioncategories")
                //                        {
                //                            fetch = string.Format(FetchXml.GetSpecialInspections, targetEntity.Id, ((EntityReference)coll[i].Attributes["dobnyc_inspectioncomponentss"]).Id.ToString());
                //                        }
                //                        if (coll[i].Attributes["dobnyc_entitytocreate"].ToString() == "dobnyc_progressinspectioncategory")
                //                        {
                //                            fetch = string.Format(FetchXml.GetProgressInspections, targetEntity.Id, ((EntityReference)coll[i].Attributes["dobnyc_inspectioncomponentss"]).Id.ToString());
                //                        }
                //                        #endregion
                //                        EntityCollection Speinsp = serviceConnector.RetrieveMultiple(new FetchExpression(fetch));
                //                        if (Speinsp.Entities.Count > 0)
                //                        {
                //                            for (int x = 0; x <= Speinsp.Entities.Count - 1; x++)
                //                            {
                //                                serviceConnector.Delete(coll[i].Attributes["dobnyc_entitytocreate"].ToString(), Speinsp[x].Id);
                //                            }
                //                        }
                //                    }
                //                    #endregion
                //                }
                //            }
                //        }
                //    }
                //}
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionsPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}

