﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using ExternalSystemIntegration;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginLibrary
{
    public class JobFilingAutoNumberGenerator : IPlugin
    {
        /// <summary>
        /// Plugin generates the Job and Filing Number
        /// </summary>


        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                //if (context.Depth > 1)
                //    return;
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);
                if (targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;

                customTrace.AppendLine("context.MessageName: " + PluginHelperStrings.UpdateMessageName);
                Entity preTargetEntity = new Entity();
                //if (context.MessageName == PluginHelperStrings.UpdateMessageName)


                //    if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                //    {
                //        preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                //        preTargetEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                //        CommonPluginLibrary.Merge(targetEntity, preTargetEntity);

                //    }

                //PW1 standardization changes: Start
                bool isHistoricFiling = false;
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                {
                    isHistoricFiling = true;
                }
                //PW1 standardization changes: End

                #region On Create
                if (context.MessageName == PluginHelperStrings.CreateMessageName && context.Stage == (int)ContextStage.Pre_operation)
                {
                    if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingNumberAttributeName) || !targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                    {

                        customTrace.AppendLine("Start Generating Auto Numbers: " + PluginHelperStrings.CreateMessageName);
                        targetEntity = JobNumberGenerator.GeneratejobFilingNumber(serviceConnector, context, targetEntity, customTrace);
                        customTrace.AppendLine("End Generating Auto Numbers: " + PluginHelperStrings.CreateMessageName);
                        //throw new Exception("Job number testing");
                    }
                    //PW1 standardization changes: Start
                    if (isHistoricFiling)
                    {
                        targetEntity = GCMHSTHandler.SetBPF_JobFiling(targetEntity, customTrace);
                    }
                    else
                    {
                        targetEntity = BEMSSTHandlerV2.SetBPF_JobFiling(targetEntity, customTrace);

                        customTrace.AppendLine("Setting Is PAA Submited to True.");
                        #region Update IsPAAinProgress in Initial Filing In case of PAA
                        if (targetEntity.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName) && (targetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName] != null))
                        {
                            customTrace.AppendLine("Start updating JobFilingEntityAttributeName.IsPAAinProgress in intial");
                            EntityReference parent_JF = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName);
                            customTrace.AppendLine("parent_JF Guid: " + parent_JF.Id);
                            Entity jf = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                            jf.Id = parent_JF.Id;
                            jf.Attributes[JobFilingEntityAttributeName.IsPAAinProgress] = true;
                            serviceConnector.Update(jf);
                            customTrace.AppendLine("End updating JobFilingEntityAttributeName.IsPAAinProgress in intial");
                        }
                        #endregion
                    }
                    //PW1 standardization changes: End
                }
                #endregion

                #region On Update - Pre_Operation
                if (context.MessageName == PluginHelperStrings.UpdateMessageName && context.Stage == (int)ContextStage.Pre_operation)
                {
                    if(context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) && context.PreEntityImages[PluginHelperStrings.PreImageName] is Entity)
                    {
                        preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                        customTrace.AppendLine("preTargetEntity Guid: " + preTargetEntity.Id);

                        #region Is Submitted Logic

                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) )
                        {
                            bool isSubmitted = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted);
                            customTrace.AppendLine("isSubmitted: " + isSubmitted.ToString());
                            bool previous_isSubmitted = preTargetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) ? preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) : false;
                            customTrace.AppendLine("previous_isSubmitted: " + previous_isSubmitted.ToString());
                            if (isSubmitted == true && isSubmitted != previous_isSubmitted)
                            {
                                customTrace.AppendLine("Start Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                                targetEntity = SubmitHandler.JobFilingSubmit(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                                //throw new Exception("Is Submitted Logic testing");
                            }
                        }

                        #endregion

                        #region GC PGL1
                        //if(targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType))
                        //{
                        //    #region PGL1
                        //    customTrace.AppendLine("Start GC PGL1");
                        //    PGL1Object pglObj = GCMHSTHandler.SetPGL1Object(targetEntity, preTargetEntity, customTrace);
                        //    string PGL1Desc = GCMHSTHandler.CalculatePGL1Insurance(targetEntity, pglObj, customTrace);
                        //    customTrace.AppendLine("PGL1Desc: " + PGL1Desc);
                        //    if (!string.IsNullOrEmpty(PGL1Desc))
                        //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PGL1Description, "Project Specific GL Insurance Required: " + PGL1Desc);
                        //    else
                        //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PGL1Description, "No PGL1 requirement");
                        //    customTrace.AppendLine("End GC PGL1");
                        //    #endregion

                        //}
                        //else
                        //{
                        //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PGL1Description, "");
                        //}

                        #endregion

                        #region PAA Job Filing

                        if (!preTargetEntity.Contains(JobFilingEntityAttributeName.EntityAttributeName) && !(context.Depth > 1))
                        {
                            if (!preTargetEntity.Contains(JobFilingEntityAttributeName.JobFilingNumAttribute))
                            {
                                customTrace.AppendLine("Start Generating Auto Numbers: " + PluginHelperStrings.UpdateMessageName);
                                targetEntity = JobNumberGenerator.GeneratejobFilingNumber(serviceConnector, context, targetEntity, customTrace);
                                customTrace.AppendLine("End Generating Auto Numbers: " + PluginHelperStrings.UpdateMessageName);
                            }
                            
                            #region Update IsPAAinProgress in Initial Filing In case of PAA
                            if(preTargetEntity.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName) && (preTargetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName] != null))
                            {
                                customTrace.AppendLine("Start updating JobFilingEntityAttributeName.IsPAAinProgress in intial");
                                EntityReference parent_JF = preTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName);
                                customTrace.AppendLine("parent_JF Guid: " + parent_JF.Id);
                                Entity jf = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                                jf.Id = parent_JF.Id;
                                jf.Attributes[JobFilingEntityAttributeName.IsPAAinProgress] = true;
                                serviceConnector.Update(jf);
                                customTrace.AppendLine("End updating JobFilingEntityAttributeName.IsPAAinProgress in intial");
                            }

                            #endregion

                            #region PAA Emails
                            if (targetEntity.Contains(JobFilingEntityAttributeName.JobFilingNumAttribute) && !preTargetEntity.Contains(JobFilingEntityAttributeName.JobFilingNumAttribute))
                            {
                                customTrace.AppendLine("Start PAA Design Professional Email: " + PluginHelperStrings.UpdateMessageName);
                                EmailHandler.DPEmail(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End PAA Design Professional Email: " + PluginHelperStrings.UpdateMessageName);

                                customTrace.AppendLine("Start PAA Owner Email: " + PluginHelperStrings.UpdateMessageName);
                                EmailHandler.OwnerEmail(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End PAA Owner Email: " + PluginHelperStrings.UpdateMessageName);

                                customTrace.AppendLine("Start PAA Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);
                                EmailHandler.FREmail(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End PAA Filing Representative Email: " + PluginHelperStrings.UpdateMessageName);

                                #region Progress Special Inspector Emails
                                customTrace.AppendLine("Start PAA Progress Special Inspector Emails: " + PluginHelperStrings.UpdateMessageName);
                                EmailHandler.PAA_PISI_Emails(serviceConnector, targetEntity, customTrace);
                                customTrace.AppendLine("End PAA Progress Special Inspector Emails: " + PluginHelperStrings.UpdateMessageName);

                                #endregion
                            }
                            #endregion
                            //throw new Exception("Job number testing");
                        }

                        #endregion

                        #region Plan Approved Date and LOC Kickoff Logic 2/11/16

                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus) && preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                        {
                            int currentFilingStatus = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                            customTrace.AppendLine("currentFiling Request Status:" + currentFilingStatus);
                            int prevoiusFilingStatus = ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                            customTrace.AppendLine("prevoiusFiling Request Status:" + prevoiusFilingStatus);

                            if (currentFilingStatus != prevoiusFilingStatus)
                            {
                               

                                if (currentFilingStatus == (int)CurrentFilingStatus.Approved || currentFilingStatus == (int)CurrentFilingStatus.UpdatedPermitIssued || currentFilingStatus == (int)CurrentFilingStatus.FilingUpdated)
                                {
                                    DateTime currentdate = DateTime.Now;
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PlanApprovedDate, currentdate.Date);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.IsPlanApproved, true);
                                }
                                if (currentFilingStatus == (int)CurrentFilingStatus.PermitIssued || currentFilingStatus == (int)CurrentFilingStatus.UpdatedPermitIssued || currentFilingStatus == (int)CurrentFilingStatus.PermitEntire)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.IsAfterPermitIssued, true);
                                }

                                if (currentFilingStatus == (int)CurrentFilingStatus.SignedOff)
                                {
                                    DateTime currentdate = DateTime.Now;
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SignoffDate, currentdate.Date);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.IsSignoffStageAttributeName, true);
                                }
                                #region Clear Adjustment and subtract adjustment from amount paid for incomplete,objections,QA failed
                                if (currentFilingStatus == (int)CurrentFilingStatus.Incomplete || currentFilingStatus == (int)CurrentFilingStatus.MinorMajorObjections || currentFilingStatus == (int)CurrentFilingStatus.QAFailed)
                                {
                                    customTrace.AppendLine("filing Status is incomplete,objections,qa failed");

                                    if (preTargetEntity.Contains(JobFilingEntityAttributeName.AdjustmentFinal) && preTargetEntity[JobFilingEntityAttributeName.AdjustmentFinal] != null && preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value > 0)
                                    {
                                        customTrace.AppendLine("adjustment is greater than zero");
                                        decimal adjustment = preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                                        customTrace.AppendLine("adjustment value" + adjustment);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(0));//clear the adjustment
                                        customTrace.AppendLine("clear the adjustment");
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money((preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value - adjustment)));//Subtract the adjustment from amount paid 
                                        customTrace.AppendLine("Subtract the adjustment from amount paid");
                                    }

                                }
                                #endregion
                                int FilingType = ((OptionSetValue)preTargetEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                                FeeCalculationObject feeObject = new FeeCalculationObject();
                                customTrace.AppendLine("set all the work type flags in fee object-start");
                                Entity getWorkTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity : preTargetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && preTargetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? preTargetEntity : targetEntity;
                                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(getWorkTypes, feeObject, customTrace);
                                customTrace.AppendLine("set all the work type flags in fee object-end");
                                if ((currentFilingStatus == (int)CurrentFilingStatus.Approved || currentFilingStatus == (int)CurrentFilingStatus.UpdatedPermitIssued || currentFilingStatus == (int)CurrentFilingStatus.AdditionalPermitIssued || currentFilingStatus == (int)CurrentFilingStatus.FilingUpdated || currentFilingStatus == (int)CurrentFilingStatus.PermitEntire || currentFilingStatus == (int)CurrentFilingStatus.PermitIssued) && FilingType == (int)FilingTypes.PA)
                                {
                                        customTrace.AppendLine("Start PAA Post Approval: " + PluginHelperStrings.UpdateMessageName);
                                        PAAHandler.PAAPostApproval(serviceConnector, targetEntity, customTrace, feeObject);
                                        customTrace.AppendLine("End PAA Post Approval: " + PluginHelperStrings.UpdateMessageName);                                       
                                }                               
                            }
                         }
                            
                        }
                        #endregion
                    }             
                #endregion
                // if Superseding Request Made
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupersedingRequestStatus))
                {
                    int supersedingStatus = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.SupersedingRequestStatus]).Value;
                    customTrace.AppendLine("Superseding Request Status:" + supersedingStatus);
                    // stop plugin when not required based on Superseding Request Status
                    if (supersedingStatus == (int)SupersedingStatus.Objections || supersedingStatus == (int)SupersedingStatus.PendingQAAssignment || supersedingStatus == (int)SupersedingStatus.QAReview)
                    {
                        customTrace.AppendLine("Superseding Request is not completed!!");
                        return;
                    }
                    if (supersedingStatus == (int)SupersedingStatus.SupersedingDesignProfessionalApproved)
                    {
                        customTrace.AppendLine("Start Superseding Request:" + PluginHelperStrings.UpdateMessageName);
                        PAAHandler.SupersedingDPPostApproval(serviceConnector, targetEntity, customTrace);
                        customTrace.AppendLine("End Superseding Request:" + PluginHelperStrings.UpdateMessageName);
                    }
                }

                // //New Property Profile Logic for Changing Address and not creating Duplicate Property Profiles in System
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN) && context.MessageName == PluginHelperStrings.CreateMessageName)
                //{
                //    customTrace.AppendLine("Start BIS integration: " + PluginHelperStrings.CreateMessageName);
                //    targetEntity = BISIntegrationHandler.AssociatePropertyProfile(serviceConnector, targetEntity, customTrace);
                //    customTrace.AppendLine("End BIS integration: " + PluginHelperStrings.CreateMessageName);
                    
                //}
                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingAutoNumberGenerator - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }



    }
}
