﻿using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using System;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WaiverDeferralLOCPostSubmit : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;

            try
            {
                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("End GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                if (targetEntity.LogicalName.ToLower() == LOCPW7EntityAttributeName.EntityLogicalName.ToLower()
                    && context.MessageName.ToLower() == PluginHelperStrings.UpdateMessageName.ToLower()
                    && context.Stage == (int)ContextStage.Post_operation)
                {
                    customTrace.AppendLine("Waiver deferral LOC post submit");
                    if (targetEntity.Contains(LOCPW7EntityAttributeName.IsSubmitted))
                    {
                        Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                        if (targetEntity.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted) && !preTargetEntity.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted))
                        {
                            customTrace.AppendLine("retrieve job filing");
                            Entity jobfiling = serviceConnector.Retrieve(
                                JobFilingEntityAttributeName.EntityLogicalName,
                                preTargetEntity.GetAttributeValue<EntityReference>(LOCPW7EntityAttributeName.GotoJobFiling).Id,
                                new ColumnSet(true)
                                );
                            customTrace.AppendLine("Waiver deferral: begin");
                            WaiverDeferralHandler.CreateTasks(serviceConnector, jobfiling, customTrace, false, new EntityReference(LOCPW7EntityAttributeName.EntityLogicalName, targetEntity.Id));
                            customTrace.AppendLine("Waiver deferral: end");
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralLOCPostSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}