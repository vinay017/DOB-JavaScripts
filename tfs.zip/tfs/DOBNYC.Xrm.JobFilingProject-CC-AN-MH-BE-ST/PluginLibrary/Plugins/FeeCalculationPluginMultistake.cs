﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using System.Linq;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class FeeCalculationPluginMultistake : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            #region Variables
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            Entity targetEntity = null;
            #endregion

            ///<summary>
            ///1. Register Plugin Step on Update Message(Pre Operation) : dobnyc_jobfiling
            ///2. Filtering Attributes:dobnyc_buildingtype,dobnyc_estimatedjobcost,dobnyc_gc_generalconstruction,dobnyc_isjobsubmitted,dobnyc_ms_jobalterationtype,
            ///                         dobnyc_gc_mechanical,dobnyc_nogoodcheck,dobnyc_proposedbuildingstories,dobnyc_totalconstructionfloorarea,dobnyc_tpa_tpaworktype,dobnyc_pa_paworktype,dobnyc_filingfees,dobnyc_paafee
            ///3. PreImage: Name :PreImageJobFiling
            ///4. PreImage Parameters: dobnyc_amountdue,dobnyc_amountpaid,dobnyc_buildingtype,dobnyc_estimatedjobcost,dobnyc_failedpaymenthistoryguid,dobnyc_filingfees,
            ///                         dobnyc_currentfilingstatus,dobnyc_filingstatustype,dobnyc_gc_generalconstruction,dobnyc_inconjunctionfee,dobnyc_isconjunctionjob,
            ///                         dobnyc_isfeeexempt,dobnyc_isjobsubmitted,dobnyc_ms_jobalterationtype,dobnyc_projectnumber,dobnyc_jobtype,dobnyc_legalizationfilingfee,
            ///                         dobnyc_gc_mechanical,dobnyc_newowrkfilingfee,dobnyc_nogoodcheckfeefine,dobnyc_nogoodcheck,dobnyc_paafee,dobnyc_parentjobfiling,
            ///                         dobnyc_phguid,dobnyc_pl_plumbing,dobnyc_plplumbinglegalization,dobnyc_proposedbuildingstories,dobnyc_recordmanagementfee,
            ///                         dobnyc_refund,dobnyc_sdstsndpipe,dobnyc_spsprinkler,dobnyc_spsprinklerlegalization,dobnyc_adjustmenttemporary,dobnyc_totalconstructionfloorarea
            /// </summary>

            try
            {
                #region Initialise Plugin
                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (targetEntity == null || targetEntity.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;
                customTrace.AppendLine("Begin: targetEntity.LogicalName.");
                //return if plugin's entering infinite loop 
                // which could be possible in this case as the same entity is being updated at 3 different instances in the Fee Calc Handler

                Entity preTargetEntity = new Entity();
                Entity postTargetEntity = new Entity();
                customTrace.AppendLine("Begin: PreImageJobFiling.");
                if (context.PreEntityImages.Contains("PreImageJobFiling"))
                    preTargetEntity = context.PreEntityImages["PreImageJobFiling"];

                if (context.PreEntityImages.Contains("PostImageJobFiling"))
                    postTargetEntity = context.PostEntityImages["PostImageJobFiling"];
                customTrace.AppendLine("Begin: PostImageJobFiling.");
                if (context.Depth > 2)
                    return;
                //return if target entity has process and stageid
                if (context.MessageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper() && (targetEntity.Contains("stageid") || targetEntity.Contains("processid")))
                    return;

                #endregion
                
                // Condition to check if plugin has to gun of selected work type.
                #region GC/MH/ST/PL/SP/SD/PA/TPA
                if (JobFilingFeeCalucaltionMultiStakeHandler.IsWorkTypeEligible(preTargetEntity, targetEntity, customTrace))
                {
                    #region Pre Update Message
                    if (context.MessageName == PluginHelperStrings.UpdateMessageName)
                    {
                        #region Fee Calculations-New Building/Alteration(Big/Major/Minor)-GC/MH/ST/PL/SP/SD/PA/TPA
                        if (JobFilingFeeCalucaltionMultiStakeHandler.IsFeeNeedToCalculate(serviceConnector,context, preTargetEntity, targetEntity, customTrace, context.SharedVariables))
                        {
                            #region New Building Calculations
                            customTrace.AppendLine("Begin: fee calculation New Logic.");
                            JobFilingFeeCalucaltionMultiStakeHandler.CalculateFeeMultiStake(serviceConnector, customTrace, targetEntity, preTargetEntity, context.SharedVariables);
                            customTrace.AppendLine("End: fee calculation New Logic");
                            #endregion

                            #region New Building PostFeeCalculationUpdates
                            customTrace.AppendLine("Begin: PostCreateFeeUpdates New Logic.");
                            JobFilingFeeCalucaltionMultiStakeHandler.PostFeeCalculationUpdates(serviceConnector, customTrace, targetEntity, preTargetEntity, context.SharedVariables);
                            customTrace.AppendLine("End: PostCreateFeeUpdates New Logic");
                            #endregion
                        }
                        #endregion

                        #region Job Submitted
                        if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted))
                        {
                            customTrace.AppendLine("Start: IsJobSubmitted New Buildings");
                            if ((preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true))
                            {
                                JobFilingFeeCalucaltionMultiStakeHandler.MergeAttributes(preTargetEntity, targetEntity, customTrace);
                                JobFilingFeeCalucaltionMultiStakeHandler.IsFilingSubmitted(serviceConnector, preTargetEntity, targetEntity, customTrace, context.SharedVariables);
                            }
                            customTrace.AppendLine("End: IsJobSubmitted New Buildings");
                        }
                        #endregion
                    }
                    #endregion
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationPluginMultistake - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

    }
}
