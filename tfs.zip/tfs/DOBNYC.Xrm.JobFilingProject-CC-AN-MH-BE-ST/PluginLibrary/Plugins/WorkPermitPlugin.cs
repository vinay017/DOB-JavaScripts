﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WorkPermitPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            
            try
            {

                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
               customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                Entity preImage = new Entity();

                if (context.PreEntityImages.Contains("PreImage"))
                    preImage = context.PreEntityImages["PreImage"];

                if (context.MessageName.ToUpper() == "CREATE")
                {
                    if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges) || (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges)))
                    {

                        customTrace.AppendLine("Permit Renewal Started:" + PluginHelperStrings.CreateMessageName);
                        WorkPermitHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                        customTrace.AppendLine("Permit Renewal end:" + PluginHelperStrings.CreateMessageName);
                    }
                }



                //Calculate total cost and update
                if (context.MessageName.ToUpper() == "UPDATE")
                {
                    if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges))
                    {
                        customTrace.AppendLine("If there is no change in renewalpermit without changes - start");
                        if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges) == true && targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges) == true)
                        {
                            customTrace.AppendLine("If there is no change in renewalpermit without changes - End");
                            return;
                        }

                    }

                    if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges))
                    {
                        customTrace.AppendLine("If there is no change in renewalpermit with changes - start");
                        if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges) == true && targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges) == true)
                        {
                            customTrace.AppendLine("If there is no change in renewalpermit with changes - end");
                            return;
                        }
                    }

                    if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges) || (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges)))
                    {
                        preImage.Attributes.Remove(WorkPermitEntityAttributeName.WorkPermitStatus);
                        CommonPluginLibrary.Merge(targetEntity, preImage);
                        customTrace.AppendLine("Permit Renewal Started:" + PluginHelperStrings.UpdateMessageName);
                        WorkPermitHandler.CalculateFee(serviceConnector, targetEntity, customTrace, context.MessageName.ToUpper(), preImage);
                        customTrace.AppendLine("Permit Renewal Started:" + PluginHelperStrings.UpdateMessageName);
                    }
                }

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
