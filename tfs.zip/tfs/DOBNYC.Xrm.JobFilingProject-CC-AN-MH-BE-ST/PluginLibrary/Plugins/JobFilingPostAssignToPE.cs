﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class JobFilingPostAssignToPE : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            IPluginExecutionContext context = null;
            EntityReference targetEntityRef = null;

            try
            {
                

                customTrace.AppendLine("Begin: Get context..");
                context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetEntityFromContext..");
                if (context.InputParameters.Contains("Target") &&
                     context.InputParameters["Target"] is EntityReference)
                {
                    targetEntityRef = (EntityReference)context.InputParameters["Target"];
                }
                customTrace.AppendLine("End GetEntityFromContext..");

                customTrace.AppendLine("Target Entity: " + targetEntityRef.LogicalName);

                if (targetEntityRef == null || targetEntityRef.LogicalName != JobFilingEntityAttributeName.EntityLogicalName)
                    return;

                Entity postTargetEntity = (Entity)context.PostEntityImages["PostImage"];

                //Check if context contains the "Assignee" parameter
                if (context.InputParameters.Contains("Assignee"))
                {                    
                    EntityReference assigneeRef = (EntityReference)context.InputParameters["Assignee"];
                    customTrace.AppendLine("Assignee:" + assigneeRef.Id);
                    //customTrace.AppendLine("asfcasdfAssignee:" + postTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlanExaminerAttributeName).Id);
                    //customTrace.AppendLine("asfcasdfAssignee:" + postTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam).Id);
                    //assigneeRef.Id == postTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlanExaminerAttributeName).Id
                    //Check if job filing is assigned to "assigned plan examiner"
                    if ((postTargetEntity.Contains(JobFilingEntityAttributeName.PlanExaminerAttributeName) && assigneeRef.Id == postTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlanExaminerAttributeName).Id))
                    {
                        customTrace.AppendLine("Begin WaiverDeferralHandler.CreateTasks..");
                        //Call Waiver Deferral Task Creation Handler
                        WaiverDeferralHandler.CreateTasks(serviceConnector, postTargetEntity, customTrace, true, null);
                        customTrace.AppendLine("End WaiverDeferralHandler.CreateTasks..");
                    }
                    if ((postTargetEntity.Contains(JobFilingEntityAttributeName.ParentTeam) && assigneeRef.Id == postTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam).Id))
                    {
                        customTrace.AppendLine("Begin WaiverDeferralHandler.CreateTasks..");
                        //Call Waiver Deferral Task Creation Handler
                        WaiverDeferralHandler.CreateTasks(serviceConnector, postTargetEntity, customTrace, false, null);
                        customTrace.AppendLine("End WaiverDeferralHandler.CreateTasks..");
                    }
                }

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "JobFilingPostAssignToPE - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
