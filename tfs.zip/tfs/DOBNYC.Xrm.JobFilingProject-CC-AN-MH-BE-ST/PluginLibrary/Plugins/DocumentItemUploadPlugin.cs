﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class DocumentItemUploadPlugin: IPlugin
    {
        /// <summary>
        /// Plugin generates the Required item list
        /// Register on Job Filing - Pre Operation Update with PreImage
        /// Register on dobnyc_scheduleofbuildingsystemsdevices - Post Operation Create
        /// Register on dobnyc_progressinspectioncategory - Post Operation Create
        /// Register on dobnyc_scheduleofbuildingsystemsdevices - Post Operation Update with PreImage
        /// Register on DSI - Post Operation Update with PreImage
        /// </summary>

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            StringBuilder customTrace = new StringBuilder();
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);

                customTrace.AppendLine("End GetEntityFromContext..");
                if (context.Depth > 1)
                    return;

                customTrace.AppendLine("End GetEntityFromContext..");
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                
                #region Job Filing Entity
                if (context.MessageName == PluginHelperStrings.UpdateMessageName && targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    Entity preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                    //PW1 Standardization: Is Historic JobFiling Check - Start
                    bool IsHistoricJobFiling = false;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                    {
                        IsHistoricJobFiling = true;
                        customTrace.AppendLine("Historic Filing");
                    }
                    else if (preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && preTargetEntity[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
                    {
                        IsHistoricJobFiling = true;
                        customTrace.AppendLine("Historic Filing");
                    }
                    //PW1 Standardization: Is Historic JobFiling Check - End

                    if ( targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                    {
                        int FilingType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                        if (FilingType == (int)FilingTypes.IF || FilingType == (int)FilingTypes.SF || FilingType == (int)FilingTypes.PA)
                        {
                            if (IsHistoricJobFiling)
                            {
                                Task<bool> CreateDocs = DocumentItemUploadHandler.CreateRequiredItemstoJobFiling(serviceConnector, targetEntity, preTargetEntity, customTrace, context); // calling the Handler for DocumentItemUpload
                            }
                                
                        }

                    }
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN))
                    {
                        string currentBIN = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString();
                        customTrace.AppendLine("currentBIN: " + currentBIN);
                        string previousBIN = preTargetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString();
                        customTrace.AppendLine("previousBIN: " + previousBIN);
                        if (currentBIN != previousBIN)
                        {
                            customTrace.AppendLine("Start BIS integration: " + PluginHelperStrings.CreateMessageName);
                            DocumentItemUploadHandler.DeleteRequiredItemstoJobFiling_PropertyProfile(serviceConnector, targetEntity, customTrace, context);
                            customTrace.AppendLine("DeleteRequiredItemstoJobFiling_PropertyProfile Done ");
                            targetEntity = BISIntegrationHandler.AssociatePropertyProfile(serviceConnector, targetEntity, false, customTrace);
                            customTrace.AppendLine("End BIS integration: " + PluginHelperStrings.CreateMessageName);
                        }
                    }
                }

                #endregion

                #region On Create Context
                if (context.MessageName == PluginHelperStrings.CreateMessageName)
                {
                    // Register Plugin on Create of the following entities
                    #region Scope of Work Documents  
                    if (targetEntity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName)
                    {
                        DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_ScopeofWorkCreate(serviceConnector, targetEntity, customTrace, context);
                    }
                    #endregion

                    #region ProgressInpection Documents
                    if (targetEntity.LogicalName == ProgressInspectionCategoryEntityAttributeName.EntityLogicalName)
                    {
                        DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_ProgressInspection2(serviceConnector, targetEntity, customTrace, context);
                    }
                    #endregion

                  
                }
                #endregion

                #region On Update Conext
                if(context.MessageName == PluginHelperStrings.UpdateMessageName)
                {
                    #region Scope of Work Documents  
                    if (targetEntity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName)
                    {
                        if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) && context.PreEntityImages[PluginHelperStrings.PreImageName] is Entity)
                        {
                            Entity preImage = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                            DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_ScopeofWorkUpdate(serviceConnector, targetEntity, preImage, customTrace, context);
                        }
                    }
                    #endregion

                    #region DS1 Documents  
                    if (targetEntity.LogicalName == AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName)
                    {
                        if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) && context.PreEntityImages[PluginHelperStrings.PreImageName] is Entity)
                        {
                            Entity preImage = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                            DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_DS1Update(serviceConnector, targetEntity, preImage, customTrace, context);
                        }
                    }
                    #endregion

                }
                #endregion

                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", null, customTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
