﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class WaiverDeferralTaskSubmit : IPlugin
    {
        IOrganizationServiceConnector serviceConnector;
        StringBuilder customTrace = new StringBuilder();
        Entity jobFiling = null;
        Entity task = null;
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            string currentCrmUserId = String.Empty;
            Entity targetEntity = null;
            try
            {
                //crmTracing.Trace("");
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                customTrace.AppendLine("End GetEntityFromContext..");

                Entity postTargetEntity = PluginHandlerBase.Retrieve(
                    serviceConnector,
                    new string[] { TaskEntityAttributeNames.TaskForm, TaskEntityAttributeNames.IsJobApplicationApproved, TaskEntityAttributeNames.ClickheretogotoJobFiling },
                    targetEntity.Id,
                    TaskEntityAttributeNames.EntityLogicalName);
                customTrace.AppendLine("postTargetEntity id " + postTargetEntity.Id.ToString());
                if (targetEntity.LogicalName.ToLower() == TaskEntityAttributeNames.EntityLogicalName.ToLower()
                    && context.MessageName.ToLower() == PluginHelperStrings.UpdateMessageName.ToLower())
                    //&& )
                {
                    customTrace.AppendLine("task state update");

                    #region waiver deferral task submit
                    if (postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.TaskForm) != null &&
                        postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.TaskForm).Value == 10 &&
                        targetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.StatusFieldName) != null &&
                        targetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.StatusFieldName).Value == TaskEntitySatus.Completed)
                    {
                        customTrace.AppendLine("Waiver deferral task submit begin");
                        WaiverDeferralHandler.SubmitTask(serviceConnector, new EntityReference(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id), customTrace);
                        customTrace.AppendLine("Waiver deferral task submit end");
                    }
                    #endregion

                    #region pe task objection submit
                    //if (postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.TaskForm) != null &&
                    //    postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.TaskForm).Value == 2 &&
                    //    postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.IsJobApplicationApproved) != null &&
                    //    postTargetEntity.GetAttributeValue<OptionSetValue>(TaskEntityAttributeNames.IsJobApplicationApproved).Value == 625470001)//PE objections
                    //{
                    //    return;
                    //    customTrace.AppendLine("waiver task for cpe");
                    //    //retrieve document list
                    //    ConditionExpression documentListCondition = new ConditionExpression(
                    //        DocumentListEntityAttributeName.DocumentListtoJobfiling,
                    //        ConditionOperator.Equal,
                    //        postTargetEntity.GetAttributeValue<EntityReference>(TaskEntityAttributeNames.ClickheretogotoJobFiling).Id);
                    //    ConditionExpression waiverStatus = new ConditionExpression(DocumentListEntityAttributeName.DocumentStatus, ConditionOperator.In, new int[] { 6, 7 });
                    //    ConditionExpression waiverRequested = new ConditionExpression(DocumentListEntityAttributeName.WaiverRequested, ConditionOperator.Equal, false);
                    //    ConditionExpression isSubmitted = new ConditionExpression(DocumentListEntityAttributeName.IsSubmitted, ConditionOperator.Equal, false);
                    //    QueryExpression query = new QueryExpression(DocumentListEntityAttributeName.EntityLogicalName);
                    //    query.ColumnSet = new ColumnSet(DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.Comments);
                    //    query.Criteria.FilterOperator = LogicalOperator.And;
                    //    query.Criteria.AddCondition(documentListCondition);
                    //    query.Criteria.AddCondition(waiverStatus);
                    //    query.Criteria.AddCondition(waiverRequested);
                    //    query.Criteria.AddCondition(isSubmitted);
                    //    EntityCollection documentListResponse = serviceConnector.RetrieveMultiple(query);
                    //    if (documentListResponse.Entities.Count > 0)
                    //    {
                    //        jobFiling = PluginHandlerBase.Retrieve(
                    //                            serviceConnector,
                    //                            new string[] {
                    //                                JobFilingEntityAttributeName.JobNumberAttributeName,
                    //                                JobFilingEntityAttributeName.FilingNumberAttributeName ,
                    //                                JobFilingEntityAttributeName.CurrentFilingStatusAttributeName,
                    //                                JobFilingEntityAttributeName.PropertProfileId,
                    //                                JobFilingEntityAttributeName.Street,
                    //                                JobFilingEntityAttributeName.HouseNumber
                    //                            },
                    //                            postTargetEntity.GetAttributeValue<EntityReference>(TaskEntityAttributeNames.ClickheretogotoJobFiling).Id,
                    //                            JobFilingEntityAttributeName.EntityLogicalName);
                    //    }
                        
                    //    foreach (Entity document in documentListResponse.Entities)
                    //    {
                    //        //throw new Exception(documentListResponse.Entities.Count.ToString());
                    //        CreateWaiverDeferralRequest(ref task, document, FetchTeamRef(TeamNames.TeamChiefPlanExaminer), "Chief Plan Examiner");
                    //    }
                    //}
                    #endregion
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        private void CreateWaiverDeferralRequest(ref Entity task, Entity document, EntityReference assignee, string roleName)
        {
            try
            {
                if (task == null)
                {
                    CreateTask(assignee, roleName);
                }
                Entity tempRequest = new Entity(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
                    tempRequest[WaiverDeferralRequestEntityAttributeName.Name] = string.Format("{0} Waiver Request for Job# {1} Filing# {2}",
                    roleName,
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName),
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName));
                    tempRequest[WaiverDeferralRequestEntityAttributeName.Type] = new OptionSetValue((int)WaiverDeferralType.Waiver);
                tempRequest[WaiverDeferralRequestEntityAttributeName.DocumentListId] = new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, document.Id);
                tempRequest[WaiverDeferralRequestEntityAttributeName.TaskId] = new EntityReference(TaskEntityAttributeNames.EntityLogicalName, task.Id);
                tempRequest[WaiverDeferralRequestEntityAttributeName.RequestorComments] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.Comments);
                Guid requestId = serviceConnector.Create(tempRequest);

                //Create association in self relationship for history
                AssociateWithPastRequests(document.Id, requestId);

                //Update Document List Status
                Entity doc = new Entity(document.LogicalName);
                doc.Id = document.Id;
                //doc[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue(9);
                doc[DocumentListEntityAttributeName.IsSubmitted] = true;
                doc[DocumentListEntityAttributeName.WaiverRequested] = true;
                UpdateDocumentList(doc);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateWaiverDeferralRequest", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        private void AssociateWithPastRequests(Guid documentId, Guid currentRequestId)
        {
            try
            {
                QueryExpression query = new QueryExpression(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
                query.ColumnSet = new ColumnSet(new string[] { WaiverDeferralRequestEntityAttributeName.DocumentListId });
                query.Criteria = new FilterExpression(LogicalOperator.And);
                query.Criteria.AddCondition(WaiverDeferralRequestEntityAttributeName.DocumentListId, ConditionOperator.Equal, documentId);
                query.Criteria.AddCondition(WaiverDeferralRequestEntityAttributeName.WaiverDeferralRequestId, ConditionOperator.NotEqual, currentRequestId);
                EntityCollection requests = serviceConnector.RetrieveMultiple(query);

                if (requests.Entities.Count == 0) return;

                EntityReferenceCollection pastRequests = new EntityReferenceCollection();

                foreach (Entity request in requests.Entities)
                {
                    pastRequests.Add(new EntityReference(WaiverDeferralRequestEntityAttributeName.EntityLogicalName, request.Id));
                }

                AssociateRequest assocReq = new AssociateRequest();
                assocReq.Relationship = new Relationship("dobnyc_dobnyc_waiverdeferraltaskintersect_dobnyc");
                assocReq.Relationship.PrimaryEntityRole = EntityRole.Referencing;
                assocReq.Target = new EntityReference(WaiverDeferralRequestEntityAttributeName.EntityLogicalName, currentRequestId);
                assocReq.RelatedEntities = pastRequests;
                serviceConnector.Execute(assocReq);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - AssociateWithPastRequests", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - AssociateWithPastRequests", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        private void CreateTask(EntityReference assignee, string roleName)
        {
            task = new Entity(TaskEntityAttributeNames.EntityLogicalName);
            try
            {
                string taskSubject = string.Format("{0} Document Waiver Request Task form for Job# {1} Filing# {2}",
                    roleName,
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName),
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName));
                
                task[TaskEntityAttributeNames.ClickheretogotoJobFiling] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFiling.Id);
                task[TaskEntityAttributeNames.RegardingObjectId] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFiling.Id);
                task[TaskEntityAttributeNames.Subject] = taskSubject;
                task[TaskEntityAttributeNames.TaskForm] = new OptionSetValue(10);// waiver deferral task form
                task[TaskEntityAttributeNames.OwnerId] = assignee;
                task[TaskEntityAttributeNames.JobNumber] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                task[TaskEntityAttributeNames.FilingNumber] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                task[TaskEntityAttributeNames.CurrentFilingStatus] = jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName);
                task[TaskEntityAttributeNames.Address] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber) + ", " + jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.Street);
                task[TaskEntityAttributeNames.PropertyProfile] = jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PropertProfileId);
                task.Id = serviceConnector.Create(task);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateTask", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - CreateTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }          
        }
        private void UpdateDocumentList(Entity documentList)
        {
            try
            {
                serviceConnector.Update(documentList);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - UpdateDocumentList", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - UpdateDocumentList", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - UpdateDocumentList", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - UpdateDocumentList", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        private EntityReference FetchTeamRef(string name)
        {
            EntityReference teamRef = null;
            try
            {
                QueryByAttribute query = new QueryByAttribute(TeamEntityAttributeNames.EntityLogicalName);
                query.AddAttributeValue(TeamEntityAttributeNames.NameFieldName, name);
                query.ColumnSet = new ColumnSet(new string[] { TeamEntityAttributeNames.TeamIdByFieldName, TeamEntityAttributeNames.NameFieldName });
                EntityCollection results = serviceConnector.RetrieveMultiple(query);
                if (results.Entities.Count == 1)
                {
                    teamRef = new EntityReference(TeamEntityAttributeNames.EntityLogicalName, results.Entities[0].Id);
                }
                else
                {
                    throw new Exception(string.Format("Team with name {0} not found", name));
                }
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - FetchTeamRef", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralTaskSubmit - FetchTeamRef", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            return teamRef;
        }
    }
}
