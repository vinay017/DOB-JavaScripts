﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersPATPARelatedEntities;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.Plugins
{
    public class PlaceOfAssemblyProfcertAuditPlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService crmTracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            StringBuilder customTrace = new StringBuilder();
            Entity targetEntity = null;
            customTrace.AppendLine("PlaceOfAssembly Procert AuditPlugin start...");
            string currentCrmUserId = String.Empty;
            try
            {
                customTrace.AppendLine("Begin: Get context..");
                IPluginExecutionContext context = CommonPluginLibrary.GetContextFromIServiceProvider(serviceProvider);
                customTrace.AppendLine("End: Get context.. Depth: " + context.Depth.ToString());
                currentCrmUserId = context.UserId.ToString();
                customTrace.AppendLine("Current User: " + currentCrmUserId);
                customTrace.AppendLine("Begin GetServiceConnector..");
                IOrganizationServiceConnector serviceConnector = new IOrganizationServiceConnector(serviceProvider, context, ICrmServiceCredentialType.ImpersonatedUser);
                customTrace.AppendLine("Begin GetServiceConnector..");
                customTrace.AppendLine("Begin GetEntityFromContext..");
                targetEntity = CommonPluginLibrary.GetEntityFromContext(context);
                if (targetEntity == null)
                    return;
                if (!targetEntity.LogicalName.Equals(JobFilingEntityAttributeName.EntityLogicalName))
                    return;

                customTrace.AppendLine("context.MessageName: " + PluginHelperStrings.UpdateMessageName);
                Entity preTargetEntity = new Entity();
                customTrace.AppendLine("Target Entity: " + targetEntity.LogicalName);

                if (context.MessageName == PluginHelperStrings.UpdateMessageName && context.Stage == (int)ContextStage.Post_operation)
                {
                    if (context.PreEntityImages.Contains(PluginHelperStrings.PreImageName) && context.PreEntityImages[PluginHelperStrings.PreImageName] is Entity)
                    {
                        preTargetEntity = (Entity)context.PreEntityImages[PluginHelperStrings.PreImageName];
                        customTrace.AppendLine("preTargetEntity Guid: " + preTargetEntity.Id);

                        #region Is Submitted Logic
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted))
                        {
                            bool isSubmitted = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted);
                            customTrace.AppendLine("isSubmitted: " + isSubmitted.ToString());
                            bool previous_isSubmitted = preTargetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) ? preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) : false;
                            customTrace.AppendLine("previous_isSubmitted: " + previous_isSubmitted.ToString());
                            if (isSubmitted == true && isSubmitted != previous_isSubmitted)
                            {
                                customTrace.AppendLine("Start Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);
                                targetEntity = PATPAHandler.PAProfCertJobFilingSubmit(serviceConnector, targetEntity, preTargetEntity, customTrace);
                                customTrace.AppendLine("End Is Submitted Logic: " + PluginHelperStrings.UpdateMessageName);

                            }
                        }

                        #endregion
                    }
                }
           // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, " PlaceOfAssemblyProcertAuditPlugin plugin", null, customTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PlaceOfAssemblyProcertAuditPlugin - Execute", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
