﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class InspectionComponentsAutoPopulationHandler : PluginHandlerBase
    {
        #region Populate Inspections based on PW1 triggers
        public static void PopulateInspectionComponents(IOrganizationService service, Entity targetEntity, int filingType, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("PopulateInspectionComponents: Start");
            try
            {
                crmTrace.AppendLine("WorkType: " + targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox));
                //string[] workTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                string[] strWorkTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                List<string> workTypes = new List<string>(strWorkTypes);
                if (workTypes.Count == 0)
                {
                    string fetch = string.Format(FetchXml.GetAssociatedWorkTypes, targetEntity.Id.ToString());
                    crmTrace.AppendLine("fetch: " + fetch);
                    EntityCollection wt_response = service.RetrieveMultiple(new FetchExpression(fetch));
                    if (wt_response != null && wt_response.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                        foreach (Entity wt in wt_response.Entities)
                        {
                            string wt_ConfigName = wt.GetAttributeValue<string>(AssociatedWorkTypesEntityAttributeName.Name);
                            crmTrace.AppendLine("wt_ConfigName: " + wt_ConfigName);
                            workTypes.Add(wt_ConfigName);

                        }
                    }
                }
                if (workTypes.Count > 0)
                {
                    foreach (string workType in workTypes)
                    {
                        //Fetch Inspection Component configuration recors with document requirement as "Conditional"
                        string configXML = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='dobnyc_specialinspectionscomponents'>
                                                    <attribute name='dobnyc_specialinspectionscomponentsid' />
                                                    <attribute name='dobnyc_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='dobnyc_worktype' />
                                                    <attribute name='dobnyc_inspectiontype' />
                                                    <attribute name='dobnyc_inspectioncode' />
                                                    <attribute name='dobnyc_documentrequirement' />
                                                    <attribute name='dobnyc_conditionxml' />
                                                    <attribute name='dobnyc_code' />
                                                    <order attribute='dobnyc_name' descending='false' />
                                                    <filter type='and'>
                                                      <filter type='and'>
                                                        <condition attribute='dobnyc_documentrequirement' operator='in'>
                                                            <value>1</value>
                                                            <value>4</value>
                                                            <value>5</value>
                                                            <value>6</value>                                                            
                                                        </condition>
                                                        <condition attribute='statecode' operator='eq' value='0' />
                                                        <condition attribute='dobnyc_worktype' operator='like' value='%{0}%' />
                                                      </filter>
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                        crmTrace.AppendLine("configXML: " + configXML);
                        string adjusted_WorkType = workType;
                        if (workType.Contains("_"))
                            adjusted_WorkType = workType.Split('_')[0];
                        crmTrace.AppendLine("adjusted_WorkType : " + adjusted_WorkType);
                        EntityCollection inspectionsResult = service.RetrieveMultiple(new FetchExpression(string.Format(configXML, adjusted_WorkType)));
                        crmTrace.AppendLine("InspectionsResult Count: " + inspectionsResult.Entities.Count.ToString());

                        if (inspectionsResult.Entities != null && inspectionsResult.Entities.Count > 0)
                        {
                            foreach (Entity inspectionRecord in inspectionsResult.Entities)
                            {
                                int inspectionType = inspectionRecord.GetAttributeValue<OptionSetValue>(InspectionsComponentsEntityAttributeName.InspectionType).Value;
                                crmTrace.AppendLine("inspectionType: " + inspectionType.ToString());
                                string documentName = inspectionRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);
                                crmTrace.AppendLine("Inspection Document: " + documentName);

                                switch (inspectionType)
                                {
                                    case 1: //Special Inspection
                                        AddSpecialInspectionDocument(service, targetEntity, inspectionRecord, filingType, crmTrace);
                                        break;
                                    case 2: // Energy Code Progress Inspection                                        
                                    case 3: //Progress Inspection
                                        AddProgressInspectionDocument(service, targetEntity, inspectionRecord, filingType, crmTrace);
                                        break;
                                    default:
                                        crmTrace.AppendLine("Inspection Type not found in the configuration.");
                                        break;
                                }
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("No conditional inspection configurations found.");
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("Work type not populated.");
                    return;
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateInspectionComponents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AddProgressInspectionDocument(IOrganizationService service, Entity targetEntity, Entity configRecord, int filingType, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("AddProgressInspectionDocument: Start");
            try
            {
                if (configRecord.Attributes.Contains(InspectionsComponentsEntityAttributeName.ConditionXML) && configRecord[InspectionsComponentsEntityAttributeName.ConditionXML] != null)
                {
                    crmTrace.AppendLine("Get Conditional XML from Config record.");
                    string conditionalXML = configRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.ConditionXML);
                    crmTrace.AppendLine("conditionalXML: " + conditionalXML);
                    EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, targetEntity.Id)));
                    crmTrace.AppendLine("Documents count:" + conditionRecCount.Entities.Count.ToString());
                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                    {
                        ConditionExpression PICondition1 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression PICondition2 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement, ConditionOperator.Equal, new string[] { configRecord.Id.ToString() });
                        EntityCollection PIResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.CodeSection, ProgressInspectionCategoryAttributeNames.FilingScope }, new ConditionExpression[] { PICondition1, PICondition2 }, LogicalOperator.And);

                        int jobType = 0;
                        Entity Jobfiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(JobFilingEntityAttributeName.JobType));
                        if (Jobfiling.Attributes.Contains(JobFilingEntityAttributeName.JobType) && Jobfiling[JobFilingEntityAttributeName.JobType] != null)
                        {
                            jobType = Jobfiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value;
                        }                        

                        if (jobType == 0)
                        {
                            jobType = 1;
                        }

                        string ICId = configRecord.Id.ToString();
                        string ICCode = configRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);
                        int inspectionType = configRecord.GetAttributeValue<OptionSetValue>(InspectionsComponentsEntityAttributeName.InspectionType).Value;
                        int finalInspectionType = (inspectionType == 2) ? 2 : 1;

                        crmTrace.AppendLine("targetEntity.Id:" + targetEntity.Id.ToString());
                        crmTrace.AppendLine("ICId:" + ICId);
                        crmTrace.AppendLine("ICCode:" + ICCode);


                        crmTrace.AppendLine("PIResponse.Entities.Count: " + PIResponse.Entities.Count.ToString());
                        if (PIResponse != null && PIResponse.Entities.Count > 0)
                        {
                            if (jobType != PIResponse[0].GetAttributeValue<OptionSetValue>(ProgressInspectionCategoryAttributeNames.FilingScope).Value)
                            {
                                crmTrace.AppendLine("Delete Progress Inspection Components as Filing Type is different");
                                DeleteInspectionComponent(service, targetEntity, configRecord, crmTrace);

                                Entity ProgressInspectionCategory = new Entity();
                                ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(jobType));
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(finalInspectionType));
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(filingType));
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                                ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.IsAutoPopulated, true);
                                crmTrace.AppendLine("Adding Progress Inspection Component.");
                                service.Create(ProgressInspectionCategory);
                                crmTrace.AppendLine("Added Progress Inspection Component.");
                            }
                            else
                            {
                                crmTrace.AppendLine("Progress Inspection Component already exists.");
                            }
                        }
                        else
                        {
                            Entity ProgressInspectionCategory = new Entity();
                            ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(jobType));
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(finalInspectionType));
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(filingType));
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.IsAutoPopulated, true);
                            crmTrace.AppendLine("Adding Progress Inspection Component.");
                            service.Create(ProgressInspectionCategory);
                            crmTrace.AppendLine("Added Progress Inspection Component.");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Delete Progress Inspection Components");
                        DeleteInspectionComponent(service, targetEntity, configRecord, crmTrace);
                    }

                }
                else
                {
                    crmTrace.AppendLine("No Conditional XML found.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AddSpecialInspectionDocument(IOrganizationService service, Entity targetEntity, Entity configRecord, int filingType, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("AddSpecialInspectionDocument: Start");
            try
            {
                if (configRecord.Attributes.Contains(InspectionsComponentsEntityAttributeName.ConditionXML) && configRecord[InspectionsComponentsEntityAttributeName.ConditionXML] != null)
                {
                    crmTrace.AppendLine("Get Conditional XML from Config record.");
                    string conditionalXML = configRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.ConditionXML);
                    crmTrace.AppendLine("conditionalXML: " + conditionalXML);
                    EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, targetEntity.Id)));
                    crmTrace.AppendLine("Documents count:" + conditionRecCount.Entities.Count.ToString());
                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                    {
                        ConditionExpression SPCondition1 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression SPCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.AddRequirement, ConditionOperator.Equal, new string[] { configRecord.Id.ToString() });
                        EntityCollection SPResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.CodeSection, SpecialInspectionCategoriesAttributeNames.FilingScope }, new ConditionExpression[] { SPCondition1, SPCondition2 }, LogicalOperator.And);

                        int jobType = 0;
                        Entity Jobfiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(JobFilingEntityAttributeName.JobType));
                        if (Jobfiling.Attributes.Contains(JobFilingEntityAttributeName.JobType) && Jobfiling[JobFilingEntityAttributeName.JobType] != null)
                        {
                            jobType = Jobfiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value;
                        }

                        if (jobType == 0)
                        {
                            jobType = 1;
                        }

                        string ICId = configRecord.Id.ToString();
                        string ICCode = configRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);

                        crmTrace.AppendLine("targetEntity.Id:" + targetEntity.Id.ToString());
                        crmTrace.AppendLine("ICId:" + ICId);
                        crmTrace.AppendLine("ICCode:" + ICCode);

                        if (SPResponse != null && SPResponse.Entities.Count > 0)
                        {
                            if (jobType != SPResponse[0].GetAttributeValue<OptionSetValue>(SpecialInspectionCategoriesAttributeNames.FilingScope).Value)
                            {
                                crmTrace.AppendLine("Delete Special Inspection Components as Filing Type is different");
                                DeleteInspectionComponent(service, targetEntity, configRecord, crmTrace);

                                Entity SpecialsInspectionCategory = new Entity();
                                SpecialsInspectionCategory.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingScope, new OptionSetValue(jobType));
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(filingType));
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.CodeSection, ICCode);
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                                SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated, true);
                                crmTrace.AppendLine("Adding Special Inspection Component.");
                                service.Create(SpecialsInspectionCategory);
                                crmTrace.AppendLine("Added Special Inspection Component.");
                            }
                            else
                            {
                                crmTrace.AppendLine("Special Inspection Component already exists.");
                            }
                        }
                        else
                        {
                            Entity SpecialsInspectionCategory = new Entity();
                            SpecialsInspectionCategory.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingScope, new OptionSetValue(jobType));
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(filingType));
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.CodeSection, ICCode);
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated, true);
                            crmTrace.AppendLine("Adding Special Inspection Component.");
                            service.Create(SpecialsInspectionCategory);
                            crmTrace.AppendLine("Added Special Inspection Component.");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Delete Special Inspection Components");
                        DeleteInspectionComponent(service, targetEntity, configRecord, crmTrace);
                    }

                }
                else
                {
                    crmTrace.AppendLine("No Conditional XML found.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteInspectionComponent(IOrganizationService service, Entity targetEntity, Entity configRecord, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("DeleteInspectionComponent: Start");
            try
            {
                crmTrace.AppendLine("Start Deleting Inspection Components");
                int inspectionType = configRecord.GetAttributeValue<OptionSetValue>(InspectionsComponentsEntityAttributeName.InspectionType).Value;
                switch (inspectionType)
                {
                    case 1: //Special Inspection
                        crmTrace.AppendLine("Deleting Special Inspection record - Start");
                        ConditionExpression SPCondition1 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression SPCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.AddRequirement, ConditionOperator.Equal, new string[] { configRecord.Id.ToString() });
                        EntityCollection SPResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.CodeSection, SpecialInspectionCategoriesAttributeNames.IsAutoPopulated }, new ConditionExpression[] { SPCondition1, SPCondition2 }, LogicalOperator.And);

                        if (SPResponse != null && SPResponse.Entities.Count > 0)
                        {
                            foreach (Entity SPRecord in SPResponse.Entities)
                            {
                                if (SPRecord.GetAttributeValue<bool>(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated))
                                {
                                    crmTrace.AppendLine("SPRecord.LogicalName to delete: " + SPRecord.LogicalName);
                                    service.Delete(SPRecord.LogicalName, SPRecord.Id);
                                }
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("No SP records to delete.");
                        }
                        crmTrace.AppendLine("Deleting Special Inspection record - End");
                        break;
                    case 2: // Energy Code Progress Inspection                        
                    case 3: //Progress Inspection
                        crmTrace.AppendLine("Deleting Progress Inspection record - Start");
                        ConditionExpression PICondition1 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression PICondition2 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement, ConditionOperator.Equal, new string[] { configRecord.Id.ToString() });
                        EntityCollection PIResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.CodeSection, ProgressInspectionCategoryAttributeNames.IsAutoPopulated }, new ConditionExpression[] { PICondition1, PICondition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("PIResponse.Entities.Count: " + PIResponse.Entities.Count.ToString());
                        if (PIResponse != null && PIResponse.Entities.Count > 0)
                        {
                            foreach (Entity PIRecord in PIResponse.Entities)
                            {
                                if (PIRecord.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.IsAutoPopulated))
                                {
                                    crmTrace.AppendLine("PIRecord.LogicalName to delete: " + PIRecord.LogicalName);
                                    service.Delete(PIRecord.LogicalName, PIRecord.Id);
                                }
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("No PI records to delete.");
                        }
                        crmTrace.AppendLine("Deleting Progress Inspection record - End");
                        break;
                    default:
                        crmTrace.AppendLine("Inspection Type not found in the configuration.");
                        break;
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteInspectionComponent", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        #region Populate BE MS ST SOW Inspections
        public static void PopulateBEMSSTInspectionComponents(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("PopulateBEMSSTInspectionComponents: Start");
            try
            {
                string JobFilingGuid = string.Empty;
                EntityCollection ICResponse = new EntityCollection();
                if (targetEntity.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    if (preTargetEntity.Attributes.Contains(BEScopeOfWorkEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[BEScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else if (targetEntity.Attributes.Contains(BEScopeOfWorkEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[BEScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else
                    {
                        crmTrace.AppendLine("No BE JobFiling Guid found.");
                    }

                    crmTrace.AppendLine("BE JobFilingGuid:" + JobFilingGuid);

                    ICResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetSOWInspectionsbyWorkType, (int)InspectionComponentsDocumentRequirement.Conditional, WorkTypes.BE)));

                }
                else if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)
                {
                    if (preTargetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling))
                    {
                        crmTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling]).Id.ToString();
                    }
                    else if (targetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling))
                    {
                        crmTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling]).Id.ToString();
                    }
                    else
                    {
                        crmTrace.AppendLine("No BE JobFiling Guid found.");
                    }

                    crmTrace.AppendLine("BE JobFilingGuid:" + JobFilingGuid);

                    ICResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetSOWInspectionsbyWorkType, (int)InspectionComponentsDocumentRequirement.Conditional, WorkTypes.BE)));

                }
                else if (targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName)
                {
                    if (preTargetEntity.Attributes.Contains(MHScopeofworkAttributeNames.GotoJobFiling))
                    {
                        crmTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[MHScopeofworkAttributeNames.GotoJobFiling]).Id.ToString();
                    }
                    else if (targetEntity.Attributes.Contains(MHScopeofworkAttributeNames.GotoJobFiling))
                    {
                        crmTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[MHScopeofworkAttributeNames.GotoJobFiling]).Id.ToString();
                    }
                    else
                    {
                        crmTrace.AppendLine("No MS JobFiling Guid found.");
                    }

                    crmTrace.AppendLine("MS JobFilingGuid:" + JobFilingGuid);

                    ICResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetSOWInspectionsbyWorkType, (int)InspectionComponentsDocumentRequirement.Conditional, WorkTypes.MS)));

                }
                else if (targetEntity.LogicalName == STScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    if (preTargetEntity.Attributes.Contains(STScopeOfWorkEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else if (preTargetEntity.Attributes.Contains(STScopeOfWorkEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[STScopeOfWorkEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else
                    {
                        crmTrace.AppendLine("No ST JobFiling Guid found.");
                    }

                    crmTrace.AppendLine("ST JobFilingGuid:" + JobFilingGuid);

                    ICResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetSOWInspectionsbyWorkType, (int)InspectionComponentsDocumentRequirement.Conditional, WorkTypes.ST)));

                }
                else if (targetEntity.LogicalName == SOWCommonWorkTypesEntityAttribute.EntityLogicalName)
                {
                    if (preTargetEntity.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("preTargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)preTargetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else if (preTargetEntity.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GoToJobFiling))
                    {
                        crmTrace.AppendLine("TargetEntity Entity Contains Job Filing:");
                        JobFilingGuid = ((EntityReference)targetEntity[SOWCommonWorkTypesEntityAttribute.GoToJobFiling]).Id.ToString();
                    }
                    else
                    {
                        crmTrace.AppendLine("No PL SOW JobFiling Guid found.");
                    }

                    crmTrace.AppendLine("PL SOW JobFilingGuid:" + JobFilingGuid);

                    ICResponse = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetSOWInspectionsbyWorkType, (int)InspectionComponentsDocumentRequirement.Conditional, WorkTypes.PL)));

                }

                crmTrace.AppendLine("SOW Config Count: " + ICResponse.Entities.Count.ToString());
                if (ICResponse != null && ICResponse.Entities.Count > 0)
                {
                    foreach (Entity ICRecord in ICResponse.Entities)
                    {
                        crmTrace.AppendLine("Get BE MS ST Conditional XML from Config record.");
                        string conditionalXML = ICRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.ConditionXML);
                        string ICId = ICRecord.GetAttributeValue<Guid>(InspectionsComponentsEntityAttributeName.InspectionsComponentsID).ToString();
                        string ICCode = ICRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);
                        int inspectionType = ICRecord.GetAttributeValue<OptionSetValue>(InspectionsComponentsEntityAttributeName.InspectionType).Value;
                        string inspectionName = ICRecord.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);

                        crmTrace.AppendLine("Inspection Name: " + inspectionName);

                        crmTrace.AppendLine("BE MS ST ICId:" + ICId);
                        crmTrace.AppendLine("BE MS ST ICCode:" + ICCode);

                        if (!string.IsNullOrEmpty(conditionalXML) && !string.IsNullOrEmpty(JobFilingGuid))
                        {
                            crmTrace.AppendLine("BE MS ST conditionalXML: " + conditionalXML);
                            EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, JobFilingGuid)));
                            crmTrace.AppendLine("BE MS ST Documents count:" + conditionRecCount.Entities.Count.ToString());

                            crmTrace.AppendLine("inspectionType: " + inspectionType.ToString());

                            switch (inspectionType)
                            {
                                case 1: //Special Inspection
                                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("AddSTSpecialInspectionDocument");
                                        AddBEMSSTSpecialInspectionDocument(service, JobFilingGuid, ICId, ICCode, crmTrace);
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("DeleteSTSpecialInspectionDocument");
                                        DeleteBEMSSTSpecialInspectionDocument(service, JobFilingGuid, ICId, crmTrace);
                                    }
                                    break;
                                case 2: //Energy Code Progress Inspection
                                case 3: //Progress Inspection
                                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("AddSTProgressInspectionDocument");
                                        AddBEMSSTProgressInspectionDocument(service, JobFilingGuid, ICId, ICCode, inspectionType, crmTrace);
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("DeleteSTProgressInspectionDocument");
                                        DeleteBEMSSTProgressInspectionDocument(service, JobFilingGuid, ICId, crmTrace);
                                    }
                                    break;
                                default:
                                    crmTrace.AppendLine("BE MS ST SOW Inspection Type not found in the configuration.");
                                    break;
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Issue with Conditional XML or Job Filing lookup ID in BE MS ST SOW.");
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No BE MS ST conditional inspection configurations found.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBEMSSTInspectionComponents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AddBEMSSTSpecialInspectionDocument(IOrganizationService service, string JobFilingGuid, string ICId, string ICCode, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression SPCondition1 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                ConditionExpression SPCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.AddRequirement, ConditionOperator.Equal, new string[] { ICId });
                EntityCollection SPResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.CodeSection, SpecialInspectionCategoriesAttributeNames.FilingScope }, new ConditionExpression[] { SPCondition1, SPCondition2 }, LogicalOperator.And);

                ConditionExpression JFCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { JobFilingGuid });
                EntityCollection JFResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName,
                                        new string[] { JobFilingEntityAttributeName.JobType, JobFilingEntityAttributeName.FilingType },
                                        new ConditionExpression[] { JFCondition }, LogicalOperator.And);

                int jobType = 0;
                int FilingType = 0;

                if (JFResponse != null && JFResponse.Entities.Count > 0)
                {
                    foreach (Entity JFRecord in JFResponse.Entities)
                    {
                        crmTrace.AppendLine("Get Job Filing Type.");
                        jobType = JFRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value;
                        FilingType = JFRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                        crmTrace.AppendLine("Job Filing Type: " + jobType);
                    }
                }


                if (jobType == 0)
                {
                    jobType = 1;
                }

                if (SPResponse != null && SPResponse.Entities.Count > 0)
                {
                    if (jobType != SPResponse[0].GetAttributeValue<OptionSetValue>(SpecialInspectionCategoriesAttributeNames.FilingScope).Value)
                    {
                        crmTrace.AppendLine("Delete Special Inspection Components as Filing Type is different");
                        DeleteBEMSSTSpecialInspectionDocument(service, JobFilingGuid, ICId, crmTrace);

                        Entity SpecialsInspectionCategory = new Entity();
                        SpecialsInspectionCategory.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid)));
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingScope, new OptionSetValue(jobType));

                        if (FilingType == 2)
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(2));
                        else
                            SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(1));

                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.CodeSection, ICCode);
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated, true);
                        crmTrace.AppendLine("Adding BE MS ST Special Inspection Component.");
                        service.Create(SpecialsInspectionCategory);
                        crmTrace.AppendLine("Added BE MS ST Special Inspection Component.");
                    }
                    else
                    {
                        crmTrace.AppendLine("Special Inspection Component already exists.");
                    }
                }
                else
                {
                    Entity SpecialsInspectionCategory = new Entity();
                    SpecialsInspectionCategory.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                    SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid)));
                    SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingScope, new OptionSetValue(jobType));

                    if (FilingType == 2)
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(2));
                    else
                        SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue(1));

                    SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.CodeSection, ICCode);
                    SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                    SpecialsInspectionCategory.Attributes.Add(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated, true);
                    crmTrace.AppendLine("Adding BE MS ST Special Inspection Component.");
                    service.Create(SpecialsInspectionCategory);
                    crmTrace.AppendLine("Added BE MS ST Special Inspection Component.");
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static void DeleteBEMSSTSpecialInspectionDocument(IOrganizationService service, string JobFilingGuid, string ICId, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Deleting BE MS ST Special Inspection record - Start");
                crmTrace.AppendLine("JobFiling Guid: " + JobFilingGuid);
                crmTrace.AppendLine("AddRequirement: " + ICId);
                ConditionExpression SPCondition1 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                ConditionExpression SPCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.AddRequirement, ConditionOperator.Equal, new string[] { ICId });
                EntityCollection SPResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.CodeSection, SpecialInspectionCategoriesAttributeNames.IsAutoPopulated }, new ConditionExpression[] { SPCondition1, SPCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("SPResponse.Entities.Count" + SPResponse.Entities.Count.ToString());

                if (SPResponse != null && SPResponse.Entities.Count > 0)
                {
                    foreach (Entity SPRecord in SPResponse.Entities)
                    {
                        if (SPRecord.GetAttributeValue<bool>(SpecialInspectionCategoriesAttributeNames.IsAutoPopulated))
                        {
                            crmTrace.AppendLine("BE MS ST SPRecord.LogicalName to delete: " + SPRecord.LogicalName);
                            service.Delete(SPRecord.LogicalName, SPRecord.Id);
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No BE MS ST SP records to delete.");
                }
                crmTrace.AppendLine("Deleting BE MS ST Special Inspection record - End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTSpecialInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static void AddBEMSSTProgressInspectionDocument(IOrganizationService service, string JobFilingGuid, string ICId, string ICCode, int inspectionType, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Adding BE MS ST Progress Inspection Component - Start.");
                ConditionExpression PICondition1 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                ConditionExpression PICondition2 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement, ConditionOperator.Equal, new string[] { ICId });
                EntityCollection PIResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.CodeSection, ProgressInspectionCategoryAttributeNames.FilingScope }, new ConditionExpression[] { PICondition1, PICondition2 }, LogicalOperator.And);

                ConditionExpression JFCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { JobFilingGuid });
                EntityCollection JFResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName,
                                new string[] { JobFilingEntityAttributeName.JobType, JobFilingEntityAttributeName.FilingType }, new ConditionExpression[] { JFCondition }, LogicalOperator.And);

                int jobType = 0;
                int FilingType = 0;

                if (JFResponse != null && JFResponse.Entities.Count > 0)
                {
                    foreach (Entity JFRecord in JFResponse.Entities)
                    {
                        crmTrace.AppendLine("Get Job Filing Type.");
                        jobType = JFRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value;
                        FilingType = JFRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                        crmTrace.AppendLine("Job Filing Type: " + jobType);
                    }
                }

                if (jobType == 0)
                {
                    jobType = 1;
                }

                int finalInspectionType = (inspectionType == 2) ? 2 : 1;

                if (PIResponse != null && PIResponse.Entities.Count > 0)
                {
                    if (jobType != PIResponse[0].GetAttributeValue<OptionSetValue>(ProgressInspectionCategoryAttributeNames.FilingScope).Value)
                    {
                        crmTrace.AppendLine("Delete Progress Inspection Components as Filing Type is different");
                        DeleteBEMSSTProgressInspectionDocument(service, JobFilingGuid, ICId, crmTrace);

                        Entity ProgressInspectionCategory = new Entity();
                        ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid)));
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(jobType));
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(finalInspectionType));

                        if (FilingType == 2)
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(2));
                        else
                            ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(1));

                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.IsAutoPopulated, true);
                        crmTrace.AppendLine("Adding BE MS ST Progress Inspection Component.");
                        service.Create(ProgressInspectionCategory);
                        crmTrace.AppendLine("Added BE MS ST Progress Inspection Component.");
                    }
                    else
                    {
                        crmTrace.AppendLine("Progress Inspection Component already exists.");
                    }
                }
                else
                {
                    Entity ProgressInspectionCategory = new Entity();
                    ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, Guid.Parse(JobFilingGuid)));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(jobType));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(finalInspectionType));

                    if (FilingType == 2)
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(2));
                    else
                        ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(1));

                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.IsAutoPopulated, true);
                    crmTrace.AppendLine("Adding BE MS ST Progress Inspection Component.");
                    service.Create(ProgressInspectionCategory);
                    crmTrace.AppendLine("Added BE MS ST Progress Inspection Component.");
                }
                crmTrace.AppendLine("Adding BE MS ST Progress Inspection Component - End.");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddBEMSSTProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static void DeleteBEMSSTProgressInspectionDocument(IOrganizationService service, string JobFilingGuid, string ICId, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Deleting BE MS ST Progress Inspection record - Start");
                ConditionExpression PICondition1 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                ConditionExpression PICondition2 = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement, ConditionOperator.Equal, new string[] { ICId });
                EntityCollection PIResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.CodeSection, ProgressInspectionCategoryEntityAttributeName.IsAutoPopulated }, new ConditionExpression[] { PICondition1, PICondition2 }, LogicalOperator.And);

                if (PIResponse != null && PIResponse.Entities.Count > 0)
                {
                    foreach (Entity PIRecord in PIResponse.Entities)
                    {
                        if (PIRecord.GetAttributeValue<bool>(ProgressInspectionCategoryEntityAttributeName.IsAutoPopulated))
                        {
                            crmTrace.AppendLine("BE MS ST PIRecord.LogicalName to delete: " + PIRecord.LogicalName);
                            service.Delete(PIRecord.LogicalName, PIRecord.Id);
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No BE MS ST PI records to delete.");
                }
                crmTrace.AppendLine("Deleting BE MS ST Progress Inspection record - End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBEMSSTProgressInspectionDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }
        #endregion

        #region Populate Required Documents based on triggers
        public static void PopulateRequiredDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, bool isTR2Record, bool isPAAFiling, bool isBCDBCTaskSubmitted)
        {
            crmTrace.AppendLine("PopulateRequiredDocuments: Start");
            try
            {
                crmTrace.AppendLine("WorkType: " + targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox));
                string[] strWorkTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                List<string> workTypes = new List<string>(strWorkTypes);
                if(workTypes.Count == 0)
                {
                    string fetch = string.Format(FetchXml.GetAssociatedWorkTypes, targetEntity.Id.ToString());
                    crmTrace.AppendLine("fetch: " + fetch);
                    EntityCollection wt_response = service.RetrieveMultiple(new FetchExpression(fetch));
                    if (wt_response != null && wt_response.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                        foreach (Entity wt in wt_response.Entities)
                        {
                            string wt_ConfigName = wt.GetAttributeValue<string>(AssociatedWorkTypesEntityAttributeName.Name);
                            crmTrace.AppendLine("wt_ConfigName: " + wt_ConfigName);
                            workTypes.Add(wt_ConfigName);

                        }
                    }
                }                
                if (workTypes.Count > 0)
                {
                    foreach (string workType in workTypes)
                    {
                        crmTrace.AppendLine("For Work Type: " + workType);
                        EntityCollection configurationResult = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetDocumentConfigurationByWorkType, workType)));
                        crmTrace.AppendLine("configurationResult.Entities.Count: " + configurationResult.Entities.Count);

                        if (configurationResult != null && configurationResult.Entities.Count > 0)
                        {
                            foreach (Entity configRecord in configurationResult.Entities)
                            {
                                int priorToStatus = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStatus).Value).Value;
                                crmTrace.AppendLine("priorToStatus: " + priorToStatus);
                                if (isPAAFiling && priorToStatus != (int)CurrentFilingStatus.Approved)
                                {
                                    crmTrace.AppendLine("PAA doesn't require documents otherthan Prior to Approved.");
                                    continue;
                                }

                                crmTrace.AppendLine("Get Conditional XML from Config record.");

                                string conditionalXML = configRecord.GetAttributeValue<string>(DocumentsRequiredConfigurationsEntityAttibuteName.ConditionalXML);
                                crmTrace.AppendLine("Conditional XML: " + conditionalXML);
                                if (!string.IsNullOrEmpty(conditionalXML))
                                {
                                    string adjusted_WorkType = workType;
                                    if (workType.Contains("_"))
                                        adjusted_WorkType = workType.Split('_')[0];
                                    crmTrace.AppendLine("adjusted_WorkType : " + adjusted_WorkType);
                                    EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, adjusted_WorkType, targetEntity.Id.ToString())));
                                    crmTrace.AppendLine("Formated Conditional XML: " + string.Format(conditionalXML, workType, targetEntity.Id.ToString()));
                                    crmTrace.AppendLine("Documents count:" + conditionRecCount.Entities.Count.ToString());

                                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Add Required Document");
                                        AddRequiredDocument(service, targetEntity, configRecord, workType, crmTrace, isTR2Record, isBCDBCTaskSubmitted, isPAAFiling);
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("Delete Required Document");
                                        DeleteRequiredDocument(service, targetEntity, configRecord, crmTrace, isTR2Record);
                                    }
                                }
                                else
                                {
                                    crmTrace.AppendLine("No Conditional XML found in Configuration");
                                }
                            }
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No Work Type found.");
                }
                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AddRequiredDocument(IOrganizationService service, Entity targetEntity, Entity configRecord, string workType, StringBuilder crmTrace, bool isTR2Record, bool isBCDBCTaskSubmitted, bool isPAAFiling)
        {
            crmTrace.AppendLine("AddRequiredDocument: Start");
            try
            {
                string strDocumentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name;
                crmTrace.AppendLine("documentName:" + strDocumentName);
                string requiredforWorkType = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.RequiredforWorkTypes).Value.ToString();
                Guid documentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Id;
                crmTrace.AppendLine("requiredforWorkTypes:" + requiredforWorkType);

                if (requiredforWorkType.Contains(workType))
                {
                    ConditionExpression RDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    ConditionExpression RDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { documentName.ToString() });
                    // ConditionExpression RDCondition3 = CreateConditionExpression("statecode", ConditionOperator.Equal,new string[] {});
                    EntityCollection RDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.ManuallySelected }, new ConditionExpression[] { RDCondition1, RDCondition2 }, LogicalOperator.And);

                    crmTrace.AppendLine("RDResponse.Entities.Count: " + RDResponse.Entities.Count);

                    bool isRequiredDocExist = false, isApprovedDocExist = false, isRejectedDocExist = false, isSubmittedDocExist = false;

                    if (RDResponse != null && RDResponse.Entities.Count > 0)
                    {
                        #region DEV V5 Document Handling based on ACP 20 document - Not Required as separate documents will populated TFS 26529 (4/15/2019)
                        //if (strDocumentName.ToUpper() == DocumentTypeNames.DEPACP20ACP21)
                        //{
                        //    foreach (Entity RDRecord in RDResponse.Entities)
                        //    {
                        //        crmTrace.AppendLine("Document Name: " + DocumentTypeNames.DEPACP20ACP21);
                        //        int docACPStatus = RDRecord.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;
                        //        if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName && (docACPStatus == 2 || docACPStatus == 5)) //Pending or Submitted ACP20 Document
                        //        {
                        //            string[] jfColumnNames = { JobFilingEntityAttributeName.FilingStatus };
                        //            Entity jfResponse = Retrieve(service, jfColumnNames, Guid.Parse(targetEntity.Id.ToString()), JobFilingEntityAttributeName.EntityLogicalName);
                        //            int filingStatus = jfResponse.Contains(JobFilingEntityAttributeName.FilingStatus) ? jfResponse.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : 0;
                        //            crmTrace.AppendLine("Job Filing Status Value: " + filingStatus);
                        //            //if (filingStatus == 1) //Pre-filing job
                        //            //{
                        //                crmTrace.AppendLine("Pre-filing Job.");
                        //                ConditionExpression RDV5Condition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        //                ConditionExpression RDV5Condition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentTypeNames.DEPVarianceV5Letter });
                        //                EntityCollection RDV5Response = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.ManuallySelected }, new ConditionExpression[] { RDV5Condition1, RDV5Condition2 }, LogicalOperator.And);

                        //                if (RDV5Response != null && RDV5Response.Entities.Count > 0)
                        //                {
                        //                    crmTrace.AppendLine("V5 letter exists.");
                        //                foreach (Entity RDV5Record in RDV5Response.Entities)
                        //                {
                        //                    if (!RDV5Record.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected) && RDV5Record.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value == (int)DocumentStatus.Required)
                        //                    {
                        //                        crmTrace.AppendLine("V5 Document Record LogicalName to delete: " + RDV5Record.LogicalName);
                        //                        service.Delete(RDV5Record.LogicalName, RDV5Record.Id);
                        //                        crmTrace.AppendLine("V5 letter record deleted.");
                        //                    }
                        //                    if (!RDV5Record.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected) && RDV5Record.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value == (int)DocumentStatus.Rejected)
                        //                    {
                        //                        crmTrace.AppendLine("V5 Document Record LogicalName to Update to Manually Selected: " + RDV5Record.LogicalName);
                        //                        RDV5Record.Attributes[DocumentListEntityAttributeName.ManuallySelected] = true;
                        //                        RDV5Record.Attributes[DocumentListEntityAttributeName.RejectionReason] = new OptionSetValue(1); //Document not required
                        //                        service.Update(RDV5Record);
                        //                        crmTrace.AppendLine("V5 letter record Updated to Manually Selected:.");
                        //                    }
                        //                }
                        //            }
                        //            //}
                        //        }
                        //    }
                        //}
                        #endregion

                        #region BCDBC Exception Report Handling
                        if (isTR2Record && !isBCDBCTaskSubmitted)
                        {
                            foreach (Entity RDRecord in RDResponse.Entities)
                            {
                                if ((workType.ToUpper() == WorkTypes.ST) && (strDocumentName.ToUpper() == DocumentTypeNames.ConcreteTestingExceptionReport))
                                {
                                    int documentStatus = RDRecord.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;
                                    if (documentStatus == 1)
                                    {
                                        isRequiredDocExist = true;
                                    }
                                    else if (documentStatus == 3)
                                    {
                                        isApprovedDocExist = true;
                                    }
                                    else if (documentStatus == 4)
                                    {
                                        isRejectedDocExist = true;
                                    }
                                    else if (documentStatus == 5)
                                    {
                                        isSubmittedDocExist = true;
                                    }
                                }


                                if ((workType.ToUpper() == WorkTypes.ST) && (strDocumentName.ToUpper() == DocumentTypeNames.ConcreteTestingExceptionReport))
                                {
                                    if (((!isRequiredDocExist && !isSubmittedDocExist && !isRejectedDocExist)
                                        || (!isRequiredDocExist && !isSubmittedDocExist && !isRejectedDocExist && isApprovedDocExist)) && !RDRecord.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected))
                                    {
                                        int documentClass = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.DocumentClass).Value).Value;
                                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                                        int priorToStatus = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStatus).Value).Value;
                                        crmTrace.AppendLine("priorToStatus:" + priorToStatus.ToString());

                                        string priorToStage = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStage).Value.ToString();
                                        crmTrace.AppendLine("priorToStage:" + priorToStage);

                                        bool manuallySelected = false;

                                        bool allowWaiver = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowWaiver).Value);
                                        crmTrace.AppendLine("allowWaiver: " + allowWaiver.ToString());
                                        bool allowdeferral = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowDeferral).Value);
                                        crmTrace.AppendLine("allowdeferral: " + allowdeferral.ToString());

                                        crmTrace.AppendLine("documentName:" + strDocumentName);
                                        crmTrace.AppendLine("documentName Id:" + documentName.ToString());
                                        crmTrace.AppendLine("jobFilingId:" + targetEntity.Id.ToString());
                                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                                        Entity DocumentList = new Entity();
                                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, strDocumentName);
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentName));
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentClass)); //Technical or Non-Technical
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(1)); //Required
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priorToStage);
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(priorToStatus));
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2)); //Supporting Document
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, manuallySelected);
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, allowWaiver);
                                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, allowdeferral);
                                        crmTrace.AppendLine("Mapping TR2 Id.");

                                        #region Associate TR2 Relationship with the documents

                                        //Get TR2 reference ID from Job Filing
                                        crmTrace.AppendLine("Get TR2 Id using the Job Filing");
                                        ConditionExpression TR2Condition = CreateConditionExpression(TR2TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                                        EntityCollection TR2Response = RetrieveMultiple(service, TR2TechnicalReport.EntityLogicalName, new string[] { TR2TechnicalReport.Name }, new ConditionExpression[] { TR2Condition }, LogicalOperator.And);
                                        crmTrace.AppendLine("TR2Response.Entities.Count: " + TR2Response.Entities.Count);

                                        if (TR2Response != null && TR2Response.Entities.Count > 0)
                                        {
                                            Guid TR2RecordId = TR2Response.Entities[0].Id;
                                            crmTrace.AppendLine("TR2 Record Id: " + TR2RecordId.ToString());
                                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.GoToTR2TechReports, new EntityReference(TR2TechnicalReport.EntityLogicalName, TR2RecordId));
                                            crmTrace.AppendLine("TR2 mapping for Document is done.");
                                        }

                                        #endregion

                                        crmTrace.AppendLine("Adding Required Document to the Document List.");
                                        service.Create(DocumentList);
                                        crmTrace.AppendLine("Added Required Document to the Document List.");
                                    }
                                }
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Required Document already exists.");
                        }
                        #endregion
                    }
                    else
                    {
                        #region DEV V5 Document creation based on ACP 20 document - Not Required as separate documents will populated TFS 26529 (4/15/2019)
                        //if (strDocumentName.ToUpper() == DocumentTypeNames.DEPVarianceV5Letter)
                        //{
                        //    crmTrace.AppendLine("Document Name: " + DocumentTypeNames.DEPVarianceV5Letter);
                        //    if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                        //    {
                        //        string[] jfColumnNames = { JobFilingEntityAttributeName.FilingStatus };
                        //        Entity jfResponse = Retrieve(service, jfColumnNames, Guid.Parse(targetEntity.Id.ToString()), JobFilingEntityAttributeName.EntityLogicalName);
                        //        int filingStatus = jfResponse.Contains(JobFilingEntityAttributeName.FilingStatus) ? jfResponse.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : 0;
                        //        crmTrace.AppendLine("Job Filing Status Value: " + filingStatus);
                        //        //if (filingStatus == 1) //Pre-filing job
                        //        //{
                        //        crmTrace.AppendLine("Pre-filing Job.");
                        //        ConditionExpression RDACPCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        //        ConditionExpression RDACPCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentTypeNames.DEPACP20ACP21 });
                        //        EntityCollection RDACPResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.ManuallySelected }, new ConditionExpression[] { RDACPCondition1, RDACPCondition2 }, LogicalOperator.And);

                        //        if (RDACPResponse != null && RDACPResponse.Entities.Count > 0)
                        //        {
                        //            crmTrace.AppendLine("V5 letter exists.");
                        //            foreach (Entity RDACPRecord in RDACPResponse.Entities)
                        //            {
                        //                int docACPStatus = RDACPRecord.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;

                        //                if (docACPStatus == 2 || docACPStatus == 3 || docACPStatus == 4 || docACPStatus == 5)
                        //                {
                        //                    crmTrace.AppendLine("Need not to add V5 letter record and skip further steps.");
                        //                    return;
                        //                }
                        //            }
                        //        }
                        //        //}
                        //    }
                        //}

                        #endregion

                        crmTrace.AppendLine("Not TR2");
                        int documentClass = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.DocumentClass).Value).Value;
                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                        int priorToStatus = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStatus).Value).Value;
                        crmTrace.AppendLine("priorToStatus:" + priorToStatus.ToString());

                        string priorToStage = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStage).Value.ToString();
                        crmTrace.AppendLine("priorToStage:" + priorToStage);

                        string requiredItemNumber = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.RequiredItemNumber).Value.ToString();
                        crmTrace.AppendLine("requiredItemNumber:" + requiredItemNumber);

                        bool manuallySelected = false;

                        bool allowWaiver = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowWaiver).Value);
                        crmTrace.AppendLine("allowWaiver: " + allowWaiver.ToString());
                        bool allowdeferral = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowDeferral).Value);
                        crmTrace.AppendLine("allowdeferral: " + allowdeferral.ToString());

                        crmTrace.AppendLine("documentName:" + strDocumentName);
                        crmTrace.AppendLine("documentName Id:" + documentName.ToString());
                        crmTrace.AppendLine("jobFilingId:" + targetEntity.Id.ToString());
                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                        Entity DocumentList = new Entity();
                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, strDocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentName));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentClass)); //Technical or Non-Technical
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(1)); //Required
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priorToStage);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(priorToStatus));
                        if(requiredItemNumber.ToUpper() == CommonStringConstants.PlansSketchDocumentCategory)
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(1)); //Plans
                        }
                        else
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2)); //Supporting Document
                        }                        
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, manuallySelected);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, allowWaiver);                        
                        crmTrace.AppendLine("Mapping TR2 Id.");

                        #region Associate TR2 Relationship with the documents
                        if ((workType.ToUpper() == WorkTypes.ST) && (strDocumentName.ToUpper() == DocumentTypeNames.ConcreteTestingExceptionReport))
                        {
                            //Get TR2 reference ID from Job Filing
                            crmTrace.AppendLine("Get TR2 Id using the Job Filing");
                            ConditionExpression TR2Condition = CreateConditionExpression(TR2TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                            EntityCollection TR2Response = RetrieveMultiple(service, TR2TechnicalReport.EntityLogicalName, new string[] { TR2TechnicalReport.Name }, new ConditionExpression[] { TR2Condition }, LogicalOperator.And);
                            crmTrace.AppendLine("TR2Response.Entities.Count: " + TR2Response.Entities.Count);

                            if (TR2Response != null && TR2Response.Entities.Count > 0)
                            {
                                Guid TR2RecordId = TR2Response.Entities[0].Id;
                                crmTrace.AppendLine("TR2 Record Id: " + TR2RecordId.ToString());
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.GoToTR2TechReports, new EntityReference(TR2TechnicalReport.EntityLogicalName, TR2RecordId));
                                crmTrace.AppendLine("TR2 mapping for Document is done.");
                            }
                        }
                        #endregion

                        crmTrace.AppendLine("Adding Required Document to the Document List.");
                        if (isPAAFiling)
                        {
                            if (priorToStatus == (int)CurrentFilingStatus.Approved)
                            {
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, false);
                                service.Create(DocumentList);
                            }
                            else
                            {
                                crmTrace.AppendLine("Documents with prior to status approve only applied for PAA.");
                            }
                        }
                        else
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, allowdeferral);
                            service.Create(DocumentList);
                        }
                        
                        crmTrace.AppendLine("Added Required Document to the Document List.");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Document is not required for the work type: " + workType);
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddRequiredDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteRequiredDocument(IOrganizationService service, Entity targetEntity, Entity configRecord, StringBuilder crmTrace, bool isTR2Record)
        {
            crmTrace.AppendLine("DeleteRequiredDocument: Start");
            try
            {
                crmTrace.AppendLine("Document Name " + configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name);
                string strDocumentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name;

                if (!string.IsNullOrEmpty(strDocumentName) && strDocumentName.ToUpper() != DocumentTypeNames.ConcreteTestingExceptionReport)
                {
                Guid documentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Id;
                ConditionExpression RDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression RDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { documentName.ToString() });
                    //ConditionExpression RDCondition3 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.NotEqual, new string[] { DocumentTypeNames.ConcreteTestingExceptionReport });
                    EntityCollection RDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.ManuallySelected, DocumentListEntityAttributeName.DocumentStatus }, new ConditionExpression[] { RDCondition1, RDCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("RDResponse.Entities.Count " + RDResponse.Entities.Count);
                if (RDResponse != null && RDResponse.Entities.Count > 0)
                {
                    foreach (Entity RDRecord in RDResponse.Entities)
                    {
                        int documentStatus = RDRecord.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;

                        if (!isTR2Record)
                        {
                            if (!RDRecord.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected))
                            {
                                crmTrace.AppendLine("Required Document Record LogicalName to delete: " + RDRecord.LogicalName);
                                service.Delete(RDRecord.LogicalName, RDRecord.Id);
                            }
                        }
                        else
                        {
                            if ((!RDRecord.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected)) && (documentStatus == (int)DocumentStatus.Required || documentStatus == (int)DocumentStatus.Submitted))
                            {
                                //crmTrace.AppendLine("TR2 Required Document Record LogicalName to delete: " + RDRecord.LogicalName);
                                //service.Delete(RDRecord.LogicalName, RDRecord.Id);

                                //crmTrace.AppendLine("TR2 Required Document Record LogicalName to hide: " + RDRecord.LogicalName);
                                //RDRecord.Attributes[DocumentListEntityAttributeName.ManuallySelected] = true;
                                //RDRecord.Attributes[DocumentListEntityAttributeName.RejectionReason] = new OptionSetValue(1); //Document is not required anymore
                                //service.Update(RDRecord);
                                //crmTrace.AppendLine("Concrete Exception Report set to hidden.");
                            }
                            else
                            {
                                crmTrace.AppendLine("No Concrete Exception Report to delete.");
                            }
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No Required Documents to delete.");
                }

                }
                crmTrace.AppendLine("DeleteRequiredDocument - End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteRequiredDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static bool IsPAAFiling(IOrganizationService service, string jobFilingGuid, StringBuilder crmTrace)
        {
            try
            {
                bool isPAAFiling = false;
                #region Check Filing Type
                string[] jfColumnNames = { JobFilingEntityAttributeName.FilingType };
                Entity jfResponse = Retrieve(service, jfColumnNames, Guid.Parse(jobFilingGuid), JobFilingEntityAttributeName.EntityLogicalName);
                int filingType = jfResponse.Contains(JobFilingEntityAttributeName.FilingType) ? jfResponse.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value : 1;

                if (filingType == (int)FilingType.PAA)
                {
                    isPAAFiling = true;
                }
                #endregion

                return isPAAFiling;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - IsPAAFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static void PopulateTR2RequiredDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, bool isTR2Record, bool isPAAFiling, bool isBCDBCTaskSubmitted)
        {
            crmTrace.AppendLine("PopulateRequiredDocuments: Start");
            try
            {
                crmTrace.AppendLine("WorkType: " + targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox));
                string[] workTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                if (workTypes.Length > 0)
                {
                    foreach (string workType in workTypes)
                    {
                        crmTrace.AppendLine("For Work Type: " + workType);
                        EntityCollection configurationResult = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetDocumentConfigurationByWorkType, workType)));
                        crmTrace.AppendLine("configurationResult.Entities.Count: " + configurationResult.Entities.Count);

                        if (configurationResult != null && configurationResult.Entities.Count > 0)
                        {
                            foreach (Entity configRecord in configurationResult.Entities)
                            {
                                int priorToStatus = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStatus).Value).Value;
                                crmTrace.AppendLine("priorToStatus: " + priorToStatus);
                                if (isPAAFiling && priorToStatus != (int)CurrentFilingStatus.Approved)
                                {
                                    crmTrace.AppendLine("PAA doesn't require documents otherthan Prior to Approved.");
                                    continue;
                                }

                                crmTrace.AppendLine("Get Conditional XML from Config record.");

                                string conditionalXML = configRecord.GetAttributeValue<string>(DocumentsRequiredConfigurationsEntityAttibuteName.ConditionalXML);
                                crmTrace.AppendLine("Conditional XML: " + conditionalXML);
                                if (!string.IsNullOrEmpty(conditionalXML))
                                {
                                    EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, workType, targetEntity.Id.ToString())));
                                    crmTrace.AppendLine("Documents count:" + conditionRecCount.Entities.Count.ToString());

                                    if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Add Required Document");
                                        AddRequiredDocument(service, targetEntity, configRecord, workType, crmTrace, isTR2Record, isBCDBCTaskSubmitted, isPAAFiling);
                                    }

                                }
                                else
                                {
                                    crmTrace.AppendLine("No Conditional XML found in Configuration");
                                }

                                ////BCDBC Record handling - Start
                                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus) && targetEntity[JobFilingEntityAttributeName.FilingStatus] != null)
                                //{
                                //    crmTrace.AppendLine("Filing Status: " + targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value);
                                //    if ((targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value == (int)CurrentFilingStatus.PermitEntireBCDBCReview) 
                                //        && (configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name.ToUpper() == DocumentTypeNames.ConcreteTestingExceptionReport))
                                //    {
                                //        DeleteRequiredDocument(service, targetEntity, configRecord, crmTrace, isTR2Record);
                                //        crmTrace.AppendLine("Delete TR2 Report");
                                //    }
                                //}
                                ////BCDBC Record handling - End

                            }
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No Work Type found.");
                }                
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateRequiredDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CloneParentDocumentsOnPAA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.Clear();
                crmTrace.AppendLine("CloneParentDocumentsOnPAA: Start");
                #region Get Parent JobFiling Details
                string[] JFColumns = { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName };
                Entity JFResponse = Retrieve(service, JFColumns, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);
                Guid parentJFId = JFResponse.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;
                crmTrace.AppendLine("parentJFId: " + parentJFId.ToString());
                #endregion

                #region Clone Parent Documents on PAA
                if(parentJFId != Guid.Empty)
                {
                    crmTrace.AppendLine("Retereive all documents on Parent");
                    EntityCollection parentDocuments = RetrieveParentDocumentsForPAA(service, parentJFId, crmTrace);
                    if (parentDocuments != null && parentDocuments.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("parentDocuments.Entities.Count: " + parentDocuments.Entities.Count);
                        foreach (Entity doc in parentDocuments.Entities)
                        {
                            Guid documentTypeGuid = doc.GetAttributeValue<EntityReference>(DocumentListEntityAttributeName.DocumentName).Id;
                            string documentTypeName = doc.GetAttributeValue<EntityReference>(DocumentListEntityAttributeName.DocumentName).Name;
                            if(documentTypeName != DocumentTypeNames.DPL1SealSignature)
                            {
                                Entity DocumentList = new Entity();
                                DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, doc.GetAttributeValue<string>(DocumentListEntityAttributeName.RequiredItemNumber));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentTypeGuid));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(doc.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentClass).Value)); //Technical or Non-Technical
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue((int)DocumentStatus.Required)); //Required
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, doc.GetAttributeValue<string>(DocumentListEntityAttributeName.PriortoStage));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(doc.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.PriortoStatus).Value));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(doc.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentCategory).Value));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, doc.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, doc.GetAttributeValue<bool>(DocumentListEntityAttributeName.AllowWaiver));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, false); //Always false for PAA documents.
                                service.Create(DocumentList);
                            }                            
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("Parent JF not found.");
                }
                #endregion
                crmTrace.AppendLine("CloneParentDocumentsOnPAA: End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n FaultException Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeoutException Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - CloneParentDocumentsOnPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nException Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static EntityCollection RetrieveParentDocumentsForPAA(IOrganizationService service, Guid JobFilngID, StringBuilder crmTrace)
        {
            EntityCollection docs = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start RetrieveParentDocumentsForPAA");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.ParentDocumentList, ConditionOperator.Null, new string[] { });
                ConditionExpression documentListCondition3 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentStatus, ConditionOperator.NotEqual, new object[] { (int)DocumentStatus.DeferralApproved });
                ConditionExpression documentListCondition4 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.Equal, new object[] { (int)CurrentFilingStatus.Approved });
                ColoumnName coloumns = new ColoumnName();
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, coloumns.DocumentList_Coloumns, new ConditionExpression[] { documentListCondition, documentListCondition2, documentListCondition3, documentListCondition4 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        docs.Entities.Add(ent);

                    }
                }
                crmTrace.AppendLine("End RetrieveParentDocumentsForPAA");
                return docs;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return docs;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - RetrieveParentDocumentsForPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }

        }

        #endregion

        #region Boiler Build Device Document Handling
        public static void PopulateBoilerBuildDeviceDocument(IOrganizationService service, Entity currentJobFilingRecord, Entity preTargetEntity, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.Clear();
                crmTrace.AppendLine("HandleBoilerBuildDeviceDocument: Start");

                if (targetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation) && (targetEntity.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation) != preTargetEntity.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation)))
                {
                    crmTrace.AppendLine("Chimney Attestation changed.");
                    string userGuid = string.Empty, chimneyUserEmail = string.Empty, chimneyUserName = string.Empty;
                    Entity chimneyUser = new Entity();

                    if (targetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup))
                    {
                        userGuid = ((EntityReference)targetEntity[BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup]).Id.ToString();                        
                    }
                    else if (preTargetEntity.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup))
                    {
                        userGuid = ((EntityReference)preTargetEntity[BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup]).Id.ToString();
                    }

                    if (!string.IsNullOrEmpty(userGuid))
                    {
                        chimneyUser = service.Retrieve(ContactEntityAttributeName.EntityLogicalName, Guid.Parse(userGuid), new ColumnSet(ContactEntityAttributeName.EmailContractor, ContactEntityAttributeName.FullName));
                        chimneyUserEmail = chimneyUser.GetAttributeValue<string>(ContactEntityAttributeName.EmailContractor);
                        chimneyUserName = chimneyUser.GetAttributeValue<string>(ContactEntityAttributeName.FullName);
                    }

                    crmTrace.AppendLine("UserGuid: " + userGuid);
                    crmTrace.AppendLine("ChimneyUserName: " + chimneyUserName);
                    crmTrace.AppendLine("ChimneyUserEmail: " + chimneyUserEmail);

                    string[] ColumnNames_DocumentType = { DocumentTypeEntityAttributeName.PortalDocumentDescription, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes };
                    ConditionExpression DTCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredforWorkTypes, ConditionOperator.Equal, new string[] { CommonStringConstants.ChimneyAttestationDocument });
                    EntityCollection DTResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, ColumnNames_DocumentType, new ConditionExpression[] { DTCondition }, LogicalOperator.And);

                    crmTrace.AppendLine("DTResponse.Entities.Count: " + DTResponse.Entities.Count);

                    if (DTResponse != null && DTResponse.Entities.Count > 0 && !string.IsNullOrEmpty(chimneyUserEmail))
                    {   
                        foreach (Entity DTRecord in DTResponse.Entities)
                        {
                            crmTrace.AppendLine("Chimney Attestation Master Record found.");

                            bool isChimneyAttested = targetEntity.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation);
                            string strDocumentName = DTRecord.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName) + " - " + chimneyUserEmail;
                            crmTrace.AppendLine("strDocumentName: " + strDocumentName);

                            ConditionExpression DLCADCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { currentJobFilingRecord.Id.ToString() });
                            ConditionExpression DLCADCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { strDocumentName });
                            EntityCollection DLCADResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName }, new ConditionExpression[] { DLCADCondition1, DLCADCondition2 }, LogicalOperator.And);
                            crmTrace.AppendLine("DLCADResponse.Entities.Count: " + DLCADResponse.Entities.Count);

                            if (DLCADResponse != null && DLCADResponse.Entities.Count > 0 && !isChimneyAttested)
                            {
                                //CAD Document Exists
                                #region Delete Document

                                ConditionExpression DeviceCondition1 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { currentJobFilingRecord.Id.ToString() });
                                ConditionExpression DeviceCondition2 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup, ConditionOperator.Equal, new string[] { userGuid });
                                ConditionExpression DeviceCondition3 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation, ConditionOperator.Equal, new object[] { true });
                                EntityCollection DeviceResponse = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber}, new ConditionExpression[] { DeviceCondition1, DeviceCondition2, DeviceCondition3 }, LogicalOperator.And);
                                crmTrace.AppendLine("DeviceResponse.Entities.Count: " + DeviceResponse.Entities.Count);

                                if(DeviceResponse.Entities.Count == 0)
                                {
                                    foreach (Entity DLCADRecord in DLCADResponse.Entities)
                                    {
                                        crmTrace.AppendLine("Chimney Attestation Document to delete: " + DLCADRecord.LogicalName);
                                        service.Delete(DLCADRecord.LogicalName, DLCADRecord.Id);
                                        crmTrace.AppendLine("Chimney Attestation Document deleted.");
                                    }
                                }
                                else
                                {
                                    crmTrace.AppendLine("Chimney user has more devices attested.");
                                }                                

                                #endregion
                            }
                            else if((DLCADResponse == null || DLCADResponse.Entities.Count == 0) && isChimneyAttested)
                            {
                                //CAD Document Doesn't Exists
                                #region Add Document

                                int documentClass = DTRecord.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value;
                                crmTrace.AppendLine("documentClass: " + documentClass.ToString());
                                string priorToStage = DTRecord.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                                crmTrace.AppendLine("priorToStage: " + priorToStage);
                                int priorToStatus = DTRecord.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                                crmTrace.AppendLine("priorToStatus: " + priorToStatus.ToString());
                                bool manuallySelected = false;
                                bool allowWaiver = DTRecord.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver);
                                crmTrace.AppendLine("allowWaiver: " + allowWaiver.ToString());
                                bool allowdeferral = DTRecord.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowDeferral);
                                crmTrace.AppendLine("allowdeferral: " + allowdeferral.ToString());

                                Entity DocumentList = new Entity();
                                DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, strDocumentName); //Document List Record Name
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, DTRecord.Id)); //Document Type Lookup
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, currentJobFilingRecord.Id)); // Job Filing Lookup
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentClass)); //Technical or Non-Technical
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(1)); //Required
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priorToStage);
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(priorToStatus));
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2)); //Supporting Document
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, manuallySelected);
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, allowWaiver);
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, allowdeferral);

                                crmTrace.AppendLine("Adding Chimney Attestation Document to the Document List.");
                                service.Create(DocumentList);
                                crmTrace.AppendLine("Added Chimney Attestation Document to the Document List.");
                                #endregion
                            }
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Chimney User not associated with the Device.");
                    }
                }
                else
                {
                    crmTrace.AppendLine("No change in Chimney Attestation.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout InnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateBoilerBuildDeviceDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteBoilerBuildDeviceDocument(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("DeleteBoilerBuildDeviceDocument: Start");
                string MCUserId = string.Empty, jobFilingId = string.Empty;                
                EntityCollection deviceResult = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetBoilerBuildDeviceById, targetEntity.Id.ToString())));
                
                crmTrace.AppendLine("deviceResult Count: " + deviceResult.Entities.Count.ToString());

                if (deviceResult != null && deviceResult.Entities.Count > 0)
                {
                    foreach (Entity deviceRecord in deviceResult.Entities)
                    {
                        if(deviceRecord.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet) && deviceRecord[BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet] != null)
                        {
                            crmTrace.AppendLine("Device Type: " + deviceRecord.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet).Value);
                            if(deviceRecord.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet).Value == 2)
                            {
                                crmTrace.AppendLine("Get Devide Record details.");
                                crmTrace.AppendLine("Job Id: " + deviceRecord.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling).Id);
                                crmTrace.AppendLine("User Id: " + deviceRecord.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup).Id);
                                jobFilingId = deviceRecord.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling).Id.ToString();
                                crmTrace.AppendLine("jobFilingId: " + jobFilingId);
                                MCUserId = deviceRecord.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup).Id.ToString();
                                crmTrace.AppendLine("MCUserId: " + MCUserId);

                                if (!string.IsNullOrEmpty(MCUserId) && !string.IsNullOrEmpty(jobFilingId))
                                {
                                    string chimneyUserEmail = string.Empty, chimneyUserName = string.Empty;

                                    ConditionExpression BDDCondition1 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingId });
                                    ConditionExpression BDDCondition2 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.ChimneyUserLookup, ConditionOperator.Equal, new string[] { MCUserId });
                                    ConditionExpression BDDCondition3 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.ChimneyAttenstation, ConditionOperator.Equal, new object[] { true });
                                    ConditionExpression BDDCondition4 = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet, ConditionOperator.Equal, new object[] { 2 });

                                    EntityCollection BDDResponse = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute, BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber }, new ConditionExpression[] { BDDCondition1, BDDCondition2, BDDCondition3, BDDCondition4 }, LogicalOperator.And);
                                    crmTrace.AppendLine("BDDResponse.Entities.Count: " + BDDResponse.Entities.Count);

                                    if (BDDResponse != null && BDDResponse.Entities.Count == 1)
                                    {
                                        Entity chimneyUser = new Entity();

                                        if (!string.IsNullOrEmpty(MCUserId))
                                        {
                                            chimneyUser = service.Retrieve(ContactEntityAttributeName.EntityLogicalName, Guid.Parse(MCUserId), new ColumnSet(ContactEntityAttributeName.EmailContractor, ContactEntityAttributeName.FullName));
                                            chimneyUserEmail = chimneyUser.GetAttributeValue<string>(ContactEntityAttributeName.EmailContractor);
                                            chimneyUserName = chimneyUser.GetAttributeValue<string>(ContactEntityAttributeName.FullName);
                                        }
                                        
                                        string chimneyDocumentName = DocumentTypeNames.ChimneyAttestationDocument + " - " + chimneyUserEmail;

                                        crmTrace.AppendLine("ChimneyUserName: " + chimneyUserName);
                                        crmTrace.AppendLine("ChimneyUserEmail: " + chimneyUserEmail);                                        
                                        crmTrace.AppendLine("chimneyDocumentName: " + chimneyDocumentName);

                                        ConditionExpression DLBDDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { jobFilingId });
                                        ConditionExpression DLBDDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { chimneyDocumentName });
                                        EntityCollection DLBDDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.ManuallySelected, DocumentListEntityAttributeName.DocumentStatus }, new ConditionExpression[] { DLBDDCondition1, DLBDDCondition2 }, LogicalOperator.And);
                                        crmTrace.AppendLine("DLBDDResponse.Entities.Count: " + DLBDDResponse.Entities.Count);

                                        if (DLBDDResponse != null && DLBDDResponse.Entities.Count == 1)
                                        {
                                            crmTrace.AppendLine("Chimney Attestation Document to delete: " + DLBDDResponse.Entities[0].LogicalName);
                                            service.Delete(DLBDDResponse.Entities[0].LogicalName, DLBDDResponse.Entities[0].Id);
                                            crmTrace.AppendLine("Chimney Attestation Document deleted.");                                            
                                        }
                                    }
                                }
                                else
                                {
                                    crmTrace.AppendLine("Job Filing or Chimney User is not available.");
                                }
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Existing Device - No need to delete document.");
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine("No Device details found");
                }

                crmTrace.AppendLine("DeleteBoilerBuildDeviceDocument: End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout InnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteBoilerBuildDeviceDocument", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        #region L2 Document Population

        public static void PopulateL2DocumentsforViolations(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("PopulateL2DocumentsforViolations: Start");
            try
            {
                ConditionExpression VCCondition = CreateConditionExpression(ViolationsCodesAttributeNames.GoToL2Request, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection VCResponse = RetrieveMultiple(service, ViolationsCodesAttributeNames.EntityLogicalName, new string[] { ViolationsCodesAttributeNames.ViolationNumber, ViolationsCodesAttributeNames.L2Code, ViolationsCodesAttributeNames.GoToL2Request, ViolationsCodesAttributeNames.GoToJobFiling }, new ConditionExpression[] { VCCondition }, LogicalOperator.And);

                crmTrace.AppendLine("VCResponse.Entities.Count: " + VCResponse.Entities.Count);

                if (VCResponse != null || VCResponse.Entities.Count > 0)
                {
                    foreach(Entity VCRecord in VCResponse.Entities)
                    {
                        crmTrace.AppendLine("Populate Documents from L2 - Start");
                        PopulateL2Documents(service, VCRecord, crmTrace);
                        crmTrace.AppendLine("Populate Documents from L2 - End");
                    }
                }
                    crmTrace.AppendLine("PopulateL2DocumentsforViolations: End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2DocumentsforViolations", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void PopulateL2Documents(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("PopulateL2Documents: Start");
            try
            {
                crmTrace.AppendLine("Get L2 Document Configurations: Start");
                crmTrace.AppendLine("Configuration: " + string.Format(FetchXml.GetDocumentConfigurationByWorkType, WorkTypes.L2));
                EntityCollection configurationResult = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetDocumentConfigurationByWorkType, WorkTypes.L2)));
                crmTrace.AppendLine("configurationResult.Entities.Count: " + configurationResult.Entities.Count);

                if (configurationResult != null && configurationResult.Entities.Count > 0)
                {
                    foreach (Entity configRecord in configurationResult.Entities)
                    {
                        crmTrace.AppendLine("Get L2 Conditional XML from Config record.");
                        crmTrace.AppendLine("Target Id: " + targetEntity.Id.ToString());

                        string conditionalXML = configRecord.GetAttributeValue<string>(DocumentsRequiredConfigurationsEntityAttibuteName.ConditionalXML);
                        string strDocumentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name;
                        crmTrace.AppendLine("strDocumentName: " + strDocumentName);
                        crmTrace.AppendLine("Conditional XML: " + conditionalXML);
                        if (!string.IsNullOrEmpty(conditionalXML))
                        {
                            string goToL2RequestId = string.Empty, violationNumber = string.Empty;

                            if (targetEntity.Attributes.Contains(ViolationsCodesAttributeNames.GoToL2Request))
                            {
                                goToL2RequestId = ((EntityReference)targetEntity[ViolationsCodesAttributeNames.GoToL2Request]).Id.ToString();
                                crmTrace.AppendLine("TargetEntity Entity Contains L2 Request Id:" + goToL2RequestId);
                                if (targetEntity.Attributes.Contains(ViolationsCodesAttributeNames.ViolationNumber))
                                {
                                    violationNumber = targetEntity.GetAttributeValue<string>(ViolationsCodesAttributeNames.ViolationNumber);
                                }
                            }
                            else
                            {
                                Entity violationsCodes = service.Retrieve(ViolationsCodesAttributeNames.EntityLogicalName, targetEntity.Id, new ColumnSet(ViolationsCodesAttributeNames.ViolationNumber, ViolationsCodesAttributeNames.GoToL2Request, ViolationsCodesAttributeNames.L2Code, ViolationsCodesAttributeNames.GoToJobFiling));
                                goToL2RequestId = ((EntityReference)violationsCodes[ViolationsCodesAttributeNames.GoToL2Request]).Id.ToString();
                                violationNumber = violationsCodes.GetAttributeValue<string>(ViolationsCodesAttributeNames.ViolationNumber);
                                crmTrace.AppendLine("Entity Contains L2 Request Id:" + goToL2RequestId);
                            }

                            crmTrace.AppendLine("goToL2RequestId: " + goToL2RequestId);
                            crmTrace.AppendLine("violationNumber: " + violationNumber);

                            if(goToL2RequestId != string.Empty && violationNumber != string.Empty)
                            {
                                EntityCollection conditionRecCount = service.RetrieveMultiple(new FetchExpression(string.Format(conditionalXML, goToL2RequestId, violationNumber)));
                                crmTrace.AppendLine("Documents count:" + conditionRecCount.Entities.Count.ToString());

                                if (conditionRecCount.Entities != null && conditionRecCount.Entities.Count > 0)
                                {
                                    crmTrace.AppendLine("Add L2 Required Document");
                                    AddL2Document(service, targetEntity, configRecord, goToL2RequestId, violationNumber, crmTrace);
                                }
                                else
                                {
                                    crmTrace.AppendLine("Delete L2 Required Document");
                                    DeleteL2Document(service, targetEntity, configRecord, goToL2RequestId, violationNumber, crmTrace);
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("L2 Request id or Violation Number is null.");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("No Conditional XML found in Configuration for L2");
                        }
                    }
                }
                crmTrace.AppendLine("PopulateL2Documents: End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details: " + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Fault Exception."));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Timeout Exception."), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - PopulateL2Documents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Exception."), null);
            }
        }

        public static void AddL2Document(IOrganizationService service, Entity targetEntity, Entity configRecord, string goToL2RequestId, string violationNumber, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("AddL2Document: Start");
            try
            {
                string strDocumentName = violationNumber +"_" + configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name;
                crmTrace.AppendLine("L2 documentName: " + strDocumentName);
                string requiredforWorkType = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.RequiredforWorkTypes).Value.ToString();
                Guid documentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Id;
                crmTrace.AppendLine("L2 requiredforWorkTypes: " + requiredforWorkType);

                if (requiredforWorkType.Contains(WorkTypes.L2))
                {
                    crmTrace.AppendLine("L2 Documents.");
                    ConditionExpression RDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.GoToL2Request, ConditionOperator.Equal, new string[] { goToL2RequestId });
                    ConditionExpression RDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { strDocumentName });
                    EntityCollection RDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.ManuallySelected, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { RDCondition1, RDCondition2 }, LogicalOperator.And);

                    crmTrace.AppendLine("L2 RDResponse.Entities.Count: " + RDResponse.Entities.Count);

                    if (RDResponse != null && RDResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("L2 Document already exists.");
                    }
                    else
                    {                        
                        int documentClass = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.DocumentClass).Value).Value;
                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                        int priorToStatus = ((OptionSetValue)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStatus).Value).Value;
                        crmTrace.AppendLine("priorToStatus:" + priorToStatus.ToString());

                        string priorToStage = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.PriortoStage).Value.ToString();
                        crmTrace.AppendLine("priorToStage:" + priorToStage);

                        string requiredItemNumber = configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.RequiredItemNumber).Value.ToString();
                        crmTrace.AppendLine("requiredItemNumber:" + requiredItemNumber);

                        bool manuallySelected = false;

                        bool allowWaiver = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowWaiver).Value);
                        crmTrace.AppendLine("allowWaiver: " + allowWaiver.ToString());
                        bool allowdeferral = ((bool)configRecord.GetAttributeValue<AliasedValue>(DocumentTypeEntityAttributeName.EntityLogicalName + "." + DocumentTypeEntityAttributeName.AllowDeferral).Value);
                        crmTrace.AppendLine("allowdeferral: " + allowdeferral.ToString());


                        crmTrace.AppendLine("documentName:" + strDocumentName);
                        crmTrace.AppendLine("documentName Id:" + documentName.ToString());
                        crmTrace.AppendLine("jobFilingId:" + targetEntity.Id.ToString());
                        crmTrace.AppendLine("documentClass:" + documentClass.ToString());

                        Entity DocumentList = new Entity();
                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, strDocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentName));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GoToL2Request, new EntityReference(L2RequestAttributeNames.EntityLogicalName, Guid.Parse(goToL2RequestId)));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentClass)); //Technical or Non-Technical
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(1)); //Required
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priorToStage);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(priorToStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2)); //Supporting Document

                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, manuallySelected);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, allowWaiver);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, allowdeferral);
                        service.Create(DocumentList);

                        crmTrace.AppendLine("Added L2 Required Document to the Document List.");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Not L2 documents.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - AddL2Document", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteL2Document(IOrganizationService service, Entity targetEntity, Entity configRecord, string goToL2RequestId, string violationNumber, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("DeleteL2Document: Start");
            try
            {
                string strDocumentName = violationNumber + "_" + configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name;
                crmTrace.AppendLine("L2 documentName: " + strDocumentName);
                crmTrace.AppendLine("L2 Document Name " + configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name);
                Guid documentName = configRecord.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Id;
                ConditionExpression RDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.GoToL2Request, ConditionOperator.Equal, new string[] { goToL2RequestId });
                ConditionExpression RDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { strDocumentName });
                EntityCollection RDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.ManuallySelected, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { RDCondition1, RDCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("RDResponse.Entities.Count " + RDResponse.Entities.Count);
                if (RDResponse != null && RDResponse.Entities.Count > 0)
                {
                    foreach (Entity RDRecord in RDResponse.Entities)
                    {
                        int documentStatus = RDRecord.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;

                        if (!RDRecord.GetAttributeValue<bool>(DocumentListEntityAttributeName.ManuallySelected))
                        {
                            crmTrace.AppendLine("L2 Required Document Record LogicalName to delete: " + RDRecord.LogicalName);
                            service.Delete(RDRecord.LogicalName, RDRecord.Id);
                        }
                        else
                        {
                            crmTrace.AppendLine("Manually selected documents can not be deleted automatically.");
                        }

                    }
                }
                else
                {
                    crmTrace.AppendLine("No L2 Required Documents to delete.");
                }
                crmTrace.AppendLine("DeleteL2Document - End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - DeleteL2Document", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void OnViolationsCodesDelete(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("OnViolationsCodesDelete: Start");
            try
            {
                string goToL2RequestId = ((EntityReference)targetEntity[ViolationsCodesAttributeNames.GoToL2Request]).Id.ToString();
                string violationNumber = targetEntity.GetAttributeValue<string>(ViolationsCodesAttributeNames.ViolationNumber);
                crmTrace.AppendLine("L2 goToL2RequestId: " + goToL2RequestId);
                crmTrace.AppendLine("L2 violationNumber Name " + violationNumber);

                ConditionExpression RDCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.GoToL2Request, ConditionOperator.Equal, new string[] { goToL2RequestId });
                ConditionExpression RDCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.RequiredItemNumber, ConditionOperator.BeginsWith, new string[] { violationNumber });
                EntityCollection RDResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.ManuallySelected, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { RDCondition1, RDCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("L2 RDResponse.Entities.Count " + RDResponse.Entities.Count);
                if (RDResponse != null && RDResponse.Entities.Count > 0)
                {
                    foreach (Entity RDRecord in RDResponse.Entities)
                    {
                        crmTrace.AppendLine("L2 Required Document Record LogicalName to delete: " + RDRecord.LogicalName);
                        service.Delete(RDRecord.LogicalName, RDRecord.Id);
                        crmTrace.AppendLine("L2 Required Document deleted.");
                    }
                }
                else
                {
                    crmTrace.AppendLine("No L2 Required Documents to delete.");
                }
                crmTrace.AppendLine("OnViolationsCodesDelete - End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InspectionComponentsAutoPopulationHandler - OnViolationsCodesDelete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        #endregion
    }
}
