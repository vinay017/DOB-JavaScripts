﻿using System;
using System.Collections.Generic;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.Helpers;
using Microsoft.Xrm.Sdk.Query;
using System.Linq;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class EODHandler : PluginHandlerBase
    {
        public static void NoGoodCheckCC(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            try
            {
                #region PA/TPA,MH Related    
                  
                #region variables
                decimal AmountDue = 0;
                decimal AmountPaid = 0;
                Entity EODResult = new Entity();
                #endregion
                if ((targetEntity.Attributes.Contains(EODAttributeNames.AHVLookup) && targetEntity[EODAttributeNames.AHVLookup] != null) || (targetEntity.Attributes.Contains(EODAttributeNames.WorkPermitLookup) && targetEntity[EODAttributeNames.WorkPermitLookup] != null) || (targetEntity.Attributes.Contains(EODAttributeNames.OP49Lookup) && targetEntity[EODAttributeNames.OP49Lookup] != null))
                {
                    return;
                }
                    if (targetEntity.Attributes.Contains(EODAttributeNames.JobFilingLookup) && targetEntity[EODAttributeNames.JobFilingLookup] != null)
                {
                    crmTrace.AppendLine("Contains : JobFilingLookup ID :" + targetEntity.GetAttributeValue<EntityReference>(EODAttributeNames.JobFilingLookup).Id);

                    #region Get Jobfiling Fields
                    EODResult = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)targetEntity[EODAttributeNames.JobFilingLookup]).Id, 
                        new ColumnSet(JobFilingEntityAttributeName.AmountDue, JobFilingEntityAttributeName.AmountPaid,
                        JobFilingEntityAttributeName.NoGoodCheckFlag, JobFilingEntityAttributeName.FailedPaymentHistoryGUID, 
                        JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.ANCheckBox,
                        JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerCheckBox, 
                        JobFilingEntityAttributeName.SprinklerWorkLegalization, JobFilingEntityAttributeName.StandPipeWorkType, 
                        JobFilingEntityAttributeName.JobNBorAltType,
                        JobFilingEntityAttributeName.TPACheckBox, JobFilingEntityAttributeName.PACheckBox,
                        JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.workTypesTextbox));

                    crmTrace.AppendLine("Contains : EODResult");

                    #endregion

                    #region PA/TPA Related
                    if (((EODResult.Contains(JobFilingEntityAttributeName.PACheckBox) && EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)) ||
                        (EODResult.Contains(JobFilingEntityAttributeName.TPACheckBox) && EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true))
                    {
                        if (EODResult != null)
                        {
                            EODResult.Id = (EODResult.GetAttributeValue<Guid>(JobFilingEntityAttributeName.JobFilingId));
                            EODResult.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            if (EODResult.Attributes[JobFilingEntityAttributeName.AmountDue] != null)
                            {
                                crmTrace.AppendLine("Contains : AmountDue");
                                AmountDue = EODResult.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value + targetEntity.GetAttributeValue<Money>(EODAttributeNames.MerchantAmount).Value;
                                EODResult.SetAttributeValue(JobFilingEntityAttributeName.AmountDue, new Money(AmountDue));
                                crmTrace.AppendLine(" EODResult Contains : AmountDue");
                            }
                            if (EODResult.Attributes[JobFilingEntityAttributeName.AmountPaid] != null && EODResult.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value > 0 && EODResult.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value >= targetEntity.GetAttributeValue<Money>(EODAttributeNames.MerchantAmount).Value)
                            {
                                crmTrace.AppendLine("Contains : AmountPaid");
                                AmountPaid = EODResult.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value - targetEntity.GetAttributeValue<Money>(EODAttributeNames.MerchantAmount).Value;
                                EODResult.SetAttributeValue(JobFilingEntityAttributeName.AmountPaid, new Money(AmountPaid));
                                crmTrace.AppendLine(" EODResult Contains : AmountPaid");
                            }
                            EODResult.SetAttributeValue(JobFilingEntityAttributeName.FailedPaymentHistoryGUID, targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId));
                        }
                        EODResult.SetAttributeValue(JobFilingEntityAttributeName.NoGoodCheckFlag, true);
                        service.Update(EODResult);
                        return;
                    }
                    #endregion

                #region Return if PL/SP/SD/AN
                bool IsWorkTypeEligible = false;
                    bool[] CheckFields = { EODResult.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox):false,
                    EODResult.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization):false,
                    EODResult.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox):false,
                    EODResult.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization):false,
                    EODResult.Attributes.Contains(JobFilingEntityAttributeName.StandPipeWorkType)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType):false,
                    EODResult.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox)? EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox):false};

                    crmTrace.AppendLine("Check if any Checkbox fields value is true -Start");
                    
                    //Linq to check if any of the check boxes are selected
                    IsWorkTypeEligible = CheckFields.Any((w => w.Equals(true)));

                    bool isHistoric = false;

                    isHistoric = EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling);

                    crmTrace.AppendLine("Check if any Checkbox fields value is true -End and isHistoric: " + isHistoric);

                    if (IsWorkTypeEligible)
                        return;


                    /* 
                      This implementation should run for 
                      Historic CC filings and
                      ALL FAB 4 filings (NEW and OLD) 
                     */

                    bool RetrunFlag = true;

                    FeeCalculationObject feeObject = new FeeCalculationObject();
                    if (EODResult.Contains(JobFilingEntityAttributeName.workTypesTextbox) && EODResult[JobFilingEntityAttributeName.workTypesTextbox] != null)
                    {
                        crmTrace.AppendLine("Calling setWorktypeFlagsinFeeObject from EOd plugin");
                        FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(EODResult, feeObject, crmTrace);

                        if (isHistoric && feeObject.IsCC)
                        {
                            crmTrace.AppendLine("isHistoric && feeObject.IsCC: " + isHistoric +" "+ feeObject.IsCC);
                            RetrunFlag = false;
                        }
                        else if (isHistoric && (feeObject.IsSG || feeObject.IsSH || feeObject.IsSF || feeObject.IsFN))
                        {
                            crmTrace.AppendLine("FAB JOB");
                            RetrunFlag = false;
                        }

                        if (RetrunFlag)
                            return;
                    }
                    else
                    {
                        crmTrace.AppendLine("Worktypes Textbox is empty");
                        return;
                    }


                    #endregion
                }
                #endregion

                #region Existing Code
                EntityCollection response = null;
                Entity entityObject = new Entity();
                Guid jobFilingId = new Guid();
                Guid result = new Guid();
                Entity JobFilingApp = new Entity();
                decimal existingAmountPaid = 0;
                decimal existingAdjustment = 0;
                decimal existingMerchantAmount = 0;
                decimal totalAmountDue = 0;
                string formulaeName = string.Empty;
                int counter = 1;

                crmTrace.AppendLine("Check if FrontEndRecord is present");
                if (targetEntity.Attributes.Contains(EODAttributeNames.FrontEndRecordId))
                {
                    //Formatting string to GUID
                    if (Guid.TryParse((targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId)), out result))
                    {
                        crmTrace.AppendLine("retrieve payment history record details- Start");
                        // retrive from old payment history--Merchant Amount,Exsisting Amount Paid,Jobfiling app
                        string[] ColumnNames_paymentHistory = new string[] { PaymentHistoryAttributeNames.MerchantAmount, PaymentHistoryAttributeNames.Amountpaid, PaymentHistoryAttributeNames.JobfilingLookup };
                        Entity PaymentHistory = Retrieve(service, ColumnNames_paymentHistory, result, PaymentHistoryAttributeNames.EntityLogicalName);
                        crmTrace.AppendLine("retrieve payment history record details- End");

                        crmTrace.AppendLine("Check if payment history not null" + PaymentHistory.Id);
                        if (PaymentHistory != null && PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.JobfilingLookup) && PaymentHistory[PaymentHistoryAttributeNames.JobfilingLookup] != null)
                        {
                            if (jobFilingId.Equals(new Guid()))
                            {
                                // retrieve amount due,adjustment, building type and Curc cut check box from Job filing application 
                                crmTrace.AppendLine("set JobfilingId");
                                jobFilingId = PaymentHistory.GetAttributeValue<EntityReference>(PaymentHistoryAttributeNames.JobfilingLookup).Id;
                                crmTrace.AppendLine("set JobfilingId1" + jobFilingId);

                                crmTrace.AppendLine(" Retrieve Job filing application details");
                                string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.EntityAttributeName, JobFilingEntityAttributeName.AmountDue, JobFilingEntityAttributeName.Refund, JobFilingEntityAttributeName.BuildingType, JobFilingEntityAttributeName.CCCheckBox, JobFilingEntityAttributeName.ConstructionFence, JobFilingEntityAttributeName.SidewalkShed, JobFilingEntityAttributeName.SupportedScaffold, JobFilingEntityAttributeName.Sign, JobFilingEntityAttributeName.AmountPaid, JobFilingEntityAttributeName.FilingFees };
                                JobFilingApp = Retrieve(service, ColumnNames_JobFiling, jobFilingId, JobFilingEntityAttributeName.EntityLogicalName);

                                // get amount paid from payment history to update the elevator application
                                crmTrace.AppendLine("set AmountPaid");
                                existingAmountPaid = Convert.ToDecimal(PaymentHistory.GetAttributeValue<string>(PaymentHistoryAttributeNames.Amountpaid));

                                // get Merchant Amount from payment history to update the elevator application
                                crmTrace.AppendLine("set MerchantAmount");
                                if (PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                                    existingMerchantAmount = PaymentHistory.GetAttributeValue<Money>(PaymentHistoryAttributeNames.MerchantAmount).Value;

                                // get Adjustment from Elevator application
                                crmTrace.AppendLine("set Adjustment");
                                if (JobFilingApp.Attributes.Contains(JobFilingEntityAttributeName.Refund))
                                    existingAdjustment = JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value;

                            }
                            crmTrace.AppendLine("Get check bounce fee transaction code");

                            crmTrace.AppendLine("Create new payment history");

                            Guid newPaymentHistory = FeeCalculationHelper.CreatePaymentHistory_NoGoodCheck(service, JobFilingApp, crmTrace);

                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history
                            crmTrace.AppendLine("Fetch Xml ");
                            string fetchXML = @"<?xml version='1.0'?>
                                                        <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                                                        <entity name='dobnyc_transactionhistory'> <attribute name='dobnyc_transactionhistoryid'/><attribute name='dobnyc_name'/>
                                                        <attribute name='createdon'/>
                                                        <attribute name='dobnyc_transactiontype'/>
                                                        <attribute name='dobnyc_transactioncode'/>
                                                        <attribute name='dobnyc_subsource'/>
                                                        <attribute name='dobnyc_revenuesource'/>
                                                        <attribute name='dobnyc_reportcategory'/>
                                                        <attribute name='dobnyc_fees'/>
                                                        <attribute name='dobnyc_budgetcode'/>
                                                        <attribute name='dobnyc_jobnumber'/>
                                                        <attribute name='dobnyc_th_transactioncode'/>
                                                        <order descending='false' attribute='dobnyc_name'/>
                                                        <filter type='and'><condition attribute='dobnyc_transactionid' value='" + result + @"' uitype='dobnyc_paymenthistory' operator='eq'/>
                                                        </filter>
                                                        </entity>
                                                        </fetch>";
                            crmTrace.AppendLine("End fetch xml for retrieving Oldthresponse ");
                            crmTrace.AppendLine("Oldthresponse from FetchXml- Start");
                            EntityCollection Oldthresponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
                            crmTrace.AppendLine("Oldthresponse from FetchXml- end");

                            if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                            {
                                foreach (Entity oldthhistory in Oldthresponse.Entities)
                                {
                                    crmTrace.AppendLine("create new transaction hsitory for new payment history");
                                    FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, oldthhistory, oldthhistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));
                                    if ((oldthhistory.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode) == TransactionCodes.CheckBounceFee))
                                    {
                                        crmTrace.AppendLine("Increment the counter");
                                        counter++;
                                    }
                                }
                            }

                            #region retrieve Check bounce Fee details

                            response = new EntityCollection();

                            crmTrace.AppendLine("retrieve fee type - check bounce");
                            crmTrace.AppendLine("formulae Name");
                            formulaeName = FeeCalculationHelper.BuildCalcName(JobFilingApp, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + formulaeName);
                            //Get fee calculation configuartion attributes 
                            crmTrace.AppendLine("get fee calculation configuration attributes");
                            response = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + response.Entities.Count);

                            #endregion

                            if (response != null && response.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.CheckBounce))
                            {
                                #region create Transaction history
                                //Add amount due attribute to targetentity object as CreateTransactionHistory uses this to set the Fee attribute value
                                crmTrace.AppendLine("Create transaction history for check bounce - start");
                                ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { TransactionCodes.CheckBounceFee });
                                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                                //added Payment History Id attribute while creating Transaction history record itself to associate
                                Guid tHistoryId = FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, transactioncodeResponse[0],
                                                                                                    new Money(Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                crmTrace.AppendLine("Create transaction history for check bounce - End");
                                #endregion

                                if (tHistoryId != new Guid())
                                {
                                    #region Update Elevator application entity
                                    crmTrace.AppendLine("update JobFiling appplication");
                                    entityObject = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                                    entityObject.Id = jobFilingId;


                                    if (existingMerchantAmount == existingAmountPaid)
                                    {

                                        totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFeeFineAttributeName, new Money(counter * Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money((JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value - existingMerchantAmount)));//amount paid=previous jobfiling amount paid- merchant amount
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                                    }

                                    else if (existingMerchantAmount < existingAmountPaid)
                                    {
                                        crmTrace.AppendLine("merchant amount is less than amount paid - start");
                                        if (existingAdjustment == 0)
                                        {
                                            totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                            crmTrace.AppendLine("if adjustment is 0" + totalAmountDue);
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment < (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])) - existingAdjustment;
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(0));
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment > (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = 0;
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(existingAdjustment - (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))));
                                        }
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFeeFineAttributeName, new Money(counter * Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        crmTrace.AppendLine("merchant amount is less than amount paid - end");
                                    }
                                    entityObject.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money((JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.FilingFees).Value + 20)));//total fee=prev totalfee +20;
                                    entityObject.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, newPaymentHistory.ToString());
                                    //update all fee fields in Jobfiling application
                                    service.Update(entityObject);
                                    #endregion

                                    #region Update PaymentHistory - reusing/replacing the same entity object
                                    crmTrace.AppendLine("update the payment history - start");
                                    entityObject = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                                    //pass new payment historyid(front end record id)
                                    entityObject.Id = newPaymentHistory;
                                    crmTrace.AppendLine("Set total fee in payment history");

                                    entityObject.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                                    crmTrace.AppendLine("Update Isposted to flase");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, false);
                                    crmTrace.AppendLine("set no good check flage to true");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckFlag, false);

                                    //Payment history record updated for flags
                                    service.Update(entityObject);
                                    crmTrace.AppendLine("update the payment history - end");
                                    #endregion
                                }
                                else
                                {
                                    crmTrace.AppendLine("Transaction history record creation failed");
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("Check bounce fee Response has no records");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Payment history Response has no records");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Frontend recordId incorrect format");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Frontend recordId is missing in target entity");
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }


        /// <summary>
        /// Used to calculate no good check fees and create PH and TH for jobfiling entity only for remaining entities it will return
        /// In Job fililing it will work for PL,SP,SD,AN,CC,FAB4,BE,MS,ST
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>

        public static void NoGoodCheckStandarization(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            FeeCalculationObject feeObject = new FeeCalculationObject();
            try
            {
                #region Get Jobfiling Related Details
                Entity EODResult = new Entity();


                if ((targetEntity.Attributes.Contains(EODAttributeNames.JobFilingLookup) && targetEntity[EODAttributeNames.JobFilingLookup] != null) && !targetEntity.Attributes.Contains(EODAttributeNames.WorkPermitLookup) && !targetEntity.Attributes.Contains(EODAttributeNames.AHVLookup))
                {
                    crmTrace.AppendLine("Contains : JobFilingLookup ID :" + targetEntity.GetAttributeValue<EntityReference>(EODAttributeNames.JobFilingLookup).Id);

                    EODResult = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)targetEntity[EODAttributeNames.JobFilingLookup]).Id, new ColumnSet(JobFilingEntityAttributeName.AmountDue, JobFilingEntityAttributeName.AmountPaid,
                    JobFilingEntityAttributeName.NoGoodCheckFlag, JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.zoningCharactersticsLookup, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.ProposeeBuildingStories, JobFilingEntityAttributeName.TotalConstructionFloorArea));
                    crmTrace.AppendLine("Contains : EODResult");

                }
                else
                {
                    crmTrace.AppendLine(" EOD is created for other entity not jobfiling so return ");
                    return;
                }
                #endregion

                #region Return if not a new jobfiling filing 
                if ((EODResult.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && EODResult[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && EODResult.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling))) //for Old job filings we should return
                {
                    crmTrace.AppendLine("Old Job filing So return");
                    return;
                }
                #endregion
                #region Get Work type flags
                if (EODResult.Contains(JobFilingEntityAttributeName.workTypesTextbox) && EODResult[JobFilingEntityAttributeName.workTypesTextbox] != null)
                {
                    crmTrace.AppendLine("Calling setWorktypeFlagsinFeeObject from EOd standardization");
                    FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(EODResult, feeObject, crmTrace);
                }
                else
                {
                    crmTrace.AppendLine("Worktypes Textbox is empty");
                    return;
                }

                #endregion
                #region execute only for valid worktypes 
                if (feeObject.IsPA || feeObject.IsTPA || feeObject.IsEL )
                {
                    crmTrace.AppendLine("Not eligible Worktypes ");
                    return;

                }

                #endregion

                #region Set Building Type

                FeeCalculationStandardizationHandler.GetBuildingTypeZoningcharactersticsInformation(service, EODResult, EODResult, crmTrace, feeObject);
                #endregion


                #region Existing Code
                EntityCollection response = null;
                EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
                Entity entityObject = new Entity();
                Guid jobFilingId = new Guid();
                Guid result = new Guid();
                Entity JobFilingApp = new Entity();
                decimal existingAmountPaid = 0;
                decimal existingAdjustment = 0;
                decimal existingMerchantAmount = 0;
                decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
                decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
                decimal totalAmountDue = 0;
                int counter = 1;

                crmTrace.AppendLine("Check if FrontEndRecord is present");
                if (targetEntity.Attributes.Contains(EODAttributeNames.FrontEndRecordId))
                {
                    //Formatting string to GUID
                    if (Guid.TryParse((targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId)), out result))
                    {
                        crmTrace.AppendLine("retrieve payment history record details- Start");
                        // retrive from old payment history--Merchant Amount,Exsisting Amount Paid,Jobfiling app
                        string[] ColumnNames_paymentHistory = new string[] { PaymentHistoryAttributeNames.MerchantAmount, PaymentHistoryAttributeNames.Amountpaid, PaymentHistoryAttributeNames.JobfilingLookup };
                        Entity PaymentHistory = Retrieve(service, ColumnNames_paymentHistory, result, PaymentHistoryAttributeNames.EntityLogicalName);
                        crmTrace.AppendLine("retrieve payment history record details- End");

                        crmTrace.AppendLine("Check if payment history not null" + PaymentHistory.Id);
                        if (PaymentHistory != null && PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.JobfilingLookup) && PaymentHistory[PaymentHistoryAttributeNames.JobfilingLookup] != null)
                        {
                            if (jobFilingId.Equals(new Guid()))
                            {
                                // retrieve amount due,adjustment, building type and Curc cut check box from Job filing application 
                                crmTrace.AppendLine("set JobfilingId");
                                jobFilingId = PaymentHistory.GetAttributeValue<EntityReference>(PaymentHistoryAttributeNames.JobfilingLookup).Id;
                                crmTrace.AppendLine("set JobfilingId1" + jobFilingId);

                                crmTrace.AppendLine(" Retrieve Job filing application details");
                                //string[] ColumnNames_Elevator = new string[] { ElevatorBuildAttributeNames.Name, ElevatorBuildAttributeNames.AmountDue, ElevatorBuildAttributeNames.NoGoodCheck, ElevatorBuildAttributeNames.Adjustment, ElevatorBuildAttributeNames.ReportStatus, ElevatorBuildAttributeNames.RevertedfromNoGoodCheck, ElevatorBuildAttributeNames.AmountPaid, ElevatorBuildAttributeNames.TotalFee, ElevatorBuildAttributeNames.IsSubmitted };// added amount paid column.
                                string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.EntityAttributeName, JobFilingEntityAttributeName.AmountDue, JobFilingEntityAttributeName.Refund, JobFilingEntityAttributeName.NoGoodCheckFee, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.AmountPaid, JobFilingEntityAttributeName.TotalFeeAttributeName };
                                JobFilingApp = Retrieve(service, ColumnNames_JobFiling, jobFilingId, JobFilingEntityAttributeName.EntityLogicalName);

                                // get amount paid from payment history to update the elevator application
                                crmTrace.AppendLine("set AmountPaid");
                                existingAmountPaid = Convert.ToDecimal(PaymentHistory.GetAttributeValue<string>(PaymentHistoryAttributeNames.Amountpaid));

                                // get Merchant Amount from payment history to update the elevator application
                                crmTrace.AppendLine("set MerchantAmount");
                                if (PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                                    existingMerchantAmount = PaymentHistory.GetAttributeValue<Money>(PaymentHistoryAttributeNames.MerchantAmount).Value;

                                // get Adjustment from Elevator application
                                crmTrace.AppendLine("set Adjustment");
                                if (JobFilingApp.Attributes.Contains(JobFilingEntityAttributeName.Refund))
                                    existingAdjustment = JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value;

                                #region Added Amount Due, No goodcheck
                                crmTrace.AppendLine("set ExistingAmountDue");
                                if (JobFilingApp.Attributes.Contains(JobFilingEntityAttributeName.AmountDue))
                                    existingAmountDue = JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value;
                                crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                                crmTrace.AppendLine("set Nogoodcheck");
                                if (JobFilingApp.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                                    existingNogoodCheck = JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                                crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                                #endregion

                            }
                            crmTrace.AppendLine("Get check bounce fee transaction code");


                            #region Check any other PH with isPosted No and No Good Check No
                            crmTrace.AppendLine("Get all openOldPaymentHistories");
                            EntityCollection openOldPaymentHistories = CountOldPaymentHistory(service, crmTrace, PaymentHistoryAttributeNames.JobfilingLookup, JobFilingApp);
                            crmTrace.AppendLine(" openOldPaymentHistories Count: " + openOldPaymentHistories.Entities.Count);
                            crmTrace.AppendLine("Get all openOldPaymentHistory Transaction Histories");

                            if (openOldPaymentHistories != null && openOldPaymentHistories.Entities.Count > 0)
                            {
                                foreach (Entity openOldPH in openOldPaymentHistories.Entities)
                                {
                                    EntityCollection IndividualopenOldPaymentHistoryTHs = new EntityCollection();
                                    IndividualopenOldPaymentHistoryTHs = getTransactionHistoriesforPH(service, crmTrace, openOldPH.Id);
                                    crmTrace.AppendLine("Count of IndividualopenOldPaymentHistoryTHs " + IndividualopenOldPaymentHistoryTHs.Entities.Count);

                                    crmTrace.AppendLine("Add TH to Global TH Variable");
                                    if (IndividualopenOldPaymentHistoryTHs != null && IndividualopenOldPaymentHistoryTHs.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Loop through TH's");
                                        foreach (Entity openOldPaymentHistoryTH in IndividualopenOldPaymentHistoryTHs.Entities)
                                        {
                                            crmTrace.AppendLine("Add to Collection");
                                            allOpenOldTransactionHistoryresponse.Entities.Add(openOldPaymentHistoryTH);
                                        }
                                    }
                                    crmTrace.AppendLine("Delete old payment history records -start");
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, openOldPH.Id);
                                    crmTrace.AppendLine("Delete old payment history records- - end");
                                }
                                // throw new Exception("Test");
                            }

                            #endregion




                            crmTrace.AppendLine("Create new payment history");

                            Guid newPaymentHistory = FeeCalculationHelper.CreatePaymentHistory_NoGoodCheck(service, JobFilingApp, crmTrace);

                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history
                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                            EntityCollection Oldthresponse = getTransactionHistoriesforPH(service, crmTrace, result);

                            crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);

                            if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                            {
                                foreach (Entity oldthhistory in Oldthresponse.Entities)
                                {
                                    #region Add oldthhistory to Global TH's
                                    allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                                    #endregion

                                }
                            }
                            crmTrace.AppendLine("Oldthresponse from FetchXml- end");

                            #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                            if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                            {
                                foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                                {
                                    crmTrace.AppendLine("create new transaction history for new payment history");
                                    FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                                }

                            }
                            #endregion

                            #region retrieve Check bounce Fee details

                            response = new EntityCollection();

                            crmTrace.AppendLine("retrieve fee type - check bounce");
                            crmTrace.AppendLine("formulae Name");
                            string formulaeName = FeeCalculationStandardizationHandler.BuildFormualeName(EODResult, EODResult, crmTrace, JobFilingEntityAttributeName.BoilersBuildIdentifier, feeObject);
                            crmTrace.AppendLine("Response from fee calculation config " + formulaeName);
                            //Get fee calculation configuartion attributes 
                            crmTrace.AppendLine("get fee calculation configuration attributes");
                            response = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + response.Entities.Count);

                            #endregion

                            if (response != null && response.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.CheckBounce))
                            {
                                #region create Transaction history
                                //Add amount due attribute to targetentity object as CreateTransactionHistory uses this to set the Fee attribute value
                                crmTrace.AppendLine("Create transaction history for check bounce - start");
                                ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { TransactionCodes.CheckBounceFee });
                                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                                //added Payment History Id attribute while creating Transaction history record itself to associate
                                Guid tHistoryId = FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, transactioncodeResponse[0],
                                                                                                    new Money(Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                crmTrace.AppendLine("Create transaction history for check bounce - End");
                                #endregion

                                if (tHistoryId != new Guid())
                                {
                                    #region Update Elevator application entity
                                    crmTrace.AppendLine("update JobFiling appplication");
                                    entityObject = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                                    entityObject.Id = jobFilingId;


                                    if (existingMerchantAmount == existingAmountPaid)
                                    {

                                        totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]) + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFeeFineAttributeName, new Money(existingNogoodCheck + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money((JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value - existingMerchantAmount)));//amount paid=previous jobfiling amount paid- merchant amount
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                                    }

                                    else if (existingMerchantAmount < existingAmountPaid)
                                    {
                                        crmTrace.AppendLine("merchant amount is less than amount paid - start");
                                        if (existingAdjustment == 0)
                                        {
                                            totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                            crmTrace.AppendLine("if adjustment is 0" + totalAmountDue);
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment < (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])) - existingAdjustment;
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(0));
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment > (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = 0;
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(totalAmountDue));
                                            entityObject.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(existingAdjustment - (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))));
                                        }
                                        entityObject.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFeeFineAttributeName, new Money(counter * Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        crmTrace.AppendLine("merchant amount is less than amount paid - end");
                                    }
                                    entityObject.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money((JobFilingApp.GetAttributeValue<Money>(JobFilingEntityAttributeName.FilingFees).Value + 20)));//total fee=prev totalfee +20;
                                    entityObject.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, newPaymentHistory.ToString());
                                    //update all fee fields in Jobfiling application
                                    service.Update(entityObject);
                                    #endregion

                                    #region Update PaymentHistory - reusing/replacing the same entity object
                                    crmTrace.AppendLine("update the payment history - start");
                                    entityObject = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                                    //pass new payment historyid(front end record id)
                                    entityObject.Id = newPaymentHistory;
                                    crmTrace.AppendLine("Set total fee in payment history");

                                    entityObject.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                                    crmTrace.AppendLine("Update Isposted to flase");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, false);
                                    crmTrace.AppendLine("set no good check flage to true");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckFlag, false);

                                    //Payment history record updated for flags
                                    service.Update(entityObject);
                                    crmTrace.AppendLine("update the payment history - end");
                                    #endregion
                                }
                                else
                                {
                                    crmTrace.AppendLine("Transaction history record creation failed");
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("Check bounce fee Response has no records");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Payment history Response has no records");
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Frontend recordId incorrect format");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Frontend recordId is missing in target entity");
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
        }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckCC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }





        /// <summary>
        /// Used to calculate no good check fees and create PH and TH for OP49 entity only for remaining entities it will return
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>

        public static void NoGoodCheckStandarizationOP49(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            FeeCalculationObject feeObject = new FeeCalculationObject();
            try
            {
                #region Get Jobfiling Related Details
                Entity EODResult = new Entity();

                #endregion

                #region Existing Code
                EntityCollection response = null;
                EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
                Entity entityObject = new Entity();
                Guid jobFilingId = new Guid();
                Guid result = new Guid();
                Entity JobFilingApp = new Entity();
                decimal existingAmountPaid = 0;
                decimal existingAdjustment = 0;
                decimal existingMerchantAmount = 0;
                decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
                decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
                decimal totalAmountDue = 0;
                int counter = 1;

                crmTrace.AppendLine("Check if FrontEndRecord is present");
                if (targetEntity.Attributes.Contains(EODAttributeNames.FrontEndRecordId))
                {
                    //Formatting string to GUID
                    if (Guid.TryParse((targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId)), out result))
                    {
                        crmTrace.AppendLine("retrieve payment history record details- Start");
                        // retrive from old payment history--Merchant Amount,Exsisting Amount Paid,Jobfiling app
                        string[] ColumnNames_paymentHistory = new string[] { PaymentHistoryAttributeNames.MerchantAmount, PaymentHistoryAttributeNames.Amountpaid, PaymentHistoryAttributeNames.GoToOP49 };
                        Entity PaymentHistory = Retrieve(service, ColumnNames_paymentHistory, result, PaymentHistoryAttributeNames.EntityLogicalName);
                        crmTrace.AppendLine("retrieve payment history record details- End");

                        crmTrace.AppendLine("Check if payment history not null" + PaymentHistory.Id);
                        if (PaymentHistory != null && PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.GoToOP49) && PaymentHistory[PaymentHistoryAttributeNames.GoToOP49] != null)
                        {
                            if (jobFilingId.Equals(new Guid()))
                            {
                                // retrieve amount due,adjustment, building type and Curc cut check box from Job filing application 
                                crmTrace.AppendLine("set JobfilingId");
                                jobFilingId = PaymentHistory.GetAttributeValue<EntityReference>(PaymentHistoryAttributeNames.GoToOP49).Id;
                                crmTrace.AppendLine("set JobfilingId1" + jobFilingId);

                                crmTrace.AppendLine(" Retrieve Job filing application details");
                                //string[] ColumnNames_Elevator = new string[] { ElevatorBuildAttributeNames.Name, ElevatorBuildAttributeNames.AmountDue, ElevatorBuildAttributeNames.NoGoodCheck, ElevatorBuildAttributeNames.Adjustment, ElevatorBuildAttributeNames.ReportStatus, ElevatorBuildAttributeNames.RevertedfromNoGoodCheck, ElevatorBuildAttributeNames.AmountPaid, ElevatorBuildAttributeNames.TotalFee, ElevatorBuildAttributeNames.IsSubmitted };// added amount paid column.
                                string[] ColumnNames_JobFiling = new string[] { OP49EntityAttributeNames.Name, OP49EntityAttributeNames.AmountDue, OP49EntityAttributeNames.NoGoodCheckFee, OP49EntityAttributeNames.ReportStatus, OP49EntityAttributeNames.AmountPaid };
                                JobFilingApp = Retrieve(service, ColumnNames_JobFiling, jobFilingId, OP49EntityAttributeNames.EntityLogicalName);

                                // get amount paid from payment history to update the elevator application
                                crmTrace.AppendLine("set AmountPaid");
                                existingAmountPaid = Convert.ToDecimal(PaymentHistory.GetAttributeValue<string>(PaymentHistoryAttributeNames.Amountpaid));

                                // get Merchant Amount from payment history to update the elevator application
                                crmTrace.AppendLine("set MerchantAmount");
                                if (PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                                    existingMerchantAmount = PaymentHistory.GetAttributeValue<Money>(PaymentHistoryAttributeNames.MerchantAmount).Value;



                                #region Added Amount Due, No goodcheck
                                crmTrace.AppendLine("set ExistingAmountDue");
                                if (JobFilingApp.Attributes.Contains(OP49EntityAttributeNames.AmountDue))
                                    existingAmountDue = JobFilingApp.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountDue).Value;
                                crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                                crmTrace.AppendLine("set Nogoodcheck");
                                if (JobFilingApp.Attributes.Contains(OP49EntityAttributeNames.NoGoodCheckFee))
                                    existingNogoodCheck = JobFilingApp.GetAttributeValue<Money>(OP49EntityAttributeNames.NoGoodCheckFee).Value;
                                crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                                #endregion

                            }
                            crmTrace.AppendLine("Get check bounce fee transaction code");


                            #region Check any other PH with isPosted No and No Good Check No
                            crmTrace.AppendLine("Get all openOldPaymentHistories");
                            EntityCollection openOldPaymentHistories = CountOldPaymentHistory(service, crmTrace, PaymentHistoryAttributeNames.GoToOP49, JobFilingApp);
                            crmTrace.AppendLine(" openOldPaymentHistories Count: " + openOldPaymentHistories.Entities.Count);
                            crmTrace.AppendLine("Get all openOldPaymentHistory Transaction Histories");

                            if (openOldPaymentHistories != null && openOldPaymentHistories.Entities.Count > 0)
                            {
                                foreach (Entity openOldPH in openOldPaymentHistories.Entities)
                                {
                                    EntityCollection IndividualopenOldPaymentHistoryTHs = new EntityCollection();
                                    IndividualopenOldPaymentHistoryTHs = getTransactionHistoriesforPH(service, crmTrace, openOldPH.Id);
                                    crmTrace.AppendLine("Count of IndividualopenOldPaymentHistoryTHs " + IndividualopenOldPaymentHistoryTHs.Entities.Count);

                                    crmTrace.AppendLine("Add TH to Global TH Variable");
                                    if (IndividualopenOldPaymentHistoryTHs != null && IndividualopenOldPaymentHistoryTHs.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Loop through TH's");
                                        foreach (Entity openOldPaymentHistoryTH in IndividualopenOldPaymentHistoryTHs.Entities)
                                        {
                                            crmTrace.AppendLine("Add to Collection");
                                            allOpenOldTransactionHistoryresponse.Entities.Add(openOldPaymentHistoryTH);
                                        }
                                    }
                                    crmTrace.AppendLine("Delete old payment history records -start");
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, openOldPH.Id);
                                    crmTrace.AppendLine("Delete old payment history records- - end");
                                }
                                // throw new Exception("Test");
                            }

                            #endregion




                            crmTrace.AppendLine("Create new payment history");

                            Guid newPaymentHistory = FeeCalculationHelper.CreatePaymentHistory_NoGoodCheck(service, JobFilingApp, crmTrace);

                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history
                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                            EntityCollection Oldthresponse = getTransactionHistoriesforPH(service, crmTrace, result);

                            crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);

                            if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                            {
                                foreach (Entity oldthhistory in Oldthresponse.Entities)
                                {
                                    #region Add oldthhistory to Global TH's
                                    allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                                    #endregion

                                }
                            }
                            crmTrace.AppendLine("Oldthresponse from FetchXml- end");

                            #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                            if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                            {
                                foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                                {
                                    crmTrace.AppendLine("create new transaction history for new payment history");
                                    FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                                }

                            }
                            #endregion

                            #region retrieve Check bounce Fee details

                            response = new EntityCollection();

                            crmTrace.AppendLine("retrieve fee type - check bounce");
                            crmTrace.AppendLine("formulae Name");
                            string formulaeName = "OP49 Initial Fee Calculation";
                            crmTrace.AppendLine("Response from fee calculation config " + formulaeName);
                            //Get fee calculation configuartion attributes 
                            crmTrace.AppendLine("get fee calculation configuration attributes");
                            response = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + response.Entities.Count);

                            #endregion

                            if (response != null && response.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.CheckBounce))
                            {
                                #region create Transaction history
                                //Add amount due attribute to targetentity object as CreateTransactionHistory uses this to set the Fee attribute value
                                crmTrace.AppendLine("Create transaction history for check bounce - start");
                                ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { TransactionCodes.CheckBounceFee });
                                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                                //added Payment History Id attribute while creating Transaction history record itself to associate
                                Guid tHistoryId = FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, transactioncodeResponse[0],
                                                                                                    new Money(Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                crmTrace.AppendLine("Create transaction history for check bounce - End");
                                #endregion

                                if (tHistoryId != new Guid())
                                {
                                    #region Update Elevator application entity
                                    crmTrace.AppendLine("update JobFiling appplication");
                                    entityObject = new Entity(OP49EntityAttributeNames.EntityLogicalName);
                                    entityObject.Id = jobFilingId;


                                    if (existingMerchantAmount == existingAmountPaid)
                                    {

                                        totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]) + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                        entityObject.Attributes.Add(OP49EntityAttributeNames.AmountDue, new Money(totalAmountDue));
                                        entityObject.Attributes.Add(OP49EntityAttributeNames.NoGoodCheckFee, new Money(existingNogoodCheck + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        entityObject.Attributes.Add(OP49EntityAttributeNames.AmountPaid, new Money((JobFilingApp.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountPaid).Value - existingMerchantAmount)));//amount paid=previous jobfiling amount paid- merchant amount
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                                    }

                                    else if (existingMerchantAmount < existingAmountPaid)
                                    {
                                        crmTrace.AppendLine("merchant amount is less than amount paid - start");
                                        if (existingAdjustment == 0)
                                        {
                                            totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                            crmTrace.AppendLine("if adjustment is 0" + totalAmountDue);
                                            entityObject.Attributes.Add(OP49EntityAttributeNames.AmountDue, new Money(totalAmountDue));
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment < (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])) - existingAdjustment;
                                            entityObject.Attributes.Add(OP49EntityAttributeNames.AmountDue, new Money(totalAmountDue));

                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment > (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = 0;
                                            entityObject.Attributes.Add(OP49EntityAttributeNames.AmountDue, new Money(totalAmountDue));

                                        }

                                        crmTrace.AppendLine("merchant amount is less than amount paid - end");
                                    }

                                    entityObject.Attributes.Add(OP49EntityAttributeNames.PhGuid, newPaymentHistory.ToString());
                                    //update all fee fields in Jobfiling application

                                    #region set OP49 report Status and Revert from No good check Status


                                    if (JobFilingApp.Contains(OP49EntityAttributeNames.ReportStatus))
                                    {
                                        crmTrace.AppendLine("check if JobFilingApp contains report status - start");

                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling-no goodcheck status to report status");
                                        entityObject.Attributes.Add(OP49EntityAttributeNames.ReportStatus, new OptionSetValue(7)); //no good check status
                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling status to Reverted from NoGoodCheck");
                                        entityObject.Attributes.Add(OP49EntityAttributeNames.RevertedFromNGC, new OptionSetValue(JobFilingApp.GetAttributeValue<OptionSetValue>(OP49EntityAttributeNames.ReportStatus).Value));

                                    }
                                    #endregion


                                    service.Update(entityObject);
                                    #endregion

                                    #region Update PaymentHistory - reusing/replacing the same entity object
                                    crmTrace.AppendLine("update the payment history - start");
                                    entityObject = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                                    //pass new payment historyid(front end record id)
                                    entityObject.Id = newPaymentHistory;
                                    crmTrace.AppendLine("Set total fee in payment history");

                                    entityObject.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                                    crmTrace.AppendLine("Update Isposted to flase");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, false);
                                    crmTrace.AppendLine("set no good check flage to true");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckFlag, false);

                                    //Payment history record updated for flags
                                    service.Update(entityObject);
                                    crmTrace.AppendLine("update the payment history - end");
                                    #endregion
                                }
                                else
                                {
                                    crmTrace.AppendLine("Transaction history record creation failed");
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("Check bounce fee Response has no records");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Payment history is created for OP49 so returning");
                            return;
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Frontend recordId incorrect format");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Frontend recordId is missing in target entity");
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }




        public static void NoGoodCheckStandarizationPW2(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            FeeCalculationObject feeObject = new FeeCalculationObject();
            try
            {
                #region Get Jobfiling Related Details
                Entity EODResult = new Entity();

                #endregion

                #region Existing Code
                EntityCollection response = null;
                EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
                Entity entityObject = new Entity();
                Guid jobFilingId = new Guid();
                Guid result = new Guid();
                Entity JobFilingApp = new Entity();
                decimal existingAmountPaid = 0;
                decimal existingAdjustment = 0;
                decimal existingMerchantAmount = 0;
                decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
                decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
                decimal totalAmountDue = 0;
               

                crmTrace.AppendLine("Check if FrontEndRecord is present");
                if (targetEntity.Attributes.Contains(EODAttributeNames.FrontEndRecordId))
                {
                    //Formatting string to GUID
                    if (Guid.TryParse((targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId)), out result))
                    {
                        crmTrace.AppendLine("retrieve payment history record details- Start");
                        // retrive from old payment history--Merchant Amount,Exsisting Amount Paid,Jobfiling app
                        string[] ColumnNames_paymentHistory = new string[] { PaymentHistoryAttributeNames.MerchantAmount, PaymentHistoryAttributeNames.Amountpaid, PaymentHistoryAttributeNames.GoToPw2 };
                        Entity PaymentHistory = Retrieve(service, ColumnNames_paymentHistory, result, PaymentHistoryAttributeNames.EntityLogicalName);
                        crmTrace.AppendLine("retrieve payment history record details- End");

                        crmTrace.AppendLine("Check if payment history not null" + PaymentHistory.Id);
                        if (PaymentHistory != null && PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.GoToPw2) && PaymentHistory[PaymentHistoryAttributeNames.GoToPw2] != null)
                        {
                            if (jobFilingId.Equals(new Guid()))
                            {
                                // retrieve amount due,adjustment, building type and Curc cut check box from Job filing application 
                                crmTrace.AppendLine("set JobfilingId");
                                jobFilingId = PaymentHistory.GetAttributeValue<EntityReference>(PaymentHistoryAttributeNames.GoToPw2).Id;
                                crmTrace.AppendLine("set JobfilingId1" + jobFilingId);

                                crmTrace.AppendLine(" Retrieve Job filing application details");
                                //string[] ColumnNames_Elevator = new string[] { ElevatorBuildAttributeNames.Name, ElevatorBuildAttributeNames.AmountDue, ElevatorBuildAttributeNames.NoGoodCheck, ElevatorBuildAttributeNames.Adjustment, ElevatorBuildAttributeNames.ReportStatus, ElevatorBuildAttributeNames.RevertedfromNoGoodCheck, ElevatorBuildAttributeNames.AmountPaid, ElevatorBuildAttributeNames.TotalFee, ElevatorBuildAttributeNames.IsSubmitted };// added amount paid column.
                                string[] ColumnNames_JobFiling = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.AmountDue, WorkPermitEntityAttributeName.NoGoodCheckFee, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.AmountPaid };
                                JobFilingApp = Retrieve(service, ColumnNames_JobFiling, jobFilingId, WorkPermitEntityAttributeName.EntityLogicalName);

                                // get amount paid from payment history to update the elevator application
                                crmTrace.AppendLine("set AmountPaid");
                                existingAmountPaid = Convert.ToDecimal(PaymentHistory.GetAttributeValue<string>(PaymentHistoryAttributeNames.Amountpaid));

                                // get Merchant Amount from payment history to update the elevator application
                                crmTrace.AppendLine("set MerchantAmount");
                                if (PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                                    existingMerchantAmount = PaymentHistory.GetAttributeValue<Money>(PaymentHistoryAttributeNames.MerchantAmount).Value;



                                #region Added Amount Due, No goodcheck
                                crmTrace.AppendLine("set ExistingAmountDue");
                                if (JobFilingApp.Attributes.Contains(WorkPermitEntityAttributeName.AmountDue))
                                    existingAmountDue = JobFilingApp.GetAttributeValue<decimal>(WorkPermitEntityAttributeName.AmountDue);
                                crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                                crmTrace.AppendLine("set Nogoodcheck");
                                if (JobFilingApp.Attributes.Contains(WorkPermitEntityAttributeName.NoGoodCheckFee))
                                    existingNogoodCheck = JobFilingApp.GetAttributeValue<Money>(WorkPermitEntityAttributeName.NoGoodCheckFee).Value;
                                crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                                #endregion

                            }
                            crmTrace.AppendLine("Get check bounce fee transaction code");


                            #region Check any other PH with isPosted No and No Good Check No
                            crmTrace.AppendLine("Get all openOldPaymentHistories");
                            EntityCollection openOldPaymentHistories = CountOldPaymentHistory(service, crmTrace, PaymentHistoryAttributeNames.GoToPw2, JobFilingApp);
                            crmTrace.AppendLine(" openOldPaymentHistories Count: " + openOldPaymentHistories.Entities.Count);
                            crmTrace.AppendLine("Get all openOldPaymentHistory Transaction Histories");

                            if (openOldPaymentHistories != null && openOldPaymentHistories.Entities.Count > 0)
                            {
                                foreach (Entity openOldPH in openOldPaymentHistories.Entities)
                                {
                                    EntityCollection IndividualopenOldPaymentHistoryTHs = new EntityCollection();
                                    IndividualopenOldPaymentHistoryTHs = getTransactionHistoriesforPH(service, crmTrace, openOldPH.Id);
                                    crmTrace.AppendLine("Count of IndividualopenOldPaymentHistoryTHs " + IndividualopenOldPaymentHistoryTHs.Entities.Count);

                                    crmTrace.AppendLine("Add TH to Global TH Variable");
                                    if (IndividualopenOldPaymentHistoryTHs != null && IndividualopenOldPaymentHistoryTHs.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Loop through TH's");
                                        foreach (Entity openOldPaymentHistoryTH in IndividualopenOldPaymentHistoryTHs.Entities)
                                        {
                                            crmTrace.AppendLine("Add to Collection");
                                            allOpenOldTransactionHistoryresponse.Entities.Add(openOldPaymentHistoryTH);
                                        }
                                    }
                                    crmTrace.AppendLine("Delete old payment history records -start");
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, openOldPH.Id);
                                    crmTrace.AppendLine("Delete old payment history records- - end");
                                }
                                // throw new Exception("Test");
                            }

                            #endregion




                            crmTrace.AppendLine("Create new payment history");

                            Guid newPaymentHistory = FeeCalculationHelper.CreatePaymentHistory_NoGoodCheck(service, JobFilingApp, crmTrace);

                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history
                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                            EntityCollection Oldthresponse = getTransactionHistoriesforPH(service, crmTrace, result);

                            crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);

                            if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                            {
                                foreach (Entity oldthhistory in Oldthresponse.Entities)
                                {
                                    #region Add oldthhistory to Global TH's
                                    allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                                    #endregion

                                }
                            }
                            crmTrace.AppendLine("Oldthresponse from FetchXml- end");

                            #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                            if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                            {
                                foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                                {
                                    crmTrace.AppendLine("create new transaction history for new payment history");
                                    FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                                }

                            }
                            #endregion

                            #region retrieve Check bounce Fee details

                            response = new EntityCollection();

                            crmTrace.AppendLine("retrieve fee type - check bounce");
                            crmTrace.AppendLine("formulae Name");
                            string formulaeName = "OP49 Initial Fee Calculation";
                            crmTrace.AppendLine("Response from fee calculation config " + formulaeName);
                            //Get fee calculation configuartion attributes 
                            crmTrace.AppendLine("get fee calculation configuration attributes");
                            response = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + response.Entities.Count);

                            #endregion

                            if (response != null && response.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.CheckBounce))
                            {
                                #region create Transaction history
                                //Add amount due attribute to targetentity object as CreateTransactionHistory uses this to set the Fee attribute value
                                crmTrace.AppendLine("Create transaction history for check bounce - start");
                                ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { TransactionCodes.CheckBounceFee });
                                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                                //added Payment History Id attribute while creating Transaction history record itself to associate
                                Guid tHistoryId = FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, transactioncodeResponse[0],
                                                                                                    new Money(Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                crmTrace.AppendLine("Create transaction history for check bounce - End");
                                #endregion

                                if (tHistoryId != new Guid())
                                {
                                    #region Update Elevator application entity
                                    crmTrace.AppendLine("update JobFiling appplication");
                                    entityObject = new Entity(WorkPermitEntityAttributeName.EntityLogicalName);
                                    entityObject.Id = jobFilingId;


                                    if (existingMerchantAmount == existingAmountPaid)
                                    {

                                        totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]) + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);
                                        entityObject.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, totalAmountDue);
                                        entityObject.Attributes.Add(WorkPermitEntityAttributeName.NoGoodCheckFee, new Money(existingNogoodCheck + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                        entityObject.Attributes.Add(WorkPermitEntityAttributeName.AmountPaid, JobFilingApp.GetAttributeValue<decimal>(WorkPermitEntityAttributeName.AmountPaid) - existingMerchantAmount);//amount paid=previous jobfiling amount paid- merchant amount
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                                    }

                                    else if (existingMerchantAmount < existingAmountPaid)
                                    {
                                        crmTrace.AppendLine("merchant amount is less than amount paid - start");
                                        if (existingAdjustment == 0)
                                        {
                                            totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                            crmTrace.AppendLine("if adjustment is 0" + totalAmountDue);
                                            entityObject.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, totalAmountDue);
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment < (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])) - existingAdjustment;
                                            entityObject.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, totalAmountDue);

                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment > (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = 0;
                                            entityObject.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, totalAmountDue);

                                        }

                                        crmTrace.AppendLine("merchant amount is less than amount paid - end");
                                    }

                                    entityObject.Attributes.Add(WorkPermitEntityAttributeName.PaymentHistoryGUID, newPaymentHistory.ToString());
                                    //update all fee fields in Jobfiling application

                                    #region set OP49 report Status and Revert from No good check Status


                                    if (JobFilingApp.Contains(WorkPermitEntityAttributeName.WorkPermitStatus))
                                    {
                                        crmTrace.AppendLine("check if JobFilingApp contains report status - start");

                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling-no goodcheck status to report status");
                                        entityObject.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue(15)); //no good check status
                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling status to Reverted from NoGoodCheck");
                                        entityObject.Attributes.Add(WorkPermitEntityAttributeName.RevertFromNGC, new OptionSetValue(JobFilingApp.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.WorkPermitStatus).Value));

                                    }
                                    #endregion


                                    service.Update(entityObject);
                                    #endregion

                                    #region Update PaymentHistory - reusing/replacing the same entity object
                                    crmTrace.AppendLine("update the payment history - start");
                                    entityObject = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                                    //pass new payment historyid(front end record id)
                                    entityObject.Id = newPaymentHistory;
                                    crmTrace.AppendLine("Set total fee in payment history");

                                    entityObject.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                                    crmTrace.AppendLine("Update Isposted to flase");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, false);
                                    crmTrace.AppendLine("set no good check flage to true");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckFlag, false);

                                    //Payment history record updated for flags
                                    service.Update(entityObject);
                                    crmTrace.AppendLine("update the payment history - end");
                                    #endregion
                                }
                                else
                                {
                                    crmTrace.AppendLine("Transaction history record creation failed");
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("Check bounce fee Response has no records");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Payment history is created for OP49 so returning");
                            return;
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Frontend recordId incorrect format");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Frontend recordId is missing in target entity");
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }




        public static void NoGoodCheckStandarizationPW5(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            FeeCalculationObject feeObject = new FeeCalculationObject();
            try
            {
                #region Get Jobfiling Related Details
                Entity EODResult = new Entity();

                #endregion

                #region Existing Code
                EntityCollection response = null;
                EntityCollection allOpenOldTransactionHistoryresponse = new EntityCollection(); //Global Collection to store all transaction histories both isposted no PH and No good check PH
                Entity entityObject = new Entity();
                Guid jobFilingId = new Guid();
                Guid result = new Guid();
                Entity JobFilingApp = new Entity();
                decimal existingAmountPaid = 0;
                decimal existingAdjustment = 0;
                decimal existingMerchantAmount = 0;
                decimal existingAmountDue = 0;//used to store if any amountdue is present on ELV1 app
                decimal existingNogoodCheck = 0;//used to store if any Nogoodcheck is present on ELV1 app
                decimal totalAmountDue = 0;


                crmTrace.AppendLine("Check if FrontEndRecord is present");
                if (targetEntity.Attributes.Contains(EODAttributeNames.FrontEndRecordId))
                {
                    //Formatting string to GUID
                    if (Guid.TryParse((targetEntity.GetAttributeValue<string>(EODAttributeNames.FrontEndRecordId)), out result))
                    {
                        crmTrace.AppendLine("retrieve payment history record details- Start");
                        // retrive from old payment history--Merchant Amount,Exsisting Amount Paid,Jobfiling app
                        string[] ColumnNames_paymentHistory = new string[] { PaymentHistoryAttributeNames.MerchantAmount, PaymentHistoryAttributeNames.Amountpaid, PaymentHistoryAttributeNames.GoToAHV };
                        Entity PaymentHistory = Retrieve(service, ColumnNames_paymentHistory, result, PaymentHistoryAttributeNames.EntityLogicalName);
                        crmTrace.AppendLine("retrieve payment history record details- End");

                        crmTrace.AppendLine("Check if payment history not null" + PaymentHistory.Id);
                        if (PaymentHistory != null && PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.GoToAHV) && PaymentHistory[PaymentHistoryAttributeNames.GoToAHV] != null)
                        {
                            if (jobFilingId.Equals(new Guid()))
                            {
                                // retrieve amount due,adjustment, building type and Curc cut check box from Job filing application 
                                crmTrace.AppendLine("set JobfilingId");
                                jobFilingId = PaymentHistory.GetAttributeValue<EntityReference>(PaymentHistoryAttributeNames.GoToAHV).Id;
                                crmTrace.AppendLine("set JobfilingId1" + jobFilingId);

                                crmTrace.AppendLine(" Retrieve Job filing application details");
                                //string[] ColumnNames_Elevator = new string[] { ElevatorBuildAttributeNames.Name, ElevatorBuildAttributeNames.AmountDue, ElevatorBuildAttributeNames.NoGoodCheck, ElevatorBuildAttributeNames.Adjustment, ElevatorBuildAttributeNames.ReportStatus, ElevatorBuildAttributeNames.RevertedfromNoGoodCheck, ElevatorBuildAttributeNames.AmountPaid, ElevatorBuildAttributeNames.TotalFee, ElevatorBuildAttributeNames.IsSubmitted };// added amount paid column.
                                string[] ColumnNames_JobFiling = new string[] { PW5AfterHoursAttributeNames.AHVname, PW5AfterHoursAttributeNames.AmountDue, PW5AfterHoursAttributeNames.NoGoodCheckFee, PW5AfterHoursAttributeNames.AHVPermitStatus, PW5AfterHoursAttributeNames.AmountPaid };
                                JobFilingApp = Retrieve(service, ColumnNames_JobFiling, jobFilingId, PW5AfterHoursAttributeNames.EntityLogicalName);

                                // get amount paid from payment history to update the elevator application
                                crmTrace.AppendLine("set AmountPaid");
                                existingAmountPaid = Convert.ToDecimal(PaymentHistory.GetAttributeValue<string>(PaymentHistoryAttributeNames.Amountpaid));

                                // get Merchant Amount from payment history to update the elevator application
                                crmTrace.AppendLine("set MerchantAmount");
                                if (PaymentHistory.Attributes.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                                    existingMerchantAmount = PaymentHistory.GetAttributeValue<Money>(PaymentHistoryAttributeNames.MerchantAmount).Value;



                                #region Added Amount Due, No goodcheck
                                crmTrace.AppendLine("set ExistingAmountDue");
                                if (JobFilingApp.Attributes.Contains(PW5AfterHoursAttributeNames.AmountDue))
                                    existingAmountDue = JobFilingApp.GetAttributeValue<decimal>(PW5AfterHoursAttributeNames.AmountDue);
                                crmTrace.AppendLine(" ExistingAmountDue value " + existingAmountDue);
                                crmTrace.AppendLine("set Nogoodcheck");
                                if (JobFilingApp.Attributes.Contains(PW5AfterHoursAttributeNames.NoGoodCheckFee))
                                    existingNogoodCheck = JobFilingApp.GetAttributeValue<Money>(PW5AfterHoursAttributeNames.NoGoodCheckFee).Value;
                                crmTrace.AppendLine(" NoGoodCheck value " + existingNogoodCheck);
                                #endregion

                            }
                            crmTrace.AppendLine("Get check bounce fee transaction code");


                            #region Check any other PH with isPosted No and No Good Check No
                            crmTrace.AppendLine("Get all openOldPaymentHistories");
                            EntityCollection openOldPaymentHistories = CountOldPaymentHistory(service, crmTrace, PaymentHistoryAttributeNames.GoToAHV, JobFilingApp);
                            crmTrace.AppendLine(" openOldPaymentHistories Count: " + openOldPaymentHistories.Entities.Count);
                            crmTrace.AppendLine("Get all openOldPaymentHistory Transaction Histories");

                            if (openOldPaymentHistories != null && openOldPaymentHistories.Entities.Count > 0)
                            {
                                foreach (Entity openOldPH in openOldPaymentHistories.Entities)
                                {
                                    EntityCollection IndividualopenOldPaymentHistoryTHs = new EntityCollection();
                                    IndividualopenOldPaymentHistoryTHs = getTransactionHistoriesforPH(service, crmTrace, openOldPH.Id);
                                    crmTrace.AppendLine("Count of IndividualopenOldPaymentHistoryTHs " + IndividualopenOldPaymentHistoryTHs.Entities.Count);

                                    crmTrace.AppendLine("Add TH to Global TH Variable");
                                    if (IndividualopenOldPaymentHistoryTHs != null && IndividualopenOldPaymentHistoryTHs.Entities.Count > 0)
                                    {
                                        crmTrace.AppendLine("Loop through TH's");
                                        foreach (Entity openOldPaymentHistoryTH in IndividualopenOldPaymentHistoryTHs.Entities)
                                        {
                                            crmTrace.AppendLine("Add to Collection");
                                            allOpenOldTransactionHistoryresponse.Entities.Add(openOldPaymentHistoryTH);
                                        }
                                    }
                                    crmTrace.AppendLine("Delete old payment history records -start");
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, openOldPH.Id);
                                    crmTrace.AppendLine("Delete old payment history records- - end");
                                }
                               
                            }

                            #endregion




                            crmTrace.AppendLine("Create new payment history");

                            Guid newPaymentHistory = FeeCalculationHelper.CreatePaymentHistory_NoGoodCheck(service, JobFilingApp, crmTrace);

                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history
                            //Retrieve the transaction history details from old payment history to create new transaction history for new payment history

                            EntityCollection Oldthresponse = getTransactionHistoriesforPH(service, crmTrace, result);

                            crmTrace.AppendLine("Number of TH's in NOGoodcheck PH" + Oldthresponse.Entities.Count);

                            if (Oldthresponse != null && Oldthresponse.Entities.Count > 0)
                            {
                                foreach (Entity oldthhistory in Oldthresponse.Entities)
                                {
                                    #region Add oldthhistory to Global TH's
                                    allOpenOldTransactionHistoryresponse.Entities.Add(oldthhistory);
                                    #endregion

                                }
                            }
                            crmTrace.AppendLine("Oldthresponse from FetchXml- end");

                            #region Create TH's for New PH  from allOpenOldTransactionHistoryresponse
                            if (allOpenOldTransactionHistoryresponse != null && allOpenOldTransactionHistoryresponse.Entities.Count > 0)
                            {
                                foreach (Entity allOpenOldTransactionHistory in allOpenOldTransactionHistoryresponse.Entities)
                                {
                                    crmTrace.AppendLine("create new transaction history for new payment history");
                                    FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, allOpenOldTransactionHistory, allOpenOldTransactionHistory.GetAttributeValue<Money>(TransactionHistoryAttributeNames.Fees));

                                }

                            }
                            #endregion

                            #region retrieve Check bounce Fee details

                            response = new EntityCollection();

                            crmTrace.AppendLine("retrieve fee type - check bounce");
                            crmTrace.AppendLine("formulae Name");
                            string formulaeName = "OP49 Initial Fee Calculation";
                            crmTrace.AppendLine("Response from fee calculation config " + formulaeName);
                            //Get fee calculation configuartion attributes 
                            crmTrace.AppendLine("get fee calculation configuration attributes");
                            response = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                            crmTrace.AppendLine("Response from fee calculation config " + response.Entities.Count);

                            #endregion

                            if (response != null && response.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.CheckBounce))
                            {
                                #region create Transaction history
                                //Add amount due attribute to targetentity object as CreateTransactionHistory uses this to set the Fee attribute value
                                crmTrace.AppendLine("Create transaction history for check bounce - start");
                                ConditionExpression transactionCodeCondition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { TransactionCodes.CheckBounceFee });
                                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                                                                                                        TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                                                                                                        TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText,
                                                                                                        TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

                                //added Payment History Id attribute while creating Transaction history record itself to associate
                                Guid tHistoryId = FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, jobFilingId, newPaymentHistory, transactioncodeResponse[0],
                                                                                                    new Money(Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])));
                                crmTrace.AppendLine("Create transaction history for check bounce - End");
                                #endregion

                                if (tHistoryId != new Guid())
                                {
                                    #region Update Elevator application entity
                                    crmTrace.AppendLine("update JobFiling appplication");
                                    entityObject = new Entity(PW5AfterHoursAttributeNames.EntityLogicalName);
                                    entityObject.Id = jobFilingId;
                                    crmTrace.AppendLine("existingMerchantAmount " + existingMerchantAmount);
                                    crmTrace.AppendLine("existingAmountPaid " + existingAmountPaid);
                                    
                                    if (existingMerchantAmount == existingAmountPaid)
                                    {
                                       
                                        totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]) + existingAmountDue;//AD=Existing Amount due+ Current No Good Check PH due+ nogood check fee
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - start" + totalAmountDue);                                        
                                        entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, totalAmountDue);
                                        decimal NGCFee = existingNogoodCheck + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                        entityObject.Attributes.Add(PW5AfterHoursAttributeNames.NoGoodCheckFee,new Money(NGCFee));
                                        entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AmountPaid,JobFilingApp.GetAttributeValue<decimal>(PW5AfterHoursAttributeNames.AmountPaid) - existingMerchantAmount);//amount paid=previous jobfiling amount paid- merchant amount
                                        crmTrace.AppendLine("check whether merchant amount is equal to amount paid - end");
                                        
                                    }

                                    else if (existingMerchantAmount < existingAmountPaid)
                                    {
                                        crmTrace.AppendLine("merchant amount is less than amount paid - start");
                                        if (existingAdjustment == 0)
                                        {
                                            totalAmountDue = existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]);
                                            crmTrace.AppendLine("if adjustment is 0" + totalAmountDue);
                                            entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, totalAmountDue);
                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment < (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce])) - existingAdjustment;
                                            entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, totalAmountDue);

                                        }
                                        if (existingAdjustment > 0 && (existingAdjustment > (existingMerchantAmount + Convert.ToDecimal(response.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce]))))
                                        {
                                            totalAmountDue = 0;
                                            entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, totalAmountDue);

                                        }

                                        crmTrace.AppendLine("merchant amount is less than amount paid - end");
                                    }

                                    entityObject.Attributes.Add(PW5AfterHoursAttributeNames.PaymentHistoryGuid, newPaymentHistory.ToString());
                                    //update all fee fields in Jobfiling application

                                    #region set OP49 report Status and Revert from No good check Status


                                    if (JobFilingApp.Contains(PW5AfterHoursAttributeNames.AHVPermitStatus))
                                    {
                                        crmTrace.AppendLine("check if JobFilingApp contains report status - start");

                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling-no goodcheck status to report status");
                                        entityObject.Attributes.Add(PW5AfterHoursAttributeNames.AHVPermitStatus, new OptionSetValue(9)); //no good check status
                                        crmTrace.AppendLine("Check if status is prefiling and add prefiling status to Reverted from NoGoodCheck");
                                        entityObject.Attributes.Add(PW5AfterHoursAttributeNames.RevertFromNGC, new OptionSetValue(JobFilingApp.GetAttributeValue<OptionSetValue>(PW5AfterHoursAttributeNames.AHVPermitStatus).Value));

                                    }
                                    #endregion


                                    service.Update(entityObject);
                                   
                                    #endregion

                                    #region Update PaymentHistory - reusing/replacing the same entity object
                                    crmTrace.AppendLine("update the payment history - start");
                                    entityObject = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                                    //pass new payment historyid(front end record id)
                                    entityObject.Id = newPaymentHistory;
                                    crmTrace.AppendLine("Set total fee in payment history");

                                    entityObject.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(totalAmountDue));
                                    crmTrace.AppendLine("Update Isposted to flase");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, false);
                                    crmTrace.AppendLine("set no good check flage to true");
                                    entityObject.Attributes.Add(PaymentHistoryAttributeNames.NoGoodCheckFlag, false);

                                    //Payment history record updated for flags
                                    service.Update(entityObject);
                                    crmTrace.AppendLine("update the payment history - end");
                                    #endregion
                                   
                                }
                                else
                                {
                                    crmTrace.AppendLine("Transaction history record creation failed");
                                }
                            }
                            else
                            {
                                crmTrace.AppendLine("Check bounce fee Response has no records");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("Payment history is created for OP49 so returning");
                            return;
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Frontend recordId incorrect format");
                    }
                }
                else
                {
                    crmTrace.AppendLine("Frontend recordId is missing in target entity");
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "NoGoodCheckStandarization - NoGoodCheckStandarizationPW5", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }






        /// <summary>
        /// This function is used to Count the PH which are is posted false. 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        public static EntityCollection CountOldPaymentHistory(IOrganizationService service, StringBuilder crmTrace, string conditionAttributeName, Entity targetEntity)
        {
            EntityCollection OldPhhistory = new EntityCollection();
            try
            {

                //retreive the Job filing application field and Is posted equals to NO and no goodcheck is NO
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='" + conditionAttributeName + @"' value='" + targetEntity.Id + @"' 
                             operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='0' operator='eq'/>
                            <condition attribute='dobnyc_nogoodcheckflag' operator='eq' value='0'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);

                return OldPhhistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return OldPhhistory;
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return OldPhhistory;
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "EODHandler - CountOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return OldPhhistory;
                //throw ex;
            }
        }

        /// <summary>
        /// This function will return the TH for a given PH guid
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="result"></param>
        /// <returns></returns>
        public static EntityCollection getTransactionHistoriesforPH(IOrganizationService service, StringBuilder crmTrace, Guid result)
        {
            crmTrace.AppendLine("Fetch Xml ");
            string fetchXML = @"<?xml version='1.0'?>
                                                        <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                                                        <entity name='dobnyc_transactionhistory'> <attribute name='dobnyc_transactionhistoryid'/><attribute name='dobnyc_name'/>
                                                        <attribute name='createdon'/>
                                                        <attribute name='dobnyc_transactiontype'/>
                                                        <attribute name='dobnyc_transactioncode'/>
                                                        <attribute name='dobnyc_subsource'/>
                                                        <attribute name='dobnyc_revenuesource'/>
                                                        <attribute name='dobnyc_reportcategory'/>
                                                        <attribute name='dobnyc_fees'/>
                                                        <attribute name='dobnyc_budgetcode'/>
                                                        <attribute name='dobnyc_th_transactioncode'/>
                                                        <order descending='false' attribute='dobnyc_name'/>
                                                        <filter type='and'><condition attribute='dobnyc_transactionid' value='" + result + @"' uitype='dobnyc_paymenthistory' operator='eq'/>
                                                        </filter>
                                                        </entity>
                                                        </fetch>";
            crmTrace.AppendLine("End fetch xml for retrieving Oldthresponse ");
            crmTrace.AppendLine("Oldthresponse from FetchXml- Start");
            EntityCollection Oldthresponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
            crmTrace.AppendLine("Oldthresponse from FetchXml- end");
            return Oldthresponse;
        }



    }
}
