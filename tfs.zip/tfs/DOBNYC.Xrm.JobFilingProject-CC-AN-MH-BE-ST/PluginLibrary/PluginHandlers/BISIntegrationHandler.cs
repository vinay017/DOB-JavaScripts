﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using ExternalSystemIntegration.Objects;
using ExternalSystemIntegration;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class BISIntegrationHandler : PluginHandlerBase
    {
        public static Entity AddressValidation(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {


                //CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, string.Empty);
                //CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BIN, null);
                
                #region Address Validation
                //string bin = string.Empty;
                //crmTrace.AppendLine("AddressValidation started");
                
                //AddressValidationRequest addressRequest = new AddressValidationRequest();
                //AddressValidationResponse addressResponse = new AddressValidationResponse();
                //ExternalSystem_AddressViolation svcAddressValidation = new ExternalSystem_AddressViolation();

                //addressRequest.Borough = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BoroughAttributeName]).Value.ToString();
                //addressRequest.HouseNumber = targetEntity.Attributes[JobFilingEntityAttributeName.HouseNumber].ToString();
                //addressRequest.StreetName = targetEntity.Attributes[JobFilingEntityAttributeName.Street].ToString();
                //addressRequest.SourceChannel = "CRM";

                //addressRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                //crmTrace.AppendLine("svcAddressValidation started");
                //addressResponse = svcAddressValidation.GetAddressValidation(addressRequest);
                //crmTrace.AppendLine("svcAddressValidation End : " + addressResponse.BIN);
                
                //if (addressResponse != null)
                //{
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, addressResponse.ReturnError);
                //    if (!string.IsNullOrEmpty(addressResponse.ReturnError))
                //        return targetEntity;


                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BIN, addressResponse.BIN);
                //    bin = addressResponse.BIN;
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Lot, addressResponse.Lot);
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Block, addressResponse.Block);
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LandMark, addressResponse.LandMark == "Y" ? new OptionSetValue(1) : new OptionSetValue(0));


                //}
                //crmTrace.AppendLine("End AddressValidation: " + addressResponse.ReturnError + " : " + addressResponse.ReturnCode);
                

                #endregion

                #region Property Violation

                PropertyViolationRequest propertyViolationRequest = new PropertyViolationRequest();
                PropertyViolationResponse propertyViolationResponse = new PropertyViolationResponse();
                crmTrace.AppendLine("PropertyViolationRequest started");

                ExternalSystem_PropertyViolation svcPropertyViolation = new ExternalSystem_PropertyViolation();
                propertyViolationRequest.Bin = targetEntity.Attributes[JobFilingEntityAttributeName.BIN].ToString();
                propertyViolationRequest.SourceChannel = "CRM";
                propertyViolationRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                crmTrace.AppendLine("svcPropertyProfileRequestViolation started");
                propertyViolationResponse = svcPropertyViolation.GetPropertyViolation(propertyViolationRequest);
                crmTrace.AppendLine("svcPropertyProfileViolationRequest Ended");
                crmTrace.AppendLine(MessageStrings.MXBI_BIS_CRM_PC.Replace(RequestAttributes.PRM_BUILDNYC_BIN, targetEntity.Attributes[JobFilingEntityAttributeName.BIN].ToString()));
                //throw new Exception(" crmTrace: " + crmTrace.ToString());
                if (propertyViolationResponse != null)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, propertyViolationResponse.ReturnError);
                    if (!string.IsNullOrEmpty(propertyViolationResponse.ReturnError))
                        return targetEntity;

                    if (propertyViolationResponse.ECBViolation.Trim() == "Y" || propertyViolationResponse.BISViolation.Trim() == "Y")
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.WorkPermitViolation, true);
                    else
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.WorkPermitViolation, false);
                    if (propertyViolationResponse.FilingOnHold.Trim() == "Y")
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BinOnHold, true);
                    else
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BinOnHold, false);
                    crmTrace.AppendLine("PropertyViolationRequest End : " + propertyViolationResponse.BISViolation);

                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Zip, propertyViolationResponse.Zipcode);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.CBNo, propertyViolationResponse.CommunityBoard);

                }


                #endregion

                #region Property Profile
                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PropertProfileId) && context.MessageName == PluginHelperStrings.UpdateMessageName)
                {

                    PropertyProfileRequest propertyRequest = new PropertyProfileRequest();
                    PropertyProfileResponse propertyResponse = new PropertyProfileResponse();
                    crmTrace.AppendLine("PropertyProfileRequest started");
                    ExternalSystem_PropertyProfile svcProperty = new ExternalSystem_PropertyProfile();
                    propertyRequest.Bin = targetEntity.Attributes[JobFilingEntityAttributeName.BIN].ToString();
                    propertyRequest.SourceChannel = "CRM";
                    propertyRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                    crmTrace.AppendLine("svcPropertyProfileRequest started");
                    propertyResponse = svcProperty.GetPropertyProfile(propertyRequest);
                    crmTrace.AppendLine("svcPropertyProfileRequest Ended");
                    crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                    if (propertyResponse != null)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, propertyResponse.ReturnError);
                        crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                        //if (!string.IsNullOrEmpty(propertyResponse.ReturnError))
                        //    return targetEntity;

                        if (string.IsNullOrEmpty(propertyResponse.ReturnCode) || propertyResponse.ReturnCode == "1" || propertyResponse.ReturnCode == "4")
                            return targetEntity;

                        Entity propertyProfile = new Entity(PropertyProfileAttributeNames.EntityLogicalName);
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.EntityNameField.ToLower(), propertyResponse.Bin);
                        crmTrace.AppendLine("propertyResponse.Bin:" + propertyResponse.Bin);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_AdditionalBINsforBuilding.ToLower(), propertyResponse.AditionalBINsForbuilding);
                        crmTrace.AppendLine("propertyResponse.AditionalBINsForbuilding:" + propertyResponse.AditionalBINsForbuilding);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Borough.ToLower(), new OptionSetValue(propertyResponse.Borough.ToLower() == BoroughNames.Bronx ? 2 : propertyResponse.Borough.ToLower() == BoroughNames.Brooklyn ? 3 : propertyResponse.Borough.ToLower() == BoroughNames.Manhattan ? 1 : propertyResponse.Borough.ToLower() == BoroughNames.Queens ? 4 : propertyResponse.Borough.ToLower() == BoroughNames.StatenIsland ? 5 : 1));
                        crmTrace.AppendLine("propertyResponse.Borough:" + propertyResponse.Borough);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CityOwned.ToLower(), propertyResponse.CityOwned);
                        crmTrace.AppendLine("propertyResponse.CityOwned:" + propertyResponse.CityOwned);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Condo.ToLower(), propertyResponse.Condo);
                        crmTrace.AppendLine("propertyResponse.Condo:" + propertyResponse.Condo);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1.ToLower(), propertyResponse.CrossStreet1);
                        crmTrace.AppendLine("propertyResponse.CrossStreet1:" + propertyResponse.CrossStreet1);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1Numbers.ToLower(), propertyResponse.CrossStreet1Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet1Numbers:" + propertyResponse.CrossStreet1Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2.ToLower(), propertyResponse.CrossStreet2);
                        crmTrace.AppendLine("propertyResponse.CrossStreet2:" + propertyResponse.CrossStreet2);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2Numbers.ToLower(), propertyResponse.CrossStreet2Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet2Numbers:" + propertyResponse.CrossStreet2Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3.ToLower(), propertyResponse.CrossStreet3);
                        crmTrace.AppendLine("propertyResponse.CrossStreet3:" + propertyResponse.CrossStreet3);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3Numbers.ToLower(), propertyResponse.CrossStreet3Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet3Numbers:" + propertyResponse.CrossStreet3Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4.ToLower(), propertyResponse.CrossStreet4);
                        crmTrace.AppendLine("propertyResponse.CrossStreet4:" + propertyResponse.CrossStreet4);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4Numbers.ToLower(), propertyResponse.CrossStreet4Numbers);
                        crmTrace.AppendLine("propertyResponse.CrossStreet4Numbers:" + propertyResponse.CrossStreet4Numbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreets.ToLower(), propertyResponse.Street);
                        crmTrace.AppendLine("propertyResponse.Street:" + propertyResponse.Street);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBBuildingRemarks.ToLower(), propertyResponse.DOBBuildingRemarks);
                        crmTrace.AppendLine("propertyResponse.DOBBuildingRemarks:" + propertyResponse.DOBBuildingRemarks);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBSpecialPlaceName.ToLower(), propertyResponse.DOBSpecialPlaceName);
                        crmTrace.AppendLine("propertyResponse.DOBSpecialPlaceName:" + propertyResponse.DOBSpecialPlaceName);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower(), propertyResponse.EnvironmentalRestrictions);
                        crmTrace.AppendLine("propertyResponse.EnvironmentalRestrictions:" + propertyResponse.EnvironmentalRestrictions);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_GrandfatheredSign.ToLower(), propertyResponse.GrandfatheredSign);
                        crmTrace.AppendLine("propertyResponse.GrandfatheredSign:" + propertyResponse.GrandfatheredSign);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HouseNo.ToLower(), propertyResponse.HouseNumber);
                        crmTrace.AppendLine("propertyResponse.HouseNumber:" + propertyResponse.HouseNumber);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower(), propertyResponse.LandmarkStatus);
                        crmTrace.AppendLine("propertyResponse.LandmarkStatus:" + propertyResponse.LandmarkStatus);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LegalAdultUse.ToLower(), propertyResponse.LegalAdultUse);
                        crmTrace.AppendLine("propertyResponse.LegalAdultUse:" + propertyResponse.LegalAdultUse);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LocalLaw.ToLower(), propertyResponse.LocalLaw);
                        crmTrace.AppendLine("propertyResponse.LocalLaw:" + propertyResponse.LocalLaw);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LoftLaw.ToLower(), propertyResponse.LoftLaw);
                        crmTrace.AppendLine("propertyResponse.LoftLaw:" + propertyResponse.LoftLaw);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialDistrict.ToLower(), propertyResponse.SpecialDistrict);
                        crmTrace.AppendLine("propertyResponse.SpecialDistrict:" + propertyResponse.SpecialDistrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialStatus.ToLower(), propertyResponse.SpecialStatus);
                        crmTrace.AppendLine("propertyResponse.SpecialStatus:" + propertyResponse.SpecialStatus);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower(), propertyResponse.SRORestrict);
                        crmTrace.AppendLine("propertyResponse.SRORestrict:" + propertyResponse.SRORestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Street.ToLower(), propertyResponse.Street);
                        crmTrace.AppendLine("propertyResponse.Street:" + propertyResponse.Street);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetName.ToLower(), propertyResponse.StreetName);
                        crmTrace.AppendLine("propertyResponse.StreetName:" + propertyResponse.StreetName);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetNumbers.ToLower(), propertyResponse.StreetNumbers);
                        crmTrace.AppendLine("propertyResponse.StreetNumbers:" + propertyResponse.StreetNumbers);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TARestricted.ToLower(), propertyResponse.TARestrict);
                        crmTrace.AppendLine("propertyResponse.TARestrict:" + propertyResponse.TARestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_UBRestricted.ToLower(), propertyResponse.UBRestrict);
                        crmTrace.AppendLine("propertyResponse.UBRestrict:" + propertyResponse.UBRestrict);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Vacant.ToLower(), propertyResponse.Vacant);
                        crmTrace.AppendLine("propertyResponse.Vacant:" + propertyResponse.Vacant);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Zip.ToLower(), propertyResponse.Zipcode);
                        crmTrace.AppendLine("propertyResponse.Zipcode:" + propertyResponse.Zipcode);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Latitude, Convert.ToDouble(propertyViolationResponse.Latitude));
                        crmTrace.AppendLine("propertyViolationResponse.Latitude:" + propertyViolationResponse.Latitude);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Longitude, Convert.ToDouble(propertyViolationResponse.Longitude));
                        crmTrace.AppendLine("propertyViolationResponse.Longitude:" + propertyViolationResponse.Longitude);
                        
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea1, Convert.ToString(propertyViolationResponse.PSpecialArea1));
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea1:" + propertyViolationResponse.PSpecialArea1);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea2, propertyViolationResponse.PSpecialArea2);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea2:" + propertyViolationResponse.PSpecialArea2);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea3, propertyViolationResponse.PSpecialArea3);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea3:" + propertyViolationResponse.PSpecialArea3);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea4, propertyViolationResponse.PSpecialArea4);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea4:" + propertyViolationResponse.PSpecialArea4);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea5, propertyViolationResponse.PSpecialArea5);
                        crmTrace.AppendLine("propertyViolationResponse.PSpecialArea5:" + propertyViolationResponse.PSpecialArea5);

                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.TransitAuthority, propertyViolationResponse.TransitAuthority);
                        crmTrace.AppendLine("propertyViolationResponse.TransitAuthority:" + propertyViolationResponse.TransitAuthority);

                        if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict1))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict1, propertyViolationResponse.SpecialDistrict1);
                        if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict2))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict2, propertyViolationResponse.SpecialDistrict2);
                        if (!string.IsNullOrEmpty(propertyViolationResponse.LoftFlag))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.LoftFlag, propertyViolationResponse.LoftFlag);
                        crmTrace.AppendLine("propertyViolationResponse.LoftFlag");
                        if (!string.IsNullOrEmpty(propertyResponse.BuildingsOnLot))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_BuildingsonLot.ToLower(), Convert.ToInt32(propertyResponse.BuildingsOnLot));
                        if (!string.IsNullOrEmpty(propertyResponse.TaxBlock))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxBlock.ToLower(), Convert.ToInt32(propertyResponse.TaxBlock));
                        if (!string.IsNullOrEmpty(propertyResponse.HealthArea))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HealthArea.ToLower(), Convert.ToInt32(propertyResponse.HealthArea));
                        if (!string.IsNullOrEmpty(propertyResponse.CommunityBoard))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CommunityBoard.ToLower(), Convert.ToInt32(propertyResponse.CommunityBoard));
                        crmTrace.AppendLine("propertyResponse.CommunityBoard");
                        if (!string.IsNullOrEmpty(propertyResponse.CensusTract))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CensusTract.ToLower(), Convert.ToInt32(propertyResponse.CensusTract));
                        if (!string.IsNullOrEmpty(propertyResponse.TaxLot))
                            propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxLot.ToLower(), Convert.ToInt32(propertyResponse.TaxLot));


                        crmTrace.AppendLine("PropertyProfileRequest Entity Reference Started : " + propertyResponse.Bin);
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_JobFilingRecord_PP.ToLower(), new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        crmTrace.AppendLine("PropertyProfileRequest Entity Reference  End: " + propertyResponse.Bin);
                        
                        Guid newGuid = service.Create(propertyProfile);
                        //DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_PropertyProfile2(service, propertyProfile, crmTrace, context);
                        //targetEntity.Attributes.Remove(JobFilingEntityAttributeName.PropertProfileId);
                        //targetEntity.Attributes.Add(JobFilingEntityAttributeName.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, newGuid));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, newGuid));
                        crmTrace.AppendLine("PropertyProfileRequest End : " + propertyResponse.Bin);
                        
                    }

                    
                }

                #endregion


               


                //#region Property Violation

                //BISJobRequest bisJobRequest = new BISJobRequest();
                //BISJobResponse bisJobResponse = new BISJobResponse();
                //crmTrace.AppendLine("bisJobRequest started");

                //ExternalSystem_BISJobs svcBISjobViolation = new ExternalSystem_BISJobs();
                //bisJobRequest.BISJobNumber =  targetEntity.Attributes[JobFilingEntityAttributeName.BIN].ToString();
                //bisJobRequest.SourceChannel = "CRM";
                //bisJobRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                //crmTrace.AppendLine("svcBISjobViolation started");
                //bisJobResponse = svcBISjobViolation.(bisJobRequest);
                //crmTrace.AppendLine("svcBISjobViolation Ended");
                //crmTrace.AppendLine(MessageStrings.MXBI_BIS_CRM_PC.Replace(RequestAttributes.PRM_BUILDNYC_BIN, targetEntity.Attributes[JobFilingEntityAttributeName.BIN].ToString()));
                ////throw new Exception(" crmTrace: " + crmTrace.ToString());
                //if (bisJobResponse != null)
                //{
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, propertyViolationResponse.ReturnError);
                //    if (!string.IsNullOrEmpty(propertyViolationResponse.ReturnError))
                //        return targetEntity;

                //   // if (bisJobResponse.J_JOB_IS_OPEN.Trim() == "Y" && bisJobResponse.J_BIN_NUMBER.Trim() ==bin && bisJobResponse.J_JOB_TYPE=="")
                     
                   

                //}


                //#endregion

                
                return targetEntity;


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AddressValidation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        public static Entity AssociatePropertyProfile(IOrganizationService service, Entity targetEntity, bool ispostCreate , StringBuilder crmTrace)
        {
            /// Summary ///
            /// Call this method on Create/Update (Pre-operation) of entities ///
            /// End Summary ///
            try
            {
                #region Job Filing
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    crmTrace.AppendLine("targetEntity.LogicalName: " + JobFilingEntityAttributeName.EntityLogicalName);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BIN))
                    {
                          string BIN = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString();
                            crmTrace.AppendLine("BIN: " + BIN);
                            EntityCollection existingPropertyProfiles = GetPropertyProfile(service, BIN, crmTrace);
                            crmTrace.AppendLine("existingPropertyProfiles Count: " + existingPropertyProfiles.Entities.Count);
                        //    if (existingPropertyProfiles != null && existingPropertyProfiles.Entities.Count > 0)
                        //    {
                        //        Entity propertyProfile = existingPropertyProfiles.Entities[0];
                        //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, propertyProfile.Id));
                        //        DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_PropertyProfile2(service, propertyProfile, targetEntity.Id.ToString(),crmTrace);
                        //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Zip, propertyProfile.GetAttributeValue<string>(PropertyProfileAttributeNames.dobnyc_Zip.ToLower()));
                        //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.CBNo,Convert.ToString( propertyProfile.GetAttributeValue<int>(PropertyProfileAttributeNames.dobnyc_CommunityBoard.ToLower())));

                        //}
                        //else
                        //    {
                                crmTrace.AppendLine("No existing Property Profiles found for BIN: " + BIN);
                                Guid PropertyProfileGuid = CreatePropertyProfile(service, BIN, targetEntity, crmTrace);
                                crmTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                if (PropertyProfileGuid != Guid.Empty)
                                {
                                    crmTrace.AppendLine("PropertyProfileGuid: " + PropertyProfileGuid.ToString());
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, PropertyProfileGuid));
                                }
                            //}                        
                    }
                    if (ispostCreate == true)
                        service.Update(targetEntity);
                }
                #endregion

                return targetEntity;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BISIntegrationHandler - AssociatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static EntityCollection GetPropertyProfile(IOrganizationService service, string BIN, StringBuilder crmTrace)
        {
            EntityCollection response = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start Getting Existing PropertyProfiles");
                string[] ColumnNames_PropertyProfile = new string[] { PropertyProfileAttributeNames.SpecialArea1, PropertyProfileAttributeNames.SpecialArea2, PropertyProfileAttributeNames.SpecialArea3, PropertyProfileAttributeNames.SpecialArea4,
                PropertyProfileAttributeNames.SpecialArea5, PropertyProfileAttributeNames.SpecialDistrict1, PropertyProfileAttributeNames.SpecialDistrict2, PropertyProfileAttributeNames.LoftFlag, PropertyProfileAttributeNames.TransitAuthority, PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower(), PropertyProfileAttributeNames.dobnyc_Zip.ToLower(), PropertyProfileAttributeNames.dobnyc_CommunityBoard.ToLower()};

                ConditionExpression propertyCondition = CreateConditionExpression(PropertyProfileAttributeNames.EntityNameField, ConditionOperator.Equal, new string[] { BIN });
                response = RetrieveMultiple(service, PropertyProfileAttributeNames.EntityLogicalName, ColumnNames_PropertyProfile, new ConditionExpression[] { propertyCondition }, LogicalOperator.And);
                crmTrace.AppendLine("End Getting Existing PropertyProfiles");
                return response;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return response;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - GetPropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return response;
            }

        }

        public static Guid CreatePropertyProfile(IOrganizationService service, string BIN, Entity targetEntity, StringBuilder crmTrace)
        {
            Byte[] bytes = new Byte[16];
            Guid newGuid = new Guid(bytes);
            try
            {
                crmTrace.AppendLine("CreatePropertyProfile started");
                crmTrace.AppendLine("newGuid: " + newGuid.ToString());
                #region Get Property Violation flags

                PropertyViolationRequest propertyViolationRequest = new PropertyViolationRequest();
                PropertyViolationResponse propertyViolationResponse = new PropertyViolationResponse();
                crmTrace.AppendLine("PropertyViolationRequest started");
                ExternalSystem_PropertyViolation svcPropertyViolation = new ExternalSystem_PropertyViolation();
                propertyViolationRequest.Bin = BIN;
                propertyViolationRequest.SourceChannel = "CRM";
                //propertyViolationRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                crmTrace.AppendLine("svcPropertyProfileRequestViolation started");
                propertyViolationResponse = svcPropertyViolation.GetPropertyViolation(propertyViolationRequest);
                crmTrace.AppendLine("svcPropertyProfileViolationRequest Ended");
                crmTrace.AppendLine(MessageStrings.MXBI_BIS_CRM_PC.Replace(RequestAttributes.PRM_BUILDNYC_BIN, BIN));
                //throw new Exception(" crmTrace: " + crmTrace.ToString());
                if (propertyViolationResponse != null)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, propertyViolationResponse.ReturnError);
                    if (!string.IsNullOrEmpty(propertyViolationResponse.ReturnError))
                        return newGuid;

                    if (propertyViolationResponse.ECBViolation.Trim() == "Y" || propertyViolationResponse.BISViolation.Trim() == "Y")
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.WorkPermitViolation, true);
                    else
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.WorkPermitViolation, false);
                    if (propertyViolationResponse.FilingOnHold.Trim() == "Y")
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BinOnHold, true);
                    else
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.BinOnHold, false);
                    crmTrace.AppendLine("PropertyViolationRequest End : " + propertyViolationResponse.BISViolation);

                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Zip, propertyViolationResponse.Zipcode);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.CBNo, propertyViolationResponse.CommunityBoard);

                }
                #endregion

                #region Property Profile
                PropertyProfileRequest propertyRequest = new PropertyProfileRequest();
                PropertyProfileResponse propertyResponse = new PropertyProfileResponse();
                crmTrace.AppendLine("PropertyProfileRequest started");
                ExternalSystem_PropertyProfile svcProperty = new ExternalSystem_PropertyProfile();
                propertyRequest.Bin = BIN;
                propertyRequest.SourceChannel = "CRM";
                //propertyRequest.JobFilingNumber = targetEntity.Attributes[JobFilingEntityAttributeName.FilingNumberAttributeName].ToString();
                crmTrace.AppendLine("svcPropertyProfileRequest started");
                propertyResponse = svcProperty.GetPropertyProfile(propertyRequest);
                crmTrace.AppendLine("svcPropertyProfileRequest Ended");
                crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                if (propertyResponse != null)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ErrorMessage, propertyResponse.ReturnError);
                    crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                    //if (!string.IsNullOrEmpty(propertyResponse.ReturnError))
                    //    return newGuid;

                    if (string.IsNullOrEmpty(propertyResponse.ReturnCode) || propertyResponse.ReturnCode == "1" || propertyResponse.ReturnCode == "4")
                        return newGuid;

                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LoftBoard, propertyResponse.LoftLaw != string.Empty? propertyResponse.LoftLaw : "NO");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SROMultiple, propertyResponse.SRORestrict != string.Empty ? propertyResponse.SRORestrict : "NO");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LandMark, propertyResponse.LandmarkStatus != string.Empty ? propertyResponse.LandmarkStatus : "NO");

                    #region added 02/05/2018 GC MH new PP fields
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands, propertyResponse.TidalWetlands == "Y" ? true : false);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, propertyResponse.CoastalErosionHazardArea == "Y" ? true : false);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, propertyResponse.FreshwaterWetlands == "Y" ? true : false);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdultEstablishment, propertyResponse.LegalAdultUse == "YES" ? true : false);
                    //Legal Adult use added 3/7/2019
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LegalAdultUse, propertyResponse.LegalAdultUse == "YES" ? true : false);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LittleEorRDSite, (propertyResponse.EnvironmentalRestrictions != string.Empty && propertyResponse.EnvironmentalRestrictions != "N/A") ? new OptionSetValue(2) : new OptionSetValue(1));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, propertyResponse.SpecialFloodHazardArea == "Y" ? true : false);
                    #endregion

                    #region added 02/15/2018 Zonning Summary fields for GC
                    if (
                        targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox)
                        || targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox)
                        //|| targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType)
                        )
                    {
                        ZonningSummary tempZonningObj = new ZonningSummary();
                        tempZonningObj = propertyResponse.ZonningInfo;
                        List<string> SpecialDistricts = new List<string>();
                        List<string> Districts = new List<string>();
                        List<string> Overlays = new List<string>();
                        #region Add values to lists
                        if (!string.IsNullOrEmpty(tempZonningObj.SpecialDistrict1))
                            SpecialDistricts.Add(tempZonningObj.SpecialDistrict1);
                        if (!string.IsNullOrEmpty(tempZonningObj.SpecialDistrict2))
                            SpecialDistricts.Add(tempZonningObj.SpecialDistrict2);
                        if (!string.IsNullOrEmpty(tempZonningObj.District1))
                            Districts.Add(tempZonningObj.District1);
                        if (!string.IsNullOrEmpty(tempZonningObj.District2))
                            Districts.Add(tempZonningObj.District2);
                        if (!string.IsNullOrEmpty(tempZonningObj.District3))
                            Districts.Add(tempZonningObj.District3);
                        if (!string.IsNullOrEmpty(tempZonningObj.CommercialOverlay1))
                            Districts.Add(tempZonningObj.CommercialOverlay1);
                        if (!string.IsNullOrEmpty(tempZonningObj.CommercialOverlay2))
                            Districts.Add(tempZonningObj.CommercialOverlay2);
                        #endregion

                        #region Intialize strings
                        string SpecialDists = string.Empty;
                        string Dists = string.Empty;
                        string ComOverlays = string.Empty;
                        #endregion

                        #region Change List to comma separated strings
                        for (int i = 0; i < SpecialDistricts.Count; i++)
                        {
                            if (i != 0)
                            {
                                SpecialDists = SpecialDists + " , " + SpecialDistricts[i];
                            }
                            else
                            SpecialDists = SpecialDists + SpecialDistricts[i];
                        }
                        for (int i = 0; i < Districts.Count; i++)
                        {
                            if (i != 0)
                            {
                                Dists = Dists + " , " + Districts[i];
                            }
                            else
                            Dists = Dists + Districts[i];
                        }
                        for (int i = 0; i < Overlays.Count; i++)
                        {
                            if (i != 0)
                            {
                                ComOverlays = ComOverlays + " , " + Overlays[i];
                            }
                            else
                            ComOverlays = ComOverlays + Overlays[i];
                         }
                        #endregion

                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SpecialDistricts, SpecialDists);
                        if(SpecialDists == "UNKNOWN")
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.isSpecialDistrictsUnkown, true);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Districts, Dists);
                        if (Dists == "UNKNOWN")
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.isDistrictsUnkown, true);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Overlays, ComOverlays);
                        if (ComOverlays == "UNKNOWN")
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.IsOverlaysUnkown, true);

                    }
                    #endregion

                    Entity propertyProfile = new Entity(PropertyProfileAttributeNames.EntityLogicalName);
                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.EntityNameField.ToLower(), propertyResponse.Bin);
                    crmTrace.AppendLine("propertyResponse.Bin:" + propertyResponse.Bin);



                    
                    if (propertyResponse.OtherBinsList != null && propertyResponse.OtherBinsList.Count > 0)
                    {
                        crmTrace.AppendLine("propertyResponse.OtherBinsList.Count:" + propertyResponse.OtherBinsList.Count);
                        List<string> otherBINS = propertyResponse.OtherBinsList;
                        string otherBINSString = string.Join(" ", otherBINS.ToArray());
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_AdditionalBINsforBuilding.ToLower(), otherBINSString);
                        crmTrace.AppendLine("propertyResponse.AditionalBINsForbuilding:" + otherBINSString);
                    }

                   
                    if (propertyResponse.streetList != null && propertyResponse.streetList.Count > 0)
                    {
                        crmTrace.AppendLine("propertyResponse.streetList.Count:" + propertyResponse.streetList.Count);
                        List<string> streetList = propertyResponse.streetList;
                        string streetListString = string.Join(", ", streetList.ToArray());
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreets.ToLower(), streetListString);
                        crmTrace.AppendLine("propertyResponse.streetList:" + streetListString);
                    }

                   
                    if (propertyResponse.SpecialArea != null && propertyResponse.SpecialArea.Count > 0)
                    {
                        crmTrace.AppendLine("propertyResponse.SpecialArea.Count" + propertyResponse.SpecialArea.Count);
                        List<string> specialAreaList = propertyResponse.SpecialArea;
                        string specialAreaListString = string.Join(", ", specialAreaList.ToArray());
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialAreaString.ToLower(), specialAreaListString);
                        crmTrace.AppendLine("propertyResponse.SpecialArea:" + specialAreaListString);
                    }

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Borough.ToLower(), new OptionSetValue(propertyResponse.Borough.ToLower() == BoroughNames.Bronx ? 2 : propertyResponse.Borough.ToLower() == BoroughNames.Brooklyn ? 3 : propertyResponse.Borough.ToLower() == BoroughNames.Manhattan ? 1 : propertyResponse.Borough.ToLower() == BoroughNames.Queens ? 4 : propertyResponse.Borough.ToLower() == BoroughNames.StatenIsland ? 5 : 1));
                    crmTrace.AppendLine("propertyResponse.Borough:" + propertyResponse.Borough);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CityOwned.ToLower(), propertyResponse.CityOwned);
                    crmTrace.AppendLine("propertyResponse.CityOwned:" + propertyResponse.CityOwned);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Condo.ToLower(), propertyResponse.Condo);
                    crmTrace.AppendLine("propertyResponse.Condo:" + propertyResponse.Condo);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1.ToLower(), propertyResponse.CrossStreet1);
                    crmTrace.AppendLine("propertyResponse.CrossStreet1:" + propertyResponse.CrossStreet1);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet1Numbers.ToLower(), propertyResponse.CrossStreet1Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet1Numbers:" + propertyResponse.CrossStreet1Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2.ToLower(), propertyResponse.CrossStreet2);
                    crmTrace.AppendLine("propertyResponse.CrossStreet2:" + propertyResponse.CrossStreet2);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet2Numbers.ToLower(), propertyResponse.CrossStreet2Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet2Numbers:" + propertyResponse.CrossStreet2Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3.ToLower(), propertyResponse.CrossStreet3);
                    crmTrace.AppendLine("propertyResponse.CrossStreet3:" + propertyResponse.CrossStreet3);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet3Numbers.ToLower(), propertyResponse.CrossStreet3Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet3Numbers:" + propertyResponse.CrossStreet3Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4.ToLower(), propertyResponse.CrossStreet4);
                    crmTrace.AppendLine("propertyResponse.CrossStreet4:" + propertyResponse.CrossStreet4);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CrossStreet4Numbers.ToLower(), propertyResponse.CrossStreet4Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet4Numbers:" + propertyResponse.CrossStreet4Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet5.ToLower(), propertyResponse.CrossStreet5);
                    crmTrace.AppendLine("propertyResponse.CrossStreet5:" + propertyResponse.CrossStreet5);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet5Numbers.ToLower(), propertyResponse.CrossStreet5Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet5Numbers:" + propertyResponse.CrossStreet5Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet6.ToLower(), propertyResponse.CrossStreet6);
                    crmTrace.AppendLine("propertyResponse.CrossStreet6:" + propertyResponse.CrossStreet6);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CrossStreet6Numbers.ToLower(), propertyResponse.CrossStreet6Numbers);
                    crmTrace.AppendLine("propertyResponse.CrossStreet6Numbers:" + propertyResponse.CrossStreet6Numbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBBuildingRemarks.ToLower(), propertyResponse.DOBBuildingRemarks);
                    crmTrace.AppendLine("propertyResponse.DOBBuildingRemarks:" + propertyResponse.DOBBuildingRemarks);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_DOBSpecialPlaceName.ToLower(), propertyResponse.DOBSpecialPlaceName);
                    crmTrace.AppendLine("propertyResponse.DOBSpecialPlaceName:" + propertyResponse.DOBSpecialPlaceName);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower(), propertyResponse.EnvironmentalRestrictions);
                    crmTrace.AppendLine("propertyResponse.EnvironmentalRestrictions:" + propertyResponse.EnvironmentalRestrictions);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_GrandfatheredSign.ToLower(), propertyResponse.GrandfatheredSign);
                    crmTrace.AppendLine("propertyResponse.GrandfatheredSign:" + propertyResponse.GrandfatheredSign);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HouseNo.ToLower(), propertyResponse.HouseNumber);
                    crmTrace.AppendLine("propertyResponse.HouseNumber:" + propertyResponse.HouseNumber);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower(), propertyResponse.LandmarkStatus);
                    crmTrace.AppendLine("propertyResponse.LandmarkStatus:" + propertyResponse.LandmarkStatus);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LegalAdultUse.ToLower(), propertyResponse.LegalAdultUse);
                    crmTrace.AppendLine("propertyResponse.LegalAdultUse:" + propertyResponse.LegalAdultUse);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LocalLaw.ToLower(), propertyResponse.LocalLaw);
                    crmTrace.AppendLine("propertyResponse.LocalLaw:" + propertyResponse.LocalLaw);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_LoftLaw.ToLower(), propertyResponse.LoftLaw);
                    crmTrace.AppendLine("propertyResponse.LoftLaw:" + propertyResponse.LoftLaw);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialDistrict.ToLower(), propertyResponse.SpecialDistrict);
                    crmTrace.AppendLine("propertyResponse.SpecialDistrict:" + propertyResponse.SpecialDistrict);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SpecialStatus.ToLower(), propertyResponse.SpecialStatus);
                    crmTrace.AppendLine("propertyResponse.SpecialStatus:" + propertyResponse.SpecialStatus);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower(), propertyResponse.SRORestrict);
                    crmTrace.AppendLine("propertyResponse.SRORestrict:" + propertyResponse.SRORestrict);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Street.ToLower(), propertyResponse.Street);
                    crmTrace.AppendLine("propertyResponse.Street:" + propertyResponse.Street);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetName.ToLower(), propertyResponse.StreetName);
                    crmTrace.AppendLine("propertyResponse.StreetName:" + propertyResponse.StreetName);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_StreetNumbers.ToLower(), propertyResponse.StreetNumbers);
                    crmTrace.AppendLine("propertyResponse.StreetNumbers:" + propertyResponse.StreetNumbers);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TARestricted.ToLower(), propertyResponse.TARestrict);
                    crmTrace.AppendLine("propertyResponse.TARestrict:" + propertyResponse.TARestrict);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_UBRestricted.ToLower(), propertyResponse.UBRestrict);
                    crmTrace.AppendLine("propertyResponse.UBRestrict:" + propertyResponse.UBRestrict);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Vacant.ToLower(), propertyResponse.Vacant);
                    crmTrace.AppendLine("propertyResponse.Vacant:" + propertyResponse.Vacant);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_Zip.ToLower(), propertyResponse.Zipcode);
                    crmTrace.AppendLine("propertyResponse.Zipcode:" + propertyResponse.Zipcode);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Latitude, Convert.ToDouble(propertyViolationResponse.Latitude));
                    crmTrace.AppendLine("propertyViolationResponse.Latitude:" + propertyViolationResponse.Latitude);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.Longitude, Convert.ToDouble(propertyViolationResponse.Longitude));
                    crmTrace.AppendLine("propertyViolationResponse.Longitude:" + propertyViolationResponse.Longitude);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea1, Convert.ToString(propertyViolationResponse.PSpecialArea1));
                    crmTrace.AppendLine("propertyViolationResponse.PSpecialArea1:" + propertyViolationResponse.PSpecialArea1);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea2, propertyViolationResponse.PSpecialArea2);
                    crmTrace.AppendLine("propertyViolationResponse.PSpecialArea2:" + propertyViolationResponse.PSpecialArea2);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea3, propertyViolationResponse.PSpecialArea3);
                    crmTrace.AppendLine("propertyViolationResponse.PSpecialArea3:" + propertyViolationResponse.PSpecialArea3);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea4, propertyViolationResponse.PSpecialArea4);
                    crmTrace.AppendLine("propertyViolationResponse.PSpecialArea4:" + propertyViolationResponse.PSpecialArea4);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialArea5, propertyViolationResponse.PSpecialArea5);
                    crmTrace.AppendLine("propertyViolationResponse.PSpecialArea5:" + propertyViolationResponse.PSpecialArea5);

                    propertyProfile.Attributes.Add(PropertyProfileAttributeNames.TransitAuthority, propertyViolationResponse.TransitAuthority);
                    crmTrace.AppendLine("propertyViolationResponse.TransitAuthority:" + propertyViolationResponse.TransitAuthority);

                    if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict1))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict1, propertyViolationResponse.SpecialDistrict1);
                    if (!string.IsNullOrEmpty(propertyViolationResponse.SpecialDistrict2))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialDistrict2, propertyViolationResponse.SpecialDistrict2);
                    if (!string.IsNullOrEmpty(propertyViolationResponse.LoftFlag))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.LoftFlag, propertyViolationResponse.LoftFlag);
                    crmTrace.AppendLine("propertyViolationResponse.LoftFlag");
                    if (!string.IsNullOrEmpty(propertyResponse.BuildingsOnLot))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_BuildingsonLot.ToLower(), Convert.ToInt32(propertyResponse.BuildingsOnLot));
                    if (!string.IsNullOrEmpty(propertyResponse.TaxBlock))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxBlock.ToLower(), Convert.ToInt32(propertyResponse.TaxBlock));
                    if (!string.IsNullOrEmpty(propertyResponse.HealthArea))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_HealthArea.ToLower(), Convert.ToInt32(propertyResponse.HealthArea));
                    if (!string.IsNullOrEmpty(propertyResponse.CommunityBoard))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_CommunityBoard.ToLower(), Convert.ToInt32(propertyResponse.CommunityBoard));
                    crmTrace.AppendLine("propertyResponse.CommunityBoard");
                    if (!string.IsNullOrEmpty(propertyResponse.CensusTract))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CensusTractString.ToLower(), propertyResponse.CensusTract);
                    if (!string.IsNullOrEmpty(propertyResponse.TaxLot))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.dobnyc_TaxLot.ToLower(), Convert.ToInt32(propertyResponse.TaxLot));

                    if (!string.IsNullOrEmpty(propertyResponse.TidalWetlands))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.TidalWetlandsMapCheck, propertyResponse.TidalWetlands);
                    if (!string.IsNullOrEmpty(propertyResponse.FreshwaterWetlands))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.FreshwaterWetlandsMapCheck, propertyResponse.FreshwaterWetlands);
                    if (!string.IsNullOrEmpty(propertyResponse.CoastalErosionHazardArea))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.CoastalErosionHazardAreaMapCheck, propertyResponse.CoastalErosionHazardArea);
                    if (!string.IsNullOrEmpty(propertyResponse.SpecialFloodHazardArea))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.SpecialFloodHazardAreaCheck, propertyResponse.SpecialFloodHazardArea);
                    if (!string.IsNullOrEmpty(propertyResponse.VlFinaOccpncy))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.DepartmentofFinanceBuildingClassification, propertyResponse.VlFinaOccpncy);
                    if (!string.IsNullOrEmpty(propertyResponse.DHCRFlag))
                        propertyProfile.Attributes.Add(PropertyProfileAttributeNames.DHCRFlag, propertyResponse.DHCRFlag);

                    crmTrace.AppendLine("PropertyProfileRequest Create Started : " + propertyResponse.Bin);
                        newGuid = service.Create(propertyProfile);
                    DocumentItemUploadHandler.CreateRequiredItemstoJobFiling_PropertyProfile2(service, propertyProfile, targetEntity.Id.ToString(), crmTrace);
                    crmTrace.AppendLine("PropertyProfile Guid: " + newGuid.ToString());
                        crmTrace.AppendLine("PropertyProfileRequest Create End: " + propertyResponse.Bin);
                    }
                    //CommonPluginLibrary.SetAttributeValue(targetEntity, TR6AttributeNames.PropertProfileId, new EntityReference(PropertyProfileAttributeNames.EntityLogicalName, newGuid)); // we are setting value of lookup so next step will be update since we are calling this on post operation
                    //service.Update(targetEntity);
                
                #endregion
                crmTrace.AppendLine("CreatePropertyProfile End : " + propertyResponse.Bin);
                return newGuid;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return newGuid;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newGuid;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BIN.ToString(), SourceChannel.CRM, "BISIntegrationHandler - CreatePropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newGuid;
            }

        }


    }
}
