﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersPATPARelatedEntities
{
    public class PATPAHandler : PluginHandlerBase
    {

        public static void CreateAlternateRecordForPA(IOrganizationService service, Entity targetEntity, Guid Guid, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CreateAlternateRecordForPA Method ");
                #region Initialize the Place of assembly space information Entity
                Entity PASpaceInformation = new Entity();
                PASpaceInformation.LogicalName = PlaceofAssemblySpaceInformation.EntityLogicalName;
                crmTrace.AppendLine("Guid:  " + Guid.ToString());

                #endregion
                String AlternativePlan = "Alternate Plan";
                int counter = 0; //intialize the counter is to 0

                // Retrive the Alternative Plan counter from Place of assembly space information 
                PASpaceInformation = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, Guid, new ColumnSet(new string[] { PlaceofAssemblySpaceInformation.alternativePlanCounter }));
               
                // Check the Place of assembly Space Information contains the Alternative plan counter value
                if (PASpaceInformation.Contains(PlaceofAssemblySpaceInformation.alternativePlanCounter))
                {
                    counter = (int)PASpaceInformation.Attributes[PlaceofAssemblySpaceInformation.alternativePlanCounter];
                    crmTrace.AppendLine("Place of assembly space information counter value " + counter);
                }

                // Check the Place of assembly Space Information counter value is greater than 0
                if (counter > 0)
                {
                    #region Setting the Next counter value in Place of assembly plan record.
                    crmTrace.AppendLine("Start End of setting the place of assembly plan counter" + AlternativePlan + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, PlaceofAssemblyPlans.Name, AlternativePlan + " " + counter.ToString());
                    crmTrace.AppendLine("End of setting the place of assembly plan counter " + AlternativePlan + counter.ToString());
                    #endregion

                    #region Setting the Next counter value in Place of assembly Space information record.
                    crmTrace.AppendLine("Start End of setting the place of assembly Space information Next counter" + AlternativePlan + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(PASpaceInformation, PlaceofAssemblySpaceInformation.alternativePlanCounter, counter + 1);
                    CommonPluginLibrary.SetAttributeValue(PASpaceInformation, PlaceofAssemblySpaceInformation.ID, Guid);
                    crmTrace.AppendLine("End of setting the place of assembly Space information Next counter" + AlternativePlan + counter.ToString());
                    service.Update(PASpaceInformation);//Update the service
                    #endregion
                }

                crmTrace.AppendLine("End CreatePrimaryAlternativePlanRecord  PA method");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - Final: End ", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord  PA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord  PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreatePrimaryAlternativePlanRecord PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateDocumentsPA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start -- Create documents upload for Place of Assembly Plans Started!");
                StringBuilder customTrace = new StringBuilder();
                Guid PAGuid = new Guid();
                Guid jobfilingid = Guid.Empty;

                if (targetEntity.Attributes.Contains(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup))
                {
                    PAGuid = ((EntityReference)targetEntity.Attributes[PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup]).Id;
                    crmTrace.AppendLine("PAGuid " + "is " + PAGuid);
                    //retreive the Job filing id
                    crmTrace.AppendLine("retreive the Job filing id ");
                    Entity pSPI = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, PAGuid, new ColumnSet(PlaceofAssemblySpaceInformation.jobFilingID));
                    jobfilingid = pSPI.GetAttributeValue<EntityReference>(PlaceofAssemblySpaceInformation.jobFilingID).Id;
                    crmTrace.AppendLine("JFGuid:  " + jobfilingid);
                    if (jobfilingid != Guid.Empty)
                    {
                        crmTrace.AppendLine("job filing ID " + "is " + jobfilingid);
                        string AlternatePlan = targetEntity.GetAttributeValue<string>(PlaceofAssemblyPlans.Name);
                        crmTrace.AppendLine("AlternatePlan: " + AlternatePlan);
                        Entity JobFiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, jobfilingid, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute, JobFilingEntityAttributeName.FilingType));
                        crmTrace.AppendLine("JobFilingID: " + JobFiling.Id);
                        #region Added on 08/29/2018 to stop creating document if intend to change plan is false (IAL is populating)
                        if (JobFiling.Contains(JobFilingEntityAttributeName.FilingType) && JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        {
                            ColumnSet columns = new ColumnSet(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                            Entity placeofAssembly = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, PAGuid, columns);
                            customTrace.AppendLine("placeofAssembly: " + placeofAssembly.Id.ToString());
                            if (!placeofAssembly.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans))
                            {
                                return;
                            }
                        }
                        #endregion

                        //Call CreateDocumentlist Method
                        SealSignaturesHandler.CreateDocumentlist(service, JobFiling, AlternatePlan, jobfilingid, crmTrace);

                        crmTrace.AppendLine("End documents upload for Place of Assembly Plans Started!");
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", null, crmTrace.ToString(), null, null);
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteDocumentsPA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                Guid jobfilingid = new Guid();
                crmTrace.AppendLine("Start - Delete documents upload for Place of Assembly Plans Started!");
                if (targetEntity.Contains(PlaceofAssemblyPlans.Name))
                {
                    string planName = targetEntity.GetAttributeValue<string>(PlaceofAssemblyPlans.Name);
                    crmTrace.AppendLine("plan Name Is!" + planName);
                    ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { planName });
                    ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                    crmTrace.AppendLine("CountIs!" + documentTypeResponse.Entities.Count);

                    if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                        Entity documentType = (Entity)documentTypeResponse.Entities[0];
                        string documentTypeId = documentType.Id.ToString();

                        Guid PAGuid = ((EntityReference)targetEntity.Attributes[PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup]).Id;
                        crmTrace.AppendLine("PAGuid " + "is " + PAGuid);

                        //retreive the Job filing id
                        crmTrace.AppendLine("retreive the Job filing id ");

                        string fetchXML = string.Format(FetchXml.GetJobFilingID, PAGuid.ToString());
                        EntityCollection JobFilingID = service.RetrieveMultiple(new FetchExpression(fetchXML));
                        if (JobFilingID.Entities.Count > 0)
                        {
                            if (JobFilingID.Entities[0].Attributes.Contains(JobFilingEntityAttributeName.JobFilingId))
                            {
                                jobfilingid = (Guid)JobFilingID.Entities[0].Attributes[JobFilingEntityAttributeName.JobFilingId];
                            }
                         
                        }
                        crmTrace.AppendLine("job filing ID " + "is " + jobfilingid);
                        crmTrace.AppendLine("Job filing count : " + JobFilingID.Entities.Count);
                        Entity JF = JobFilingID.Entities[0];
                        SealSignaturesHandler.DeleteDocuments_RelatedtoJob(service, JF, documentTypeId, crmTrace);
                    }
                }
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - CreateDocumentsPATPA", null, crmTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAAlternativePlanHandler - DeleteDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static Entity PAProfCertJobFilingSubmit(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            try
            {
                bool proCert = preImage.Contains(JobFilingEntityAttributeName.ProfessionalCertificate) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate) : false;
                crmTrace.AppendLine("proCert: " + proCert.ToString());

                String HouseNumber = preImage.Contains(JobFilingEntityAttributeName.HouseNumber) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber) : string.Empty;
                crmTrace.AppendLine("HouseNumber: " + HouseNumber);

                int currentFillingStatus = preImage.Contains(JobFilingEntityAttributeName.FilingStatus) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : 0;
                crmTrace.AppendLine("currentFillingStatus: " + currentFillingStatus.ToString());

                int Borough = preImage.Contains(JobFilingEntityAttributeName.BoroughAttributeName) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName).Value : 0;
                crmTrace.AppendLine("Borough: " + Borough.ToString());

                String StreetNumber = preImage.Contains(JobFilingEntityAttributeName.Street) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Street) : string.Empty;
                crmTrace.AppendLine("StreetNumber: " + StreetNumber);

                bool currentPA = preImage.Contains(JobFilingEntityAttributeName.PACheckBox) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) : false;
                crmTrace.AppendLine("currentPlace Of Assembly: " + currentPA);

                bool Auditflag = false;
                if (proCert == true && currentPA== true)
                {
                    crmTrace.AppendLine("entering this loop: ");
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.PACheckBox,JobFilingEntityAttributeName.ProfessionalCertificate, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.HouseNumber, JobFilingEntityAttributeName.Street };

                    ConditionExpression jobCondition = CreateConditionExpression(JobFilingEntityAttributeName.HouseNumber, ConditionOperator.Equal, new string[] { HouseNumber });
                    ConditionExpression jobCondition1 = CreateConditionExpression(JobFilingEntityAttributeName.Street, ConditionOperator.Equal, new string[] { StreetNumber });
                    ConditionExpression jobCondition2 = CreateConditionExpression(JobFilingEntityAttributeName.BoroughAttributeName, ConditionOperator.Equal, new string[] { Borough.ToString() });
                    ConditionExpression jobCondition3 = CreateConditionExpression(JobFilingEntityAttributeName.ProfessionalCertificate, ConditionOperator.Equal, new string[] { GenericConstants.StatusCodeActive.ToString() });
                    ConditionExpression jobCondition4 = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.NotEqual, new string[] { targetEntity.Id.ToString() });
                    ConditionExpression jobCondition5 = CreateConditionExpression(JobFilingEntityAttributeName.FilingStatus, ConditionOperator.NotEqual, new object[] { CurrentFilingStatus.PreFiling });
                    ConditionExpression jobCondition6 = CreateConditionExpression(JobFilingEntityAttributeName.PACheckBox, ConditionOperator.Equal,  new string[]{ GenericConstants.StatusCodeActive.ToString()});

                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobCondition, jobCondition1, jobCondition2, jobCondition3, jobCondition4, jobCondition5, jobCondition6 }, LogicalOperator.And);
                    crmTrace.AppendLine("Total Filings in Jobs: " + jobfilingResponse.Entities.Count);

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        JF_WorkonFloors jfWFList = new JF_WorkonFloors();
                        #region WF Other JF Records
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            Entity entity = (Entity)jobfilingResponse.Entities[i];
                            Guid jobFilingGuid = entity.GetAttributeValue<Guid>(JobFilingEntityAttributeName.JobFilingId);
                            crmTrace.AppendLine("jobFilingGuid: " + jobFilingGuid.ToString());
                            EntityCollection WorkOnFloorDetails = RetrieveRelatedEntities(service, jobFilingGuid, WorkOnFloorEntityAttributeName.EntityLogicalName, WorkOnFloorEntityAttributeName.GoToJobFiling);
                            crmTrace.AppendLine("WorkOnFloorDetails.Entities.Count: " + WorkOnFloorDetails.Entities.Count);
                            if (WorkOnFloorDetails.Entities.Count > 0)
                            {
                                foreach (Entity wf in WorkOnFloorDetails.Entities)
                                {
                                    WFObject wfObj = new WFObject();
                                    wfObj.JFID = entity.Id.ToString();
                                    crmTrace.AppendLine("wfObj.JFID " + wfObj.JFID.ToString());
                                    wfObj.From = (wf.Attributes.Contains(WorkOnFloorEntityAttributeName.FloorFrom))? wf.GetAttributeValue<string>(WorkOnFloorEntityAttributeName.FloorFrom).ToString() : string.Empty;
                                    crmTrace.AppendLine("wfObj.From " + wfObj.From.ToString());
                                    wfObj.To = (wf.Attributes.Contains(WorkOnFloorEntityAttributeName.FloorTo)) ? wf.GetAttributeValue<string>(WorkOnFloorEntityAttributeName.FloorTo).ToString() : string.Empty;
                                    crmTrace.AppendLine("wfObj.FloorTo " + wfObj.To.ToString());
                                    wfObj.Location = wf.GetAttributeValue<OptionSetValue>(WorkOnFloorEntityAttributeName.Location).Value.ToString();
                                    jfWFList.JFWFObjectList.Add(wfObj);
                                }
                            }
                        }
                        #endregion

                        #region WF target Entity
                        JF_WorkonFloors jfWFList_target = new JF_WorkonFloors();
                        EntityCollection WorkOnFloor_TargetDetails = RetrieveRelatedEntities(service, targetEntity.Id, WorkOnFloorEntityAttributeName.EntityLogicalName, WorkOnFloorEntityAttributeName.GoToJobFiling);
                        if (WorkOnFloor_TargetDetails.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Target WorkOnFloorDetails.Entities.Count: " + WorkOnFloor_TargetDetails.Entities.Count);
                            foreach (Entity wf in WorkOnFloor_TargetDetails.Entities)
                            {
                                WFObject wfObj = new WFObject();
                                wfObj.JFID = targetEntity.Id.ToString();
                                crmTrace.AppendLine("Target wfObj.JFID " + wfObj.JFID.ToString());

                                wfObj.From = (wf.Attributes.Contains(WorkOnFloorEntityAttributeName.FloorFrom)) ? wf.GetAttributeValue<string>(WorkOnFloorEntityAttributeName.FloorFrom).ToString() : string.Empty;
                                crmTrace.AppendLine("wfObj.From " + wfObj.From.ToString());
                                wfObj.To = (wf.Attributes.Contains(WorkOnFloorEntityAttributeName.FloorTo)) ? wf.GetAttributeValue<string>(WorkOnFloorEntityAttributeName.FloorTo).ToString() : string.Empty;
                                crmTrace.AppendLine("wfObj.FloorTo " + wfObj.To.ToString());

                                wfObj.Location = wf.GetAttributeValue<OptionSetValue>(WorkOnFloorEntityAttributeName.Location).Value.ToString();
                                crmTrace.AppendLine("Location " + wfObj.Location.ToString());
                                jfWFList_target.JFWFObjectList.Add(wfObj);
                            }
                        }
                        #endregion

                        #region Overlapping
                        foreach (WFObject obj in jfWFList_target.JFWFObjectList)
                        {
                            Auditflag = true;
                            crmTrace.AppendLine("entering this Ovarlapping loop : ");
                            int target_From = Convert.ToInt32(obj.From);
                            crmTrace.AppendLine("Target target_From " + target_From.ToString());
                            int target_To = Convert.ToInt32(obj.To);
                            int location = Convert.ToInt32(obj.Location);
                            crmTrace.AppendLine("Target location " + location.ToString());
                            crmTrace.AppendLine("Target target_To " + target_To.ToString());
                            foreach (WFObject other_obj in jfWFList.JFWFObjectList)
                            {
                                crmTrace.AppendLine("other_obj From " + other_obj.From.ToString());
                                crmTrace.AppendLine("other_obj.to" + other_obj.To.ToString());
                                crmTrace.AppendLine("other_obj.Location" + location.ToString());

                                if (location == (int)WorkOnFloorsLocation.Attic || location == (int)WorkOnFloorsLocation.balcony || location == (int)WorkOnFloorsLocation.Floors || location == (int)WorkOnFloorsLocation.Mezzanine || location == (int)WorkOnFloorsLocation.Stairwells)
                                {

                                    if (location == Convert.ToInt32(other_obj.Location))
                                    {
                                        crmTrace.AppendLine("entering this final Ovarlapping loop- Location Is matching :");
                                        if (target_From >= Convert.ToInt32(other_obj.From) && target_From >= Convert.ToInt32(other_obj.To)
                                            || target_To >= Convert.ToInt32(other_obj.From) && target_To >= Convert.ToInt32(other_obj.To))
                                                                                #region Updating the Jobfiling is the True
                                        crmTrace.AppendLine("Setting the Flag to True Audit");
                                        Entity jobFilingEntity = new Entity();
                                        jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                        jobFilingEntity.Id = targetEntity.Id;
                                        jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.IsPAAuditInitiated, Auditflag);
                                        service.Update(jobFilingEntity);
                                        crmTrace.AppendLine("jobFilingEntity Update Completed ");
                                        #endregion
                                    }
                                }
                                else if(location == Convert.ToInt32(other_obj.Location))
                                {
                                    #region Updating the Jobfiling is the True
                                    crmTrace.AppendLine("Setting the Flag to True Audit");
                                    Entity jobFilingEntity = new Entity();
                                    jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                    jobFilingEntity.Id = targetEntity.Id;
                                    jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.IsPAAuditInitiated, true);
                                    service.Update(jobFilingEntity);
                                    crmTrace.AppendLine("jobFilingEntity Update Completed ");
                                    #endregion
                                }

                            }
                        }
                        #endregion
                    }
                }
                return targetEntity;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PATPAHandler - PAProfCertJobFilingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }
    
       public static EntityCollection RetrieveRelatedEntities(IOrganizationService service, Guid targetEntityGuid, string RelatedEntitySchemaName, string RelationshipName)
        {
        ConditionExpression responseCondition = CreateConditionExpression(RelationshipName, ConditionOperator.Equal, new string[] { targetEntityGuid.ToString() });
        FilterExpression filterExpression = new FilterExpression();
        filterExpression.Conditions.AddRange(responseCondition);
        filterExpression.FilterOperator = LogicalOperator.And;

        ColumnSet columns = new ColumnSet(true);
        QueryExpression qe = new QueryExpression();
        qe.EntityName = RelatedEntitySchemaName;
        qe.ColumnSet = new ColumnSet(true);
        qe.Criteria = filterExpression;
        qe.NoLock = true;
        EntityCollection response = service.RetrieveMultiple(qe);
        return response;
     }

        /// <summary>
        /// Check if Event or Request Date changed after filing
        /// </summary>
        /// <para>Check if Event or Request Date changed after filing</para> 
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        public static void CheckifDatesChangedAfterFiling(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            try
            {
               
                crmTrace.AppendLine("Start -CheckifDatesChangedAfterFiling");
                #region Temporary Place of Assembly
                if(targetEntity.LogicalName == TempororayPlaceOfAssembly.EntityLogicalName && preImage.Contains(TempororayPlaceOfAssembly.jobfilingLookup))
                {
                    crmTrace.AppendLine(" Temporary Place of Assembly");
                    TPAEventDateObj EventObj = new TPAEventDateObj();
                    bool eventDateChanged = false;
                    if (targetEntity.Contains(TempororayPlaceOfAssembly.EventStartdate) && preImage.Contains(TempororayPlaceOfAssembly.EventStartdate))
                    {
                        EventDetail eventdetail = new EventDetail();
                        eventdetail.dateSchema = TempororayPlaceOfAssembly.EventStartdate;
                        eventdetail.currentDate = targetEntity.GetAttributeValue<DateTime>(TempororayPlaceOfAssembly.EventStartdate);
                        eventdetail.previousDate = preImage.GetAttributeValue<DateTime>(TempororayPlaceOfAssembly.EventStartdate);
                        EventObj.EventList.Add(eventdetail);
                    }

                    if (targetEntity.Contains(TempororayPlaceOfAssembly.EventEnddate) && preImage.Contains(TempororayPlaceOfAssembly.EventEnddate))
                    {
                        EventDetail eventdetail = new EventDetail();
                        eventdetail.dateSchema = TempororayPlaceOfAssembly.EventEnddate;
                        eventdetail.currentDate = targetEntity.GetAttributeValue<DateTime>(TempororayPlaceOfAssembly.EventEnddate);
                        eventdetail.previousDate = preImage.GetAttributeValue<DateTime>(TempororayPlaceOfAssembly.EventEnddate);
                        EventObj.EventList.Add(eventdetail);
                    }

                    if(EventObj.EventList != null && EventObj.EventList.Count > 0 )
                    {
                        foreach (EventDetail e in EventObj.EventList)
                        {
                            crmTrace.AppendLine("DateSchema: " + e.dateSchema + " currentDate: " + e.currentDate + " previousDate: " + e.previousDate);
                            if (e.currentDate != e.previousDate)
                                eventDateChanged = true;
                        }

                        #region eventDateChanged
                        if (eventDateChanged)
                        {
                            crmTrace.AppendLine("eventDateChanged");
                            Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(TempororayPlaceOfAssembly.jobfilingLookup).Id, new ColumnSet(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName));
                            int currentFilingStatus = JF.Contains(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName) ? JF.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value: 1;
                            if(currentFilingStatus != (int)CurrentFilingStatus.PreFiling)
                            {
                                crmTrace.AppendLine("currentFilingStatus != (int)CurrentFilingStatus.PreFiling");
                                targetEntity.SetAttributeValue(TempororayPlaceOfAssembly.RequestPeriodDatesChangedAfterFiling, true);
                            }
                        }
                        #endregion
                    }
                }
                #endregion

                #region TPA Event Dates
                if (targetEntity.LogicalName == TPAEventDates.EntityLogicalName && preImage.Contains(TPAEventDates.TPALookup))
                {
                    crmTrace.AppendLine(" TPA Event Dates");
                    TPAEventDateObj EventObj = new TPAEventDateObj();
                    bool eventDateChanged = false;
                    if (targetEntity.Contains(TPAEventDates.EventStartdate) && preImage.Contains(TPAEventDates.EventStartdate))
                    {
                        EventDetail eventdetail = new EventDetail();
                        eventdetail.dateSchema = TPAEventDates.EventStartdate;
                        eventdetail.currentDate = targetEntity.GetAttributeValue<DateTime>(TPAEventDates.EventStartdate);
                        eventdetail.previousDate = preImage.GetAttributeValue<DateTime>(TPAEventDates.EventStartdate);
                        EventObj.EventList.Add(eventdetail);
                    }

                    if (targetEntity.Contains(TPAEventDates.EventEndDate) && preImage.Contains(TPAEventDates.EventEndDate))
                    {
                        EventDetail eventdetail = new EventDetail();
                        eventdetail.dateSchema = TPAEventDates.EventEndDate;
                        eventdetail.currentDate = targetEntity.GetAttributeValue<DateTime>(TPAEventDates.EventEndDate);
                        eventdetail.previousDate = preImage.GetAttributeValue<DateTime>(TPAEventDates.EventEndDate);
                        EventObj.EventList.Add(eventdetail);
                    }

                    if (EventObj.EventList != null && EventObj.EventList.Count > 0)
                    {
                        foreach (EventDetail e in EventObj.EventList)
                        {
                            crmTrace.AppendLine("DateSchema: " + e.dateSchema + " currentDate: " + e.currentDate + " previousDate: " + e.previousDate);
                            if (e.currentDate != e.previousDate)
                                eventDateChanged = true;
                        }

                        #region eventDateChanged
                        if (eventDateChanged)
                        {
                            crmTrace.AppendLine("eventDateChanged");

                            #region
                            QueryExpression query = new QueryExpression();
                            query.EntityName = TempororayPlaceOfAssembly.EntityLogicalName;
                            ColumnSet columns = new ColumnSet(TempororayPlaceOfAssembly.ID);
                            query.ColumnSet = columns;
                            FilterExpression filter = new FilterExpression();
                            ConditionExpression condition = new ConditionExpression(TempororayPlaceOfAssembly.ID, ConditionOperator.Equal, new string[] { preImage.GetAttributeValue<EntityReference>(TPAEventDates.TPALookup).Id.ToString() });
                            query.Criteria.AddCondition(condition);
                            query.LinkEntities.Add(new LinkEntity(TempororayPlaceOfAssembly.EntityLogicalName, JobFilingEntityAttributeName.EntityLogicalName,
                                                                   TempororayPlaceOfAssembly.jobfilingLookup, JobFilingEntityAttributeName.JobFilingId, JoinOperator.Inner));
                            query.LinkEntities[0].Columns.AddColumns(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName);
                            query.LinkEntities[0].EntityAlias = "JF";
                            #endregion

                            EntityCollection TPA = service.RetrieveMultiple(query);
                            if (TPA != null && TPA.Entities != null && TPA.Entities.Count() > 0)
                            {
                                OptionSetValue currentFilingStatus = TPA.Entities[0].Attributes.Contains("JF." + JobFilingEntityAttributeName.CurrentFilingStatusAttributeName) ? (OptionSetValue)TPA.Entities[0].GetAttributeValue<AliasedValue>("JF." + JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value : new OptionSetValue(1);
                                crmTrace.AppendLine("currentFilingStatus: " + currentFilingStatus.Value);
                                if (currentFilingStatus.Value != (int)CurrentFilingStatus.PreFiling)
                                {
                                    crmTrace.AppendLine("currentFilingStatus != (int)CurrentFilingStatus.PreFiling");
                                    Entity tpa = new Entity(TempororayPlaceOfAssembly.EntityLogicalName);
                                    tpa.SetAttributeValue(TempororayPlaceOfAssembly.EventDatesChangedAfterFiling, true);
                                    tpa.Id = TPA.Entities[0].Id;
                                    service.Update(tpa);
                                }
                            }
                        }
                        #endregion
                    }
                }
                #endregion

                    crmTrace.AppendLine("End -CheckifDatesChangedAfterFiling");

                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAHandler - CheckifDatesChangedAfterFiling", null, crmTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("", SourceChannel.CRM, "PATPAHandler - DeleteDocumentsPATPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
