﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobFilingPAAHandler : PluginHandlerBase
    {
        public static void CalculatePAA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string messageName)
        {
            #region Varibale Declarations


            string formulaeName = string.Empty;

            Dictionary<string, int> preimageValues = new Dictionary<string, int>();

            EntityCollection transCodesResponse = new EntityCollection();
            List<string> transCodesList = new List<string>();
            decimal refund = 0;
            decimal estimatedJobCost = 0;
            Entity phResponse = new Entity();
            Entity thResponse = new Entity();
            string paaFees = string.Empty;
            //decimal existingFilingFees = 0;
            decimal existingRefund = 0;
            decimal existingDue = 0;
            decimal amountDue = 0;
            decimal existingPaaFee = 0;
            decimal newfilingFee = 0;
            decimal paaFee = 0;
            string thGuid = string.Empty;
            List<Guid> transHistoryGuid = new List<Guid>();
            string phGuid = string.Empty;
            decimal amountPaid = 0;
            decimal totalPayable = 0;
            decimal estJobCostLegal = 0;
            decimal inConjunctionFee = 0;
            decimal recordManagementFee = 0;
            int jobType = 0;
            FeeCalculationObject fcObject = new FeeCalculationObject();
            FeeCalculationObject legalFeeObject = new FeeCalculationObject();
            EntityCollection getFeeParameterResponse = new EntityCollection();
            EntityCollection getPAAParameterResponse = new EntityCollection();
            EntityCollection getInconjunctionforPAA = new EntityCollection();

            #endregion

            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName))
                estimatedJobCost = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value;
            
            try
            {
                crmTrace.AppendLine("Fee Calculation for PAA - Start");
                //Check if the Estimated job Cost is changed. If Changed Calculate the filing fees. Check if it exceeded or decreased and change the appropriate posted/not posted transaction record
                if (estimatedJobCost != 0)
                {
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Refund))
                        existingRefund = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.Refund]).Value;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                        amountPaid = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                  
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountDue))
                        existingDue = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountDue]).Value;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PAAFee))
                        existingPaaFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.PAAFee]).Value;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobType))
                        jobType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                        estJobCostLegal = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value;

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RecordManagementFee))
                        recordManagementFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.RecordManagementFee]).Value;

                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);
                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                    getPAAParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.PAA, service, crmTrace);
                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);   //Build FormulaeName
                    getInconjunctionforPAA = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);


                    fcObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estimatedJobCost);
                    legalFeeObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estJobCostLegal);

                    Entity jobFiling = new Entity();


                    newfilingFee = decimal.Parse(fcObject.TotalFee);
                    paaFee = decimal.Parse(getPAAParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PaaFee].ToString());

                  
                    if (jobType == 1)
                        totalPayable = newfilingFee + paaFee;

                    if (jobType == 3)
                        totalPayable = newfilingFee + paaFee + decimal.Parse(legalFeeObject.LegalizationFilingFee);

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaidPAAFee))
                        if (((Money)targetEntity.Attributes[JobFilingEntityAttributeName.PaidPAAFee]).Value != 0)
                            totalPayable = totalPayable + paaFee;

                    // Total Payable Incase of Inconjunction
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                        if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true)
                        {
                            //totalPayable = decimal.Parse(getInconjunctionforPAA.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString()) +
                            //    decimal.Parse(getInconjunctionforPAA.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString()) + paaFee;

                        inConjunctionFee = decimal.Parse(getInconjunctionforPAA.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString()) ;
                            totalPayable = inConjunctionFee + paaFee;

                        }

                    // Alt Bis Job
                    //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                    //                  targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                    //{
                    //    recordManagementFee = decimal.Parse(fcObject.RecordManagementFee);
                    //    crmTrace.AppendLine("Record Management Fee");
                    //    totalPayable = decimal.Parse(fcObject.TotalFee);
                    //    totalPayable = (totalPayable - recordManagementFee)+paaFee;
                    //    crmTrace.AppendLine("Total Amount" + totalPayable);
                    //    fcObject.RecordManagementFee = "0";
                    //    crmTrace.AppendLine("record management fee " + fcObject.RecordManagementFee);
                    //   // fcObject.TotalFee = "" + totalPayable;
                    //    crmTrace.AppendLine("totalPayable ");
                    //}
                   
                    //Total Payable in case of Fee Exemption
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                    {
                        if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true))
                        {
                            //if (!FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity))
                            //{
                                totalPayable = paaFee;
                            // }
                            //else
                            //{
                            //    totalPayable = 0;
                            //}  
                           
                        }
                        
                    }

                    //check if the new filing fees and exisitng filing fees are the same and proceed further only if they aren't
                    if (totalPayable == amountPaid)
                    {
                       
                        crmTrace.AppendLine("If amount paid and totalpayable are equal - Start");
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                        crmTrace.AppendLine("If amount paid and totalpayable are equal - End");
                       // throw new Exception("test" + amountDue);
                    }

                    if (totalPayable > amountPaid)
                    {
                        crmTrace.AppendLine(amountPaid.ToString());
                        amountDue = totalPayable - amountPaid;
                     
                        if (amountDue == paaFee)
                        {
                            crmTrace.AppendLine("If amount due is  equal to PAA Fee- Start");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                            crmTrace.AppendLine("If amount due is  equal to PAA Fee - End");
                           
                        }
                        if (amountDue > 0 && amountDue < paaFee)
                        {
                            if (existingRefund > amountDue)
                            {
                                refund = existingRefund - amountDue;
                            }
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                        }

                        if (amountDue > paaFee)
                        {
                            crmTrace.AppendLine("If amount due is greater than refund - Start");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                            crmTrace.AppendLine("If amount due is greater than refund - End");
                        }
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                    }
                    else if (totalPayable < amountPaid)
                    {
                       
                        crmTrace.AppendLine("If amount paid is less than totalpayable - Start");
                        refund = amountPaid - totalPayable;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                        // if total fee is less than amount paid
                        //if (!FeeCalculationHelper.isPostedPaymentHistories(service, crmTrace, targetEntity))
                        //{
                        //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(paaFee));
                        //}
                        //else
                        //{
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(0));
                        //}
                       
                        crmTrace.AppendLine("If amount paid is less than totalpayable - End");
                    }
                    transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getPAAParameterResponse, targetEntity);
              
                    if (existingPaaFee == 0)
                    {
                        crmTrace.AppendLine("Setting Transaction codes and Fee values when Existing PAA fee is null - Start");

                        if (amountDue > 0 && amountDue < paaFee)
                        {
                            transCodesList.Add(TransactionCodes.PAA);
                            transCodesList.Add(TransactionCodes.Adjustment);

                            getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = paaFee - amountDue;
                        }

                        if (amountDue == 0 && refund > 0)
                        {
                            transCodesList.Add(TransactionCodes.PAA);
                            transCodesList.Add(TransactionCodes.Adjustment);

                            //getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund + paaFee;
                            getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund ;
                        }

                        if (amountDue == 0 && refund == 0)
                        {
                            transCodesList.Add(TransactionCodes.PAA);
                        }

                        if (amountDue > paaFee)
                        {
                            transCodesList.Add(TransactionCodes.PAA);
                            transCodesList.Add(TransactionCodes.FilingBalance);
                            getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = amountDue - paaFee;
                        }

                        if (amountDue == paaFee)
                        {
                            transCodesList.Add(TransactionCodes.PAA);
                        }
                        crmTrace.AppendLine("Setting Transaction codes and Fee values when Existing PAA is null- End");
                    }

                    if (existingPaaFee == paaFee)
                    {
                        crmTrace.AppendLine("Setting Transaction codes and Fee values when Existing PAA Fee is not null - Start");
                        if ((preImage.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID)))
                        {
                            crmTrace.AppendLine("Payment History Guid - " + preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString());
                            phGuid = preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                            phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                        }

                        if ((preImage.Attributes.Contains(JobFilingEntityAttributeName.TransactionHistoryGUID)))
                        {
                            crmTrace.AppendLine("Transaction History Guid - " + preImage.Attributes[JobFilingEntityAttributeName.TransactionHistoryGUID].ToString());
                            thGuid = preImage.Attributes[JobFilingEntityAttributeName.TransactionHistoryGUID].ToString();
                            thResponse = Retrieve(service, new string[] { TransactionHistoryAttributeNames.TransCode }, new Guid(thGuid), TransactionHistoryAttributeNames.EntityLogicalName);
                        }
                        if (!preImage.Attributes.Contains(JobFilingEntityAttributeName.TransactionHistoryGUID))
                        {
                            crmTrace.AppendLine("If transactionhistory guid doesn't exist - Start");
                            if (amountDue == 0 && refund > 0)
                            {
                                transCodesList.Add(TransactionCodes.Adjustment);
                                if (transCodesList.Contains(TransactionCodes.PAA))
                                    transCodesList.Remove(TransactionCodes.PAA);
                                getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund;
                            }

                            if (amountDue > 0)
                            {
                                if (transCodesList.Contains(TransactionCodes.PAA))
                                    transCodesList.Remove(TransactionCodes.PAA);
                                transCodesList.Add(TransactionCodes.FilingBalance);
                                getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = amountDue;
                            }
                            if (amountDue == paaFee)
                            {
                                if (!transCodesList.Contains(TransactionCodes.PAA))
                                    transCodesList.Add(TransactionCodes.PAA);
                            }
                            crmTrace.AppendLine("If transactionhistory guid doesn't exist - End");
                        }

                        if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted) && thResponse.Attributes.Contains(TransactionHistoryAttributeNames.TransCode))
                        {
                            if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false && thResponse.Attributes[TransactionHistoryAttributeNames.TransCode].ToString() == TransactionCodes.PAA)
                            {
                                if (amountDue > 0 && amountDue < paaFee)
                                {
                                    if (!transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Add(TransactionCodes.PAA);
                                    transCodesList.Add(TransactionCodes.Adjustment);
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = paaFee - amountDue;
                                }

                                if (amountDue == 0 && refund > 0)
                                {
                                    if (!transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Add(TransactionCodes.PAA);
                                    transCodesList.Add(TransactionCodes.Adjustment);

                                    //getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund + paaFee;
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund;
                                }

                                if (amountDue > paaFee)
                                {
                                    
                                    if (!transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Add(TransactionCodes.PAA);
                                    transCodesList.Add(TransactionCodes.FilingBalance);
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = amountDue - paaFee;
                                }

                                if (amountDue == paaFee)
                                {
                                    if (!transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Add(TransactionCodes.PAA);
                                }
                                //service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                            }
                            if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false && thResponse.Attributes[TransactionHistoryAttributeNames.TransCode].ToString() != TransactionCodes.PAA)
                            {
                                if (amountDue == 0 && refund > 0)
                                {
                                    if (transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Remove(TransactionCodes.PAA);
                                    transCodesList.Add(TransactionCodes.Adjustment);

                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund;
                                }
                                if (amountDue > 0)
                                {
                                    if (transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Remove(TransactionCodes.PAA);
                                    transCodesList.Add(TransactionCodes.FilingBalance);
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = amountDue;
                                }
                            }

                            if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == true)
                            {
                                if (amountDue == 0 && refund > 0)
                                {
                                    transCodesList.Add(TransactionCodes.Adjustment);
                                    if (transCodesList.Contains(TransactionCodes.PAA))
                                        transCodesList.Remove(TransactionCodes.PAA);
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = refund;
                                }

                                if (amountDue > 0)
                                {
                                    transCodesList.Add(TransactionCodes.FilingBalance);
                                    getPAAParameterResponse.Entities[0].Attributes[FeeSchemaNames.NewFilingFeeSchemaName] = amountDue;
                                }
                            }
                        }

                        crmTrace.AppendLine("Setting Transaction codes and Fee values when Existing PAA Fee is not null - End");
                    }
                    if (transCodesList != null)
                    {
                        if (transCodesList.Count != 0)
                        {
                            
                            transHistoryGuid = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getPAAParameterResponse, targetEntity, transCodesResponse,preImage);
                            targetEntity.Attributes.Add(FeeTypeName.IsPaa, true);
                            crmTrace.AppendLine("Job filing update with transaction history guid Done");

                            //Create Payment history
                            crmTrace.AppendLine("create payment history in paa -start");
                            if (refund == 0 )
                                FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuid, amountDue);
                            else if (refund > 0)
                                FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuid, 0);
                            crmTrace.AppendLine("create payment history in paa -end");
                        }

                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Id = targetEntity.Id;
                       
                        if (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] !=null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename)==true)
                        {
                            crmTrace.AppendLine("fee exempt in paa - start");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse("0")));
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                            crmTrace.AppendLine("fee exempt in paa - end");
                        }
                  
                        else if (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] !=null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob)==true)
                        {
                            crmTrace.AppendLine("inconjunction in paa - start");
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionFee));
                            crmTrace.AppendLine("inconjunction in paa - end");
                        }
                       
                      else if((targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename]!=null &&(bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == false) && 
                            (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob]!=null &&(bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == false))
                        {
                            crmTrace.AppendLine("filing fee in paa -start");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                            crmTrace.AppendLine("filing fee in paa -end");
                        }
                        
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(totalPayable));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.PAAFee, new Money(paaFee));
                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                        if (jobFiling.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                            jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingRepresentativeAttributeName);
                        crmTrace.AppendLine("Update Job filing - last update on job filing - CalculatePAA Method - Start");
                        service.Update(jobFiling);
                        crmTrace.AppendLine("Update Job filing - last update on job filing - CalculatePAA Method - End");
                        crmTrace.AppendLine("Fee Calculation for PAA - End");
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingPAAHandler - CalculatePAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
    }
}
