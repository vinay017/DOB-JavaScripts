﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class SealSignaturesHandler : PluginHandlerBase
    {
        public static void WorkPermitDocuments(IOrganizationService service, Entity targetEntity, Entity preImageEntity, IPluginExecutionContext context, StringBuilder crmTrace)
        {
            try
            {
                string requiredDocumentName = "CONTRACTOR SEAL & SIGNATURE";
                string deleteDocumentName = "CONTRACTOR SEAL & SIGNATURE";
                crmTrace.AppendLine("WorkPermitDocuments Started!");
                #region WorkPermit Documents - Based on Applicant License Type
                Guid JobFilingId = ((EntityReference)targetEntity[WorkPermitEntityAttributeName.JobFilingRelationshipID]).Id;
                if (targetEntity.Contains(WorkPermitEntityAttributeName.LicenseeType))
                {
                    EntityReference licensee = targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.LicenseeType);
                    Entity Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                    string licenseType_Name = Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                    string licenseType = licenseType_Name.Substring(0, licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                    crmTrace.AppendLine("licenseType: " + licenseType);

                    if (licenseType.Equals(LicenseType.PE) || licenseType.Equals(LicenseType.LA) || licenseType.Equals(LicenseType.RA))
                    {
                        if (targetEntity.Contains(WorkPermitEntityAttributeName.TypeofPermit))
                        {
                            int typeofPermit = targetEntity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                            crmTrace.AppendLine("typeofPermit:" + typeofPermit);
                            if (typeofPermit == (int)TypeofPermit.GeneralConstruction)// if it is combined documents for other wt should be populated || typeofPermit == (int)TypeofPermit.GCMH || typeofPermit == (int)TypeofPermit.GCST || typeofPermit == (int)TypeofPermit.GCMHST)
                            {
                                requiredDocumentName = "No Document is required";
                            }
                            else
                                requiredDocumentName = "ACCORD FORM";

                        }
                        else
                            requiredDocumentName = "ACCORD FORM";
                    }

                    if (licenseType.Equals(LicenseType.PR))
                        requiredDocumentName = "OWNER INSURANCE WAIVER DOCUMENT";

                    if (licenseType.Equals(LicenseType.GC) || licenseType.Equals(LicenseType.S))
                        requiredDocumentName = "No Document is required";

                    #region On Update - Delete the appropriate Document
                    if (context.MessageName == MessageName.Update)
                    {
                        crmTrace.AppendLine("Update Call!");
                        EntityReference Pre_licensee = preImageEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.LicenseeType);
                        Entity Pre_Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, Pre_licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                        string Pre_licenseType_Name = Pre_Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                        string Pre_licenseType = Pre_licenseType_Name.Substring(0, Pre_licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                        crmTrace.AppendLine("Pre_licenseType: " + Pre_licenseType);

                        if (Pre_licenseType.Equals(LicenseType.PE) || Pre_licenseType.Equals(LicenseType.LA) || Pre_licenseType.Equals(LicenseType.RA))
                            deleteDocumentName = "ACCORD FORM";

                        if (Pre_licenseType.Equals(LicenseType.PR))
                            deleteDocumentName = "OWNER INSURANCE WAIVER DOCUMENT";

                        if (Pre_licenseType.Equals(LicenseType.GC) || Pre_licenseType.Equals(LicenseType.S))
                            deleteDocumentName = "CONTRACTOR SEAL & SIGNATURE";

                        ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { deleteDocumentName });
                        ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                        if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                            Entity documentType = (Entity)documentTypeResponse.Entities[0];
                            string documentTypeId = documentType.Id.ToString();
                            DeleteDocuments_RelatedtoPermit(service, targetEntity, documentTypeId, crmTrace);
                        }

                    }
                    #endregion

                    CreateDocumentlist(service, targetEntity, requiredDocumentName, JobFilingId, crmTrace);
                    // Temp Waiver/Defferal Document
                    //CreateDocumentlist(service, targetEntity, "PW2 Waiver/Deferral Sample", JobFilingId, crmTrace);

                    #region  Sidewalk shed -Permit renewal justification letter
                    if (targetEntity.Contains(WorkPermitEntityAttributeName.IsRenewalPermit) && context.MessageName == MessageName.Create)
                    {
                        bool isrenewal = targetEntity.Contains(WorkPermitEntityAttributeName.IsRenewalPermit) ? targetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.IsRenewalPermit) : false;
                        int typeofPermit = targetEntity.Contains(WorkPermitEntityAttributeName.TypeofPermit) ? targetEntity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value : 1;
                        if (isrenewal && typeofPermit == (int)TypeofPermit.SideWalkShed)
                        {
                            requiredDocumentName = "Sidewalk Shed - Permit Renewal Justification Letter";
                            CreateDocumentlist(service, targetEntity, requiredDocumentName, JobFilingId, crmTrace);

                        }
                    }
                    #endregion

                    #region Owner Type is SCA
                    if(targetEntity.Contains(WorkPermitEntityAttributeName.GotoJobFiling) && targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling] != null)
                    {
                        EntityReference JFRef = targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.GotoJobFiling);
                        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, JFRef.Id, new ColumnSet(JobFilingEntityAttributeName.OwnerTypePW1Statement));
                        if(JF.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement))
                        {
                            if(JF.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value == (int)OwnerTypeJobFiling.SCA)
                            {
                                requiredDocumentName = "NYCSCA wrap-up insurance program";
                                CreateDocumentlist(service, targetEntity, requiredDocumentName, JobFilingId, crmTrace);
                            }
                        }
                    }

                    #endregion

                }
                #endregion
                crmTrace.AppendLine("WorkPermitDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void WorkPermitDocuments_AN(IOrganizationService service, Entity targetEntity, Entity preImageEntity, IPluginExecutionContext context, StringBuilder crmTrace)
        {
            try
            {
                Guid JobFilingId = ((EntityReference)targetEntity[WorkPermitEntityAttributeName.JobFilingRelationshipID]).Id;
                #region WorkPermit Documents - Based on Site Safety Manager License Type
                if (targetEntity.Contains(WorkPermitEntityAttributeName.AntennaLicenseType) && targetEntity.Attributes[WorkPermitEntityAttributeName.AntennaLicenseType] != null)
                {
                    EntityReference licensee = targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.AntennaLicenseType);
                    Entity Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                    string licenseType_Name = Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                    string licenseType = licenseType_Name.Substring(0, licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                    crmTrace.AppendLine("licenseType: " + licenseType);
                    string addtionalDocumentName = "No Document Needed";
                    string removeDocumentName = "No Document Needed";
                    if (licenseType.Equals(LicenseType.M))
                        addtionalDocumentName = "Site Safety Program - BEST Approval Letter";


                    #region On Update - Delete the appropriate Document
                    if (context.MessageName == MessageName.Update && preImageEntity.Contains(WorkPermitEntityAttributeName.AntennaLicenseType))
                    {
                        crmTrace.AppendLine("Update Call!");
                        EntityReference Pre_licensee = preImageEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.AntennaLicenseType);
                        Entity Pre_Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, Pre_licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                        string Pre_licenseType_Name = Pre_Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                        string Pre_licenseType = Pre_licenseType_Name.Substring(0, licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                        crmTrace.AppendLine("Pre_licenseType: " + Pre_licenseType);

                        if (Pre_licenseType.Equals(LicenseType.M))
                            removeDocumentName = "Site Safety Program - BEST Approval Letter";

                        if (removeDocumentName != "No Document Needed")
                        {
                            ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { removeDocumentName });
                            ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                            EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                            if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                            {
                                crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                                Entity documentType = (Entity)documentTypeResponse.Entities[0];
                                string documentTypeId = documentType.Id.ToString();
                                DeleteDocuments_RelatedtoPermit(service, targetEntity, documentTypeId, crmTrace);
                            }

                        }
                    }
                    #endregion

                    CreateDocumentlist(service, targetEntity, addtionalDocumentName, JobFilingId, crmTrace);
                }
                else if (targetEntity.Attributes[WorkPermitEntityAttributeName.AntennaLicenseType] == null)
                {
                    var removeDocumentName = "Site Safety Program - BEST Approval Letter";
                    ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { removeDocumentName });
                    ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                    if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                        Entity documentType = (Entity)documentTypeResponse.Entities[0];
                        string documentTypeId = documentType.Id.ToString();
                        DeleteDocuments_RelatedtoPermit(service, targetEntity, documentTypeId, crmTrace);
                    }
                }

                #endregion

                crmTrace.AppendLine("WorkPermitDocuments_AN Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_AN", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        //public static void WorkPermitDocuments_PGL1(IOrganizationService service, Entity targetEntity, Entity preImageEntity, IPluginExecutionContext context, StringBuilder crmTrace)
        //{
        //    try
        //    {
        //        Guid JobFilingId = ((EntityReference)targetEntity[WorkPermitEntityAttributeName.JobFilingRelationshipID]).Id;
        //        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId, new ColumnSet(JobFilingEntityAttributeName.PGL1Description));
        //        string PGL1Desc = JF.GetAttributeValue<string>(JobFilingEntityAttributeName.PGL1Description);
        //        crmTrace.AppendLine("PGL1Desc: " + PGL1Desc);
        //        #region WorkPermit Documents - Based on PGL1
        //        if (!string.IsNullOrEmpty(PGL1Desc))
        //        {
        //            crmTrace.AppendLine("PGL1Desc.IndexOf: " + PGL1Desc.IndexOf(":"));
        //            crmTrace.AppendLine("PGL1Desc.Length: " + PGL1Desc.Length);
        //            string PGL1_Amount = PGL1Desc.Substring(PGL1Desc.IndexOf(":") + 1, PGL1Desc.Length - (PGL1Desc.IndexOf(":") + 1)).Trim();
        //            if (targetEntity.Contains(WorkPermitEntityAttributeName.IsTowerCraneUsed))
        //            {
        //                if (targetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.IsTowerCraneUsed))
        //                    PGL1_Amount = "80M";
        //            }
        //            crmTrace.AppendLine("PGL1_Amount: " + PGL1_Amount);
        //            #region Document Configurations
        //            ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { WorkPermitEntityAttributeName.EntityLogicalName });
        //            ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });

        //            EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldType, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType },
        //                new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);

        //            if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
        //            {
        //                crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
        //                #region Looping document configs
        //                foreach (Entity docConfig in documentRequiredConfigurationsResponse.Entities)  // check if target entity contains Field mapping (schema name of the field that requires doc)
        //                {
        //                    string doc_PGL1 = docConfig.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();
        //                    Dictionary<string, Guid> DocNames = new Dictionary<string, Guid>();
        //                    if (docConfig.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType))
        //                        DocNames.Add(docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Name, docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType).Id);
        //                    if (docConfig.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
        //                        DocNames.Add(docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType).Name, docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType).Id);
        //                    if (docConfig.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
        //                        DocNames.Add(docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType).Name, docConfig.GetAttributeValue<EntityReference>(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType).Id);

        //                    if (doc_PGL1 == PGL1_Amount)
        //                    {
        //                        //Create if already does not exist documents then create
        //                        foreach (var doc in DocNames)
        //                        {
        //                            crmTrace.AppendLine("doc.Key: " + doc.Key);
        //                            crmTrace.AppendLine("doc.Value: " + doc.Value);
        //                            bool ifAlreadyExist = DocumentItemUploadHandler.CheckDocumentAlreadyExists(service, targetEntity, doc.Value);
        //                            crmTrace.AppendLine("ifAlreadyExist: " + ifAlreadyExist);
        //                            if (!ifAlreadyExist)
        //                                CreateDocumentlist_Id(service, targetEntity, doc.Value, JobFilingId, crmTrace);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        //Check and Delete documents
        //                        foreach (var doc in DocNames)
        //                        {
        //                            DocumentItemUploadHandler.CheckandDeleteIfDocumentExists_Permit(service, targetEntity.Id.ToString(), doc.Value, crmTrace);
        //                        }
        //                    }
        //                }
        //                #endregion
        //            }
        //            #endregion
        //        }
        //        #endregion
        //        crmTrace.AppendLine("WorkPermitDocuments_PGL1 Completed!");
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", null, crmTrace.ToString(), null, null);
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WorkPermitDocuments_PGL1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //}

        public static void JobFilingSealandSignatureDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                string requiredDocumentName = "DPL-1: Design Professional Seal & Signature";
                crmTrace.AppendLine("JobFilingSealandSignatureDocuments Started!");
                #region Added 08/16/2018 PA PAA Do not populate documents if no intend to change requirements
                if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA &&
                    targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))
                {
                    crmTrace.AppendLine("Start 08/16/2018 PA PAA Do not populate documents if no intend to change requirements");
                    crmTrace.AppendLine("filingType: " + "PAA");
                    if (targetEntity.Contains(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp))
                    {
                        ColumnSet columns = new ColumnSet(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                        Entity placeofAssembly = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp).Id, columns);
                        crmTrace.AppendLine("placeofAssembly: " + placeofAssembly.ToString());
                        if (!placeofAssembly.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans))
                        {
                            return;
                        }
                    }

                }
                #endregion

                #region WorkPermit Doucments
                Guid JobFilingId = targetEntity.Id;
                if (targetEntity.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                {
                    EntityReference licensee = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.LicenseLookupField);
                    Entity Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                    string licenseType_Name = Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                    string licenseType = licenseType_Name.Substring(0, licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                    crmTrace.AppendLine("licenseType: " + licenseType);

                    ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { requiredDocumentName });
                    ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                    if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                    {
                        Entity documentType = (Entity)documentTypeResponse.Entities[0];
                        string documentTypeId = documentType.Id.ToString();

                        #region OLD Logic commented on 08/08/2017
                        //if (licenseType.Contains(LicenseType.PR))
                        //{
                        //    crmTrace.AppendLine("licenseType.Contains(LicenseType.PR) ");
                        //    DeleteDocuments_RelatedtoJob(service, targetEntity, documentTypeId, crmTrace);

                        //}
                        //else
                        //{
                        //    if (!DocumentItemUploadHandler.CheckDocumentAlreadyExists(service, targetEntity, Guid.Parse(documentTypeId)))
                        //        CreateDocumentlist(service, targetEntity, requiredDocumentName, JobFilingId, crmTrace);
                        //}
                        #endregion

                        #region New Logic Added on 08/08/2017
                        if (licenseType.Equals(LicenseType.PE) || licenseType.Equals(LicenseType.RA) || licenseType.Equals(LicenseType.LA) || licenseType.Equals(LicenseType.P) || licenseType.Equals(LicenseType.O) || licenseType.Equals(LicenseType.A) || licenseType.Equals(LicenseType.F))
                        {
                            if (!DocumentItemUploadHandler.CheckDocumentAlreadyExists(service, targetEntity, Guid.Parse(documentTypeId)))
                                CreateDocumentlist(service, targetEntity, requiredDocumentName, JobFilingId, crmTrace);
                        }
                        else
                        {
                            crmTrace.AppendLine("Remove DPL1");
                            DeleteDocuments_RelatedtoJob(service, targetEntity, documentTypeId, crmTrace);
                        }
                        #endregion


                        //throw new Exception("DPL1 Test");
                    }



                }



                #endregion

                crmTrace.AppendLine("JobFilingSealandSignatureDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - JobFilingSealandSignatureDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AHVDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("AHVDocuments Started!");
                #region AHV Documents
                //Guid JobFilingId = ((EntityReference)targetEntity[PW5AfterHoursAttributeNames.JobFilingLookUp]).Id;
                Guid JobFilingId = Guid.Empty;
                //string ContractorSeal = "CONTRACTOR SEAL";
                string ContractorSignature = "CONTRACTOR SEAL & SIGNATURE";
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.License))
                {
                    EntityReference licensee = targetEntity.GetAttributeValue<EntityReference>(PW5AfterHoursAttributeNames.License);
                    Entity Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                    string licenseType_Name = Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                    string licenseType = licenseType_Name.Substring(0, licenseType_Name.IndexOf("-")).Replace(" ", String.Empty);
                    crmTrace.AppendLine("licenseType: " + licenseType);

                    if (licenseType.Equals(LicenseType.PE) || licenseType.Equals(LicenseType.LA) || licenseType.Equals(LicenseType.RA))
                        ContractorSignature = "ACCORD FORM";

                    if (licenseType.Equals(LicenseType.PR))
                        ContractorSignature = "OWNER INSURANCE WAIVER DOCUMENT";

                    if (licenseType.Equals(LicenseType.A)) // Electrical Liscense Type
                        ContractorSignature = "DPL-1: Design Professional Seal & Signature";

                    if (licenseType.Equals(LicenseType.GC) || licenseType.Equals(LicenseType.S))
                        ContractorSignature = "No Document is required";

                }

                // CreateDocumentlist(service, targetEntity, ContractorSeal);
                CreateDocumentlist(service, targetEntity, ContractorSignature, JobFilingId, crmTrace);

                #endregion
                crmTrace.AppendLine("AHVDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        //Created On 10/30/2017 for Nov 30 release 
        public static void AHVFeeExemptDocuments(IOrganizationService service, Entity targetEntity, Entity preImageEntity, IPluginExecutionContext context, StringBuilder crmTrace)
        {
            try
            {
                string DocumentNameACRIS = "ACRIS REPORT AHV";
                string DocumentNameletter = "Government/City owned fee exemption letter";
                Guid JobFilingId = Guid.Empty;
                crmTrace.AppendLine("AHVFeeExemptDocuments Started!");
                #region AHVFeeExempt Documents -Based on Acceptable Fee Exempt Documents List
                if (context.MessageName == MessageName.Create)
                {
                    if (targetEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) && targetEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != null)
                    {
                        if (targetEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 1)
                        {
                            DocumentNameACRIS = "ACRIS REPORT AHV"; // Create new document prior to Permit Issance with ACRIS REPORT AHV as Required Item Number
                            CreateDocumentlist(service, targetEntity, DocumentNameACRIS, JobFilingId, crmTrace);
                        }

                        if (targetEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 2)
                        {
                            DocumentNameletter = "Government/City owned fee exemption letter";
                            CreateDocumentlist(service, targetEntity, DocumentNameletter, JobFilingId, crmTrace);
                        }
                    }
                }
                #endregion
                if (context.Depth > 1)
                    return;
                #region On Update - Delete the appropriate Document
                if (context.MessageName == MessageName.Update)
                {
                    crmTrace.AppendLine("Update Call!");
                    if ((!preImageEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) || (preImageEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) && preImageEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != null && preImageEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != targetEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] && preImageEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 1)) //preimage null or preimage 1
                        &&
                     targetEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) && targetEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != null && targetEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 2) //target not null and target=2
                    {
                        ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentNameACRIS });
                        ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);
                        if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                            Entity documentType = (Entity)documentTypeResponse.Entities[0];
                            string documentTypeId = documentType.Id.ToString();
                            DeleteDocuments_AHVFeeExempt(service, targetEntity, documentTypeId, crmTrace);
                        }
                        CreateDocumentlist(service, targetEntity, DocumentNameletter, JobFilingId, crmTrace);
                    }
                    else if ((!preImageEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) || (preImageEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) && preImageEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != null && preImageEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != targetEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] && preImageEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 2)) &&
                            targetEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments) && targetEntity[AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments] != null && targetEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceFeeExemptAttributeNames.FeeExemptDocuments).Value == 1)
                    {
                        ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentNameletter });
                        ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);

                        if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                            Entity documentType = (Entity)documentTypeResponse.Entities[0];
                            string documentTypeId = documentType.Id.ToString();
                            DeleteDocuments_AHVFeeExempt(service, targetEntity, documentTypeId, crmTrace);
                        }
                        CreateDocumentlist(service, targetEntity, DocumentNameACRIS, JobFilingId, crmTrace);
                    }
                    else if (targetEntity.Contains(AfterHourVarianceFeeExemptAttributeNames.IsAHVapplicationfeeexempt) && targetEntity[AfterHourVarianceFeeExemptAttributeNames.IsAHVapplicationfeeexempt] != null && !targetEntity.GetAttributeValue<bool>(AfterHourVarianceFeeExemptAttributeNames.IsAHVapplicationfeeexempt))
                    {
                        ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentNameletter });
                        ConditionExpression documentTypeCondition1 = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { DocumentNameACRIS });
                        //     ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, documentTypeCondition1 }, LogicalOperator.Or);
                        crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);

                        // throw new Exception("Test");
                        if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        {
                            foreach (Entity documentType in documentTypeResponse.Entities) //retriving multiple but checking only one so added forecah
                            {
                                crmTrace.AppendLine("documentTypeResponse.Entities.Count: " + documentTypeResponse.Entities.Count);
                                //Entity documentType = (Entity)documentTypeResponse.Entities[0];
                                string documentTypeId = documentType.Id.ToString();
                                DeleteDocuments_AHVFeeExempt(service, targetEntity, documentTypeId, crmTrace);
                            }

                        }
                    }

                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - AHVFeeExemptDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


        public static void En2Documents(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("En2Documents Started!");
                #region En2 Documents
                Guid JobFilingId = ((EntityReference)targetEntity[EN2EntityAttributeNames.JobFilingGuid]).Id;
                //string ProgressInspSeal = "PROGRESS INSPECTOR SEAL";
                string ProgressInspSignature = "PROGRESS INSPECTOR SEAL & SIGNATURE";
                //CreateDocumentlist(service, targetEntity, ProgressInspSeal);
                CreateDocumentlist(service, targetEntity, ProgressInspSignature, JobFilingId, crmTrace);

                #endregion
                crmTrace.AppendLine("En2Documents Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - En2Documents", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void WithdrawalsDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("WithdrawalsDocuments Started!");
                #region WithdrawalsDocuments Documents
                Guid JobFilingId = ((EntityReference)targetEntity[WithdrawalRequestEntityAttributeName.GotoJobFiling]).Id;
                //string OwnerSignature = "OWNER SIGNATURE";
                string RequesterSignature = "REQUESTER SEAL & SIGNATURE";
                CreateDocumentlist(service, targetEntity, RequesterSignature, JobFilingId, crmTrace);
                //CreateDocumentlist(service, targetEntity, OwnerSignature, JobFilingId);
                #endregion
                crmTrace.AppendLine("WithdrawalsDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - WithdrawalsDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SupersedingDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("SupersedingDocuments Started!");
                #region Superseding Documents
                Guid JobFilingId = ((EntityReference)targetEntity[SupersedingRequestEntityAttributeName.GotoJobFiling]).Id;
                //string OwnerSignature = "OWNER SIGNATURE";
                string RequesterSignature = "REQUESTER SEAL & SIGNATURE";
                CreateDocumentlist(service, targetEntity, RequesterSignature, JobFilingId, crmTrace);
                //CreateDocumentlist(service, targetEntity, OwnerSignature, JobFilingId);
                #endregion
                crmTrace.AppendLine("SupersedingDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SupersedingDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ProgressInspectionDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("ProgressInspectionDocuments Started!");
                #region ProgressInspection Documents
                bool iscopiedfromPAA = (targetEntity.Contains(ProgressInspectionCategoryAttributeNames.IsCopiedfromPAA) && targetEntity.Attributes[ProgressInspectionCategoryAttributeNames.IsCopiedfromPAA] != null) ? targetEntity.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.IsCopiedfromPAA) : false;
                crmTrace.AppendLine("iscopiedfromPAA :" + iscopiedfromPAA.ToString());
                if (iscopiedfromPAA)
                    return;
                Guid JobFilingId = ((EntityReference)targetEntity[ProgressInspectionCategoryAttributeNames.GoToJobFiling]).Id;
                //string ProgressInspSeal = "PROGRESS INSPECTOR SEAL";
                string ProgressInspSignature = "PROGRESS INSPECTOR SEAL & SIGNATURE";
                //CreateDocumentlist(service, targetEntity, ProgressInspSeal);
                CreateDocumentlist(service, targetEntity, ProgressInspSignature, JobFilingId, crmTrace);

                #endregion
                crmTrace.AppendLine("ProgressInspectionDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - ProgressInspectionDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SpecialInspectionDocuments(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("SpecialInspectionDocuments Started!");
                #region SpecialInspection Documents
                bool iscopiedfromPAA = (targetEntity.Contains(SpecialInspectionCategoriesAttributeNames.IsCopiedfromPAA) && targetEntity.Attributes[SpecialInspectionCategoriesAttributeNames.IsCopiedfromPAA] != null) ? targetEntity.GetAttributeValue<bool>(SpecialInspectionCategoriesAttributeNames.IsCopiedfromPAA) : false;
                crmTrace.AppendLine("iscopiedfromPAA :" + iscopiedfromPAA.ToString());
                if (iscopiedfromPAA)
                    return;
                Guid JobFilingId = ((EntityReference)targetEntity[SpecialInspectionCategoriesAttributeNames.GoToJobFiling]).Id;
                //string SpecialInspSeal = "SPECIAL INSPECTOR SEAL";
                string SpecialInspSignature = "SPECIAL INSPECTOR SEAL & SIGNATURE";
                // CreateDocumentlist(service, targetEntity, SpecialInspSeal);
                CreateDocumentlist(service, targetEntity, SpecialInspSignature, JobFilingId, crmTrace);

                #endregion
                crmTrace.AppendLine("SpecialInspectionDocuments Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - SpecialInspectionDocuments", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteDocuments_RelatedtoPermit(IOrganizationService service, Entity targetEntity, string DocumentTypeId, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("DeleteDocuments_RelatedtoPermit Started!");
                #region Work Pemrit Documents

                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoWorkPermit, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { DocumentTypeId });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName, ent.Id);

                    }
                }

                #endregion
                crmTrace.AppendLine("DeleteDocuments_RelatedtoPermit Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        public static void DeleteDocuments_AHVFeeExempt(IOrganizationService service, Entity targetEntity, string DocumentTypeId, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("DeleteDocuments_RelatedtoPermit Started!");
                #region Work Pemrit Documents

                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoAHVFeeExempt, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { DocumentTypeId });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName, ent.Id);

                    }
                }

                #endregion
                crmTrace.AppendLine("DeleteDocuments_RelatedtoPermit Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_AHVFeeExempt", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        public static void DeleteDocuments_RelatedtoJob(IOrganizationService service, Entity targetEntity, string DocumentTypeId, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("DeleteDocuments_RelatedtoJob Started!");
                #region Work Pemrit Documents

                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { DocumentTypeId });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName, ent.Id);

                    }
                }

                #endregion
                crmTrace.AppendLine("DeleteDocuments_RelatedtoJob Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - DeleteDocuments_RelatedtoJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateDocumentlist(IOrganizationService service, Entity targetEntity, string RequiredItemNumber, Guid JobFilingId, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { RequiredItemNumber });
                EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.PortalDocumentDescription, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage }, new ConditionExpression[] { documentTypeCondition }, LogicalOperator.And);

                if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentTypeResponse.count" + documentTypeResponse.Entities.Count);
                    Entity documentType = (Entity)documentTypeResponse.Entities[0];
                    string PriortoStage = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                    crmTrace.AppendLine("PriortoStage" + PriortoStage);
                    int PriortoStatus = documentTypeResponse.Entities[0].GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                    crmTrace.AppendLine("PriortoStatus" + PriortoStatus);
                    Entity DocumentList = new Entity();
                    DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentType.Id));
                    if (documentType.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredItemNumber).ToLower().Contains("plan"))
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(1));
                    else
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, PriortoStage);
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentUploadNote, documentType.Contains(DocumentTypeEntityAttributeName.PortalDocumentDescription) ?
                            documentType.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PortalDocumentDescription) : string.Empty);
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue((int)DocumentStatus.Required));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentTypeResponse.Entities[0].GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                    //DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId));
                    bool AllowWaiver = documentTypeResponse.Entities[0].Contains(DocumentTypeEntityAttributeName.AllowWaiver) ? documentTypeResponse.Entities[0].GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver) : false;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, AllowWaiver);
                    bool AllowDeferral = documentTypeResponse.Entities[0].Contains(DocumentTypeEntityAttributeName.AllowDeferral) ? documentTypeResponse.Entities[0].GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowDeferral) : false;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, AllowDeferral);


                    if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.JobFiling));
                        string name = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                        if(targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        {
                            DocumentList.Attributes.Remove(DocumentListEntityAttributeName.AllowDeferral);
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, false);
                        }
                    }
                    if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoWorkPermit, new EntityReference(WorkPermitEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.WorkPermit));
                        string name = targetEntity.GetAttributeValue<string>(WorkPermitEntityAttributeName.TrackingNumber);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoAHV, new EntityReference(AfterHourVarianceAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.AHV));
                        string name = targetEntity.GetAttributeValue<string>(AfterHourVarianceAttributeNames.AHVPermitNumber);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == AfterHourVarianceFeeExemptAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoAHVFeeExempt, new EntityReference(AfterHourVarianceFeeExemptAttributeNames.EntityLogicalName, targetEntity.Id));
                        // DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.AHV));
                        string name = targetEntity.GetAttributeValue<string>(AfterHourVarianceFeeExemptAttributeNames.AHVPermitNumber);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        // DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == EN2EntityAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoEN2, new EntityReference(EN2EntityAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.En2));
                        string name = "EN2";
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == ProgressInspectionCategoryEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoProgressInspection, new EntityReference(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.ProgressInspection));
                        string name = "Progress Inspection Category";
                        if (targetEntity.Contains(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement))
                        {
                            EntityReference Insp_CompRef = targetEntity.GetAttributeValue<EntityReference>(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement);
                            Entity Insp_Comp = service.Retrieve(InspectionsComponentsEntityAttributeName.EntityLogicalName, Insp_CompRef.Id, new ColumnSet(InspectionsComponentsEntityAttributeName.Name));
                            string Insp_Comp_Name = Insp_Comp.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);
                            name = Insp_Comp_Name;
                        }
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoSpecialInspection, new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.SpecialInspection));
                        string name = "Special Inspection Category";
                        if (targetEntity.Contains(SpecialInspectionCategoriesAttributeNames.AddRequirement))
                        {
                            EntityReference Insp_CompRef = targetEntity.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.AddRequirement);
                            Entity Insp_Comp = service.Retrieve(InspectionsComponentsEntityAttributeName.EntityLogicalName, Insp_CompRef.Id, new ColumnSet(InspectionsComponentsEntityAttributeName.Name));
                            string Insp_Comp_Name = Insp_Comp.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);
                            name = Insp_Comp_Name;
                        }
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoWithdrawalRequest, new EntityReference(WithdrawalRequestEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.WithdrawalRequest));
                        string name = targetEntity.GetAttributeValue<string>(WithdrawalRequestEntityAttributeName.WithdrawalRequestNumber);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoSupersedingRequest, new EntityReference(SupersedingRequestEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.SuprsedingRequest));
                        string name = targetEntity.GetAttributeValue<string>(SupersedingRequestEntityAttributeName.SupersedingRequestNumber);
                        string docname = documentTypeResponse.Entities[0].GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);

                    }
                    //throw new Exception("Test");
                    service.Create(DocumentList);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }  // CreateDocumentlist Method ends here

        public static void CreateDocumentlist_Id(IOrganizationService service, Entity targetEntity, Guid documentTypeGuid, Guid JobFilingId, StringBuilder crmTrace)
        {
            try
            {
                string[] ColumnNames_DocumentType = new string[] { DocumentTypeEntityAttributeName.PortalDocumentDescription, DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes };
                Entity documentTypeResponse = Retrieve(service, ColumnNames_DocumentType, documentTypeGuid, DocumentTypeEntityAttributeName.EntityLogicalName);
                if (documentTypeResponse != null)
                {
                    crmTrace.AppendLine("documentTypeResponse");
                    string PriortoStage = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                    crmTrace.AppendLine("PriortoStage" + PriortoStage);
                    int PriortoStatus = documentTypeResponse.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                    crmTrace.AppendLine("PriortoStatus" + PriortoStatus);
                    Entity DocumentList = new Entity();
                    DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentTypeResponse.Id));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, PriortoStage);
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentUploadNote, documentTypeResponse.Contains(DocumentTypeEntityAttributeName.PortalDocumentDescription) ?
                            documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PortalDocumentDescription) : string.Empty);
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue((int)DocumentStatus.Required));
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentTypeResponse.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                    //DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId));
                    bool AllowWaiver = documentTypeResponse.Contains(DocumentTypeEntityAttributeName.AllowWaiver) ? documentTypeResponse.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver) : false;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, AllowWaiver);
                    bool AllowDeferral = documentTypeResponse.Contains(DocumentTypeEntityAttributeName.AllowDeferral) ? documentTypeResponse.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowDeferral) : false;
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, AllowDeferral);


                    if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.JobFiling));
                        string name = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoWorkPermit, new EntityReference(WorkPermitEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.WorkPermit));
                        string name = targetEntity.GetAttributeValue<string>(WorkPermitEntityAttributeName.TrackingNumber);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoAHV, new EntityReference(AfterHourVarianceAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.AHV));
                        string name = targetEntity.GetAttributeValue<string>(AfterHourVarianceAttributeNames.AHVPermitNumber);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == AfterHourVarianceFeeExemptAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoAHVFeeExempt, new EntityReference(AfterHourVarianceFeeExemptAttributeNames.EntityLogicalName, targetEntity.Id));
                        // DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.AHV));
                        string name = targetEntity.GetAttributeValue<string>(AfterHourVarianceFeeExemptAttributeNames.AHVPermitNumber);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        // DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == EN2EntityAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoEN2, new EntityReference(EN2EntityAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.En2));
                        string name = "EN2";
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }
                    if (targetEntity.LogicalName == ProgressInspectionCategoryEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoProgressInspection, new EntityReference(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.ProgressInspection));
                        string name = "Progress Inspection Category";
                        if (targetEntity.Contains(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement))
                        {
                            EntityReference Insp_CompRef = targetEntity.GetAttributeValue<EntityReference>(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement);
                            Entity Insp_Comp = service.Retrieve(InspectionsComponentsEntityAttributeName.EntityLogicalName, Insp_CompRef.Id, new ColumnSet(InspectionsComponentsEntityAttributeName.Name));
                            string Insp_Comp_Name = Insp_Comp.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);
                            name = Insp_Comp_Name;
                        }
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoSpecialInspection, new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.SpecialInspection));
                        string name = "Special Inspection Category";
                        if (targetEntity.Contains(SpecialInspectionCategoriesAttributeNames.AddRequirement))
                        {
                            EntityReference Insp_CompRef = targetEntity.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.AddRequirement);
                            Entity Insp_Comp = service.Retrieve(InspectionsComponentsEntityAttributeName.EntityLogicalName, Insp_CompRef.Id, new ColumnSet(InspectionsComponentsEntityAttributeName.Name));
                            string Insp_Comp_Name = Insp_Comp.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.Name);
                            name = Insp_Comp_Name;
                        }
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == WithdrawalRequestEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoWithdrawalRequest, new EntityReference(WithdrawalRequestEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.WithdrawalRequest));
                        string name = targetEntity.GetAttributeValue<string>(WithdrawalRequestEntityAttributeName.WithdrawalRequestNumber);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);
                    }

                    if (targetEntity.LogicalName == SupersedingRequestEntityAttributeName.EntityLogicalName)
                    {
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.GotoSupersedingRequest, new EntityReference(SupersedingRequestEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.SuprsedingRequest));
                        string name = targetEntity.GetAttributeValue<string>(SupersedingRequestEntityAttributeName.SupersedingRequestNumber);
                        string docname = documentTypeResponse.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, name + "-" + docname);

                    }
                    //throw new Exception("Test");
                    service.Create(DocumentList);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SealSignaturesHandler - CreateDocumentlist_Id", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


    } //class ends
} // namespace ends
