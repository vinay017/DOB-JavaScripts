﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginLibrary;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobNumberGenerator : PluginHandlerBase
    {
        public static Entity GeneratejobFilingNumber(IOrganizationService service, IPluginExecutionContext context, Entity targetEntity, StringBuilder crmTrace)
        {
            
            bool jobNumberRequired = false;
            string jobNumber = string.Empty; ;
            int jobNumberPadding = 8;
            Decimal jobAutoNumber = 0;
            Decimal filingAutoNumber = 0;
            char paddingChar = '0';
            //string jobformatString = "{0}-{1}-{2}";
            //string filingformatString = "{0}-{1}-{2}";

            string jobformatString = "{0}{1}";
            string filingformatString = "{0}{1}";

            string jobNumberFormatted = string.Empty;
            string filingNumberFormatted = string.Empty;
            string borough = string.Empty;
            string filingType = string.Empty;
            int filingTypeIntvalue = 0;
            bool CreateSuperseding = false;

            //PW1 standardization changes: Start
            bool isHistoricFiling = false;
            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) == true)
            {
                isHistoricFiling = true;
                crmTrace.AppendLine("Historic Filing.");
            }

            FeeCalculationObject targetFCObject = new FeeCalculationObject();
            FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(targetEntity, targetFCObject, crmTrace);
            //PW1 standardization changes: End

            try
            {
                //Changed job number logic for better performance to avoid locking 
                //string fetchXML = @"<fetch mapping='logical' aggregate='true' version='1.0'>
                //                       <entity name='dobnyc_autonumberentity'>
                //                        <attribute name='dobnyc_jobnumbercounter' alias='dobnyc_jobnumbercounter' aggregate='max' />
                //                        <attribute name='dobnyc_jobnumberpadding' alias='dobnyc_jobnumberpadding' groupby='true' />
                //                        <attribute name='dobnyc_paddingcharacter' alias='dobnyc_paddingcharacter' groupby='true' />
                //                        <filter>
                //                            <condition attribute='dobnyc_name' operator='eq' value='counter record' />
                //                        </filter>
                //                       </entity>
                //                    </fetch>";

                //EntityCollection response = service.RetrieveMultiple(new FetchExpression(fetchXML));


                using (DataSet ds = new DataSet())
                {
                    SqlDataAdapter da = new SqlDataAdapter();
                    DataTable response = new DataTable();
                    SqlConnection sqlConn = new SqlConnection();
                    SqlCommand sqlCommand = new SqlCommand();
                    string connString = string.Empty;

                    switch (context.OrganizationName)
                    {
                        case ParameterName.DevOrganisationName:
                            connString = ParameterName.DEVconnString; 
                            break;
                        case ParameterName.TestOrganisationName:
                            connString = ParameterName.TESTconnString;
                            break;
                        case ParameterName.StgOrganisationName:
                            connString = ParameterName.STGconnString;
                            break;
                        case ParameterName.ProdOrganisationName:
                            connString = ParameterName.PRODconnString;
                            break;

                        default:
                            break;
                    }
                    //CustomConfigurations.GetXMLConfigurationKey(ConfigKeys.CRMDBConnectionString);
                    string spName = ParameterName.AutoiNumberSpName;//"dobnyc_autonumberentity_retrieve"; //CustomConfigurations.GetXMLConfigurationKey(ConfigKeys.DashboardRetrieveStoredProcedure);
                    sqlConn.ConnectionString = connString;
                    sqlConn.Open();
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandText = spName;


                    sqlCommand.Connection = sqlConn;
                    //Fill the DataAdapter with a SelectCommand
                    da.SelectCommand = sqlCommand;
                    da.Fill(ds, "datatable");
                    response = ds.Tables["datatable"];

                    //Changing Query Expression to FetchXML
                    //ConditionExpression autoNumberCondition = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { "Counter Record" });
                    //EntityCollection response = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.JobNumberCounterAttribute,JobAutoNumberEntityAttribute.EntityNameAttribute ,JobAutoNumberEntityAttribute.JobNumberPaddingAttribute, JobAutoNumberEntityAttribute.FilingNumberCounterAttribute, JobAutoNumberEntityAttribute.PaddingCharacterAttribute }, new ConditionExpression[] { autoNumberCondition }, LogicalOperator.And);
                    if (response != null && response.Rows.Count > 0)
                    {

                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BoroughAttributeName))
                            borough = Enum.GetName(typeof(Borough), ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BoroughAttributeName]).Value);

                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName))
                        {
                            filingType = Enum.GetName(typeof(FilingTypes), ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value);
                            filingTypeIntvalue = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value;
                            crmTrace.AppendLine("filingTypeIntvalue= " + filingTypeIntvalue);
                        }

                        #region Superseding DP
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CreateaSupersedingRequest) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                        {
                            crmTrace.AppendLine("parent Job is there ");
                            Guid ParentJobGuid = ((EntityReference)targetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                            crmTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());

                            // Reterieve all the filing with same Parent Job Filing
                            string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.IsPlanApproved };

                            crmTrace.AppendLine("Target entity contains JobFilingEntityAttributeName.CreateaSupersedingRequest ");
                            CreateSuperseding = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CreateaSupersedingRequest);
                            crmTrace.AppendLine("CreateSuperseding= " + CreateSuperseding);
                            #region Superseding Request
                            if (CreateSuperseding == true)
                            {
                                string RequestformatString = "{0}{1}";
                                string RequestFormatted = string.Empty;
                                Decimal SupersedingNumber = 0;
                                int Supersedingnumberpadding = 0;
                                char sppaddingChar = '0';

                                ConditionExpression autoNumberCondition1 = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { SupersedingRequestEntityAttributeName.EntityLogicalName });
                                EntityCollection Anresponse = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.SupersedingCounter, JobAutoNumberEntityAttribute.SupersedingPaddingChar, JobAutoNumberEntityAttribute.SupersedingPaddingNumber }, new ConditionExpression[] { autoNumberCondition1 }, LogicalOperator.And);
                                if (Anresponse != null && Anresponse.Entities.Count > 0)
                                {
                                    if (Anresponse.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingCounter))
                                        SupersedingNumber = decimal.Parse(Anresponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingCounter].ToString());
                                    if (Anresponse.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingPaddingNumber))
                                        Supersedingnumberpadding = int.Parse(Anresponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingPaddingNumber].ToString());
                                    if (Anresponse.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingPaddingChar))
                                        paddingChar = char.Parse(Anresponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingPaddingChar].ToString());

                                    crmTrace.AppendLine("SupersedingNumber: " + SupersedingNumber);
                                    RequestFormatted = String.Format(RequestformatString, "SR", Math.Round(SupersedingNumber, 0).ToString().PadLeft(Supersedingnumberpadding, sppaddingChar));
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RequestNumber, RequestFormatted);
                                    #region Update Counters
                                    Entity AN = new Entity();
                                    crmTrace.AppendLine("Start Updating Counter: " + RequestFormatted);
                                    AN.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                                    AN.Id = Anresponse.Entities[0].Id;
                                    AN.Attributes.Add(JobAutoNumberEntityAttribute.SupersedingCounter, (SupersedingNumber + 1));
                                    UpdateEntity(service, AN);
                                    crmTrace.AppendLine("End Updating Counter: " + RequestFormatted);
                                    #endregion
                                }


                                crmTrace.AppendLine("filingTypeIntvalue : " + filingTypeIntvalue);
                                ConditionExpression parentJobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                                EntityCollection parentJobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { parentJobfilingCondition }, LogicalOperator.And);
                                crmTrace.AppendLine("parentJobfiling count: " + parentJobfilingResponse.Entities.Count);

                                bool isPlanApproved = parentJobfilingResponse.Entities[0].GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPlanApproved);
                                crmTrace.AppendLine("isPlanApproved: " + isPlanApproved);
                                string parentJobNumber = parentJobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                                string parentFilingNumber = parentJobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                                crmTrace.AppendLine("parentJobNumber: " + parentJobNumber);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobNumberAttributeName, parentJobNumber);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, parentFilingNumber);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + parentFilingNumber);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.IsPlanApproved, isPlanApproved);

                                return targetEntity;

                            }

                            #endregion
                        }
                        #endregion


                        if (response.Rows[0][JobAutoNumberEntityAttribute.JobNumberCounterAttribute] != null)
                        {
                            crmTrace.AppendLine("manoj test");
                            //jobAutoNumber = Convert.ToDecimal(((AliasedValue)response.Rows[0][JobAutoNumberEntityAttribute.JobNumberCounterAttribute]).Value);
                            //filingAutoNumber = Convert.ToDecimal(((AliasedValue)response.Rows[0][JobAutoNumberEntityAttribute.JobNumberCounterAttribute]).Value);

                            jobAutoNumber = Convert.ToDecimal(response.Rows[0][JobAutoNumberEntityAttribute.JobNumberCounterAttribute]);
                            filingAutoNumber = Convert.ToDecimal(response.Rows[0][JobAutoNumberEntityAttribute.JobNumberCounterAttribute]);
                            crmTrace.AppendLine("jobAutoNumber");
                            crmTrace.AppendLine("filingAutoNumber");
                        }
                        if (response.Rows[0][JobAutoNumberEntityAttribute.JobNumberPaddingAttribute] != null)
                            jobNumberPadding = Convert.ToInt32((response.Rows[0][JobAutoNumberEntityAttribute.JobNumberPaddingAttribute]));
                        crmTrace.AppendLine("jobNumberPadding");

                        if (response.Rows[0][JobAutoNumberEntityAttribute.PaddingCharacterAttribute] != null)
                            paddingChar = Convert.ToChar((response.Rows[0][JobAutoNumberEntityAttribute.PaddingCharacterAttribute]));
                        crmTrace.AppendLine("paddingChar");


                        //filingNumberFormatted = String.Format(filingformatString, borough, filingType, Math.Round(filingAutoNumber, 0).ToString().PadLeft(jobNumberPadding, paddingChar));
                        //jobNumberFormatted = String.Format(jobformatString, borough, filingType, Math.Round(jobAutoNumber, 0).ToString().PadLeft(jobNumberPadding, paddingChar));
                        jobNumberFormatted = String.Format(jobformatString, borough, Math.Round(jobAutoNumber, 0).ToString().PadLeft(jobNumberPadding, paddingChar));
                        //Guid ParentJobGuid = ((EntityReference)targetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                        //crmTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());
                        if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                        {
                            crmTrace.AppendLine("Parent Job is not there");
                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobNumberAttributeName) && filingTypeIntvalue != (int)FilingTypes.SF)
                            {
                                jobNumberRequired = true;
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobNumberAttributeName, jobNumberFormatted);

                                crmTrace.AppendLine("Filing Number: " + jobNumberFormatted);
                            }

                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingNumberAttributeName))
                            {
                                string JobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                                if (filingTypeIntvalue == (int)FilingTypes.IF)
                                {
                                    filingNumberFormatted = "I1";
                                    crmTrace.AppendLine("Filing Number: " + filingNumberFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, JobNumber + "-" + filingNumberFormatted);
                                }

                                if (filingTypeIntvalue == (int)FilingTypes.PA)
                                {
                                    filingNumberFormatted = "P1";
                                    crmTrace.AppendLine("Filing Number: " + filingNumberFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, JobNumber + "-" + filingNumberFormatted);
                                }

                                //if (filingTypeIntvalue == (int)FilingTypes.SF)
                                //{
                                //    filingNumberFormatted = "S1";
                                //    crmTrace.AppendLine("Filing Number: " + filingNumberFormatted);
                                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, JobNumber + "-" + filingNumberFormatted);
                                //}


                            }
                        }

                        ///// If parent Job is there
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))

                        {
                            crmTrace.AppendLine("parent Job is there ");
                            Guid ParentJobGuid = ((EntityReference)targetEntity[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                            crmTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());

                            // Reterieve all the filing with same Parent Job Filing
                            string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.IsPlanApproved };

                            #region PAA

                            if (filingTypeIntvalue == (int)FilingTypes.PA)
                            {
                                
                                if (context.MessageName == MessageName.Create)
                                {

                                    //PW1 standardization changes: Start
                                    if (isHistoricFiling) //Old Logic
                                    {
                                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox)
                                        || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed))
                                            return targetEntity;
                                    }
                                    //else // New Logic
                                    //{
                                    //    if (targetFCObject.IsAN || targetFCObject.IsCC || targetFCObject.IsSG || targetFCObject.IsSF || targetFCObject.IsFN || targetFCObject.IsSH)
                                    //        return targetEntity;
                                    //}
                                    //PW1 standardization changes: End
                                    
                                }
                                crmTrace.AppendLine("filingTypeIntvalue : " + filingTypeIntvalue);
                                ConditionExpression parentJobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                                EntityCollection parentJobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { parentJobfilingCondition }, LogicalOperator.And);
                                crmTrace.AppendLine("parentJobfiling count: " + parentJobfilingResponse.Entities.Count);


                                string parentJobNumber = parentJobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                                crmTrace.AppendLine("parentJobNumber: " + parentJobNumber);

                                // Check all the filings with same Job Number and filingType
                                //ConditionExpression JobfilingCondition1 = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { parentJobNumber });
                                //ConditionExpression JobfilingCondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingTypeAttributeName, ConditionOperator.Equal, new string[] { filingTypeIntvalue.ToString() });
                                //ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                                //EntityCollection JobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { JobfilingCondition1, JobfilingCondition2, condition }, LogicalOperator.And);
                                //crmTrace.AppendLine("JobfilingResponse count: " + JobfilingResponse.Entities.Count);


                                //if (JobfilingResponse == null && JobfilingResponse.Entities == null && JobfilingResponse.Entities.Count == 0)
                                //{
                                //    crmTrace.AppendLine("No other child filing records found ");
                                //    int Count = JobfilingResponse.Entities.Count + 1;
                                //    filingNumberFormatted = "A" + Count.ToString();
                                //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, filingNumberFormatted);
                                //}

                                string fetch = "";
                                int Count = 0;
                                EntityCollection PAARecords = new EntityCollection();
                                fetch = string.Format(FetchXml.GetPAARecordsCount, parentJobNumber);
                                crmTrace.AppendLine("fetch: " + fetch);
                                if (fetch != null)
                                {
                                    PAARecords = service.RetrieveMultiple(new FetchExpression(fetch));
                                }
                                if (PAARecords.Entities != null)
                                {
                                    crmTrace.AppendLine("PAARecords.Entities: " + PAARecords.Entities.Count);
                                    //crmTrace.AppendLine("Other child filing records were found ");
                                    int filingCount = PAARecords.Entities.Count > 0 ? Convert.ToInt32(((Microsoft.Xrm.Sdk.AliasedValue)PAARecords.Entities[0].Attributes[RelatedFilngs.Counter]).Value) : 0;
                                    Count = filingCount+1;
                                    crmTrace.AppendLine("Count: " + Count.ToString());
                                    int rf_Counter = Count;
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobNumberAttributeName, parentJobNumber);
                                    string JobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                                    #region Old Code Filing Number Generated
                                    //#region Filing Number Generated
                                    //if (filingCount >= 0 && filingCount < 9)
                                    //{
                                    //    filingNumberFormatted = "P" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, JobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 9 && filingCount < 18)
                                    //{
                                    //    // You can change the Intial to anything that is required
                                    //    // For Example if After P9 the next sequence should have "O1 - O9". Just replace "B" with "O" in the following code
                                    //    Count = filingCount - 9;
                                    //    filingNumberFormatted = "B" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 18 && filingCount < 27)
                                    //{
                                    //    Count = filingCount - 18;
                                    //    filingNumberFormatted = "C" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 27 && filingCount < 36)
                                    //{
                                    //    Count = filingCount - 27;
                                    //    filingNumberFormatted = "D" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 36 && filingCount < 45)
                                    //{
                                    //    Count = filingCount - 36;
                                    //    filingNumberFormatted = "E" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 45 && filingCount < 54)
                                    //{
                                    //    Count = filingCount - 45;
                                    //    filingNumberFormatted = "F" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 54 && filingCount < 63)
                                    //{
                                    //    Count = filingCount - 54;
                                    //    filingNumberFormatted = "G" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}

                                    //if (filingCount >= 63 && filingCount < 72)
                                    //{
                                    //    Count = filingCount - 63;
                                    //    filingNumberFormatted = "H" + (Count + 1).ToString();
                                    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                                    //}
                                    //#endregion
                                    #endregion

                                    #region Filing Number Generated
                                    if (Count > 108)
                                    {
                                        throw new Exception("Maximum allowed number of PAA filing reached.");
                                    }
                                    if (Count >= 1 && Count < 10)
                                    {
                                        filingNumberFormatted = "P" + (Count).ToString();
                                     }
                                    else if (Count < 82)
                                    {
                                        Count = Count - 9;
                                        filingNumberFormatted = (((Char)((((Count % 9) == 0) ? (Count / 9) - 1 : (Count / 9)) + 'A')).ToString() + (((Count % 9) == 0) ? 9 : Count % 9).ToString());
                                     }
                                    else if (Count >= 82)
                                    {
                                        filingNumberFormatted = (((Char)((((Count % 9) == 0) ? (Count / 9) - 1 : (Count / 9)) + 'A')).ToString() + (((Count % 9) == 0) ? 9 : Count % 9).ToString());
                                    }
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, JobNumber + "-" + filingNumberFormatted);
                                    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                                    #endregion

                                    #region Create Related Filng PAA Record
                                    if (context.MessageName == MessageName.Update)
                                    {
                                        Entity RelatedFilng = new Entity();
                                        crmTrace.AppendLine("Start Creating Related Filngs Record PAA Type: Start");
                                        RelatedFilng.LogicalName = RelatedFilngs.EntityLogicalName;
                                        RelatedFilng.Attributes.Add(RelatedFilngs.JobNumber, JobNumber);
                                        RelatedFilng.Attributes.Add(RelatedFilngs.Name, JobNumber + "-" + filingNumberFormatted);
                                        RelatedFilng.Attributes.Add(RelatedFilngs.FilingType, new OptionSetValue(filingTypeIntvalue));
                                        RelatedFilng.Attributes[RelatedFilngs.JobFilingId] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                                        RelatedFilng.Attributes.Add(RelatedFilngs.ParentGUID, ParentJobGuid.ToString());
                                        RelatedFilng.Attributes.Add(RelatedFilngs.SchemaName, JobFilingEntityAttributeName.EntityLogicalName);
                                        RelatedFilng.Attributes.Add(RelatedFilngs.Counter, rf_Counter);
                                        crmTrace.AppendLine("test1");
                                        service.Create(RelatedFilng);
                                        crmTrace.AppendLine("Start Creating Related Filngs Record PAA Type: End");
                                    }
                                    #endregion


                                }


                            }
                            #endregion

                            #region Subsequent
                            //#region Subsequent
                            //if (filingTypeIntvalue == (int)FilingTypes.SF)
                            //{
                            //    crmTrace.AppendLine("filingTypeIntvalue : " + filingTypeIntvalue);
                            //    ConditionExpression parentJobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                            //    EntityCollection parentJobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { parentJobfilingCondition }, LogicalOperator.And);
                            //    crmTrace.AppendLine("parentJobfiling count: " + parentJobfilingResponse.Entities.Count);


                            //    string parentJobNumber = parentJobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                            //    crmTrace.AppendLine("parentJobNumber: " + parentJobNumber);


                            //    // Check all the filings with same Job Number and filingType
                            //    ConditionExpression JobfilingCondition1 = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { parentJobNumber });
                            //    ConditionExpression JobfilingCondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingTypeAttributeName, ConditionOperator.Equal, new string[] { filingTypeIntvalue.ToString() });
                            //    ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });

                            //    EntityCollection JobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { JobfilingCondition1, JobfilingCondition2, condition }, LogicalOperator.And);
                            //    crmTrace.AppendLine("JobfilingResponse count: " + JobfilingResponse.Entities.Count);

                            //    //if (JobfilingResponse == null && JobfilingResponse.Entities == null && JobfilingResponse.Entities.Count == 0)
                            //    //{
                            //    //    crmTrace.AppendLine("No other child filing records found ");
                            //    //    int Count = JobfilingResponse.Entities.Count + 1;
                            //    //    filingNumberFormatted = "A" + Count.ToString();
                            //    //    crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //    //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, filingNumberFormatted);
                            //    //}

                            //    if (JobfilingResponse.Entities.Count >= 0)
                            //    {
                            //        //crmTrace.AppendLine("Other child filing records were found ");
                            //        int filingCount = JobfilingResponse.Entities.Count;
                            //        int Count = filingCount;
                            //        crmTrace.AppendLine("Count: " + Count.ToString());
                            //        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobNumberAttributeName, parentJobNumber);

                            //        #region Filing Number Generated
                            //        if (filingCount >= 0 && filingCount < 9)
                            //        {
                            //            filingNumberFormatted = "S" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 9 && filingCount < 18)
                            //        {
                            //            // You can change the Intial to anything that is required
                            //            // For Example if After S9 the next sequence should have "O1 - O9". Just replace "B" with "O" in the following code
                            //            Count = filingCount - 9;
                            //            filingNumberFormatted = "B" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 18 && filingCount < 27)
                            //        {
                            //            Count = filingCount - 18;
                            //            filingNumberFormatted = "C" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 27 && filingCount < 36)
                            //        {
                            //            Count = filingCount - 27;
                            //            filingNumberFormatted = "D" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 36 && filingCount < 45)
                            //        {
                            //            Count = filingCount - 36;
                            //            filingNumberFormatted = "E" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 45 && filingCount < 54)
                            //        {
                            //            Count = filingCount - 45;
                            //            filingNumberFormatted = "F" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 54 && filingCount < 63)
                            //        {
                            //            Count = filingCount - 54;
                            //            filingNumberFormatted = "G" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }

                            //        if (filingCount >= 63 && filingCount < 72)
                            //        {
                            //            Count = filingCount - 63;
                            //            filingNumberFormatted = "H" + (Count + 1).ToString();
                            //            crmTrace.AppendLine("filingNumberFormatted: " + filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingNumberAttributeName, filingNumberFormatted);
                            //            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.EntityAttributeName, parentJobNumber + "-" + filingNumberFormatted);
                            //        }
                            //        #endregion

                            //    }
                            //}

                            //#endregion
                            #endregion

                        } ///// If parent Job is there - Ends here

                        #region Update Counters
                        //Entity autoNumber = new Entity();
                        //crmTrace.AppendLine("Start Updating Counter: " + filingNumberFormatted);
                        //autoNumber.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                        //autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.FilingNumberCounterAttribute, (filingAutoNumber + 1));

                        //if (jobNumberRequired)
                        //    autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.JobNumberCounterAttribute, (jobAutoNumber + 1));

                        //autoNumber.Id = response.Entities[0].Id;
                        //UpdateEntity(service, autoNumber);
                        //crmTrace.AppendLine("End Updating Counter: " + filingNumberFormatted);
                        #endregion
                        #region Create Counter
                        if (jobNumberRequired)
                        {
                            Entity autoNumber = new Entity();
                            crmTrace.AppendLine("Start Creating Counter: " + filingNumberFormatted);
                            autoNumber.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                            autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.EntityNameAttribute, "Counter Record");
                            autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.FilingNumberCounterAttribute, (jobAutoNumber + 1));
                            autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.JobNumberPaddingAttribute, jobNumberPadding.ToString());
                            autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.PaddingCharacterAttribute, paddingChar.ToString());

                            autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.JobNumberCounterAttribute, (jobAutoNumber + 1));

                            service.Create(autoNumber);
                            crmTrace.AppendLine("End Creating Counter: " + filingNumberFormatted);
                        }
                        #endregion


                        sqlCommand.Connection.Close();
                        sqlConn.Close();

                    }
                }
                //throw new Exception("Job Number Test");
                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobNumberGenerator - GeneratejobFilingNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }
        public static Entity GenerateAutoNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            #region Declare Variable
            string TrackingNumberFormatted = string.Empty;
            decimal facadesAutoNumber = 0;
            int facadesPaddingNumber = 0;
            char facadesPaddingChar = 'X';
            string trackingNumber = "{0}{1}";
            #endregion

            try
            {
                crmTrace.AppendLine("Begin: Retrieve Auto Number Entity");
                crmTrace.AppendLine(targetEntity.LogicalName);

                EntityCollection response = GetAutoNumberEntityInfo(service, targetEntity, crmTrace);
                crmTrace.AppendLine(response.Entities.Count.ToString() + " number of auto number record!");
                crmTrace.AppendLine("End: Retrieve Auto Number Entity");
                if (response != null && response.Entities != null && response.Entities.Count > 0)
                {
                    crmTrace.AppendLine("RecievedResponse: Retrieve Auto Number Entity");
                    if (response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesCounter) && response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesPaddingNumber) && response.Entities[0].Contains(AutoNumberEntityAttribute.FacadesPaddingCharacter))
                    {
                        facadesAutoNumber = decimal.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesCounter].ToString());
                        crmTrace.AppendLine("facadesAutoNumber" + facadesAutoNumber);
                        facadesPaddingNumber = int.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesPaddingNumber].ToString());
                        crmTrace.AppendLine("facadesPaddingNumber" + facadesPaddingNumber);
                        facadesPaddingChar = char.Parse(response.Entities[0].Attributes[AutoNumberEntityAttribute.FacadesPaddingCharacter].ToString());
                        crmTrace.AppendLine("facadesPaddingChar" + facadesPaddingChar);
                    }
                    #region Update Counters
                    UpdateCounter(service, facadesAutoNumber, response);
                    #endregion

                    #region OP49
                    if (targetEntity.LogicalName == OP49EntityAttributeNames.EntityLogicalName)
                    {
                        string Borough = "";
                        trackingNumber = "{0}-{1}-{2}";

                        if (targetEntity.Attributes.Contains(OP49EntityAttributeNames.Borough))
                            Borough = Enum.GetName(typeof(Borough), ((OptionSetValue)targetEntity.Attributes[OP49EntityAttributeNames.Borough]).Value);
          
                        TrackingNumberFormatted = String.Format(trackingNumber, Borough, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar),"OP49");
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.Name, TrackingNumberFormatted);
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    #region BoilerBuildDeviceDetails
                    if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName && !(targetEntity.Contains(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) && targetEntity[BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute] != null))//name is not present then generate the tracking number
                    {
                        //Number should generate when there is no name filled from Integartion
                        Entity jobFiling=new Entity();
                        trackingNumber = "{0}";
                        TrackingNumberFormatted = String.Format(trackingNumber, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);

                        crmTrace.AppendLine("Get Job Filing Details start" );

                        if(targetEntity.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling) && targetEntity[BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling]!=null)
                        {
                             jobFiling = Retrieve(service, new string[] { JobFilingEntityAttributeName.BEScopeIncludesBL,JobFilingEntityAttributeName.FilingType }, targetEntity.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling).Id, JobFilingEntityAttributeName.EntityLogicalName);
                        }

                        //if(jobFiling != null && jobFiling.Id!=null && jobFiling.Contains(JobFilingEntityAttributeName.BEScopeIncludesBL)&& jobFiling[JobFilingEntityAttributeName.BEScopeIncludesBL] !=null && jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value==3) //for Fuel Storage
                        //{
                        //    TrackingNumberFormatted = "FS-" + TrackingNumberFormatted;
                        //}
                        if (jobFiling != null && jobFiling.Id != null && jobFiling.Contains(JobFilingEntityAttributeName.FilingType) && jobFiling[JobFilingEntityAttributeName.FilingType] != null && jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA) //for Fuel Storage
                        {
                            if (targetEntity.Contains(BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber) && targetEntity[BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber] == null)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber, TrackingNumberFormatted);
                            }
                            CommonPluginLibrary.SetAttributeValue(targetEntity, BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute, TrackingNumberFormatted);
                            crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                        }
                    }
                    #endregion

                    #region Manage Boiler Request
                    if (targetEntity.LogicalName == ManageBoilerRequest.EntityLogicalName )//name is not present then generate the tracking number
                    {
                        //Number should generate when there is no name filled from Integartion
                        Entity jobFiling = new Entity();
                        trackingNumber = "{0}";
                        TrackingNumberFormatted = String.Format(trackingNumber, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);

                        crmTrace.AppendLine("Get Job Filing Details start");
  
                        TrackingNumberFormatted = "MBR-" + TrackingNumberFormatted;
                        
                        CommonPluginLibrary.SetAttributeValue(targetEntity, ManageBoilerRequest.EntityNameAttribute, TrackingNumberFormatted);
                       
                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }
                    #endregion

                    #region Fuel Burner Master

                    if (targetEntity.LogicalName == FulelBurnerMaster.EntityLogicalName)
                    {
                        //Number should generate when there is no name filled from Integartion
                        Entity Boiler = new Entity();
                        if (targetEntity.Contains(FulelBurnerMaster.BoilerMasterLookup) && targetEntity[FulelBurnerMaster.BoilerMasterLookup] != null)
                        {
                            Boiler = Retrieve(service, new string[] { BoilerMasterDevice.EntityNameAttribute }, targetEntity.GetAttributeValue<EntityReference>(FulelBurnerMaster.BoilerMasterLookup).Id, BoilerMasterDevice.EntityLogicalName);
                        }
                        string BoilerID = Boiler != null && Boiler.Contains(BoilerMasterDevice.EntityNameAttribute) && Boiler[BoilerMasterDevice.EntityNameAttribute] != null ? Boiler.GetAttributeValue<string>(BoilerMasterDevice.EntityNameAttribute) : "Not Connected to Boiler";
                        trackingNumber = "{0}-{1}-{2}";//FB-BoilerID-trackingnumber
                        TrackingNumberFormatted = String.Format(trackingNumber,"FB" ,BoilerID,Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                        crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);

                        crmTrace.AppendLine("Get Job Filing Details start");

                     

                        CommonPluginLibrary.SetAttributeValue(targetEntity, FulelBurnerMaster.EntityNameAttribute, TrackingNumberFormatted);

                        crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                    }


                    #endregion

                    #region Fuel Storage Master
                    if (targetEntity.LogicalName == FulelStorageMaster.EntityLogicalName)
                    {
                        //Number should generate when there is no name filled from Integartion
                        Entity Boiler = new Entity();
                        if(targetEntity.Contains(FulelStorageMaster.BoilerMasterLookup) && targetEntity[FulelStorageMaster.BoilerMasterLookup] != null)
                        {
                            Boiler = Retrieve(service, new string[] { BoilerMasterDevice.EntityNameAttribute }, targetEntity.GetAttributeValue<EntityReference>(FulelStorageMaster.BoilerMasterLookup).Id, BoilerMasterDevice.EntityLogicalName);
                        }
                        string BoilerID = Boiler != null && Boiler.Contains(BoilerMasterDevice.EntityNameAttribute) && Boiler[BoilerMasterDevice.EntityNameAttribute]!=null ?  Boiler.GetAttributeValue<string>(BoilerMasterDevice.EntityNameAttribute) : "Not Connected to Boiler";
                        

                        if (BoilerID == "Not Connected to Boiler") {
                            trackingNumber = "{0}-{1}";//Fs-trackingnumber
                            TrackingNumberFormatted = String.Format(trackingNumber, "FS", Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                            crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                            crmTrace.AppendLine("Get Job Filing Details start");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, FulelStorageMaster.EntityNameAttribute, TrackingNumberFormatted);
                            crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);

                        }
                        else
                        {
               
                            trackingNumber = "{0}-{1}-{2}";//Fs-BoilerID-trackingnumber
                            TrackingNumberFormatted = String.Format(trackingNumber, "FS", BoilerID, Math.Round(facadesAutoNumber, 0).ToString().PadLeft(facadesPaddingNumber, facadesPaddingChar));
                            crmTrace.AppendLine("TrackingNumberFormatted" + TrackingNumberFormatted);
                            crmTrace.AppendLine("Get Job Filing Details start");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, FulelStorageMaster.EntityNameAttribute, TrackingNumberFormatted);
                            crmTrace.AppendLine("TrackingNumberSet" + TrackingNumberFormatted);
                        }
                    }

                    #endregion

                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
              //  throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GenerateAutoNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
               // throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            return targetEntity;
        }

        public static EntityCollection GetAutoNumberEntityInfo(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression autoNumberCondition = CreateConditionExpression(AutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { targetEntity.LogicalName });
                crmTrace.AppendLine(autoNumberCondition.AttributeName + " " + autoNumberCondition.ToString() + " " + autoNumberCondition.Operator);
                crmTrace.AppendLine(AutoNumberEntityAttribute.EntityLogicalName);
                EntityCollection response = RetrieveMultiple(service, AutoNumberEntityAttribute.EntityLogicalName, new string[] { AutoNumberEntityAttribute.FacadesCounter, AutoNumberEntityAttribute.FacadesPaddingNumber, AutoNumberEntityAttribute.FacadesPaddingCharacter }, new ConditionExpression[] { autoNumberCondition }, LogicalOperator.And);
                crmTrace.AppendLine(response.Entities.Count.ToString());
                return response;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }

        }

        public static void UpdateCounter(IOrganizationService service, decimal facadesAutoNumber, EntityCollection response)
        {
            try
            {
                Entity autoNumber = new Entity();
                autoNumber.LogicalName = AutoNumberEntityAttribute.EntityLogicalName;
                autoNumber.Attributes.Add(AutoNumberEntityAttribute.FacadesCounter, (facadesAutoNumber + 1));
                autoNumber.Id = response.Entities[0].Id;
                UpdateEntity(service, autoNumber);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw new Exception(ex.ToString());
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex.ToString());
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", null, "", null, null);
                DOBLogger.WriteExceptionLog("", "CRM", "JobNumberGenerator - GetAutoNumberEntityInfo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex.ToString());
            }
        }

    } //class ends
} // namespace ends
