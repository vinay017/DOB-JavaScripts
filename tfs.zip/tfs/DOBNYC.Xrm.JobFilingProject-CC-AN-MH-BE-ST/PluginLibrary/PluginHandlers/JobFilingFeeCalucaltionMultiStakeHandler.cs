﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginHandlers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class JobFilingFeeCalucaltionMultiStakeHandler : PluginHandlerBase
    {
        /* JobFilingFeeCalucaltionMultiStakeHandler Flow:
* []CalculateFeeMultiStake- Set all the retrieved Fee Calculation values to respective attributes
* []PostFeeCalculationUpdates- Check Amount Due and Amount Paid and creaet PH and TH
* []IsFeeNeedToCalculate- Check if any of the attribute values is changed from Preimage 
* []IsFilingSubmitted- Chaeck if job is submitted and create Refund TH
* []IsWorkTypeEligible- Check if worktype is elegible or not-GCMHSTPLSPSD
* []MergeAttributes- Merge Preimage values to target
* []GetTransCodesList- Setting or adding Transaction codes based on filing type to list of TransCodes
* []CreateTransPaymentHistory- Create/Update PH and TH based on PH isposted or IsNoGoodCheck flags.
*/

        public static void CalculateFeeMultiStake(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, ParameterCollection SharedVariables)
        {
            try
            {
                #region Variable Declarations
                decimal NewWorkFilingFee = 0;
                decimal PAAFilingFee = 0;
                decimal Totalfee = 0;
                decimal legalizationFee = 0;
                decimal TPALateFees = 0;
                decimal RecordManagementFee = 0;
                #endregion

                #region Calculate NB fee--Filng Fee,Legalization Fee,SubSequent Fee,PAA Fee,NoGood Check Fee,Conjution Fee
                IFeeCalculationObject fcObject = new GCMHSTFeeCalObject();
                crmTrace.AppendLine("Calculate NB Fee - Start");
                //Helper calss returns Minimum Filng Fee 
                fcObject = FeeCalNewBuildingAltHelper.CalculateMultiStakeFilingFee(service, targetEntity, crmTrace);
                crmTrace.AppendLine("Calculate NB Fee - End");
                #endregion

                #region Set AmoutDue,FilingFee,TotalFee,LegalizationFee,PAAFee,ConjuctionFee,RMFee,NoGoodCheckFee

                #region Set Retrieved Object Values
                NewWorkFilingFee = fcObject.FilingFee;
                crmTrace.AppendLine("FilingFee" + fcObject.FilingFee + "Totalfee" + fcObject.TotalFees);
                legalizationFee = fcObject.LegalizationFilingFees;
                TPALateFees = fcObject.TPALateFees;
                Totalfee = Convert.ToDecimal(fcObject.TotalFees);
                RecordManagementFee = fcObject.RecordManagementFees;
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(NewWorkFilingFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(RecordManagementFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(Totalfee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(fcObject.InConjunctionFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NoGoodCheckFee, new Money(fcObject.NoGoodCheckFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LegalizationFilingFee, new Money(legalizationFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TPALateFees, new Money(TPALateFees));
                SharedVariables.Add(SharedVariableNames.IsFeeExempt, fcObject.IsFeeExempt);
                #endregion

                #region Set for PAA
                if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingTypes.PA)
                {
                    PAAFilingFee = fcObject.PAAFees;
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(PAAFilingFee));
                }
                #endregion

                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CalculateFeeNewBuildings", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void PostFeeCalculationUpdates(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, ParameterCollection SharedVariables)
        {
            try
            {
                #region Variables
                decimal existingamountPaid = 0;
                decimal AmountDue = 0;
                decimal FilingFee = 0;
                decimal adjustment = 0;
                decimal NoGoodCheckFee = 0;
                bool IsFeeExempt = false;
                decimal TotalFee = 0;
                decimal PAAFee = 0;
                int buildVal = 0;
                List<Guid> transHistoryGuids = new List<Guid>();
                EntityCollection OldPhhistory = new EntityCollection();
                #endregion

                FilingFee = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value);
                TotalFee = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value);
                if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                    NoGoodCheckFee = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value);
                if (targetEntity.Contains(JobFilingEntityAttributeName.PAAFee))
                    PAAFee = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value);

                #region AmountPaid
                crmTrace.AppendLine("GCMH AmountPaid -Exists");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                    existingamountPaid = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) ? ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value : ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                #endregion

                #region AmountDue
                AmountDue = TotalFee - existingamountPaid;
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(AmountDue));
                #endregion

                #region Builing Type Value
                crmTrace.AppendLine("GCMH Builing Type Value");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                    buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingTypeAttribute]).Value;
                #endregion

                #region NoGoodCheck
                if (NoGoodCheckFee == 0)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                #endregion

                #region Bool type for IsFeeExempt
                if (SharedVariables.Contains(SharedVariableNames.IsFeeExempt) && (bool)SharedVariables[SharedVariableNames.IsFeeExempt] == true)
                {
                    IsFeeExempt = (bool)SharedVariables[SharedVariableNames.IsFeeExempt];
                }
                #endregion
                //feeExempt Came here to check if there are any Adjustments.
                if (TotalFee < existingamountPaid || IsFeeExempt)
                {
                    #region  Is Fee Exempt
                    if (IsFeeExempt)
                    {
                        //Delete Old PH-Clear PH GUID field on Jobfiling
                        OldPhhistory = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetOldPaymentHistory, targetEntity.Id)));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                        crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                        foreach (Entity phhistory in OldPhhistory.Entities)
                        {
                            crmTrace.AppendLine("Delete old payment history records -start");
                            service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phhistory.Id);
                            crmTrace.AppendLine("Delete old payment history records - end");
                        }
                        //Remove nogoodcheckfee from AmountPaid
                        if (NoGoodCheckFee > 0)
                        {
                            //CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(AmountPaid-NoGoodCheckFee));
                        }
                    }
                    #endregion

                    #region Temporary Adjustment Calculation
                    adjustment = (existingamountPaid - TotalFee);
                    crmTrace.AppendLine("Build GCMH-PW1 Entity for Update - Populate Adjustment Amount");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(adjustment));
                    #endregion
                }
                else
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(0));

                    #region Create Transaction,Payment History and PAA Amount Due Logic
                    crmTrace.AppendLine("Build GCMH for Update - Populate Amount Due");
                    if (AmountDue > 0)
                    {
                        #region Amount Due for PAA Record
                        ///<summary>
                        ///PAA--->
                        ///Calculation Flow: 
                        ///Put PAA logic here.
                        ///Check if atleast one payment is done
                        ///If done,take Amount Due.Else,check if less than 100(PAA Fee) make Amount Due=100,Temporary Adjustment=PAAFee-Amount Due
                        /// </summary>
                        /// 
                        if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                        {
                            EntityCollection response = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetIsPostedCount, targetEntity.Id.ToString())));
                            if (AmountDue <= PAAFee && response.Entities.Count == 0)
                            {
                                AmountDue = PAAFee;
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(AmountDue));
                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(PAAFee - AmountDue));
                            }
                        }
                        #endregion

                        CreateTransPaymentHistory(service, crmTrace, targetEntity, preImage, SharedVariables, AmountDue);
                    }
                    #endregion
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - PostCreateFeeUpdates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static bool IsFeeNeedToCalculate(IOrganizationService service, IPluginExecutionContext context ,Entity preImage, Entity targetEntity, StringBuilder crmTrace, ParameterCollection SharedVariables)
        {
            try
            {
                crmTrace.AppendLine("Start : IsFeeNeedToCalculate");

                #region JobSubmitted-Calc should be only when NGC
                if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted))
                {
                    crmTrace.AppendLine("IsJobSubmitted");
                    if ((preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true))
                    {
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) == false)
                        {
                            return false;
                        }
                    }
                }
                #endregion

                #region IsFeeExemptAttributename
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && preImage.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                {
                    crmTrace.AppendLine("IsFeeExemptAttributename");
                    if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) &&
                        targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename))
                    {
                        return true;
                    }
                }
                #endregion

                #region PA/TPA-Changes
                if (((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox)) ||
                   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))) &&
                   !targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value != (int)FilingType.PAA))
                {
                    crmTrace.AppendLine("Context.Depth :" + context.Depth);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus)&& targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value== (int)CurrentFilingStatus.PreFiling && context.Depth==1)
                    {
                        crmTrace.AppendLine("IsFeeNeedToCalculate-PA/TPA");
                        return true;
                    }
                }
                #endregion

                #region InConjunctionJob
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && preImage.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                {
                    crmTrace.AppendLine("IsConjunctionJob");
                    if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob))
                    {
                        return true;
                    }
                }
                #endregion

                #region IsPAA
                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == false) &&
                   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA) &&
                   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PAAFee) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value == 0))
                {
                   
                    return true;
                }
                #endregion

                #region Job Alteration Type Change-NB to Alt/Alt to NB
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobNBorAltType) && preImage.Attributes.Contains(JobFilingEntityAttributeName.JobNBorAltType))
                {
                    crmTrace.AppendLine("JobNBorAltType");
                    if (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value != preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value)
                    {
                        return true;
                    }
                }
                #endregion

                #region NoGoodCheckFlag
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && preImage.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                {
                    crmTrace.AppendLine("NoGoodCheckFlag");
                    if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) == false && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) == true)
                    {
                        //Merge attributes from PreImage so that targetentity will have all the values.-Package will update just 3 fields(NoGoodCheckFlag,AmountDue,AmountPaid,FailedPaymentHistory)
                        MergeAttributes(preImage, targetEntity, crmTrace);
                        return true;
                    }
                }
                #endregion

                #region Mechanical Related
                #region Legalization
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value > 0)
                //{

                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsLegalization) && preImage.Attributes.Contains(JobFilingEntityAttributeName.IsLegalization))
                //    {
                //        crmTrace.AppendLine("IsLegalization");
                //        if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization))
                //        {
                //            return true;
                //        }
                //        crmTrace.AppendLine("IsLegalization:True");
                //        if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization) &&
                //            targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsLegalization))
                //        {
                //            crmTrace.AppendLine("Estimated JobCost Legalization");
                //            if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName))
                //            {
                //                return true;
                //            }
                //            crmTrace.AppendLine("Total Construction Area Legalization");
                //            if (preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName))
                //            {
                //                return true;
                //            }
                //        }
                //    }
                //}
                #endregion

                #region Building Type Based Total Construction,Proposed Building Stories
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value != 4)
                //{
                //    #region EstimatedJobCost-Not Applicable for New Building
                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) &&
                //        targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value != (int)JobTypeNBorAlt.NewBuilings)
                //    {
                //        crmTrace.AppendLine("EstimatedJobCost  Building Type 123");
                //        if ((preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value) != targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value)
                //        {
                //            return true;
                //        }
                //    }
                //    #endregion

                //    #region TotalConstructionFloorArea
                //    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea))
                //    {
                //        crmTrace.AppendLine("TotalConstructionFloorArea1");
                //        if (Convert.ToDecimal(preImage.Attributes[JobFilingEntityAttributeName.TotalConstructionFloorArea].ToString()) != Convert.ToDecimal(targetEntity.Attributes[JobFilingEntityAttributeName.TotalConstructionFloorArea]))
                //        {
                //            return true;
                //        }
                //    }
                //    #endregion
                //}
                //else
                //{
                //    #region Check if ProposeeBuildingStories or TotalConstructionFloorArea are not Null
                //    if (((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories] != null) ||
                //       (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity.Attributes[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null)))
                //    {
                //        #region ProposeeBuildingStories
                //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories] != null)
                //        {
                //            crmTrace.AppendLine("ProposeeBuildingStories");
                //            if (preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories] != null && Convert.ToDecimal(targetEntity.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories]) >= 0)
                //            {
                //                if (Convert.ToDecimal(preImage.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories]) != Convert.ToDecimal(targetEntity.Attributes[JobFilingEntityAttributeName.ProposeeBuildingStories]))
                //                {
                //                    #region Check BuildingType
                //                    int buildVal = 0;
                //                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                //                        buildVal = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value;
                //                    if (buildVal == 1 || buildVal == 2 || buildVal == 3)
                //                    {
                //                        return false;
                //                    }
                //                    else
                //                    {
                //                        return true;
                //                    }
                //                    #endregion
                //                }
                //            }
                //            else
                //            {
                //                crmTrace.AppendLine("ProposeeBuildingStories13");

                //                return true;
                //            }
                //        }
                //        #endregion

                //        #region TotalConstructionFloorArea
                //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea))
                //        {
                //            crmTrace.AppendLine("TotalConstructionFloorArea");
                //            if (Convert.ToDecimal(preImage.Attributes[JobFilingEntityAttributeName.TotalConstructionFloorArea].ToString()) != Convert.ToDecimal(targetEntity.Attributes[JobFilingEntityAttributeName.TotalConstructionFloorArea]))
                //            {
                //                return true;
                //            }
                //        }
                //        #endregion

                //        #region EstimatedJobCost-Not Applicable for New Building
                //        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) &&
                //            targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value != (int)JobTypeNBorAlt.NewBuilings)
                //        {
                //            crmTrace.AppendLine("EstimatedJobCost Building Type Other" + targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value);
                //            if ((preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value) != targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost).Value)
                //            {
                //                return true;
                //            }
                //        }
                //        #endregion
                //    }
                //    #endregion
                //}
                #endregion

                #region BuildingTypeFilingFees-OnCreate
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value >= 1 &&
                //    (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && !targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename)) &&
                //   (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingFees) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.FilingFees).Value == 0))
                //{
                //    return true;
                //}
                #endregion

                #region BuildingType
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && preImage.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                //{
                //    crmTrace.AppendLine("BuildingType");
                //    if (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value != preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value)
                //    {
                //        return true;
                //    }
                //}
                #endregion
                #endregion

                crmTrace.AppendLine("End : IsFeeNeedToCalculate");
                return false;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFeeNeedToCalculate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void IsFilingSubmitted(IOrganizationService service, Entity preImage, Entity targetEntity, StringBuilder crmTrace, ParameterCollection SharedVariables)
        {
            try
            {
                #region Variables
                decimal Finaladjustment = 0;
                decimal TotalFee = 0;
                #endregion

                TotalFee = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value);
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Refund) && targetEntity.Attributes[JobFilingEntityAttributeName.Refund] != null)
                    Finaladjustment = (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value);
                crmTrace.AppendLine("Start: Finaladjustment");
                #region IsFiled-Refund Amount and Create Final Adjustments/Refund Payment History              
                if (Finaladjustment > 0)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(Finaladjustment));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(0));
                    SharedVariables.Add(SharedVariableNames.IsPaymentPosted, true);
                    CreateTransPaymentHistory(service, crmTrace, targetEntity, preImage, SharedVariables, Finaladjustment);//Refund Payment History and Transaction History
                }
                else
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(0));
                }

                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsFilingSubmitted", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static bool IsWorkTypeEligible(Entity preImage, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start: IsWorkTypeEligible");

                #region GCMHSTPLSPSD-Mechanical Related
                // //GCMHST
                // if (((targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType) == true) ||
                //    (preImage.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType) == true)) ||
                //    ((targetEntity.Contains(JobFilingEntityAttributeName.MechanicalWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType) == true) ||
                //  (preImage.Contains(JobFilingEntityAttributeName.MechanicalWorkType) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType) == true)))
                // {
                //     return true;
                // }
                // //PLSPSDPLSPLegalization-Should return true if not Minor Work Type.
                // else if ((((targetEntity.Contains(JobFilingEntityAttributeName.PlumbingCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox) == true) ||
                //  (preImage.Contains(JobFilingEntityAttributeName.PlumbingCheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox) == true)) ||
                //  ((targetEntity.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization) == true) ||
                //(preImage.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization) == true)) ||
                //((targetEntity.Contains(JobFilingEntityAttributeName.SprinklerCheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox) == true) ||
                // (preImage.Contains(JobFilingEntityAttributeName.SprinklerCheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox) == true)) ||
                // ((targetEntity.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization) == true) ||
                //(preImage.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization) == true)) ||
                //((targetEntity.Contains(JobFilingEntityAttributeName.StandPipeWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType) == true) ||
                //    (preImage.Contains(JobFilingEntityAttributeName.StandPipeWorkType) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType) == true))) &&
                //    (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value != (int)JobTypeNBorAlt.MinorAlteration))
                // {
                //     return true;
                // }
                // else if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true) ||
                //    (preImage.Contains(JobFilingEntityAttributeName.PACheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)) ||
                //    ((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true) ||
                //    (preImage.Contains(JobFilingEntityAttributeName.TPACheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true)))
                // {
                //     MergeAttributes(preImage, targetEntity, crmTrace);
                //     return true;
                // }
                // else
                // {
                //     return false;
                // }
                #endregion

                #region PA/TPA Related
                if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true) ||
                   (preImage.Contains(JobFilingEntityAttributeName.PACheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)) ||
                   ((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true) ||
                   (preImage.Contains(JobFilingEntityAttributeName.TPACheckBox) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true)))
                {
                    MergeAttributes(preImage, targetEntity, crmTrace);
                    return true;
                }
                else
                {
                    return false;
                }
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - IsWorkTypeEligible", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static void MergeAttributes(Entity preImage, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start: MergeAttributes");
                #region Preimage Data merge
                CommonPluginLibrary.Merge(targetEntity, preImage);
                #endregion
                crmTrace.AppendLine("End: MergeAttributes");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        internal static List<string> GetTransCodesList(IOrganizationService service, Entity preImage, Entity targetEntity, int buildVal, StringBuilder crmTrace, ParameterCollection SharedVariables)
        {
            try
            {

                #region Variables
                List<string> transCodesList = new List<string>();
                crmTrace.AppendLine("Start: GetTransCodesList");
                decimal existingamountPaid = 0;
                decimal AmountDue = 0;
                decimal PAAFee = 0;
                #endregion

                #region Get ExistingamountPaid
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                    existingamountPaid = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) ? ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value : ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                #endregion

                #region Get AmountDue
                AmountDue = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountDue).Value;
                #endregion

                #region Get PAAFee
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PAAFee) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value > 0)
                    PAAFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.PAAFee).Value;
                #endregion

                #region NoGoodCheck Code Filng Code
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag))
                {
                    crmTrace.AppendLine("TEST4");
                    crmTrace.AppendLine("GetTransCodesList: NoGoodCheck TransCode");
                    transCodesList.Add(TransactionCodes.CheckBounceFee);//NoGoodCheck Code Filng Code
                    return transCodesList;
                }
                #endregion

                #region Overage/Refund Filng Code
                if (targetEntity.Contains(JobFilingEntityAttributeName.AdjustmentFinal) && (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value) > 0)
                {
                    if (transCodesList.Count > 1)
                    {
                        for (int i = 0; i <= transCodesList.Count - 1; i++)
                        {
                            transCodesList.Remove(transCodesList[i]);
                        }
                    }
                    transCodesList.Add(TransactionCodes.Adjustment);//Overage/Refund Filng Code
                    return transCodesList;
                }
                #endregion

                #region Legalization Fee Code- Mechanical related
                //if (targetEntity.Contains(JobFilingEntityAttributeName.LegalizationFilingFee) && (targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.LegalizationFilingFee).Value) > 0)
                //{
                //    EntityCollection response = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetIsPostedCount, targetEntity.Id.ToString())));
                //    if (response.Entities.Count == 0)
                //        transCodesList.Add(TransactionCodes.Legalization);//Legalization Fee Code
                //}
                #endregion

                #region Add Transaction Codes  to the TransCodeList based on Filing Type

                #region Initial Filng Code and InConjuction Code
                if ((((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.IF)) ||
                    (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true))))
                {
                    //Initial Filng Code and InConjuction Code
                    #region Mechanical Related
                    //if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == false))
                    //{
                    //    if (existingamountPaid == 0)
                    //    {
                    //        #region RecordManagement Fee Code
                    //        switch (buildVal)
                    //        {
                    //            case 1:
                    //            case 2:
                    //            case 3:
                    //                {
                    //                    transCodesList.Add(TransactionCodes.RecordManagement123);
                    //                    break;
                    //                }
                    //            case 4:
                    //                {
                    //                    transCodesList.Add(TransactionCodes.RecordManagementOther);
                    //                    break;
                    //                }
                    //        }
                    //        #endregion
                    //    }
                    //}
                    #endregion
                    if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))))
                    {
                        transCodesList.Add(TransactionCodes.PATransCode);
                        transCodesList.Add(TransactionCodes.RecordManagementOther);
                    }
                    else if ((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox)))
                    {
                        transCodesList.Add(TransactionCodes.TPATransCode);
                    }
                }
                #endregion

                #region PAA Filng Code
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                {
                    #region IsPosted PAA Count
                    EntityCollection response = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetIsPostedCount, targetEntity.Id.ToString())));
                    if (response.Entities.Count == 0)//IsPosted count for PAA- which means one paymnet is done
                    {
                        transCodesList.Add(TransactionCodes.PAA);//PAA Filng Code
                    }
                    else if (AmountDue > PAAFee)
                    {
                        if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))))
                            transCodesList.Add(TransactionCodes.PATransCode);

                        else if ((targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox)))
                            transCodesList.Add(TransactionCodes.TPATransCode);
                    }
                    #endregion
                }
                #endregion

                #region Subsequent Filng Code and InConjuction Code- Mechanical Related
                //else if (((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF)) ||
                //     (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == true)))
                //{
                //    transCodesList.Add(TransactionCodes.GCMH_NB_TransCode);//Subsequent Filng Code and InConjuction Code
                //    if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == false))
                //    {
                //        if (existingamountPaid == 0)
                //        {
                //            #region RecordManagement Fee Code
                //            //Record Management Fee is not applicable for New Building-Subsequent Filing. Is applicable for Alteration-all types
                //            if (targetEntity.Contains(JobFilingEntityAttributeName.JobNBorAltType) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobNBorAltType).Value != (int)JobTypeNBorAlt.NewBuilings)
                //            {
                //                switch (buildVal)
                //                {
                //                    case 1:
                //                    case 2:
                //                    case 3:
                //                        {
                //                            transCodesList.Add(TransactionCodes.RecordManagement123);
                //                            break;
                //                        }
                //                    case 4:
                //                        {
                //                            transCodesList.Add(TransactionCodes.RecordManagementOther);
                //                            break;
                //                        }
                //                }
                //            }
                //            #endregion
                //        }
                //    }

                //    if (((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))))
                //    {
                //        transCodesList.Add(TransactionCodes.RecordManagement123);
                //    }
                //}
                #endregion

                #endregion

                crmTrace.AppendLine("End: GetTransCodesList");
                return transCodesList;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetTransCodesList", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - MergeAttributes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetTransCodesList", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetTransCodesList", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetTransCodesList", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - GetTransCodesList", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void CreateTransPaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, ParameterCollection SharedVariables, decimal AmountDue)
        {
            #region Variables
            int buildVal = 0;
            string PaymentHistoryGUID = "";
            string FailedPaymentHistoryGUID = "";
            Entity EntityJobFilngPost;
            List<string> transCodesList = null;
            Guid PHGUID;
            List<Guid> transHistoryGuids = new List<Guid>();
            EntityJobFilngPost = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
            Entity PH;
            EntityCollection transCodesResponse = new EntityCollection();
            EntityCollection TransHisCollection = new EntityCollection();
            EntityCollection FailedTransHisCollection = new EntityCollection();
            #endregion
            try
            {
                #region NoGoodCheck
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag))
                {
                    /// <summary>
                    /// Retrieve Transaction Histories based on Failed Payment History GUID field on JobFiliing
                    /// Check if Paymnet History GUID field on JobFiling isposted=true or IsNoGoodCheck=true
                    /// If any one is true, create a new one
                    /// Else,Update existing Payment History
                    /// Do not delete Transaction Histories of existing Payment history
                    /// Add retrieved Transaction Histories with existing Transaction Histories if any
                    /// </summary>

                    PaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID);
                    if (PaymentHistoryGUID != null)
                    {
                        PH = service.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(PaymentHistoryAttributeNames.IsPosted, PaymentHistoryAttributeNames.NoGoodCheckFlag));
                        if (PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted) == true || PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.NoGoodCheckFlag) == true)
                        {
                            SharedVariables.Add(SharedVariableNames.PHCreatUpdate, "Create");
                        }
                        else
                        {
                            SharedVariables.Add(SharedVariableNames.PHCreatUpdate, "Update");
                        }
                        PHGUID = FeeCalNewBuildingAltHelper.CreateUpdatePaymentHistoryRecord(service, targetEntity, preImage, SharedVariables, crmTrace, AmountDue);
                        crmTrace.AppendLine("CreateUpdatePaymentHistoryRecord :" + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag));

                        #region Create Transaction History for NoGoodCheck Amount
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                            buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingTypeAttribute]).Value;
                        transCodesList = GetTransCodesList(service, preImage, targetEntity, buildVal, crmTrace, SharedVariables);
                        if (transCodesList.Count > 0)
                            transCodesResponse = FeeCalNewBuildingAltHelper.GetTransactionCode(service, targetEntity, crmTrace, transCodesList);
                        crmTrace.AppendLine("TransCodesResponse Count :" + transCodesResponse.Entities.Count);
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - Start");
                        if (transCodesResponse.Entities.Count > 0)
                            transHistoryGuids = FeeCalNewBuildingAltHelper.CreateTransactionHistory(crmTrace, service, targetEntity, preImage, transCodesResponse, PHGUID); //create transaction hisroty record
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - End");
                        #endregion
                        crmTrace.AppendLine("transHistoryGuids.Count :" + transHistoryGuids.Count);
                        
                        FailedPaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FailedPaymentHistoryGUID) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.FailedPaymentHistoryGUID) : preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.FailedPaymentHistoryGUID);
                        if (FailedPaymentHistoryGUID != null)
                        {
                            FailedTransHisCollection = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetTransactionHistorytoDelete, FailedPaymentHistoryGUID)));
                            if (FailedTransHisCollection.Entities.Count > 0)
                            {
                                for (int i = 0; i <= FailedTransHisCollection.Entities.Count - 1; i++)
                                {
                                    Entity CloneTransactions = new Entity(TransactionHistoryAttributeNames.EntityLogicalName);
                                    FailedTransHisCollection.Entities[i].Attributes.Remove(TransactionHistoryAttributeNames.TransactionHistoryId);
                                    FailedTransHisCollection.Entities[i].Attributes.Remove(TransactionHistoryAttributeNames.PaymentInvoice);
                                    FailedTransHisCollection.Entities[i].Id = Guid.NewGuid();
                                    FailedTransHisCollection.Entities[i].Attributes[TransactionHistoryAttributeNames.PaymentInvoice] = new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PHGUID);
                                    CloneTransactions = FailedTransHisCollection.Entities[i];
                                    transHistoryGuids.Add(service.Create(CloneTransactions));
                                }
                            }
                        }
                        crmTrace.AppendLine("transHistoryGuids.Count :" + transHistoryGuids.Count);
                    }
                    if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) == true) &&
               (preImage.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) == false))
                    {
                        targetEntity.SetAttributeValue(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                    }
                    crmTrace.AppendLine("NoGoodCheckFlag :" + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag));
                }
                #endregion

                #region Not NoGoodCheck
                else
                {
                    /// <summary>
                    /// Get the Payment History GUID from Job Filing entity
                    /// Retrieve Payment History Entity  Data with that PH GUID
                    /// Check if Is Posted or NogGoodCheck are true
                    /// If true, Create a new Payment History
                    /// If False,Delete all existing Transaction Histories related to that PH
                    /// create new set of  TH’s with Transaction Codes.
                    /// Update of PH.
                    /// </summary>
                    #region Payment history-Create/Update
                    PaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID);
                    if (PaymentHistoryGUID != null)
                    {
                        PH = service.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(PaymentHistoryAttributeNames.IsPosted, PaymentHistoryAttributeNames.NoGoodCheckFlag));

                        if (PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted) == true || PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.NoGoodCheckFlag) == true)
                        {
                            SharedVariables.Add(SharedVariableNames.PHCreatUpdate, "Create");
                        }
                        else
                        {
                            SharedVariables.Add(SharedVariableNames.PHCreatUpdate, "Update");

                            #region Delete and recreate Transaction Histories for existing PH
                            string fetch = string.Format(FetchXml.GetTransactionHistorytoDelete, PaymentHistoryGUID);
                            EntityCollection TH_response = service.RetrieveMultiple(new FetchExpression(fetch));
                            if (TH_response.Entities.Count > 0)
                            {
                                for (int i = 0; i <= TH_response.Entities.Count - 1; i++)
                                {
                                    service.Delete(TransactionHistoryAttributeNames.EntityLogicalName, (Guid)TH_response.Entities[i].Attributes[TransactionHistoryAttributeNames.TransactionHistoryId]);
                                }
                            }
                            #endregion

                        }
                        PHGUID = FeeCalNewBuildingAltHelper.CreateUpdatePaymentHistoryRecord(service, targetEntity, preImage, SharedVariables, crmTrace, AmountDue);

                        #region Create Transaction History
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                            buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingTypeAttribute]).Value;
                        transCodesList = GetTransCodesList(service, preImage, targetEntity, buildVal, crmTrace, SharedVariables);
                        if (transCodesList.Count > 0)
                            transCodesResponse = FeeCalNewBuildingAltHelper.GetTransactionCode(service, targetEntity, crmTrace, transCodesList);
                        crmTrace.AppendLine("TransCodesResponse Count :" + transCodesResponse.Entities.Count);
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - Start");
                        if (transCodesResponse.Entities.Count > 0)
                            transHistoryGuids = FeeCalNewBuildingAltHelper.CreateTransactionHistory(crmTrace, service, targetEntity, preImage, transCodesResponse, PHGUID); //create transaction hisroty record
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - End");
                        #endregion
                    }
                    else
                    {
                        SharedVariables.Add(SharedVariableNames.PHCreatUpdate, "Create");
                        PHGUID = FeeCalNewBuildingAltHelper.CreateUpdatePaymentHistoryRecord(service, targetEntity, preImage, SharedVariables, crmTrace, AmountDue);
                        #region Create Transaction History
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                            buildVal = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingTypeAttribute]).Value;
                        transCodesList = GetTransCodesList(service, preImage, targetEntity, buildVal, crmTrace, SharedVariables);
                        if (transCodesList.Count > 0)
                            transCodesResponse = FeeCalNewBuildingAltHelper.GetTransactionCode(service, targetEntity, crmTrace, transCodesList);
                        crmTrace.AppendLine("TransCodesResponse Count :" + transCodesResponse.Entities.Count);
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - Start");
                        if (transCodesResponse.Entities.Count > 0)
                            transHistoryGuids = FeeCalNewBuildingAltHelper.CreateTransactionHistory(crmTrace, service, targetEntity, preImage, transCodesResponse, PHGUID); //create transaction hisroty record
                        crmTrace.AppendLine("Create Transaction History New Building Records1 - End");
                        #endregion
                        crmTrace.AppendLine("Payment History Create and Job filing Update with payment history guid done.");
                    }
                    #endregion

                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateTransPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        internal static bool Compare(List<string> mAttributes, List<string> mAttributesValues, List<string> Operator, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                bool mresult = false;
                for (int i = 0; i <= Operator.Count - 1; i++)
                {
                    if (i == 0)
                    {
                        switch (Operator[i])
                        {
                            case "||":
                                {
                                    if (targetEntity.Attributes.Contains(mAttributes[i]))
                                    {
                                        if (targetEntity.Attributes[mAttributes[i]].GetType().Name == "OptionSetValue")//Optionset values
                                        {
                                            mresult = targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i]).Value.ToString() == mAttributesValues[i] || targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i + 1]).Value.ToString() == mAttributesValues[i + 1];
                                        }
                                        else
                                        {
                                            mresult = ((bool)targetEntity.Attributes[mAttributes[i]] == bool.Parse(mAttributesValues[i]) || (bool)targetEntity.Attributes[mAttributes[i + 1]] == bool.Parse(mAttributesValues[i + 1]));
                                        }
                                    }
                                    break;
                                }
                            case "&&":
                                {
                                    if (targetEntity.Attributes.Contains(mAttributes[i]))
                                    {
                                        if (targetEntity.Attributes[mAttributes[i]].GetType().Name == "OptionSetValue")//Optionset values
                                        {
                                            mresult = targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i]).Value.ToString() == mAttributesValues[i] && targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i + 1]).Value.ToString() == mAttributesValues[i + 1];
                                        }
                                        else
                                        {
                                            mresult = (bool)targetEntity.Attributes[mAttributes[i]] == bool.Parse(mAttributesValues[i]) && (bool)targetEntity.Attributes[mAttributes[i + 1]] == bool.Parse(mAttributesValues[i + 1]);
                                        }
                                    }
                                    break;
                                }
                            case "":
                                {
                                    if (targetEntity.Attributes.Contains(mAttributes[i]))
                                    {
                                        if (targetEntity.Attributes[mAttributes[i]].GetType().Name == "OptionSetValue")//Optionset values
                                        {
                                            mresult = targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i]).Value.ToString() == mAttributesValues[i];
                                        }
                                        else
                                        {
                                            mresult = (bool)targetEntity.Attributes[mAttributes[i]] == bool.Parse(mAttributesValues[i]);
                                        }
                                    }
                                    break;
                                }
                        }
                    }
                    else
                    {
                        switch (Operator[i])
                        {
                            case "||":
                                {
                                    if (targetEntity.Attributes.Contains(mAttributes[i + 1]))
                                    {
                                        if (targetEntity.Attributes[mAttributes[i]].GetType().Name == "OptionSetValue")//Optionset values
                                        {
                                            mresult = mresult || targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i + 1]).ToString() == mAttributesValues[i + 1];
                                        }
                                        else
                                        {
                                            mresult = mresult || (bool)targetEntity.Attributes[mAttributes[i + 1]] == bool.Parse(mAttributesValues[i + 1]);
                                        }
                                    }
                                    break;
                                }
                            case "&&":
                                {
                                    if (targetEntity.Attributes.Contains(mAttributes[i + 1]))
                                    {
                                        if (targetEntity.Attributes[mAttributes[i]].GetType().Name == "OptionSetValue")//Optionset values
                                        {
                                            mresult = mresult && targetEntity.GetAttributeValue<OptionSetValue>(mAttributes[i + 1]).ToString() == mAttributesValues[i + 1];
                                        }
                                        else
                                        {
                                            mresult = mresult && (bool)targetEntity.Attributes[mAttributes[i + 1]] == bool.Parse(mAttributesValues[i + 1]);
                                        }
                                    }
                                    break;
                                }
                        }
                    }
                }
                return mresult;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - Compare", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - Compare", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - Compare", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - Compare", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - Compare", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static bool CompareMatchCriteria(Entity mEntity, IOrganizationService Service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string CreatDeleteAttr)
        {
            try
            {
                string s = mEntity.Attributes[CreatDeleteAttr].ToString();
                bool mCriteria = false;
                bool IsAttChange = false;
                string[] words = s.Split(',');
                string[] mwords = new string[] { };
                List<string> mAttributesValues = new List<string>();
                List<string> Operator = new List<string>();
                List<string> mAttributes = new List<string>();
                for (int j = 0; j <= words.Length - 1; j++)
                {
                    if (words[j].Contains("="))
                    {
                        mwords = words[j].Split('=');
                        if (targetEntity.Attributes.Contains(mwords[0]) && targetEntity.Attributes[mwords[0]] != null && targetEntity.Attributes[mwords[0]].GetType().Name == "Boolean")
                        {
                            if (preImage.GetAttributeValue<bool>(mwords[0]) == targetEntity.GetAttributeValue<bool>(mwords[0]))
                            {
                                IsAttChange = false;
                            }
                            else
                            {
                                IsAttChange = true;
                            }
                        }
                        else if (targetEntity.Attributes.Contains(mwords[0]) && targetEntity.Attributes[mwords[0]] != null && targetEntity.Attributes[mwords[0]].GetType().Name == "OptionSetValue")
                        {
                            crmTrace.AppendLine("dropword" + mwords[0]);
                            if (preImage.Attributes.Contains(mwords[0]) && targetEntity.Attributes.Contains(mwords[0]))
                            {
                                if (preImage.GetAttributeValue<OptionSetValue>(mwords[0]).Value.ToString() == targetEntity.GetAttributeValue<OptionSetValue>(mwords[0]).Value.ToString())
                                {
                                    IsAttChange = false;
                                    crmTrace.AppendLine("IsAttChange" + IsAttChange);
                                }
                                else
                                {
                                    IsAttChange = true;
                                    crmTrace.AppendLine("IsAttChange" + IsAttChange);
                                }
                            }
                            else if (targetEntity.Attributes.Contains(mwords[0]))
                            {
                                IsAttChange = true;
                            }

                        }
                        mAttributes.Add(mwords[0]);
                        mAttributesValues.Add(mwords[1]);
                    }
                    else
                    {
                        Operator.Add(words[j]);
                    }
                }
                if (IsAttChange)
                    mCriteria = Compare(mAttributes, mAttributesValues, Operator, targetEntity, crmTrace);

                return mCriteria;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalucaltionNewBuilingsHandler - CreateMatchCriteria", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

    }
}

