﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class JobFilingChangeTraceHandler : PluginHandlerBase
    {
        public static void ChangeTrace(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("JobFilingChangeSetTrace Started!");
                #region JobFiling Entity PW1Section
                //JobFiling Entity PW1Section
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("JobFiling Entity.");
                    if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                    {
                        int filingType = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                        int filingStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                        if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview)|| //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                            )
                        {
                           // if (filingType != (int)FilingType.PAA) //commented out because we have to create changeset for PAA also 
                            {
                                Dictionary<string, string> preimageValues1 = new Dictionary<string, string>();
                                crmTrace.AppendLine("Get Values from JobFiling PreImage");
                                preimageValues1 = PW1ImageValues1(preImage, crmTrace);
                                crmTrace.AppendLine("Get Values from JobFiling PreImage - End");
                                foreach (var item in preimageValues1)
                                {
                                    //Prepare jobFilingchangeset entity
                                    Entity jobFilingchangeset = new Entity();
                                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;
                                    crmTrace.AppendLine("loop started");
                                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                                    {
                                        string newValue = SetNewValueBasedOnType(service, targetEntity, crmTrace, preImage, item);
                                        string oldValue = item.Value.ToString();
                                        //if (item.Key.ToString() == JobFilingEntityAttributeName.EstimatedJobCost || item.Key.ToString() == JobFilingEntityAttributeName.EstimatedJobCostLegal || item.Key.ToString() == JobFilingEntityAttributeName.LandmarkFee || item.Key.ToString() == JobFilingEntityAttributeName.SizeoftheShed || item.Key.ToString() == JobFilingEntityAttributeName.TotalJobCost)
                                        if (item.Key.ToString() == JobFilingEntityAttributeName.SizeoftheShed)
                                        {
                                            if (newValue.Contains("."))
                                            {
                                                string[] newVal = newValue.ToString().Split('.');
                                                if (newVal[1] == "0000" || newVal[1] == "00" || newVal[1] == "0000000000")
                                                    newValue = newVal[0];

                                            }
                                            string[] est = oldValue.Split('.');
                                            if (est[1] == "0000" || est[1] == "00" || est[1] == "0000000000")
                                                oldValue = est[0];
                                        }

                                        if (!newValue.Trim().Equals(oldValue.Trim()))
                                        {
                                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), service);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                            //Set NewValue to changeSet entity based on Type of Attribute                            
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, "Job Filing");
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName))
                                            {
                                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName));

                                            }
                                            else
                                            {
                                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName));

                                            }

                                            service.Create(jobFilingchangeset);
                                        }
                                    }
                                }

                            }
                        }
                    }
                    //throw new Exception(" crmTrace: " + crmTrace.ToString());

                }

                #endregion
                #region ScopeOfWork Entity
                if (targetEntity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("SOW Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(ScopeOfWorkEntityAttributeName.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {

                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from ScopeofWork PreImage");
                            Dictionary<string, string> scopeImageValues = new Dictionary<string, string>();
                            scopeImageValues = ScopeOfWorkImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from ScopeofWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, scopeImageValues, ScopeOfWorkEntityAttributeName.GoToJobFiling, filingType, "Scope Of Work");
                        }
                    }
                }
                #endregion
                #region WorkCostDetails Entity
                if (targetEntity.LogicalName == WorkCostDetailsAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Work Cost Details Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(WorkCostDetailsAttributeNames.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                              (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                             ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                         )
                    {

                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from WorkCostDetails PreImage");
                            Dictionary<string, string> workImageValues = new Dictionary<string, string>();
                            workImageValues = WorkCostDetailsValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from WorkCostDetails PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, workImageValues, WorkCostDetailsAttributeNames.GoToJobFiling, filingType, "Work Cost Detail");
                        }
                    }

                }
                #endregion
                #region SpecialInspectionCategories Entity
                if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Special Inspection Category Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                        //if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from SpecialInspectionCategories PreImage");
                            Dictionary<string, string> InspectionImageValues = new Dictionary<string, string>();
                            InspectionImageValues = SpecialInspectionCategoriesValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from SpecialInspectionCategories PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, InspectionImageValues, SpecialInspectionCategoriesAttributeNames.GoToJobFiling, filingType, "Special Inspection Categories");
                        }
                    }
                }
                #endregion
                #region ProgressInspectionCategory Entity
                if (targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Progress Inspection Category Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from ProgressInspectionCategory PreImage");
                            Dictionary<string, string> ProgressImageValues = new Dictionary<string, string>();
                            ProgressImageValues = ProgressInspectionCategoryValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from ProgressInspectionCategory PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, ProgressImageValues, ProgressInspectionCategoryAttributeNames.GoToJobFiling, filingType, "Progress Inspection Categories");
                        }
                    }
                }
                #endregion
                #region Zoning Characteristics Entity
                // throw new Exception("Target is this" + "-" + ZoningCharactersticsPW1AttributeNames.EntityLogicalName);
                if (targetEntity.LogicalName == ZoningCharactersticsPW1AttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNamesEntity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(ZoningCharactersticsPW1AttributeNames.JobFilingGuid);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 4.");
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                      //  if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage");
                            Dictionary<string, string> ZoningCharacterImageValues = new Dictionary<string, string>();
                            ZoningCharacterImageValues = ZoningCharacterImageValuesValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, ZoningCharacterImageValues, ZoningCharactersticsPW1AttributeNames.JobFilingGuid, filingType, "Zoning Characeteristics");
                        }
                    }
                }
                #endregion

                #region Boiler Build Device Details
                if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("BoilerBuildDeviceDetailsEntityAttribute.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling);
                    crmTrace.AppendLine("BoilerBuildDeviceDetailsEntityAttribute - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 4.");
                    if (
                              (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                              ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                         )
                    {

                        crmTrace.AppendLine("Get Values from BBD PreImage");
                        Dictionary<string, string> ZoningCharacterImageValues = new Dictionary<string, string>();
                        ZoningCharacterImageValues = BoilerBuildDeviceImageValues(preImage, crmTrace);
                        crmTrace.AppendLine("Get Values from BBD PreImage - End");
                        CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, ZoningCharacterImageValues, BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, filingType, "Boiler Build Device Details");

                    }
                }

                #endregion
                #region Boiler Build Scope pf Work Details
                if (targetEntity.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("BEScopeOfWorkEntityAttribute.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(BEScopeOfWorkEntityAttribute.GotoJobFiling);
                    crmTrace.AppendLine("BEScopeOfWorkEntityAttribute - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 4.");
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                           ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {

                        crmTrace.AppendLine("Get Values from BEScopeOfWorkEntityAttribute PreImage");
                        Dictionary<string, string> ZoningCharacterImageValues = new Dictionary<string, string>();
                        ZoningCharacterImageValues = BoilerBuildScopeofWorkImageValues(preImage, crmTrace);
                        crmTrace.AppendLine("Get Values from BEScopeOfWorkEntityAttribute PreImage - End");
                        CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, ZoningCharacterImageValues, BEScopeOfWorkEntityAttribute.GotoJobFiling, filingType, "Boilers Build Scope of Work");

                    }
                }

                #endregion

                #region TR3
                if (targetEntity.LogicalName == TR3TechnicalReport.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("TR3TechnicalReport Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(TR3TechnicalReport.GotoJobFiling);
                    crmTrace.AppendLine("TR3TechnicalReport - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("TR3TechnicalReport - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("TR3TechnicalReport - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 4.");
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage");
                            Dictionary<string, string> TR3TechinalReportImageValues1 = new Dictionary<string, string>();
                            TR3TechinalReportImageValues1 = TR3TechinalReportImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, TR3TechinalReportImageValues1, TR3TechnicalReport.GotoJobFiling, filingType, "TR3TechnicalReport");
                        }
                    }
                }
                #endregion
                #region TR3Directors
                if (targetEntity.LogicalName == TR3Directors.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("Get TR3Directors GUID.");
                    ColumnSet columns = new ColumnSet(true);
                    Entity currentTR3DirectorGUID = service.Retrieve(TR3Directors.EntityLogicalName, targetEntity.Id, columns);
                    //Guid TR3TechnicalReportGUID = ((EntityReference)currentTR3GUID[TR3Directors.GoToTR3]).Id;
                    crmTrace.AppendLine("currentTR3GUID." + currentTR3DirectorGUID.Id.ToString());
                    //Issue in this line
                    //Entity currentTR3GUID = service.Retrieve(TR3TechnicalReport.EntityLogicalName, ((EntityReference)currentTR3DirectorGUID[TR3Directors.GoToTR3]).Id, columns);
                    //crmTrace.AppendLine("currentTR3GUID." + currentTR3GUID.Id.ToString());

                    EntityReference filingObj = ((EntityReference)currentTR3DirectorGUID[TR3Director.GotoJobFiling]);
                    crmTrace.AppendLine("TR3Directors - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("TR3Directors - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("TR3Directors - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 4.");
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                      //  if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage");
                            Dictionary<string, string> TR3TechinalReportImageValues1 = new Dictionary<string, string>();
                            TR3TechinalReportImageValues1 = TR3TechinalReportImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage - End");
                            CreateJobFilingChangeSetRecordsSubRelateEntities(service, targetEntity, crmTrace, preImage, TR3TechinalReportImageValues1, filingObj, filingType, "TR3Directors");
                        }
                    }
                }
                #endregion
                #region STScopeOfWork
                if (targetEntity.LogicalName == STScopeOfWorkEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(STScopeOfWorkEntityAttribute.GoToJobFiling);
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute - 4.");
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                             ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage");
                            Dictionary<string, string> STSOWImageValues1 = new Dictionary<string, string>();
                            STSOWImageValues1 = STSOWImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, STSOWImageValues1, STScopeOfWorkEntityAttribute.GoToJobFiling, filingType, "STScopeOfWork");
                        }
                    }
                }
                #endregion

                #region MSScopeOfWork
                if (targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("MHScopeofworkAttributeNames Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(MHScopeofworkAttributeNames.GotoJobFiling);
                    crmTrace.AppendLine("MHScopeofworkAttributeNames - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("MHScopeofworkAttributeNames - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("MHScopeofworkAttributeNames - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("MHScopeofworkAttributeNames - 4.");
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from MHScopeofworkAttributeNames PreImage");
                            Dictionary<string, string> STSOWImageValues1 = new Dictionary<string, string>();
                            STSOWImageValues1 = MHSOWImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from STScopeOfWorkEntityAttribute PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, STSOWImageValues1, MHScopeofworkAttributeNames.GotoJobFiling, filingType, "MHScopeOfWork");
                        }
                    }
                }
                #endregion

                #region SOWQuestionnaireImageValues
                if (targetEntity.LogicalName == ScopeofWorkQuestionnaire.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("ScopeofWorkQuestionnaire Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(ScopeofWorkQuestionnaire.GotoJobFiling);
                    crmTrace.AppendLine("ScopeofWorkQuestionnaire - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("ScopeofWorkQuestionnaire - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("ScopeofWorkQuestionnaire - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("ScopeofWorkQuestionnaire - 4.");
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage");
                            Dictionary<string, string> SOWQuestionnaireImageValues1 = new Dictionary<string, string>();
                            SOWQuestionnaireImageValues1 = SOWQuestionnaireImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, SOWQuestionnaireImageValues1, ScopeofWorkQuestionnaire.GotoJobFiling, filingType, "ScopeofWorkQuestionnaire");
                        }
                    }
                }
                #endregion
                #region SOWCommonWorkTypeImageValues
                if (targetEntity.LogicalName == SOWCommonWorkTypesEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("SOWCommonWorkTypeImageValues Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(SOWCommonWorkTypesEntityAttribute.GoToJobFiling);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNames - 4.");
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                     //   if (filingType != (int)FilingType.PAA)
                        {

                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage");
                            Dictionary<string, string> SOWCommonWorkTypeImageValues1 = new Dictionary<string, string>();
                            SOWCommonWorkTypeImageValues1 = SOWCommonWorkTypeImageValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, SOWCommonWorkTypeImageValues1, SOWCommonWorkTypesEntityAttribute.GoToJobFiling, filingType, "SOW Common Work Type");
                        }
                    }
                }
                #endregion

                #region AntennaScopeOfWork Entity
                if (targetEntity.LogicalName == AntennaScopeOfWorkEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("AN SOW Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(AntennaScopeOfWorkEntityAttributeName.GoToJobFiling);
                    crmTrace.AppendLine("AN SOW Entity - 1.");
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    crmTrace.AppendLine("AN SOW Entity - 2.");
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    crmTrace.AppendLine("AN SOW Entity - 3.");
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    crmTrace.AppendLine("AN SOW Entity - 4.");
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                             ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage");
                            Dictionary<string, string> AntennaSOWImageValues = new Dictionary<string, string>();
                            AntennaSOWImageValues = AntennaScopeOfWorkValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from AntennaScopeOfWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, AntennaSOWImageValues, AntennaScopeOfWorkEntityAttributeName.GoToJobFiling, filingType, "Antenna Scope Of Work");
                        }
                    }
                }
                #endregion
                #region AntennaDS1 Entity
                if (targetEntity.LogicalName == AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("AN DS1 Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                           ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                        //if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from AntennaDemolitionSubmittalCertification PreImage");
                            Dictionary<string, string> AntennaDS1ImageValues = new Dictionary<string, string>();
                            AntennaDS1ImageValues = AntennaDemolitionSubmittalValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from AntennaDemolitionSubmittalCertification PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, AntennaDS1ImageValues, AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling, filingType, "Antenna Demolition Submittal Certification DS1");
                        }
                    }
                }
                #endregion
                #region CurbCutQuestionnaire Entity
                if (targetEntity.LogicalName == CurbCutQuestionnaireEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("CC Questionnaire Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(CurbCutQuestionnaireEntityAttributeName.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from CurbCutQuestionnaire PreImage");
                            Dictionary<string, string> CurbCutQuestionnaireImageValues = new Dictionary<string, string>();
                            CurbCutQuestionnaireImageValues = CurbCutQuestionnaireValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from CurbCutQuestionnaire PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, CurbCutQuestionnaireImageValues, CurbCutQuestionnaireEntityAttributeName.GoToJobFiling, filingType, "Curb Cut Questionnaire");
                        }
                    }
                }
                #endregion

                #region Delegates Entity
                if (targetEntity.LogicalName == DelegatesEntityAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Delegates Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(DelegatesEntityAttributeNames.GoToJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                           (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                          ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                      )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from Delegates PreImage");
                            Dictionary<string, string> DelegatesImageValues = new Dictionary<string, string>();
                            DelegatesImageValues = DelegatesValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from Delegates PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, DelegatesImageValues, DelegatesEntityAttributeNames.GoToJobFiling, filingType, "Delegates");
                        }
                    }
                }
                #endregion

                #region FenceScopeOfWork Entity
                if (targetEntity.LogicalName == FenceScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Fence SOW Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(FenceScopeofWorkAttributeNames.GotoJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                             (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                             ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                        )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from FenceScopeofWork PreImage");
                            Dictionary<string, string> FenceSOWImageValues = new Dictionary<string, string>();
                            FenceSOWImageValues = FenceScopeOfWorkValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from FenceScopeofWork PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, FenceSOWImageValues, FenceScopeofWorkAttributeNames.GotoJobFiling, filingType, "Fence Scope of Work");
                        }
                    }
                }
                #endregion

                #region SidewalkShedScopeofwork Entity
                if (targetEntity.LogicalName == SHScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Side Walk SOW Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(SHScopeofWorkAttributeNames.GotoJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                           ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from SHSOWImageValues PreImage");
                            Dictionary<string, string> SHSOWImageValues = new Dictionary<string, string>();
                            SHSOWImageValues = SHScopeOfWorkValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from SHSOWImageValues PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, SHSOWImageValues, SHScopeofWorkAttributeNames.GotoJobFiling, filingType, "Side Walk Shed Scope of Work");
                        }
                    }
                }
                #endregion

                #region ScaffoldScopeofwork Entity
                if (targetEntity.LogicalName == ScaffoldScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Scaffold SOW Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(ScaffoldScopeofWorkAttributeNames.GotoJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1,PAA filings we have to create change set after file
                           ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from SHSOWImageValues PreImage");
                            Dictionary<string, string> SFSOWImageValues = new Dictionary<string, string>();
                            SFSOWImageValues = SFScopeOfWorkValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from SHSOWImageValues PreImage - End");
                            CreateJobFilingChangeSetRecords(service, targetEntity, crmTrace, preImage, SFSOWImageValues, ScaffoldScopeofWorkAttributeNames.GotoJobFiling, filingType, "Scaffold Scope Of Work");
                        }
                    }
                }
                #endregion

                #region Signs Entity

                if (targetEntity.LogicalName == SignCharactersticsAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Sign Entity.");
                    EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(SignCharactersticsAttributeName.GotoJobFiling);
                    Entity filing = RetrieveJobFiling(service, filingObj);
                    int filingType = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName]).Value;
                    int filingStatus = ((OptionSetValue)filing.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                    if (
                            (filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview) || //for I1 & PAA filings we have to create change set after file
                            ((filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview) && filingType == (int)FilingType.PAA) //For PAA changeset shoul create at 2 places 1)After save if they change any details i.e. cahngeset related to I1 2)after file changeset
                       )
                    {
                       // if (filingType != (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Get Values from SignsImageValue PreImage");
                            Dictionary<string, string> SignsImageValue = new Dictionary<string, string>();
                            SignsImageValue = SignCharacteristicsValues(preImage, crmTrace);
                            crmTrace.AppendLine("Get Values from SignsImageValue PreImage - End");
                            CreateJobFilingChangeSetRecordsforSigns(service, targetEntity, crmTrace, preImage, SignsImageValue, SignCharactersticsAttributeName.GotoJobFiling, filingType, "Sign Characteristics");
                        }
                    }
                }
                #endregion


                crmTrace.AppendLine("JobFilingChangeSetTrace Completed!");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ChangeTrace", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        } // ChangeTrace ends here


        public static void UpdateModifiedAfterFileFlag(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            Entity updateEntity = new Entity();
            try
            {
                #region ScopeOfWork Entity
                if (targetEntity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("SOW Entity.");

                    updateEntity = new Entity(ScopeOfWorkEntityAttributeName.EntityLogicalName);
                    updateEntity.SetAttributeValue(ScopeOfWorkEntityAttributeName.ModifiedAfterFile, true);
                   
                }
                #endregion

                #region WorkCostDetails Entity
                if (targetEntity.LogicalName == WorkCostDetailsAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Work Cost Details Entity.");
                    updateEntity = new Entity(WorkCostDetailsAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(WorkCostDetailsAttributeNames.ModifiedAfterFile, true);

                }
                #endregion
                #region SpecialInspectionCategories Entity
                if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Special Inspection Category Entity.");
                    updateEntity = new Entity(SpecialInspectionCategoriesAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(SpecialInspectionCategoriesAttributeNames.ModifiedAfterFile, true);
                }
                #endregion

                #region ProgressInspectionCategory Entity
                if (targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Progress Inspection Category Entity.");
                    updateEntity = new Entity(ProgressInspectionCategoryAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(ProgressInspectionCategoryAttributeNames.ModifiedAfterFile, true);
                }
                #endregion

                #region Zoning Characteristics Entity
                // throw new Exception("Target is this" + "-" + ZoningCharactersticsPW1AttributeNames.EntityLogicalName);
                if (targetEntity.LogicalName == ZoningCharactersticsPW1AttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("ZoningCharactersticsPW1AttributeNamesEntity.");
                    updateEntity = new Entity(ZoningCharactersticsPW1AttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(ZoningCharactersticsPW1AttributeNames.ModifiedAfterFile, true);
                }
                #endregion

                #region Boiler Build Device Details
                if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("BoilerBuildDeviceDetailsEntityAttribute.");
                    updateEntity = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);
                    updateEntity.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.ModifiedAfterFile, true);
                }

                #endregion
                #region Boiler Build Scope pf Work Details
                if (targetEntity.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("BEScopeOfWorkEntityAttribute.");
                    updateEntity = new Entity(BEScopeOfWorkEntityAttribute.EntityLogicalName);
                    updateEntity.SetAttributeValue(BEScopeOfWorkEntityAttribute.ModifiedAfterFile, true);
                }

                #endregion
                #region TR3
                if (targetEntity.LogicalName == TR3TechnicalReport.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("TR3TechnicalReport Entity.");
                    updateEntity = new Entity(TR3TechnicalReport.EntityLogicalName);
                    updateEntity.SetAttributeValue(TR3TechnicalReport.ModifiedAfterFile, true);
                }
                #endregion
                #region TR3Directors
                if (targetEntity.LogicalName == TR3Directors.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("Get TR3Directors GUID.");
                    updateEntity = new Entity(TR3Directors.EntityLogicalName);
                    updateEntity.SetAttributeValue(TR3Directors.ModifiedAfterFile, true);
                }
                #endregion

                #region STScopeOfWork
                if (targetEntity.LogicalName == STScopeOfWorkEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute Entity.");
                    updateEntity = new Entity(STScopeOfWorkEntityAttribute.EntityLogicalName);
                    updateEntity.SetAttributeValue(STScopeOfWorkEntityAttribute.ModifiedAfterFile, true);
                }
                #endregion
                #region MSScopeOfWork
                if (targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("MHScopeofworkAttributeNames Entity.");
                    updateEntity = new Entity(MHScopeofworkAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(MHScopeofworkAttributeNames.ModifiedAfterFile, true);
                }
                #endregion
                #region SOWQuestionnaireImageValues
                if (targetEntity.LogicalName == ScopeofWorkQuestionnaire.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("ScopeofWorkQuestionnaire Entity.");
                    updateEntity = new Entity(ScopeofWorkQuestionnaire.EntityLogicalName);
                    updateEntity.SetAttributeValue(ScopeofWorkQuestionnaire.ModifiedAfterFile, true);
                }
                #endregion
                #region SOWCommonWorkTypeImageValues
                if (targetEntity.LogicalName == SOWCommonWorkTypesEntityAttribute.EntityLogicalName && targetEntity.LogicalName != null)
                {

                    crmTrace.AppendLine("SOWCommonWorkTypeImageValues Entity.");
                    updateEntity = new Entity(SOWCommonWorkTypesEntityAttribute.EntityLogicalName);
                    updateEntity.SetAttributeValue(SOWCommonWorkTypesEntityAttribute.ModifiedAfterFile, true);
                }
                #endregion
                #region AntennaScopeOfWork Entity
                if (targetEntity.LogicalName == AntennaScopeOfWorkEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("AN SOW Entity.");
                    updateEntity = new Entity(AntennaScopeOfWorkEntityAttributeName.EntityLogicalName);
                    updateEntity.SetAttributeValue(AntennaScopeOfWorkEntityAttributeName.ModifiedAfterFile, true);
                }
                #endregion
                #region AntennaDS1 Entity
                if (targetEntity.LogicalName == AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("AN DS1 Entity.");
                    updateEntity = new Entity(AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName);
                    updateEntity.SetAttributeValue(AntennaDemolitionSubmittalCertificationEntityAttributeName.ModifiedAfterFile, true);
                }
                #endregion
                #region CurbCutQuestionnaire Entity
                if (targetEntity.LogicalName == CurbCutQuestionnaireEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("CC Questionnaire Entity.");
                    updateEntity = new Entity(CurbCutQuestionnaireEntityAttributeName.EntityLogicalName);
                    updateEntity.SetAttributeValue(CurbCutQuestionnaireEntityAttributeName.ModifiedAfterFile, true);
                }
                #endregion
                #region Delegates Entity
                if (targetEntity.LogicalName == DelegatesEntityAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Delegates Entity.");
                    updateEntity = new Entity(DelegatesEntityAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(DelegatesEntityAttributeNames.ModifiedAfterFile, true);
                }
                #endregion
                #region FenceScopeOfWork Entity
                if (targetEntity.LogicalName == FenceScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Fence SOW Entity.");
                    updateEntity = new Entity(FenceScopeofWorkAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(FenceScopeofWorkAttributeNames.ModifiedAfterFile, true);
                }
                #endregion
                #region SidewalkShedScopeofwork Entity
                if (targetEntity.LogicalName == SHScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Side Walk SOW Entity.");
                    updateEntity = new Entity(SHScopeofWorkAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(SHScopeofWorkAttributeNames.ModifiedAfterFile, true);
                }
                #endregion
                #region ScaffoldScopeofwork Entity
                if (targetEntity.LogicalName == ScaffoldScopeofWorkAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Scaffold SOW Entity.");
                    updateEntity = new Entity(ScaffoldScopeofWorkAttributeNames.EntityLogicalName);
                    updateEntity.SetAttributeValue(ScaffoldScopeofWorkAttributeNames.ModifiedAfterFile, true);
                }
                #endregion
                #region Signs Entity

                if (targetEntity.LogicalName == SignCharactersticsAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    crmTrace.AppendLine("Sign Entity.");
                    updateEntity = new Entity(SignCharactersticsAttributeName.EntityLogicalName);
                    updateEntity.SetAttributeValue(SignCharactersticsAttributeName.ModifiedAfterFile, true);

                }
                #endregion
                updateEntity.Id = targetEntity.Id;
                service.Update(updateEntity);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - UpdateModifiedAfterFileFlag", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


        #region Create JobFilingChangeSet Records

        private static void CreateJobFilingChangeSetRecords(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, Dictionary<string, string> preimageValues, string filingObjattribute, int filingType, string entityDisplayName)
        {
            

            try
            {
                bool isChangesetRecordCreated = false; //based on this falg we have to update the modified after flag falg
                foreach (var item in preimageValues)
                {
                    crmTrace.AppendLine("loop PreImage For:" + targetEntity.LogicalName);
                    Entity jobFilingchangeset = new Entity();
                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;

                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                    {

                        string newValue = SetNewValueBasedOnType(service, targetEntity, crmTrace, preImage, item);
                        string oldValue = item.Value.ToString();




                        if (item.Key.ToString() == WorkCostDetailsAttributeNames.UnitCost || item.Key.ToString() == WorkCostDetailsAttributeNames.TotalCost)
                        {
                            if (newValue.Contains("."))
                            {
                                string[] newVal = newValue.ToString().Split('.');
                                if (newVal[1] == "0000" || newVal[1] == "00" || newVal[1] == "0000000000")
                                    newValue = newVal[0];

                            }
                            string[] est = oldValue.Split('.');
                            if (est[1] == "0000" || est[1] == "0000000000")
                                oldValue = est[0];
                        }
                        if (!newValue.Trim().Equals(oldValue.Trim()))
                        {

                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), service);
                            crmTrace.AppendLine("attribute" + item.Key.ToString());
                            EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(filingObjattribute);

                            if (!(targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName || targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName))
                            {
                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, filingObj.Id));
                            }

                            if (targetEntity.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)
                            {
                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.BoilerBuildDevice, targetEntity.ToEntityReference());
                            }
                            if (targetEntity.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName)
                            {
                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.mhScopeOfwork, targetEntity.ToEntityReference());
                            }
                            if (targetEntity.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName)
                            {
                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.BoilerScopeofwork, targetEntity.ToEntityReference());
                            }
                            //Set NewValue to changeSet entity based on Type of Attribute
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, new OptionSetValue(filingType));
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, entityDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                            service.Create(jobFilingchangeset);

                            isChangesetRecordCreated = true;

                        }
                    }
                }

                if(isChangesetRecordCreated)
                {
                    //call method to update the modified after file flag
                    JobFilingChangeTraceHandler.UpdateModifiedAfterFileFlag(service, targetEntity, crmTrace, preImage);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        #region Create JobFilingChangeSet Records

        private static void CreateJobFilingChangeSetRecordsSubRelateEntities(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, Dictionary<string, string> preimageValues, EntityReference filingObj, int filingType, string entityDisplayName)
        {
            try
            {
                foreach (var item in preimageValues)
                {
                    crmTrace.AppendLine("loop PreImage For:" + targetEntity.LogicalName);
                    Entity jobFilingchangeset = new Entity();
                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;

                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                    {

                        string newValue = SetNewValueBasedOnType(service, targetEntity, crmTrace, preImage, item);
                        string oldValue = item.Value.ToString();




                        if (item.Key.ToString() == WorkCostDetailsAttributeNames.UnitCost || item.Key.ToString() == WorkCostDetailsAttributeNames.TotalCost)
                        {
                            if (newValue.Contains("."))
                            {
                                string[] newVal = newValue.ToString().Split('.');
                                if (newVal[1] == "0000" || newVal[1] == "00" || newVal[1] == "0000000000")
                                    newValue = newVal[0];

                            }
                            string[] est = oldValue.Split('.');
                            if (est[1] == "0000" || est[1] == "0000000000")
                                oldValue = est[0];
                        }
                        if (!newValue.Trim().Equals(oldValue.Trim()))
                        {

                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), service);
                            crmTrace.AppendLine("attribute" + item.Key.ToString());
                            //EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(filingObjattribute);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, filingObj.Id));
                            //Set NewValue to changeSet entity based on Type of Attribute
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, new OptionSetValue(filingType));
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, entityDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                            service.Create(jobFilingchangeset);
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        /// <summary>
        /// This change set function is used only for Signs Change set- created a new relation in signs with jobfiling c 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <param name="preimageValues"></param>
        /// <param name="filingObjattribute"></param>
        /// <param name="filingType"></param>
        /// <param name="entityDisplayName"></param>
        private static void CreateJobFilingChangeSetRecordsforSigns(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, Dictionary<string, string> preimageValues, string filingObjattribute, int filingType, string entityDisplayName)
        {
            try
            {
                foreach (var item in preimageValues)
                {
                    crmTrace.AppendLine("loop PreImage For:" + targetEntity.LogicalName);
                    Entity jobFilingchangeset = new Entity();
                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;
                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                    {

                        string newValue = SetNewValueBasedOnType(service, targetEntity, crmTrace, preImage, item);
                        string oldValue = item.Value.ToString();
                        if (item.Key.ToString() == WorkCostDetailsAttributeNames.UnitCost || item.Key.ToString() == WorkCostDetailsAttributeNames.TotalCost)
                        {
                            if (newValue.Contains("."))
                            {
                                string[] newVal = newValue.ToString().Split('.');
                                if (newVal[1] == "0000" || newVal[1] == "00" || newVal[1] == "0000000000")
                                    newValue = newVal[0];

                            }
                            string[] est = oldValue.Split('.');
                            if (est[1] == "0000" || est[1] == "00" || est[1] == "0000000000")
                                oldValue = est[0];
                        }
                        if (!newValue.Trim().Equals(oldValue.Trim()))
                        {
                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), service);
                            crmTrace.AppendLine("attribute" + item.Key.ToString());
                            //  EntityReference filingObj = preImage.GetAttributeValue<EntityReference>(filingObjattribute);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.signCharacterstics, new EntityReference(SignCharactersticsAttributeName.EntityLogicalName, targetEntity.Id));
                            //Set NewValue to changeSet entity based on Type of Attribute
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, new OptionSetValue(filingType));
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, entityDisplayName);
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                            service.Create(jobFilingchangeset);
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - CreateJobFilingChangeSetRecordsforSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        #region Retrieve JobFiling Status
        public static Entity RetrieveJobFiling(IOrganizationService service, EntityReference filingObj)
        {
            Entity jobFiling = Retrieve(service, new string[] { JobFilingEntityAttributeName.FilingTypeAttributeName, JobFilingEntityAttributeName.FilingStatus }, filingObj.Id, filingObj.LogicalName);
            return jobFiling;
        }
        #endregion
        #region Set NewValue of changeset entity base don type of attribute

        private static string SetNewValueBasedOnType(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, KeyValuePair<string, string> item)
        {
            string newValue = string.Empty;
            try
            {
                crmTrace.AppendLine("SetNewValueBasedOnType Started!");
                crmTrace.AppendLine("item.Key: " + item.Key);

                string type = string.Empty;

                if (string.IsNullOrEmpty(item.Value))
                {
                    if (targetEntity.Attributes.Contains(item.Key))
                    {
                        if (targetEntity.Attributes[item.Key.ToString()] != null)
                        {
                            if (targetEntity.Attributes[item.Key.ToString()].GetType() != null)
                            {
                                type = targetEntity.Attributes[item.Key.ToString()].GetType().ToString();
                            }
                        }
                    }
                }
                else
                {
                    if (preImage.Attributes.Contains(item.Key))
                    {
                        if (preImage.Attributes[item.Key.ToString()] != null)
                        {
                            if (preImage.Attributes[item.Key.ToString()].GetType() != null)
                            {
                                type = preImage.Attributes[item.Key.ToString()].GetType().ToString();
                            }
                        }
                    }
                }
                crmTrace.AppendLine("Get Type :" + type);
                if (type.Equals("Microsoft.Xrm.Sdk.OptionSetValue"))
                {
                    OptionSetValue optionsetObj = targetEntity.GetAttributeValue<OptionSetValue>(item.Key.ToString());
                    if (optionsetObj != null)
                    {
                        int optionsetvalue = optionsetObj.Value;
                        crmTrace.AppendLine("Get Values :" + optionsetvalue);
                        string optionsetText = GetOptionsSetTextOnValue(service, targetEntity.LogicalName, item.Key.ToString(), optionsetvalue);
                        crmTrace.AppendLine("optionsetText: " + optionsetText);
                        newValue = optionsetText;
                    }
                    else
                    {
                        newValue = string.Empty;
                    }

                }
                else if (type.Equals("Microsoft.Xrm.Sdk.Money"))
                {
                    Money moneyObj = targetEntity.GetAttributeValue<Money>(item.Key.ToString());
                    if (moneyObj != null)
                    {
                        newValue = moneyObj.Value.ToString("C2", CultureInfo.CurrentCulture);

                    }
                    else
                    {
                        newValue = string.Empty;
                    }
                }
                else if (type.Equals("Microsoft.Xrm.Sdk.EntityReference"))
                {
                    EntityReference refobj = targetEntity.GetAttributeValue<EntityReference>(item.Key.ToString());
                    if (refobj != null)
                    {
                        if (refobj.LogicalName == "contact")
                        {
                            Entity refEntity = Retrieve(service, new string[] { "fullname" }, refobj.Id, refobj.LogicalName);
                            string lookupName = refEntity.Attributes["fullname"].ToString();
                            newValue = lookupName;
                        }
                        else
                        {
                            Entity refEntity = Retrieve(service, new string[] { "dobnyc_name" }, refobj.Id, refobj.LogicalName);
                            string lookupName = refEntity.Attributes["dobnyc_name"].ToString();
                            newValue = lookupName;
                        }
                    }
                    else
                    {
                        newValue = string.Empty;
                    }
                }
                else if (type.Equals("System.DateTime"))
                {
                    DateTime dateObj = targetEntity.GetAttributeValue<DateTime>(item.Key.ToString());
                    if (dateObj == DateTime.MinValue)
                    {
                        newValue = string.Empty;

                    }
                    else
                    {
                        newValue = dateObj.ToString();

                    }
                }
                else if (type.Equals("System.Boolean"))
                {
                    bool boolObj = targetEntity.GetAttributeValue<bool>(item.Key.ToString());
                    if (boolObj)
                    {
                        newValue = "Yes";
                    }
                    else
                    {
                        newValue = "No";
                    }
                }
                else if (type.Equals("System.Double"))
                {
                    double value = targetEntity.GetAttributeValue<double>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.Int32"))
                {
                    int value = targetEntity.GetAttributeValue<int>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.Decimal"))
                {
                    decimal value = targetEntity.GetAttributeValue<decimal>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.String"))
                {
                    string value = targetEntity.GetAttributeValue<string>(item.Key.ToString());
                    if (string.IsNullOrEmpty(value))
                    {
                        newValue = string.Empty;
                    }
                    else
                    {
                        newValue = value;
                    }
                }
                crmTrace.AppendLine("SetNewValueBasedOnType Ended!");
                return newValue;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return newValue;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newValue;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SetNewValueBasedOnType", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newValue;
            }
        }
        #endregion
        #region Get Values from Entity PW1 Section



        public static Dictionary<string, string> PW1ImageValues1(Entity preImage, StringBuilder crmTrace)
        {

            #region Get Pre Image values for PW1 Section
            #region Variable Declaration
            string PlumbingCheckBox = string.Empty;
            string JobDescription = string.Empty;//dobnyc_jobdescription
            string JobDescriptionLeg = string.Empty;//dobnyc_jobdescriptionlegalization
            string SprinklerCheckBox = string.Empty;
            string EstimatedJobCost = string.Empty;
            string EstimatedJobCostLegal = string.Empty;
            string TotalConstructionFloorArea = string.Empty;
            string Reviewisrequestedunderwhichbuildingcode = string.Empty;
            string LittleEorRDSite = string.Empty;
            string NoTR8InspectionCheckbox = string.Empty;

            string UnmappedCCOStreet = string.Empty;
            string RequestingLegalizationofworkwherenowork = string.Empty;
            string Workincludespermanentremovalofstandpipe = string.Empty;
            string CompliacnewiththeNYCECC = string.Empty;
            string CodeCompliancePath = string.Empty;
            string EnergyAnalysis = string.Empty;
            string ExemptfromtheNYCECC = string.Empty;
            string ProfessionaljudgementallworkisExempt = string.Empty;
            string ExistingFireAlarm = string.Empty;
            string ProposedFireAlarm = string.Empty;
            string ExisitingFireSuppression = string.Empty;
            string ProposedFireSuppression = string.Empty;
            string ExisitingSprinkler = string.Empty;
            string ProposedSprinkler = string.Empty;
            string Mixedusebuilding = string.Empty;
            string ExisitingBuildingStories = string.Empty;
            string ProposeeBuildingStories = string.Empty;
            string ExistingBuildingHeight = string.Empty;
            string ProposedBuildingHeight = string.Empty;
            string ExistingDwellingUnits = string.Empty;
            string ProposedDwellingUnits = string.Empty;

            string AlternateJobInBISAssociation = string.Empty;
            string AntennaWorkType = string.Empty;
            string BSACalendarNumbers = string.Empty;
            string CPCCalendarNumbers = string.Empty;
            string CRFNZoningExhibit = string.Empty;
            string CurbCutWorkType = string.Empty;
            string Directive14 = string.Empty;
            string Districts = string.Empty;
            string ExtendHigherThan6Feet = string.Empty;
            string HighRiseTeamTrackingNumber = string.Empty;
            string IsAntennaOneMeterinDiameter = string.Empty;
            string IsStructuralWorkIncluded = string.Empty;
            string MapNumber = string.Empty;
            string OccupyMoreThan5Percent = string.Empty;
            string Overlays = string.Empty;
            string ProvideBSACalendarNumbers = string.Empty;
            string ProvideCPCCalendarNumbers = string.Empty;
            string RelatedAltBISJobNumbers = string.Empty;
            string RelatedDOBJobNumbers = string.Empty;
            string SpecialDistricts = string.Empty;
            string StructuralStabilityAffected = string.Empty;
            string WorkIncludesPartialDemolition = string.Empty;

            string CRFNNumber1 = string.Empty;
            string CRFNNumber2 = string.Empty;
            string CRFNNumber3 = string.Empty;
            string CRFNNumber4 = string.Empty;
            string CRFNZoningExhibitNumber1 = string.Empty;
            string CRFNZoningExhibitNumber2 = string.Empty;
            string CRFNZoningExhibitNumber3 = string.Empty;
            string CRFNZoningExhibitNumber4 = string.Empty;

            //Bug 4622 - Fix
            string SiteCharacteristicsTidalWastelands = string.Empty;
            string SiteCharacteristicsCoastalErosionHazardArea = string.Empty;
            string SiteCharacteristicsFireDistrict = string.Empty;
            string SiteCharacteristicsFreshwaterWetlands = string.Empty;
            string SiteCharacteristicsUrbanRenewal = string.Empty;
            string SiteCharacteristicsFloodHazardArea = string.Empty;
            string IsFloodHzAreaSubstantiallyDamaged = string.Empty;
            string FloodHzAreaIsSubstantialImprovement = string.Empty;
            string FloodHzAreaFloodShieldsProposedWork = string.Empty;
            string AsbestosAbatementCompliance = string.Empty;
            string DEPACPControlNoAttributeName = string.Empty;
            string CommentsPWAttributeName = string.Empty;

            string OccupancyClassification = string.Empty;
            string ConstructionClassification = string.Empty;
            string MultipleDwellingClassification = string.Empty;

            string CRFNRestrictiveDeclaration = string.Empty;
            string FacadeAlternation = string.Empty;
            string AdultEstablishment = string.Empty;
            string QualityHousing = string.Empty;

            string ComplyingToLocalLaws = string.Empty;
            string ListOfLawNumbers = string.Empty;
            string IsFilingtoAddressViolations = string.Empty;
            string ListViolationsDOBECB = string.Empty;
            string ECBNumbers = string.Empty;

            string IsConjunctionJob = string.Empty;
            string BisRelatedJobNumber = string.Empty;

            //created by SN on 11/19/2018 for new fields
            string MSWorkIncludesRaisingorMoving = string.Empty;
            string STWorkOnInterior = string.Empty;
            string STWorkOnExterior = string.Empty;
            string STRemovingOneOrMoreStories = string.Empty;
            string STDemolishing50OrMore = string.Empty;
            string STAlternativeMaterialsOTCR = string.Empty;

            //ST created by SN on 01/16/2019

            string ApplicableStatSection = string.Empty; //String
            string Easementaggrementname = string.Empty; //String
            string Associatedbuildingsbulletinnumber = string.Empty; //String

            string NYSPELicenseNumber = string.Empty;

            string Modularconstnystate = string.Empty; //String
            string Modularconstnystatenyc = string.Empty; //String
            string Buildinggreater = string.Empty; //String
            string Buildingsgrossfloorarea = string.Empty; //String
            string Areallaspectratiossixorless = string.Empty; //String
            string Specialseismicenergy = string.Empty; //String
            string Doesthebuildingincludeany = string.Empty; //String
            string Isthebuildingincludedinstructural = string.Empty; //String
            string Buildinghavemorethan50000squarefeet = string.Empty; //String
            string Doanyelementsexcept = string.Empty; //String
            string Structuralpeerreview = string.Empty; //String
            string Yearforlocallaws = string.Empty;

            //Statements and signatures
            string MateriallyApplicableStatutory = string.Empty;
            string AcceptedByDOBApplicableStatutoryCheckbox = string.Empty;
            string MateriallyEasementAgreement = string.Empty;
            string AcceptedByDOBEasementAgreement = string.Empty;
            string POC3Checkbox = string.Empty;
            string POC3OwnerCheckbox = string.Empty;
            string Doesthisbuildingqualify = string.Empty;
            string ApplicantofRecordsStatementandSignaturesECA = string.Empty;
            string ApplicantofRecordsStatementandSignaturesECB = string.Empty;
            string DpCheckPW1 = string.Empty;
            string OBIorLMPCheckbox = string.Empty;
            string LicenseType = string.Empty;
            string RAorPECheckbox = string.Empty;
            string SSLicenseType = string.Empty;
            string FeeExemptionRequestNonProfitOwnedOperated = string.Empty;
            string NYCHAHHCNYCAgencyorOwnedOperated = string.Empty;
            string OwnersCertificationsRegardingOccupiedHousing = string.Empty;
            string Propertyowner4thTwoOption = string.Empty;
            string NotRequiredToNotifyNYCHomes = string.Empty;
            string NotifiedtheNYCHomes = string.Empty;
            string POCheckPW1 = string.Empty;

            //Text
            string POC3Name = string.Empty;
            string ApplicantofRecord = string.Empty;
            string OBIorLMPName = string.Empty;
            string RAorPEName = string.Empty;
            string OnwerStatmentNamePrintPW1 = string.Empty;
            string OwnerTypePW1Statement = string.Empty;
            //Date
            string POC3Date = string.Empty;
            string Date = string.Empty;
            string OBIorLMPDate = string.Empty;
            string RAorPEDate = string.Empty;
            string OnwerStatmentDatePrintPW1 = string.Empty;
            string AlternativeMaterialsthatrequire = string.Empty;
            string TotalJobCost = string.Empty;


            string InvestigatorCertificateNumber = string.Empty;
            string Depvariancev5letter = string.Empty;
            string Depacp20acp21asbestos = string.Empty;
            string AlternateBisRelatedJobNumber = string.Empty;

            #region Missing fields
            string BuildingsDesign = string.Empty;
            string Sowrequirethestandpipeservice = string.Empty;
            string Sowinvolvemorethan5contiguousfloors = string.Empty;
            string PLworkimpactthewatersupply = string.Empty;
            string Thesiteofthebuildingtobealteredordemolished4thcheckbox = string.Empty;
            string AThesiteofthebuildingtobealteredordemolished = string.Empty;
            string BNotifiedtheNYCHomes = string.Empty;
            string ProvideDateNYSHCRNotified = string.Empty;
            string Structuredesignbase = string.Empty;
            string DwellingUnits = string.Empty;
            string WorkonFloorsAttributeName = string.Empty;
            //string DEPACPControlNoAttributeName = string.Empty;
            string SROMultiple = string.Empty;
            string LoftBoard = string.Empty;
            string SiteSafetyJob = string.Empty;
            string IncludedinLMCC = string.Empty;
            string describeOther = string.Empty;

            string HeatingSystem = string.Empty;
            string VentilationSystem = string.Empty;
            string AirConditioningSystem = string.Empty;
            string Refrigeration = string.Empty;
            string CoolingTowers = string.Empty;
            string AssociatedDuctsAndPiping = string.Empty;
            string Generator = string.Empty;
            string Other = string.Empty;
            string OtherValues = string.Empty;

            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            #endregion
            try
            {
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.POC3Date))
                //{
                //    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.POC3Date);
                //    if (dateTime != DateTime.MinValue)
                //    {
                //        POC3Date = dateTime.ToString();
                //        imageValues.Add(JobFilingEntityAttributeName.POC3Date, POC3Date);
                //    }
                //    else
                //    {
                //        imageValues.Add(JobFilingEntityAttributeName.POC3Date, DateTime.MinValue.ToString());
                //    }
                //    crmTrace.AppendLine("Retrieve POC3Date:" + POC3Date);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Date))
                //{
                //    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.Date);
                //    if (dateTime != DateTime.MinValue)
                //    {
                //        Date = dateTime.ToString();
                //        imageValues.Add(JobFilingEntityAttributeName.Date, Date);
                //    }
                //    else
                //    {
                //        imageValues.Add(JobFilingEntityAttributeName.Date, DateTime.MinValue.ToString());
                //    }
                //    crmTrace.AppendLine("Retrieve Date:" + Date);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OBIorLMPDate))
                //{
                //    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.OBIorLMPDate);
                //    if (dateTime != DateTime.MinValue)
                //    {
                //        OBIorLMPDate = dateTime.ToString();
                //        imageValues.Add(JobFilingEntityAttributeName.OBIorLMPDate, OBIorLMPDate);
                //    }
                //    else
                //    {
                //        imageValues.Add(JobFilingEntityAttributeName.OBIorLMPDate, DateTime.MinValue.ToString());
                //    }
                //    crmTrace.AppendLine("Retrieve OBIorLMPDate:" + OBIorLMPDate);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RAorPEDate))
                //{
                //    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.RAorPEDate);
                //    if (dateTime != DateTime.MinValue)
                //    {
                //        RAorPEDate = dateTime.ToString();
                //        imageValues.Add(JobFilingEntityAttributeName.RAorPEDate, RAorPEDate);
                //    }
                //    else
                //    {
                //        imageValues.Add(JobFilingEntityAttributeName.RAorPEDate, DateTime.MinValue.ToString());
                //    }
                //    crmTrace.AppendLine("Retrieve RAorPEDate:" + RAorPEDate);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OnwerStatmentDatePrintPW1))
                //{
                //    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.OnwerStatmentDatePrintPW1);
                //    if (dateTime != DateTime.MinValue)
                //    {
                //        OnwerStatmentDatePrintPW1 = dateTime.ToString();
                //        imageValues.Add(JobFilingEntityAttributeName.OnwerStatmentDatePrintPW1, OnwerStatmentDatePrintPW1);
                //    }
                //    else
                //    {
                //        imageValues.Add(JobFilingEntityAttributeName.OnwerStatmentDatePrintPW1, DateTime.MinValue.ToString());
                //    }
                //    crmTrace.AppendLine("Retrieve OnwerStatmentDatePrintPW1:" + OnwerStatmentDatePrintPW1);
                //}

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MateriallyApplicableStatutory))
                {
                    crmTrace.AppendLine("Retrieve MateriallyApplicableStatutory");
                    MateriallyApplicableStatutory = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.MateriallyApplicableStatutory);
                    imageValues.Add(JobFilingEntityAttributeName.MateriallyApplicableStatutory, MateriallyApplicableStatutory);
                    crmTrace.AppendLine("Retrieve MateriallyApplicableStatutory:" + MateriallyApplicableStatutory);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AcceptedByDOBApplicableStatutoryCheckbox))
                {
                    crmTrace.AppendLine("Retrieve AcceptedByDOBApplicableStatutoryCheckbox");
                    AcceptedByDOBApplicableStatutoryCheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AcceptedByDOBApplicableStatutoryCheckbox);
                    imageValues.Add(JobFilingEntityAttributeName.AcceptedByDOBApplicableStatutoryCheckbox, AcceptedByDOBApplicableStatutoryCheckbox);
                    crmTrace.AppendLine("Retrieve AcceptedByDOBApplicableStatutoryCheckbox:" + AcceptedByDOBApplicableStatutoryCheckbox);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MateriallyEasementAgreement))
                {
                    crmTrace.AppendLine("Retrieve MateriallyEasementAgreement");
                    MateriallyEasementAgreement = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.MateriallyEasementAgreement);
                    imageValues.Add(JobFilingEntityAttributeName.MateriallyEasementAgreement, MateriallyEasementAgreement);
                    crmTrace.AppendLine("Retrieve MateriallyEasementAgreement:" + MateriallyEasementAgreement);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AcceptedByDOBEasementAgreement))
                {
                    crmTrace.AppendLine("Retrieve AcceptedByDOBEasementAgreement");
                    AcceptedByDOBEasementAgreement = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AcceptedByDOBEasementAgreement);
                    imageValues.Add(JobFilingEntityAttributeName.AcceptedByDOBEasementAgreement, AcceptedByDOBEasementAgreement);
                    crmTrace.AppendLine("Retrieve AcceptedByDOBEasementAgreement:" + AcceptedByDOBEasementAgreement);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.POC3Checkbox))
                {
                    crmTrace.AppendLine("Retrieve POC3Checkbox");
                    POC3Checkbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.POC3Checkbox);
                    imageValues.Add(JobFilingEntityAttributeName.POC3Checkbox, POC3Checkbox);
                    crmTrace.AppendLine("Retrieve POC3Checkbox:" + POC3Checkbox);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.POC3OwnerCheckbox))
                {
                    crmTrace.AppendLine("Retrieve POC3OwnerCheckbox");
                    POC3OwnerCheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.POC3OwnerCheckbox);
                    imageValues.Add(JobFilingEntityAttributeName.POC3OwnerCheckbox, POC3OwnerCheckbox);
                    crmTrace.AppendLine("Retrieve POC3OwnerCheckbox:" + POC3OwnerCheckbox);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Doesthisbuildingqualify))
                {
                    crmTrace.AppendLine("Retrieve Doesthisbuildingqualify");
                    Doesthisbuildingqualify = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Doesthisbuildingqualify);
                    imageValues.Add(JobFilingEntityAttributeName.Doesthisbuildingqualify, Doesthisbuildingqualify);
                    crmTrace.AppendLine("Retrieve Doesthisbuildingqualify:" + Doesthisbuildingqualify);
                }
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECA))
                //{
                //    crmTrace.AppendLine("Retrieve ApplicantofRecordsStatementandSignaturesECA");
                //    ApplicantofRecordsStatementandSignaturesECA = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECA);
                //    imageValues.Add(JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECA, ApplicantofRecordsStatementandSignaturesECA);
                //    crmTrace.AppendLine("Retrieve ApplicantofRecordsStatementandSignaturesECA:" + ApplicantofRecordsStatementandSignaturesECA);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECB))
                //{
                //    crmTrace.AppendLine("Retrieve ApplicantofRecordsStatementandSignaturesECB");
                //    ApplicantofRecordsStatementandSignaturesECB = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECB);
                //    imageValues.Add(JobFilingEntityAttributeName.ApplicantofRecordsStatementandSignaturesECB, ApplicantofRecordsStatementandSignaturesECB);
                //    crmTrace.AppendLine("Retrieve ApplicantofRecordsStatementandSignaturesECB:" + ApplicantofRecordsStatementandSignaturesECB);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.DpCheckPW1))
                //{
                //    crmTrace.AppendLine("Retrieve DpCheckPW1");
                //    DpCheckPW1 = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.DpCheckPW1);
                //    imageValues.Add(JobFilingEntityAttributeName.DpCheckPW1, DpCheckPW1);
                //    crmTrace.AppendLine("Retrieve DpCheckPW1:" + DpCheckPW1);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OBIorLMPCheckbox))
                //{
                //    crmTrace.AppendLine("Retrieve OBIorLMPCheckbox");
                //    OBIorLMPCheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.OBIorLMPCheckbox);
                //    imageValues.Add(JobFilingEntityAttributeName.OBIorLMPCheckbox, OBIorLMPCheckbox);
                //    crmTrace.AppendLine("Retrieve OBIorLMPCheckbox:" + OBIorLMPCheckbox);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.LicenseType))
                //{
                //    crmTrace.AppendLine("Retrieve LicenseType");
                //    LicenseType = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.LicenseType);
                //    imageValues.Add(JobFilingEntityAttributeName.LicenseType, LicenseType);
                //    crmTrace.AppendLine("Retrieve LicenseType:" + LicenseType);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RAorPECheckbox))
                //{
                //    crmTrace.AppendLine("Retrieve RAorPECheckbox");
                //    RAorPECheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.RAorPECheckbox);
                //    imageValues.Add(JobFilingEntityAttributeName.RAorPECheckbox, RAorPECheckbox);
                //    crmTrace.AppendLine("Retrieve RAorPECheckbox:" + RAorPECheckbox);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SSLicenseType))
                //{
                //    crmTrace.AppendLine("Retrieve SSLicenseType");
                //    SSLicenseType = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SSLicenseType);
                //    imageValues.Add(JobFilingEntityAttributeName.SSLicenseType, SSLicenseType);
                //    crmTrace.AppendLine("Retrieve SSLicenseType:" + SSLicenseType);
                //}
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated))
                {
                    crmTrace.AppendLine("Retrieve FeeExemptionRequestNonProfitOwnedOperated");
                    FeeExemptionRequestNonProfitOwnedOperated = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated);
                    imageValues.Add(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated, FeeExemptionRequestNonProfitOwnedOperated);
                    crmTrace.AppendLine("Retrieve FeeExemptionRequestNonProfitOwnedOperated:" + FeeExemptionRequestNonProfitOwnedOperated);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated))
                {
                    crmTrace.AppendLine("Retrieve NYCHAHHCNYCAgencyorOwnedOperated");
                    NYCHAHHCNYCAgencyorOwnedOperated = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated);
                    imageValues.Add(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated, NYCHAHHCNYCAgencyorOwnedOperated);
                    crmTrace.AppendLine("Retrieve NYCHAHHCNYCAgencyorOwnedOperated:" + NYCHAHHCNYCAgencyorOwnedOperated);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing))
                {
                    crmTrace.AppendLine("Retrieve OwnersCertificationsRegardingOccupiedHousing");
                    OwnersCertificationsRegardingOccupiedHousing = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing);
                    imageValues.Add(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing, OwnersCertificationsRegardingOccupiedHousing);
                    crmTrace.AppendLine("Retrieve OwnersCertificationsRegardingOccupiedHousing:" + OwnersCertificationsRegardingOccupiedHousing);
                }
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Propertyowner4thTwoOption))
                //{
                //    crmTrace.AppendLine("Retrieve Propertyowner4thTwoOption");
                //    Propertyowner4thTwoOption = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Propertyowner4thTwoOption);
                //    imageValues.Add(JobFilingEntityAttributeName.Propertyowner4thTwoOption, Propertyowner4thTwoOption);
                //    crmTrace.AppendLine("Retrieve Propertyowner4thTwoOption:" + Propertyowner4thTwoOption);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.NotRequiredToNotifyNYCHomes))
                //{
                //    crmTrace.AppendLine("Retrieve NotRequiredToNotifyNYCHomes");
                //    NotRequiredToNotifyNYCHomes = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.NotRequiredToNotifyNYCHomes);
                //    imageValues.Add(JobFilingEntityAttributeName.NotRequiredToNotifyNYCHomes, NotRequiredToNotifyNYCHomes);
                //    crmTrace.AppendLine("Retrieve NotRequiredToNotifyNYCHomes:" + NotRequiredToNotifyNYCHomes);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.NotifiedtheNYCHomes))
                //{
                //    crmTrace.AppendLine("Retrieve NotifiedtheNYCHomes");
                //    NotifiedtheNYCHomes = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.NotifiedtheNYCHomes);
                //    imageValues.Add(JobFilingEntityAttributeName.NotifiedtheNYCHomes, NotifiedtheNYCHomes);
                //    crmTrace.AppendLine("Retrieve NotifiedtheNYCHomes:" + NotifiedtheNYCHomes);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.POCheckPW1))
                //{
                //    crmTrace.AppendLine("Retrieve POCheckPW1");
                //    POCheckPW1 = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.POCheckPW1);
                //    imageValues.Add(JobFilingEntityAttributeName.POCheckPW1, POCheckPW1);
                //    crmTrace.AppendLine("Retrieve POCheckPW1:" + POCheckPW1);
                //}


                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.POC3Name))
                //{
                //    crmTrace.AppendLine("Retrieve POC3Name");
                //    POC3Name = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.POC3Name).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.POC3Name, POC3Name);
                //    crmTrace.AppendLine("Retrieve POC3Name:" + POC3Name);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.POC3Name, string.Empty);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicantofRecord))
                //{
                //    crmTrace.AppendLine("Retrieve ApplicantofRecord");
                //    ApplicantofRecord = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ApplicantofRecord).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.ApplicantofRecord, ApplicantofRecord);
                //    crmTrace.AppendLine("Retrieve ApplicantofRecord:" + ApplicantofRecord);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.ApplicantofRecord, string.Empty);
                //}

                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OBIorLMPName))
                //{
                //    crmTrace.AppendLine("Retrieve OBIorLMPName");
                //    OBIorLMPName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.OBIorLMPName).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.OBIorLMPName, OBIorLMPName);
                //    crmTrace.AppendLine("Retrieve OBIorLMPName:" + OBIorLMPName);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.OBIorLMPName, string.Empty);
                //}

                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RAorPEName))
                //{
                //    crmTrace.AppendLine("Retrieve RAorPEName");
                //    RAorPEName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.RAorPEName).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.RAorPEName, RAorPEName);
                //    crmTrace.AppendLine("Retrieve JobDescription:" + RAorPEName);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.RAorPEName, string.Empty);
                //}
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OnwerStatmentNamePrintPW1))
                //{
                //    crmTrace.AppendLine("Retrieve OnwerStatmentNamePrintPW1");
                //    OnwerStatmentNamePrintPW1 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.OnwerStatmentNamePrintPW1).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.OnwerStatmentNamePrintPW1, OnwerStatmentNamePrintPW1);
                //    crmTrace.AppendLine("Retrieve JobDescription:" + OnwerStatmentNamePrintPW1);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.OnwerStatmentNamePrintPW1, string.Empty);
                //}



                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Yearforlocallaws))
                {
                    crmTrace.AppendLine("Retrieve Yearforlocallaws");
                    Yearforlocallaws = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Yearforlocallaws).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Yearforlocallaws, Yearforlocallaws);
                    crmTrace.AppendLine("Retrieve Yearforlocallaws:" + Yearforlocallaws);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Yearforlocallaws, string.Empty);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber))
                {
                    crmTrace.AppendLine("Retrieve AlternateBisRelatedJobNumber");
                    AlternateBisRelatedJobNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber, AlternateBisRelatedJobNumber);
                    crmTrace.AppendLine("Retrieve AlternateBisRelatedJobNumber:" + AlternateBisRelatedJobNumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.NYSPELicenseNumber))
                {
                    crmTrace.AppendLine("Retrieve NYSPELicenseNumber");
                    NYSPELicenseNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.NYSPELicenseNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.NYSPELicenseNumber, NYSPELicenseNumber);
                    crmTrace.AppendLine("Retrieve NYSPELicenseNumber:" + NYSPELicenseNumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.NYSPELicenseNumber, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicableStatSection))
                {
                    crmTrace.AppendLine("Retrieve ApplicableStatSection");
                    ApplicableStatSection = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ApplicableStatSection).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ApplicableStatSection, ApplicableStatSection);
                    crmTrace.AppendLine("Retrieve ApplicableStatSection:" + ApplicableStatSection);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ApplicableStatSection, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Easementaggrementname))
                {
                    crmTrace.AppendLine("Retrieve Easementaggrementname");
                    Easementaggrementname = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Easementaggrementname).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Easementaggrementname, Easementaggrementname);
                    crmTrace.AppendLine("Retrieve Easementaggrementname:" + Easementaggrementname);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Easementaggrementname, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber))
                {
                    crmTrace.AppendLine("Retrieve Associatedbuildingsbulletinnumber");
                    Associatedbuildingsbulletinnumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, Associatedbuildingsbulletinnumber);
                    crmTrace.AppendLine("Retrieve Associatedbuildingsbulletinnumber:" + Associatedbuildingsbulletinnumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Structuralpeerreview");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Structuralpeerreview))
                {
                    Structuralpeerreview = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Structuralpeerreview);
                    imageValues.Add(JobFilingEntityAttributeName.Structuralpeerreview, Structuralpeerreview);
                    crmTrace.AppendLine("Retrieve Structuralpeerreview:" + Structuralpeerreview);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Structuralpeerreview, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Doanyelementsexcept");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Doanyelementsexcept))
                {
                    Doanyelementsexcept = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Doanyelementsexcept);
                    imageValues.Add(JobFilingEntityAttributeName.Doanyelementsexcept, Doanyelementsexcept);
                    crmTrace.AppendLine("Retrieve Doanyelementsexcept:" + Doanyelementsexcept);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Doanyelementsexcept, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Buildinghavemorethan50000squarefeet");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet))
                {
                    Buildinghavemorethan50000squarefeet = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet);
                    imageValues.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, Buildinghavemorethan50000squarefeet);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildinghavemorethan50000squarefeet);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Specialseismicenergy");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Isthebuildingincludedinstructural))
                {
                    Isthebuildingincludedinstructural = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Isthebuildingincludedinstructural);
                    imageValues.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, Isthebuildingincludedinstructural);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Isthebuildingincludedinstructural);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Specialseismicenergy");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Doesthebuildingincludeany))
                {
                    Doesthebuildingincludeany = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Doesthebuildingincludeany);
                    imageValues.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, Doesthebuildingincludeany);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Doesthebuildingincludeany);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Specialseismicenergy");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Specialseismicenergy))
                {
                    Specialseismicenergy = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Specialseismicenergy);
                    imageValues.Add(JobFilingEntityAttributeName.Specialseismicenergy, Specialseismicenergy);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Specialseismicenergy);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Specialseismicenergy, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Areallaspectratiossixorless");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Areallaspectratiossixorless))
                {
                    Areallaspectratiossixorless = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Areallaspectratiossixorless);
                    imageValues.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, Areallaspectratiossixorless);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Areallaspectratiossixorless);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Buildingsgrossfloorarea");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildingsgrossfloorarea))
                {
                    Buildingsgrossfloorarea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildingsgrossfloorarea);
                    imageValues.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, Buildingsgrossfloorarea);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildingsgrossfloorarea);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Buildinggreater");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildinggreater))
                {
                    Buildinggreater = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildinggreater);
                    imageValues.Add(JobFilingEntityAttributeName.Buildinggreater, Buildinggreater);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildinggreater);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildinggreater, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Modularconstnystatenyc");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystatenyc))
                {
                    Modularconstnystatenyc = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Modularconstnystatenyc);
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, Modularconstnystatenyc);
                    crmTrace.AppendLine("Retrieve Modularconstnystate:" + Modularconstnystatenyc);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Modularconstnystate");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystate))
                {
                    Modularconstnystate = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Modularconstnystate);
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystate, Modularconstnystate);
                    crmTrace.AppendLine("Retrieve Modularconstnystate:" + Modularconstnystate);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystate, string.Empty);
                }


                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    crmTrace.AppendLine("Retrieve PlumbingCheckBox");
                    PlumbingCheckBox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.PlumbingCheckBox);
                    imageValues.Add(JobFilingEntityAttributeName.PlumbingCheckBox, PlumbingCheckBox);
                    crmTrace.AppendLine("Retrieve PlumbingCheckBox:" + PlumbingCheckBox);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    crmTrace.AppendLine("Retrieve SprinklerCheckBox");
                    SprinklerCheckBox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SprinklerCheckBox);
                    imageValues.Add(JobFilingEntityAttributeName.SprinklerCheckBox, SprinklerCheckBox);
                    crmTrace.AppendLine("Retrieve SprinklerCheckBox:" + SprinklerCheckBox);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.NoTR8InspectionCheckbox))
                {
                    crmTrace.AppendLine("Retrieve NoTR8InspectionCheckbox");
                    NoTR8InspectionCheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.NoTR8InspectionCheckbox);
                    imageValues.Add(JobFilingEntityAttributeName.NoTR8InspectionCheckbox, NoTR8InspectionCheckbox);
                    crmTrace.AppendLine("Retrieve NoTR8InspectionCheckbox:" + NoTR8InspectionCheckbox);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))
                {
                    crmTrace.AppendLine("Retrieve EstimatedJobCost");
                    Money jobcost = preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost);
                    EstimatedJobCost = jobcost.Value.ToString("C2", CultureInfo.CurrentCulture);
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCost, EstimatedJobCost);
                    crmTrace.AppendLine("Retrieve EstimatedJobCost:" + EstimatedJobCost);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                {
                    crmTrace.AppendLine("Retrieve EstimatedJobCostLeg");
                    Money jobcost = preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCostLegal);
                    EstimatedJobCostLegal = jobcost.Value.ToString("C2", CultureInfo.CurrentCulture);
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, EstimatedJobCostLegal);
                    crmTrace.AppendLine("Retrieve EstimatedJobCostLegal:" + EstimatedJobCostLegal);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalJobCost))
                {
                    crmTrace.AppendLine("Retrieve TotalJobCost");
                    Money jobcost = preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalJobCost);
                    TotalJobCost = jobcost.Value.ToString("C2", CultureInfo.CurrentCulture);
                    imageValues.Add(JobFilingEntityAttributeName.TotalJobCost, TotalJobCost);
                    crmTrace.AppendLine("Retrieve TotalJobCost:" + TotalJobCost);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.JobDescription))
                {
                    crmTrace.AppendLine("Retrieve JobDescription");
                    crmTrace.AppendLine("Retrieve wewfwefwefew");
                    JobDescription = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescription).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.JobDescription, JobDescription);
                    crmTrace.AppendLine("Retrieve JobDescriptionwdwede:");
                    crmTrace.AppendLine("Retrieve JobDescription:" + JobDescription);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement))
                {
                    crmTrace.AppendLine("Retrieve OwnerTypePW1Statement");
                    OwnerTypePW1Statement = preImage.FormattedValues[JobFilingEntityAttributeName.OwnerTypePW1Statement];
                    imageValues.Add(JobFilingEntityAttributeName.OwnerTypePW1Statement, OwnerTypePW1Statement);
                    crmTrace.AppendLine("Retrieve OwnerTypePW1Statement:" + OwnerTypePW1Statement);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.JobDescriptionLeg))
                {
                    crmTrace.AppendLine("Retrieve JobDescriptionLeg");
                    JobDescriptionLeg = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescriptionLeg).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.JobDescriptionLeg, JobDescriptionLeg);
                    crmTrace.AppendLine("Retrieve JobDescriptionLeg:" + JobDescriptionLeg);
                }

                crmTrace.AppendLine("Retrieve TotalConstructionFloorArea");
                TotalConstructionFloorArea = (preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea)) ? (preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea)).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.TotalConstructionFloorArea, TotalConstructionFloorArea);
                crmTrace.AppendLine("Retrieve TotalConstructionFloorArea:" + TotalConstructionFloorArea);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode))
                {
                    crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode");
                    Reviewisrequestedunderwhichbuildingcode = preImage.FormattedValues[JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode];
                    imageValues.Add(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode, Reviewisrequestedunderwhichbuildingcode);
                    crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode:" + Reviewisrequestedunderwhichbuildingcode);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.LittleEorRDSite))
                {
                    crmTrace.AppendLine("Retrieve LittleEorRDSite");
                    LittleEorRDSite = preImage.FormattedValues[JobFilingEntityAttributeName.LittleEorRDSite];
                    imageValues.Add(JobFilingEntityAttributeName.LittleEorRDSite, LittleEorRDSite);
                    crmTrace.AppendLine("Retrieve LittleEorRDSite:" + LittleEorRDSite);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.UnmappedCCOStreet))
                {
                    crmTrace.AppendLine("Retrieve UnmappedCCOStreet");
                    UnmappedCCOStreet = preImage.FormattedValues[JobFilingEntityAttributeName.UnmappedCCOStreet];
                    imageValues.Add(JobFilingEntityAttributeName.UnmappedCCOStreet, UnmappedCCOStreet);
                    crmTrace.AppendLine("Retrieve UnmappedCCOStreet:" + UnmappedCCOStreet);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork))
                {
                    crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork");
                    RequestingLegalizationofworkwherenowork = preImage.FormattedValues[JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork];
                    imageValues.Add(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork, RequestingLegalizationofworkwherenowork);
                    crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork:" + RequestingLegalizationofworkwherenowork);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe))
                {
                    crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe");
                    Workincludespermanentremovalofstandpipe = preImage.FormattedValues[JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe];
                    imageValues.Add(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe, Workincludespermanentremovalofstandpipe);
                    crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe:" + Workincludespermanentremovalofstandpipe);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CompliacnewiththeNYCECC))
                {
                    crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC");
                    CompliacnewiththeNYCECC = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CompliacnewiththeNYCECC);
                    imageValues.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, CompliacnewiththeNYCECC);
                    crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC:" + CompliacnewiththeNYCECC);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CodeCompliancePath))
                {
                    crmTrace.AppendLine("Retrieve CodeCompliancePath");
                    CodeCompliancePath = preImage.FormattedValues[JobFilingEntityAttributeName.CodeCompliancePath];
                    imageValues.Add(JobFilingEntityAttributeName.CodeCompliancePath, CodeCompliancePath);
                    crmTrace.AppendLine("Retrieve CodeCompliancePath:" + CodeCompliancePath);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EnergyAnalysis))
                {
                    crmTrace.AppendLine("Retrieve EnergyAnalysis");
                    EnergyAnalysis = preImage.FormattedValues[JobFilingEntityAttributeName.EnergyAnalysis];
                    imageValues.Add(JobFilingEntityAttributeName.EnergyAnalysis, EnergyAnalysis);
                    crmTrace.AppendLine("Retrieve EnergyAnalysis:" + EnergyAnalysis);
                }
                             

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExemptfromtheNYCECC))
                {
                    crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC");
                    ExemptfromtheNYCECC = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExemptfromtheNYCECC);
                    imageValues.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, ExemptfromtheNYCECC);
                    crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC:" + ExemptfromtheNYCECC);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt))
                {
                    crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt");
                    ProfessionaljudgementallworkisExempt = preImage.FormattedValues[JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt];
                    imageValues.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, ProfessionaljudgementallworkisExempt);
                    crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt:" + ProfessionaljudgementallworkisExempt);
                }
               

                crmTrace.AppendLine("Retrieve ExistingFireAlarm");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingFireAlarm))
                {
                    ExistingFireAlarm = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExistingFireAlarm);
                    imageValues.Add(JobFilingEntityAttributeName.ExistingFireAlarm, ExistingFireAlarm);
                    crmTrace.AppendLine("Retrieve ExistingFireAlarm:" + ExistingFireAlarm);
                }
                crmTrace.AppendLine("Retrieve ProposedFireAlarm");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireAlarm))
                {
                    ProposedFireAlarm = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedFireAlarm);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireAlarm, ProposedFireAlarm);
                    crmTrace.AppendLine("Retrieve ProposedFireAlarm:" + ProposedFireAlarm);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingFireSuppression))
                {
                    crmTrace.AppendLine("Retrieve ExisitingFireSuppression");
                    ExisitingFireSuppression = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExisitingFireSuppression);
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, ExisitingFireSuppression);
                    crmTrace.AppendLine("Retrieve ExisitingFireSuppression:" + ExisitingFireSuppression);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireSuppression))
                {
                    crmTrace.AppendLine("Retrieve ProposedFireSuppression");
                    ProposedFireSuppression = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedFireSuppression);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireSuppression, ProposedFireSuppression);
                    crmTrace.AppendLine("Retrieve ProposedFireSuppression:" + ProposedFireSuppression);
                }

                crmTrace.AppendLine("Retrieve ExisitingSprinkler");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingSprinkler))
                {
                    ExisitingSprinkler = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExisitingSprinkler);
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingSprinkler, ExisitingSprinkler);
                    crmTrace.AppendLine("Retrieve ExisitingSprinkler:" + ExisitingSprinkler);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedSprinkler))
                {
                    crmTrace.AppendLine("Retrieve ProposedSprinkler");
                    ProposedSprinkler = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedSprinkler);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedSprinkler, ProposedSprinkler);
                    crmTrace.AppendLine("Retrieve ProposedSprinkler:" + ProposedSprinkler);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Mixedusebuilding))
                {
                    crmTrace.AppendLine("Retrieve Mixedusebuilding");
                    Mixedusebuilding = preImage.FormattedValues[JobFilingEntityAttributeName.Mixedusebuilding];
                    imageValues.Add(JobFilingEntityAttributeName.Mixedusebuilding, Mixedusebuilding);
                    crmTrace.AppendLine("Retrieve Mixedusebuilding:" + Mixedusebuilding);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingBuildingStories))
                {
                    crmTrace.AppendLine("Retrieve ExisitingBuildingStories");
                    ExisitingBuildingStories = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExisitingBuildingStories).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingBuildingStories, ExisitingBuildingStories);
                    crmTrace.AppendLine("Retrieve ExisitingBuildingStories:" + ExisitingBuildingStories);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingBuildingStories))
                {
                    crmTrace.AppendLine("Retrieve ProposeeBuildingStories");
                    ProposeeBuildingStories = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposeeBuildingStories, ProposeeBuildingStories);
                    crmTrace.AppendLine("Retrieve ProposeeBuildingStories:" + ProposeeBuildingStories);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingBuildingHeight))
                {
                    crmTrace.AppendLine("Retrieve ExistingBuildingHeight");
                    ExistingBuildingHeight = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingBuildingHeight).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExistingBuildingHeight, ExistingBuildingHeight);
                    crmTrace.AppendLine("Retrieve ExistingBuildingHeight:" + ExistingBuildingHeight);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight))
                {
                    crmTrace.AppendLine("Retrieve ProposedBuildingHeight");
                    ProposedBuildingHeight = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposedBuildingHeight, ProposedBuildingHeight);
                    crmTrace.AppendLine("Retrieve ProposedBuildingHeight:" + ProposedBuildingHeight);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingDwellingUnits))
                {
                    crmTrace.AppendLine("Retrieve ExistingDwellingUnits");
                    ExistingDwellingUnits = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingDwellingUnits).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExistingDwellingUnits, ExistingDwellingUnits);
                    crmTrace.AppendLine("Retrieve ExistingDwellingUnits:" + ExistingDwellingUnits);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedDwellingUnits))
                {
                    crmTrace.AppendLine("Retrieve ProposedDwellingUnits");
                    ProposedDwellingUnits = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedDwellingUnits).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposedDwellingUnits, ProposedDwellingUnits);
                    crmTrace.AppendLine("Retrieve ProposedDwellingUnits:" + ProposedDwellingUnits);
                }

                //Antenna & Curb Cut - Start

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation))
                {
                    crmTrace.AppendLine("Retrieve AlternateJobInBISAssociation");
                    AlternateJobInBISAssociation = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AlternateJobInBISAssociation);
                    imageValues.Add(JobFilingEntityAttributeName.AlternateJobInBISAssociation, AlternateJobInBISAssociation);
                    crmTrace.AppendLine("Retrieve AlternateJobInBISAssociation:" + AlternateJobInBISAssociation);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AntennaWorkType))
                {
                    crmTrace.AppendLine("Retrieve AntennaWorkType");
                    AntennaWorkType = preImage.FormattedValues[JobFilingEntityAttributeName.AntennaWorkType];
                    imageValues.Add(JobFilingEntityAttributeName.AntennaWorkType, AntennaWorkType);
                    crmTrace.AppendLine("Retrieve AntennaWorkType:" + AntennaWorkType);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BSACalendarNumbers))
                {
                    crmTrace.AppendLine("Retrieve BSACalendarNumbers");
                    BSACalendarNumbers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.BSACalendarNumbers);
                    imageValues.Add(JobFilingEntityAttributeName.BSACalendarNumbers, BSACalendarNumbers);
                    crmTrace.AppendLine("Retrieve BSACalendarNumbers:" + BSACalendarNumbers);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CPCCalendarNumbers))
                {
                    crmTrace.AppendLine("Retrieve CPCCalendarNumbers");
                    CPCCalendarNumbers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CPCCalendarNumbers);
                    imageValues.Add(JobFilingEntityAttributeName.CPCCalendarNumbers, CPCCalendarNumbers);
                    crmTrace.AppendLine("Retrieve CPCCalendarNumbers:" + CPCCalendarNumbers);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibit");
                CRFNZoningExhibit = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibit)) ? SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CRFNZoningExhibit) : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibit, CRFNZoningExhibit);
                crmTrace.AppendLine("Retrieve CRFNZoningExhibit:" + CRFNZoningExhibit);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CurbCutWorkType))
                {
                    crmTrace.AppendLine("Retrieve CurbCutWorkType");
                    CurbCutWorkType = preImage.FormattedValues[JobFilingEntityAttributeName.CurbCutWorkType];
                    imageValues.Add(JobFilingEntityAttributeName.CurbCutWorkType, CurbCutWorkType);
                    crmTrace.AppendLine("Retrieve CurbCutWorkType:" + CurbCutWorkType);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Directive14))
                {
                    crmTrace.AppendLine("Retrieve Directive14");
                    Directive14 = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Directive14);
                    imageValues.Add(JobFilingEntityAttributeName.Directive14, Directive14);
                    crmTrace.AppendLine("Retrieve Directive14:" + Directive14);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Districts))
                {
                    crmTrace.AppendLine("Retrieve Districts");
                    Districts = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Districts).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Districts, Districts);
                    crmTrace.AppendLine("Retrieve Districts:" + Districts);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExtendHigherThan6Feet))
                {
                    crmTrace.AppendLine("Retrieve ExtendHigherThan6Feet");
                    ExtendHigherThan6Feet = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExtendHigherThan6Feet);
                    imageValues.Add(JobFilingEntityAttributeName.ExtendHigherThan6Feet, ExtendHigherThan6Feet);
                    crmTrace.AppendLine("Retrieve ExtendHigherThan6Feet:" + ExtendHigherThan6Feet);
                }

                crmTrace.AppendLine("Retrieve HighRiseTeamTrackingNumber");
                HighRiseTeamTrackingNumber = (preImage.Attributes.Contains(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber, HighRiseTeamTrackingNumber);
                crmTrace.AppendLine("Retrieve HighRiseTeamTrackingNumber:" + HighRiseTeamTrackingNumber);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter))
                {
                    crmTrace.AppendLine("Retrieve IsAntennaOneMeterinDiameter");
                    IsAntennaOneMeterinDiameter = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter);
                    imageValues.Add(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter, IsAntennaOneMeterinDiameter);
                    crmTrace.AppendLine("Retrieve IsAntennaOneMeterinDiameter:" + IsAntennaOneMeterinDiameter);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsStructuralWorkIncluded))
                {
                    crmTrace.AppendLine("Retrieve IsStructuralWorkIncluded");
                    IsStructuralWorkIncluded = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsStructuralWorkIncluded);
                    imageValues.Add(JobFilingEntityAttributeName.IsStructuralWorkIncluded, IsStructuralWorkIncluded);
                    crmTrace.AppendLine("Retrieve IsStructuralWorkIncluded:" + IsStructuralWorkIncluded);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MapNumber))
                {
                    crmTrace.AppendLine("Retrieve MapNumber");
                    MapNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.MapNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.MapNumber, MapNumber);
                    crmTrace.AppendLine("Retrieve MapNumber:" + MapNumber);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OccupyMoreThan5Percent))
                {
                    crmTrace.AppendLine("Retrieve OccupyMoreThan5Percent");
                    OccupyMoreThan5Percent = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.OccupyMoreThan5Percent);
                    imageValues.Add(JobFilingEntityAttributeName.OccupyMoreThan5Percent, OccupyMoreThan5Percent);
                    crmTrace.AppendLine("Retrieve OccupyMoreThan5Percent:" + OccupyMoreThan5Percent);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Overlays))
                {
                    crmTrace.AppendLine("Retrieve Overlays");
                    Overlays = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Overlays).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Overlays, Overlays);
                    crmTrace.AppendLine("Retrieve Overlays:" + Overlays);
                }

                crmTrace.AppendLine("Retrieve ProvideBSACalendarNumbers");
                ProvideBSACalendarNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProvideBSACalendarNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideBSACalendarNumbers).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ProvideBSACalendarNumbers, ProvideBSACalendarNumbers);
                crmTrace.AppendLine("Retrieve ProvideBSACalendarNumbers:" + ProvideBSACalendarNumbers);

                crmTrace.AppendLine("Retrieve ProvideCPCCalendarNumbers");
                ProvideCPCCalendarNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers, ProvideCPCCalendarNumbers);
                crmTrace.AppendLine("Retrieve ProvideCPCCalendarNumbers:" + ProvideCPCCalendarNumbers);

                //crmTrace.AppendLine("Retrieve RelatedAltBISJobNumbers");
                //RelatedAltBISJobNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.RelatedAltBISJobNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedAltBISJobNumbers).ToString() : string.Empty;
                //imageValues.Add(JobFilingEntityAttributeName.RelatedAltBISJobNumbers, RelatedAltBISJobNumbers);
                //crmTrace.AppendLine("Retrieve RelatedAltBISJobNumbers:" + RelatedAltBISJobNumbers);

                crmTrace.AppendLine("Retrieve RelatedDOBJobNumbers");
                RelatedDOBJobNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.RelatedDOBJobNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedDOBJobNumbers).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.RelatedDOBJobNumbers, RelatedDOBJobNumbers);
                crmTrace.AppendLine("Retrieve RelatedDOBJobNumbers:" + RelatedDOBJobNumbers);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SpecialDistricts))
                {
                    crmTrace.AppendLine("Retrieve SpecialDistricts");
                    SpecialDistricts = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.SpecialDistricts).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.SpecialDistricts, SpecialDistricts);
                    crmTrace.AppendLine("Retrieve SpecialDistricts:" + SpecialDistricts);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.StructuralStabilityAffected))
                {
                    crmTrace.AppendLine("Retrieve StructuralStabilityAffected");
                    StructuralStabilityAffected = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.StructuralStabilityAffected);
                    imageValues.Add(JobFilingEntityAttributeName.StructuralStabilityAffected, StructuralStabilityAffected);
                    crmTrace.AppendLine("Retrieve StructuralStabilityAffected:" + StructuralStabilityAffected);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.WorkIncludesPartialDemolition))
                {
                    crmTrace.AppendLine("Retrieve WorkIncludesPartialDemolition");
                    WorkIncludesPartialDemolition = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.WorkIncludesPartialDemolition);
                    imageValues.Add(JobFilingEntityAttributeName.WorkIncludesPartialDemolition, WorkIncludesPartialDemolition);
                    crmTrace.AppendLine("Retrieve WorkIncludesPartialDemolition:" + WorkIncludesPartialDemolition);
                }

                /// Bug 5044: Fix

                crmTrace.AppendLine("Retrieve CRFNNumber1");
                CRFNNumber1 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber1)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber1).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNNumber1, CRFNNumber1);
                crmTrace.AppendLine("Retrieve CRFNNumber1:" + CRFNNumber1);

                crmTrace.AppendLine("Retrieve CRFNNumber2");
                CRFNNumber2 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber2)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber2).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNNumber2, CRFNNumber2);
                crmTrace.AppendLine("Retrieve CRFNNumber2:" + CRFNNumber2);

                crmTrace.AppendLine("Retrieve CRFNNumber3");
                CRFNNumber3 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber3)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber3).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNNumber3, CRFNNumber3);
                crmTrace.AppendLine("Retrieve CRFNNumber3:" + CRFNNumber3);

                crmTrace.AppendLine("Retrieve CRFNNumber4");
                CRFNNumber4 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber4)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber4).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNNumber4, CRFNNumber4);
                crmTrace.AppendLine("Retrieve CRFNNumber4:" + CRFNNumber4);

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber1");
                CRFNZoningExhibitNumber1 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1, CRFNZoningExhibitNumber1);
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber1:" + CRFNZoningExhibitNumber1);

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber2");
                CRFNZoningExhibitNumber2 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2, CRFNZoningExhibitNumber2);
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber2:" + CRFNZoningExhibitNumber2);

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber3");
                CRFNZoningExhibitNumber3 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3, CRFNZoningExhibitNumber3);
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber3:" + CRFNZoningExhibitNumber3);

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber4");
                CRFNZoningExhibitNumber4 = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4, CRFNZoningExhibitNumber4);
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber4:" + CRFNZoningExhibitNumber4);

                //Bug 4622 - Fix
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsTidalWastelands");
                    SiteCharacteristicsTidalWastelands = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands, SiteCharacteristicsTidalWastelands);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsTidalWastelands:" + SiteCharacteristicsTidalWastelands);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsCoastalErosionHazardArea");
                    SiteCharacteristicsCoastalErosionHazardArea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, SiteCharacteristicsCoastalErosionHazardArea);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsCoastalErosionHazardArea:" + SiteCharacteristicsCoastalErosionHazardArea);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFireDistrict");
                    SiteCharacteristicsFireDistrict = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict, SiteCharacteristicsFireDistrict);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFireDistrict:" + SiteCharacteristicsFireDistrict);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFreshwaterWetlands");
                    SiteCharacteristicsFreshwaterWetlands = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, SiteCharacteristicsFreshwaterWetlands);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFreshwaterWetlands:" + SiteCharacteristicsFreshwaterWetlands);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsUrbanRenewal");
                    SiteCharacteristicsUrbanRenewal = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal, SiteCharacteristicsUrbanRenewal);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsUrbanRenewal:" + SiteCharacteristicsUrbanRenewal);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea))
                {
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFloodHazardArea");
                    SiteCharacteristicsFloodHazardArea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, SiteCharacteristicsFloodHazardArea);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFloodHazardArea:" + SiteCharacteristicsFloodHazardArea);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged))
                {
                    crmTrace.AppendLine("Retrieve IsFloodHzAreaSubstantiallyDamaged");
                    IsFloodHzAreaSubstantiallyDamaged = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged);
                    imageValues.Add(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged, IsFloodHzAreaSubstantiallyDamaged);
                    crmTrace.AppendLine("Retrieve IsFloodHzAreaSubstantiallyDamaged:" + IsFloodHzAreaSubstantiallyDamaged);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement))
                {
                    crmTrace.AppendLine("Retrieve FloodHzAreaIsSubstantialImprovement");
                    FloodHzAreaIsSubstantialImprovement = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement);
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement, FloodHzAreaIsSubstantialImprovement);
                    crmTrace.AppendLine("Retrieve FloodHzAreaIsSubstantialImprovement:" + FloodHzAreaIsSubstantialImprovement);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork))
                {
                    crmTrace.AppendLine("Retrieve FloodHzAreaFloodShieldsProposedWork");
                    FloodHzAreaFloodShieldsProposedWork = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork);
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork, FloodHzAreaFloodShieldsProposedWork);
                    crmTrace.AppendLine("Retrieve FloodHzAreaFloodShieldsProposedWork:" + FloodHzAreaFloodShieldsProposedWork);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AsbestosAbatementCompliance))
                {
                    crmTrace.AppendLine("Retrieve AsbestosAbatementCompliance");
                    AsbestosAbatementCompliance = preImage.FormattedValues[JobFilingEntityAttributeName.AsbestosAbatementCompliance];
                    imageValues.Add(JobFilingEntityAttributeName.AsbestosAbatementCompliance, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve AsbestosAbatementCompliance:" + AsbestosAbatementCompliance);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.InvestigatorCertificateNumber))
                {
                    crmTrace.AppendLine("Retrieve InvestigatorCertificateNumber ");
                    InvestigatorCertificateNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.InvestigatorCertificateNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.InvestigatorCertificateNumber, InvestigatorCertificateNumber);
                    crmTrace.AppendLine("Retrieve InvestigatorCertificateNumber :" + InvestigatorCertificateNumber);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Depacp20acp21asbestos))
                {
                    crmTrace.AppendLine("Retrieve Depacp20acp21asbestos  ");
                    Depacp20acp21asbestos = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Depacp20acp21asbestos);
                    imageValues.Add(JobFilingEntityAttributeName.Depacp20acp21asbestos, Depacp20acp21asbestos);
                    crmTrace.AppendLine("Retrieve Depacp20acp21asbestos :" + Depacp20acp21asbestos);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Depvariancev5letter))
                {
                    crmTrace.AppendLine("Retrieve Depvariancev5letter ");
                    Depvariancev5letter = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Depvariancev5letter);
                    imageValues.Add(JobFilingEntityAttributeName.Depvariancev5letter, Depvariancev5letter);
                    crmTrace.AppendLine("Retrieve Depvariancev5letter:" + Depvariancev5letter);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CommentsPWAttributeName))
                {
                    crmTrace.AppendLine("Retrieve CommentsPWAttributeName");
                    CommentsPWAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CommentsPWAttributeName).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve CommentsPWAttributeName:" + CommentsPWAttributeName);
                }
                if (!preImage.Attributes.Contains(JobFilingEntityAttributeName.CommentsPWAttributeName)) //since comments is optional on PW1.if they add in corrections
                {
                    crmTrace.AppendLine("Retrieve CommentsPWAttributeName");
                    //CommentsPWAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CommentsPWAttributeName).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve CommentsPWAttributeName:" + CommentsPWAttributeName);
                }

                crmTrace.AppendLine("Retrieve OccupancyClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OccupancyClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.OccupancyClassification);
                    if (reqLookUp != null)
                    {
                        OccupancyClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.OccupancyClassification, OccupancyClassification);
                    }
                    crmTrace.AppendLine("Retrieve OccupancyClassification:" + OccupancyClassification);
                }

                crmTrace.AppendLine("Retrieve ConstructionClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ConstructionClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ConstructionClassification);
                    if (reqLookUp != null)
                    {
                        ConstructionClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.ConstructionClassification, ConstructionClassification);
                    }
                    crmTrace.AppendLine("Retrieve ConstructionClassification:" + ConstructionClassification);
                }

                crmTrace.AppendLine("Retrieve MultipleDwellingClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MultipleDwellingClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.MultipleDwellingClassification);
                    if (reqLookUp != null)
                    {
                        MultipleDwellingClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.MultipleDwellingClassification, MultipleDwellingClassification);
                    }
                    crmTrace.AppendLine("Retrieve MultipleDwellingClassification:" + MultipleDwellingClassification);
                }

                crmTrace.AppendLine("Retrieve CRFNRestrictiveDeclaration value");
                CRFNRestrictiveDeclaration = (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration)) ? SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CRFNRestrictiveDeclaration) : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration, CRFNRestrictiveDeclaration);
                crmTrace.AppendLine("Retrieve CRFNRestrictiveDeclaration value:" + CRFNRestrictiveDeclaration);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FacadeAlternation))
                {
                    crmTrace.AppendLine("Retrieve FacadeAlternation");
                    FacadeAlternation = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FacadeAlternation);
                    imageValues.Add(JobFilingEntityAttributeName.FacadeAlternation, FacadeAlternation);
                    crmTrace.AppendLine("Retrieve FacadeAlternation:" + FacadeAlternation);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AdultEstablishment))
                {
                    crmTrace.AppendLine("Retrieve AdultEstablishment");
                    AdultEstablishment = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AdultEstablishment);
                    imageValues.Add(JobFilingEntityAttributeName.AdultEstablishment, AdultEstablishment);
                    crmTrace.AppendLine("Retrieve AdultEstablishment:" + AdultEstablishment);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.QualityHousing))
                {
                    crmTrace.AppendLine("Retrieve QualityHousing");
                    QualityHousing = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.QualityHousing);
                    imageValues.Add(JobFilingEntityAttributeName.QualityHousing, QualityHousing);
                    crmTrace.AppendLine("Retrieve QualityHousing:" + QualityHousing);
                }

                crmTrace.AppendLine("Retrieve ComplyingToLocalLaws");
                ComplyingToLocalLaws = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ComplyingToLocalLaws)) ? SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ComplyingToLocalLaws) : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ComplyingToLocalLaws, ComplyingToLocalLaws);
                crmTrace.AppendLine("Retrieve ComplyingToLocalLaws:" + ComplyingToLocalLaws);

                crmTrace.AppendLine("Retrieve ListOfLawNumbers");
                ListOfLawNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ListOfLawNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ListOfLawNumbers).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ListOfLawNumbers, ListOfLawNumbers);
                crmTrace.AppendLine("Retrieve ListOfLawNumbers:" + ListOfLawNumbers);

                crmTrace.AppendLine("Retrieve IsFilingtoAddressViolations");
                IsFilingtoAddressViolations = (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsFilingtoAddressViolations)) ? SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsFilingtoAddressViolations) : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.IsFilingtoAddressViolations, IsFilingtoAddressViolations);
                crmTrace.AppendLine("Retrieve IsFilingtoAddressViolations:" + IsFilingtoAddressViolations);

                crmTrace.AppendLine("Retrieve ListViolationsDOBECB");
                ListViolationsDOBECB = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ListViolationsDOBECB)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ListViolationsDOBECB).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ListViolationsDOBECB, ListViolationsDOBECB);
                crmTrace.AppendLine("Retrieve ListViolationsDOBECB:" + ListViolationsDOBECB);

                crmTrace.AppendLine("Retrieve ECBNumbers");
                ECBNumbers = (preImage.Attributes.Contains(JobFilingEntityAttributeName.ECBNumbers)) ? preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ECBNumbers).ToString() : string.Empty;
                imageValues.Add(JobFilingEntityAttributeName.ECBNumbers, ECBNumbers);
                crmTrace.AppendLine("Retrieve ECBNumbers:" + ECBNumbers);

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    IsConjunctionJob = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsConjunctionJob);
                    imageValues.Add(JobFilingEntityAttributeName.IsConjunctionJob, IsConjunctionJob);
                    crmTrace.AppendLine("Retrieve IsConjunctionJob:" + IsConjunctionJob);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BisRelatedJobNumber))
                {
                    crmTrace.AppendLine("Retrieve BisRelatedJobNumber");
                    BisRelatedJobNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.BisRelatedJobNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.BisRelatedJobNumber, BisRelatedJobNumber);
                    crmTrace.AppendLine("Retrieve BisRelatedJobNumber:" + BisRelatedJobNumber);
                }

                //Antenna & Curb Cut - End


                #region FAB4 PW1 Change set
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.constructionMaterial))
                {
                    crmTrace.AppendLine("Retrieve constructionMaterial");
                    CommentsPWAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.constructionMaterial).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.constructionMaterial, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve constructionMaterial:" + CommentsPWAttributeName);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SizeoftheShed))
                {
                    crmTrace.AppendLine("Retrieve SizeoftheShed");
                    CommentsPWAttributeName = preImage.GetAttributeValue<decimal>(JobFilingEntityAttributeName.SizeoftheShed).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.SizeoftheShed, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve SizeoftheShed:" + CommentsPWAttributeName);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber))
                {
                    crmTrace.AppendLine("Retrieve BSAMEAOTCRApprovalNumber");
                    CommentsPWAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve BSAMEAOTCRApprovalNumber:" + CommentsPWAttributeName);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.fenceConstructionMaterial))
                {
                    crmTrace.AppendLine("Retrieve fenceConstructionMaterial");
                    AsbestosAbatementCompliance = preImage.FormattedValues[JobFilingEntityAttributeName.fenceConstructionMaterial];
                    imageValues.Add(JobFilingEntityAttributeName.fenceConstructionMaterial, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve fenceConstructionMaterial:" + AsbestosAbatementCompliance);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence))
                {
                    crmTrace.AppendLine("Retrieve ConstructionFence");
                    AsbestosAbatementCompliance = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ConstructionFence);

                    imageValues.Add(JobFilingEntityAttributeName.ConstructionFence, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve ConstructionFence:" + AsbestosAbatementCompliance);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe))
                {
                    crmTrace.AppendLine("Retrieve FireProtectionEquipmentExistingStandPipe");
                    AsbestosAbatementCompliance = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe);

                    imageValues.Add(JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve FireProtectionEquipmentExistingStandPipe:" + AsbestosAbatementCompliance);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe))
                {
                    crmTrace.AppendLine("Retrieve FireProtectionEquipmentProposedStandPipe");
                    AsbestosAbatementCompliance = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe);

                    imageValues.Add(JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve FireProtectionEquipmentProposedStandPipe:" + AsbestosAbatementCompliance);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                {
                    crmTrace.AppendLine("Retrieve SupportedScaffold");
                    AsbestosAbatementCompliance = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SupportedScaffold);

                    imageValues.Add(JobFilingEntityAttributeName.SupportedScaffold, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve SupportedScaffold:" + AsbestosAbatementCompliance);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed))
                {
                    crmTrace.AppendLine("Retrieve SidewalkShed");
                    AsbestosAbatementCompliance = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SidewalkShed);

                    imageValues.Add(JobFilingEntityAttributeName.SidewalkShed, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve SidewalkShed:" + AsbestosAbatementCompliance);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.LandmarkFee))
                {
                    crmTrace.AppendLine("Retrieve LandmarkFee");
                    Money jobcost = preImage.GetAttributeValue<Money>(JobFilingEntityAttributeName.LandmarkFee);
                    EstimatedJobCostLegal = jobcost.Value.ToString("C2", CultureInfo.CurrentCulture);
                    imageValues.Add(JobFilingEntityAttributeName.LandmarkFee, EstimatedJobCostLegal);
                    crmTrace.AppendLine("Retrieve LandmarkFee:" + EstimatedJobCostLegal);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.heightFt))
                {
                    crmTrace.AppendLine("Retrieve heightFt");
                    ProposedDwellingUnits = preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.heightFt).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.heightFt, ProposedDwellingUnits);
                    crmTrace.AppendLine("Retrieve heightFt:" + ProposedDwellingUnits);
                }
                crmTrace.AppendLine("Retrieve FilingRepresentativeAttributeName");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.FilingRepresentativeAttributeName);
                    if (reqLookUp != null)
                    {
                        ConstructionClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.FilingRepresentativeAttributeName, ConstructionClassification);
                    }
                    crmTrace.AppendLine("Retrieve FilingRepresentativeAttributeName:" + ConstructionClassification);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName))
                {
                    crmTrace.AppendLine("Retrieve TotalConstructionAreaLegalizationAttributeName");
                    ProposedDwellingUnits = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName);
                    imageValues.Add(JobFilingEntityAttributeName.TotalConstructionAreaLegalizationAttributeName, ProposedDwellingUnits);
                    crmTrace.AppendLine("Retrieve TotalConstructionAreaLegalizationAttributeName:" + ProposedDwellingUnits);
                }
                #endregion

                #region ST Fields
                //Added by SN on 11/19/2018 when new fields added
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving))
                {
                    crmTrace.AppendLine("Retrieve MSWorkIncludesRaisingorMoving");
                    MSWorkIncludesRaisingorMoving = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving);
                    imageValues.Add(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving, MSWorkIncludesRaisingorMoving);
                    crmTrace.AppendLine("Retrieve MSWorkIncludesRaisingorMoving:" + MSWorkIncludesRaisingorMoving);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnInterior))
                {
                    crmTrace.AppendLine("Retrieve STWorkOnInterior");
                    STWorkOnInterior = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STWorkOnInterior);
                    imageValues.Add(JobFilingEntityAttributeName.STWorkOnInterior, STWorkOnInterior);
                    crmTrace.AppendLine("Retrieve STWorkOnInterior:" + STWorkOnInterior);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnExterior))
                {
                    crmTrace.AppendLine("Retrieve STWorkOnExterior");
                    STWorkOnExterior = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STWorkOnExterior);
                    imageValues.Add(JobFilingEntityAttributeName.STWorkOnExterior, STWorkOnExterior);
                    crmTrace.AppendLine("Retrieve STWorkOnExterior:" + STWorkOnExterior);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STRemovingOneOrMoreStories))
                {
                    crmTrace.AppendLine("Retrieve STRemovingOneOrMoreStories");
                    STRemovingOneOrMoreStories = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STRemovingOneOrMoreStories);
                    imageValues.Add(JobFilingEntityAttributeName.STRemovingOneOrMoreStories, STRemovingOneOrMoreStories);
                    crmTrace.AppendLine("Retrieve STRemovingOneOrMoreStories:" + STRemovingOneOrMoreStories);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STDemolishing50OrMore))
                {
                    crmTrace.AppendLine("Retrieve STDemolishing50OrMore");
                    STDemolishing50OrMore = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STDemolishing50OrMore);
                    imageValues.Add(JobFilingEntityAttributeName.STDemolishing50OrMore, STDemolishing50OrMore);
                    crmTrace.AppendLine("Retrieve STDemolishing50OrMore:" + STDemolishing50OrMore);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR))
                {
                    crmTrace.AppendLine("Retrieve STAlternativeMaterialsOTCR");
                    STAlternativeMaterialsOTCR = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STAlternativeMaterialsOTCR);
                    imageValues.Add(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR, STAlternativeMaterialsOTCR);
                    crmTrace.AppendLine("Retrieve STAlternativeMaterialsOTCR:" + STAlternativeMaterialsOTCR);
                }

                #endregion

                #region Missing Fields

                crmTrace.AppendLine("Retrieve BuildingsDesign");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BuildingsDesign))
                {
                    BuildingsDesign = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.BuildingsDesign);
                    imageValues.Add(JobFilingEntityAttributeName.BuildingsDesign, BuildingsDesign);
                    crmTrace.AppendLine("Retrieve BuildingsDesign:" + BuildingsDesign);
                }

                crmTrace.AppendLine("Retrieve Sowrequirethestandpipeservice");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Sowrequirethestandpipeservice))
                {
                    Sowrequirethestandpipeservice = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Sowrequirethestandpipeservice);
                    imageValues.Add(JobFilingEntityAttributeName.Sowrequirethestandpipeservice, Sowrequirethestandpipeservice);
                    crmTrace.AppendLine("Retrieve Sowrequirethestandpipeservice:" + Sowrequirethestandpipeservice);
                }

                crmTrace.AppendLine("Retrieve Sowinvolvemorethan5contiguousfloors");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors))
                {
                    Sowinvolvemorethan5contiguousfloors = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors);
                    imageValues.Add(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors, Sowinvolvemorethan5contiguousfloors);
                    crmTrace.AppendLine("Retrieve Sowinvolvemorethan5contiguousfloors:" + Sowinvolvemorethan5contiguousfloors);
                }

                crmTrace.AppendLine("Retrieve PLworkimpactthewatersupply");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.PLworkimpactthewatersupply))
                {
                    PLworkimpactthewatersupply = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.PLworkimpactthewatersupply);
                    imageValues.Add(JobFilingEntityAttributeName.PLworkimpactthewatersupply, PLworkimpactthewatersupply);
                    crmTrace.AppendLine("Retrieve PLworkimpactthewatersupply:" + PLworkimpactthewatersupply);
                }

                crmTrace.AppendLine("Retrieve Thesiteofthebuildingtobealteredordemolished4thcheckbox");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox))
                {
                    Thesiteofthebuildingtobealteredordemolished4thcheckbox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox);
                    imageValues.Add(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox, Thesiteofthebuildingtobealteredordemolished4thcheckbox);
                    crmTrace.AppendLine("Retrieve Thesiteofthebuildingtobealteredordemolished4thcheckbox:" + Thesiteofthebuildingtobealteredordemolished4thcheckbox);
                }

                crmTrace.AppendLine("Retrieve AThesiteofthebuildingtobealteredordemolished");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished))
                {
                    AThesiteofthebuildingtobealteredordemolished = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished);
                    imageValues.Add(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished, AThesiteofthebuildingtobealteredordemolished);
                    crmTrace.AppendLine("Retrieve AThesiteofthebuildingtobealteredordemolished:" + AThesiteofthebuildingtobealteredordemolished);
                }

                crmTrace.AppendLine("Retrieve BNotifiedtheNYCHomes");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BNotifiedtheNYCHomes))
                {
                    BNotifiedtheNYCHomes = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.BNotifiedtheNYCHomes);
                    imageValues.Add(JobFilingEntityAttributeName.BNotifiedtheNYCHomes, BNotifiedtheNYCHomes);
                    crmTrace.AppendLine("Retrieve BNotifiedtheNYCHomes:" + BNotifiedtheNYCHomes);
                }

                crmTrace.AppendLine("Retrieve ProvideDateNYSHCRNotified");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified);
                    if (dateTime != DateTime.MinValue)
                    {
                        ProvideDateNYSHCRNotified = dateTime.ToString();
                        imageValues.Add(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified, ProvideDateNYSHCRNotified);
                    }
                    crmTrace.AppendLine("Retrieve ProvideDateNYSHCRNotified:" + ProvideDateNYSHCRNotified);
                }

                crmTrace.AppendLine("Retrieve Structuredesignbase");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Structuredesignbase))
                {
                    Structuredesignbase = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Structuredesignbase);
                    imageValues.Add(JobFilingEntityAttributeName.Structuredesignbase, Structuredesignbase);
                    crmTrace.AppendLine("Retrieve Structuredesignbase:" + Structuredesignbase);
                }

                crmTrace.AppendLine("Retrieve DwellingUnits");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.DwellingUnits))
                {
                    DwellingUnits = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.DwellingUnits);
                    imageValues.Add(JobFilingEntityAttributeName.DwellingUnits, DwellingUnits);
                    crmTrace.AppendLine("Retrieve DwellingUnits:" + DwellingUnits);
                }

                crmTrace.AppendLine("Retrieve WorkonFloorsAttributeName");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.WorkonFloorsAttributeName))
                {
                    WorkonFloorsAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.WorkonFloorsAttributeName);
                    imageValues.Add(JobFilingEntityAttributeName.WorkonFloorsAttributeName, WorkonFloorsAttributeName);
                    crmTrace.AppendLine("Retrieve WorkonFloorsAttributeName:" + WorkonFloorsAttributeName);
                }

                crmTrace.AppendLine("Retrieve DEPACPControlNoAttributeName");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.DEPACPControlNoAttributeName))
                {
                    DEPACPControlNoAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.DEPACPControlNoAttributeName);
                    imageValues.Add(JobFilingEntityAttributeName.DEPACPControlNoAttributeName, DEPACPControlNoAttributeName);
                    crmTrace.AppendLine("Retrieve DEPACPControlNoAttributeName:" + DEPACPControlNoAttributeName);
                }

                crmTrace.AppendLine("Retrieve SROMultiple");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SROMultiple))
                {
                    SROMultiple = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.SROMultiple);
                    imageValues.Add(JobFilingEntityAttributeName.SROMultiple, SROMultiple);
                    crmTrace.AppendLine("Retrieve SROMultiple:" + SROMultiple);
                }

                crmTrace.AppendLine("Retrieve LoftBoard");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.LoftBoard))
                {
                    LoftBoard = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.LoftBoard);
                    imageValues.Add(JobFilingEntityAttributeName.LoftBoard, LoftBoard);
                    crmTrace.AppendLine("Retrieve LoftBoard:" + LoftBoard);
                }

                crmTrace.AppendLine("Retrieve SiteSafetyJob");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteSafetyJob))
                {
                    SiteSafetyJob = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteSafetyJob);
                    imageValues.Add(JobFilingEntityAttributeName.SiteSafetyJob, SiteSafetyJob);
                    crmTrace.AppendLine("Retrieve SiteSafetyJob:" + SiteSafetyJob);
                }

                crmTrace.AppendLine("Retrieve IncludedinLMCC");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IncludedinLMCC))
                {
                    IncludedinLMCC = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IncludedinLMCC);
                    imageValues.Add(JobFilingEntityAttributeName.IncludedinLMCC, IncludedinLMCC);
                    crmTrace.AppendLine("Retrieve IncludedinLMCC:" + IncludedinLMCC);
                }

                crmTrace.AppendLine("Retrieve describeOther");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.describeOther))
                {
                    describeOther = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.describeOther);
                    imageValues.Add(JobFilingEntityAttributeName.describeOther, describeOther);
                    crmTrace.AppendLine("Retrieve describeOther:" + describeOther);
                }


                crmTrace.AppendLine("Retrieve HeatingSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.HeatingSystem))
                {
                    HeatingSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.HeatingSystem);
                    imageValues.Add(JobFilingEntityAttributeName.HeatingSystem, HeatingSystem);
                    crmTrace.AppendLine("Retrieve HeatingSystem:" + HeatingSystem);
                }

                crmTrace.AppendLine("Retrieve VentilationSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.VentilationSystem))
                {
                    VentilationSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.VentilationSystem);
                    imageValues.Add(JobFilingEntityAttributeName.VentilationSystem, VentilationSystem);
                    crmTrace.AppendLine("Retrieve VentilationSystem:" + VentilationSystem);
                }

                crmTrace.AppendLine("Retrieve AirConditioningSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AirConditioningSystem))
                {
                    AirConditioningSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AirConditioningSystem);
                    imageValues.Add(JobFilingEntityAttributeName.AirConditioningSystem, AirConditioningSystem);
                    crmTrace.AppendLine("Retrieve AirConditioningSystem:" + AirConditioningSystem);
                }

                crmTrace.AppendLine("Retrieve Refrigeration");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Refrigeration))
                {
                    Refrigeration = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Refrigeration);
                    imageValues.Add(JobFilingEntityAttributeName.Refrigeration, Refrigeration);
                    crmTrace.AppendLine("Retrieve Refrigeration:" + Refrigeration);
                }

                crmTrace.AppendLine("Retrieve CoolingTowers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CoolingTowers))
                {
                    CoolingTowers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CoolingTowers);
                    imageValues.Add(JobFilingEntityAttributeName.CoolingTowers, CoolingTowers);
                    crmTrace.AppendLine("Retrieve CoolingTowers:" + CoolingTowers);
                }

                crmTrace.AppendLine("Retrieve AssociatedDuctsAndPiping");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AssociatedDuctsAndPiping))
                {
                    AssociatedDuctsAndPiping = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AssociatedDuctsAndPiping);
                    imageValues.Add(JobFilingEntityAttributeName.AssociatedDuctsAndPiping, AssociatedDuctsAndPiping);
                    crmTrace.AppendLine("Retrieve AssociatedDuctsAndPiping:" + AssociatedDuctsAndPiping);
                }

                crmTrace.AppendLine("Retrieve Generator");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Generator))
                {
                    Generator = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Generator);
                    imageValues.Add(JobFilingEntityAttributeName.Generator, Generator);
                    crmTrace.AppendLine("Retrieve Generator:" + Generator);
                }

                crmTrace.AppendLine("Retrieve Other");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Other))
                {
                    Other = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Other);
                    imageValues.Add(JobFilingEntityAttributeName.Other, Other);
                    crmTrace.AppendLine("Retrieve Other:" + Other);
                }

                crmTrace.AppendLine("Retrieve OtherValues");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OtherValues))
                {
                    OtherValues = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.OtherValues);
                    imageValues.Add(JobFilingEntityAttributeName.OtherValues, OtherValues);
                    crmTrace.AppendLine("Retrieve OtherValues:" + OtherValues);
                }

                #endregion

                return imageValues;
            }
            #endregion

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - PW1ImageValues1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }


        }

        #endregion
        #region Get Values from Entity ScopeOfWork

        public static Dictionary<string, string> ScopeOfWorkImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Get Pre Image values for ScopeOfWork Section
            #region Variable Declaration
            string System = string.Empty;
            string WorkTypeCategory = string.Empty;
            string WorkType = string.Empty;
            string FilingScope = string.Empty;
            string Description = string.Empty;
            string UnitLocation = string.Empty;
            string TypeofUnit = string.Empty;
            string TotalInputCapacity = string.Empty;
            string BackFlowPreventerType = string.Empty; //optionset
            string BackFlowPreventerrpzFloor = string.Empty;// string
            string EquipmentType = string.Empty;//optionset
            string BoilerType = string.Empty;//optionset
            string FuelGasType = string.Empty;//optionset
            string FuelGasUse = string.Empty;//optionset
            string PrivateDrainageType = string.Empty;//optionset
            string PrivateDrainageLocation = string.Empty; // string
            string CookingGasUse = string.Empty;  //optionset
            string MetersNumber = string.Empty;  // string
            string MetersLocatedAt = string.Empty; // string
            string EquipmentandAlarms = string.Empty;  //optionset
            string TotalInputCapacityinBTUH = string.Empty; // string
            string NumberofUnits = string.Empty; //whole number
            string Floor = string.Empty; // string
            string NumberofUnitsCogenSystems = string.Empty; //whole number
            string FDNYUtilityApprovals = string.Empty; //optionset
            string FloorCoGEnSystems = string.Empty;  //string
            string FuelGasTypeCogenSystems = string.Empty; //optionset
            string FuelGasUseCogenSystems = string.Empty;  //optionset
            string MedicalOtherGas = string.Empty; //optionset
            string MedicalOtherGasLocatedat = string.Empty;  //string
            string PrivateStorm = string.Empty; //optionset
            string DryWellWorkType = string.Empty;//optionset
            string StormSystems = string.Empty; //optionset
            string StormSystemsLocatedat = string.Empty; //string
            string PoolType = string.Empty;//optionset
            string Describe = string.Empty;// multiple string
            string SprinklerSystem = string.Empty;//optionset
            string HazardType = string.Empty; //optionset
            string SystemType = string.Empty; //optionset
            string WaterMain = string.Empty;//optionset
            string FDC = string.Empty; //optionset
            string Tank = string.Empty;//optionset
            string TypeofPumps = string.Empty;//optionset
            string StandardSprinklerHead = string.Empty;// two options
            string ExtendedCoverageHead = string.Empty; // two options
            string WorkRequiresPenetrationofFireRated = string.Empty;//optionset
            string TypeofSprinklerSystem = string.Empty;//optionset
            string RiserControlValve = string.Empty;// two options
            string RiserSandBranches = string.Empty;// two options
            string BoosterPump = string.Empty;// two options
            string FirePump = string.Empty; // two options
            string DryPumpValve = string.Empty;// two options
            string SpecialServicePump = string.Empty;// two options
            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {


                crmTrace.AppendLine("Retrieve System");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.System))
                {
                    EntityReference systemLookUp = preImage.GetAttributeValue<EntityReference>(ScopeOfWorkEntityAttributeName.System);
                    if (systemLookUp != null)
                    {
                        System = systemLookUp.Name;
                        imageValues.Add(ScopeOfWorkEntityAttributeName.System, System);
                    }
                    crmTrace.AppendLine("Retrieve System:" + System);
                }


                crmTrace.AppendLine("Retrieve WorkTypeCategory");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkTypeCategory))
                {
                    WorkTypeCategory = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.WorkTypeCategory).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkTypeCategory, WorkTypeCategory);
                    crmTrace.AppendLine("Retrieve WorkTypeCategory:" + WorkTypeCategory);
                }
                crmTrace.AppendLine("Retrieve WorkType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkType))
                {
                    WorkType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.WorkType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkType, WorkType);
                    crmTrace.AppendLine("Retrieve WorkType:" + WorkType);
                }
                crmTrace.AppendLine("Retrieve FilingScope");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FilingScope))
                {
                    FilingScope = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FilingScope];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FilingScope, FilingScope);
                    crmTrace.AppendLine("Retrieve FilingScope:" + FilingScope);
                }
                crmTrace.AppendLine("Retrieve Description");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.Description))
                {
                    Description = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Description).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Description, Description);
                    crmTrace.AppendLine("Retrieve Description:" + Description);
                }
                crmTrace.AppendLine("Retrieve UnitLocation");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.UnitLocation))
                {
                    UnitLocation = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.UnitLocation).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.UnitLocation, UnitLocation);
                    crmTrace.AppendLine("Retrieve UnitLocation:" + UnitLocation);
                }
                crmTrace.AppendLine("Retrieve TypeofUnit");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofUnit))
                {
                    TypeofUnit = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TypeofUnit).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofUnit, TypeofUnit);
                    crmTrace.AppendLine("Retrieve TypeofUnit:" + TypeofUnit);
                }

                crmTrace.AppendLine("Retrieve TotalInputCapacity");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.TotalInputCapacity))
                {
                    TotalInputCapacity = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TotalInputCapacity).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacity, TotalInputCapacity);
                    crmTrace.AppendLine("Retrieve TotalInputCapacity:" + TotalInputCapacity);
                }

                crmTrace.AppendLine("Retrieve BackFlowPreventerType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.BackFlowPreventerType))
                {
                    BackFlowPreventerType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.BackFlowPreventerType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerType, BackFlowPreventerType);
                    crmTrace.AppendLine("Retrieve BackFlowPreventerType:" + BackFlowPreventerType);
                }
                crmTrace.AppendLine("Retrieve BackFlowPreventerrpzFloor");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor))
                {
                    BackFlowPreventerrpzFloor = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor, BackFlowPreventerrpzFloor);
                    crmTrace.AppendLine("Retrieve BackFlowPreventerrpzFloor:" + BackFlowPreventerrpzFloor);
                }
                crmTrace.AppendLine("Retrieve EquipmentType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.EquipmentType))
                {
                    EquipmentType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.EquipmentType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentType, EquipmentType);
                    crmTrace.AppendLine("Retrieve EquipmentType:" + EquipmentType);
                }
                crmTrace.AppendLine("Retrieve BoilerType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.BoilerType))
                {
                    BoilerType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.BoilerType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoilerType, BoilerType);
                    crmTrace.AppendLine("Retrieve BoilerType:" + BoilerType);
                }
                crmTrace.AppendLine("Retrieve FuelGasType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasType))
                {
                    FuelGasType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasType, FuelGasType);
                    crmTrace.AppendLine("Retrieve FuelGasType:" + FuelGasType);
                }
                crmTrace.AppendLine("Retrieve FuelGasUse");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasUse))
                {
                    FuelGasUse = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasUse];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUse, FuelGasUse);
                    crmTrace.AppendLine("Retrieve FuelGasUse:" + FuelGasUse);
                }
                crmTrace.AppendLine("Retrieve PrivateDrainageType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateDrainageType))
                {
                    PrivateDrainageType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.PrivateDrainageType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageType, PrivateDrainageType);
                    crmTrace.AppendLine("Retrieve PrivateDrainageType:" + PrivateDrainageType);
                }

                crmTrace.AppendLine("Retrieve PrivateDrainageLocation");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation))
                {
                    PrivateDrainageLocation = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation, PrivateDrainageLocation);
                    crmTrace.AppendLine("Retrieve PrivateDrainageLocation:" + PrivateDrainageLocation);
                }
                crmTrace.AppendLine("Retrieve CookingGasUse");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.CookingGasUse))
                {
                    CookingGasUse = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.CookingGasUse];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.CookingGasUse, CookingGasUse);
                    crmTrace.AppendLine("Retrieve CookingGasUse:" + CookingGasUse);
                }
                crmTrace.AppendLine("Retrieve MetersNumber");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.MetersNumber))
                {
                    MetersNumber = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MetersNumber).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersNumber, MetersNumber);
                    crmTrace.AppendLine("Retrieve MetersNumber:" + MetersNumber);
                }
                crmTrace.AppendLine("Retrieve MetersLocatedAt");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.MetersLocatedAt))
                {
                    MetersLocatedAt = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MetersLocatedAt).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersLocatedAt, MetersLocatedAt);
                    crmTrace.AppendLine("Retrieve MetersLocatedAt:" + MetersLocatedAt);
                }
                crmTrace.AppendLine("Retrieve EquipmentandAlarms");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.EquipmentandAlarms))
                {
                    EquipmentandAlarms = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.EquipmentandAlarms];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentandAlarms, EquipmentandAlarms);
                    crmTrace.AppendLine("Retrieve EquipmentandAlarms:" + EquipmentandAlarms);
                }

                crmTrace.AppendLine("Retrieve TotalInputCapacityinBTUH");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH))
                {
                    TotalInputCapacityinBTUH = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH, TotalInputCapacityinBTUH);
                    crmTrace.AppendLine("Retrieve TotalInputCapacityinBTUH:" + TotalInputCapacityinBTUH);
                }
                crmTrace.AppendLine("Retrieve NumberofUnits");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.NumberofUnits))
                {
                    NumberofUnits = preImage.GetAttributeValue<int>(ScopeOfWorkEntityAttributeName.NumberofUnits).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnits, NumberofUnits);
                    crmTrace.AppendLine("Retrieve NumberofUnits:" + NumberofUnits);
                }
                crmTrace.AppendLine("Retrieve Floor");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.Floor))
                {
                    Floor = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Floor).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Floor, Floor);
                    crmTrace.AppendLine("Retrieve Floor:" + Floor);
                }
                crmTrace.AppendLine("Retrieve NumberofUnitsCogenSystems");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems))
                {
                    NumberofUnitsCogenSystems = preImage.GetAttributeValue<int>(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems, NumberofUnits);
                    crmTrace.AppendLine("Retrieve NumberofUnitsCogenSystems:" + NumberofUnitsCogenSystems);
                }
                crmTrace.AppendLine("Retrieve FDNYUtilityApprovals");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals))
                {
                    FDNYUtilityApprovals = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals, FDNYUtilityApprovals);
                    crmTrace.AppendLine("Retrieve FDNYUtilityApprovals:" + FDNYUtilityApprovals);
                }
                crmTrace.AppendLine("Retrieve FloorCoGEnSystems");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems))
                {
                    FloorCoGEnSystems = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems, FloorCoGEnSystems);
                    crmTrace.AppendLine("Retrieve FloorCoGEnSystems:" + FloorCoGEnSystems);
                }

                crmTrace.AppendLine("Retrieve FuelGasTypeCogenSystems");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems))
                {
                    FuelGasTypeCogenSystems = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems, FuelGasTypeCogenSystems);
                    crmTrace.AppendLine("Retrieve FuelGasTypeCogenSystems:" + FuelGasTypeCogenSystems);
                }
                crmTrace.AppendLine("Retrieve FuelGasUseCogenSystems");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems))
                {
                    FuelGasUseCogenSystems = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems, FuelGasUseCogenSystems);
                    crmTrace.AppendLine("Retrieve FuelGasUseCogenSystems:" + FuelGasUseCogenSystems);
                }
                crmTrace.AppendLine("Retrieve MedicalOtherGas");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.MedicalOtherGas))
                {
                    MedicalOtherGas = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.MedicalOtherGas];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGas, MedicalOtherGas);
                    crmTrace.AppendLine("Retrieve MedicalOtherGas:" + MedicalOtherGas);
                }
                crmTrace.AppendLine("Retrieve MedicalOtherGasLocatedat");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat))
                {
                    MedicalOtherGasLocatedat = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat, MedicalOtherGasLocatedat);
                    crmTrace.AppendLine("Retrieve MedicalOtherGasLocatedat:" + MedicalOtherGasLocatedat);
                }
                crmTrace.AppendLine("Retrieve PrivateStorm");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateStorm))
                {
                    PrivateStorm = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.PrivateStorm];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateStorm, PrivateStorm);
                    crmTrace.AppendLine("Retrieve PrivateStorm:" + PrivateStorm);
                }
                crmTrace.AppendLine("Retrieve DryWellWorkType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.DryWellWorkType))
                {
                    DryWellWorkType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.DryWellWorkType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryWellWorkType, DryWellWorkType);
                    crmTrace.AppendLine("Retrieve DryWellWorkType:" + DryWellWorkType);
                }
                crmTrace.AppendLine("Retrieve StormSystems");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.StormSystems))
                {
                    StormSystems = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.StormSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystems, StormSystems);
                    crmTrace.AppendLine("Retrieve StormSystems:" + StormSystems);
                }
                crmTrace.AppendLine("Retrieve StormSystemsLocatedat");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat))
                {
                    StormSystemsLocatedat = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat, StormSystemsLocatedat);
                    crmTrace.AppendLine("Retrieve StormSystemsLocatedat:" + StormSystemsLocatedat);
                }
                crmTrace.AppendLine("Retrieve PoolType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.PoolType))
                {
                    PoolType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.PoolType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PoolType, PoolType);
                    crmTrace.AppendLine("Retrieve PoolType:" + PoolType);
                }
                crmTrace.AppendLine("Retrieve Describe");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.Describe))
                {
                    Describe = preImage.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Describe).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Describe, Describe);
                    crmTrace.AppendLine("Retrieve Describe:" + Describe);
                }
                crmTrace.AppendLine("Retrieve SprinklerSystem");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.SprinklerSystem))
                {
                    SprinklerSystem = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.SprinklerSystem];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SprinklerSystem, SprinklerSystem);
                    crmTrace.AppendLine("Retrieve SprinklerSystem:" + SprinklerSystem);
                }
                crmTrace.AppendLine("Retrieve HazardType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.HazardType))
                {
                    HazardType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.HazardType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.HazardType, HazardType);
                    crmTrace.AppendLine("Retrieve HazardType:" + HazardType);
                }
                crmTrace.AppendLine("Retrieve SystemType");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.SystemType))
                {
                    SystemType = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.SystemType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SystemType, SystemType);
                    crmTrace.AppendLine("Retrieve SystemType:" + SystemType);
                }
                crmTrace.AppendLine("Retrieve WaterMain");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.WaterMain))
                {
                    WaterMain = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.WaterMain];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WaterMain, WaterMain);
                    crmTrace.AppendLine("Retrieve WaterMain:" + WaterMain);
                }
                crmTrace.AppendLine("Retrieve FDC");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FDC))
                {
                    FDC = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.FDC];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDC, FDC);
                    crmTrace.AppendLine("Retrieve FDC:" + FDC);
                }
                crmTrace.AppendLine("Retrieve Tank");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.Tank))
                {
                    Tank = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.Tank];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Tank, Tank);
                    crmTrace.AppendLine("Retrieve Tank:" + Tank);
                }
                crmTrace.AppendLine("Retrieve TypeofPumps");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofPumps))
                {
                    TypeofPumps = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.TypeofPumps];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofPumps, TypeofPumps);
                    crmTrace.AppendLine("Retrieve TypeofPumps:" + TypeofPumps);
                }
                crmTrace.AppendLine("Retrieve StandardSprinklerHead");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.StandardSprinklerHead))
                {
                    StandardSprinklerHead = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.StandardSprinklerHead);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StandardSprinklerHead, StandardSprinklerHead);
                    crmTrace.AppendLine("Retrieve StandardSprinklerHead:" + StandardSprinklerHead);
                }
                crmTrace.AppendLine("Retrieve ExtendedCoverageHead");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.ExtendedCoverageHead))
                {
                    ExtendedCoverageHead = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.ExtendedCoverageHead);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.ExtendedCoverageHead, ExtendedCoverageHead);
                    crmTrace.AppendLine("Retrieve ExtendedCoverageHead:" + ExtendedCoverageHead);
                }
                crmTrace.AppendLine("Retrieve WorkRequiresPenetrationofFireRated");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated))
                {
                    WorkRequiresPenetrationofFireRated = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated, WorkRequiresPenetrationofFireRated);
                    crmTrace.AppendLine("Retrieve WorkRequiresPenetrationofFireRated:" + WorkRequiresPenetrationofFireRated);
                }
                crmTrace.AppendLine("Retrieve TypeofSprinklerSystem");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem))
                {
                    TypeofSprinklerSystem = preImage.FormattedValues[ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem, TypeofSprinklerSystem);
                    crmTrace.AppendLine("Retrieve TypeofSprinklerSystem:" + TypeofSprinklerSystem);
                }
                crmTrace.AppendLine("Retrieve RiserControlValve");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.RiserControlValve))
                {
                    RiserControlValve = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.RiserControlValve);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserControlValve, RiserControlValve);
                    crmTrace.AppendLine("Retrieve RiserControlValve:" + RiserControlValve);
                }
                crmTrace.AppendLine("Retrieve RiserSandBranches");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.RiserSandBranches))
                {
                    RiserSandBranches = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.RiserSandBranches);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserSandBranches, RiserSandBranches);
                    crmTrace.AppendLine("Retrieve RiserSandBranches:" + RiserSandBranches);
                }
                crmTrace.AppendLine("Retrieve BoosterPump");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.BoosterPump))
                {
                    BoosterPump = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.BoosterPump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoosterPump, BoosterPump);
                    crmTrace.AppendLine("Retrieve BoosterPump:" + BoosterPump);
                }
                crmTrace.AppendLine("Retrieve FirePump");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.FirePump))
                {
                    FirePump = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.FirePump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FirePump, FirePump);
                    crmTrace.AppendLine("Retrieve FirePump:" + FirePump);
                }

                crmTrace.AppendLine("Retrieve DryPumpValve");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.DryPumpValve))
                {
                    DryPumpValve = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.DryPumpValve);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryPumpValve, DryPumpValve);
                    crmTrace.AppendLine("Retrieve DryPumpValve:" + DryPumpValve);
                }
                crmTrace.AppendLine("Retrieve SpecialServicePump");
                if (preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.SpecialServicePump))
                {
                    SpecialServicePump = SetBooleanAttribute(preImage, ScopeOfWorkEntityAttributeName.SpecialServicePump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SpecialServicePump, SpecialServicePump);
                    crmTrace.AppendLine("Retrieve SpecialServicePump:" + SpecialServicePump);
                }

                return imageValues;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ScopeOfWorkImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            #endregion
        }
        #endregion
        #region Get Values from WorkCostDetails Entity
        public static Dictionary<string, string> SOWQuestionnaireImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string HeatingEquipment = string.Empty;
            string CoolingEquipment = string.Empty;
            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve HeatingEquipment");
                if (preImage.Attributes.Contains(ScopeofWorkQuestionnaire.HeatingEquipment))
                {
                    HeatingEquipment = preImage.GetAttributeValue<int>(ScopeofWorkQuestionnaire.HeatingEquipment).ToString();
                    imageValues.Add(ScopeofWorkQuestionnaire.HeatingEquipment, HeatingEquipment);
                    crmTrace.AppendLine("Retrieve SpecifyVolumeofWater:" + HeatingEquipment);
                }
                crmTrace.AppendLine("Retrieve CoolingEquipment");
                if (preImage.Attributes.Contains(ScopeofWorkQuestionnaire.CoolingEquipment))
                {
                    CoolingEquipment = preImage.GetAttributeValue<int>(ScopeofWorkQuestionnaire.CoolingEquipment).ToString();
                    imageValues.Add(ScopeofWorkQuestionnaire.CoolingEquipment, CoolingEquipment);
                    crmTrace.AppendLine("Retrieve WhatisthetotalNoofsprinklerheadsoffthedom:" + CoolingEquipment);
                }
                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SOWQuestionnaire", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }

        public static Dictionary<string, string> SOWCommonWorkTypeImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string EntityLogicalName = string.Empty;
            string SOWCommonWorkTypesEntityAttributeId = string.Empty;
            string EntityNameAttribute = string.Empty;
            string GoToJobFiling = string.Empty;
            string StormSewer = string.Empty;
            string CombinedSewer = string.Empty;
            string PrivateDisposal = string.Empty;
            string Isanewormodifiedstreetconnectionproposed = string.Empty;
            string Isanewsystemormodificationstotheprivated = string.Empty;
            string IsdetentionorretentionrequiredbytheDEP = string.Empty;
            string RoofDetention = string.Empty;
            string OpenSiteDetention = string.Empty;
            string DetentionTanks = string.Empty;
            string DrainageSump = string.Empty;
            string PrivateSewageTreatmentPlant = string.Empty;
            string DryWellRetention = string.Empty;
            string AreaYardDrain = string.Empty;
            string RoofDrain = string.Empty;
            string SumpPump = string.Empty;
            string DetentionTank = string.Empty;
            string ComponentsDryWellRetention = string.Empty;
            string Other = string.Empty;
            string GasPipingInvolved = string.Empty;
            string Individual = string.Empty;
            string Common = string.Empty;
            string NA = string.Empty;
            string CookingResidential = string.Empty;
            string CookingCommercial = string.Empty;
            string HotWater = string.Empty;
            string Heating = string.Empty;
            string Burner = string.Empty;
            string GeneratorCoGeneratorsProcessing = string.Empty;
            string LocationOtherGasAppliancesEquipment = string.Empty;
            string GasBoosterPump = string.Empty;
            string CookingEquipmentnonresidential = string.Empty;
            string CookingEquipmentresidential = string.Empty;
            string GasBoiler350Kfamily = string.Empty;
            string GasBurner = string.Empty;
            string GasBarbeque = string.Empty;
            string GasCombinationUnitHeatHWColl = string.Empty;
            string GasDryer = string.Empty;
            string GasFurnace = string.Empty;
            string GasWaterHeater = string.Empty;
            string NonGasWaterHeater = string.Empty;
            string EmergencyCoGeneratorMicroturbine = string.Empty;
            string EmergencyCoGeneratorEngine = string.Empty;
            string EmergencyCoGeneratorFuelcell = string.Empty;
            string GasOther = string.Empty;
            string SpecifyTypeofSprinklerSystem = string.Empty;
            string ChoosePrimaryWaterSystem = string.Empty;
            string NFPA13 = string.Empty;
            string NFPA13R = string.Empty;
            string NFPA13D = string.Empty;
            string MedicalGasPiping = string.Empty;
            string MedicalEquipment = string.Empty;
            string NonflammableMedicalGas = string.Empty;
            string NonmedicalOxygen = string.Empty;
            string Domestic = string.Empty;
            string DomesticwithSPtakeoff = string.Empty;
            string Sprinklerwithdomestictakeoff = string.Empty;
            string FireService = string.Empty;
            string Domesticwatertank = string.Empty;
            string WaterNA = string.Empty;
            string BackflowPreventerPrimary = string.Empty;
            string BackflowPreventerSecondary = string.Empty;
            string WaterHeaterNonGas = string.Empty;
            string PlumbingFixturesWater = string.Empty;
            string Pump = string.Empty;
            string WaterComponentsNA = string.Empty;
            string BoosterPump = string.Empty;
            string DomesticwaterpumpFillPump = string.Empty;
            string SpecifyVolumeofWater = string.Empty;
            string WhatisthetotalNoofsprinklerheadsoffthedom = string.Empty;
            string SpecifyDesignCriteria = string.Empty;
            string OperatingPressure = string.Empty;
            string PlumbingScopeOfWorkCategory = string.Empty;


            string Antifreeze = string.Empty;
            string CirculatingClosedLoop = string.Empty;
            string CombinedDryPipePreaction = string.Empty;
            string Deluge = string.Empty;
            string DryPipe = string.Empty;
            string Gridded = string.Empty;
            string Looped = string.Empty;
            string MultiCycle = string.Empty;
            string Preaction = string.Empty;
            string WetPipe = string.Empty;
            string DryOpenPipe = string.Empty;
            string IsaDryPipeValverequired = string.Empty;
            string IsthisaCombinedStandpipeSprinklerSystem = string.Empty;
            string SPSDNFPA13 = string.Empty;
            string SPSDNFPA13D = string.Empty;
            string SPSDNFPA13R = string.Empty;
            string SPSDNFPA20 = string.Empty;
            string SPSDBoosterPump = string.Empty;
            string SpecialServicePump = string.Empty;
            string JockeyPump = string.Empty;
            string StandpipeFirePump = string.Empty;
            string SPSDNA = string.Empty;
            string DryStandpipeSystem = string.Empty;
            string ManualSDsystem = string.Empty;
            string Semiautomatic = string.Empty;
            string WetSDsystemSpecify = string.Empty;
            string SPSDNFPA14 = string.Empty;
            string FirePump = string.Empty;

            string SpecifyClass = string.Empty;
            string SPSDChoosePrimaryWaterSystem = string.Empty;
            string SPSDChooseSecondaryWaterSystem = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                //Antifreeze
                crmTrace.AppendLine("Retrieve Antifreeze");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Antifreeze))
                {
                    crmTrace.AppendLine("Retrieve Antifreeze");
                    Antifreeze = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Antifreeze);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Antifreeze, Antifreeze);
                    crmTrace.AppendLine("Retrieve Antifreeze:" + Antifreeze);
                }
                //CirculatingClosedLoop
                crmTrace.AppendLine("Retrieve CirculatingClosedLoop");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CirculatingClosedLoop))
                {
                    crmTrace.AppendLine("Retrieve CirculatingClosedLoop");
                    CirculatingClosedLoop = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CirculatingClosedLoop);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CirculatingClosedLoop, CirculatingClosedLoop);
                    crmTrace.AppendLine("Retrieve CirculatingClosedLoop:" + CirculatingClosedLoop);
                }
                //CombinedDryPipePreaction
                crmTrace.AppendLine("Retrieve CombinedDryPipePreaction");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CombinedDryPipePreaction))
                {
                    crmTrace.AppendLine("Retrieve CombinedDryPipePreaction");
                    CombinedDryPipePreaction = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CombinedDryPipePreaction);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CombinedDryPipePreaction, CombinedDryPipePreaction);
                    crmTrace.AppendLine("Retrieve CombinedDryPipePreaction:" + CombinedDryPipePreaction);
                }
                //Deluge
                crmTrace.AppendLine("Retrieve Deluge");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Deluge))
                {
                    crmTrace.AppendLine("Retrieve Deluge");
                    Deluge = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Deluge);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Deluge, Deluge);
                    crmTrace.AppendLine("Retrieve Deluge:" + Deluge);
                }
                //DryPipe =string.Empty;
                crmTrace.AppendLine("Retrieve DryPipe");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DryPipe))
                {
                    crmTrace.AppendLine("Retrieve DryPipe");
                    DryPipe = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DryPipe);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DryPipe, DryPipe);
                    crmTrace.AppendLine("Retrieve DryPipe:" + DryPipe);
                }
                //Gridded
                crmTrace.AppendLine("Retrieve Gridded");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Gridded))
                {
                    crmTrace.AppendLine("Retrieve Gridded");
                    Gridded = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Gridded);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Gridded, Gridded);
                    crmTrace.AppendLine("Retrieve Gridded:" + Gridded);
                }
                //Looped
                crmTrace.AppendLine("Retrieve Looped");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Looped))
                {
                    crmTrace.AppendLine("Retrieve Looped");
                    Looped = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Looped);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Looped, Looped);
                    crmTrace.AppendLine("Retrieve Looped:" + Looped);
                }
                //MultiCycle
                crmTrace.AppendLine("Retrieve MultiCycle");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.MultiCycle))
                {
                    crmTrace.AppendLine("Retrieve MultiCycle");
                    MultiCycle = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.MultiCycle);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.MultiCycle, MultiCycle);
                    crmTrace.AppendLine("Retrieve MultiCycle:" + MultiCycle);
                }
                //Preaction
                crmTrace.AppendLine("Retrieve Preaction");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Preaction))
                {
                    crmTrace.AppendLine("Retrieve Preaction");
                    Preaction = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Preaction);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Preaction, Preaction);
                    crmTrace.AppendLine("Retrieve Preaction:" + Preaction);
                }
                //WetPipe
                crmTrace.AppendLine("Retrieve WetPipe");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WetPipe))
                {
                    crmTrace.AppendLine("Retrieve WetPipe");
                    WetPipe = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.WetPipe);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WetPipe, WetPipe);
                    crmTrace.AppendLine("Retrieve WetPipe:" + WetPipe);
                }
                //DryOpenPipe
                crmTrace.AppendLine("Retrieve DryOpenPipe");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DryOpenPipe))
                {
                    crmTrace.AppendLine("Retrieve DryOpenPipe");
                    DryOpenPipe = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DryOpenPipe);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DryOpenPipe, DryOpenPipe);
                    crmTrace.AppendLine("Retrieve DryOpenPipe:" + DryOpenPipe);
                }
                //IsaDryPipeValverequired
                crmTrace.AppendLine("Retrieve IsaDryPipeValverequired");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.IsaDryPipeValverequired))
                {
                    crmTrace.AppendLine("Retrieve IsaDryPipeValverequired");
                    IsaDryPipeValverequired = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.IsaDryPipeValverequired);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.IsaDryPipeValverequired, IsaDryPipeValverequired);
                    crmTrace.AppendLine("Retrieve IsaDryPipeValverequired:" + IsaDryPipeValverequired);
                }
                //IsthisaCombinedStandpipeSprinklerSystem
                crmTrace.AppendLine("Retrieve IsthisaCombinedStandpipeSprinklerSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.IsthisaCombinedStandpipeSprinklerSystem))
                {
                    crmTrace.AppendLine("Retrieve IsthisaCombinedStandpipeSprinklerSystem");
                    IsthisaCombinedStandpipeSprinklerSystem = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.IsthisaCombinedStandpipeSprinklerSystem);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.IsthisaCombinedStandpipeSprinklerSystem, IsthisaCombinedStandpipeSprinklerSystem);
                    crmTrace.AppendLine("Retrieve IsthisaCombinedStandpipeSprinklerSystem:" + IsthisaCombinedStandpipeSprinklerSystem);
                }
                //SPSDNFPA13
                crmTrace.AppendLine("Retrieve SPSDNFPA13");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13))
                {
                    crmTrace.AppendLine("Retrieve SPSDNFPA13");
                    SPSDNFPA13 = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNFPA13);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13, SPSDNFPA13);
                    crmTrace.AppendLine("Retrieve SPSDNFPA13:" + SPSDNFPA13);
                }
                //SPSDNFPA13D
                crmTrace.AppendLine("Retrieve SPSDNFPA13D");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13D))
                {
                    crmTrace.AppendLine("Retrieve SPSDNFPA13D");
                    SPSDNFPA13D = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNFPA13D);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13D, SPSDNFPA13D);
                    crmTrace.AppendLine("Retrieve SPSDNFPA13D:" + SPSDNFPA13D);
                }
                //SPSDNFPA13R
                crmTrace.AppendLine("Retrieve SPSDNFPA13R");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13R))
                {
                    crmTrace.AppendLine("Retrieve SPSDNFPA13R");
                    SPSDNFPA13R = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNFPA13R);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNFPA13R, SPSDNFPA13R);
                    crmTrace.AppendLine("Retrieve SPSDNFPA13R:" + SPSDNFPA13R);
                }
                //SPSDNFPA20
                crmTrace.AppendLine("Retrieve SPSDNFPA20");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNFPA20))
                {
                    crmTrace.AppendLine("Retrieve SPSDNFPA20");
                    SPSDNFPA20 = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNFPA20);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNFPA20, SPSDNFPA20);
                    crmTrace.AppendLine("Retrieve SPSDNFPA20:" + SPSDNFPA20);
                }
                //SPSDBoosterPump
                crmTrace.AppendLine("Retrieve SPSDBoosterPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDBoosterPump))
                {
                    crmTrace.AppendLine("Retrieve SPSDBoosterPump");
                    SPSDBoosterPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDBoosterPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDBoosterPump, SPSDBoosterPump);
                    crmTrace.AppendLine("Retrieve SPSDBoosterPump:" + SPSDBoosterPump);
                }
                //SpecialServicePump
                crmTrace.AppendLine("Retrieve SpecialServicePump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SpecialServicePump))
                {
                    crmTrace.AppendLine("Retrieve SpecialServicePump");
                    SpecialServicePump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SpecialServicePump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SpecialServicePump, SpecialServicePump);
                    crmTrace.AppendLine("Retrieve SpecialServicePump:" + SpecialServicePump);
                }
                //JockeyPump
                crmTrace.AppendLine("Retrieve JockeyPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.JockeyPump))
                {
                    crmTrace.AppendLine("Retrieve JockeyPump");
                    JockeyPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.JockeyPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.JockeyPump, JockeyPump);
                    crmTrace.AppendLine("Retrieve JockeyPump:" + JockeyPump);
                }
                //StandpipeFirePump
                crmTrace.AppendLine("Retrieve StandpipeFirePump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.StandpipeFirePump))
                {
                    crmTrace.AppendLine("Retrieve StandpipeFirePump");
                    StandpipeFirePump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.StandpipeFirePump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.StandpipeFirePump, StandpipeFirePump);
                    crmTrace.AppendLine("Retrieve StandpipeFirePump:" + StandpipeFirePump);
                }
                //SPSDNA = "dobnyc_spsd_na";
                crmTrace.AppendLine("Retrieve SPSDNA");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNA))
                {
                    crmTrace.AppendLine("Retrieve SPSDNA");
                    SPSDNA = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNA);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNA, SPSDNA);
                    crmTrace.AppendLine("Retrieve SPSDNA:" + SPSDNA);
                }
                //DryStandpipeSystem
                crmTrace.AppendLine("Retrieve DryStandpipeSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DryStandpipeSystem))
                {
                    crmTrace.AppendLine("Retrieve DryStandpipeSystem");
                    DryStandpipeSystem = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DryStandpipeSystem);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DryStandpipeSystem, DryStandpipeSystem);
                    crmTrace.AppendLine("Retrieve DryStandpipeSystem:" + DryStandpipeSystem);
                }
                //ManualSDsystem
                crmTrace.AppendLine("Retrieve ManualSDsystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.ManualSDsystem))
                {
                    crmTrace.AppendLine("Retrieve ManualSDsystem");
                    ManualSDsystem = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.ManualSDsystem);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.ManualSDsystem, ManualSDsystem);
                    crmTrace.AppendLine("Retrieve ManualSDsystem:" + ManualSDsystem);
                }
                //Semiautomatic
                crmTrace.AppendLine("Retrieve Semiautomatic");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Semiautomatic))
                {
                    crmTrace.AppendLine("Retrieve Semiautomatic");
                    Semiautomatic = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Semiautomatic);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Semiautomatic, Semiautomatic);
                    crmTrace.AppendLine("Retrieve Semiautomatic:" + Semiautomatic);
                }
                //WetSDsystemSpecify
                crmTrace.AppendLine("Retrieve WetSDsystemSpecify");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WetSDsystemSpecify))
                {
                    crmTrace.AppendLine("Retrieve WetSDsystemSpecify");
                    WetSDsystemSpecify = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.WetSDsystemSpecify);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WetSDsystemSpecify, WetSDsystemSpecify);
                    crmTrace.AppendLine("Retrieve WetSDsystemSpecify:" + WetSDsystemSpecify);
                }
                //SPSDNFPA14 =string.Empty;
                crmTrace.AppendLine("Retrieve SPSDNFPA14");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDNFPA14))
                {
                    crmTrace.AppendLine("Retrieve SPSDNFPA14");
                    SPSDNFPA14 = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SPSDNFPA14);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDNFPA14, SPSDNFPA14);
                    crmTrace.AppendLine("Retrieve SPSDNFPA14:" + SPSDNFPA14);
                }
                //FirePump
                crmTrace.AppendLine("Retrieve FirePump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.FirePump))
                {
                    crmTrace.AppendLine("Retrieve FirePump");
                    FirePump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.FirePump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.FirePump, FirePump);
                    crmTrace.AppendLine("Retrieve FirePump:" + FirePump);
                }


                //
                crmTrace.AppendLine("Retrieve StormSewer");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.StormSewer))
                {
                    crmTrace.AppendLine("Retrieve StormSewer");
                    StormSewer = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.StormSewer);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.StormSewer, StormSewer);
                    crmTrace.AppendLine("Retrieve StormSewer:" + StormSewer);
                }
                crmTrace.AppendLine("Retrieve CombinedSewer");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CombinedSewer))
                {
                    crmTrace.AppendLine("Retrieve CombinedSewer");
                    CombinedSewer = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CombinedSewer);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CombinedSewer, CombinedSewer);
                    crmTrace.AppendLine("Retrieve CombinedSewer:" + CombinedSewer);
                }
                crmTrace.AppendLine("Retrieve PrivateDisposal");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.PrivateDisposal))
                {
                    crmTrace.AppendLine("Retrieve PrivateDisposal");
                    PrivateDisposal = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.PrivateDisposal);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.PrivateDisposal, PrivateDisposal);
                    crmTrace.AppendLine("Retrieve PrivateDisposal:" + PrivateDisposal);
                }
                crmTrace.AppendLine("Retrieve Isanewormodifiedstreetconnectionproposed");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Isanewormodifiedstreetconnectionproposed))
                {
                    crmTrace.AppendLine("Retrieve Isanewormodifiedstreetconnectionproposed");
                    Isanewormodifiedstreetconnectionproposed = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Isanewormodifiedstreetconnectionproposed);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Isanewormodifiedstreetconnectionproposed, Isanewormodifiedstreetconnectionproposed);
                    crmTrace.AppendLine("Retrieve Isanewormodifiedstreetconnectionproposed:" + Isanewormodifiedstreetconnectionproposed);
                }
                crmTrace.AppendLine("Retrieve Isanewsystemormodificationstotheprivated");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Isanewsystemormodificationstotheprivated))
                {
                    crmTrace.AppendLine("Retrieve Isanewsystemormodificationstotheprivated");
                    Isanewsystemormodificationstotheprivated = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Isanewsystemormodificationstotheprivated);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Isanewsystemormodificationstotheprivated, Isanewsystemormodificationstotheprivated);
                    crmTrace.AppendLine("Retrieve Isanewsystemormodificationstotheprivated:" + Isanewsystemormodificationstotheprivated);
                }
                crmTrace.AppendLine("Retrieve IsdetentionorretentionrequiredbytheDEP");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.IsdetentionorretentionrequiredbytheDEP))
                {
                    crmTrace.AppendLine("Retrieve IsdetentionorretentionrequiredbytheDEP");
                    IsdetentionorretentionrequiredbytheDEP = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.IsdetentionorretentionrequiredbytheDEP);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.IsdetentionorretentionrequiredbytheDEP, IsdetentionorretentionrequiredbytheDEP);
                    crmTrace.AppendLine("Retrieve IsdetentionorretentionrequiredbytheDEP:" + IsdetentionorretentionrequiredbytheDEP);
                }
                crmTrace.AppendLine("Retrieve RoofDetention");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.RoofDetention))
                {
                    crmTrace.AppendLine("Retrieve RoofDetention");
                    RoofDetention = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.RoofDetention);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.RoofDetention, RoofDetention);
                    crmTrace.AppendLine("Retrieve RoofDetention:" + RoofDetention);
                }
                crmTrace.AppendLine("Retrieve OpenSiteDetention");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.OpenSiteDetention))
                {
                    crmTrace.AppendLine("Retrieve OpenSiteDetention");
                    OpenSiteDetention = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.OpenSiteDetention);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.OpenSiteDetention, OpenSiteDetention);
                    crmTrace.AppendLine("Retrieve OpenSiteDetention:" + OpenSiteDetention);
                }
                crmTrace.AppendLine("Retrieve DetentionTanks");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DetentionTanks))
                {
                    crmTrace.AppendLine("Retrieve DetentionTanks");
                    DetentionTanks = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DetentionTanks);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DetentionTanks, DetentionTanks);
                    crmTrace.AppendLine("Retrieve DetentionTanks:" + DetentionTanks);
                }
                crmTrace.AppendLine("Retrieve DrainageSump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DrainageSump))
                {
                    crmTrace.AppendLine("Retrieve DrainageSump");
                    DrainageSump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DrainageSump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DrainageSump, DrainageSump);
                    crmTrace.AppendLine("Retrieve DrainageSump:" + DrainageSump);
                }
                crmTrace.AppendLine("Retrieve PrivateSewageTreatmentPlant");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.PrivateSewageTreatmentPlant))
                {
                    crmTrace.AppendLine("Retrieve PrivateSewageTreatmentPlant");
                    PrivateSewageTreatmentPlant = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.PrivateSewageTreatmentPlant);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.PrivateSewageTreatmentPlant, PrivateSewageTreatmentPlant);
                    crmTrace.AppendLine("Retrieve PrivateSewageTreatmentPlant:" + PrivateSewageTreatmentPlant);
                }
                crmTrace.AppendLine("Retrieve DryWellRetention");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DryWellRetention))
                {
                    crmTrace.AppendLine("Retrieve DryWellRetention");
                    DryWellRetention = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DryWellRetention);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DryWellRetention, DryWellRetention);
                    crmTrace.AppendLine("Retrieve DryWellRetention:" + DryWellRetention);
                }
                crmTrace.AppendLine("Retrieve AreaYardDrain");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.AreaYardDrain))
                {
                    crmTrace.AppendLine("Retrieve AreaYardDrain");
                    AreaYardDrain = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.AreaYardDrain);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.AreaYardDrain, AreaYardDrain);
                    crmTrace.AppendLine("Retrieve AreaYardDrain:" + AreaYardDrain);
                }
                crmTrace.AppendLine("Retrieve RoofDrain");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.RoofDrain))
                {
                    crmTrace.AppendLine("Retrieve RoofDrain");
                    RoofDrain = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.RoofDrain);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.RoofDrain, RoofDrain);
                    crmTrace.AppendLine("Retrieve RoofDrain:" + RoofDrain);
                }
                crmTrace.AppendLine("Retrieve SumpPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SumpPump))
                {
                    crmTrace.AppendLine("Retrieve SumpPump");
                    SumpPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SumpPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SumpPump, SumpPump);
                    crmTrace.AppendLine("Retrieve SumpPump:" + SumpPump);
                }
                crmTrace.AppendLine("Retrieve DetentionTank");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DetentionTank))
                {
                    crmTrace.AppendLine("Retrieve DetentionTank");
                    DetentionTank = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DetentionTank);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DetentionTank, DetentionTank);
                    crmTrace.AppendLine("Retrieve DetentionTank:" + DetentionTank);
                }
                crmTrace.AppendLine("Retrieve ComponentsDryWellRetention");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.ComponentsDryWellRetention))
                {
                    crmTrace.AppendLine("Retrieve ComponentsDryWellRetention");
                    ComponentsDryWellRetention = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.ComponentsDryWellRetention);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.ComponentsDryWellRetention, ComponentsDryWellRetention);
                    crmTrace.AppendLine("Retrieve ComponentsDryWellRetention:" + ComponentsDryWellRetention);
                }
                crmTrace.AppendLine("Retrieve Other");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Other))
                {
                    crmTrace.AppendLine("Retrieve Other");
                    Other = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Other);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Other, Other);
                    crmTrace.AppendLine("Retrieve Other:" + Other);
                }
                crmTrace.AppendLine("Retrieve GasPipingInvolved");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasPipingInvolved))
                {
                    crmTrace.AppendLine("Retrieve GasPipingInvolved");
                    GasPipingInvolved = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasPipingInvolved);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasPipingInvolved, GasPipingInvolved);
                    crmTrace.AppendLine("Retrieve GasPipingInvolved:" + GasPipingInvolved);
                }
                crmTrace.AppendLine("Retrieve Individual");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Individual))
                {
                    crmTrace.AppendLine("Retrieve Individual");
                    Individual = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Individual);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Individual, Individual);
                    crmTrace.AppendLine("Retrieve Individual:" + Individual);
                }
                crmTrace.AppendLine("Retrieve Common");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Common))
                {
                    crmTrace.AppendLine("Retrieve Common");
                    Common = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Common);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Common, Common);
                    crmTrace.AppendLine("Retrieve Common:" + Common);
                }
                crmTrace.AppendLine("Retrieve NA");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NA))
                {
                    crmTrace.AppendLine("Retrieve NA");
                    NA = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NA);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NA, NA);
                    crmTrace.AppendLine("Retrieve NA:" + NA);
                }
                crmTrace.AppendLine("Retrieve CookingResidential");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CookingResidential))
                {
                    crmTrace.AppendLine("Retrieve CookingResidential");
                    CookingResidential = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CookingResidential);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CookingResidential, CookingResidential);
                    crmTrace.AppendLine("Retrieve CookingResidential:" + CookingResidential);
                }
                crmTrace.AppendLine("Retrieve CookingCommercial");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CookingCommercial))
                {
                    crmTrace.AppendLine("Retrieve CookingCommercial");
                    CookingCommercial = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CookingCommercial);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CookingCommercial, CookingCommercial);
                    crmTrace.AppendLine("Retrieve CookingCommercial:" + CookingCommercial);
                }
                crmTrace.AppendLine("Retrieve HotWater");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.HotWater))
                {
                    crmTrace.AppendLine("Retrieve HotWater");
                    HotWater = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.HotWater);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.HotWater, HotWater);
                    crmTrace.AppendLine("Retrieve HotWater:" + HotWater);
                }
                crmTrace.AppendLine("Retrieve Heating");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Heating))
                {
                    crmTrace.AppendLine("Retrieve Heating");
                    Heating = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Heating);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Heating, Heating);
                    crmTrace.AppendLine("Retrieve Heating:" + Heating);
                }
                crmTrace.AppendLine("Retrieve Burner");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Burner))
                {
                    crmTrace.AppendLine("Retrieve Burner");
                    Burner = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Burner);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Burner, Burner);
                    crmTrace.AppendLine("Retrieve Burner:" + Burner);
                }
                crmTrace.AppendLine("Retrieve GeneratorCoGeneratorsProcessing");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GeneratorCoGeneratorsProcessing))
                {
                    crmTrace.AppendLine("Retrieve GeneratorCoGeneratorsProcessing");
                    GeneratorCoGeneratorsProcessing = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GeneratorCoGeneratorsProcessing);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GeneratorCoGeneratorsProcessing, GeneratorCoGeneratorsProcessing);
                    crmTrace.AppendLine("Retrieve GeneratorCoGeneratorsProcessing:" + GeneratorCoGeneratorsProcessing);
                }
                crmTrace.AppendLine("Retrieve LocationOtherGasAppliancesEquipment");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.LocationOtherGasAppliancesEquipment))
                {
                    crmTrace.AppendLine("Retrieve LocationOtherGasAppliancesEquipment");
                    LocationOtherGasAppliancesEquipment = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.LocationOtherGasAppliancesEquipment);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.LocationOtherGasAppliancesEquipment, LocationOtherGasAppliancesEquipment);
                    crmTrace.AppendLine("Retrieve LocationOtherGasAppliancesEquipment:" + LocationOtherGasAppliancesEquipment);
                }
                crmTrace.AppendLine("Retrieve GasBoosterPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasBoosterPump))
                {
                    crmTrace.AppendLine("Retrieve GasBoosterPump");
                    GasBoosterPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasBoosterPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasBoosterPump, GasBoosterPump);
                    crmTrace.AppendLine("Retrieve GasBoosterPump:" + GasBoosterPump);
                }
                crmTrace.AppendLine("Retrieve CookingEquipmentnonresidential");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CookingEquipmentnonresidential))
                {
                    crmTrace.AppendLine("Retrieve CookingEquipmentnonresidential");
                    CookingEquipmentnonresidential = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CookingEquipmentnonresidential);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CookingEquipmentnonresidential, CookingEquipmentnonresidential);
                    crmTrace.AppendLine("Retrieve CookingEquipmentnonresidential:" + CookingEquipmentnonresidential);
                }
                crmTrace.AppendLine("Retrieve CookingEquipmentresidential");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.CookingEquipmentresidential))
                {
                    crmTrace.AppendLine("Retrieve CookingEquipmentresidential");
                    CookingEquipmentresidential = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.CookingEquipmentresidential);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.CookingEquipmentresidential, CookingEquipmentresidential);
                    crmTrace.AppendLine("Retrieve CookingEquipmentresidential:" + CookingEquipmentresidential);
                }
                crmTrace.AppendLine("Retrieve GasBoiler350Kfamily");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasBoiler350Kfamily))
                {
                    crmTrace.AppendLine("Retrieve GasBoiler350Kfamily");
                    GasBoiler350Kfamily = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasBoiler350Kfamily);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasBoiler350Kfamily, GasBoiler350Kfamily);
                    crmTrace.AppendLine("Retrieve GasBoiler350Kfamily:" + GasBoiler350Kfamily);
                }
                crmTrace.AppendLine("Retrieve GasBurner");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasBurner))
                {
                    crmTrace.AppendLine("Retrieve GasBurner");
                    GasBurner = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasBurner);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasBurner, GasBurner);
                    crmTrace.AppendLine("Retrieve GasBurner:" + GasBurner);
                }
                crmTrace.AppendLine("Retrieve GasBarbeque");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasBarbeque))
                {
                    crmTrace.AppendLine("Retrieve GasBarbeque");
                    GasBarbeque = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasBarbeque);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasBarbeque, GasBarbeque);
                    crmTrace.AppendLine("Retrieve GasBarbeque:" + GasBarbeque);
                }
                crmTrace.AppendLine("Retrieve GasCombinationUnitHeatHWColl");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasCombinationUnitHeatHWColl))
                {
                    crmTrace.AppendLine("Retrieve GasCombinationUnitHeatHWColl");
                    GasCombinationUnitHeatHWColl = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasCombinationUnitHeatHWColl);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasCombinationUnitHeatHWColl, GasCombinationUnitHeatHWColl);
                    crmTrace.AppendLine("Retrieve GasCombinationUnitHeatHWColl:" + GasCombinationUnitHeatHWColl);
                }
                crmTrace.AppendLine("Retrieve GasDryer");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasDryer))
                {
                    crmTrace.AppendLine("Retrieve GasDryer");
                    GasDryer = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasDryer);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasDryer, GasDryer);
                    crmTrace.AppendLine("Retrieve GasDryer:" + GasDryer);
                }
                crmTrace.AppendLine("Retrieve GasFurnace");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasFurnace))
                {
                    crmTrace.AppendLine("Retrieve GasFurnace");
                    GasFurnace = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasFurnace);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasFurnace, GasFurnace);
                    crmTrace.AppendLine("Retrieve GasFurnace:" + GasFurnace);
                }
                crmTrace.AppendLine("Retrieve GasWaterHeater");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasWaterHeater))
                {
                    crmTrace.AppendLine("Retrieve GasWaterHeater");
                    GasWaterHeater = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasWaterHeater);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasWaterHeater, GasWaterHeater);
                    crmTrace.AppendLine("Retrieve GasWaterHeater:" + GasWaterHeater);
                }
                crmTrace.AppendLine("Retrieve NonGasWaterHeater");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NonGasWaterHeater))
                {
                    crmTrace.AppendLine("Retrieve NonGasWaterHeater");
                    NonGasWaterHeater = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NonGasWaterHeater);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NonGasWaterHeater, NonGasWaterHeater);
                    crmTrace.AppendLine("Retrieve NonGasWaterHeater:" + NonGasWaterHeater);
                }
                crmTrace.AppendLine("Retrieve EmergencyCoGeneratorMicroturbine");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorMicroturbine))
                {
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorMicroturbine");
                    EmergencyCoGeneratorMicroturbine = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorMicroturbine);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorMicroturbine, EmergencyCoGeneratorMicroturbine);
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorMicroturbine:" + EmergencyCoGeneratorMicroturbine);
                }
                crmTrace.AppendLine("Retrieve EmergencyCoGeneratorEngine");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorEngine))
                {
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorEngine");
                    EmergencyCoGeneratorEngine = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorEngine);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorEngine, EmergencyCoGeneratorEngine);
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorEngine:" + EmergencyCoGeneratorEngine);
                }
                crmTrace.AppendLine("Retrieve EmergencyCoGeneratorFuelcell");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorFuelcell))
                {
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorFuelcell");
                    EmergencyCoGeneratorFuelcell = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorFuelcell);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.EmergencyCoGeneratorFuelcell, EmergencyCoGeneratorFuelcell);
                    crmTrace.AppendLine("Retrieve EmergencyCoGeneratorFuelcell:" + EmergencyCoGeneratorFuelcell);
                }
                crmTrace.AppendLine("Retrieve GasOther");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.GasOther))
                {
                    crmTrace.AppendLine("Retrieve GasOther");
                    GasOther = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.GasOther);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.GasOther, GasOther);
                    crmTrace.AppendLine("Retrieve GasOther:" + GasOther);
                }
                crmTrace.AppendLine("Retrieve SpecifyTypeofSprinklerSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SpecifyTypeofSprinklerSystem))
                {
                    crmTrace.AppendLine("Retrieve SpecifyTypeofSprinklerSystem");
                    SpecifyTypeofSprinklerSystem = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.SpecifyTypeofSprinklerSystem);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SpecifyTypeofSprinklerSystem, SpecifyTypeofSprinklerSystem);
                    crmTrace.AppendLine("Retrieve SpecifyTypeofSprinklerSystem:" + SpecifyTypeofSprinklerSystem);
                }
                crmTrace.AppendLine("Retrieve ChoosePrimaryWaterSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.ChoosePrimaryWaterSystem))
                {
                    crmTrace.AppendLine("Retrieve ChoosePrimaryWaterSystem");
                    ChoosePrimaryWaterSystem = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.ChoosePrimaryWaterSystem);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.ChoosePrimaryWaterSystem, ChoosePrimaryWaterSystem);
                    crmTrace.AppendLine("Retrieve ChoosePrimaryWaterSystem:" + ChoosePrimaryWaterSystem);
                }
                crmTrace.AppendLine("Retrieve NFPA13");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NFPA13))
                {
                    crmTrace.AppendLine("Retrieve NFPA13");
                    NFPA13 = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NFPA13);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NFPA13, NFPA13);
                    crmTrace.AppendLine("Retrieve NFPA13:" + NFPA13);
                }
                crmTrace.AppendLine("Retrieve NFPA13R");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NFPA13R))
                {
                    crmTrace.AppendLine("Retrieve NFPA13R");
                    NFPA13R = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NFPA13R);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NFPA13R, NFPA13R);
                    crmTrace.AppendLine("Retrieve NFPA13R:" + NFPA13R);
                }
                crmTrace.AppendLine("Retrieve NFPA13D");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NFPA13D))
                {
                    crmTrace.AppendLine("Retrieve NFPA13D");
                    NFPA13D = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NFPA13D);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NFPA13D, NFPA13D);
                    crmTrace.AppendLine("Retrieve NFPA13D:" + NFPA13D);
                }
                crmTrace.AppendLine("Retrieve MedicalGasPiping");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.MedicalGasPiping))
                {
                    crmTrace.AppendLine("Retrieve MedicalGasPiping");
                    MedicalGasPiping = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.MedicalGasPiping);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.MedicalGasPiping, MedicalGasPiping);
                    crmTrace.AppendLine("Retrieve MedicalGasPiping:" + MedicalGasPiping);
                }
                crmTrace.AppendLine("Retrieve MedicalEquipment");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.MedicalEquipment))
                {
                    crmTrace.AppendLine("Retrieve MedicalEquipment");
                    MedicalEquipment = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.MedicalEquipment);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.MedicalEquipment, MedicalEquipment);
                    crmTrace.AppendLine("Retrieve MedicalEquipment:" + MedicalEquipment);
                }
                crmTrace.AppendLine("Retrieve NonflammableMedicalGas");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NonflammableMedicalGas))
                {
                    crmTrace.AppendLine("Retrieve NonflammableMedicalGas");
                    NonflammableMedicalGas = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NonflammableMedicalGas);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NonflammableMedicalGas, NonflammableMedicalGas);
                    crmTrace.AppendLine("Retrieve NonflammableMedicalGas:" + NonflammableMedicalGas);
                }
                crmTrace.AppendLine("Retrieve NonmedicalOxygen");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.NonmedicalOxygen))
                {
                    crmTrace.AppendLine("Retrieve NonmedicalOxygen");
                    NonmedicalOxygen = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.NonmedicalOxygen);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.NonmedicalOxygen, NonmedicalOxygen);
                    crmTrace.AppendLine("Retrieve NonmedicalOxygen:" + NonmedicalOxygen);
                }
                crmTrace.AppendLine("Retrieve Domestic");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Domestic))
                {
                    crmTrace.AppendLine("Retrieve Domestic");
                    Domestic = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Domestic);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Domestic, Domestic);
                    crmTrace.AppendLine("Retrieve Domestic:" + Domestic);
                }
                crmTrace.AppendLine("Retrieve DomesticwithSPtakeoff");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DomesticwithSPtakeoff))
                {
                    crmTrace.AppendLine("Retrieve DomesticwithSPtakeoff");
                    DomesticwithSPtakeoff = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DomesticwithSPtakeoff);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DomesticwithSPtakeoff, DomesticwithSPtakeoff);
                    crmTrace.AppendLine("Retrieve DomesticwithSPtakeoff:" + DomesticwithSPtakeoff);
                }
                crmTrace.AppendLine("Retrieve Sprinklerwithdomestictakeoff");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Sprinklerwithdomestictakeoff))
                {
                    crmTrace.AppendLine("Retrieve Sprinklerwithdomestictakeoff");
                    Sprinklerwithdomestictakeoff = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Sprinklerwithdomestictakeoff);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Sprinklerwithdomestictakeoff, Sprinklerwithdomestictakeoff);
                    crmTrace.AppendLine("Retrieve Sprinklerwithdomestictakeoff:" + Sprinklerwithdomestictakeoff);
                }
                crmTrace.AppendLine("Retrieve FireService");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.FireService))
                {
                    crmTrace.AppendLine("Retrieve FireService");
                    FireService = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.FireService);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.FireService, FireService);
                    crmTrace.AppendLine("Retrieve FireService:" + FireService);
                }
                crmTrace.AppendLine("Retrieve Domesticwatertank");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Domesticwatertank))
                {
                    crmTrace.AppendLine("Retrieve Domesticwatertank");
                    Domesticwatertank = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Domesticwatertank);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Domesticwatertank, Domesticwatertank);
                    crmTrace.AppendLine("Retrieve Domesticwatertank:" + Domesticwatertank);
                }
                crmTrace.AppendLine("Retrieve WaterNA");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WaterNA))
                {
                    crmTrace.AppendLine("Retrieve WaterNA");
                    WaterNA = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.WaterNA);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WaterNA, WaterNA);
                    crmTrace.AppendLine("Retrieve WaterNA:" + WaterNA);
                }
                crmTrace.AppendLine("Retrieve BackflowPreventerPrimary");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.BackflowPreventerPrimary))
                {
                    crmTrace.AppendLine("Retrieve BackflowPreventerPrimary");
                    BackflowPreventerPrimary = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.BackflowPreventerPrimary);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.BackflowPreventerPrimary, BackflowPreventerPrimary);
                    crmTrace.AppendLine("Retrieve BackflowPreventerPrimary:" + BackflowPreventerPrimary);
                }
                crmTrace.AppendLine("Retrieve BackflowPreventerSecondary");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.BackflowPreventerSecondary))
                {
                    crmTrace.AppendLine("Retrieve BackflowPreventerSecondary");
                    BackflowPreventerSecondary = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.BackflowPreventerSecondary);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.BackflowPreventerSecondary, BackflowPreventerSecondary);
                    crmTrace.AppendLine("Retrieve BackflowPreventerSecondary:" + BackflowPreventerSecondary);
                }
                crmTrace.AppendLine("Retrieve WaterHeaterNonGas");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WaterHeaterNonGas))
                {
                    crmTrace.AppendLine("Retrieve WaterHeaterNonGas");
                    WaterHeaterNonGas = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.WaterHeaterNonGas);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WaterHeaterNonGas, WaterHeaterNonGas);
                    crmTrace.AppendLine("Retrieve WaterHeaterNonGas:" + WaterHeaterNonGas);
                }
                crmTrace.AppendLine("Retrieve PlumbingFixturesWater");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.PlumbingFixturesWater))
                {
                    crmTrace.AppendLine("Retrieve PlumbingFixturesWater");
                    PlumbingFixturesWater = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.PlumbingFixturesWater);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.PlumbingFixturesWater, PlumbingFixturesWater);
                    crmTrace.AppendLine("Retrieve PlumbingFixturesWater:" + PlumbingFixturesWater);
                }
                crmTrace.AppendLine("Retrieve Pump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.Pump))
                {
                    crmTrace.AppendLine("Retrieve Pump");
                    Pump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.Pump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.Pump, Pump);
                    crmTrace.AppendLine("Retrieve Pump:" + Pump);
                }
                crmTrace.AppendLine("Retrieve WaterComponentsNA");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WaterComponentsNA))
                {
                    crmTrace.AppendLine("Retrieve WaterComponentsNA");
                    WaterComponentsNA = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.WaterComponentsNA);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WaterComponentsNA, WaterComponentsNA);
                    crmTrace.AppendLine("Retrieve WaterComponentsNA:" + WaterComponentsNA);
                }
                crmTrace.AppendLine("Retrieve BoosterPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.BoosterPump))
                {
                    crmTrace.AppendLine("Retrieve BoosterPump");
                    BoosterPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.BoosterPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.BoosterPump, BoosterPump);
                    crmTrace.AppendLine("Retrieve BoosterPump:" + BoosterPump);
                }
                crmTrace.AppendLine("Retrieve BoosterPump");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.DomesticwaterpumpFillPump))
                {
                    crmTrace.AppendLine("Retrieve DomesticwaterpumpFillPump");
                    DomesticwaterpumpFillPump = SetBooleanAttribute(preImage, SOWCommonWorkTypesEntityAttribute.DomesticwaterpumpFillPump);
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.DomesticwaterpumpFillPump, DomesticwaterpumpFillPump);
                    crmTrace.AppendLine("Retrieve DomesticwaterpumpFillPump:" + DomesticwaterpumpFillPump);
                }





                crmTrace.AppendLine("Retrieve SpecifyVolumeofWater");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SpecifyVolumeofWater))
                {
                    SpecifyVolumeofWater = preImage.GetAttributeValue<int>(SOWCommonWorkTypesEntityAttribute.SpecifyVolumeofWater).ToString();
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SpecifyVolumeofWater, SpecifyVolumeofWater);
                    crmTrace.AppendLine("Retrieve SpecifyVolumeofWater:" + SpecifyVolumeofWater);
                }
                crmTrace.AppendLine("Retrieve WhatisthetotalNoofsprinklerheadsoffthedom");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.WhatisthetotalNoofsprinklerheadsoffthedom))
                {
                    WhatisthetotalNoofsprinklerheadsoffthedom = preImage.GetAttributeValue<int>(SOWCommonWorkTypesEntityAttribute.WhatisthetotalNoofsprinklerheadsoffthedom).ToString();
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.WhatisthetotalNoofsprinklerheadsoffthedom, WhatisthetotalNoofsprinklerheadsoffthedom);
                    crmTrace.AppendLine("Retrieve WhatisthetotalNoofsprinklerheadsoffthedom:" + WhatisthetotalNoofsprinklerheadsoffthedom);
                }
                crmTrace.AppendLine("Retrieve SpecifyDesignCriteria");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SpecifyDesignCriteria))
                {
                    SpecifyDesignCriteria = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.SpecifyDesignCriteria];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SpecifyDesignCriteria, SpecifyDesignCriteria);
                    crmTrace.AppendLine("Retrieve SpecifyDesignCriteria:" + SpecifyDesignCriteria);
                }
                crmTrace.AppendLine("Retrieve OperatingPressure");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.OperatingPressure))
                {
                    OperatingPressure = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.OperatingPressure];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.OperatingPressure, OperatingPressure);
                    crmTrace.AppendLine("Retrieve OperatingPressure:" + OperatingPressure);
                }
                crmTrace.AppendLine("Retrieve PlumbingScopeOfWorkCategory");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.PlumbingScopeOfWorkCategory))
                {
                    PlumbingScopeOfWorkCategory = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.PlumbingScopeOfWorkCategory];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.PlumbingScopeOfWorkCategory, PlumbingScopeOfWorkCategory);
                    crmTrace.AppendLine("Retrieve PlumbingScopeOfWorkCategory:" + PlumbingScopeOfWorkCategory);
                }



                crmTrace.AppendLine("Retrieve SpecifyClass");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SpecifyClass))
                {
                    SpecifyClass = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.SpecifyClass];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SpecifyClass, SpecifyClass);
                    crmTrace.AppendLine("Retrieve SpecifyClass:" + SpecifyClass);
                }
                crmTrace.AppendLine("Retrieve SPSDChoosePrimaryWaterSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDChoosePrimaryWaterSystem))
                {
                    SPSDChoosePrimaryWaterSystem = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.SPSDChoosePrimaryWaterSystem];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDChoosePrimaryWaterSystem, SPSDChoosePrimaryWaterSystem);
                    crmTrace.AppendLine("Retrieve SPSDChoosePrimaryWaterSystem:" + SPSDChoosePrimaryWaterSystem);
                }
                crmTrace.AppendLine("Retrieve SPSDChooseSecondaryWaterSystem");
                if (preImage.Attributes.Contains(SOWCommonWorkTypesEntityAttribute.SPSDChooseSecondaryWaterSystem))
                {
                    SPSDChooseSecondaryWaterSystem = preImage.FormattedValues[SOWCommonWorkTypesEntityAttribute.SPSDChooseSecondaryWaterSystem];
                    imageValues.Add(SOWCommonWorkTypesEntityAttribute.SPSDChooseSecondaryWaterSystem, SPSDChooseSecondaryWaterSystem);
                    crmTrace.AppendLine("Retrieve SPSDChooseSecondaryWaterSystem:" + SPSDChooseSecondaryWaterSystem);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }

        public static Dictionary<string, string> STSOWImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string Mechanical = string.Empty;
            string PartialDemolition = string.Empty;
            string Aluminum = string.Empty;
            string Concrete = string.Empty;
            string HandheldMechanical = string.Empty;
            string Masonry = string.Empty;
            string NonHandheldMechanical = string.Empty;
            string OtherMiscellaneous = string.Empty;
            string RaisingandMovingofBuildings = string.Empty;
            string SignStructure = string.Empty;
            string Steel = string.Empty;
            string TemporaryStructuralBracing = string.Empty;
            string Wood = string.Empty;
            string PrefabWoodJoists = string.Empty;
            string StructuralColdformedSteel = string.Empty;
            string OpenWebSteelPosts = string.Empty;

            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {
                crmTrace.AppendLine("Retrieve PartialDemolition");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.PartialDemolition))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    PartialDemolition = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.PartialDemolition);
                    imageValues.Add(STScopeOfWorkEntityAttribute.PartialDemolition, PartialDemolition);
                    crmTrace.AppendLine("Retrieve PartialDemolition:" + PartialDemolition);
                }
                crmTrace.AppendLine("Retrieve Aluminum");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.Aluminum))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Aluminum = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.Aluminum);
                    imageValues.Add(STScopeOfWorkEntityAttribute.Aluminum, Aluminum);
                    crmTrace.AppendLine("Retrieve Aluminum:" + Aluminum);
                }
                crmTrace.AppendLine("Retrieve Concrete");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.Concrete))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Concrete = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.Concrete);
                    imageValues.Add(STScopeOfWorkEntityAttribute.Concrete, Concrete);
                    crmTrace.AppendLine("Retrieve Concrete:" + Concrete);
                }
                crmTrace.AppendLine("Retrieve HandheldMechanical");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.HandheldMechanical))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    HandheldMechanical = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.HandheldMechanical);
                    imageValues.Add(STScopeOfWorkEntityAttribute.HandheldMechanical, HandheldMechanical);
                    crmTrace.AppendLine("Retrieve HandheldMechanical:" + HandheldMechanical);
                }
                crmTrace.AppendLine("Retrieve Masonry");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.Masonry))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Masonry = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.Masonry);
                    imageValues.Add(STScopeOfWorkEntityAttribute.Masonry, Masonry);
                    crmTrace.AppendLine("Retrieve Masonry:" + Masonry);
                }
                crmTrace.AppendLine("Retrieve NonHandheldMechanical");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.NonHandheldMechanical))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    NonHandheldMechanical = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.NonHandheldMechanical);
                    imageValues.Add(STScopeOfWorkEntityAttribute.NonHandheldMechanical, NonHandheldMechanical);
                    crmTrace.AppendLine("Retrieve NonHandheldMechanical:" + NonHandheldMechanical);
                }
                crmTrace.AppendLine("Retrieve OtherMiscellaneous");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.OtherMiscellaneous))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    OtherMiscellaneous = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.OtherMiscellaneous);
                    imageValues.Add(STScopeOfWorkEntityAttribute.OtherMiscellaneous, OtherMiscellaneous);
                    crmTrace.AppendLine("Retrieve OtherMiscellaneous:" + OtherMiscellaneous);
                }
                crmTrace.AppendLine("Retrieve RaisingandMovingofBuildings");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.RaisingandMovingofBuildings))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    RaisingandMovingofBuildings = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.RaisingandMovingofBuildings);
                    imageValues.Add(STScopeOfWorkEntityAttribute.RaisingandMovingofBuildings, RaisingandMovingofBuildings);
                    crmTrace.AppendLine("Retrieve RaisingandMovingofBuildings:" + RaisingandMovingofBuildings);
                }
                crmTrace.AppendLine("Retrieve SignStructure");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.SignStructure))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    SignStructure = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.SignStructure);
                    imageValues.Add(STScopeOfWorkEntityAttribute.SignStructure, SignStructure);
                    crmTrace.AppendLine("Retrieve SignStructure:" + SignStructure);
                }
                crmTrace.AppendLine("Retrieve Steel");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.Steel))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Steel = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.Steel);
                    imageValues.Add(STScopeOfWorkEntityAttribute.Steel, Steel);
                    crmTrace.AppendLine("Retrieve Steel:" + Steel);
                }
                crmTrace.AppendLine("Retrieve TemporaryStructuralBracing");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.TemporaryStructuralBracing))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    TemporaryStructuralBracing = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.TemporaryStructuralBracing);
                    imageValues.Add(STScopeOfWorkEntityAttribute.TemporaryStructuralBracing, TemporaryStructuralBracing);
                    crmTrace.AppendLine("Retrieve TemporaryStructuralBracing:" + TemporaryStructuralBracing);
                }
                crmTrace.AppendLine("Retrieve Wood");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.Wood))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Wood = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.Wood);
                    imageValues.Add(STScopeOfWorkEntityAttribute.Wood, Wood);
                    crmTrace.AppendLine("Retrieve Wood:" + Wood);
                }
                crmTrace.AppendLine("Retrieve PrefabWoodJoists");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.PrefabWoodJoists))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    PrefabWoodJoists = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.PrefabWoodJoists);
                    imageValues.Add(STScopeOfWorkEntityAttribute.PrefabWoodJoists, PrefabWoodJoists);
                    crmTrace.AppendLine("Retrieve PrefabWoodJoists:" + PrefabWoodJoists);
                }
                crmTrace.AppendLine("Retrieve StructuralColdformedSteel");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.StructuralColdformedSteel))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    StructuralColdformedSteel = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.StructuralColdformedSteel);
                    imageValues.Add(STScopeOfWorkEntityAttribute.StructuralColdformedSteel, StructuralColdformedSteel);
                    crmTrace.AppendLine("Retrieve StructuralColdformedSteel:" + StructuralColdformedSteel);
                }

                crmTrace.AppendLine("Retrieve OpenWebSteelPosts");
                if (preImage.Attributes.Contains(STScopeOfWorkEntityAttribute.OpenWebSteelPosts))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    OpenWebSteelPosts = SetBooleanAttribute(preImage, STScopeOfWorkEntityAttribute.OpenWebSteelPosts);
                    imageValues.Add(STScopeOfWorkEntityAttribute.OpenWebSteelPosts, OpenWebSteelPosts);
                    crmTrace.AppendLine("Retrieve OpenWebSteelPosts:" + OpenWebSteelPosts);
                }

                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }


        public static Dictionary<string, string> MHSOWImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string ModelName = string.Empty;
            string itemName = string.Empty;
            string ManufacturersName = string.Empty;
            string equipmentEfficiency = string.Empty;
            string capacityUnits = string.Empty;
            string NumberOfItems = string.Empty;
            string Location = string.Empty;
            string CertificationforLISTING = string.Empty;
            string itemText = string.Empty;
            string IsinitialFilingScopeOfwork = string.Empty;
            string isCoCNeeded = string.Empty;
            string capacityNumber = string.Empty;
            string subCategory = string.Empty;
            string equipmentUnits = string.Empty;

            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {
                crmTrace.AppendLine("Retrieve IsinitialFilingScopeOfwork");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.IsinitialFilingScopeOfwork))
                {
                    crmTrace.AppendLine("Retrieve IsinitialFilingScopeOfwork");
                    IsinitialFilingScopeOfwork = SetBooleanAttribute(preImage, MHScopeofworkAttributeNames.IsinitialFilingScopeOfwork);
                    imageValues.Add(MHScopeofworkAttributeNames.IsinitialFilingScopeOfwork, IsinitialFilingScopeOfwork);
                    crmTrace.AppendLine("Retrieve PartialDemolition:" + IsinitialFilingScopeOfwork);
                }
                crmTrace.AppendLine("Retrieve isCoCNeeded");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.isCoCNeeded))
                {
                    crmTrace.AppendLine("Retrieve isCoCNeeded");
                    isCoCNeeded = SetBooleanAttribute(preImage, MHScopeofworkAttributeNames.isCoCNeeded);
                    imageValues.Add(MHScopeofworkAttributeNames.isCoCNeeded, isCoCNeeded);
                    crmTrace.AppendLine("Retrieve isCoCNeeded:" + isCoCNeeded);
                }
                crmTrace.AppendLine("Retrieve itemText");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.itemText))
                {
                    itemText = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.itemText);
                    imageValues.Add(MHScopeofworkAttributeNames.itemText, itemText);
                    crmTrace.AppendLine("Retrieve itemText:" + itemText);
                }
                crmTrace.AppendLine("Retrieve CertificationforLISTING");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.CertificationforLISTING))
                {
                    CertificationforLISTING = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.CertificationforLISTING);
                    imageValues.Add(MHScopeofworkAttributeNames.CertificationforLISTING, CertificationforLISTING);
                    crmTrace.AppendLine("Retrieve CertificationforLISTING:" + CertificationforLISTING);
                }
                crmTrace.AppendLine("Retrieve Location");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.Location))
                {
                    Location = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.Location);
                    imageValues.Add(MHScopeofworkAttributeNames.Location, Location);
                    crmTrace.AppendLine("Retrieve itemText:" + Location);
                }
                crmTrace.AppendLine("Retrieve NumberOfItems");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.NumberOfItems))
                {
                    NumberOfItems = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.NumberOfItems);
                    imageValues.Add(MHScopeofworkAttributeNames.NumberOfItems, NumberOfItems);
                    crmTrace.AppendLine("Retrieve NumberOfItems:" + NumberOfItems);
                }
                crmTrace.AppendLine("Retrieve capacityNumber");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.capacityNumber))
                {
                    capacityNumber = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.capacityNumber);
                    imageValues.Add(MHScopeofworkAttributeNames.capacityNumber, capacityNumber);
                    crmTrace.AppendLine("Retrieve capacityNumber:" + capacityNumber);
                }
                crmTrace.AppendLine("Retrieve capacityUnits");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.capacityUnits))
                {
                    capacityUnits = preImage.FormattedValues[MHScopeofworkAttributeNames.capacityUnits];
                    imageValues.Add(MHScopeofworkAttributeNames.capacityUnits, capacityUnits);
                    crmTrace.AppendLine("Retrieve capacityUnits:" + capacityUnits);
                }
                crmTrace.AppendLine("Retrieve equipmentEfficiency");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.equipmentEfficiency))
                {
                    equipmentEfficiency = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.equipmentEfficiency);
                    imageValues.Add(MHScopeofworkAttributeNames.equipmentEfficiency, equipmentEfficiency);
                    crmTrace.AppendLine("Retrieve equipmentEfficiency:" + equipmentEfficiency);
                }
                crmTrace.AppendLine("Retrieve ManufacturersName");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.ManufacturersName))
                {
                    ManufacturersName = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.ManufacturersName);
                    imageValues.Add(MHScopeofworkAttributeNames.ManufacturersName, ManufacturersName);
                    crmTrace.AppendLine("Retrieve ManufacturersName:" + ManufacturersName);
                }
                crmTrace.AppendLine("Retrieve ModelName");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.ModelName))
                {
                    ModelName = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.ModelName);
                    imageValues.Add(MHScopeofworkAttributeNames.ModelName, ModelName);
                    crmTrace.AppendLine("Retrieve ModelName:" + ModelName);
                }





                crmTrace.AppendLine("Retrieve itemName");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.itemName))
                {
                    itemName = preImage.GetAttributeValue<string>(MHScopeofworkAttributeNames.itemName);
                    imageValues.Add(MHScopeofworkAttributeNames.itemName, itemName);
                    crmTrace.AppendLine("Retrieve itemName:" + itemName);
                }
                crmTrace.AppendLine("Retrieve subCategory");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.subCategory))
                {
                    subCategory = preImage.FormattedValues[MHScopeofworkAttributeNames.subCategory];
                    imageValues.Add(MHScopeofworkAttributeNames.subCategory, subCategory);
                    crmTrace.AppendLine("Retrieve subCategory:" + subCategory);
                }

                crmTrace.AppendLine("Retrieve equipmentUnits");
                if (preImage.Attributes.Contains(MHScopeofworkAttributeNames.equipmentUnits))
                {
                    equipmentUnits = preImage.FormattedValues[MHScopeofworkAttributeNames.equipmentUnits];
                    imageValues.Add(MHScopeofworkAttributeNames.equipmentUnits, equipmentUnits);
                    crmTrace.AppendLine("Retrieve equipmentUnits:" + equipmentUnits);
                }


                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - MHSOWImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }


        public static Dictionary<string, string> TR3TechinalReportImageValues(Entity preImage, StringBuilder crmTrace)
        {
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            string EntityLogicalName = string.Empty;
            string GoToJobFiling = string.Empty;
            string ApplicantStatementChk = string.Empty;
            string ApplicantStatementName = string.Empty;
            string ApplicantStatementDate = string.Empty;
            string OwnerStatementChk = string.Empty;
            string OwnerStatementName = string.Empty;
            string OwnerStatementDate = string.Empty;
            try
            {
                crmTrace.AppendLine("Retrieve ApplicantStatementName");
                if (preImage.Attributes.Contains(TR3TechinalReport.ApplicantStatementName))
                {
                    ApplicantStatementName = preImage.GetAttributeValue<string>(TR3TechinalReport.ApplicantStatementName).ToString();
                    imageValues.Add(TR3TechinalReport.ApplicantStatementName, ApplicantStatementName);
                    crmTrace.AppendLine("Retrieve ApplicantStatementName:" + ApplicantStatementName);
                }
                crmTrace.AppendLine("Retrieve OwnerStatementName");
                if (preImage.Attributes.Contains(TR3TechinalReport.OwnerStatementName))
                {
                    OwnerStatementName = preImage.GetAttributeValue<string>(TR3TechinalReport.OwnerStatementName).ToString();
                    imageValues.Add(TR3TechinalReport.OwnerStatementName, OwnerStatementName);
                    crmTrace.AppendLine("Retrieve OwnerStatementName:" + OwnerStatementName);
                }

                if (preImage.Attributes.Contains(TR3TechinalReport.ApplicantStatementChk))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    ApplicantStatementChk = SetBooleanAttribute(preImage, TR3TechinalReport.ApplicantStatementChk);
                    imageValues.Add(TR3TechinalReport.ApplicantStatementChk, ApplicantStatementChk);
                    crmTrace.AppendLine("Retrieve ApplicantStatementChk:" + ApplicantStatementChk);
                }
                if (preImage.Attributes.Contains(TR3TechinalReport.OwnerStatementChk))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    OwnerStatementChk = SetBooleanAttribute(preImage, TR3TechinalReport.OwnerStatementChk);
                    imageValues.Add(TR3TechinalReport.OwnerStatementChk, OwnerStatementChk);
                    crmTrace.AppendLine("Retrieve OwnerStatementChk:" + OwnerStatementChk);
                }
                crmTrace.AppendLine("Retrieve ApplicantStatementDate");
                if (preImage.Attributes.Contains(TR3TechinalReport.ApplicantStatementDate))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3TechinalReport.ApplicantStatementDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        ApplicantStatementDate = dateTime.ToString();
                        imageValues.Add(TR3TechinalReport.ApplicantStatementDate, ApplicantStatementDate);
                    }
                    else
                    {
                        imageValues.Add(TR3TechinalReport.ApplicantStatementDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve ApplicantStatementDate:" + ApplicantStatementDate);
                }
                crmTrace.AppendLine("Retrieve OwnerStatementDate");
                if (preImage.Attributes.Contains(TR3TechinalReport.OwnerStatementDate))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3TechinalReport.OwnerStatementDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        OwnerStatementDate = dateTime.ToString();
                        imageValues.Add(TR3TechinalReport.OwnerStatementDate, OwnerStatementDate);
                    }
                    else
                    {
                        imageValues.Add(TR3TechinalReport.OwnerStatementDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve OwnerStatementDate:" + OwnerStatementDate);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3TechinalReportImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }
        public static Dictionary<string, string> TR3DirectorsImageValues(Entity preImage, StringBuilder crmTrace)
        {
            string NRMCACertificationExpirationDate = string.Empty;
            string TR3DirectorEmail = string.Empty;
            string BusinessName = string.Empty;
            string LicenseNumber = string.Empty;
            string ConcreteProducerName = string.Empty;
            string ConcreteProducerBusinessName = string.Empty;
            string ConcreteProducerLicNum = string.Empty;
            string ConcreteProducerSSName = string.Empty;
            string ConcreteProducerSSChk = string.Empty;
            string ConcreteProducerSSDate = string.Empty;
            string ConcreteDirecotQulityManagerSSName = string.Empty;
            string ConcreteDirecotQulityManagerSSchk = string.Empty;
            string ConcreteDirecotQulityManagerSSDate = string.Empty;

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {

                crmTrace.AppendLine("Retrieve TR3DirectorEmail");
                if (preImage.Attributes.Contains(TR3Directors.TR3DirectorEmail))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.TR3DirectorEmail);
                    if (reqLookUp != null)
                    {
                        TR3DirectorEmail = reqLookUp.Name;
                        imageValues.Add(TR3Directors.TR3DirectorEmail, TR3DirectorEmail);
                    }
                    crmTrace.AppendLine("Retrieve TR3DirectorEmail:" + TR3DirectorEmail);
                }
                crmTrace.AppendLine("Retrieve BusinessName");
                if (preImage.Attributes.Contains(TR3Directors.BusinessName))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.BusinessName);
                    if (reqLookUp != null)
                    {
                        BusinessName = reqLookUp.Name;
                        imageValues.Add(TR3Directors.BusinessName, BusinessName);
                    }
                    crmTrace.AppendLine("Retrieve BusinessName:" + BusinessName);
                }
                crmTrace.AppendLine("Retrieve LicenseNumber");
                if (preImage.Attributes.Contains(TR3Directors.LicenseNumber))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.LicenseNumber);
                    if (reqLookUp != null)
                    {
                        LicenseNumber = reqLookUp.Name;
                        imageValues.Add(TR3Directors.LicenseNumber, LicenseNumber);
                    }
                    crmTrace.AppendLine("Retrieve LicenseNumber:" + LicenseNumber);
                }
                crmTrace.AppendLine("Retrieve ConcreteProducerName");
                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerName))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.ConcreteProducerName);
                    if (reqLookUp != null)
                    {
                        ConcreteProducerName = reqLookUp.Name;
                        imageValues.Add(TR3Directors.ConcreteProducerName, ConcreteProducerName);
                    }
                    crmTrace.AppendLine("Retrieve ConcreteProducerName:" + ConcreteProducerName);
                }
                crmTrace.AppendLine("Retrieve ConcreteProducerBusinessName");
                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerBusinessName))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.ConcreteProducerBusinessName);
                    if (reqLookUp != null)
                    {
                        ConcreteProducerBusinessName = reqLookUp.Name;
                        imageValues.Add(TR3Directors.ConcreteProducerBusinessName, ConcreteProducerBusinessName);
                    }
                    crmTrace.AppendLine("Retrieve ConcreteProducerBusinessName:" + ConcreteProducerBusinessName);
                }
                crmTrace.AppendLine("Retrieve ConcreteProducerLicNum");
                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerLicNum))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(TR3Directors.ConcreteProducerLicNum);
                    if (reqLookUp != null)
                    {
                        ConcreteProducerLicNum = reqLookUp.Name;
                        imageValues.Add(TR3Directors.ConcreteProducerLicNum, ConcreteProducerLicNum);
                    }
                    crmTrace.AppendLine("Retrieve ConcreteProducerLicNum:" + ConcreteProducerLicNum);
                }


                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerSSName))
                {
                    ConcreteProducerSSName = preImage.GetAttributeValue<string>(TR3Directors.ConcreteProducerSSName).ToString();
                    imageValues.Add(TR3Directors.ConcreteProducerSSName, ConcreteProducerSSName);
                    crmTrace.AppendLine("Retrieve ConcreteProducerSSName:" + ConcreteProducerSSName);
                }
                if (preImage.Attributes.Contains(TR3Directors.ConcreteDirecotQulityManagerSSName))
                {
                    ConcreteDirecotQulityManagerSSName = preImage.GetAttributeValue<string>(TR3Directors.ConcreteDirecotQulityManagerSSName).ToString();
                    imageValues.Add(TR3Directors.ConcreteDirecotQulityManagerSSName, ConcreteDirecotQulityManagerSSName);
                    crmTrace.AppendLine("Retrieve ConcreteDirecotQulityManagerSSName:" + ConcreteDirecotQulityManagerSSName);
                }
                if (preImage.Attributes.Contains(TR3Directors.ConcreteDirecotQulityManagerSSchk))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    ConcreteDirecotQulityManagerSSchk = SetBooleanAttribute(preImage, TR3Directors.ConcreteDirecotQulityManagerSSchk);
                    imageValues.Add(TR3Directors.ConcreteDirecotQulityManagerSSchk, ConcreteDirecotQulityManagerSSchk);
                    crmTrace.AppendLine("Retrieve ConcreteDirecotQulityManagerSSchk:" + ConcreteDirecotQulityManagerSSchk);
                }
                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerSSChk))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    ConcreteProducerSSChk = SetBooleanAttribute(preImage, TR3Directors.ConcreteProducerSSChk);
                    imageValues.Add(TR3Directors.ConcreteProducerSSChk, ConcreteProducerSSChk);
                    crmTrace.AppendLine("Retrieve ConcreteProducerSSChk:" + ConcreteProducerSSChk);
                }
                crmTrace.AppendLine("Retrieve ConcreteDirecotQulityManagerSSDate");
                if (preImage.Attributes.Contains(TR3Directors.ConcreteDirecotQulityManagerSSDate))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3Directors.ConcreteDirecotQulityManagerSSDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        ConcreteDirecotQulityManagerSSDate = dateTime.ToString();
                        imageValues.Add(TR3Directors.ConcreteDirecotQulityManagerSSDate, ConcreteDirecotQulityManagerSSDate);
                    }
                    else
                    {
                        imageValues.Add(TR3Directors.ConcreteDirecotQulityManagerSSDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve ConcreteDirecotQulityManagerSSDate:" + ConcreteDirecotQulityManagerSSDate);
                }
                crmTrace.AppendLine("Retrieve ConcreteProducerSSDate");
                if (preImage.Attributes.Contains(TR3Directors.ConcreteProducerSSDate))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3Directors.ConcreteProducerSSDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        ConcreteProducerSSDate = dateTime.ToString();
                        imageValues.Add(TR3Directors.ConcreteProducerSSDate, ConcreteProducerSSDate);
                    }
                    else
                    {
                        imageValues.Add(TR3Directors.ConcreteProducerSSDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve OwnerStatementDate:" + ConcreteProducerSSDate);
                }
                crmTrace.AppendLine("Retrieve NRMCACertificationExpirationDate");
                if (preImage.Attributes.Contains(TR3Directors.NRMCACertificationExpirationDate))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3Directors.NRMCACertificationExpirationDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        NRMCACertificationExpirationDate = dateTime.ToString();
                        imageValues.Add(TR3Directors.NRMCACertificationExpirationDate, NRMCACertificationExpirationDate);
                    }
                    else
                    {
                        imageValues.Add(TR3Directors.NRMCACertificationExpirationDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve OwnerStatementDate:" + NRMCACertificationExpirationDate);
                }


                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3DirecotsImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }
        public static Dictionary<string, string> TR3MixImageValues(Entity preImage, StringBuilder crmTrace)
        {
            string RequiredStrength = string.Empty;
            string SpecifiedStrength = string.Empty;
            string SpecifiedTestAgeDays = string.Empty;
            string Method = string.Empty;
            string TrialPerformedOn = string.Empty;
            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {
                crmTrace.AppendLine("Retrieve Method");
                if (preImage.Attributes.Contains(TR3Mix.Method))
                {
                    Method = preImage.FormattedValues[TR3Mix.Method];
                    imageValues.Add(TR3Mix.Method, Method);
                    crmTrace.AppendLine("Retrieve Method:" + Method);
                }

                crmTrace.AppendLine("Retrieve RequiredStrength");
                if (preImage.Attributes.Contains(TR3Mix.RequiredStrength))
                {
                    RequiredStrength = preImage.GetAttributeValue<decimal>(TR3Mix.RequiredStrength).ToString();
                    imageValues.Add(TR3Mix.RequiredStrength, RequiredStrength);
                    crmTrace.AppendLine("Retrieve RequiredStrength:" + RequiredStrength);
                }
                crmTrace.AppendLine("Retrieve SpecifiedStrength");
                if (preImage.Attributes.Contains(TR3Mix.SpecifiedStrength))
                {
                    SpecifiedStrength = preImage.GetAttributeValue<decimal>(TR3Mix.SpecifiedStrength).ToString();
                    imageValues.Add(TR3Mix.SpecifiedStrength, SpecifiedStrength);
                    crmTrace.AppendLine("Retrieve SpecifiedStrength:" + SpecifiedStrength);
                }
                crmTrace.AppendLine("Retrieve SpecifiedStrength");
                crmTrace.AppendLine("Retrieve SpecifiedTestAgeDays");
                if (preImage.Attributes.Contains(TR3Mix.SpecifiedTestAgeDays))
                {
                    SpecifiedTestAgeDays = preImage.GetAttributeValue<decimal>(TR3Mix.SpecifiedTestAgeDays).ToString();
                    imageValues.Add(TR3Mix.SpecifiedTestAgeDays, SpecifiedTestAgeDays);
                    crmTrace.AppendLine("Retrieve SpecifiedStrength:" + SpecifiedTestAgeDays);
                }
                if (preImage.Attributes.Contains(TR3Mix.SpecifiedTestAgeDays))
                {
                    RequiredStrength = preImage.GetAttributeValue<decimal>(TR3Mix.RequiredStrength).ToString();
                    imageValues.Add(TR3Mix.RequiredStrength, RequiredStrength);
                    crmTrace.AppendLine("Retrieve RequiredStrength:" + RequiredStrength);
                }

                crmTrace.AppendLine("Retrieve TrialPerformedOn");
                if (preImage.Attributes.Contains(TR3Mix.TrialPerformedOn))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(TR3Mix.TrialPerformedOn);
                    if (dateTime != DateTime.MinValue)
                    {
                        TrialPerformedOn = dateTime.ToString();
                        imageValues.Add(TR3Mix.TrialPerformedOn, TrialPerformedOn);
                    }
                    else
                    {
                        imageValues.Add(TR3Mix.TrialPerformedOn, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve TrialPerformedOn:" + TrialPerformedOn);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }
        public static Dictionary<string, string> TR3MixIngredientsImageValues(Entity preImage, StringBuilder crmTrace)
        {
            string ASTMStandard = string.Empty;
            string lbs = string.Empty;
            string Materialsource = string.Empty;
            string MaterialType = string.Empty;
            string Types = string.Empty;

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {
                if (preImage.Attributes.Contains(TR3MixIngredients.ASTMStandard))
                {
                    ASTMStandard = preImage.GetAttributeValue<string>(TR3MixIngredients.ASTMStandard).ToString();
                    imageValues.Add(TR3MixIngredients.ASTMStandard, ASTMStandard);
                    crmTrace.AppendLine("Retrieve ASTMStandard:" + ASTMStandard);
                }
                if (preImage.Attributes.Contains(TR3MixIngredients.MaterialType))
                {
                    MaterialType = preImage.GetAttributeValue<string>(TR3MixIngredients.MaterialType).ToString();
                    imageValues.Add(TR3MixIngredients.MaterialType, MaterialType);
                    crmTrace.AppendLine("Retrieve MaterialType:" + MaterialType);
                }
                if (preImage.Attributes.Contains(TR3MixIngredients.Types))
                {
                    Types = preImage.GetAttributeValue<string>(TR3MixIngredients.Types).ToString();
                    imageValues.Add(TR3MixIngredients.Types, Types);
                    crmTrace.AppendLine("Retrieve Types:" + Types);
                }

                crmTrace.AppendLine("Retrieve Types");
                if (preImage.Attributes.Contains(TR3MixIngredients.Types))
                {
                    Types = preImage.FormattedValues[TR3MixIngredients.Types];
                    imageValues.Add(TR3MixIngredients.Types, Types);
                    crmTrace.AppendLine("Retrieve Method:" + Types);
                }

                crmTrace.AppendLine("Retrieve lbs");
                if (preImage.Attributes.Contains(TR3MixIngredients.lbs))
                {
                    lbs = preImage.GetAttributeValue<decimal>(TR3MixIngredients.lbs).ToString();
                    imageValues.Add(TR3MixIngredients.lbs, lbs);
                    crmTrace.AppendLine("Retrieve lbs:" + lbs);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - TR3MixIngredientsImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }

        }


        public static Dictionary<string, string> BoilerBuildDeviceImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string IsAssociatedWithCOGEN = string.Empty;
            string BoilerDesign = string.Empty;
            string BoilerComments = string.Empty;
            string ServiceLocationFloor = string.Empty;
            string ServiceLocationAddress = string.Empty;
            string IsBoilerEquippedWithManholes = string.Empty;
            string IsBoilerHeatingaSingleAppartment = string.Empty;
            string OccupancyType = string.Empty;
            string BoilerListingAgencyNameOther = string.Empty;
            string BoilerListingAgencyName = string.Empty;
            string BoilerCertificationNumber = string.Empty;
            string SerialNumber = string.Empty;
            string constructionMaterial = string.Empty;
            string constructionMaterialOther = string.Empty;
            string NationalBoardNumber = string.Empty;
            string BoilerModel = string.Empty;
            string Efficiency = string.Empty;
            string PressureSettingOfreliefValvepsi = string.Empty;
            string InternalAccess = string.Empty;
            string BTU = string.Empty;
            string BoilerManufacturer = string.Empty;
            string Locatedin = string.Empty;

            string BurnerComments = string.Empty;
            string BurnerCertificationNumber = string.Empty;
            string BurnerListingAgencyOther = string.Empty;
            string PrimaryStructuralSystem = string.Empty;

            string BurnerManufacturer = string.Empty;
            string BurnerType = string.Empty;
            string BurnerListingAgencyName = string.Empty;
            string BurnerULCSAETLNumber = string.Empty;
            string BurnerModelNumber = string.Empty;
            string BurnerFiringRate = string.Empty;
            string BurnerFiringBTUHour = string.Empty;
            string DualBurningCapacity = string.Empty;
            string ReplacingBurner = string.Empty;
            string BurnerIsThisExisting = string.Empty;

            string FDNYPermitNumber = string.Empty;
            string FSFloorNumber = string.Empty;
            string OtherFuelStorageAppliance = string.Empty;
            string FSComments = string.Empty;
            string FSExistingGrdaeOil = string.Empty;

            string FSLocationOfFS = string.Empty;
            string FSExistingStorageTank = string.Empty;
            string FSTotalTankCapacity = string.Empty;
            string FSApplianceFuelStorage = string.Empty;
            string FSabandedResultOfOiltoGas = string.Empty;
            string FSBuildingAdjacentLineOfSubway = string.Empty;
            string FSHowTanksInstalled = string.Empty;
            string Isabonabandonremovaloftank = string.Empty;            
            string ChimneyApplianceConnectedTo = string.Empty;
            string ChimneyIsNewInstallation = string.Empty;
            string ChimneyChooseFollowing = string.Empty;
            string ChimneyMaterialLinedWith = string.Empty;
            string ChimneyMaterialOther = string.Empty;
            string VentApprovedMaterial = string.Empty;
            string AssociatedJobNumber = string.Empty;
            string VentMaterialOther = string.Empty;
            string QuantityofBoilers = string.Empty;
            
            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {

                #region Boiler Device Details




                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN))
                {
                    crmTrace.AppendLine("Retrieve IsAssociatedWithCOGEN");
                    IsAssociatedWithCOGEN = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN, IsAssociatedWithCOGEN);
                    crmTrace.AppendLine("Retrieve IsAssociatedWithCOGEN:" + IsAssociatedWithCOGEN);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress))
                {
                    crmTrace.AppendLine("Retrieve ServiceLocationAddress");
                    ServiceLocationAddress = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress, ServiceLocationAddress);
                    crmTrace.AppendLine("Retrieve ServiceLocationAddress:" + ServiceLocationAddress);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers))
                {
                    crmTrace.AppendLine("Retrieve QuantityofBoilers");
                    QuantityofBoilers = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers, QuantityofBoilers);
                    crmTrace.AppendLine("Retrieve QuantityofBoilers:" + QuantityofBoilers);
                }

                crmTrace.AppendLine("Retrieve BoilerDesign");
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign))
                {
                    BoilerDesign = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign, BoilerDesign);
                    crmTrace.AppendLine("Retrieve BoilerDesign:" + BoilerDesign);
                }
                crmTrace.AppendLine("Retrieve BoilerComments");
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerComments))
                {
                    BoilerComments = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerComments);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerComments, BoilerComments);
                    crmTrace.AppendLine("Retrieve BoilerInputCapacity:" + BoilerComments);
                }

                crmTrace.AppendLine("Retrieve ServiceLocationFloor");
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor))
                {
                    ServiceLocationFloor = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor, ServiceLocationFloor);
                    crmTrace.AppendLine("Retrieve ServiceLocationFloor:" + ServiceLocationFloor);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes))
                {
                    crmTrace.AppendLine("Retrieve IsBoilerEquippedWithManholes");
                    IsBoilerEquippedWithManholes = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes, IsBoilerEquippedWithManholes);
                    crmTrace.AppendLine("Retrieve IsBoilerEquippedWithManholes:" + IsBoilerEquippedWithManholes);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment))
                {
                    crmTrace.AppendLine("Retrieve IsBoilerHeatingaSingleAppartment");
                    IsBoilerHeatingaSingleAppartment = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment, IsBoilerHeatingaSingleAppartment);
                    crmTrace.AppendLine("Retrieve IsBoilerHeatingaSingleAppartment:" + IsBoilerHeatingaSingleAppartment);
                }

                crmTrace.AppendLine("Retrieve OccupancyType");
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.OccupancyType))
                {
                    OccupancyType = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.OccupancyType];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.OccupancyType, OccupancyType);
                    crmTrace.AppendLine("Retrieve OccupancyType:" + OccupancyType);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther))
                {
                    BoilerListingAgencyNameOther = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther, BoilerListingAgencyNameOther);
                    crmTrace.AppendLine("Retrieve BoilerListingAgencyNameOther:" + BoilerListingAgencyNameOther);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName))
                {
                    BoilerListingAgencyName = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName, BoilerListingAgencyName);
                    crmTrace.AppendLine("Retrieve BoilerListingAgencyName:" + BoilerListingAgencyName);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber))
                {
                    BoilerCertificationNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber, BoilerCertificationNumber);
                    crmTrace.AppendLine("Retrieve BoilerCertificationNumber:" + BoilerCertificationNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.SerialNumber))
                {
                    SerialNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.SerialNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.SerialNumber, SerialNumber);
                    crmTrace.AppendLine("Retrieve SerialNumber:" + SerialNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial))
                {
                    constructionMaterial = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial, constructionMaterial);
                    crmTrace.AppendLine("Retrieve constructionMaterial:" + constructionMaterial);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther))
                {
                    constructionMaterialOther = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther, constructionMaterialOther);
                    crmTrace.AppendLine("Retrieve constructionMaterialOther:" + constructionMaterialOther);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber))
                {
                    NationalBoardNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber, NationalBoardNumber);
                    crmTrace.AppendLine("Retrieve NationalBoardNumber:" + NationalBoardNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerModel))
                {
                    BoilerModel = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerModel);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerModel, BoilerModel);
                    crmTrace.AppendLine("Retrieve BoilerModel:" + BoilerModel);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.Efficiency))
                {
                    Efficiency = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.Efficiency);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.Efficiency, Efficiency);
                    crmTrace.AppendLine("Retrieve Efficiency:" + Efficiency);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi))
                {
                    PressureSettingOfreliefValvepsi = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi, PressureSettingOfreliefValvepsi);
                    crmTrace.AppendLine("Retrieve Efficiency:" + PressureSettingOfreliefValvepsi);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.InternalAccess))
                {
                    InternalAccess = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.InternalAccess];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.InternalAccess, InternalAccess);
                    crmTrace.AppendLine("Retrieve InternalAccess:" + InternalAccess);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BTU))
                {
                    BTU = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BTU);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BTU, BTU);
                    crmTrace.AppendLine("Retrieve BTU:" + BTU);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer))
                {
                    BoilerManufacturer = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer, BoilerManufacturer);
                    crmTrace.AppendLine("Retrieve BoilerManufacturer:" + BoilerManufacturer);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.Locatedin))
                {
                    Locatedin = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.Locatedin);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.Locatedin, Locatedin);
                    crmTrace.AppendLine("Retrieve Locatedin:" + Locatedin);
                }


                #endregion



                #region Burner Details

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments))
                {
                    BurnerComments = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments, BurnerComments);
                    crmTrace.AppendLine("Retrieve BurnerComments:" + BurnerComments);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber))
                {
                    BurnerCertificationNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber, BurnerCertificationNumber);
                    crmTrace.AppendLine("Retrieve BurnerCertificationNumber:" + BurnerCertificationNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther))
                {
                    BurnerListingAgencyOther = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther, BurnerListingAgencyOther);
                    crmTrace.AppendLine("Retrieve BurnerListingAgencyOther:" + BurnerListingAgencyOther);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer))
                {
                    BurnerManufacturer = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer, BurnerManufacturer);
                    crmTrace.AppendLine("Retrieve BurnerManufacturer:" + BurnerManufacturer);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerType))
                {
                    BurnerType = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.BurnerType];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerType, BurnerType);
                    crmTrace.AppendLine("Retrieve BurnerType:" + BurnerType);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName))
                {
                    BurnerListingAgencyName = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName, BurnerListingAgencyName);
                    crmTrace.AppendLine("Retrieve BurnerListingAgencyName:" + BurnerListingAgencyName);
                }


                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber))
                {
                    BurnerULCSAETLNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber, BurnerULCSAETLNumber);
                    crmTrace.AppendLine("Retrieve BurnerListingAgencyOther:" + BurnerULCSAETLNumber);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber))
                {
                    BurnerModelNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber, BurnerModelNumber);
                    crmTrace.AppendLine("Retrieve BurnerModelNumber:" + BurnerModelNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity))
                {
                    PrimaryStructuralSystem = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity, PrimaryStructuralSystem);
                    crmTrace.AppendLine("Retrieve BurnerInputCapacity:" + PrimaryStructuralSystem);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate))
                {
                    BurnerFiringRate = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate, BurnerFiringRate);
                    crmTrace.AppendLine("Retrieve BurnerFiringRate:" + BurnerFiringRate);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour))
                {
                    BurnerFiringBTUHour = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour, BurnerFiringBTUHour);
                    crmTrace.AppendLine("Retrieve BurnerFiringBTUHour:" + BurnerFiringBTUHour);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity))
                {
                    crmTrace.AppendLine("Retrieve DualBurningCapacity");
                    DualBurningCapacity = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity, DualBurningCapacity);
                    crmTrace.AppendLine("Retrieve DualBurningCapacity:" + DualBurningCapacity);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner))
                {
                    crmTrace.AppendLine("Retrieve ReplacingBurner");
                    ReplacingBurner = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner, ReplacingBurner);
                    crmTrace.AppendLine("Retrieve ReplacingBurner:" + ReplacingBurner);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting))
                {
                    crmTrace.AppendLine("Retrieve BurnerIsThisExisting");
                    PrimaryStructuralSystem = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting, PrimaryStructuralSystem);
                    crmTrace.AppendLine("Retrieve BurnerIsThisExisting:" + PrimaryStructuralSystem);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo))
                {
                    BurnerIsThisExisting = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo, BurnerIsThisExisting);
                    crmTrace.AppendLine("Retrieve BurnerApplianceConnectedTo:" + BurnerIsThisExisting);
                }



                #endregion



                #region FS Details

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber))
                {
                    FDNYPermitNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber, FDNYPermitNumber);
                    crmTrace.AppendLine("Retrieve FDNYPermitNumber:" + FDNYPermitNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber))
                {
                    FSFloorNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber, FSFloorNumber);
                    crmTrace.AppendLine("Retrieve FSFloorNumber:" + FSFloorNumber);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance))
                {
                    OtherFuelStorageAppliance = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance, OtherFuelStorageAppliance);
                    crmTrace.AppendLine("Retrieve OtherFuelStorageAppliance:" + OtherFuelStorageAppliance);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSComments))
                {
                    FSComments = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.FSComments);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSComments, FSComments);
                    crmTrace.AppendLine("Retrieve FSComments:" + FSComments);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil))
                {
                    FSExistingGrdaeOil = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil, FSExistingGrdaeOil);
                    crmTrace.AppendLine("Retrieve FSExistingGrdaeOil:" + FSExistingGrdaeOil);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS))
                {
                    FSLocationOfFS = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS, FSLocationOfFS);
                    crmTrace.AppendLine("Retrieve FSLocationOfFS:" + FSLocationOfFS);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank))
                {
                    crmTrace.AppendLine("Retrieve FSExistingStorageTank");
                    FSExistingStorageTank = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank, FSExistingStorageTank);
                    crmTrace.AppendLine("Retrieve ReplacingBurner:" + FSExistingStorageTank);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.Isabonabandonremovaloftank))
                {
                    crmTrace.AppendLine("Retrieve Isabonabandonremovaloftank");
                    Isabonabandonremovaloftank = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.Isabonabandonremovaloftank);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.Isabonabandonremovaloftank, Isabonabandonremovaloftank);
                    crmTrace.AppendLine("Retrieve Isabonabandonremovaloftank:" + Isabonabandonremovaloftank);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity))
                {
                    FSTotalTankCapacity = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity, FSTotalTankCapacity);
                    crmTrace.AppendLine("Retrieve FSTotalTankCapacity:" + FSTotalTankCapacity);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage))
                {
                    FSApplianceFuelStorage = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage, FSApplianceFuelStorage);
                    crmTrace.AppendLine("Retrieve FSApplianceFuelStorage:" + FSApplianceFuelStorage);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas))
                {
                    crmTrace.AppendLine("Retrieve FSabandedResultOfOiltoGas");
                    FSabandedResultOfOiltoGas = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas, FSabandedResultOfOiltoGas);
                    crmTrace.AppendLine("Retrieve FSabandedResultOfOiltoGas:" + FSabandedResultOfOiltoGas);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway))
                {
                    crmTrace.AppendLine("Retrieve FSBuildingAdjacentLineOfSubway");
                    FSBuildingAdjacentLineOfSubway = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway, FSBuildingAdjacentLineOfSubway);
                    crmTrace.AppendLine("Retrieve FSBuildingAdjacentLineOfSubway:" + FSBuildingAdjacentLineOfSubway);
                }

                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled))
                {
                    FSHowTanksInstalled = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled, FSHowTanksInstalled);
                    crmTrace.AppendLine("Retrieve FSHowTanksInstalled:" + FSHowTanksInstalled);
                }
                


                #endregion

                #region Chimney Details                
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo))
                {
                    ChimneyApplianceConnectedTo = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo, ChimneyApplianceConnectedTo);
                    crmTrace.AppendLine("Retrieve ChimneyApplianceConnectedTo:" + ChimneyApplianceConnectedTo);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing))
                {
                    ChimneyChooseFollowing = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing, ChimneyChooseFollowing);
                    crmTrace.AppendLine("Retrieve ChimneyChooseFollowing:" + ChimneyChooseFollowing);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith))
                {
                    ChimneyMaterialLinedWith = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith, ChimneyMaterialLinedWith);
                    crmTrace.AppendLine("Retrieve ChimneyMaterialLinedWith:" + ChimneyMaterialLinedWith);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial))
                {
                    VentApprovedMaterial = preImage.FormattedValues[BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial];
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial, VentApprovedMaterial);
                    crmTrace.AppendLine("Retrieve VentApprovedMaterial:" + VentApprovedMaterial);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation))
                {
                    crmTrace.AppendLine("Retrieve ChimneyIsNewInstallation");
                    ChimneyIsNewInstallation = SetBooleanAttribute(preImage, BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation, ChimneyIsNewInstallation);
                    crmTrace.AppendLine("Retrieve ChimneyIsNewInstallation:" + ChimneyIsNewInstallation);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther))
                {
                    VentMaterialOther = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther, VentMaterialOther);
                    crmTrace.AppendLine("Retrieve VentMaterialOther:" + VentMaterialOther);
                }
                if (preImage.Attributes.Contains(BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber))
                {
                    AssociatedJobNumber = preImage.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber);
                    imageValues.Add(BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber, AssociatedJobNumber);
                    crmTrace.AppendLine("Retrieve AssociatedJobNumber:" + AssociatedJobNumber);
                }
                #endregion
                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }

        public static Dictionary<string, string> BoilerBuildScopeofWorkImageValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string BoilerScope = string.Empty;
            string FSScope = string.Empty;
            string FBScope = string.Empty;


            string Associatedpljobnumber = string.Empty;
            string MaximumAllowableWorkingPressure = string.Empty;
            string BoilerRating = string.Empty;
            string BoilerType = string.Empty;


            string BoilerClassification = string.Empty;
            string Heatingcapacitybtuhr = string.Empty;

            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {

                #region Boiler Scope of work Details


                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.BoilerScope))
                {
                    crmTrace.AppendLine("Retrieve BoilerScope");
                    BoilerScope = SetBooleanAttribute(preImage, BEScopeOfWorkEntityAttribute.BoilerScope);
                    imageValues.Add(BEScopeOfWorkEntityAttribute.BoilerScope, BoilerScope);
                    crmTrace.AppendLine("Retrieve BoilerScope:" + BoilerScope);
                }

                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.FSScope))
                {
                    crmTrace.AppendLine("Retrieve FSScope");
                    FSScope = SetBooleanAttribute(preImage, BEScopeOfWorkEntityAttribute.FSScope);
                    imageValues.Add(BEScopeOfWorkEntityAttribute.FSScope, FSScope);
                    crmTrace.AppendLine("Retrieve FSScope:" + FSScope);
                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.FBScope))
                {
                    crmTrace.AppendLine("Retrieve FBScope");
                    FBScope = SetBooleanAttribute(preImage, BEScopeOfWorkEntityAttribute.FBScope);
                    imageValues.Add(BEScopeOfWorkEntityAttribute.FBScope, FBScope);
                    crmTrace.AppendLine("Retrieve FBScope:" + FBScope);
                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.Associatedpljobnumber))
                {
                    crmTrace.AppendLine("Retrieve Associatedpljobnumber");


                    Associatedpljobnumber = preImage.GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.Associatedpljobnumber);
                    imageValues.Add(BEScopeOfWorkEntityAttribute.Associatedpljobnumber, Associatedpljobnumber);
                    crmTrace.AppendLine("Retrieve Associatedpljobnumber:" + Associatedpljobnumber);


                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure))
                {
                    crmTrace.AppendLine("Retrieve MaximumAllowableWorkingPressure");
                    MaximumAllowableWorkingPressure = preImage.GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure);
                    imageValues.Add(BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure, MaximumAllowableWorkingPressure);
                    crmTrace.AppendLine("Retrieve MaximumAllowableWorkingPressure:" + MaximumAllowableWorkingPressure);
                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.BoilerRating))
                {
                    crmTrace.AppendLine("Retrieve BoilerRating");
                    BoilerRating = preImage.FormattedValues[BEScopeOfWorkEntityAttribute.BoilerRating];
                    imageValues.Add(BEScopeOfWorkEntityAttribute.BoilerRating, BoilerRating);
                    crmTrace.AppendLine("Retrieve BoilerRating:" + BoilerRating);
                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.BoilerType))
                {
                    crmTrace.AppendLine("Retrieve BoilerType");
                    BoilerRating = preImage.FormattedValues[BEScopeOfWorkEntityAttribute.BoilerType];
                    imageValues.Add(BEScopeOfWorkEntityAttribute.BoilerType, BoilerType);
                    crmTrace.AppendLine("Retrieve BoilerType:" + BoilerType);
                }
                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.BoilerClassification))
                {
                    crmTrace.AppendLine("Retrieve BoilerClassification");
                    BoilerClassification = preImage.FormattedValues[BEScopeOfWorkEntityAttribute.BoilerClassification];
                    imageValues.Add(BEScopeOfWorkEntityAttribute.BoilerClassification, BoilerClassification);
                    crmTrace.AppendLine("Retrieve BoilerClassification:" + BoilerClassification);
                }

                if (preImage.Attributes.Contains(BEScopeOfWorkEntityAttribute.Heatingcapacitybtuhr))
                {
                    crmTrace.AppendLine("Retrieve Heatingcapacitybtuhr");
                    Heatingcapacitybtuhr = preImage.GetAttributeValue<int>(BEScopeOfWorkEntityAttribute.Heatingcapacitybtuhr).ToString();
                    imageValues.Add(BEScopeOfWorkEntityAttribute.Heatingcapacitybtuhr, Heatingcapacitybtuhr);
                    crmTrace.AppendLine("Retrieve Heatingcapacitybtuhr:" + Heatingcapacitybtuhr);
                }

                #endregion



                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - BoilerBuildDeviceImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        public static Dictionary<string, string> ZoningCharacterImageValuesValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string PrimaryStructuralSystem = string.Empty;
            string StructuralOccupancyRiskCat = string.Empty;
            string ProposedStructuralOccupancyRiskCat = string.Empty;
            string SeismicDesignCat = string.Empty;
            string ProposedSeismicDesignCategory = string.Empty;
            string Doesthe2014Codedesignationsapply = string.Empty;
            string ExistingOccupancyClassification = string.Empty;
            string ProposedOccupancyClassification = string.Empty;
            string Doesthe2014CodedesignationsapplyforCC = string.Empty;
            string ExistingConstructionClassification = string.Empty;
            string ProposedConstructionClassification = string.Empty;
            string MultipleDwellingClassification = string.Empty;
            string Mixedusebuilding = string.Empty;
            string BuldingType = string.Empty;
            string ProposedBuildingFootprint = string.Empty;
            string ExistingBuildingFootprint = string.Empty;

            string ExistingDwellingUnits = string.Empty;
            string ProposedDwellingUnits = string.Empty;
            string IsbuildingErrected = string.Empty;
            string EarliestCodeBuildiing = string.Empty;
            string NumberofStoriesajdbuld = string.Empty;
            string Isproposedconstlotline = string.Empty;
            string Heightoftallestbuld = string.Empty;
            string Isrequiresexcavation = string.Empty;

            string Exisitingbuildingstories = string.Empty;
            string Proposeebuildingstoriesft = string.Empty;
            string Buildingtype = string.Empty;

            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();

            try
            {
                crmTrace.AppendLine("Retrieve PrimaryStructuralSystem");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.PrimaryStructuralSystem))
                {
                    PrimaryStructuralSystem = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.PrimaryStructuralSystem];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.PrimaryStructuralSystem, PrimaryStructuralSystem);
                    crmTrace.AppendLine("Retrieve PrimaryStructuralSystem:" + PrimaryStructuralSystem);
                }
                crmTrace.AppendLine("Retrieve StructuralOccupancyRiskCat");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.StructuralOccupancyRiskCat))
                {
                    StructuralOccupancyRiskCat = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.StructuralOccupancyRiskCat];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.StructuralOccupancyRiskCat, StructuralOccupancyRiskCat);
                    crmTrace.AppendLine("Retrieve StructuralOccupancyRiskCat:" + StructuralOccupancyRiskCat);
                }
                crmTrace.AppendLine("Retrieve ProposedStructuralOccupancyRiskCat");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedStructuralOccupancyRiskCat))
                {
                    ProposedStructuralOccupancyRiskCat = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ProposedStructuralOccupancyRiskCat];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedStructuralOccupancyRiskCat, ProposedStructuralOccupancyRiskCat);
                    crmTrace.AppendLine("Retrieve ProposedStructuralOccupancyRiskCat:" + ProposedStructuralOccupancyRiskCat);
                }
                crmTrace.AppendLine("Retrieve SeismicDesignCat");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.SeismicDesignCat))
                {
                    SeismicDesignCat = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.SeismicDesignCat];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.SeismicDesignCat, SeismicDesignCat);
                    crmTrace.AppendLine("Retrieve SeismicDesignCat:" + SeismicDesignCat);
                }
                crmTrace.AppendLine("Retrieve ProposedSeismicDesignCategory");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedSeismicDesignCategory))
                {
                    ProposedSeismicDesignCategory = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ProposedSeismicDesignCategory];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedSeismicDesignCategory, ProposedSeismicDesignCategory);
                    crmTrace.AppendLine("Retrieve ProposedSeismicDesignCategory:" + ProposedSeismicDesignCategory);
                }
                crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Doesthe2014Codedesignationsapply))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply");
                    Doesthe2014Codedesignationsapply = SetBooleanAttribute(preImage, ZoningCharactersticsPW1AttributeNames.Doesthe2014Codedesignationsapply);
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Doesthe2014Codedesignationsapply, Doesthe2014Codedesignationsapply);
                    crmTrace.AppendLine("Retrieve Doesthe2014Codedesignationsapply:" + Doesthe2014Codedesignationsapply);
                }

                crmTrace.AppendLine("Retrieve ExistingOccupancyClassification");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ExistingOccupancyClassification))
                {
                    ExistingOccupancyClassification = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ExistingOccupancyClassification];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ExistingOccupancyClassification, ExistingOccupancyClassification);
                    crmTrace.AppendLine("Retrieve ExistingOccupancyClassification:" + ExistingOccupancyClassification);
                }
                crmTrace.AppendLine("Retrieve ProposedOccupancyClassification");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedOccupancyClassification))
                {
                    ProposedOccupancyClassification = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ProposedOccupancyClassification];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedOccupancyClassification, ProposedOccupancyClassification);
                    crmTrace.AppendLine("Retrieve ProposedOccupancyClassification:" + ProposedOccupancyClassification);
                }


                crmTrace.AppendLine("Retrieve Doesthe2014CodedesignationsapplyforCC");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Doesthe2014CodedesignationsapplyforCC))
                {
                    crmTrace.AppendLine("Retrieve Doesthe2014CodedesignationsapplyforCC");
                    Doesthe2014CodedesignationsapplyforCC = SetBooleanAttribute(preImage, ZoningCharactersticsPW1AttributeNames.Doesthe2014CodedesignationsapplyforCC);
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Doesthe2014CodedesignationsapplyforCC, Doesthe2014CodedesignationsapplyforCC);
                    crmTrace.AppendLine("Retrieve Doesthe2014CodedesignationsapplyforCC:" + Doesthe2014CodedesignationsapplyforCC);
                }
                crmTrace.AppendLine("Retrieve Mixedusebuilding");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Mixedusebuilding))
                {
                    Mixedusebuilding = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.Mixedusebuilding];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Mixedusebuilding, Mixedusebuilding);
                    crmTrace.AppendLine("Retrieve Mixedusebuilding:" + Mixedusebuilding);
                }
                //crmTrace.AppendLine("Retrieve Mixedusebuilding");
                //if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Mixedusebuilding))
                //{
                //    crmTrace.AppendLine("Retrieve Mixedusebuilding");
                //    Mixedusebuilding = SetBooleanAttribute(preImage, ZoningCharactersticsPW1AttributeNames.Mixedusebuilding);
                //    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Mixedusebuilding, Mixedusebuilding);
                //    crmTrace.AppendLine("Retrieve Mixedusebuilding:" + Mixedusebuilding);
                //}

                crmTrace.AppendLine("Retrieve ExistingConstructionClassification");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ExistingConstructionClassification))
                {
                    ExistingConstructionClassification = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ExistingConstructionClassification];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ExistingConstructionClassification, ExistingConstructionClassification);
                    crmTrace.AppendLine("Retrieve ExistingConstructionClassification:" + ExistingConstructionClassification);
                }
                crmTrace.AppendLine("Retrieve ProposedConstructionClassification");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedConstructionClassification))
                {
                    ProposedConstructionClassification = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.ProposedConstructionClassification];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedConstructionClassification, ProposedConstructionClassification);
                    crmTrace.AppendLine("Retrieve ProposedConstructionClassification:" + ProposedConstructionClassification);
                }
                crmTrace.AppendLine("Retrieve MultipleDwellingClassification");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.MultipleDwellingClassification))
                {
                    MultipleDwellingClassification = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.MultipleDwellingClassification];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.MultipleDwellingClassification, MultipleDwellingClassification);
                    crmTrace.AppendLine("Retrieve MultipleDwellingClassification:" + MultipleDwellingClassification);
                }
                crmTrace.AppendLine("Retrieve BuldingType");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.BuildingType))
                {
                    BuldingType = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.BuildingType];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.BuildingType, BuldingType);
                    crmTrace.AppendLine("Retrieve BuldingType:" + BuldingType);
                }

                crmTrace.AppendLine("Retrieve ExistingBuildingFootprint");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ExistingBuildingFootprint))
                {
                    ExistingBuildingFootprint = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.ExistingBuildingFootprint).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ExistingBuildingFootprint, ExistingBuildingFootprint);
                    crmTrace.AppendLine("Retrieve ExistingBuildingFootprint:" + ExistingBuildingFootprint);
                }
                crmTrace.AppendLine("Retrieve ProposedBuildingFootprint");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedBuildingFootprint))
                {
                    ProposedBuildingFootprint = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.ProposedBuildingFootprint).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedBuildingFootprint, ProposedBuildingFootprint);
                    crmTrace.AppendLine("Retrieve ProposedBuildingFootprint:" + ProposedBuildingFootprint);
                }

                //crmTrace.AppendLine("Retrieve Buildingtype");
                //if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Buildingtype))
                //{
                //    Buildingtype = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.Buildingtype];
                //    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Buildingtype, Buildingtype);
                //    crmTrace.AppendLine("Retrieve Buildingtype:" + Buildingtype);
                //}

                crmTrace.AppendLine("Retrieve Heightoftallestbuld");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Heightoftallestbuld))
                {
                    Heightoftallestbuld = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.Heightoftallestbuld];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Heightoftallestbuld, Heightoftallestbuld);
                    crmTrace.AppendLine("Retrieve Heightoftallestbuld:" + Heightoftallestbuld);
                }
                crmTrace.AppendLine("Retrieve NumberofStoriesajdbuld");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.NumberofStoriesajdbuld))
                {
                    NumberofStoriesajdbuld = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.NumberofStoriesajdbuld];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.NumberofStoriesajdbuld, NumberofStoriesajdbuld);
                    crmTrace.AppendLine("Retrieve NumberofStoriesajdbuld:" + NumberofStoriesajdbuld);
                }
                crmTrace.AppendLine("Retrieve EarliestCodeBuildiing");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.EarliestCodeBuildiing))
                {
                    EarliestCodeBuildiing = preImage.FormattedValues[ZoningCharactersticsPW1AttributeNames.EarliestCodeBuildiing];
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.EarliestCodeBuildiing, EarliestCodeBuildiing);
                    crmTrace.AppendLine("Retrieve EarliestCodeBuildiing:" + EarliestCodeBuildiing);
                }

                crmTrace.AppendLine("Retrieve Isrequiresexcavation");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Isrequiresexcavation))
                {
                    crmTrace.AppendLine("Retrieve Isrequiresexcavation");
                    Isrequiresexcavation = SetBooleanAttribute(preImage, ZoningCharactersticsPW1AttributeNames.Isrequiresexcavation);
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Isrequiresexcavation, Isrequiresexcavation);
                    crmTrace.AppendLine("Retrieve Isrequiresexcavation:" + Isrequiresexcavation);
                }
                crmTrace.AppendLine("Retrieve Isproposedconstlotline");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Isproposedconstlotline))
                {
                    crmTrace.AppendLine("Retrieve Isproposedconstlotline");
                    Isproposedconstlotline = SetBooleanAttribute(preImage, ZoningCharactersticsPW1AttributeNames.Isproposedconstlotline);
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Isproposedconstlotline, Isproposedconstlotline);
                    crmTrace.AppendLine("Retrieve Isproposedconstlotline:" + Isproposedconstlotline);
                }
                crmTrace.AppendLine("Retrieve ExistingDwellingUnits");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ExistingDwellingUnits))
                {
                    ExistingDwellingUnits = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.ExistingDwellingUnits).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ExistingDwellingUnits, ExistingDwellingUnits);
                    crmTrace.AppendLine("Retrieve ProposedBuildingFootprint:" + ExistingDwellingUnits);
                }
                crmTrace.AppendLine("Retrieve Exisitingbuildingstories");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Exisitingbuildingstories))
                {
                    Exisitingbuildingstories = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.Exisitingbuildingstories).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Exisitingbuildingstories, Exisitingbuildingstories);
                    crmTrace.AppendLine("Retrieve Exisitingbuildingstories:" + Exisitingbuildingstories);
                }
                crmTrace.AppendLine("Retrieve ProposedDwellingUnits");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.ProposedDwellingUnits))
                {
                    ProposedDwellingUnits = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.ProposedDwellingUnits).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.ProposedDwellingUnits, ProposedDwellingUnits);
                    crmTrace.AppendLine("Retrieve ProposedDwellingUnits:" + ProposedDwellingUnits);
                }
                crmTrace.AppendLine("Retrieve Proposeebuildingstoriesft");
                if (preImage.Attributes.Contains(ZoningCharactersticsPW1AttributeNames.Proposeebuildingstoriesft))
                {
                    Proposeebuildingstoriesft = preImage.GetAttributeValue<int>(ZoningCharactersticsPW1AttributeNames.Proposeebuildingstoriesft).ToString();
                    imageValues.Add(ZoningCharactersticsPW1AttributeNames.Proposeebuildingstoriesft, Proposeebuildingstoriesft);
                    crmTrace.AppendLine("Retrieve Proposeebuildingstoriesft:" + Proposeebuildingstoriesft);
                }
                return imageValues;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ZoningCharacterImageValuesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        public static Dictionary<string, string> WorkCostDetailsValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string WorkCategory = string.Empty;
            string WorkScope = string.Empty;
            string DescriptionofWork = string.Empty;
            string UnitCost = string.Empty;
            string AreaUnits = string.Empty;
            string TotalCost = string.Empty;
            string Name = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve WorkCategory");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.WorkCategory))
                {
                    WorkCategory = preImage.FormattedValues[WorkCostDetailsAttributeNames.WorkCategory];
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkCategory, WorkCategory);
                    crmTrace.AppendLine("Retrieve WorkCategory:" + WorkCategory);
                }
                crmTrace.AppendLine("Retrieve WorkScope");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.WorkScope))
                {
                    WorkScope = preImage.FormattedValues[WorkCostDetailsAttributeNames.WorkScope];
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkScope, WorkScope);
                    crmTrace.AppendLine("Retrieve WorkScope:" + WorkScope);
                }
                crmTrace.AppendLine("Retrieve DescriptionofWork");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.DescriptionofWork))
                {
                    DescriptionofWork = preImage.GetAttributeValue<string>(WorkCostDetailsAttributeNames.DescriptionofWork).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.DescriptionofWork, DescriptionofWork);
                    crmTrace.AppendLine("Retrieve DescriptionofWork:" + DescriptionofWork);
                }
                crmTrace.AppendLine("Retrieve UnitCost");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.UnitCost))
                {
                    UnitCost = ((Money)(preImage.Attributes[WorkCostDetailsAttributeNames.UnitCost])).Value.ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.UnitCost, UnitCost);
                    crmTrace.AppendLine("Retrieve UnitCost:" + UnitCost);
                }
                crmTrace.AppendLine("Retrieve AreaUnits");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.AreaUnits))
                {
                    AreaUnits = preImage.GetAttributeValue<int>(WorkCostDetailsAttributeNames.AreaUnits).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.AreaUnits, AreaUnits);
                    crmTrace.AppendLine("Retrieve AreaUnits:" + AreaUnits);
                }
                crmTrace.AppendLine("Retrieve TotalCost");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.TotalCost))
                {
                    TotalCost = ((Money)(preImage.Attributes[WorkCostDetailsAttributeNames.TotalCost])).Value.ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.TotalCost, TotalCost);
                    crmTrace.AppendLine("Retrieve TotalCost:" + TotalCost);
                }
                crmTrace.AppendLine("Retrieve Name");
                if (preImage.Attributes.Contains(WorkCostDetailsAttributeNames.Name))
                {
                    Name = preImage.GetAttributeValue<string>(WorkCostDetailsAttributeNames.Name).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.Name, Name);
                    crmTrace.AppendLine("Retrieve Name:" + Name);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - WorkCostDetailsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Get Values from SpecialInspectionCategories Entity

        public static Dictionary<string, string> SpecialInspectionCategoriesValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string AddRequirement = string.Empty;
            string FilingScope = string.Empty;
            string SpecialInspector = string.Empty;
            string ResponsibilityofIdentifingRequirement = string.Empty;
            string ICertifyCompleteInspectionsTests = string.Empty;
            string IWithdrawResponsibility = string.Empty;
            string DateForIdentificationofResponsibility = string.Empty;
            string DateForCertifyCompleteInspections = string.Empty;
            string DateForWithdrawResposibility = string.Empty;
            string CodeSection = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {

                crmTrace.AppendLine("Retrieve AddRequirement");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.AddRequirement))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.AddRequirement);
                    if (reqLookUp != null)
                    {
                        AddRequirement = reqLookUp.Name;
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.AddRequirement, AddRequirement);
                    }
                    crmTrace.AppendLine("Retrieve AddRequirement:" + AddRequirement);
                }
                crmTrace.AppendLine("Retrieve FilingScope");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.FilingScope))
                {
                    FilingScope = preImage.FormattedValues[SpecialInspectionCategoriesAttributeNames.FilingScope];
                    imageValues.Add(SpecialInspectionCategoriesAttributeNames.FilingScope, FilingScope);
                    crmTrace.AppendLine("Retrieve FilingScope:" + FilingScope);
                }
                crmTrace.AppendLine("Retrieve SpecialInspector");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.SpecialInspector))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(SpecialInspectionCategoriesAttributeNames.SpecialInspector);
                    if (reqLookUp != null)
                    {
                        SpecialInspector = reqLookUp.Name;
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.SpecialInspector, SpecialInspector);
                    }
                    crmTrace.AppendLine("Retrieve SpecialInspector:" + SpecialInspector);
                }
                crmTrace.AppendLine("Retrieve ResponsibilityofIdentifingRequirement");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.ResponsibilityofIdentifingRequirement))
                {
                    ResponsibilityofIdentifingRequirement = SetBooleanAttribute(preImage, SpecialInspectionCategoriesAttributeNames.ResponsibilityofIdentifingRequirement);
                    imageValues.Add(SpecialInspectionCategoriesAttributeNames.ResponsibilityofIdentifingRequirement, ResponsibilityofIdentifingRequirement);
                    crmTrace.AppendLine("Retrieve ResponsibilityofIdentifingRequirement:" + ResponsibilityofIdentifingRequirement);
                }
                crmTrace.AppendLine("Retrieve ICertifyCompleteInspectionsTests");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests))
                {
                    ICertifyCompleteInspectionsTests = SetBooleanAttribute(preImage, SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests);
                    imageValues.Add(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests, ICertifyCompleteInspectionsTests);
                    crmTrace.AppendLine("Retrieve ICertifyCompleteInspectionsTests:" + ICertifyCompleteInspectionsTests);
                }
                crmTrace.AppendLine("Retrieve IWithdrawResponsibility");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.IWithdrawResponsibility))
                {
                    IWithdrawResponsibility = SetBooleanAttribute(preImage, SpecialInspectionCategoriesAttributeNames.IWithdrawResponsibility);
                    imageValues.Add(SpecialInspectionCategoriesAttributeNames.IWithdrawResponsibility, IWithdrawResponsibility);
                    crmTrace.AppendLine("Retrieve IWithdrawResponsibility:" + IWithdrawResponsibility);
                }
                crmTrace.AppendLine("Retrieve DateForIdentificationofResponsibility");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForIdentificationofResponsibility = dateTime.ToString();
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility, DateForIdentificationofResponsibility);
                    }
                    else
                    {
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForIdentificationofResponsibility:" + DateForIdentificationofResponsibility);
                }
                crmTrace.AppendLine("Retrieve DateForCertifyCompleteInspections");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForCertifyCompleteInspections = dateTime.ToString();
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections, DateForCertifyCompleteInspections);
                    }
                    else
                    {
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForCertifyCompleteInspections:" + DateForCertifyCompleteInspections);
                }
                crmTrace.AppendLine("Retrieve DateForWithdrawResposibility");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.DateForWithdrawResposibility))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(SpecialInspectionCategoriesAttributeNames.DateForWithdrawResposibility);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForWithdrawResposibility = dateTime.ToString();
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForWithdrawResposibility, DateForWithdrawResposibility);
                    }
                    else
                    {
                        imageValues.Add(SpecialInspectionCategoriesAttributeNames.DateForWithdrawResposibility, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForWithdrawResposibility:" + DateForWithdrawResposibility);
                }
                crmTrace.AppendLine("Retrieve CodeSection");
                if (preImage.Attributes.Contains(SpecialInspectionCategoriesAttributeNames.CodeSection))
                {
                    CodeSection = preImage.GetAttributeValue<string>(SpecialInspectionCategoriesAttributeNames.CodeSection).ToString();
                    imageValues.Add(SpecialInspectionCategoriesAttributeNames.CodeSection, CodeSection);
                    crmTrace.AppendLine("Retrieve CodeSection:" + CodeSection);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SpecialInspectionCategoriesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Get Values from ProgressInspectionCategory Entity

        public static Dictionary<string, string> ProgressInspectionCategoryValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string AddRequirement = string.Empty;
            string FilingScope = string.Empty;
            string ProgressInspector = string.Empty;
            string ResponsibilityofIdentifingRequirement = string.Empty;
            string ICertifyCompleteInspectionsTests = string.Empty;
            string IWithdrawResponsibility = string.Empty;
            string DateForIdentificationofResponsibility = string.Empty;
            string DateForCertifyCompleteInspections = string.Empty;
            string DateForWithdrawResposibility = string.Empty;
            string CodeSection = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve AddRequirement");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.AddRequirement))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(ProgressInspectionCategoryAttributeNames.AddRequirement);
                    if (reqLookUp != null)
                    {
                        AddRequirement = reqLookUp.Name;
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, AddRequirement);
                    }
                    crmTrace.AppendLine("Retrieve AddRequirement:" + AddRequirement);
                }
                crmTrace.AppendLine("Retrieve FilingScope");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.FilingScope))
                {
                    FilingScope = preImage.FormattedValues[ProgressInspectionCategoryAttributeNames.FilingScope];
                    imageValues.Add(ProgressInspectionCategoryAttributeNames.FilingScope, FilingScope);
                    crmTrace.AppendLine("Retrieve FilingScope:" + FilingScope);
                }
                crmTrace.AppendLine("Retrieve ProgressInspector");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.ProgressInspector))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(ProgressInspectionCategoryAttributeNames.ProgressInspector);
                    if (reqLookUp != null)
                    {
                        ProgressInspector = reqLookUp.Name;
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.ProgressInspector, ProgressInspector);
                    }
                    crmTrace.AppendLine("Retrieve ProgressInspector:" + ProgressInspector);
                }
                crmTrace.AppendLine("Retrieve ResponsibilityofIdentifingRequirement");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.ResponsibilityofIdentifingRequirement))
                {
                    ResponsibilityofIdentifingRequirement = SetBooleanAttribute(preImage, ProgressInspectionCategoryAttributeNames.ResponsibilityofIdentifingRequirement);
                    imageValues.Add(ProgressInspectionCategoryAttributeNames.ResponsibilityofIdentifingRequirement, ResponsibilityofIdentifingRequirement);
                    crmTrace.AppendLine("Retrieve ResponsibilityofIdentifingRequirement:" + ResponsibilityofIdentifingRequirement);
                }
                crmTrace.AppendLine("Retrieve ICertifyCompleteInspectionsTests");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests))
                {
                    ICertifyCompleteInspectionsTests = SetBooleanAttribute(preImage, ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests);
                    imageValues.Add(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests, ICertifyCompleteInspectionsTests);
                    crmTrace.AppendLine("Retrieve ICertifyCompleteInspectionsTests:" + ICertifyCompleteInspectionsTests);
                }
                crmTrace.AppendLine("Retrieve IWithdrawResponsibility");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.IWithdrawResponsibility))
                {
                    IWithdrawResponsibility = SetBooleanAttribute(preImage, ProgressInspectionCategoryAttributeNames.IWithdrawResponsibility);
                    imageValues.Add(ProgressInspectionCategoryAttributeNames.IWithdrawResponsibility, IWithdrawResponsibility);
                    crmTrace.AppendLine("Retrieve IWithdrawResponsibility:" + IWithdrawResponsibility);
                }
                crmTrace.AppendLine("Retrieve DateForIdentificationofResponsibility");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.DateForIdentificationofResponsibility))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(ProgressInspectionCategoryAttributeNames.DateForIdentificationofResponsibility);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForIdentificationofResponsibility = dateTime.ToString();
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForIdentificationofResponsibility, DateForIdentificationofResponsibility);
                    }
                    else
                    {
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForIdentificationofResponsibility, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForIdentificationofResponsibility:" + DateForIdentificationofResponsibility);
                }
                crmTrace.AppendLine("Retrieve DateForCertifyCompleteInspections");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.DateForCertifyCompleteInspections))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(ProgressInspectionCategoryAttributeNames.DateForCertifyCompleteInspections);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForCertifyCompleteInspections = dateTime.ToString();
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForCertifyCompleteInspections, DateForCertifyCompleteInspections);
                    }
                    else
                    {
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForCertifyCompleteInspections, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForCertifyCompleteInspections:" + DateForCertifyCompleteInspections);
                }
                crmTrace.AppendLine("Retrieve DateForWithdrawResposibility");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.DateForWithdrawResposibility))
                {
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(ProgressInspectionCategoryAttributeNames.DateForWithdrawResposibility);
                    if (dateTime != DateTime.MinValue)
                    {
                        DateForWithdrawResposibility = dateTime.ToString();
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForWithdrawResposibility, DateForWithdrawResposibility);
                    }
                    else
                    {
                        imageValues.Add(ProgressInspectionCategoryAttributeNames.DateForWithdrawResposibility, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve DateForWithdrawResposibility:" + DateForWithdrawResposibility);
                }
                crmTrace.AppendLine("Retrieve CodeSection");
                if (preImage.Attributes.Contains(ProgressInspectionCategoryAttributeNames.CodeSection))
                {
                    CodeSection = preImage.GetAttributeValue<string>(ProgressInspectionCategoryAttributeNames.CodeSection).ToString();
                    imageValues.Add(ProgressInspectionCategoryAttributeNames.CodeSection, CodeSection);
                    crmTrace.AppendLine("Retrieve CodeSection:" + CodeSection);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Set boolen value to preImage entity
        private static string SetBooleanAttribute(Entity preImage, string attributeName)
        {
            bool boolObj = preImage.GetAttributeValue<bool>(attributeName);
            if (boolObj)
            {
                attributeName = "Yes";
            }
            else
            {
                attributeName = "No";
            }
            return attributeName;
        }
        #endregion
        #region Get Text from optioset value
        public static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {
            string selectedOptionLabel = string.Empty;
            try
            {
                OptionMetadata[] optionList = null;
                RetrieveAttributeRequest retrieveAttributeRequest = new
                RetrieveAttributeRequest
                {

                    EntityLogicalName = entityName,

                    LogicalName = attributeName,

                    RetrieveAsIfPublished = true

                };
                // Execute the request.
                RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                string restype = retrieveAttributeResponse.AttributeMetadata.GetType().ToString();
                // Access the retrieved attribute.
                if (restype == "Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata")
                {
                    Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata stateatt = (Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
                    optionList = stateatt.OptionSet.Options.ToArray();
                }
                else if (restype == "Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata")
                {
                    Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

                    retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
                    optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
                }

                foreach (OptionMetadata oMD in optionList)
                {
                    if (oMD.Value == selectedValue)
                    {
                        selectedOptionLabel = oMD.Label.UserLocalizedLabel.Label;

                    }

                }
                return selectedOptionLabel;
                //crmTrace.AppendLine("Retrieve OptionText completed!");
            }
            catch (Exception ex)
            {
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "GetOptionsSetTextOnValue", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", (ex.InnerException != null ? ex.InnerException.ToString() : string.Empty), "browserinfo");
                return selectedOptionLabel;

            }

        }
        #endregion
        #region Get Values from AntennaScopeOfWork Entity
        public static Dictionary<string, string> AntennaScopeOfWorkValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string AntennastobeModifiedReplaced = string.Empty; //Whole Number
            string AntennastobeRemoved = string.Empty; //Whole Number
            string ArraystobeModifiedReplaced = string.Empty; //Whole Number
            string ArraystobeRemoved = string.Empty; //Whole Number
            string Bulkhead = string.Empty; //Two Options
            string Chimney = string.Empty; //Two Options
            string EmergencyPowerSystem = string.Empty; //Two Options
            string ExistingAntennas = string.Empty; //Two Options
            string Facade = string.Empty; //Two Options
            string IsMechanicalWorkProposed = string.Empty; //Two Options
            string MechanicalandElectricalEquipmentLocation = string.Empty; //String
            string Monopole = string.Empty; //Two Options
            string NewAntennasOrArrays = string.Empty; //Two Options
            string NumberofArrays = string.Empty; //Whole Number
            string NumberofExistingAntennas = string.Empty; //Whole Number
            string NumberofExistingRRH = string.Empty; //Whole Number
            string NumberofNewAntennas = string.Empty; //Whole Number
            string NumberofNewArrays = string.Empty; //Whole Number
            string NumberofNewRRH = string.Empty; //Whole Number
            string NumberofNewSectors = string.Empty; //Whole Number
            string NumberofSectors = string.Empty; //Whole Number
            string OnGrade = string.Empty; //Two Options
            string OtherStructure = string.Empty; //Two Options
            string Parapet = string.Empty; //Two Options
            string Roof = string.Empty; //Two Options
            string RRHtobeModifiedReplaced = string.Empty; //Whole Number
            string RRHtobeRemoved = string.Empty; //Whole Number
            string SectorstobeModifiedReplaced = string.Empty; //Whole Number
            string SectorstobeRemoved = string.Empty; //Whole Number
            string TypeOfStructuralWork = string.Empty; //Two Options
            string WaterTank = string.Empty; //Two Options
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.AntennastobeModifiedReplaced))
                {
                    crmTrace.AppendLine("Retrieve AntennastobeModifiedReplaced");
                    AntennastobeModifiedReplaced = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.AntennastobeModifiedReplaced).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.AntennastobeModifiedReplaced, AntennastobeModifiedReplaced);
                    crmTrace.AppendLine("Retrieve AntennastobeModifiedReplaced:" + AntennastobeModifiedReplaced);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.AntennastobeRemoved))
                {
                    crmTrace.AppendLine("Retrieve AntennastobeRemoved");
                    AntennastobeRemoved = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.AntennastobeRemoved).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.AntennastobeRemoved, AntennastobeRemoved);
                    crmTrace.AppendLine("Retrieve AntennastobeRemoved:" + AntennastobeRemoved);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.ArraystobeModifiedReplaced))
                {
                    crmTrace.AppendLine("Retrieve ArraystobeModifiedReplaced");
                    ArraystobeModifiedReplaced = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.ArraystobeModifiedReplaced).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.ArraystobeModifiedReplaced, ArraystobeModifiedReplaced);
                    crmTrace.AppendLine("Retrieve ArraystobeModifiedReplaced:" + ArraystobeModifiedReplaced);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.ArraystobeRemoved))
                {
                    crmTrace.AppendLine("Retrieve ArraystobeRemoved");
                    ArraystobeRemoved = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.ArraystobeRemoved).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.ArraystobeRemoved, ArraystobeRemoved);
                    crmTrace.AppendLine("Retrieve ArraystobeRemoved:" + ArraystobeRemoved);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Bulkhead))
                {
                    crmTrace.AppendLine("Retrieve Bulkhead");
                    Bulkhead = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Bulkhead);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Bulkhead, Bulkhead);
                    crmTrace.AppendLine("Retrieve Bulkhead:" + Bulkhead);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Chimney))
                {
                    crmTrace.AppendLine("Retrieve Chimney");
                    Chimney = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Chimney);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Chimney, Chimney);
                    crmTrace.AppendLine("Retrieve Chimney:" + Chimney);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.EmergencyPowerSystem))
                {
                    crmTrace.AppendLine("Retrieve EmergencyPowerSystem");
                    EmergencyPowerSystem = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.EmergencyPowerSystem);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.EmergencyPowerSystem, EmergencyPowerSystem);
                    crmTrace.AppendLine("Retrieve EmergencyPowerSystem:" + EmergencyPowerSystem);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.ExistingAntennas))
                {
                    crmTrace.AppendLine("Retrieve ExistingAntennas");
                    ExistingAntennas = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.ExistingAntennas);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.ExistingAntennas, ExistingAntennas);
                    crmTrace.AppendLine("Retrieve ExistingAntennas:" + ExistingAntennas);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Facade))
                {
                    crmTrace.AppendLine("Retrieve Facade");
                    Facade = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Facade);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Facade, Facade);
                    crmTrace.AppendLine("Retrieve Facade:" + Facade);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.IsMechanicalWorkProposed))
                {
                    crmTrace.AppendLine("Retrieve IsMechanicalWorkProposed");
                    IsMechanicalWorkProposed = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.IsMechanicalWorkProposed);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.IsMechanicalWorkProposed, IsMechanicalWorkProposed);
                    crmTrace.AppendLine("Retrieve IsMechanicalWorkProposed:" + IsMechanicalWorkProposed);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.MechanicalandElectricalEquipmentLocation))
                {
                    crmTrace.AppendLine("Retrieve MechanicalandElectricalEquipmentLocation");
                    MechanicalandElectricalEquipmentLocation = preImage.GetAttributeValue<string>(AntennaScopeOfWorkEntityAttributeName.MechanicalandElectricalEquipmentLocation).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.MechanicalandElectricalEquipmentLocation, MechanicalandElectricalEquipmentLocation);
                    crmTrace.AppendLine("Retrieve MechanicalandElectricalEquipmentLocation:" + MechanicalandElectricalEquipmentLocation);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Monopole))
                {
                    crmTrace.AppendLine("Retrieve Monopole");
                    Monopole = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Monopole);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Monopole, Monopole);
                    crmTrace.AppendLine("Retrieve Monopole:" + Monopole);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NewAntennasOrArrays))
                {
                    crmTrace.AppendLine("Retrieve NewAntennasOrArrays");
                    NewAntennasOrArrays = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.NewAntennasOrArrays);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NewAntennasOrArrays, NewAntennasOrArrays);
                    crmTrace.AppendLine("Retrieve NewAntennasOrArrays:" + NewAntennasOrArrays);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofArrays))
                {
                    crmTrace.AppendLine("Retrieve NumberofArrays");
                    NumberofArrays = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofArrays).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofArrays, NumberofArrays);
                    crmTrace.AppendLine("Retrieve NumberofArrays:" + NumberofArrays);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofExistingAntennas))
                {
                    crmTrace.AppendLine("Retrieve NumberofExistingAntennas");
                    NumberofExistingAntennas = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofExistingAntennas).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofExistingAntennas, NumberofExistingAntennas);
                    crmTrace.AppendLine("Retrieve NumberofExistingAntennas:" + NumberofExistingAntennas);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofExistingRRH))
                {
                    crmTrace.AppendLine("Retrieve NumberofExistingRRH");
                    NumberofExistingRRH = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofExistingRRH).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofExistingRRH, NumberofExistingRRH);
                    crmTrace.AppendLine("Retrieve NumberofExistingRRH:" + NumberofExistingRRH);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofNewAntennas))
                {
                    crmTrace.AppendLine("Retrieve NumberofNewAntennas");
                    NumberofNewAntennas = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofNewAntennas).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofNewAntennas, NumberofNewAntennas);
                    crmTrace.AppendLine("Retrieve NumberofNewAntennas:" + NumberofNewAntennas);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofNewArrays))
                {
                    crmTrace.AppendLine("Retrieve NumberofNewArrays");
                    NumberofNewArrays = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofNewArrays).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofNewArrays, NumberofNewArrays);
                    crmTrace.AppendLine("Retrieve NumberofNewArrays:" + NumberofNewArrays);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofNewRRH))
                {
                    crmTrace.AppendLine("Retrieve NumberofNewRRH");
                    NumberofNewRRH = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofNewRRH).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofNewRRH, NumberofNewRRH);
                    crmTrace.AppendLine("Retrieve NumberofNewRRH:" + NumberofNewRRH);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofNewSectors))
                {
                    crmTrace.AppendLine("Retrieve NumberofNewSectors");
                    NumberofNewSectors = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofNewSectors).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofNewSectors, NumberofNewSectors);
                    crmTrace.AppendLine("Retrieve NumberofNewSectors:" + NumberofNewSectors);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.NumberofSectors))
                {
                    crmTrace.AppendLine("Retrieve NumberofSectors");
                    NumberofSectors = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.NumberofSectors).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.NumberofSectors, NumberofSectors);
                    crmTrace.AppendLine("Retrieve NumberofSectors:" + NumberofSectors);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.OnGrade))
                {
                    crmTrace.AppendLine("Retrieve OnGrade");
                    OnGrade = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.OnGrade);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.OnGrade, OnGrade);
                    crmTrace.AppendLine("Retrieve OnGrade:" + OnGrade);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.OtherStructure))
                {
                    crmTrace.AppendLine("Retrieve OtherStructure");
                    OtherStructure = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.OtherStructure);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.OtherStructure, OtherStructure);
                    crmTrace.AppendLine("Retrieve OtherStructure:" + OtherStructure);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Parapet))
                {
                    crmTrace.AppendLine("Retrieve Parapet");
                    Parapet = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Parapet);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Parapet, Parapet);
                    crmTrace.AppendLine("Retrieve Parapet:" + Parapet);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.Roof))
                {
                    crmTrace.AppendLine("Retrieve Roof");
                    Roof = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.Roof);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.Roof, Roof);
                    crmTrace.AppendLine("Retrieve Roof:" + Roof);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.RRHtobeModifiedReplaced))
                {
                    crmTrace.AppendLine("Retrieve RRHtobeModifiedReplaced");
                    RRHtobeModifiedReplaced = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.RRHtobeModifiedReplaced).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.RRHtobeModifiedReplaced, RRHtobeModifiedReplaced);
                    crmTrace.AppendLine("Retrieve RRHtobeModifiedReplaced:" + RRHtobeModifiedReplaced);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.RRHtobeRemoved))
                {
                    crmTrace.AppendLine("Retrieve RRHtobeRemoved");
                    RRHtobeRemoved = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.RRHtobeRemoved).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.RRHtobeRemoved, RRHtobeRemoved);
                    crmTrace.AppendLine("Retrieve RRHtobeRemoved:" + RRHtobeRemoved);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.SectorstobeModifiedReplaced))
                {
                    crmTrace.AppendLine("Retrieve SectorstobeModifiedReplaced");
                    SectorstobeModifiedReplaced = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.SectorstobeModifiedReplaced).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.SectorstobeModifiedReplaced, SectorstobeModifiedReplaced);
                    crmTrace.AppendLine("Retrieve SectorstobeModifiedReplaced:" + SectorstobeModifiedReplaced);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.SectorstobeRemoved))
                {
                    crmTrace.AppendLine("Retrieve SectorstobeRemoved");
                    SectorstobeRemoved = preImage.GetAttributeValue<int>(AntennaScopeOfWorkEntityAttributeName.SectorstobeRemoved).ToString();
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.SectorstobeRemoved, SectorstobeRemoved);
                    crmTrace.AppendLine("Retrieve SectorstobeRemoved:" + SectorstobeRemoved);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.TypeOfStructuralWork))
                {
                    crmTrace.AppendLine("Retrieve TypeOfStructuralWork");
                    TypeOfStructuralWork = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.TypeOfStructuralWork);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.TypeOfStructuralWork, TypeOfStructuralWork);
                    crmTrace.AppendLine("Retrieve TypeOfStructuralWork:" + TypeOfStructuralWork);
                }

                if (preImage.Attributes.Contains(AntennaScopeOfWorkEntityAttributeName.WaterTank))
                {
                    crmTrace.AppendLine("Retrieve WaterTank");
                    WaterTank = SetBooleanAttribute(preImage, AntennaScopeOfWorkEntityAttributeName.WaterTank);
                    imageValues.Add(AntennaScopeOfWorkEntityAttributeName.WaterTank, WaterTank);
                    crmTrace.AppendLine("Retrieve WaterTank:" + WaterTank);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Get Values from AntennaDS1 Entity
        public static Dictionary<string, string> AntennaDemolitionSubmittalValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string DemolitionType = string.Empty; //Two Options
            string ExteriorWorkGeneralDescription = string.Empty; //String
            string IsSigned = string.Empty; //Two Options
            string NonMechanicalGeneralDescription = string.Empty; //String
            string OtherEquipmentGeneralDescription = string.Empty; //String
            string OwnerName = string.Empty; //String
            string SignedDate = string.Empty; //DateTime
            string SubmittalType = string.Empty; //Two Options
            string UseHandheldMechanicals = string.Empty; //Two Options
            string UseNonmechanicalMethods = string.Empty; //Two Options
            string UseOtherMechanicals = string.Empty; //Two Options
            string WorkOnExteriors = string.Empty; //Two Options

            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.DemolitionType))
                {
                    crmTrace.AppendLine("Retrieve DemolitionType");
                    DemolitionType = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.DemolitionType);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.DemolitionType, DemolitionType);
                    crmTrace.AppendLine("Retrieve DemolitionType:" + DemolitionType);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.ExteriorWorkGeneralDescription))
                {
                    crmTrace.AppendLine("Retrieve ExteriorWorkGeneralDescription");
                    ExteriorWorkGeneralDescription = preImage.GetAttributeValue<string>(AntennaDemolitionSubmittalCertificationEntityAttributeName.ExteriorWorkGeneralDescription).ToString();
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.ExteriorWorkGeneralDescription, ExteriorWorkGeneralDescription);
                    crmTrace.AppendLine("Retrieve ExteriorWorkGeneralDescription:" + ExteriorWorkGeneralDescription);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.IsSigned))
                {
                    crmTrace.AppendLine("Retrieve IsSigned");
                    IsSigned = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.IsSigned);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.IsSigned, IsSigned);
                    crmTrace.AppendLine("Retrieve IsSigned:" + IsSigned);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.NonMechanicalGeneralDescription))
                {
                    crmTrace.AppendLine("Retrieve NonMechanicalGeneralDescription");
                    NonMechanicalGeneralDescription = preImage.GetAttributeValue<string>(AntennaDemolitionSubmittalCertificationEntityAttributeName.NonMechanicalGeneralDescription).ToString();
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.NonMechanicalGeneralDescription, NonMechanicalGeneralDescription);
                    crmTrace.AppendLine("Retrieve NonMechanicalGeneralDescription:" + NonMechanicalGeneralDescription);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.OtherEquipmentGeneralDescription))
                {
                    crmTrace.AppendLine("Retrieve OtherEquipmentGeneralDescription");
                    OtherEquipmentGeneralDescription = preImage.GetAttributeValue<string>(AntennaDemolitionSubmittalCertificationEntityAttributeName.OtherEquipmentGeneralDescription).ToString();
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.OtherEquipmentGeneralDescription, OtherEquipmentGeneralDescription);
                    crmTrace.AppendLine("Retrieve OtherEquipmentGeneralDescription:" + OtherEquipmentGeneralDescription);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.OwnerName))
                {
                    crmTrace.AppendLine("Retrieve OwnerName");
                    OwnerName = preImage.GetAttributeValue<string>(AntennaDemolitionSubmittalCertificationEntityAttributeName.OwnerName).ToString();
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.OwnerName, OwnerName);
                    crmTrace.AppendLine("Retrieve OwnerName:" + OwnerName);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.SignedDate))
                {
                    crmTrace.AppendLine("Retrieve SignedDate");
                    DateTime dateTime = preImage.GetAttributeValue<DateTime>(AntennaDemolitionSubmittalCertificationEntityAttributeName.SignedDate);
                    if (dateTime != DateTime.MinValue)
                    {
                        SignedDate = dateTime.ToString();
                        imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.SignedDate, SignedDate);
                    }
                    else
                    {
                        imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.SignedDate, DateTime.MinValue.ToString());
                    }
                    crmTrace.AppendLine("Retrieve SignedDate:" + SignedDate);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.SubmittalType))
                {
                    crmTrace.AppendLine("Retrieve SubmittalType");
                    SubmittalType = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.SubmittalType);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.SubmittalType, SubmittalType);
                    crmTrace.AppendLine("Retrieve SubmittalType:" + SubmittalType);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseHandheldMechanicals))
                {
                    crmTrace.AppendLine("Retrieve UseHandheldMechanicals");
                    UseHandheldMechanicals = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.UseHandheldMechanicals);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseHandheldMechanicals, UseHandheldMechanicals);
                    crmTrace.AppendLine("Retrieve UseHandheldMechanicals:" + UseHandheldMechanicals);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseNonmechanicalMethods))
                {
                    crmTrace.AppendLine("Retrieve UseNonmechanicalMethods");
                    UseNonmechanicalMethods = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.UseNonmechanicalMethods);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseNonmechanicalMethods, UseNonmechanicalMethods);
                    crmTrace.AppendLine("Retrieve UseNonmechanicalMethods:" + UseNonmechanicalMethods);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals))
                {
                    crmTrace.AppendLine("Retrieve UseOtherMechanicals");
                    UseOtherMechanicals = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals, UseOtherMechanicals);
                    crmTrace.AppendLine("Retrieve UseOtherMechanicals:" + UseOtherMechanicals);
                }

                if (preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.WorkOnExteriors))
                {
                    crmTrace.AppendLine("Retrieve WorkOnExteriors");
                    WorkOnExteriors = SetBooleanAttribute(preImage, AntennaDemolitionSubmittalCertificationEntityAttributeName.WorkOnExteriors);
                    imageValues.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.WorkOnExteriors, WorkOnExteriors);
                    crmTrace.AppendLine("Retrieve WorkOnExteriors:" + WorkOnExteriors);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Get Values from CurbCutQuestionnaire Entity
        public static Dictionary<string, string> CurbCutQuestionnaireValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string AgenciesRequiredDocument = string.Empty; //Option Set
            string AttachedGarage = string.Empty; //Two Option
            string CurbCutsidenearesttothepropertyline = string.Empty; //Option Set
            string Curbcutslocatedinfronttoadjoiningproperties = string.Empty; //Two Option
            string DetachedGarage = string.Empty; //Two Option
            string Distancefromnearestpropertyline = string.Empty; //Floating Point
            string Distancetonearestcorner = string.Empty; //Floating Point
            string Isthecurbcutongrade = string.Empty; //Two Option
            string Isthecurbcutonotherstructure = string.Empty; //Two Option
            string Isthecurbcutoveravault = string.Empty; //Two Option
            string LoadingBerth = string.Empty; //Two Option
            string ParkingGarage = string.Empty; //Two Option
            string ParkingLot = string.Empty; //Two Option
            string ParkingPad = string.Empty; //Two Option
            string PrivateDriveRoad = string.Empty; //Two Option
            string Sideofthestreetiscurbcuton = string.Empty; //Option Set
            string Sidewalkobstructionstobedestroyedrelocated = string.Empty; //Two Option
            string Sidewalkobstructionswithin8ftofproposedCC = string.Empty; //Two Option
            string Sizeofcutwithsplays = string.Empty; //Floating Point
            string Tostreet = string.Empty; //String            
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.AgenciesRequiredDocument))
                {
                    crmTrace.AppendLine("Retrieve AgenciesRequiredDocument");
                    AgenciesRequiredDocument = preImage.FormattedValues[CurbCutQuestionnaireEntityAttributeName.AgenciesRequiredDocument];
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.AgenciesRequiredDocument, AgenciesRequiredDocument);
                    crmTrace.AppendLine("Retrieve AgenciesRequiredDocument:" + AgenciesRequiredDocument);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.AttachedGarage))
                {
                    crmTrace.AppendLine("Retrieve AttachedGarage");
                    AttachedGarage = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.AttachedGarage);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.AttachedGarage, AttachedGarage);
                    crmTrace.AppendLine("Retrieve AttachedGarage:" + AttachedGarage);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.CurbCutsidenearesttothepropertyline))
                {
                    crmTrace.AppendLine("Retrieve CurbCutsidenearesttothepropertyline");
                    CurbCutsidenearesttothepropertyline = preImage.FormattedValues[CurbCutQuestionnaireEntityAttributeName.CurbCutsidenearesttothepropertyline];
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.CurbCutsidenearesttothepropertyline, CurbCutsidenearesttothepropertyline);
                    crmTrace.AppendLine("Retrieve CurbCutsidenearesttothepropertyline:" + CurbCutsidenearesttothepropertyline);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Curbcutslocatedinfronttoadjoiningproperties))
                {
                    crmTrace.AppendLine("Retrieve Curbcutslocatedinfronttoadjoiningproperties");
                    Curbcutslocatedinfronttoadjoiningproperties = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Curbcutslocatedinfronttoadjoiningproperties);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Curbcutslocatedinfronttoadjoiningproperties, Curbcutslocatedinfronttoadjoiningproperties);
                    crmTrace.AppendLine("Retrieve Curbcutslocatedinfronttoadjoiningproperties:" + Curbcutslocatedinfronttoadjoiningproperties);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.DetachedGarage))
                {
                    crmTrace.AppendLine("Retrieve DetachedGarage");
                    DetachedGarage = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.DetachedGarage);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.DetachedGarage, DetachedGarage);
                    crmTrace.AppendLine("Retrieve DetachedGarage:" + DetachedGarage);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Distancefromnearestpropertyline))
                {
                    crmTrace.AppendLine("Retrieve Distancefromnearestpropertyline");
                    Distancefromnearestpropertyline = (preImage.GetAttributeValue<double>(CurbCutQuestionnaireEntityAttributeName.Distancefromnearestpropertyline)).ToString();
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Distancefromnearestpropertyline, Distancefromnearestpropertyline);
                    crmTrace.AppendLine("Retrieve Distancefromnearestpropertyline:" + Distancefromnearestpropertyline);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Distancetonearestcorner))
                {
                    crmTrace.AppendLine("Retrieve Distancetonearestcorner");
                    Distancetonearestcorner = (preImage.GetAttributeValue<double>(CurbCutQuestionnaireEntityAttributeName.Distancetonearestcorner)).ToString();
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Distancetonearestcorner, Distancetonearestcorner);
                    crmTrace.AppendLine("Retrieve Distancetonearestcorner:" + Distancetonearestcorner);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutongrade))
                {
                    crmTrace.AppendLine("Retrieve Isthecurbcutongrade");
                    Isthecurbcutongrade = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Isthecurbcutongrade);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutongrade, Isthecurbcutongrade);
                    crmTrace.AppendLine("Retrieve Isthecurbcutongrade:" + Isthecurbcutongrade);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutonotherstructure))
                {
                    crmTrace.AppendLine("Retrieve Isthecurbcutonotherstructure");
                    Isthecurbcutonotherstructure = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Isthecurbcutonotherstructure);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutonotherstructure, Isthecurbcutonotherstructure);
                    crmTrace.AppendLine("Retrieve Isthecurbcutonotherstructure:" + Isthecurbcutonotherstructure);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutoveravault))
                {
                    crmTrace.AppendLine("Retrieve Isthecurbcutoveravault");
                    Isthecurbcutoveravault = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Isthecurbcutoveravault);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Isthecurbcutoveravault, Isthecurbcutoveravault);
                    crmTrace.AppendLine("Retrieve Isthecurbcutoveravault:" + Isthecurbcutoveravault);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.LoadingBerth))
                {
                    crmTrace.AppendLine("Retrieve LoadingBerth");
                    LoadingBerth = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.LoadingBerth);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.LoadingBerth, LoadingBerth);
                    crmTrace.AppendLine("Retrieve LoadingBerth:" + LoadingBerth);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.ParkingGarage))
                {
                    crmTrace.AppendLine("Retrieve ParkingGarage");
                    ParkingGarage = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.ParkingGarage);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.ParkingGarage, ParkingGarage);
                    crmTrace.AppendLine("Retrieve ParkingGarage:" + ParkingGarage);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.ParkingLot))
                {
                    crmTrace.AppendLine("Retrieve ParkingLot");
                    ParkingLot = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.ParkingLot);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.ParkingLot, ParkingLot);
                    crmTrace.AppendLine("Retrieve ParkingLot:" + ParkingLot);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.ParkingPad))
                {
                    crmTrace.AppendLine("Retrieve ParkingPad");
                    ParkingPad = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.ParkingPad);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.ParkingPad, ParkingPad);
                    crmTrace.AppendLine("Retrieve ParkingPad:" + ParkingPad);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.PrivateDriveRoad))
                {
                    crmTrace.AppendLine("Retrieve PrivateDriveRoad");
                    PrivateDriveRoad = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.PrivateDriveRoad);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.PrivateDriveRoad, PrivateDriveRoad);
                    crmTrace.AppendLine("Retrieve PrivateDriveRoad:" + PrivateDriveRoad);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Sideofthestreetiscurbcuton))
                {
                    crmTrace.AppendLine("Retrieve Sideofthestreetiscurbcuton");
                    Sideofthestreetiscurbcuton = preImage.FormattedValues[CurbCutQuestionnaireEntityAttributeName.Sideofthestreetiscurbcuton];
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Sideofthestreetiscurbcuton, Sideofthestreetiscurbcuton);
                    crmTrace.AppendLine("Retrieve Sideofthestreetiscurbcuton:" + Sideofthestreetiscurbcuton);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionstobedestroyedrelocated))
                {
                    crmTrace.AppendLine("Retrieve Sidewalkobstructionstobedestroyedrelocated");
                    Sidewalkobstructionstobedestroyedrelocated = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionstobedestroyedrelocated);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionstobedestroyedrelocated, Sidewalkobstructionstobedestroyedrelocated);
                    crmTrace.AppendLine("Retrieve Sidewalkobstructionstobedestroyedrelocated:" + Sidewalkobstructionstobedestroyedrelocated);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionswithin8ftofproposedCC))
                {
                    crmTrace.AppendLine("Retrieve Sidewalkobstructionswithin8ftofproposedCC");
                    Sidewalkobstructionswithin8ftofproposedCC = SetBooleanAttribute(preImage, CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionswithin8ftofproposedCC);
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Sidewalkobstructionswithin8ftofproposedCC, Sidewalkobstructionswithin8ftofproposedCC);
                    crmTrace.AppendLine("Retrieve Sidewalkobstructionswithin8ftofproposedCC:" + Sidewalkobstructionswithin8ftofproposedCC);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Sizeofcutwithsplays))
                {
                    crmTrace.AppendLine("Retrieve Sizeofcutwithsplays");
                    Sizeofcutwithsplays = (preImage.GetAttributeValue<double>(CurbCutQuestionnaireEntityAttributeName.Sizeofcutwithsplays)).ToString();
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Sizeofcutwithsplays, Sizeofcutwithsplays);
                    crmTrace.AppendLine("Retrieve Sizeofcutwithsplays:" + Sizeofcutwithsplays);
                }

                if (preImage.Attributes.Contains(CurbCutQuestionnaireEntityAttributeName.Tostreet))
                {
                    crmTrace.AppendLine("Retrieve Tostreet");
                    Tostreet = preImage.GetAttributeValue<string>(CurbCutQuestionnaireEntityAttributeName.Tostreet).ToString();
                    imageValues.Add(CurbCutQuestionnaireEntityAttributeName.Tostreet, Tostreet);
                    crmTrace.AppendLine("Retrieve Tostreet:" + Tostreet);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - ProgressInspectionCategoryValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

        #region Get Values from Fence Scope of Work Entity
        public static Dictionary<string, string> FenceScopeOfWorkValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string FenceHeight = string.Empty; //String
            string FenceLocation = string.Empty; //OptionSet
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(FenceScopeofWorkAttributeNames.FenceHeight))
                {
                    crmTrace.AppendLine("Retrieve FenceHeight");
                    FenceHeight = preImage.GetAttributeValue<string>(FenceScopeofWorkAttributeNames.FenceHeight);
                    imageValues.Add(FenceScopeofWorkAttributeNames.FenceHeight, FenceHeight);
                    crmTrace.AppendLine("Retrieve FenceHeight:" + FenceHeight);
                }

                if (preImage.Attributes.Contains(FenceScopeofWorkAttributeNames.FenceLocation))
                {
                    crmTrace.AppendLine("Retrieve FenceLocation");
                    FenceLocation = preImage.FormattedValues[FenceScopeofWorkAttributeNames.FenceLocation];
                    imageValues.Add(FenceScopeofWorkAttributeNames.FenceLocation, FenceLocation);
                    crmTrace.AppendLine("Retrieve FenceLocation:" + FenceLocation);
                }


                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - FenceScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

        #region Get Values from Side Walk Shed Scope of Work Entity
        public static Dictionary<string, string> SHScopeOfWorkValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string FenceHeight = string.Empty; //String
            string FenceLocation = string.Empty; //OptionSet
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.shedType))
                {
                    crmTrace.AppendLine("Retrieve shedType");
                    FenceHeight = preImage.FormattedValues[SHScopeofWorkAttributeNames.shedType];
                    imageValues.Add(SHScopeofWorkAttributeNames.shedType, FenceHeight);
                    crmTrace.AppendLine("Retrieve shedType:" + FenceHeight);
                }

                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.extendPropertyLines))
                {
                    crmTrace.AppendLine("Retrieve extendPropertyLines");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.extendPropertyLines);

                    imageValues.Add(SHScopeofWorkAttributeNames.extendPropertyLines, FenceLocation);
                    crmTrace.AppendLine("Retrieve extendPropertyLines:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.howShedSupported))
                {
                    crmTrace.AppendLine("Retrieve howShedSupported");
                    FenceLocation = preImage.FormattedValues[SHScopeofWorkAttributeNames.howShedSupported];

                    imageValues.Add(SHScopeofWorkAttributeNames.howShedSupported, FenceLocation);
                    crmTrace.AppendLine("Retrieve howShedSupported:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.relatedConstruction))
                {
                    crmTrace.AppendLine("Retrieve relatedConstruction");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.relatedConstruction);

                    imageValues.Add(SHScopeofWorkAttributeNames.relatedConstruction, FenceLocation);
                    crmTrace.AppendLine("Retrieve relatedConstruction:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.EnterBISjobnNmberor))
                {
                    crmTrace.AppendLine("Retrieve EnterBISjobnNmberor");

                    FenceLocation = preImage.GetAttributeValue<string>(SHScopeofWorkAttributeNames.EnterBISjobnNmberor).ToString();
                    imageValues.Add(SHScopeofWorkAttributeNames.EnterBISjobnNmberor, FenceLocation);
                    crmTrace.AppendLine("Retrieve EnterBISjobnNmberor:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.restontopofasidewalk))
                {
                    crmTrace.AppendLine("Retrieve restontopofasidewalk");

                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.restontopofasidewalk);
                    imageValues.Add(SHScopeofWorkAttributeNames.restontopofasidewalk, FenceLocation);
                    crmTrace.AppendLine("Retrieve restontopofasidewalk:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.safetyNetting))
                {
                    crmTrace.AppendLine("Retrieve safetyNetting");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.safetyNetting);
                    imageValues.Add(SHScopeofWorkAttributeNames.safetyNetting, FenceLocation);
                    crmTrace.AppendLine("Retrieve safetyNetting:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Hoists))
                {
                    crmTrace.AppendLine("Retrieve Hoists");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Hoists);
                    imageValues.Add(SHScopeofWorkAttributeNames.Hoists, FenceLocation);
                    crmTrace.AppendLine("Retrieve Hoists:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Cranes))
                {
                    crmTrace.AppendLine("Retrieve Cranes");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Cranes);
                    imageValues.Add(SHScopeofWorkAttributeNames.Cranes, FenceLocation);
                    crmTrace.AppendLine("Retrieve Cranes:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Derricks))
                {
                    crmTrace.AppendLine("Retrieve Derricks");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Derricks);
                    imageValues.Add(SHScopeofWorkAttributeNames.Derricks, FenceLocation);
                    crmTrace.AppendLine("Retrieve Derricks:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Chutes))
                {
                    crmTrace.AppendLine("Retrieve Chutes");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Chutes);
                    imageValues.Add(SHScopeofWorkAttributeNames.Chutes, FenceLocation);
                    crmTrace.AppendLine("Retrieve Chutes:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.SideWalkVault))
                {
                    crmTrace.AppendLine("Retrieve SideWalkVault");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.SideWalkVault);
                    imageValues.Add(SHScopeofWorkAttributeNames.SideWalkVault, FenceLocation);
                    crmTrace.AppendLine("Retrieve SideWalkVault:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.ElectricalVault))
                {
                    crmTrace.AppendLine("Retrieve ElectricalVault");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.ElectricalVault);
                    imageValues.Add(SHScopeofWorkAttributeNames.ElectricalVault, FenceLocation);
                    crmTrace.AppendLine("Retrieve ElectricalVault:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.SiameseConnection))
                {
                    crmTrace.AppendLine("Retrieve SiameseConnection");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.SiameseConnection);
                    imageValues.Add(SHScopeofWorkAttributeNames.SiameseConnection, FenceLocation);
                    crmTrace.AppendLine("Retrieve ElectricalVault:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.BusStop))
                {
                    crmTrace.AppendLine("Retrieve BusStop");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.BusStop);
                    imageValues.Add(SHScopeofWorkAttributeNames.BusStop, FenceLocation);
                    crmTrace.AppendLine("Retrieve BusStop:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.LightPole))
                {
                    crmTrace.AppendLine("Retrieve LightPole");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.LightPole);
                    imageValues.Add(SHScopeofWorkAttributeNames.LightPole, FenceLocation);
                    crmTrace.AppendLine("Retrieve LightPole:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Sign))
                {
                    crmTrace.AppendLine("Retrieve Sign");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Sign);
                    imageValues.Add(SHScopeofWorkAttributeNames.Sign, FenceLocation);
                    crmTrace.AppendLine("Retrieve Sign:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Canopy))
                {
                    crmTrace.AppendLine("Retrieve Canopy");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Canopy);
                    imageValues.Add(SHScopeofWorkAttributeNames.Canopy, FenceLocation);
                    crmTrace.AppendLine("Retrieve Canopy:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.Other))
                {
                    crmTrace.AppendLine("Retrieve Other");
                    FenceLocation = SetBooleanAttribute(preImage, SHScopeofWorkAttributeNames.Other);
                    imageValues.Add(SHScopeofWorkAttributeNames.Canopy, FenceLocation);
                    crmTrace.AppendLine("Retrieve Other:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SHScopeofWorkAttributeNames.ShedModificationDescribe))
                {
                    crmTrace.AppendLine("Retrieve ShedModificationDescribe");
                    FenceLocation = preImage.GetAttributeValue<string>(SHScopeofWorkAttributeNames.ShedModificationDescribe).ToString();
                    imageValues.Add(SHScopeofWorkAttributeNames.ShedModificationDescribe, FenceLocation);
                    crmTrace.AppendLine("Retrieve ShedModificationDescribe:" + FenceLocation);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SHScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

        #region Get Values from Supported Scaffold Scope of Work Entity
        public static Dictionary<string, string> SFScopeOfWorkValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string FenceHeight = string.Empty; //String
            string FenceLocation = string.Empty; //OptionSet
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.ScaffoldShedType))
                {
                    crmTrace.AppendLine("Retrieve ScaffoldShedType");
                    FenceHeight = preImage.FormattedValues[ScaffoldScopeofWorkAttributeNames.ScaffoldShedType];
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.ScaffoldShedType, FenceHeight);
                    crmTrace.AppendLine("Retrieve ScaffoldShedType:" + FenceHeight);
                }

                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.IsTheSupportedScaffoldGoing))
                {
                    crmTrace.AppendLine("Retrieve IsTheSupportedScaffoldGoing");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.IsTheSupportedScaffoldGoing);

                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.IsTheSupportedScaffoldGoing, FenceLocation);
                    crmTrace.AppendLine("Retrieve IsTheSupportedScaffoldGoing:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.HowIsTheScaffoldSupported))
                {
                    crmTrace.AppendLine("Retrieve HowIsTheScaffoldSupported");
                    FenceLocation = preImage.FormattedValues[ScaffoldScopeofWorkAttributeNames.HowIsTheScaffoldSupported];

                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.HowIsTheScaffoldSupported, FenceLocation);
                    crmTrace.AppendLine("Retrieve HowIsTheScaffoldSupported:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.IsThereAnyRelatedConstructione))
                {
                    crmTrace.AppendLine("Retrieve IsThereAnyRelatedConstructione");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.IsThereAnyRelatedConstructione);

                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.IsThereAnyRelatedConstructione, FenceLocation);
                    crmTrace.AppendLine("Retrieve IsThereAnyRelatedConstructione:" + FenceLocation);
                }

                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.SupportedScaffoldThatRest))
                {
                    crmTrace.AppendLine("Retrieve SupportedScaffoldThatRest");

                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.SupportedScaffoldThatRest);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.SupportedScaffoldThatRest, FenceLocation);
                    crmTrace.AppendLine("Retrieve SupportedScaffoldThatRest:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.SafetyNetting))
                {
                    crmTrace.AppendLine("Retrieve safetyNetting");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.SafetyNetting);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.SafetyNetting, FenceLocation);
                    crmTrace.AppendLine("Retrieve safetyNetting:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.Hoists))
                {
                    crmTrace.AppendLine("Retrieve Hoists");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.Hoists);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.Hoists, FenceLocation);
                    crmTrace.AppendLine("Retrieve Hoists:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.Cranes))
                {
                    crmTrace.AppendLine("Retrieve Cranes");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.Cranes);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.Cranes, FenceLocation);
                    crmTrace.AppendLine("Retrieve Cranes:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.Derricks))
                {
                    crmTrace.AppendLine("Retrieve Derricks");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.Derricks);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.Derricks, FenceLocation);
                    crmTrace.AppendLine("Retrieve Derricks:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.Chutes))
                {
                    crmTrace.AppendLine("Retrieve Chutes");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.Chutes);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.Chutes, FenceLocation);
                    crmTrace.AppendLine("Retrieve Chutes:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.Walkshed))
                {
                    crmTrace.AppendLine("Retrieve Walkshed");
                    FenceLocation = SetBooleanAttribute(preImage, ScaffoldScopeofWorkAttributeNames.Walkshed);
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.Walkshed, FenceLocation);
                    crmTrace.AppendLine("Retrieve Walkshed:" + FenceLocation);
                }

                if (preImage.Attributes.Contains(ScaffoldScopeofWorkAttributeNames.DobnowFilingNumber))
                {
                    crmTrace.AppendLine("Retrieve DobnowFilingNumber");
                    FenceLocation = preImage.GetAttributeValue<string>(ScaffoldScopeofWorkAttributeNames.DobnowFilingNumber).ToString();
                    imageValues.Add(ScaffoldScopeofWorkAttributeNames.DobnowFilingNumber, FenceLocation);
                    crmTrace.AppendLine("Retrieve DobnowFilingNumber:" + FenceLocation);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SFScopeOfWorkValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

        #region Get Values from Sign Characteristics
        public static Dictionary<string, string> SignCharacteristicsValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string FenceHeight = string.Empty; //String
            string FenceLocation = string.Empty; //OptionSet
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve ContactName");
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.ContactName))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(SignCharactersticsAttributeName.ContactName);
                    if (reqLookUp != null)
                    {
                        FenceHeight = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.OccupancyClassification, FenceHeight);
                    }
                    crmTrace.AppendLine("Retrieve ContactName:" + FenceHeight);
                }

                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.RelationshiptoOwner))
                {
                    crmTrace.AppendLine("Retrieve RelationshiptoOwner");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.RelationshiptoOwner).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.RelationshiptoOwner, FenceLocation);
                    crmTrace.AppendLine("Retrieve RelationshiptoOwner:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.signPurpose))
                {
                    crmTrace.AppendLine("Retrieve signPurpose");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.signPurpose];
                    imageValues.Add(SignCharactersticsAttributeName.signPurpose, FenceHeight);
                    crmTrace.AppendLine("Retrieve signPurpose:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.MaterialOfTheSign))
                {
                    crmTrace.AppendLine("Retrieve MaterialOfTheSign");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.MaterialOfTheSign];
                    imageValues.Add(SignCharactersticsAttributeName.MaterialOfTheSign, FenceHeight);
                    crmTrace.AppendLine("Retrieve MaterialOfTheSign:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.Weightlbs))
                {
                    crmTrace.AppendLine("Retrieve Weightlbs");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.Weightlbs).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.Weightlbs, FenceLocation);
                    crmTrace.AppendLine("Retrieve Weightlbs:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft))
                {
                    crmTrace.AppendLine("Retrieve TotalSurfaceAreaofthisSigninSqft");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft, FenceLocation);
                    crmTrace.AppendLine("Retrieve TotalSurfaceAreaofthisSigninSqft:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.TotalSquareFeet))
                {
                    crmTrace.AppendLine("Retrieve TotalSquareFeet");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSquareFeet).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.TotalSquareFeet, FenceLocation);
                    crmTrace.AppendLine("Retrieve TotalSquareFeet:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet))
                {
                    crmTrace.AppendLine("Retrieve TotalZoningLotFrontageFeet");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet, FenceLocation);
                    crmTrace.AppendLine("Retrieve TotalZoningLotFrontageFeet:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning))
                {
                    crmTrace.AppendLine("Retrieve TotalSurfaceAreaofallSignsinZoning");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning, FenceLocation);
                    crmTrace.AppendLine("Retrieve TotalSurfaceAreaofallSignsinZoning:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.EstimatedJobCost))
                {
                    crmTrace.AppendLine("Retrieve EstimatedJobCost");
                    FenceLocation = preImage.GetAttributeValue<Money>(SignCharactersticsAttributeName.EstimatedJobCost).Value.ToString();
                    imageValues.Add(SignCharactersticsAttributeName.EstimatedJobCost, FenceLocation);
                    crmTrace.AppendLine("Retrieve EstimatedJobCost:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon))
                {
                    crmTrace.AppendLine("Retrieve MaximumAllowableSurfaceAreaonZon");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon, FenceLocation);
                    crmTrace.AppendLine("Retrieve MaximumAllowableSurfaceAreaonZon:" + FenceLocation);
                }

                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignType))
                {
                    crmTrace.AppendLine("Retrieve SignType");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.SignType];
                    imageValues.Add(SignCharactersticsAttributeName.SignType, FenceHeight);
                    crmTrace.AppendLine("Retrieve SignType:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.TypeOfIllumination))
                {
                    crmTrace.AppendLine("Retrieve TypeOfIllumination");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.TypeOfIllumination];
                    imageValues.Add(SignCharactersticsAttributeName.TypeOfIllumination, FenceHeight);
                    crmTrace.AppendLine("Retrieve TypeOfIllumination:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignLocation))
                {
                    crmTrace.AppendLine("Retrieve SignLocation");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.SignLocation];
                    imageValues.Add(SignCharactersticsAttributeName.SignLocation, FenceHeight);
                    crmTrace.AppendLine("Retrieve SignLocation:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.HeightAboveTheCurb))
                {
                    crmTrace.AppendLine("Retrieve HeightAboveTheCurb");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAboveTheCurb).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.HeightAboveTheCurb, FenceLocation);
                    crmTrace.AppendLine("Retrieve HeightAboveTheCurb:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.isThisProjectingSign))
                {
                    crmTrace.AppendLine("Retrieve isThisProjectingSign");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.isThisProjectingSign);
                    imageValues.Add(SignCharactersticsAttributeName.isThisProjectingSign, FenceLocation);
                    crmTrace.AppendLine("Retrieve isThisProjectingSign:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignProjectsByFt))
                {
                    crmTrace.AppendLine("Retrieve SignProjectsByFt");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.SignProjectsByFt).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.SignProjectsByFt, FenceLocation);
                    crmTrace.AppendLine("Retrieve SignProjectsByFt:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignProjectsByIn))
                {
                    crmTrace.AppendLine("Retrieve SignProjectsByIn");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.SignProjectsByIn).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.SignProjectsByIn, FenceLocation);
                    crmTrace.AppendLine("Retrieve SignProjectsByIn:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.IsRoofSignTightFlag))
                {
                    crmTrace.AppendLine("Retrieve IsRoofSignTightFlag");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.IsRoofSignTightFlag);
                    imageValues.Add(SignCharactersticsAttributeName.IsRoofSignTightFlag, FenceLocation);
                    crmTrace.AppendLine("Retrieve IsRoofSignTightFlag:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.HeightAboveTheRoof))
                {
                    crmTrace.AppendLine("Retrieve HeightAboveTheRoof");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAboveTheRoof).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.HeightAboveTheRoof, FenceLocation);
                    crmTrace.AppendLine("Retrieve HeightAboveTheRoof:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.IsRoofSignTightClosedSolid))
                {
                    crmTrace.AppendLine("Retrieve IsRoofSignTightClosedSolid");
                    FenceHeight = preImage.FormattedValues[SignCharactersticsAttributeName.IsRoofSignTightClosedSolid];
                    imageValues.Add(SignCharactersticsAttributeName.IsRoofSignTightClosedSolid, FenceHeight);
                    crmTrace.AppendLine("Retrieve IsRoofSignTightClosedSolid:" + FenceHeight);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignWording))
                {
                    crmTrace.AppendLine("Retrieve SignWording");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.SignWording).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.SignWording, FenceLocation);
                    crmTrace.AppendLine("Retrieve SignWording:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.IgnDesignedforChangeableCopy))
                {
                    crmTrace.AppendLine("Retrieve IgnDesignedforChangeableCopy");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.IgnDesignedforChangeableCopy);
                    imageValues.Add(SignCharactersticsAttributeName.IgnDesignedforChangeableCopy, FenceLocation);
                    crmTrace.AppendLine("Retrieve IgnDesignedforChangeableCopy:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign))
                {
                    crmTrace.AppendLine("Retrieve DoesAnoaChaveanInterestinThisSign");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign);
                    imageValues.Add(SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign, FenceLocation);
                    crmTrace.AppendLine("Retrieve DoesAnoaChaveanInterestinThisSign:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.WithInviewofAnarterialHighway))
                {
                    crmTrace.AppendLine("Retrieve WithInviewofAnarterialHighway");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.WithInviewofAnarterialHighway);
                    imageValues.Add(SignCharactersticsAttributeName.WithInviewofAnarterialHighway, FenceLocation);
                    crmTrace.AppendLine("Retrieve WithInviewofAnarterialHighway:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.Within200AndWithinViewPark))
                {
                    crmTrace.AppendLine("Retrieve Within200AndWithinViewPark");

                    FenceLocation = SetBooleanAttribute(preImage, SignCharactersticsAttributeName.Within200AndWithinViewPark);
                    imageValues.Add(SignCharactersticsAttributeName.Within200AndWithinViewPark, FenceLocation);
                    crmTrace.AppendLine("Retrieve Within200AndWithinViewPark:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.OacRegistrationNumber))
                {
                    crmTrace.AppendLine("Retrieve OacRegistrationNumber");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.OacRegistrationNumber).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.OacRegistrationNumber, FenceLocation);
                    crmTrace.AppendLine("Retrieve OacRegistrationNumber:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.DistanceFromarterialHighwayFeet))
                {
                    crmTrace.AppendLine("Retrieve DistanceFromarterialHighwayFeet");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.DistanceFromarterialHighwayFeet).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.DistanceFromarterialHighwayFeet, FenceLocation);
                    crmTrace.AppendLine("Retrieve DistanceFromarterialHighwayFeet:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore))
                {
                    crmTrace.AppendLine("Retrieve DistanceFromPark12AcreorMore");
                    FenceLocation = preImage.GetAttributeValue<decimal>(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore, FenceLocation);
                    crmTrace.AppendLine("Retrieve DistanceFromPark12AcreorMore:" + FenceLocation);
                }
                if (preImage.Attributes.Contains(SignCharactersticsAttributeName.SignRegistrationNumber))
                {
                    crmTrace.AppendLine("Retrieve SignRegistrationNumber");
                    FenceLocation = preImage.GetAttributeValue<string>(SignCharactersticsAttributeName.SignRegistrationNumber).ToString();
                    imageValues.Add(SignCharactersticsAttributeName.SignRegistrationNumber, FenceLocation);
                    crmTrace.AppendLine("Retrieve SignRegistrationNumber:" + FenceLocation);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - SignCharacteristicsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

        #region Get Values from Delegates Entity

        public static Dictionary<string, string> DelegatesValues(Entity preImage, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string Contact = string.Empty;
            string License = string.Empty;
            string Email = string.Empty;

            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve Contact");
                if (preImage.Attributes.Contains(DelegatesEntityAttributeNames.GoToContact))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(DelegatesEntityAttributeNames.GoToContact);
                    if (reqLookUp != null)
                    {
                        Contact = reqLookUp.Name;
                        imageValues.Add(DelegatesEntityAttributeNames.GoToContact, Contact);
                    }
                    crmTrace.AppendLine("Retrieve Contact:" + Contact);
                }

                crmTrace.AppendLine("Retrieve License");
                if (preImage.Attributes.Contains(DelegatesEntityAttributeNames.GoToLicense))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(DelegatesEntityAttributeNames.GoToLicense);
                    if (reqLookUp != null)
                    {
                        License = reqLookUp.Name;
                        imageValues.Add(DelegatesEntityAttributeNames.GoToLicense, License);
                    }
                    crmTrace.AppendLine("Retrieve License:" + License);
                }

                if (preImage.Attributes.Contains(DelegatesEntityAttributeNames.Email))
                {
                    crmTrace.AppendLine("Retrieve Email");
                    Email = preImage.GetAttributeValue<string>(DelegatesEntityAttributeNames.Email).ToString();
                    imageValues.Add(DelegatesEntityAttributeNames.Email, Email);
                    crmTrace.AppendLine("Retrieve Email:" + Email);
                }

                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingChangeTraceHandler - DelegatesValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion

    } // class ends here
} // namespace ends here
