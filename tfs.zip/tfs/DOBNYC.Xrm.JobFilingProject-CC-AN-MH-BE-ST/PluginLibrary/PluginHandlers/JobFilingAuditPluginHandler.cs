﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class JobFilingAuditPluginHandler : PluginHandlerBase
    {
        public static void GenerateJobFilingAuditRequestNumber(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace)
        {

            string jobFiling = string.Empty;

            try
            {
                crmTrace.AppendLine("GenerateJobFilingAuditRequestNumber - Start");

                string jobFilingName = string.Empty;
                int AuditCounter = 0;
                Guid jobFilingGuid = targetEntity.Attributes.Contains(JobFilingAuditAttributeNames.GoToJobFiling) ? targetEntity.GetAttributeValue<EntityReference>(JobFilingAuditAttributeNames.GoToJobFiling).Id : preTargetEntity.GetAttributeValue<EntityReference>(JobFilingAuditAttributeNames.GoToJobFiling).Id;

                crmTrace.AppendLine("jobFilingGuid: " + jobFilingGuid);
                //Retrieve Name of job filing


                if (jobFilingGuid != Guid.Empty)
                {
                    #region Get Job Filing Name
                    Entity jobFilingEntity = new Entity();
                    string[] ColumnNames_JobFiling = { JobFilingEntityAttributeName.EntityAttributeName };
                    jobFilingEntity = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                    crmTrace.AppendLine("Get Job Filing Name");
                    if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.EntityAttributeName))
                        jobFilingName = jobFilingEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.EntityAttributeName);

                    #endregion
                }
                //End of Retrieve Name of job filing

                //get the latest Audit Sequence Counter in existing
                if (preTargetEntity.Attributes.Contains(JobFilingAuditAttributeNames.AuditSequenceCounter))
                {
                    crmTrace.AppendLine("Start of getting AuditCounter on update and increment from " + AuditCounter);
                    AuditCounter = preTargetEntity.GetAttributeValue<int>(JobFilingAuditAttributeNames.AuditSequenceCounter) + 1;
                    crmTrace.AppendLine("End of getting AuditCounter on update and increment to " + AuditCounter);
                }
                #region Check the counter and Set the Job Filing Audit Counter value
                if ( AuditCounter == 0)
                {
                    #region If the AuditCounter is 0 default;
                    crmTrace.AppendLine("Start of setting Name and counter JobFilingAuditEntity" + jobFilingName);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingAuditAttributeNames.Name, " AUDIT - "+ jobFilingName);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingAuditAttributeNames.AuditSequenceCounter, 1);
                    crmTrace.AppendLine("End of setting Name and counter JobFilingAuditEntity" + jobFilingName);
                    #endregion


                }
                else if (AuditCounter > 0)
                {

                    #region If the AuditCounter has value set updated AuditCounter

                    crmTrace.AppendLine("Start of Updating Name and counter JobFilingAuditEntity " + jobFilingName + AuditCounter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingAuditAttributeNames.Name, " AUDIT - " + jobFilingName);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingAuditAttributeNames.AuditSequenceCounter, AuditCounter);
                    crmTrace.AppendLine("End of Updating Name and counter JobFilingAuditEntity " + jobFilingName + AuditCounter.ToString());
                    service.Update(targetEntity);
                    #endregion


                }
                #endregion


                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - FaultException", null, crmTrace.ToString(), null, null);
                crmTrace.AppendLine("GenerateJobFilingAuditRequestNumber - Updated");

                crmTrace.AppendLine("GenerateJobFilingAuditRequestNumber - End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - FaultException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - TimeoutException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - Exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateJobFilingAuditRequestNumber - GenerateJobFilingAuditRequestNumber - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
