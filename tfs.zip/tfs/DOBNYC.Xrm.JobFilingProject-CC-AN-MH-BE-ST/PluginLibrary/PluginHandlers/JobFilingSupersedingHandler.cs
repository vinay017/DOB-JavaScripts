﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOB.Logging;
using Microsoft.Xrm.Client;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class JobFilingSupersedingHandler : PluginHandlerBase
    {
        public static void Superseding(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, int supersedingStatus)
        {
            try
            {
                crmTrace.AppendLine("Superseding started!");
                #region Superseding of Design Professional Approved
                // Handled in JobFilingAutoNumberGenerator - PAAHandler.SupersedingDPPostApproval Method
                #endregion

                #region Superseding of Applicant Approved
                if (supersedingStatus == (int)SupersedingStatus.SupersedingApplicantApproved)
                {
                    crmTrace.AppendLine("supersedingStatus: Superseding Applicant Approved");

                    #region Column Names
                    // Retreiving Job Filing Attributes
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.ApplicantPerson,
                   JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.SupersedingRequestStatus,
                   JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription, JobFilingEntityAttributeName.SupersedingRequesterId, JobFilingEntityAttributeName.ProfessionalCertificate,
                   JobFilingEntityAttributeName.ApplicantPerson,  JobFilingEntityAttributeName.SupersedingWorkpermit};

                    // Retreiving WorkPermit Attributes
                    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.GotoJobFiling, WorkPermitEntityAttributeName.ApplicantContractor, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.WorkPermitId,
                    WorkPermitEntityAttributeName.LastNameContractor, WorkPermitEntityAttributeName.MiddleInitialContractor, WorkPermitEntityAttributeName.FirstNameContractor,WorkPermitEntityAttributeName.BusinessAddressContractor,WorkPermitEntityAttributeName.BusinessFaxContractor,
                    WorkPermitEntityAttributeName.BusinessNameContractor, WorkPermitEntityAttributeName.LicensenumberContractor, WorkPermitEntityAttributeName.BusinessTelephoneContractor, WorkPermitEntityAttributeName.LicenceTypeContractor, WorkPermitEntityAttributeName.StateContractor,
                    WorkPermitEntityAttributeName.MobileTelephoneContractor, WorkPermitEntityAttributeName.CityContractor, WorkPermitEntityAttributeName.ZipContractor, WorkPermitEntityAttributeName.TaxPayerIDContractor, WorkPermitEntityAttributeName.EmailContractor, WorkPermitEntityAttributeName.DescriptionContractor,
                    WorkPermitEntityAttributeName.ApplicantResponsibleforalltheworkContractor, WorkPermitEntityAttributeName.SequenceNumber};

                    // Retreiving Contacts Attributes
                    string[] ColumnNames_Contact = new string[] { ContactEntityAttributeName.ContactId, ContactEntityAttributeName.LastNameContractor, ContactEntityAttributeName.MiddleInitialContractor, ContactEntityAttributeName.FirstNameContractor,ContactEntityAttributeName.BusinessAddressContractor,ContactEntityAttributeName.BusinessFaxContractor,
                    ContactEntityAttributeName.BusinessNameContractor, ContactEntityAttributeName.LicensenumberContractor, ContactEntityAttributeName.BusinessTelephoneContractor, ContactEntityAttributeName.LicenceTypeContractor, ContactEntityAttributeName.StateContractor,
                    ContactEntityAttributeName.MobileTelephoneContractor, ContactEntityAttributeName.CityContractor, ContactEntityAttributeName.ZipContractor, ContactEntityAttributeName.TaxPayerIDContractor, ContactEntityAttributeName.EmailContractor };
                    #endregion

                    #region ConditionExpressions
                    ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                    Guid jfID = new Guid();

                    Entity jobfilingentity = (Entity)jobfilingResponse.Entities[0];
                    Guid SupersedingContactGuid = ((EntityReference)jobfilingentity[JobFilingEntityAttributeName.SupersedingRequesterId]).Id;
                    Guid SupersedingWorkpermitGuid = ((EntityReference)jobfilingentity[JobFilingEntityAttributeName.SupersedingWorkpermit]).Id;
                    crmTrace.AppendLine("SupersedingContactGuid:" + SupersedingContactGuid);
                    crmTrace.AppendLine("SupersedingWorkpermitGuid:" + SupersedingWorkpermitGuid);

                    ConditionExpression workpermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitId, ConditionOperator.Equal, new string[] { SupersedingWorkpermitGuid.ToString() });
                    EntityCollection workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition }, LogicalOperator.And);
                    Guid wpID = new Guid();
                    wpID = Guid.Parse(workpermitResponse.Entities[0].Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());
                    int sequenceNumber = workpermitResponse.Entities[0].GetAttributeValue<int>(WorkPermitEntityAttributeName.SequenceNumber);
                    crmTrace.AppendLine("workpermit count: " + workpermitResponse.Entities.Count);
                    crmTrace.AppendLine("wpID:" + wpID.ToString());
                    crmTrace.AppendLine("sequenceNumber:" + sequenceNumber.ToString());

                    // Get the requester information and update the Job filing
                    ConditionExpression contactCondition = CreateConditionExpression(ContactEntityAttributeName.ContactId, ConditionOperator.Equal, new string[] { SupersedingContactGuid.ToString() });
                    EntityCollection contactResponse = RetrieveMultiple(service, ContactEntityAttributeName.EntityLogicalName, ColumnNames_Contact, new ConditionExpression[] { contactCondition }, LogicalOperator.And);
                    Entity contactentity = (Entity)contactResponse.Entities[0];
                    Guid contractorID = new Guid();
                    contractorID = Guid.Parse(contactResponse.Entities[0].Attributes[ContactEntityAttributeName.ContactId].ToString());
                    crmTrace.AppendLine("Contact count: " + contactResponse.Entities.Count);
                    #endregion

                    // Update the JobFiling
                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Job filing:" + i);
                            jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());
                            crmTrace.AppendLine("Updating Job filing Starts");

                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.Approved));
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobDescription, "Superseding Contractor is approved");
                                service.Update(jobFiling);
                                crmTrace.AppendLine("Updating Job filing End");

                        }
                    }

                    // Update the Workpermit and Set the status to Active
                    if (workpermitResponse != null && workpermitResponse.Entities != null && workpermitResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Workpermits count: " + workpermitResponse.Entities.Count);
                        for (int i = 0; i < workpermitResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating workpermit:" + i);
                            
                            
                            Entity workpermit = new Entity();
                            workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, wpID);
                            //workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.Active));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.ApplicantContractor, new EntityReference(ContactEntityAttributeName.EntityLogicalName, SupersedingContactGuid));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.SequenceNumber, (sequenceNumber + 1));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.LastNameContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.LastNameContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.MiddleInitialContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.MiddleInitialContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.FirstNameContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.FirstNameContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.BusinessAddressContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.BusinessAddressContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.BusinessFaxContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.BusinessFaxContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.BusinessNameContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.BusinessNameContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.LicensenumberContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.LicensenumberContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.BusinessTelephoneContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.BusinessTelephoneContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.LicenceTypeContractor, contactentity.GetAttributeValue<OptionSetValue>(ContactEntityAttributeName.LicenceTypeContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.StateContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.StateContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.MobileTelephoneContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.MobileTelephoneContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.CityContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.CityContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.ZipContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.ZipContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.TaxPayerIDContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.TaxPayerIDContractor));
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.EmailContractor, contactentity.GetAttributeValue<string>(ContactEntityAttributeName.EmailContractor));
                            

                            crmTrace.AppendLine("workpermit Guid:" + workpermit.Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());

                            service.Update(workpermit);
                            crmTrace.AppendLine(" Workpermit Updated!");
                                                       
                        }

                    }


                }
                #endregion
               // throw new Exception("Superseding Debugging"); 
            }// try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void Superseding_SiPi(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, int supersedingStatus)
        {
            try
            {

                Entity Tentity = (Entity)preImage;
                crmTrace.AppendLine("Tentity: " + Tentity.LogicalName);
                Guid jobFilingGuid = ((EntityReference)Tentity[SupersedingRequestEntityAttributeName.GotoJobFiling]).Id;
                crmTrace.AppendLine("Regarding Job Filing Guid: " + jobFilingGuid.ToString());

                string[] Column_Superseding = new string[] { SupersedingRequestEntityAttributeName.Requester};
                Entity response = Retrieve(service, Column_Superseding, targetEntity.Id, SupersedingRequestEntityAttributeName.EntityLogicalName);
                Guid requester = ((EntityReference)response.Attributes[SupersedingRequestEntityAttributeName.Requester]).Id;
                crmTrace.AppendLine("Requester: " + requester);

                crmTrace.AppendLine("Superseding started!");
                #region Superseding of ProgressInspector Approved
                if (supersedingStatus == (int)SupersedingStatus.SupersedingofProgressInspectorApproved)
                {
                    ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelationId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelationId, ProgressInspectionCategoryEntityAttributeName.GoToJobFiling }, new ConditionExpression[] { progressInspCondition }, LogicalOperator.And);
                    EntityReferenceCollection progressInsps = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the progressInsps");

                    if (progressInspResponse != null && progressInspResponse.Entities != null && progressInspResponse.Entities.Count > 0)
                    {
                        Guid jfID = new Guid();
                        crmTrace.AppendLine("progressInspResponse count: " + progressInspResponse.Entities.Count);
                        for (int i = 0; i < progressInspResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Progress Inspection Record:" + i);
                            jfID = ((EntityReference)progressInspResponse.Entities[i].Attributes[ProgressInspectionCategoryEntityAttributeName.GoToJobFiling]).Id;
                           crmTrace.AppendLine("jfID:" + jfID.ToString());
                            Entity ProgressInsp = new Entity();
                            ProgressInsp.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                            crmTrace.AppendLine("progressInspResponse.Entities[i].Id:" + progressInspResponse.Entities[i].Id);
                            ProgressInsp.Attributes.Add(ProgressInspectionCategoryAttributeNames.ProgressInspectionCategoryId, progressInspResponse.Entities[i].Id);
                            ProgressInsp.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.Superseded, true);
                            crmTrace.AppendLine("ProgressInsp Superseded Status:" + ProgressInsp.Attributes[ProgressInspectionCategoryEntityAttributeName.Superseded].ToString());

                            service.Update(ProgressInsp);

                            progressInsps.Add(new EntityReference(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, ProgressInsp.Id));

                            Entity temp = CreateProgressInspectionCategorieslist(service, progressInspResponse.Entities[i], jfID, crmTrace, requester);
                            service.Create(temp);
                        }
                            
                        
                    }

                    crmTrace.AppendLine("All the progress Inspection records are associated");


                } //Superseding of ProgressInspector Approved
                #endregion

                #region Superseding of SpecialInspector Approved
                if (supersedingStatus == (int)SupersedingStatus.SupersedingofInspectorApproved)
                {
                    ConditionExpression specialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelationid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection specialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelationid, SpecialInspectionCategoriesAttributeNames.GoToJobFiling }, new ConditionExpression[] { specialInspCondition }, LogicalOperator.And);
                    EntityReferenceCollection specialInsps = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the specialInsps");

                    if (specialInspResponse != null && specialInspResponse.Entities != null && specialInspResponse.Entities.Count > 0)
                    {
                        Guid jfID = new Guid();
                        crmTrace.AppendLine("specialInspResponse count: " + specialInspResponse.Entities.Count);
                        for (int i = 0; i < specialInspResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Special Inspection Record:" + i);
                            jfID = ((EntityReference)specialInspResponse.Entities[i].Attributes[SpecialInspectionCategoriesAttributeNames.GoToJobFiling]).Id;
                            crmTrace.AppendLine("jfID:" + jfID.ToString());
                            Entity SpecialInspEntity = new Entity();
                            SpecialInspEntity.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                            crmTrace.AppendLine("specialInspResponse.Entities[i].Id:" + specialInspResponse.Entities[i].Id);
                            SpecialInspEntity.Attributes.Add(SpecialInspectionCategoriesAttributeNames.SpecialInspectionCategoriesId, specialInspResponse.Entities[i].Id);
                            SpecialInspEntity.Attributes.Add(SpecialInspectionCategoriesAttributeNames.Superseded, true);
                            crmTrace.AppendLine("SpecialInspEntity Superseded Status:" + SpecialInspEntity.Attributes[SpecialInspectionCategoriesAttributeNames.Superseded].ToString());

                            service.Update(SpecialInspEntity);

                            specialInsps.Add(new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspEntity.Id));

                            Entity temp = CreateSpecialInspectionCategorieslist(service, specialInspResponse.Entities[i], jfID, crmTrace, requester);
                            service.Create(temp);
                        }


                    }

                    crmTrace.AppendLine("All the Special Inspection records are associated");


                } //Superseding of ProgressInspector Approved
                #endregion

                //throw new Exception("Withdrawal Debugging");   

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static Entity CreateSpecialInspectionCategorieslist(IOrganizationService service, Entity currentSpecialInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace, Guid requester)
        {
            Entity SIC = new Entity();
            try
            { ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, currentSpecialInspectionCategoriesRecord.Id, columns);

                SIC = EntityExtensions.Clone(response, false);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspector);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.CreatedFrom);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.LicenseType);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectionCategoriesId);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelationid);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IWithdrawResponsibility);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.Superseded);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IResponsibleName);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ICentifyName);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectionAgencyNo);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IORStatement1);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.FinalIOR);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.InspectionApplicantNameStatement);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ResponsibleStatementDate);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ResponsibilityofIdentifingRequirement);
                SIC.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                SIC.Attributes.Add(SpecialInspectionCategoriesAttributeNames.SpecialInspector, new EntityReference(ContactEntityAttributeName.EntityLogicalName, requester));
                SIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("SIC ID :" + SIC.Id.ToString());

                return SIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return SIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentSpecialInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
        }

        public static Entity CreateProgressInspectionCategorieslist(IOrganizationService service, Entity currentProgressInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace, Guid requester)
        {
            Entity PIC = new Entity();
            try
            { ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(ProgressInspectionCategoryAttributeNames.EntityLogicalName, currentProgressInspectionCategoriesRecord.Id, columns);


                PIC = EntityExtensions.Clone(response, false);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ProgressInspector);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ProgressInspectionCategoryId);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelationId);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.Superseded);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.LicenseType);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.CreatedFrom);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.IWithdrawResponsibility);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IReponsibleCheckName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ICertifyCheckName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IdentificationofResponsibilities);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.CertificateofCompleteInspections);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IORStatement1);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressInsFinalStatememt);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressResponsibleName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressReponsibleDate);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ResponsibilityofIdentifingRequirement);
                PIC.Attributes.Add(ProgressInspectionCategoryAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                PIC.Attributes.Add(ProgressInspectionCategoryAttributeNames.ProgressInspector, new EntityReference(ContactEntityAttributeName.EntityLogicalName, requester));
                PIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("PIC ID :" + PIC.Id.ToString());

                return PIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(currentProgressInspectionCategoriesRecord.Id.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - Superseding_SiPi", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
        }

        //Deactivate a record
        public static void DeactivateRecord(StringBuilder crmTrace, string entityName, Guid recordId, IOrganizationService organizationService)
        {
            try
            { var cols = new ColumnSet(new[] { "statecode", "statuscode" });
                crmTrace.AppendLine(" Deactivate Record Started");
                //Check if it is Active or not
                var entity = organizationService.Retrieve(entityName, recordId, cols);

                if (entity != null && entity.GetAttributeValue<OptionSetValue>("statecode").Value == 0)
                {
                    //StateCode = 1 and StatusCode = 2 for deactivating Account or Contact
                    SetStateRequest setStateRequest = new SetStateRequest()
                    {
                        EntityMoniker = new EntityReference
                        {
                            Id = recordId,
                            LogicalName = entityName,
                        },
                        State = new OptionSetValue(1),
                        Status = new OptionSetValue(2)
                    };
                    organizationService.Execute(setStateRequest);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
              
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
             }
        }
    } // class ends here
} // namespace ends here
