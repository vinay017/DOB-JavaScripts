﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class RequestNumberHandler : PluginHandlerBase
    {
        public static Entity WithdrawalRequestNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            
            try
            {
                bool WithdrawalRequired = false;
                string RequestformatString = "{0}{1}";
                string RequestFormatted = string.Empty;
                Decimal WithdrawalNumber = 0;
                int Withdrawalnumberpadding = 0;
                char paddingChar = '0';
                if(targetEntity.Attributes.Contains(WithdrawalRequestEntityAttributeName.GotoJobFiling))
                {
                    ConditionExpression autoNumberCondition = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { WithdrawalRequestEntityAttributeName.EntityLogicalName });
                    EntityCollection response = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.WithdrawalCounter, JobAutoNumberEntityAttribute.WithdrawalPadingCharacter, JobAutoNumberEntityAttribute.WithdrawalPadingNumber}, new ConditionExpression[] { autoNumberCondition }, LogicalOperator.And);
                    if (response != null && response.Entities.Count > 0)
                    {
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.WithdrawalCounter))
                            WithdrawalNumber = decimal.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.WithdrawalCounter].ToString());
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.WithdrawalPadingNumber))
                            Withdrawalnumberpadding = int.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.WithdrawalPadingNumber].ToString());
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.WithdrawalPadingCharacter))
                            paddingChar = char.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.WithdrawalPadingCharacter].ToString());

                        crmTrace.AppendLine("WithdrawalNumber: " + WithdrawalNumber);

                        RequestFormatted = String.Format(RequestformatString, "WR", Math.Round(WithdrawalNumber, 0).ToString().PadLeft(Withdrawalnumberpadding, paddingChar));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, WithdrawalRequestEntityAttributeName.WithdrawalRequestNumber, RequestFormatted);

                        #region Update Counters
                        Entity AN = new Entity();
                        crmTrace.AppendLine("Start Updating Counter: " + RequestFormatted);
                        AN.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                        AN.Id = response.Entities[0].Id;
                        AN.Attributes.Add(JobAutoNumberEntityAttribute.WithdrawalCounter, (WithdrawalNumber + 1));
                        UpdateEntity(service, AN);
                        crmTrace.AppendLine("End Updating Counter: " + RequestFormatted);
                        #endregion
                    }

                }


                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - WithdrawalRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        public static Entity SupersedingRequestNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
        try
            {
                string RequestformatString = "{0}{1}";
                string RequestFormatted = string.Empty;
                Decimal SupersedingNumber = 0;
                int Supersedingnumberpadding = 0;
                char paddingChar = '0';
                if (targetEntity.Attributes.Contains(SupersedingRequestEntityAttributeName.GotoJobFiling))
                {
                    ConditionExpression autoNumberCondition = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { SupersedingRequestEntityAttributeName.EntityLogicalName });
                    EntityCollection response = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.SupersedingCounter, JobAutoNumberEntityAttribute.SupersedingPaddingChar, JobAutoNumberEntityAttribute.SupersedingPaddingNumber }, new ConditionExpression[] { autoNumberCondition }, LogicalOperator.And);
                    if (response != null && response.Entities.Count > 0)
                    {
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingCounter))
                            SupersedingNumber = decimal.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingCounter].ToString());
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingPaddingNumber))
                            Supersedingnumberpadding = int.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingPaddingNumber].ToString());
                        if (response.Entities[0].Contains(JobAutoNumberEntityAttribute.SupersedingPaddingChar))
                            paddingChar = char.Parse(response.Entities[0].Attributes[JobAutoNumberEntityAttribute.SupersedingPaddingChar].ToString());

                        crmTrace.AppendLine("SupersedingNumber: " + SupersedingNumber);

                        RequestFormatted = String.Format(RequestformatString, "SR", Math.Round(SupersedingNumber, 0).ToString().PadLeft(Supersedingnumberpadding, paddingChar));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, SupersedingRequestEntityAttributeName.SupersedingRequestNumber, RequestFormatted);

                        #region Update Counters
                        Entity AN = new Entity();
                        crmTrace.AppendLine("Start Updating Counter: " + RequestFormatted);
                        AN.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                        AN.Id = response.Entities[0].Id;
                        AN.Attributes.Add(JobAutoNumberEntityAttribute.SupersedingCounter, (SupersedingNumber + 1));
                        UpdateEntity(service, AN);
                        crmTrace.AppendLine("End Updating Counter: " + RequestFormatted);
                        #endregion
                    }

                }


                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - SupersedingRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }



        }

        public static Entity AddressChangeRequestNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            string RequestformatString = "{0}";
            string RequestFormatted = string.Empty;

            try
            {
                Random rnd = new Random();
                int sevenDigitRandom = rnd.Next(1000000, 9999999);
                RequestFormatted = String.Format(RequestformatString, sevenDigitRandom.ToString());
                crmTrace.AppendLine("RequestFormatted: " + RequestFormatted);
                if (!targetEntity.Attributes.Contains(AddressChangeRequestsEntityAttributeName.ChangeAddressrequestNumber))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, AddressChangeRequestsEntityAttributeName.ChangeAddressrequestNumber, RequestFormatted);

                }

                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "RequestNumberHandler - AddressChangeRequestNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }


    } // class ends here
}// namespace ends here
