﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;
using System.IO;
using Microsoft.Crm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class EmailHandler : PluginHandlerBase
    {
        public static void DPEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
           try
            {
                crmTrace.AppendLine("Start DPEmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Design Professional", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End DPEmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - DPEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void PACORenewEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start PACORenewEmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Party to Renew PACO same as Owner - Email Workflow", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End PACORenewEmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PACORenewEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void PAA_PISI_Emails(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                #region Send Emails to Progress Inspectors and Special Inspectors
                string[] ColumnNames_Progress = new string[] { ProgressInspectionCategoryAttributeNames.ProgressInspector };
                ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression progressInspCondition2 = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.ProgressInspector, ConditionOperator.NotNull, new string[] { });
                EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ColumnNames_Progress, new ConditionExpression[] { progressInspCondition, progressInspCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("progressInspResponse.Entities.Count: " + progressInspResponse.Entities.Count);
                if (progressInspResponse != null && progressInspResponse.Entities.Count > 0)
                {
                    foreach (Entity prgInspection in progressInspResponse.Entities)
                    {
                        crmTrace.AppendLine("Start ProgressInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                        EmailHandler.ProgressInspectorEmail(service, prgInspection, crmTrace);
                        crmTrace.AppendLine("End ProgressInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    }
                }

                string[] ColumnNames_Special = new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspector };
                ConditionExpression SpecialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression SpecialInspCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspector, ConditionOperator.NotNull, new string[] { });
                EntityCollection SpecialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, ColumnNames_Special, new ConditionExpression[] { SpecialInspCondition, SpecialInspCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("SpecialInspResponse.Entities.Count: " + SpecialInspResponse.Entities.Count);
                if (SpecialInspResponse != null && SpecialInspResponse.Entities.Count > 0)
                {
                    foreach (Entity spclInspection in SpecialInspResponse.Entities)
                    {
                        crmTrace.AppendLine("Start SpecialInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                        EmailHandler.SpecialInspectorEmail(service, spclInspection, crmTrace);
                        crmTrace.AppendLine("End SpecialInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    }
                }

                #endregion
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - PAA_PISI_Emails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ProgressInspectorEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start ProgressInspectorEmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Progress Inspector - On Associate", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End ProgressInspectorEmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ProgressInspectorEmail_WTSignOff(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start ProgressInspectorEmail_WTSignOff Method ");
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Progress Inspector - Work Type Sign off", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #region New Email - Using Plugin
                //SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit, EmailReferences.A102, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End ProgressInspectorEmail_WTSignOff Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_WTSignOff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ProgressInspectorEmail_SignOffQAFailed(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start ProgressInspectorEmail_SignOffQAFailed Method ");
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Progress Inspector - Sign off QA Failed", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #region New Email - Using Plugin
                //SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit, EmailReferences.A101, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End ProgressInspectorEmail_SignOffQAFailed Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_SignOffQAFailed", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ProgressInspectorEmail_PermitIssued(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit_Pre, StringBuilder crmTrace)
        {
            try
            {
                // targetEntity -- ProgressInspection entity
                // WorkPermit_Pre -- WorkPermit PreImage
                crmTrace.AppendLine("Start ProgressInspectorEmail_PermitIssued Method ");
                #region Old Workflow Logic
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Progress Inspector - Permit Issued", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #endregion

                #region New Email - Using Plugin
                //SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit_Pre, EmailReferences.A24, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End ProgressInspectorEmail_PermitIssued Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - ProgressInspectorEmail_PermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SpecialInspectorEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start SpecialInspectorEmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Special Inspector - On Associate", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End SpecialInspectorEmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SpecialInspectorEmail_WTSignOff(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start SpecialInspectorEmail_WTSignOff Method ");
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Special Inspector - Work Type Sign off", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #region New Email - Using Plugin
                //SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit, EmailReferences.A103, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End SpecialInspectorEmail_WTSignOff Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_WTSignOff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SpecialInspectorEmail_SignOffQAFailed(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start SpecialInspectorEmail_SignOffQAFailed Method ");
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Special Inspector - Sign off QA Failed", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #region New Email - Using Plugin
               // SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit, EmailReferences.A101, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End SpecialInspectorEmail_SignOffQAFailed Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_SignOffQAFailed", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SpecialInspectorEmail_PermitIssued(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start SpecialInspectorEmail_PermitIssued Method ");
                //Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Special Inspector - On Permit Issued", crmTrace).Id.ToString());
                //crmTrace.AppendLine("processId:  " + processId.ToString());
                //ExecuteWorkflow(service, processId, targetEntity.Id);
                #region New Email - Using Plugin
                //SendEmail_PermitRelated(service, targetEntity, JobFiling, WorkPermit, EmailReferences.A24, crmTrace);
                crmTrace.AppendLine("Email Sent ");
                #endregion
                crmTrace.AppendLine("End SpecialInspectorEmail_PermitIssued Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SpecialInspectorEmail_PermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void OwnerEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start OwnerEmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Owner", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End OwnerEmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - OwnerEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void FREmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start FREmail Method ");
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Email - Filing Representative", crmTrace).Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("End FREmail Method ");
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - FREmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        private static Entity GetProcessId(IOrganizationService service, string EntityLogicalName, string SearchFieldName, object SearchValue, StringBuilder crmTrace)
        {
            Guid trackingGuid = Guid.NewGuid();
            EntityLogicalName = EntityLogicalName.ToLower();
            SearchFieldName = SearchFieldName.ToLower();
            QueryExpression query = new QueryExpression(EntityLogicalName);
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition(new ConditionExpression(SearchFieldName, ConditionOperator.Equal, SearchValue));
            query.Criteria.AddCondition(new ConditionExpression("type", ConditionOperator.Equal, 1));

            try
            {
                crmTrace.AppendLine("Start GetProcessId Method");
                EntityCollection response = service.RetrieveMultiple(query);
                if (response != null && response.Entities.Count > 0)
                    return response.Entities[0];
                else { return null; }
                crmTrace.AppendLine("End GetProcessId Method");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return null;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return null;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "EmailHandler - GetProcessId", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return null;
            }

        }  // getProcessId ends here

        public static string ReadHtml(StringBuilder crmTrace)
        {
            string strHTML = "Test";
            string path = string.Empty;
            try
            {
                crmTrace.AppendLine("Start Reading Permit Email Template");
                path = @"D:\CRM2015Server\HTMLTemplate\PermitEmail.html";
                crmTrace.AppendLine(path);
                if (File.Exists(path))
                {
                    strHTML = File.ReadAllText(path);

                }
                crmTrace.AppendLine("Email Template: " + strHTML);
                crmTrace.AppendLine("End Reading Permit Email Template");
                return strHTML;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return strHTML;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return strHTML;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(path, SourceChannel.CRM, "EmailHandler - ReadHtml", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return strHTML;
            }

        }

        public static void SendEmail_PermitRelated(IOrganizationService service, Entity targetEntity, Entity JobFiling, Entity WorkPermit_Pre, string Emailreference, StringBuilder crmTrace)
        {
            try
            {
                #region Reterieve Email User
                string[] ColumnNames_CustomConfig = new string[] { CustomConfigurationEntityAttributeName.Key };
                ConditionExpression CustomConfigCondition_Email = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "EMAIL USER" });
                EntityCollection CustomConfigResponse_Email = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_Email }, LogicalOperator.And);
                string EmailUser = CustomConfigResponse_Email.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);
                #endregion

                #region Get CRM Buildings NYC DEV user Guid
                string[] ColumnNames_User = new string[] { SystemUserEntityAttributeNames.SystemUserIdFieldName };
                ConditionExpression userCondition = CreateConditionExpression(SystemUserEntityAttributeNames.FullNameFieldName, ConditionOperator.Equal, new string[] { EmailUser });
                EntityCollection userResponse = RetrieveMultiple(service, SystemUserEntityAttributeNames.EntityLogicalName, ColumnNames_User, new ConditionExpression[] { userCondition }, LogicalOperator.And);
                Guid EmailUserGuid = userResponse.Entities[0].Id;
                crmTrace.AppendLine("EmailUserGuid: " + EmailUserGuid.ToString());
                #endregion

                #region Read Parameters from Job Filing
                String JobNumber = JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                crmTrace.AppendLine("JobNumber: " + JobNumber);
                String FilingNumber = JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                crmTrace.AppendLine("FilingNumber: " + FilingNumber);
                String HouseStreet = JobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseStreetAttributeName);
                crmTrace.AppendLine("HouseStreet: " + HouseStreet);
                #endregion

                #region Read Parameters from WorkPermit
                string[] Columns = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber};
                Entity WorkPermit = Retrieve(service, Columns, WorkPermit_Pre.Id, WorkPermitEntityAttributeName.EntityLogicalName);
                String PermitNumber = WorkPermit.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber);
                crmTrace.AppendLine("PermitNumber: " + PermitNumber);
                #endregion

                #region Get and Adjust Subject
                crmTrace.AppendLine("Emailreference: " + Emailreference);
                ConditionExpression CustomConfigCondition_EmailSub = new ConditionExpression();
                if (Emailreference == EmailReferences.A24)
                    CustomConfigCondition_EmailSub = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Subject_A24 Email" });
                if (Emailreference == EmailReferences.A101)
                    CustomConfigCondition_EmailSub = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Subject_A101 Email" });
                if (Emailreference == EmailReferences.A102)
                    CustomConfigCondition_EmailSub = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Subject_A102 Email" });
                if (Emailreference == EmailReferences.A103)
                    CustomConfigCondition_EmailSub = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Subject_A103 Email" });

                EntityCollection CustomConfigResponse_EmailSub = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_EmailSub }, LogicalOperator.And);
                crmTrace.AppendLine("CustomConfigResponse_EmailSub Response: " + CustomConfigResponse_EmailSub.Entities.Count);
                string Subject = CustomConfigResponse_EmailSub.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);
                crmTrace.AppendLine("Subject: " + Subject);
                string Subject_Adjusted = Subject.Replace(PermitEmail_HTMLAttributes.PRM_JobNumber, JobNumber).Replace(PermitEmail_HTMLAttributes.PRM_FilingNumber, FilingNumber).Replace(PermitEmail_HTMLAttributes.PRM_Address, HouseStreet).Replace(PermitEmail_HTMLAttributes.PRM_PermitNumber, PermitNumber);
                crmTrace.AppendLine("Subject_Adjusted: " + Subject_Adjusted);
                #endregion

                #region Get Email Body
                ConditionExpression CustomConfigCondition_EmailBody = new ConditionExpression();
                if (Emailreference == EmailReferences.A24)
                    CustomConfigCondition_EmailBody = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Body_A24 Email" });
                if (Emailreference == EmailReferences.A101)
                    CustomConfigCondition_EmailBody = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Body_A101 Email" });
                if (Emailreference == EmailReferences.A102)
                    CustomConfigCondition_EmailBody = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Body_A102 Email" });
                if (Emailreference == EmailReferences.A103)
                    CustomConfigCondition_EmailBody = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "Body_A103 Email" });

                EntityCollection CustomConfigResponse_EmailBody = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_EmailBody }, LogicalOperator.And);
                crmTrace.AppendLine("CustomConfigResponse_EmailBody Response: " + CustomConfigResponse_EmailBody.Entities.Count);
                string EmailBody = CustomConfigResponse_EmailBody.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);
                crmTrace.AppendLine("EmailBody: " + EmailBody);
                #endregion

                #region Read FROM
                Guid From = EmailUserGuid; // CRM Buildings NYC DEV User
                crmTrace.AppendLine("From guid: " + From.ToString());
                #endregion

                #region Read TO contact for Email
                Guid TO = Guid.Empty;
                if (targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                TO = ((EntityReference)targetEntity[ProgressInspectionCategoryAttributeNames.ProgressInspector]).Id;

                if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                    TO = ((EntityReference)targetEntity[SpecialInspectionCategoriesAttributeNames.SpecialInspector]).Id;

                crmTrace.AppendLine("TO owner guid: " + TO.ToString());
                #endregion

                // Read Permit Html

                string Html = ReadHtml(crmTrace);

                
                string description = Html.Replace(PermitEmail_HTMLAttributes.PRM_JobNumber, JobNumber).Replace(PermitEmail_HTMLAttributes.PRM_FilingNumber, FilingNumber).Replace(PermitEmail_HTMLAttributes.PRM_Address, HouseStreet).Replace(PermitEmail_HTMLAttributes.PRM_PermitNumber, PermitNumber).Replace(PermitEmail_HTMLAttributes.PRM_EmailBody, EmailBody);
                crmTrace.AppendLine("description Message:  " + description);

                crmTrace.AppendLine("Email Started!");
                // Create 'From' activity party for the email

                Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, TO);
                Entity[] ToOwner = { toParty };

                Entity fromParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                fromParty[ActivityParty.ActivityPartId] = new EntityReference(SystemuserEntityAttributeNames.EntityName, From);
                Entity[] FromAdmin = { fromParty };

               
                // Create an e-mail message
                Entity email = new Entity();
                email.LogicalName = EmailEntityAttributeName.EntityLogicalName;
                email.Attributes.Add(EmailEntityAttributeName.From, FromAdmin);
                email.Attributes.Add(EmailEntityAttributeName.To, ToOwner);
                email.Attributes.Add(EmailEntityAttributeName.Subject, Subject_Adjusted);
                email.Attributes.Add(EmailEntityAttributeName.Description, description);
                if (targetEntity.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                    email.Attributes[EmailEntityAttributeName.Regarding] = new EntityReference(ProgressInspectionCategoryAttributeNames.EntityLogicalName, targetEntity.Id);
                if (targetEntity.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                    email.Attributes[EmailEntityAttributeName.Regarding] = new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, targetEntity.Id);
                Guid _emailId = service.Create(email);

                SendEmailRequest sendEmailreq = new SendEmailRequest

                {

                    EmailId = _emailId,

                    TrackingToken = "",

                    IssueSend = true

                };

                SendEmailResponse sendEmailresp = (SendEmailResponse)service.Execute(sendEmailreq);

                if (sendEmailresp != null)

                {

                    //Console.WriteLine("Email record created successfully");

                    //Console.ReadKey();

                }

                //throw new Exception("Testing LOC Email");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "EmailHandler - SendEmail_PermitRelated", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }


    } // class ends here
}// namespace ends here
