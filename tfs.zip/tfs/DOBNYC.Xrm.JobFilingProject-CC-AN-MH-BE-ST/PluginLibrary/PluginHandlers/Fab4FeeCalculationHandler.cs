﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using System;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;
using System.ServiceModel;
using System.Text;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class Fab4FeeCalculationHandler : PluginHandlerBase
    {
        /// <summary>
        /// This Function is used to calculate side walk shed fee based on number of shed
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <param name="messageName"></param>
        /// <returns></returns>
        public static Fab4FeeCalculationobject SideWalk_FeeCalculation(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Fab4FeeCalculationobject feeObject, string messageName)
        {
            #region Formulae for SideWalk Shed
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

                Filing Fee:
                     Size of Shed <=25 <==> Filing fee = $160(flat)
                              >25 <==> Filing fee =$160 + (diff. Size * 10)
                [diff size = Size of Shed - 25]

                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region set variables

                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFilingFee = 0;
                decimal jobCost = 0;
                decimal sizeofShed = 0;
                decimal tier1CostFee = 0;
                int recordManagementFee = 0;

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SizeoftheShed))
                {
                    sizeofShed = (targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.SizeoftheShed));

                }

                #endregion

                //this if will only execute in create of PAA
                #region PAA Create
                if (messageName == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                {
                    //all fee object variables will be mapped with target entity values
                    feeObject.PaaFee = 100;
                    feeObject.NewWorkFilingFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value + feeObject.PaaFee;
                    feeObject.RecordManagementFee = 45;
                    feeObject.Adjustment = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                    feeObject.TotalFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value + feeObject.PaaFee;


                }
                #endregion
                #region Other Than PAA Create
                else
                {
                    #region fee calculation for SideWalk Shed
                    //Get formulae name
                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = Fab4_FeeCalculationHelper.BuildFormualeName(targetEntity, crmTrace, JobFilingEntityAttributeName.SidewalkIdentifier);
                    //  throw new Exception("test" +formulaeName);
                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = Fab4_FeeCalculationHelper.RetrieveFee(crmTrace, service, formulaeName);

                    //Get variables from fee calculation configuration entity
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFilingFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                    crmTrace.AppendLine("get Minfiling fee - End" + minFilingFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        recordManagementFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee);
                    crmTrace.AppendLine("Record management Fee - End" + recordManagementFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                        tier1CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee);
                    crmTrace.AppendLine("tier1 cost Fee - End" + tier1CostFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        feeObject.PaaFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PaaFee);

                    // formulae for side walk shed fee
                    if (sizeofShed > 25)
                    {
                        jobCost = minFilingFee + ((Math.Ceiling(sizeofShed / 25) - 1) * tier1CostFee);
                    }
                    else
                    {
                        //this will execute on create
                        jobCost = minFilingFee;
                    }
                    crmTrace.AppendLine("Total job cost" + jobCost);



                    feeObject.SideWalkShedFee = jobCost;



                    crmTrace.AppendLine("Sidewalk shed fee" + feeObject.SideWalkShedFee);
                    feeObject.RecordManagementFee = recordManagementFee;
                    crmTrace.AppendLine("Sidewalk shed fee" + feeObject.RecordManagementFee);


                    #endregion
                }
                #endregion
                return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SideWalk_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        public static Fab4FeeCalculationobject Constructionfence_FeeCalculation(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Fab4FeeCalculationobject feeObject, string messageName)
        {
            #region Formulae for Construction Fence
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

                Filing Fee:
                    Filing Fee =$160(flat)

                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region set variables

                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFilingFee = 0;
                decimal interJobCost = 0;
                int recordManagementFee = 0;

                #endregion
                /// On Create of PAA Set All to zero only set paafee to 100
                /// so if(paa create)else (Not PAA,paa Update) the only change in update is if the job filing is paa then add PAA fee as 100
                /// 
                #region PAA Create
                if (messageName == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                {
                    feeObject.PaaFee = 100;
                    feeObject.NewWorkFilingFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value + feeObject.PaaFee;
                    feeObject.RecordManagementFee = 45;
                    feeObject.Adjustment = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                    feeObject.TotalFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value + feeObject.PaaFee;

                }
                #endregion
                else
                {
                    #region Fee Calculation for Construction Fence

                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = Fab4_FeeCalculationHelper.BuildFormualeName(targetEntity, crmTrace, JobFilingEntityAttributeName.FenceIdentifier);

                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = Fab4_FeeCalculationHelper.RetrieveFee(crmTrace, service, formulaeName);

                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFilingFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                    crmTrace.AppendLine("Variable Assignments - End" + minFilingFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        recordManagementFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee);
                    crmTrace.AppendLine("Variable Assignments - End" + recordManagementFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        feeObject.PaaFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PaaFee);




                    feeObject.ConstructionFenceFee = minFilingFee;


                    crmTrace.AppendLine("set Minimum filing fee :" + minFilingFee);

                    feeObject.RecordManagementFee = recordManagementFee;
                    crmTrace.AppendLine("set Record management filing fee" + interJobCost);


                    #endregion
                }

                return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Constructionfence_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static Fab4FeeCalculationobject SupportedScaffold_FeeCalculation(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Fab4FeeCalculationobject feeObject, string messageName)
        {
            #region Formulae for Supported Scaffold
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

                Filing Fee:
                    Filing Fee =$160(flat)

                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region Set Variables
                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFilingFee = 0;
                decimal tier1Cost = 0;
                decimal interJobCost = 0;
                int recordManagementFee = 0;
                #endregion
                #region PAA Create

                if (messageName == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                {
                    feeObject.PaaFee = 100;
                    feeObject.NewWorkFilingFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value + feeObject.PaaFee;
                    feeObject.RecordManagementFee = 45;
                    feeObject.Adjustment = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                    feeObject.TotalFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value + feeObject.PaaFee;

                }
                #endregion
                #region Other than PAA Create
                else
                {
                    #region Fee Calculation for Suppoerted Scaffold
                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = Fab4_FeeCalculationHelper.BuildFormualeName(targetEntity, crmTrace, JobFilingEntityAttributeName.ScaffoldIdentifier);

                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = Fab4_FeeCalculationHelper.RetrieveFee(crmTrace, service, formulaeName);

                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFilingFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                    crmTrace.AppendLine("Variable Assignments - End" + minFilingFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        recordManagementFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee);
                    crmTrace.AppendLine("Variable Assignments - End" + recordManagementFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        feeObject.PaaFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PaaFee);

                    //Fee calculation formula for curb cut
                    crmTrace.AppendLine("calculate fee for 123 family - start :" + minFilingFee + " tier1cost:" + tier1Cost);


                    feeObject.ScaffoldFee = minFilingFee; ;




                    crmTrace.AppendLine("calculate fee for 123 family - End" + interJobCost);
                    feeObject.RecordManagementFee = recordManagementFee;


                    #endregion
                }
                #endregion


                return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SupportedScaffold_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }


        /// <summary>
        /// This function is used to get whether that address is landmark or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="BIN"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static bool getLandmarkstatus(IOrganizationService service, string BIN, StringBuilder crmTrace)
        {

            try
            {



                #region Property Profile

                PropertyProfileRequest propertyRequest = new PropertyProfileRequest();
                PropertyProfileResponse propertyResponse = new PropertyProfileResponse();
                crmTrace.AppendLine("PropertyProfileRequest started");
                ExternalSystem_PropertyProfile svcProperty = new ExternalSystem_PropertyProfile();
                propertyRequest.Bin = BIN;
                propertyRequest.SourceChannel = "CRM";
                crmTrace.AppendLine("svcPropertyProfileRequest started");
                propertyResponse = svcProperty.GetPropertyProfile(propertyRequest);
                crmTrace.AppendLine("svcPropertyProfileRequest Ended");
                crmTrace.AppendLine("propertyResponse.ReturnError:" + propertyResponse.ReturnError);
                if (propertyResponse != null)
                {
                    if (string.IsNullOrEmpty(propertyResponse.ReturnError))
                    {
                        if (!(string.IsNullOrEmpty(propertyResponse.LandmarkStatus)) && propertyResponse.LandmarkStatus != null)
                        {
                            return true;
                        }
                    }

                }
                #endregion
                return false;


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("Error", "SourceChannel", "getLandmarkstatus", crmTrace.ToString(), " CreatePropertyProfile trace log", "User ID", "UserBrowserInfo");
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "getLandmarkstatus", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", "ElevatorsTrackingNumber Class - CreatePropertyProfile Method Exceptions", "browserinfo");
                return false;
            }
        }

        /// <summary>
        /// This function is used to get all signs associated to Application
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>

        public static EntityCollection assocaitedSigns(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Fab4FeeCalculationobject feeObject)
        {
            ConditionExpression deviceCondition;
            EntityCollection deviceResponse;
            try
            {
                deviceCondition = CreateConditionExpression(SignCharactersticsAttributeName.JobFilingGUID, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                deviceResponse = RetrieveMultiple(service, SignCharactersticsAttributeName.EntityLogicalName, new string[] { SignCharactersticsAttributeName.Location, SignCharactersticsAttributeName.TypeofIllumination, SignCharactersticsAttributeName.isThisProjectingSign, SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign, SignCharactersticsAttributeName.IsRoofSignTightSolidFlag, SignCharactersticsAttributeName.HeightAbovetheRoof, SignCharactersticsAttributeName.SignType, SignCharactersticsAttributeName.SignEstimatedJobCost }, new ConditionExpression[] { deviceCondition }, LogicalOperator.And);
                return deviceResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }


        /// <summary>
        /// This function is used to calculate  Mimimum fee based on estimated Sign job Cost  for 123 family type used in signs
        /// </summary>
        /// <param name="Sign"></param>
        /// <param name="minFilingFee"></param>
        /// <param name="EstimatedJobTierCost123"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static decimal signEstimatedCost123family(Entity Sign, decimal minFilingFee, decimal EstimatedJobTierCost123, StringBuilder crmTrace)
        {
            try
            {
                #region sign estimated Cost 123family
                if (Sign.Contains(SignCharactersticsAttributeName.SignEstimatedJobCost) && Sign[SignCharactersticsAttributeName.SignEstimatedJobCost] != null)
                {
                    /// calculate number of thousands in estimated cost use ceil method eg:10001 has 11 thousands
                    /// number of thousands less than 5 then apply only min fee else for remaining thousands multiply with 5.15
                    /// 



                    if (Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value <= 5000)
                    {
                        crmTrace.AppendLine("Min filing fee 123 family less than 5000 start");
                        minFilingFee = minFilingFee + 0;
                        crmTrace.AppendLine("Min filing fee 123 family less than 5000 End" + minFilingFee);
                    }
                    //greater than 5000
                    else
                    {
                        crmTrace.AppendLine("Min filing fee 123 family greater than 5000 start");
                        minFilingFee = minFilingFee + ((Math.Ceiling(Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value / 1000) - 5) * EstimatedJobTierCost123);
                        crmTrace.AppendLine("Min filing fee 123 family greater than 5000 End" + minFilingFee);
                    }
                }
                //sign estimated job cost is null
                else
                {
                    minFilingFee = minFilingFee + 0;
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCost123family", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

            return minFilingFee;
        }

        /// <summary>
        /// This function is used to calculate  Mimimum fee based on estimated Sign job Cost  for Others family type used in signs
        /// </summary>
        /// <param name="Sign"></param>
        /// <param name="minFilingFee"></param>
        /// <param name="EstimatedJobTierCost123"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static decimal signEstimatedCostothersfamily(Entity Sign, decimal minFilingFee, decimal EstimatedJobTierCost123, StringBuilder crmTrace)
        {

            try
            {
                #region sign estimated Cost Others family
                if (Sign.Contains(SignCharactersticsAttributeName.SignEstimatedJobCost) && Sign[SignCharactersticsAttributeName.SignEstimatedJobCost] != null)
                {
                    /// calculate number of thousands in estimated cost use ceil method eg:10001 has 11 thousands
                    /// number of thousands less than 5 then apply only min fee else for remaining thousands multiply with 5.15
                    /// 



                    if (Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value <= 3000)
                    {
                        crmTrace.AppendLine("Min filing fee other family less than 3000 start");
                        minFilingFee = minFilingFee + 0;
                        crmTrace.AppendLine("Min filing fee others family less than 3000 End" + minFilingFee);
                    }
                    //greater than 3000 but less than 5000
                    else if (Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value <= 5000)
                    {
                        crmTrace.AppendLine("Min filing fee other family less than 3000 start");
                        minFilingFee = minFilingFee + (Math.Ceiling(Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value / 1000) - 3) * 20;
                        crmTrace.AppendLine("Min filing fee others family less than 3000 End" + minFilingFee);
                    }
                    //greater than 5000
                    else
                    {
                        crmTrace.AppendLine("Min filing fee 123 family greater than 5000 start");
                        //added 40 because 3000 to 5000  there are 2 thousands for those two we have to multiply with 20
                        minFilingFee = minFilingFee + 40 + ((Math.Ceiling(Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.SignEstimatedJobCost).Value / 1000) - 5) * EstimatedJobTierCost123);
                        crmTrace.AppendLine("Min filing fee 123 family greater than 5000 End" + minFilingFee);
                    }
                }
                //sign estimated job cost is null
                else
                {
                    minFilingFee = minFilingFee + 0;
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("id", "CRM", "Fab4FeeCalculationHandler - signEstimatedCostothersfamily", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }


            return minFilingFee;
        }




        /// <summary>
        /// This Function has all possible conditions and their fee calculations for Sign Work Type
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="Sign"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <param name="messageName"></param>
        /// <returns></returns>

        public static Fab4FeeCalculationobject Sign_FeeCalculation(IOrganizationService service, Entity targetEntity, Entity Sign, StringBuilder crmTrace, Fab4FeeCalculationobject feeObject, string messageName)
        {
            try
            {
                #region Set Variables
                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFilingFee = 0;
                decimal tier1Cost = 0;
                decimal interJobCost = 0;
                int recordManagementFee = 0;
                decimal height = 0;
                bool landmark;
                #endregion

                #region Get Fee Calculation Parameters from fee config
                crmTrace.AppendLine("formulae Name" + formulaeName);
                formulaeName = Fab4_FeeCalculationHelper.BuildFormualeName(targetEntity, crmTrace, JobFilingEntityAttributeName.SignIdentifier);

                //Get fee calculation configuartion attributes 
                crmTrace.AppendLine("get fee calculation configuration attributes");
                retrieveFeeCollection = Fab4_FeeCalculationHelper.RetrieveFee(crmTrace, service, formulaeName);

                //Get variables from fee calculation configuration entity
                crmTrace.AppendLine("Variable Assignments - Start");
                if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                    minFilingFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                crmTrace.AppendLine("Variable Assignments - End" + minFilingFee);

                if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                    recordManagementFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee);
                crmTrace.AppendLine("Variable Assignments - End" + recordManagementFee);

                if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    feeObject.PaaFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.PaaFee);
                crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PaaFee);

                feeObject.RecordManagementFee = recordManagementFee;
                #endregion

                #region PAA Create
                if (messageName == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                {
                    feeObject.PaaFee = 100;
                    feeObject.NewWorkFilingFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NewWorkFilingFee).Value + feeObject.PaaFee;
                    feeObject.RecordManagementFee = 45;
                    feeObject.Adjustment = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                    feeObject.TotalFee = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.TotalFeeAttributeName).Value + feeObject.PaaFee;

                }
                #endregion
                #region Other than PAA Create
                else
                {
                    if (Sign != null)
                    {
                        crmTrace.AppendLine("Signs Calculation based on Location");
                        if (Sign.Contains(SignCharactersticsAttributeName.Location) && Sign[SignCharactersticsAttributeName.Location] != null)
                        {
                            crmTrace.AppendLine("Signs Calculation based on Location Switch Started");
                            #region Main Sign Fee Calculation Based on Location
                            switch (Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.Location).Value)
                            {
                                #region SignLocation- Ground Fee
                                case (int)SignLocation.Ground:
                                    {

                                        decimal EstimatedJobTierCost123 = new decimal(5.15);
                                        decimal minimumSurfaceAreaCost123 = 35;//same for others
                                        decimal minimumSurfaceAreaTierCost123 = 5;//same for others
                                        decimal EstimatedJobTierCostOther = new decimal(10.30);



                                        crmTrace.AppendLine("Signs Calculation based on Ground Location Started");
                                        #region get the landmark fee
                                        //get the location fee
                                        if (targetEntity.Contains(JobFilingEntityAttributeName.BIN) && targetEntity[JobFilingEntityAttributeName.BIN] != null)
                                        {
                                            landmark = Fab4FeeCalculationHandler.getLandmarkstatus(service, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString(), crmTrace);
                                            if (landmark == true)
                                            {
                                                feeObject.Landmarkfee = 150; //based on BRD 
                                            }
                                            else
                                            {
                                                feeObject.Landmarkfee = 0;
                                            }

                                        }
                                        #endregion

                                        #region surface area Fee
                                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) && Sign[SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign] != null)
                                        {
                                            if (Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) > 700)
                                            {
                                                minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + (Math.Ceiling(Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) / 100) - 7) * minimumSurfaceAreaTierCost123;
                                            }
                                            else
                                            {
                                                minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + 0;
                                            }
                                        }
                                        //surface area is null
                                        else
                                        {
                                            minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + 0;
                                        }
                                        #endregion

                                        #region Calculation based on Building Type
                                        switch (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value)
                                        {
                                            case 1:
                                            case 2:
                                            case 3:
                                                {
                                                    ///For 123 family calculation formula 
                                                    ///($130 for first $5000 of estimated cost + $5.15 for every thousand above $5000) + $5 for each 100 sq feet of surface area or fraction thereof, but not less than $35.
                                                    crmTrace.AppendLine("Check sign is Ground sign 123 family started");

                                                    #region sign estimated Cost 123family

                                                    minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                    #endregion

                                                    #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)
                                                    crmTrace.AppendLine("Final Sign fee start");

                                                    feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;


                                                    crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);
                                                    #endregion

                                                    crmTrace.AppendLine("Check sign is Ground  sign 123 family Ended");
                                                    break;
                                                }
                                            case 4://others
                                                {
                                                    ///for Others Family Calculation formula
                                                    ///$225 for first $3000 of estimated cost + $20 for every thousand above $3000 to $5000 + $10.30 for every thousand above $5000) + $5 for each 100 sq feet of surface area or fraction thereof, but not less than $35.
                                                    crmTrace.AppendLine("Check sign is Ground sign Others family started");

                                                    #region sign estimated Cost Others family
                                                    minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                    #endregion

                                                    #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost +feeobj.signfee (previous))

                                                    crmTrace.AppendLine("Final Sign fee others start");
                                                    feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                    crmTrace.AppendLine("Final Sign fee Others End:" + feeObject.SignFee);


                                                    #endregion
                                                    crmTrace.AppendLine("Check sign is Ground sign Others family Ended");
                                                    break;
                                                }
                                        }
                                        #endregion
                                        break;
                                    }
                                #endregion
                                #region SignLocation- Wall fee
                                case (int)SignLocation.Wall:
                                    {
                                        decimal EstimatedJobTierCost123 = new decimal(5.15);
                                        decimal minimumSurfaceAreaCost123 = 35;//same for others
                                        decimal minimumSurfaceAreaTierCost123 = 5;//same for others
                                        decimal EstimatedJobTierCostOther = new decimal(10.30);



                                        #region get the Landmark fee
                                        //get the location fee
                                        if (targetEntity.Contains(JobFilingEntityAttributeName.BIN) && targetEntity[JobFilingEntityAttributeName.BIN] != null)
                                        {
                                            landmark = Fab4FeeCalculationHandler.getLandmarkstatus(service, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString(), crmTrace);
                                            if (landmark == true)
                                            {
                                                feeObject.Landmarkfee = 100; //based on BRD 
                                            }
                                            else
                                            {
                                                feeObject.Landmarkfee = 0;
                                            }

                                        }
                                        #endregion

                                        #region surface area Fee
                                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) && Sign[SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign] != null)
                                        {
                                            if (Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) > 700)
                                            {
                                                minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + (Math.Ceiling(Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) / 100) - 7) * minimumSurfaceAreaTierCost123;
                                            }
                                            else
                                            {
                                                minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + 0;
                                            }
                                        }
                                        //surface area is null
                                        else
                                        {
                                            minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + 0;
                                        }
                                        #endregion
                                        /// wall fee calculation is based on projecting sign and sign type-illuminating,non-illuminating
                                        crmTrace.AppendLine("Signs Calculation based on Wall Location Started");
                                        crmTrace.AppendLine("Check sign is illuminated and projecting sign");


                                        if ((Sign.Contains(SignCharactersticsAttributeName.isThisProjectingSign) && Sign[SignCharactersticsAttributeName.isThisProjectingSign] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.isThisProjectingSign) == true) &&
                                            (Sign.Contains(SignCharactersticsAttributeName.SignType) && Sign[SignCharactersticsAttributeName.SignType] != null && Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.SignType).Value == (int)SignType.Illuminated))
                                        {
                                            crmTrace.AppendLine("Check sign is illuminated and projecting sign entered");
                                            if (targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                                            {
                                                #region Calculation based on Building Type
                                                switch (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value)
                                                {
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                        {
                                                            ///For illuminting and projecting sign fee calculation formula 123 family
                                                            ///$130 for first $5000 estimated cost + $5.15 for every thousand above $5000   (NO SURFACE AREA FEE)
                                                            crmTrace.AppendLine("Check sign is illuminated and projecting sign 123 family started");

                                                            #region sign estimated Cost 123family

                                                            minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                            #endregion

                                                            #region Main Formula for sign fee (Minimum estimated job cost + Landmark fee cost +feeobj.signfee (previous))
                                                            crmTrace.AppendLine("Final Sign fee others start");
                                                            feeObject.SignFee = minFilingFee + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee Others End:" + feeObject.SignFee);


                                                            #endregion

                                                            crmTrace.AppendLine("Check sign is illuminated and projecting sign 123 family Ended");
                                                            break;
                                                        }
                                                    case 4://others
                                                        {
                                                            ///for illuminating and projecting sign fee calculation formula others family
                                                            ///$225 for first $3000 of estimated cost + $20 for every thousand above $3000 to $5000 + $10.30 for every thousand above $5000 (NO SURFACE AREA FEE)
                                                            crmTrace.AppendLine("Check sign is illuminated and projecting sign Others family started");

                                                            #region sign estimated Cost Others family
                                                            minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                            #endregion

                                                            #region Main Formula for sign fee (Minimum estimated job cost + Landmark fee cost +feeobj.signfee (previous))


                                                            crmTrace.AppendLine("Final Sign fee others start");
                                                            feeObject.SignFee = minFilingFee + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee Others End:" + feeObject.SignFee);


                                                            #endregion
                                                            crmTrace.AppendLine("Check sign is illuminated and projecting sign Others family Ended");
                                                            break;
                                                        }
                                                }
                                                #endregion
                                            }

                                        }
                                        else
                                        {
                                            crmTrace.AppendLine("Check sign is  Non-illuminated ");
                                            #region Calculation based on Building Type
                                            switch (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value)
                                            {
                                                case 1:
                                                case 2:
                                                case 3:
                                                    {
                                                        crmTrace.AppendLine("Check sign is  Non-illuminated and projecting sign 123 family started");

                                                        #region sign estimated Cost 123family

                                                        minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                        #endregion

                                                        #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)

                                                        crmTrace.AppendLine("Final Sign fee start");
                                                        feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                        crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);


                                                        #endregion
                                                        crmTrace.AppendLine("Check sign is  Non-illuminated and projecting sign 123 family Ended");
                                                        break;
                                                    }
                                                case 4://others
                                                    {
                                                        crmTrace.AppendLine("Check sign is  Non-illuminated and projecting sign Others family started");

                                                        #region sign estimated Cost Others family
                                                        minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                        #endregion

                                                        #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)

                                                        crmTrace.AppendLine("Final Sign fee start");
                                                        feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                        crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);


                                                        #endregion

                                                        crmTrace.AppendLine("Check sign is  Non-illuminated and projecting sign Others family Ended");
                                                        break;
                                                    }
                                            }
                                            #endregion
                                        }
                                        break;
                                    }
                                #endregion
                                #region SignLocation- Roof fee
                                case (int)SignLocation.Roof:
                                    {

                                        decimal EstimatedJobTierCost123 = new decimal(5.15);
                                        decimal minimumSurfaceAreaCost123 = 35;//same for others
                                        decimal minimumSurfaceAreaTierCost123 = 15;//same for others
                                        decimal EstimatedJobTierCostOther = new decimal(10.30);


                                        #region get the location fee
                                        //get the location fee
                                        if (targetEntity.Contains(JobFilingEntityAttributeName.BIN) && targetEntity[JobFilingEntityAttributeName.BIN] != null)
                                        {
                                            landmark = Fab4FeeCalculationHandler.getLandmarkstatus(service, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString(), crmTrace);
                                            if (landmark == true)
                                            {
                                                feeObject.Landmarkfee = 150; //based on BRD 
                                            }
                                            else
                                            {
                                                feeObject.Landmarkfee = 0;
                                            }

                                        }
                                        #endregion

                                        #region surface area Fee
                                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) && Sign[SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign] != null)
                                        {
                                            if (Sign.Contains(SignCharactersticsAttributeName.HeightAbovetheRoof) && Sign[SignCharactersticsAttributeName.HeightAbovetheRoof] != null &&
                                              ((Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == false) || Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] == null))
                                            {
                                                if (Convert.ToDecimal(targetEntity.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAbovetheRoof)) <= 31)
                                                {
                                                    if (Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) > 660)
                                                    {
                                                        minimumSurfaceAreaCost123 = 100 + (Math.Ceiling(Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) / 100) - 6) * minimumSurfaceAreaTierCost123;
                                                    }
                                                    else
                                                    {
                                                        minimumSurfaceAreaCost123 = 100;
                                                    }
                                                }
                                                else if (Convert.ToDecimal(targetEntity.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAbovetheRoof)) > 31)
                                                {
                                                    if (Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) > 540)
                                                    {
                                                        minimumSurfaceAreaCost123 = 135 + (Math.Ceiling(Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) / 100) - 5) * 25;
                                                    }
                                                    else
                                                    {
                                                        minimumSurfaceAreaCost123 = 135;
                                                    }
                                                }
                                            }
                                            else if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == true)
                                            {
                                                if (Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) > 467)
                                                {
                                                    minimumSurfaceAreaCost123 = 70 + (Math.Ceiling(Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaOfThisSign) / 100) - 4) * minimumSurfaceAreaTierCost123;
                                                }
                                                else
                                                {
                                                    minimumSurfaceAreaCost123 = 70;
                                                }
                                            }


                                        }
                                        //surface area is null
                                        else
                                        {
                                            minimumSurfaceAreaCost123 = minimumSurfaceAreaCost123 + 0;
                                        }
                                        #endregion
                                        #region Calculation based on Building Type
                                        switch (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value)
                                        {
                                            ///roof fee is based on two flags issigntightclosedflag, heightofroof
                                            case 1:
                                            case 2:
                                            case 3:
                                                {
                                                    crmTrace.AppendLine("Check sign Location is Roof 123 family started");

                                                    #region Possible Conditions 
                                                    crmTrace.AppendLine("Check roof istightclosed");
                                                    if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == true)
                                                    {
                                                        crmTrace.AppendLine("Check roof is tightclosed started");
                                                        #region sign estimated Cost 123family

                                                        minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                        #endregion
                                                        #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)

                                                        crmTrace.AppendLine("Final Sign fee start");
                                                        feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                        crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                        #endregion
                                                        crmTrace.AppendLine("Check roof is tightclosed End");
                                                    }

                                                    else if (((Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == false) || Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] == null) &&
                                                        (Sign.Contains(SignCharactersticsAttributeName.HeightAbovetheRoof) && Sign[SignCharactersticsAttributeName.HeightAbovetheRoof] != null))
                                                    {
                                                        crmTrace.AppendLine("Check roof is  not tightclosed and has height above roof --started");
                                                        height = Convert.ToDecimal(targetEntity.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAbovetheRoof));
                                                        if (height <= 31)
                                                        {
                                                            crmTrace.AppendLine("Check roof  height above roof is <31 --started");
                                                            #region sign estimated Cost 123family

                                                            minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                            #endregion
                                                            #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)


                                                            crmTrace.AppendLine("Final Sign fee start");
                                                            feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                            #endregion
                                                            crmTrace.AppendLine("Check roof  height above roof is <31 --End");
                                                        }
                                                        else if (height > 31)
                                                        {
                                                            crmTrace.AppendLine("Check roof  height above roof is >31 --started");
                                                            //for height>31 landmark fee is different
                                                            #region get the location fee
                                                            //get the location fee
                                                            if (targetEntity.Contains(JobFilingEntityAttributeName.BIN) && targetEntity[JobFilingEntityAttributeName.BIN] != null)
                                                            {
                                                                landmark = Fab4FeeCalculationHandler.getLandmarkstatus(service, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString(), crmTrace);
                                                                if (landmark == true)
                                                                {
                                                                    feeObject.Landmarkfee = 200; //based on BRD 
                                                                }
                                                                else
                                                                {
                                                                    feeObject.Landmarkfee = 0;
                                                                }

                                                            }
                                                            #endregion
                                                            #region sign estimated Cost 123family

                                                            minFilingFee = signEstimatedCost123family(Sign, minFilingFee, EstimatedJobTierCost123, crmTrace);

                                                            #endregion
                                                            #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)


                                                            crmTrace.AppendLine("Final Sign fee start");
                                                            feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                            #endregion
                                                            crmTrace.AppendLine("Check roof  height above roof is >31 --End");
                                                        }
                                                        crmTrace.AppendLine("Check roof is  not tightclosed and has height above roof --ended");
                                                    }
                                                    #endregion


                                                    crmTrace.AppendLine("Check sign Location is Roof  123 family Ended");
                                                    break;
                                                }
                                            case 4://others
                                                {
                                                    crmTrace.AppendLine("Check sign Location is Roof  Others family started");

                                                    #region Possible Conditions 
                                                    crmTrace.AppendLine("Check roof istightclosed others");
                                                    if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == true)
                                                    {
                                                        crmTrace.AppendLine("Check roof is tightclosed started others");
                                                        #region sign estimated Cost Others family
                                                        minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                        #endregion
                                                        #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)



                                                        crmTrace.AppendLine("Final Sign fee start");
                                                        feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                        crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                        #endregion
                                                        crmTrace.AppendLine("Check roof is tightclosed End others");
                                                    }

                                                    else if (((Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null && Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) == false) || Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] == null) &&
                                                        (Sign.Contains(SignCharactersticsAttributeName.HeightAbovetheRoof) && Sign[SignCharactersticsAttributeName.HeightAbovetheRoof] != null))
                                                    {
                                                        crmTrace.AppendLine("Check roof is  not tightclosed and has height above roof others--started");
                                                        height = Convert.ToDecimal(targetEntity.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAbovetheRoof));
                                                        if (height <= 31)
                                                        {
                                                            crmTrace.AppendLine("Check roof  height above roof is <31 others--started");
                                                            #region sign estimated Cost Others family
                                                            minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                            #endregion
                                                            #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)


                                                            crmTrace.AppendLine("Final Sign fee start");
                                                            feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                            #endregion
                                                            crmTrace.AppendLine("Check roof  height above roof is <31 others--End");
                                                        }
                                                        else if (height > 31)
                                                        {
                                                            crmTrace.AppendLine("Check roof  height above roof is >31 others--started");
                                                            //for height>31 landmark fee is different
                                                            #region get the location fee
                                                            //get the location fee
                                                            if (targetEntity.Contains(JobFilingEntityAttributeName.BIN) && targetEntity[JobFilingEntityAttributeName.BIN] != null)
                                                            {
                                                                landmark = Fab4FeeCalculationHandler.getLandmarkstatus(service, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString(), crmTrace);
                                                                if (landmark == true)
                                                                {
                                                                    feeObject.Landmarkfee = 200; //based on BRD 
                                                                }
                                                                else
                                                                {
                                                                    feeObject.Landmarkfee = 0;
                                                                }

                                                            }
                                                            #endregion

                                                            #region sign estimated Cost Others family
                                                            minFilingFee = signEstimatedCostothersfamily(Sign, minFilingFee, EstimatedJobTierCostOther, crmTrace);

                                                            #endregion
                                                            #region Main Formula for sign fee (Minimum estimated job cost+minimum surface cost + Landmark fee cost + feeObject.SignFee)



                                                            crmTrace.AppendLine("Final Sign fee start");
                                                            feeObject.SignFee = minFilingFee + minimumSurfaceAreaCost123 + feeObject.Landmarkfee + feeObject.SignFee;
                                                            crmTrace.AppendLine("Final Sign fee End:" + feeObject.SignFee);

                                                            #endregion
                                                            crmTrace.AppendLine("Check roof  height above roof is >31 others--End");
                                                        }
                                                        crmTrace.AppendLine("Check roof is  not tightclosed and has height above roof others--ended");
                                                    }
                                                    #endregion

                                                    crmTrace.AppendLine("Check sign Location is Roof  Others family Ended");
                                                    break;
                                                }
                                        }
                                        #endregion

                                        break;
                                    }
                                    #endregion
                            }
                            #endregion
                        }
                    }
                }
                #endregion











                return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - Sign_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }



        /// <summary>
        /// This function will return whether the jobfiling has any PH with is posted true 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        /// <returns></returns>
        public static bool isPostedPaymentHistories(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            try
            {

                //retreive the Job filing application field and Is posted equals to NO
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_jobfilinglookup' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_jobfiling' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='1' operator='eq'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                EntityCollection OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                if (OldPhhistory.Entities.Count > 0)
                {
                    return true;
                }
                return false;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        /// <summary>
        /// This function is used to delete the PH which are is posted false. 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        public static void DeleteOldPaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            try
            {

                //retreive the Job filing application field and Is posted equals to NO
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_jobfilinglookup' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_jobfiling' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='0' operator='eq'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                EntityCollection OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                if (OldPhhistory.Entities.Count > 0)
                {
                    foreach (Entity phhistory in OldPhhistory.Entities)
                    {
                        crmTrace.AppendLine("Delete old payment history records -start");
                        service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phhistory.Id);
                        crmTrace.AppendLine("Delete old payment history records-DeleteOldPaymentHistoryCC - end");
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationHelper - DeleteOldPaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        /// <summary>
        /// This Function handles the main logic for calculating Total fee,amount due,New filing fee.
        /// </summary>
        /// <param name="feeObject"></param>
        /// <param name="targetEntity"></param>
        /// <param name="service"></param>
        /// <param name="preImage"></param>
        /// <param name="crmTrace"></param>
        /// <param name="sharedVariables"></param>
        /// <param name="context"></param>

        public static void TotalFee(Fab4FeeCalculationobject feeObject, Entity targetEntity, IOrganizationService service, Entity preImage, StringBuilder crmTrace, ParameterCollection sharedVariables, IPluginExecutionContext context)
        {
            try
            {


                #region Set Variables
                decimal totalfee = 0;
                decimal amountDue = 0;
                decimal existingamountPaid = 0;
                decimal legalizationMultiplier = new decimal(14);

                if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.NewJobFiling)
                {
                    existingamountPaid = 0;
                }
                else
                {
                    if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))//  Targetentity condition  will be executed  only in PAA Create
                    {
                        existingamountPaid = targetEntity.Contains(JobFilingEntityAttributeName.AmountPaid) && targetEntity[JobFilingEntityAttributeName.AmountPaid] != null ? ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value : ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                        crmTrace.AppendLine("Exsisting amount paid" + existingamountPaid);
                        feeObject.existingamountpaid = existingamountPaid;
                    }
                }

                #endregion

                // If InConjunction fee will be calculated but RecordManagement fee will be 0.
                bool InconjunctionNewJob = (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null) ?
                     targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) : false;
                bool InaltJob = (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null) ?
                    targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) : false;

                #region Fee Exempt Check (Make sign fee,cF fee,SF fee,SWS fee, RecordMGMT fee to 0)
                if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == true))
                {
                    feeObject.SignFee = 0;
                    feeObject.ScaffoldFee = 0;
                    feeObject.SideWalkShedFee = 0;
                    feeObject.ConstructionFenceFee = 0;
                    feeObject.RecordManagementFee = 0;
                }

                #endregion

                #region Inconjunction NEW JOB (Flat FEE 100 Only for Signs not for other work types)
                if (InconjunctionNewJob == true && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity[JobFilingEntityAttributeName.Sign] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true))
                {
                    feeObject.SignFee = 100;
                    feeObject.RecordManagementFee = 0;
                }
                #endregion

                #region Legalization job and new Filing Job
                if (targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.Legal)
                {
                    crmTrace.AppendLine("Legalization Sign start");
                    feeObject.SignFee = feeObject.SignFee * legalizationMultiplier;
                    feeObject.ConstructionFenceFee = feeObject.ConstructionFenceFee * legalizationMultiplier;
                    feeObject.ScaffoldFee = feeObject.ScaffoldFee * legalizationMultiplier;
                    feeObject.SideWalkShedFee = feeObject.SideWalkShedFee * legalizationMultiplier;

                    crmTrace.AppendLine("Legalization Sign End");
                }
                else
                {
                    //crmTrace.AppendLine("Normal Fee  start");
                    //feeObject.SignFee = feeObject.SignFee ;
                    //feeObject.ConstructionFenceFee = feeObject.ConstructionFenceFee ;
                    //feeObject.ScaffoldFee = feeObject.ScaffoldFee;
                    //feeObject.SideWalkShedFee = feeObject.SideWalkShedFee ;

                    //crmTrace.AppendLine("Normal Fee  End");
                }
                #endregion

                ///This conjunction and else block will only execute when filing is not PAA Create
                #region This region will execute in all conditions except PAA Create
                if (!(context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper() && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA))
                {
                    //alt job - NO record mgmt fee  in calculation only for signs 
                    if (InaltJob == true && (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity[JobFilingEntityAttributeName.Sign] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true))
                    {
                        //Get total fee from 
                        //to be removed- signs fee calculation
                        crmTrace.AppendLine("Set total fee ");
                        crmTrace.AppendLine("Add All fab4 fee swsfee, cffee, sffee, signfee, paafee  But Not Recordmgmt fee");
                        feeObject.NewWorkFilingFee = feeObject.SideWalkShedFee + feeObject.ConstructionFenceFee + feeObject.ScaffoldFee + feeObject.SignFee + feeObject.PaaFee;
                        feeObject.TotalFee = feeObject.SideWalkShedFee + feeObject.ConstructionFenceFee + feeObject.ScaffoldFee + feeObject.SignFee + feeObject.PaaFee;
                        feeObject.RecordManagementFee = 0;// for creating transaction history's
                    }
                    //in conjunction-flat fee 100



                    // fee calculation (new work filing fee + record management fee)
                    else
                    {
                        crmTrace.AppendLine("Add All fab4 fee swsfee, cffee, sffee, signfee, paafee and Recordmgmt fee");

                        feeObject.TotalFee = feeObject.SideWalkShedFee + feeObject.ConstructionFenceFee + feeObject.ScaffoldFee + feeObject.SignFee + feeObject.RecordManagementFee + feeObject.PaaFee;
                        feeObject.NewWorkFilingFee = feeObject.SideWalkShedFee + feeObject.ConstructionFenceFee + feeObject.ScaffoldFee + feeObject.SignFee + feeObject.PaaFee;
                        feeObject.RecordManagementFee = feeObject.RecordManagementFee;
                    }
                }
                #endregion
                else
                {
                    //PAA Create
                    crmTrace.AppendLine("PAA Create SetAttributeValue Start" + feeObject.PaaFee);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(feeObject.PaaFee));
                    crmTrace.AppendLine("PAA Create SetAttributeValue End");
                }


                amountDue = feeObject.TotalFee - existingamountPaid;
                crmTrace.AppendLine("amountDue" + amountDue);
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(feeObject.NewWorkFilingFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(feeObject.TotalFee));
                //  CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(existingamountPaid));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(feeObject.RecordManagementFee));


                crmTrace.AppendLine("if total filing fee is less that amount paid");
                if (feeObject.TotalFee < existingamountPaid)
                {
                    crmTrace.AppendLine("Job filing FAB4 Entity for Update - Populate Adjustment Amount");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                    feeObject.AmountDue = 0;
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(existingamountPaid - feeObject.TotalFee));
                    // using the adjustment fromshared variables
                    feeObject.Adjustment = (existingamountPaid - feeObject.TotalFee);
                }
                else
                {
                    crmTrace.AppendLine("Job filing FAB4 Entity for Update - Populate Amount Due");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                    feeObject.AmountDue = amountDue;
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(0));
                    feeObject.Adjustment = 0;
                }

                #region assign shared variables  to post operation from fee object
                // To make use of all fee related variables in post operation
                sharedVariables.Add(JobFilingEntityAttributeName.sharedCFFee, feeObject.ConstructionFenceFee);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedScaffoldFee, feeObject.ScaffoldFee);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedSidewalkFee, feeObject.SideWalkShedFee);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedSignFee, feeObject.SignFee);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedRecordMgmt, feeObject.RecordManagementFee);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedBuildingType, feeObject.BuildingType);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedRefund, feeObject.Adjustment);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedAmountdue, feeObject.AmountDue);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedExistingAmountPaid, feeObject.existingamountpaid);
                sharedVariables.Add(JobFilingEntityAttributeName.sharedPaaFee, feeObject.PaaFee);

                #endregion


                //return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        /// <summary>
        /// This function has all the conditions for when a particular transaction histrory should create and associate it to PH
        /// </summary>
        /// <param name="SharedVariables"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <returns></returns>

        public static Fab4FeeCalculationobject CreateFAB4TransactionHistoryRecords(ParameterCollection SharedVariables, Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace, Entity preImage)
        {
            try
            {

                /// ALL PAA Conditions will fall under existing amount paid has value and amount due is greater than zero.




                #region Set Variables
                ConditionExpression condition = null;
                Guid transHistoryGuids = new Guid();
                Fab4FeeCalculationobject feeObject = new Fab4FeeCalculationobject();
                #endregion
                crmTrace.AppendLine("Start get details from shared variables");
                #region get values from shared variables and assign it to feeobject
                feeObject = SetFeeObjectFromSharedVariables(SharedVariables, targetEntity, crmTrace);
                #endregion

                crmTrace.AppendLine("End get details from shared variables");

                #region User does not pay anything till now

                if (feeObject.existingamountpaid == 0)
                {
                    /// if feeobject has some value then we need to create a transaction history for that work type

                    //  feeObject = (Fab4FeeCalculationobject)SharedVariables[JobFilingEntityAttributeName.Fab4SharedVariable];

                    //In Fab4 3 work types can be filed together(Construction Fence, SideWlak Shed, Supported Scaffold).
                    if (feeObject.ConstructionFenceFee > 0)
                    {
                        // get transaction codes  
                        crmTrace.AppendLine("Create Transaction History for CF-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.ConstructionFence, feeObject.ConstructionFenceFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for CF-End");
                    }
                    if (feeObject.ScaffoldFee > 0)
                    {
                        crmTrace.AppendLine("Create Transaction History for SF-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.SupportedScaffold, feeObject.ScaffoldFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for SF-End");

                    }
                    if (feeObject.SideWalkShedFee > 0)
                    {
                        crmTrace.AppendLine("Create Transaction History for SWS-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.SidewalkShed, feeObject.SideWalkShedFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for SWS-End");

                    }

                    if (feeObject.SignFee > 0)
                    {
                        crmTrace.AppendLine("Create Transaction History for Sign-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.Signs, feeObject.SignFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Sign-End");
                    }
                    if (feeObject.RecordManagementFee > 0 && (feeObject.BuildingType == FAB4BuildingType.familyHouse1 || feeObject.BuildingType == FAB4BuildingType.familyHouse2 || feeObject.BuildingType == FAB4BuildingType.familyHouse3))
                    {
                        crmTrace.AppendLine("Create Transaction History for RecordMGMT-Start 123");
                        transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_123family, feeObject.RecordManagementFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for RecordMGMT-End 123");

                    }
                    //record management fee  has two different Fee values based on building type
                    if (feeObject.RecordManagementFee > 0 && feeObject.BuildingType == FAB4BuildingType.familyHouseOther)
                    {
                        crmTrace.AppendLine("Create Transaction History for RecordMGMT-Start other");
                        transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_Others, feeObject.RecordManagementFee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for RecordMGMT-End other");
                    }
                    //  for adjustment
                    if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && feeObject.Adjustment > 0)
                    {
                        crmTrace.AppendLine("Condition Expression for Adjustment");
                        transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.Adjustment, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }
                }

                #endregion

                #region user Paid some Amount
                else if (feeObject.existingamountpaid > 0)
                {



                    //If user needs to pay some amount because of adding new work type or chnaging size of shed
                    if (feeObject.AmountDue > 0)
                    {

                        decimal amountDue = feeObject.AmountDue;

                        ///for CT,SS,Record MGMT Fee (Based on inconjunction flag) transaction codes only added when preimage is null or false and target entity is true
                        ///For SWS Two cases
                        ///1)Is SWS is newely added i.e.preimage is null or false and target is true
                        ///2)size of shed is changed -Check preimage and target then subtract
                        ///

                        ///1)check job type is paa and paa fee >0
                        ///if yes then check any payment posted flags are present if yes then do not create TH for PAA if no  then create one.
                        ///
                        //This will execute  only when PAA has fee and filingtype is PAA
                        if (feeObject.PaaFee > 0 && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        {
                            //do not add paa TH to PH if application has any PH  with is posted true because they paid initially.
                            if (!isPostedPaymentHistories(service, crmTrace, targetEntity))
                            {
                                if (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && targetEntity[JobFilingEntityAttributeName.Sign] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                                {
                                    crmTrace.AppendLine("Condition Expression for PAA FEE");
                                    transactionHistoryHelper(Fab4_TransactionCodes.SignsPAA, feeObject.PaaFee, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for PAA FEE-End");
                                }
                                else
                                {
                                    crmTrace.AppendLine("Condition Expression for PAA FEE");
                                    transactionHistoryHelper(Fab4_TransactionCodes.PAA, feeObject.PaaFee, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for PAA FEE-End");
                                }
                                amountDue = amountDue - feeObject.PaaFee;

                            }

                        }


                        #region CF,SF,RecordMGMT
                        //newly added CF
                        if (preImage.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence) && preImage[JobFilingEntityAttributeName.ConstructionFence] != targetEntity[JobFilingEntityAttributeName.ConstructionFence] && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                        {
                            if (feeObject.ConstructionFenceFee > 0 && amountDue > 0)
                            {
                                //create trans history for CF
                                crmTrace.AppendLine("Create Transaction History for CF after amount paid-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.ConstructionFence, feeObject.ConstructionFenceFee, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for CF after amount paid-End");
                                amountDue = amountDue - feeObject.ConstructionFenceFee;
                            }

                        }
                        //Newly Added SF
                        if (preImage.Contains(JobFilingEntityAttributeName.SupportedScaffold) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold) && preImage[JobFilingEntityAttributeName.SupportedScaffold] != targetEntity[JobFilingEntityAttributeName.SupportedScaffold] && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)
                        {
                            if (feeObject.ScaffoldFee > 0 && amountDue > 0)
                            {
                                //create trans history for SF
                                crmTrace.AppendLine("Create Transaction History for SF after amount paid-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.SupportedScaffold, feeObject.ScaffoldFee, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for SF after amount paid-End");
                                amountDue = amountDue - feeObject.ScaffoldFee;
                            }

                        }
                        //Newly Added inconjumction Flag
                        if (preImage.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && preImage[JobFilingEntityAttributeName.InConjunctionFlag] != targetEntity[JobFilingEntityAttributeName.InConjunctionFlag] && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) == true)
                        {
                            if (feeObject.RecordManagementFee > 0 && feeObject.RecordManagementFee == 45 && amountDue > 0)//for 123 family
                            {
                                //create trans history for RecordMGMT
                                crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_123family, feeObject.RecordManagementFee, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-End");
                                amountDue = amountDue - feeObject.RecordManagementFee;
                            }
                            else if (feeObject.RecordManagementFee > 0 && feeObject.RecordManagementFee == 165 && amountDue > 0)//for others
                            {
                                crmTrace.AppendLine("Create Transaction History for RecordMGMT Other after amount paid-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_Others, feeObject.RecordManagementFee, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                amountDue = amountDue - feeObject.RecordManagementFee;
                            }

                        }
                        #endregion

                        #region Side walk Shed (else if)
                        //this if should execute after all above conditions then remaining Amount due will excatly gives sws fee.
                        if (preImage.Contains(JobFilingEntityAttributeName.SidewalkShed) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed) &&

                            targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true && amountDue > 0)
                        {
                            crmTrace.AppendLine("Entered SWS After Payment");
                            //Newly Checked sws
                            //preImage[JobFilingEntityAttributeName.SidewalkShed] == null && preImage[JobFilingEntityAttributeName.SizeoftheShed]==null &&
                            if (preImage[JobFilingEntityAttributeName.SidewalkShed] != targetEntity[JobFilingEntityAttributeName.SidewalkShed] && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)
                            {
                                crmTrace.AppendLine("Create Transaction History for SWS after amount paid-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.SidewalkShed, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for SWS after amount paid-End");
                            }
                            //Changed the existing size of shed
                            else if (preImage[JobFilingEntityAttributeName.SizeoftheShed] != null && preImage[JobFilingEntityAttributeName.SizeoftheShed] != targetEntity[JobFilingEntityAttributeName.SizeoftheShed] && targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.SizeoftheShed) > preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.SizeoftheShed))
                            {
                                crmTrace.AppendLine("Create Transaction History for SWS after amount paid change size of shed-Start");
                                transactionHistoryHelper(Fab4_TransactionCodes.SidewalkShed, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for SWS after amount paid change size of shed-End");
                            }
                        }


                        #endregion

                        #region signs
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true && amountDue > 0)
                        {
                            //Newly Added sign or they may change existing sign details.
                            crmTrace.AppendLine("Create Transaction History for Signs after amount paid -Start");
                            transactionHistoryHelper(Fab4_TransactionCodes.Signs, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                            crmTrace.AppendLine("Create Transaction History for Signs after amount paid -End");
                        }
                        #endregion

                        //Needs to add PAA Transaction history block
                      

                    }
                    //existing amount paid>0  then adjustment.
                    if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && feeObject.Adjustment > 0)
                    {
                        crmTrace.AppendLine("Condition Expression for Adjustment");
                        transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.Adjustment, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }

                }
                #endregion

                return feeObject;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - TotalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        /// <summary>
        /// this function is used to create transaction history based on transcode passed
        /// </summary>
        /// <param name="fab4transcodes"></param>
        /// <param name="transFee"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        public static void transactionHistoryHelper(string fab4transcodes, decimal transFee, Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("COndition expression for" + fab4transcodes);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { fab4transcodes });
                crmTrace.AppendLine("get transaction code for" + fab4transcodes);
                EntityCollection transactioncodeResponse = Fab4_FeeCalculationHelper.GetTransactionCodes(service, targetEntity, crmTrace, condition);
                if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                {
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                    Guid transHistoryGuids = (Fab4_FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, targetEntity.Id, paymentHistoryId, transactioncodeResponse.Entities[0], new Money(transFee)));
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        /// <summary>
        /// This Function is used to retreive all values from shared variables and assign it to feeobject
        /// </summary>
        /// <param name="SharedVariables"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Fab4FeeCalculationobject SetFeeObjectFromSharedVariables(ParameterCollection SharedVariables, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                Fab4FeeCalculationobject feeObject = new Fab4FeeCalculationobject();


                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedCFFee) && SharedVariables[JobFilingEntityAttributeName.sharedCFFee] != null)
                {
                    crmTrace.AppendLine("get fence fee from shared variables");
                    feeObject.ConstructionFenceFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedCFFee];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedScaffoldFee) && SharedVariables[JobFilingEntityAttributeName.sharedScaffoldFee] != null)
                {
                    crmTrace.AppendLine("get ScaffoldFee from shared variables");
                    feeObject.ScaffoldFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedScaffoldFee];
                }

                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedSidewalkFee) && SharedVariables[JobFilingEntityAttributeName.sharedSidewalkFee] != null)
                {
                    crmTrace.AppendLine("get SideWalkShedFee from shared variables");
                    feeObject.SideWalkShedFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedSidewalkFee];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedSignFee) && SharedVariables[JobFilingEntityAttributeName.sharedSignFee] != null)
                {
                    crmTrace.AppendLine("get SignFee from shared variables");
                    feeObject.SignFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedSignFee];
                }

                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedRecordMgmt) && SharedVariables[JobFilingEntityAttributeName.sharedRecordMgmt] != null)
                {
                    crmTrace.AppendLine("get RecordManagementFee from shared variables");
                    feeObject.RecordManagementFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedRecordMgmt];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedBuildingType) && SharedVariables[JobFilingEntityAttributeName.sharedBuildingType] != null)
                {
                    crmTrace.AppendLine("get BuildingType from shared variables");
                    feeObject.BuildingType = (int)SharedVariables[JobFilingEntityAttributeName.sharedBuildingType];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedRefund) && SharedVariables[JobFilingEntityAttributeName.sharedRefund] != null)
                {
                    crmTrace.AppendLine("get Adjustment from shared variables");
                    feeObject.Adjustment = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedRefund];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedAmountdue) && SharedVariables[JobFilingEntityAttributeName.sharedAmountdue] != null)
                {
                    crmTrace.AppendLine("get AmountDue from shared variables");
                    feeObject.AmountDue = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedAmountdue];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedExistingAmountPaid) && SharedVariables[JobFilingEntityAttributeName.sharedExistingAmountPaid] != null)
                {
                    crmTrace.AppendLine("get AmountDue from shared variables");
                    feeObject.existingamountpaid = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedExistingAmountPaid];
                }
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedPaaFee) && SharedVariables[JobFilingEntityAttributeName.sharedPaaFee] != null)
                {
                    crmTrace.AppendLine("get sharedElectricalFee from shared variables");
                    feeObject.PaaFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedPaaFee];
                }
                //electrical
                if (SharedVariables.Contains(JobFilingEntityAttributeName.sharedElectricalFee) && SharedVariables[JobFilingEntityAttributeName.sharedElectricalFee] != null)
                {
                    crmTrace.AppendLine("get sharedElectricalFee from shared variables");
                    feeObject.ElectricalFee = (decimal)SharedVariables[JobFilingEntityAttributeName.sharedElectricalFee];
                }

                return feeObject;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - SetFeeObjectFromSharedVariables", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
        public static Fab4FeeCalculationobject CreateElectricalTransactionHistoryRecords(Fab4FeeCalculationobject feeObject, Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                #region Set Variables
                ConditionExpression condition = null;
                Guid transHistoryGuids = new Guid();
                #endregion
                crmTrace.AppendLine("Start get details from shared variables");


                #region user did not pay any amount till now
                if (feeObject != null)
                {


                    if (feeObject.existingamountpaid == 0)
                    {
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                        {
                            int filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                            if (filingType != (int)FilingType.PAA)
                            {
                                condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { Electrical_TransactionCodes.Electrical });

                            }
                            else if (filingType == (int)FilingType.PAA)
                            {

                                condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { Electrical_TransactionCodes.PAA });
                            }
                            crmTrace.AppendLine("filingType :" + filingType);

                        }


                        //In Fab4 3 work types can be filed together(Construction Fence, SideWlak Shed, Supported Scaffold).
                        if (feeObject.AmountDue > 0)
                        {
                            // get transaction codes  
                            crmTrace.AppendLine("COndition expression for ElectricalFee ");

                            crmTrace.AppendLine("get transaction code for Electrical Fee " + paymentHistoryId);
                            EntityCollection transactioncodeResponse = Fab4_FeeCalculationHelper.GetTransactionCodes(service, targetEntity, crmTrace, condition);
                            if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                            {
                                // create transaction history and add transaction history guid to fee object list 
                                crmTrace.AppendLine("create transaction history for Electrical Fee- start");
                                transHistoryGuids = (Fab4_FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, targetEntity.Id, paymentHistoryId, transactioncodeResponse.Entities[0], new Money(feeObject.AmountDue)));
                                crmTrace.AppendLine("create transaction history for cElectrical Fee- end");

                            }
                        }

                    }

                    #endregion

                    #region user pays some amount to DOB
                    //  for adjustment
                    if (targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && feeObject.Adjustment > 0)
                    {
                        crmTrace.AppendLine("COndition expression for ElectricalFee ");
                        condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { Electrical_TransactionCodes.OVERAGE_PAYMENT });
                        crmTrace.AppendLine("get transaction code for Electrical Fee ");
                        EntityCollection transactioncodeResponse = Fab4_FeeCalculationHelper.GetTransactionCodes(service, targetEntity, crmTrace, condition);

                        if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                        {

                            transHistoryGuids = (Fab4_FeeCalculationHelper.CreateTransactionHistory(crmTrace, service, targetEntity.Id, paymentHistoryId, transactioncodeResponse.Entities[0], new Money(feeObject.Adjustment)));

                        }
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }
                    #endregion
                }

                return feeObject;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - CreateElectricalTransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }
        public static void ElectricalFee(Fab4FeeCalculationobject feeObject, Entity targetEntity, IOrganizationService service, Entity preImage, StringBuilder crmTrace, ParameterCollection sharedVariables, IPluginExecutionContext context)
        {
            try
            {
                if (context.Stage == 20)
                {
                    string formulaeName = string.Empty;
                    EntityCollection retrieveFeeCollection = null;

                    if (context.MessageName.ToUpper() == PluginHelperStrings.CreateMessageName.ToUpper())
                    {
                        feeObject.existingamountpaid = 0;

                    }
                    else
                    {
                        if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                        {
                            feeObject.existingamountpaid = ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                            crmTrace.AppendLine("Exsisting amount paid" + feeObject.existingamountpaid);

                        }
                    }

                    if ((targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == true))
                    {
                        feeObject.ElectricalFee = 0;
                        feeObject.TotalFee = 0;
                    }
                    else
                    {

                        formulaeName = FeeTypeName.ElectricalFilingFee;
                        crmTrace.AppendLine("formulae Name" + formulaeName);
                        //Get fee calculation configuartion attributes 
                        crmTrace.AppendLine("get fee calculation configuration attributes");
                        retrieveFeeCollection = Fab4_FeeCalculationHelper.RetrieveFee(crmTrace, service, formulaeName);
                        crmTrace.AppendLine("formulae Name" + formulaeName);
                        crmTrace.AppendLine("Filing Fee" + retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee));
                        //Get variables from fee calculation configuration entity
                        crmTrace.AppendLine("Variable Assignments - Start");



                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                        {
                            int filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                            if (filingType != (int)FilingType.PAA)
                            {

                                if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                                {
                                    feeObject.ElectricalFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                                    feeObject.TotalFee = feeObject.ElectricalFee;
                                    crmTrace.AppendLine("FeeCalculationConfigurationAttributeNames.MinFilingFee :" + FeeCalculationConfigurationAttributeNames.MinFilingFee);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(feeObject.ElectricalFee));
                                }
                            }
                            else if (filingType == (int)FilingType.PAA)

                                if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                                {
                                    feeObject.PaaFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.PaaFee);
                                    feeObject.TotalFee = feeObject.PaaFee;
                                    crmTrace.AppendLine("FeeCalculationConfigurationAttributeNames.PaaFee :" + FeeCalculationConfigurationAttributeNames.PaaFee);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(feeObject.PaaFee));
                                }
                            crmTrace.AppendLine("filingType :" + filingType);

                        }
                        else
                        {
                            feeObject.ElectricalFee = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee);
                            feeObject.TotalFee = feeObject.ElectricalFee;
                            crmTrace.AppendLine("FeeCalculationConfigurationAttributeNames.MinFilingFee :" + FeeCalculationConfigurationAttributeNames.MinFilingFee);
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(feeObject.ElectricalFee));

                        }
                    }

                    crmTrace.AppendLine("if total filing fee is less that amount paid");
                    if (feeObject.TotalFee < feeObject.existingamountpaid)
                    {
                        feeObject.AmountDue = 0;
                        feeObject.Adjustment = (feeObject.existingamountpaid - feeObject.TotalFee);
                        crmTrace.AppendLine("Job filing Electrical Entity for Update - Populate Adjustment Amount");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(feeObject.AmountDue));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(feeObject.Adjustment));
                        // using the adjustment fromshared variables

                    }
                    else
                    {
                        feeObject.AmountDue = feeObject.TotalFee - feeObject.existingamountpaid;
                        crmTrace.AppendLine("Job filing Electrical Entity for Update - Populate Amount Due");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(feeObject.AmountDue));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(0));
                        context.SharedVariables.Add(JobFilingEntityAttributeName.Refund, feeObject.Adjustment);
                        feeObject.Adjustment = 0;
                    }

                    context.SharedVariables.Add(JobFilingEntityAttributeName.AmountDue, feeObject.AmountDue);
                    context.SharedVariables.Add(JobFilingEntityAttributeName.sharedRefund, feeObject.Adjustment);


                    // assign shared variables  to post operation from fee object
                    // To make use of all fee related variables in post operation

                }
                else if (context.Stage == 40)
                {
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true)
                    {
                        crmTrace.AppendLine("On File Electrical -Start");

                        if (feeObject.Adjustment != 0)
                        {
                            crmTrace.AppendLine("On File Electrical Fee SET Adjustment -Start");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(feeObject.Adjustment));
                            // used in post operation and creation of payment history
                            crmTrace.AppendLine("On File Electrical Fee SET Adjustment -END");
                        }

                    }

                    Guid paymentHistoryId = new Guid();
                    crmTrace.AppendLine("On File Electrical Fee -END");
                    crmTrace.AppendLine("Delete PHs-start");
                    Fab4FeeCalculationHandler.DeleteOldPaymentHistory(service, crmTrace, targetEntity);
                    crmTrace.AppendLine("Delete PHs-End");
                    paymentHistoryId = Fab4_FeeCalculationHelper.CreatePaymentHistory(service, targetEntity, crmTrace, context.SharedVariables);
                    #region ElectricalTransactionHistory
                    crmTrace.AppendLine("AmountDue : " + feeObject.AmountDue);
                    crmTrace.AppendLine("Adjustment :" + feeObject.Adjustment);

                    crmTrace.AppendLine("Create ElectricalTransactionHistory - plugin -Start");
                    Fab4FeeCalculationHandler.CreateElectricalTransactionHistoryRecords(feeObject, targetEntity, paymentHistoryId, service, crmTrace);
                    crmTrace.AppendLine("Create ElectricalTransactionHistory - plugin -End");
                    #endregion
                }

                //return feeObject;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "Fab4FeeCalculationHandler - ElectricalFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }


        }
    }
}
