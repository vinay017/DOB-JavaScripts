﻿namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class pluginHandlerBase
    {
    }
}