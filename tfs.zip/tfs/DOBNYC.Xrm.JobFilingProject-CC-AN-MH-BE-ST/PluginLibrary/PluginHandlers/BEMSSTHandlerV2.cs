﻿using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;
using System;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities
{
    public class BEMSSTHandlerV2 : PluginHandlerBase
    {
        public static Entity SetBPF_JobFiling(Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                //PW1 Standardization: Start
                crmTrace.AppendLine("PW1 Standardization - Start");
                FeeCalculationObject targetFCObject = new FeeCalculationObject();                
                FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(targetEntity, targetFCObject, crmTrace);
                crmTrace.AppendLine("PW1 Standardization - Worktype Set");
                //PW1 Standardization: End

                #region SetBPF_JobFiling
                crmTrace.AppendLine("Start SetBPF_JobFiling");
                if (targetFCObject.IsFN || targetFCObject.IsSH || targetFCObject.IsSF || targetFCObject.IsSG)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.FAB4_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.FAB4_StageIdV2));
                    return targetEntity;
                }

                if (targetFCObject.IsAN || targetFCObject.IsCC)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.ANCC_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.ANCC_StageIdV2));
                    return targetEntity;
                }
                if(targetFCObject.IsBE )
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.BE_ProcessV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.BE_StageIdV2));
                    return targetEntity;
                }

                if ( targetFCObject.IsMS || targetFCObject.IsST)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.BEMSST_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.BEMSST_StageIdV2));
                    return targetEntity;
                }

                if (targetFCObject.IsPA || targetFCObject.IsTPA)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.PAT_PA_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.PAT_PA_StageIdV2));
                    return targetEntity;
                }

                if (targetFCObject.IsPL || targetFCObject.IsSP || targetFCObject.IsSD)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.PLSPSD_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.PLSPSD_StageIdV2));
                }
                else 
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.PLSPSD_ProcessIdV2));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.PLSPSD_StageIdV2));
                }
                crmTrace.AppendLine("Start SetBPF_JobFiling V2");
                #endregion
                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - SetBPF_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        public static void CreateProgressInspectionCategoryRecordForPA_TPA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CreateProgressInspectionCategoryRecordFor PA/TPA method");


                string[] ColumnNames_CustomConfig = new string[] { CustomConfigurationEntityAttributeName.Key };
                ConditionExpression CustomConfigCondition_Name = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "TR1_PA" });
                EntityCollection CustomConfigResponse = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_Name }, LogicalOperator.And);
                string Key = CustomConfigResponse.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);


                // string inspectionComponentName = "Final";
                string ICId = string.Empty;
                string ICCode = string.Empty;

                string fetchXML = @"<?xml version='1.0'?>
                                      <fetch distinct='true' mapping='logical' output-format='xml-platform' version='1.0'>
                                       <entity name='dobnyc_specialinspectionscomponents'>
                                        <attribute name='dobnyc_specialinspectionscomponentsid' />
                                        <attribute name='dobnyc_code' />
                                        <attribute name='dobnyc_inspectioncomponentguid' />                                        
                                        <order attribute='dobnyc_code' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_code' operator='eq' value='" + Key + @"'/>                                          
                                        </filter>
                                      </entity>
                                    </fetch>";

                crmTrace.AppendLine("fetchXML: " + fetchXML);
                EntityCollection ICResponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
                if (ICResponse.Entities != null && ICResponse.Entities.Count > 0)
                {
                    foreach (Entity icresponse in ICResponse.Entities)
                    {
                        ICId = icresponse.Id.ToString();
                        ICCode = icresponse.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);
                    }

                    Entity ProgressInspectionCategory = new Entity();
                    ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                    service.Create(ProgressInspectionCategory);
                }

                crmTrace.AppendLine("End CreateProgressInspectionCategoryRecordFor PA/TPA method");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Inspection Components - Record Exists for Final: End ", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForPA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForPA/TPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateTR1SpecialInspectionFields(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Update TR1 Special Inspcetion Fields Started");
                //Gettting the Job Filling from the Target Entity
                var queryJobFilling = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='dobnyc_mh_mechanicalscopeofwork'>
                                        <attribute name='dobnyc_mh_mechanicalscopeofworkid' />
                                        <attribute name='dobnyc_mh_certificationforlisting' />
                                        <attribute name='dobnyc_mh_modelname' />
                                        <attribute name='dobnyc_mh_manufacturersname' />
                                        <attribute name='dobnyc_mh_gotojobfiling' />
                                        <order attribute='dobnyc_mh_certificationforlisting' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_mh_mechanicalscopeofworkid' operator='eq'  uitype='dobnyc_mh_mechanicalscopeofwork' value='" + targetEntity.Id + "' />" + @"
                                        </filter>
                                      </entity>
                                    </fetch>";
                EntityCollection ecqueryjobFilling = serviceConnector.RetrieveMultiple(new FetchExpression(queryJobFilling));
                if (ecqueryjobFilling.Entities.Count > 0)
                {
                    //If Target Entity Contains Jobfilling ,Get the special Inspection Category
                    Guid jobfillingId = ecqueryjobFilling.Entities[0].GetAttributeValue<EntityReference>("dobnyc_mh_gotojobfiling").Id;
                    var querySpecB = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_specialinspectioncategories'>
                                    <attribute name='dobnyc_specialinspectioncategoriesid' />
                                    <attribute name='dobnyc_completionstatementdate' />
                                    <attribute name='dobnyc_inspectionapplicantnamecompletionstatemen' />
                                    <attribute name='dobnyc_certificateofcompletionstatement' />
                                    <order attribute='dobnyc_completionstatementdate' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_jobfilingtospecialinspectionscaid' operator='eq'  uitype='dobnyc_jobfiling' value='" + jobfillingId + "' />" + @"
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";
                    EntityCollection ecspecB = serviceConnector.RetrieveMultiple(new FetchExpression(querySpecB));
                    if (ecspecB.Entities.Count > 0)
                    {  //Updating fields to null
                        foreach (Entity eSpecialB in ecspecB.Entities)
                        {
                            Entity eSpecB = new Entity("dobnyc_specialinspectioncategories");
                            eSpecB.Id = eSpecialB.Id;
                            eSpecB.Attributes["dobnyc_completionstatementdate"] = null;
                            eSpecB.Attributes["dobnyc_inspectionapplicantnamecompletionstatemen"] = null;
                            eSpecB.Attributes["dobnyc_certificateofcompletionstatement"] = false;
                            serviceConnector.Update(eSpecB);
                        }
                    }
                }
                crmTrace.AppendLine("Update TR1 Special Inspcetion Fields Completed");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "BEMSSTHandlerV2 - Update TR1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
