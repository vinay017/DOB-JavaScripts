﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    class JobFilingFeeCalc : PluginHandlerBase
    {
        public static void CalculateFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string messageName)
        {
            #region set fee parameters
            #region Variable Declarations
            crmTrace.AppendLine("Entered Calculate Fee");
            FeeCalculationObject fcObject = new FeeCalculationObject();
            FeeCalculationObject legalFeeObject = new FeeCalculationObject();
            EntityCollection getFeeParameterResponse = new EntityCollection();
            int jobType = 0;
            string formulaeName = string.Empty;
            EntityCollection transCodesResponse = new EntityCollection();
            List<string> transCodesList = null;
            decimal estJobCost = 0;
            decimal estJobCostLegal = 0;
            Entity jobFiling = new Entity();
            decimal filingType = 0;
            string thGuid = string.Empty;
            string phGuid = string.Empty;
            List<Guid> transHistoryGuids = new List<Guid>();
            Entity phResponse = new Entity();
            decimal amountDue = 0;
            decimal amountPaid = 0;
            decimal totalPayable = 0;
            decimal refund = 0;
            decimal totalFee = 0;
            decimal newWorkFilingFee = 0;
            decimal legalFilingFee = 0;
            decimal getRefund = 0;
            decimal recordManagementFee = 0;
            decimal noGoodCheckFee = 0;
            decimal existingAmountdue = 0;
            int noGoodCheckCount = 0;
            string noGoodCheckphGuid = string.Empty;
            decimal merchantAmount = 0;
            decimal existingNoGoodCheckFee = 0;
            decimal inConjunctionJobFee = 0;
            EntityCollection checkBounceParameter = new EntityCollection();
            EntityCollection checkBounceTransactionCode = new EntityCollection();

            #endregion

            try
            {
                crmTrace.AppendLine("Variable Declarations - Start");

                if (targetEntity.Contains(JobFilingEntityAttributeName.JobType))
                    jobType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.JobType]).Value;
                crmTrace.AppendLine("jobtype" + jobType);

                crmTrace.AppendLine("estJobCost" + targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost));
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                    estJobCost = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value;
                crmTrace.AppendLine("estJobCost" + estJobCost);

                //this block will be executed in LOC.
                crmTrace.AppendLine("estJobCost" + targetEntity.Contains(JobFilingEntityAttributeName.EstimatedCostFinal));
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedCostFinal) && targetEntity[JobFilingEntityAttributeName.EstimatedCostFinal] != null &&
               targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedCostFinal).Value > 0)
                    estJobCost = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedCostFinal]).Value;
                crmTrace.AppendLine("estJobCost" + estJobCost);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                    estJobCostLegal = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]).Value;
                crmTrace.AppendLine("estJobCostLegal" + estJobCostLegal);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingType))
                    filingType = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                crmTrace.AppendLine("filingType" + filingType);
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountDue))
                // amountDue = decimal.Parse(targetEntity.Attributes[JobFilingEntityAttributeName.AmountDue].ToString());

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                    amountPaid = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value;
                crmTrace.AppendLine("amountPaid" + amountPaid);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RecordManagementFee))
                    recordManagementFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.RecordManagementFee]).Value;
                crmTrace.AppendLine("recordManagementFee" + recordManagementFee);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountDue))
                    existingAmountdue = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountDue]).Value;
                crmTrace.AppendLine("existingAmountdue" + existingAmountdue);
                crmTrace.AppendLine("Variable declarations (After AmountPaid)");

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingFees))
                    totalFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.FilingFees])).Value;
                crmTrace.AppendLine("totalFee" + totalFee);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NewWorkFilingFee))
                    newWorkFilingFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.NewWorkFilingFee]).Value;
                crmTrace.AppendLine("newWorkFilingFee" + newWorkFilingFee);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LegalizationFilingFee))
                    legalFilingFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.LegalizationFilingFee]).Value;
                crmTrace.AppendLine("legalFilingFee" + legalFilingFee);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Refund))
                    getRefund = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.Refund]).Value;
                crmTrace.AppendLine("getRefund" + getRefund);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckCount))
                    noGoodCheckCount = (int)(targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckCount]);
                crmTrace.AppendLine("noGoodCheckCount" + noGoodCheckCount);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                    existingNoGoodCheckFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFee])).Value;
                crmTrace.AppendLine("existingNoGoodCheckFee" + existingNoGoodCheckFee);
                crmTrace.AppendLine("Variable declarations - End");
                
                #endregion

                #region No good Check Fee

                // check if no good check flag is true
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFlag] != null)
                {
                    crmTrace.AppendLine("No Good Check fee -start");
                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                    {
                        crmTrace.AppendLine("JobFilingEntityAttributeName.NoGoodCheckFlag");
                        // get no good check fee from fee calculation configuration attributes
                        getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.NoGoodCheckFee, service, crmTrace);
                        noGoodCheckFee = noGoodCheckCount * decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce].ToString());
                        crmTrace.AppendLine("No Good Check Fee: " + noGoodCheckFee);
                        // get the no good check phGuid from target entity
                        if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckphGUID))
                        {
                            noGoodCheckphGuid = targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckphGUID].ToString();
                        }
                        // retrieve merchant amount, no good check PHGUID, entity logical name from payment history.
                        Entity paymentHistory = Retrieve(service, new string[] { PaymentHistoryAttributeNames.MerchantAmount }, new Guid(noGoodCheckphGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                        if (paymentHistory.Contains(PaymentHistoryAttributeNames.MerchantAmount))
                            merchantAmount = ((Money)paymentHistory.Attributes[PaymentHistoryAttributeNames.MerchantAmount]).Value;
                      
                    }
                }

                #endregion

                #region Is Fee Exempt
                if (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename)==true)
                {
                    crmTrace.AppendLine("Is Fee Exempt -start");
                   // if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true))
                    //{
                        // if the target entity/ preimage contains PHGUID or if it is create message
                        crmTrace.AppendLine(" Check paymeny history guid");
                        if (targetEntity.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) || preImage.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) || messageName == PluginHelperStrings.CreateMessageName.ToUpper())
                        {
                            if (messageName.ToUpper() == PluginHelperStrings.UpdateMessageName.ToUpper())
                            {
                                #region Delete Payment History record
                                try
                                {
                                    // If IsPosted flag is false  means payment is not done and we delete payment history record.
                                    phGuid = targetEntity.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                                    phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                                    if (phResponse.Contains(PaymentHistoryAttributeNames.IsPosted))
                                    {
                                        crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                                        if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                        {
                                            //ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                                            //{

                                            //    Settings = new ExecuteMultipleSettings()
                                            //    {
                                            //        ContinueOnError = true,
                                            //        ReturnResponses = true
                                            //    },

                                            //    Requests = new OrganizationRequestCollection()
                                            //};
                                            //DeleteRequest delRequest = new DeleteRequest { Target = new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(targetEntity.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString())) };
                                            //requestWithResults.Requests.Add(delRequest);
                                            //ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);
                                            if (filingType != 2)
                                            {
                                                service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                            }
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee - Is Fee exempt - PaymentHistory already deleted ", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                                }
                                crmTrace.AppendLine("Payment History - Deleted");
                                #endregion
                            }
                        }
                        #region Set values and update jobfiling record
                        if (amountPaid != 0)
                        {
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(amountPaid));
                        }
                        crmTrace.AppendLine("Update Filing with 0 as Fee exempt");
                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Id = targetEntity.Id;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse("0")));
                        
                        //Commented out as it is over righting the final estinated job cost.
                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCost, new Money(estJobCost));
                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, new Money(estJobCostLegal));

                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));
                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                        service.Update(jobFiling);
                        #endregion

                        #region PAA
                        if (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == true) && filingType == 2)
                        {
                            crmTrace.AppendLine("PAA in case of Inconjunction job - Start");
                        JobFilingPAAHandler.CalculatePAA(service, targetEntity, crmTrace, preImage, messageName);
                        crmTrace.AppendLine("PAA in case of Inconjunction job - End");
                        }
                        crmTrace.AppendLine(" Is Fee exempt - End");
                        #endregion
                   // }
                }
                #endregion
                
                #region Is Conjunction Job
                if (targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null)
                {

                    #region PAA
                    // if the job is paa and inconjunction
                    crmTrace.AppendLine(" Is Conjunction Job- start");
                    if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == false) && filingType == 2)
                    {
                        crmTrace.AppendLine("PAA in case of Inconjunction job - Start");
                        JobFilingPAAHandler.CalculatePAA(service, targetEntity, crmTrace, preImage, messageName);
                        crmTrace.AppendLine("PAA in case of Inconjunction job - End");
                    }
                    #endregion
                    if (((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsConjunctionJob] == true) && ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.IsFeeExemptAttributename] == false) && filingType != 2)
                    {
                        #region Delete Payment History
                        crmTrace.AppendLine("Start Inconjunction Job");
                        if (targetEntity.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) || preImage.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID))
                        {
                            phGuid = targetEntity.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                            crmTrace.AppendLine("Payment Hisotry Guid: " + targetEntity.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID]);
                            phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                            crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                            if (phResponse.Contains(PaymentHistoryAttributeNames.IsPosted))
                            {
                                crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                                if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                {
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                }
                            }

                        }
                        #endregion

                        #region Inconjunction Fee Calculation
                        formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);   //Build FormulaeName
                        getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);// get fee calculation parameters
                        crmTrace.AppendLine("In Conjunction job fee " + getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee]);

                        transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                        if (getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
                        {
                            crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
                            getFeeParameterResponse.Entities[0].Attributes.Remove(FeeTypeName.FilingFeeSchemaName);
                            getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                            crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
                        }

                        else if (!getFeeParameterResponse.Entities[0].Attributes.Contains(FeeTypeName.FilingFeeSchemaName))
                        {
                            crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - Start");
                            getFeeParameterResponse.Entities[0].Attributes.Add(FeeTypeName.FilingFeeSchemaName, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());
                            crmTrace.AppendLine("Add Inconjunction Fee value to filing schema name as Filing Balance bucket is being used for Inconjunction Job - End");
                        }
                        //retreive Inconjunction Job fee from fee calculation configuration.
                        inConjunctionJobFee = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.InConjunctionJobFee].ToString());

                       

                        if (amountPaid == 0) //build transaction codes list
                        {
                            transCodesList = new List<string>();
                            // for inconjunction filing balance transaction code 
                            transCodesList.Add(TransactionCodes.FilingBalance);
                            #region create Transaction history and payment history 
                            crmTrace.AppendLine("Create Transaction History Records - Start");
                            transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage); //create transaction hisroty record
                            crmTrace.AppendLine("Create Transaction History Records - Start");

                            FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue); //Create Payment history
                            crmTrace.AppendLine("Payment History Create and Job filing Update with payment history guid done.");

                            #endregion
                            amountDue = inConjunctionJobFee;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.TotalJobCost, new Money(amountDue));
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));
                        }
                        else if (amountPaid != 0)
                        {
                            totalPayable = inConjunctionJobFee;
                            if (totalPayable == amountPaid)
                            {
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(0));
                            }

                            if (totalPayable < amountPaid)
                            {
                                refund = amountPaid - totalPayable;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(inConjunctionJobFee));
                            }
                        }
                        #region Set Attribute Values and update job filing
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Id = targetEntity.Id;
                      
                         jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(inConjunctionJobFee));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse("0")));

                        //Commented out as it is over righting the final estinated job cost.
                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCost, new Money(estJobCost));
                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, new Money(estJobCostLegal));

                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus); //Remove Filing Status from 
                        service.Update(jobFiling);
                        crmTrace.AppendLine("End In Conjunction Job");
                        #endregion
                        #endregion
                    }
                }
                #endregion

                #region Fee Calculation
                // if its antenna its default job type new job.
                if (jobType == 0 && (targetEntity.Contains(JobFilingEntityAttributeName.ANCheckBox) && targetEntity[JobFilingEntityAttributeName.ANCheckBox] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox) == true))
                {
                    jobType = 1;

                }
                crmTrace.AppendLine("Check if is conjunction job and fee exempt is false");
                if ((targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) == false) &&
                    (targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity[JobFilingEntityAttributeName.IsFeeExemptAttributename] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == false))
                {
                    transCodesList = new List<string>();
                    switch (jobType)
                    {
                        #region Newjob
                        case 1:
                            if (estJobCost != 0)
                            {
                                
                                crmTrace.AppendLine("filing type" + filingType.ToString());
                                if (filingType == 1 || filingType == 3)
                                {
                                    #region Delete if payment is not Posted
                                    if (messageName == "UPDATE")
                                    {
                                        if ((preImage.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) && (preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID] != null)))
                                        {
                                            phGuid = preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                                            crmTrace.AppendLine("payment history for new job " + " " + phGuid);
                                            try
                                            {
                                                phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, Guid.Parse(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                                                if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                                                {
                                                    crmTrace.AppendLine("check is posted" + phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                                                    if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                                    {
                                                        service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                                        DOBLogger.WriteTraceLog("payment history", "CRM", "Execute", phResponse.ToString() + "\n" + " Execute trace log", "User ID", "dele");
                                                        crmTrace.AppendLine("delete payment history");
                                                    }
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee -Fee calculation - PaymentHistory already deleted ", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                                            }
                                        }
                                    }

                                    #endregion
                                    crmTrace.AppendLine("Start Fee Calculation for New Job ");
                                    //get formulae name so that the fee calculation record can be retrieved which has all the parameters and
                                    //multipliers needed for calculating Fees
                                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);
                                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                                    fcObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estJobCost);
                                    crmTrace.AppendLine("NewWorkFIling Fee" + fcObject.NewWorkFilingFee.ToString());
                                    crmTrace.AppendLine("total fee" + fcObject.TotalFee);
                                    transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);

                                    crmTrace.AppendLine(transCodesResponse.Entities.Count.ToString());
                                    //Build Transaction codes
                                    foreach (var transCodes in transCodesResponse.Entities)
                                    {
                                        if ((bool)transCodes.Attributes[TransactionCodeAttributeNames.IsLegalizationFee] == false)
                                        {
                                            transCodesList.Add(transCodes.Attributes[TransactionCodeAttributeNames.TransCode].ToString());
                                        }
                                    }

                                    transCodesList.Remove(TransactionCodes.CheckBounceFee);
                                  
                                    if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                    {
                                        crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal - new job");
                                        if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                        {
                                            crmTrace.AppendLine("No good check - Add Transaction Code for No Good Check Bucket - Start");
                                            //checkBounceParameter = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.NoGoodCheckFee, service, crmTrace);
                                            //checkBounceTransactionCode = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, checkBounceParameter, targetEntity);
                                            transCodesList.Add(TransactionCodes.CheckBounceFee);
                                            crmTrace.AppendLine("No good check - Add     Transaction Code for No Good Check Bucket - End");
                                        }

                                    }
                                    
                                    crmTrace.AppendLine("No. of Transaction codes " + transCodesList.Count.ToString());
                                    #region amountdue and refund
                                    if (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost))
                                    {
                                        
                                        if (amountPaid != 0)
                                        {
                                            if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RecordManagementFee))
                                                recordManagementFee = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.RecordManagementFee]).Value;
                                            crmTrace.AppendLine(fcObject.TotalFee);
                                            totalPayable = decimal.Parse(fcObject.TotalFee);
                                            crmTrace.AppendLine("total Payable " + totalPayable);
                                           
                                            #region ALT BIS Condition 
                                            //Total Fee will be Toatl Fee - Record Management Fee
                                            //      if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                            //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                            //      {
                                            //          recordManagementFee = decimal.Parse(fcObject.RecordManagementFee);
                                            //          crmTrace.AppendLine("Record Management Fee");
                                            //          totalPayable = decimal.Parse(fcObject.TotalFee);
                                            //          totalPayable = totalPayable - recordManagementFee;
                                            //          crmTrace.AppendLine("Total Amount" + totalPayable);
                                            //          fcObject.RecordManagementFee = "0";
                                            //          crmTrace.AppendLine("record management fee " + fcObject.RecordManagementFee);
                                            //          fcObject.TotalFee = "" + totalPayable;
                                            //          crmTrace.AppendLine("totalPayable ");

                                            //      }
                                            #endregion
                                            if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFlag]!=null&&targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag)==true)
                                            {
                                                crmTrace.AppendLine("In case of more than 1 no good check fee, total payable changes to total fee + already paid no good check fee amount");
                                                    totalPayable = totalPayable + existingNoGoodCheckFee;//adding old no good check fees but not added this time no good check fee
                                                    crmTrace.AppendLine("total Payable " + totalPayable);
                                              
                                            }
                                            
                                            //check if the new filing fees and exisitng filing fees are the same and proceed further only if they aren't
                                            if (totalPayable == amountPaid)
                                            {
                                               
                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                }

                                                if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = decimal.Parse(fcObject.TotalFee) + noGoodCheckFee;
                                                            decimal fee_totalfee = decimal.Parse(fcObject.TotalFee) + noGoodCheckFee;
                                                            fcObject.TotalFee = fee_totalfee.ToString();
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            crmTrace.AppendLine("No good check - Amount Due: " + fcObject.TotalFee);
                                                            // throw new Exception("test" + fcObject.TotalFee);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            //getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }
                                                       
                                                        if (merchantAmount < amountPaid)
                                                        {
                                                            amountDue = (amountPaid - merchantAmount) + noGoodCheckFee - existingNoGoodCheckFee;
                                                        }
                                                        crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                        
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        
                                                    }
                                                    else
                                                    {
                                                        crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                    }
                                                }
                                            }
                                          
                                            if (totalPayable > amountPaid)
                                            {
                                                crmTrace.AppendLine("If totalpayable is greater than amount paid");
                                                crmTrace.AppendLine("Amount Paid: " + amountPaid.ToString());

                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    amountDue = totalPayable - amountPaid;
                                                }

                                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                           // jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }

                                                        if (merchantAmount < amountPaid)
                                                        {
                                                            amountDue = (amountPaid - merchantAmount) + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        amountDue = totalPayable - amountPaid;
                                                    }
                                                }

                                                switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                {
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                        crmTrace.AppendLine("Remove record Management Fee if exists already");
                                                        transCodesList.Remove(TransactionCodes.RecordManagement123);
                                                        break;

                                                    case 4:
                                                        crmTrace.AppendLine("Remove record Management Fee if exists already");
                                                        transCodesList.Remove(TransactionCodes.RecordManagementOther);
                                                        break;
                                                }
                                                if (amountDue > getRefund)
                                                {
                                                    crmTrace.AppendLine("If amount due is greater than refund");
                                                    amountDue = amountDue - getRefund;
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                    getFeeParameterResponse.Entities[0].Attributes["dobnyc_filingfees"] = amountDue;

                                                    #region out of scope
                                                    //    switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                    //    {
                                                    //        case 4:
                                                    //            if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                    //            {
                                                    //                jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money((decimal.Parse(fcObject.RecordManagementFee) - recormManagementFee)));
                                                    //                getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee] = decimal.Parse(fcObject.RecordManagementFee) - recormManagementFee;
                                                    //            }
                                                    //            break;

                                                    //        case 1:
                                                    //        case 2:
                                                    //        case 3:
                                                    //            if (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value == 4)
                                                    //            {
                                                    //                jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money((recormManagementFee - decimal.Parse(fcObject.RecordManagementFee))));
                                                    //                getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee] = recormManagementFee - decimal.Parse(fcObject.RecordManagementFee);
                                                    //            }
                                                    //            break;
                                                    //    }
                                                    #endregion
                                                }

                                                else if (amountDue < getRefund)
                                                {
                                                    crmTrace.AppendLine("if amountdue is less than refund");
                                                    refund = getRefund - amountDue;
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                }

                                            }
                                           
                                            else if (totalPayable < amountPaid)
                                            {
                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                    refund = amountPaid - totalPayable;
                                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) - getRefund;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }

                                                        if (merchantAmount < amountPaid)
                                                        {
                                                            merchantAmount = merchantAmount + noGoodCheckFee - existingNoGoodCheckFee;
                                                            if (merchantAmount == getRefund)
                                                            {
                                                                amountDue = amountPaid - merchantAmount;
                                                                refund = merchantAmount - getRefund;
                                                            }

                                                            if (merchantAmount < getRefund)
                                                            {
                                                                refund = getRefund - merchantAmount;
                                                                amountDue = (decimal)0;
                                                            }

                                                            if (merchantAmount > getRefund)
                                                            {
                                                                refund = (decimal)0;
                                                                amountDue = merchantAmount - getRefund;
                                                            }
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                           // jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }
                                                    }

                                                    else
                                                    {
                                                        refund = amountPaid - totalPayable;
                                                    }
                                                }
                                                crmTrace.AppendLine("If amount paid is leass than totalpayable");

                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);

                                                #region out of scope
                                                //if (decimal.Parse(fcObject.NewWorkFilingFee) != newWorkFilingFee)
                                                //{
                                                //    if (((Money)preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value == ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value)
                                                //    {
                                                //        switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                //        {
                                                //            case 1:
                                                //            case 2:
                                                //            case 3:
                                                //                if (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value == 4)
                                                //                {
                                                //                    refund = getRefund - amountDue;
                                                //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                                                //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                                //                }
                                                //                break;

                                                //            case 4:
                                                //                switch (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                //                {
                                                //                    case 1:
                                                //                    case 2:
                                                //                    case 3:
                                                //                        refund = getRefund - amountDue;
                                                //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                                                //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                                //                        break;
                                                //                }
                                                //                break;

                                                //        }
                                                //    }
                                                //    else if (((Money)preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value)
                                                //    {
                                                //        refund = amountPaid - totalPayable;
                                                //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                                                //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                                //    }
                                                //}

                                                #endregion
                                            }
                                            //throw new Exception("test" + amountDue + "t"+ targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckphGUID) +"v"+ targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.NoGoodCheckphGUID));
                                            //if((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false ||
                                            //    targetEntity.Contains(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.SignedOff)
                                            //    && amountDue>0)
                                            if ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == false ||
                                               (targetEntity.Contains(JobFilingEntityAttributeName.IsEstimatedCostsameasFinalCost) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsEstimatedCostsameasFinalCost) == false)
                                               || targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckphGUID)&& targetEntity[JobFilingEntityAttributeName.NoGoodCheckphGUID]!=null && targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.NoGoodCheckphGUID)!=string.Empty )
                                               && amountDue > 0)
                                            {
                   
                                                transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                                                //Create Payment history
                                                FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                                                crmTrace.AppendLine("Payment History Create and Job filing Update with payment history guid done.");
                                                crmTrace.AppendLine("End Fee Calculation for New Job ");
                                            }
                                        }

                                        #endregion

                                        if (refund == 0)
                                        {
                                            crmTrace.AppendLine(transHistoryGuids.Count.ToString());
                                            if (amountPaid == 0)
                                            {
                                                #region ALT BIS Job
                                                //      if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                                //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                                //      {

                                                //          recordManagementFee = decimal.Parse(fcObject.RecordManagementFee);
                                                //          totalPayable = decimal.Parse(fcObject.TotalFee);
                                                //          totalPayable = totalPayable - recordManagementFee;
                                                //          crmTrace.AppendLine("Total Amount" + totalPayable);
                                                //          //jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(0));
                                                //          fcObject.RecordManagementFee = "0";
                                                //          crmTrace.AppendLine("record management fee " + fcObject.RecordManagementFee);
                                                //          fcObject.TotalFee = "" + totalPayable;
                                                //          crmTrace.AppendLine("totalPayable ");
                                                // remove record management transaction codes

                                                //switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                //{
                                                //    case 1:
                                                //    case 2:
                                                //    case 3:
                                                //        crmTrace.AppendLine("Remove record Management Fee if exists already");
                                                //        transCodesList.Remove(TransactionCodes.RecordManagement123);
                                                //        break;

                                                //    case 4:
                                                //        crmTrace.AppendLine("Remove record Management Fee if exists already");
                                                //        transCodesList.Remove(TransactionCodes.RecordManagementOther);
                                                //        break;
                                                //}
                                                //  }
                                                #endregion
                                                amountDue = decimal.Parse(fcObject.TotalFee);
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                                                //Create Payment history
                                                FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                                                crmTrace.AppendLine("Payment History Create and Job filing Update with payment history guid done.");
                                                crmTrace.AppendLine("End Fee Calculation for New Job ");
                                            }
                                            crmTrace.AppendLine("Job filing update with transaction history guid Done");
                                        }
                                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse("0")));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                        crmTrace.AppendLine("record management fee- update" + (fcObject.RecordManagementFee));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                                        // add no good check fee to total fee and if the no good check flag is not true 
                                     
                                        if (targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFee] != null && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value > 0 &&
                                            targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFlag] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag) != true)
                                        {

                                            crmTrace.AppendLine("No good check fee- update" + targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) + "value" + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value + "no good check flag" +
                                        targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag) + "flag value" + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoGoodCheckFlag)
                                        + "total fee" + fcObject.TotalFee);

                                            // decimal nogoodcheckfilingfee = decimal.Parse(fcObject.TotalFee) + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value;
                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(decimal.Parse(fcObject.TotalFee) + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value));
                                            amountDue = ((decimal.Parse(fcObject.TotalFee) + targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value)) - amountPaid;
                                            if(amountDue>0)
                                            CommonPluginLibrary.SetAttributeValue(jobFiling, JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                        }
                                        else
                                        {
                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(decimal.Parse(fcObject.TotalFee)));
                                        }
                                        
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                        jobFiling.Id = targetEntity.Id;
                                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                      //  throw new Exception("total fee" + fcObject.TotalFee);
                                        service.Update(jobFiling);
                                      
                                        crmTrace.AppendLine("Update jobfiling application");
                                       
                                    }
                                }
                                if (filingType == 2)
                                {
                                    JobFilingPAAHandler.CalculatePAA(service, targetEntity, crmTrace, preImage, messageName);
                                }
                            }
                            break;
                        #endregion

                        case 2:
                            #region Legalization
                            if (estJobCostLegal != 0)
                            {

                                #region Delete if payment is not Posted
                                if (messageName == "UPDATE")
                                {
                                    if ((preImage.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) && (preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID] != null)))
                                    {
                                        phGuid = preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                                        crmTrace.AppendLine("payment history for legalization " + " " + phGuid);
                                        try
                                        {
                                            phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);

                                            if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                                            {
                                                crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                                                if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                                {
                                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                                    //Entity jobFilingUpdate = new Entity();
                                                    //jobFilingUpdate.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                                                    //jobFilingUpdate.Id = targetEntity.Id;
                                                    //service.Update(jobFilingUpdate);
                                                    crmTrace.AppendLine("delete payment history - legalization");
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee - legalization - PaymentHistory already deleted ", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                                        }

                                    }
                                }
                                #endregion
                                crmTrace.AppendLine("Start Fee Calculation for Legalization Job ");
                                formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);
                                getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                                fcObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estJobCostLegal);
                                crmTrace.AppendLine("Legalization Fee: " + fcObject.LegalizationFilingFee);
                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                                {
                                    if (amountPaid != 0)
                                    {
                                        totalPayable = (decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee));
                                        crmTrace.AppendLine("total Payable " + totalPayable);
                                        #region ALT BIS Job
                                        //      if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                        //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                        //      {

                                        //          recordManagementFee = decimal.Parse(fcObject.RecordManagementFee);
                                        //          crmTrace.AppendLine("Record Management Fee");
                                        //          totalPayable = (decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee));
                                        //          totalPayable = totalPayable - recordManagementFee;
                                        //          crmTrace.AppendLine("Total Amount" + totalPayable);
                                        //          fcObject.RecordManagementFee = "0";
                                        //          crmTrace.AppendLine("record management fee " + fcObject.RecordManagementFee);
                                        //          fcObject.TotalFee = "" + totalPayable;
                                        //          crmTrace.AppendLine("totalPayable ");

                                        //      }
                                        #endregion

                                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                        {
                                            crmTrace.AppendLine("In case of more than 1 no good check fee, total payable changes to total fee + already paid no good check fee amount");
                                            if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                            {
                                                totalPayable = totalPayable + existingNoGoodCheckFee;
                                                crmTrace.AppendLine("total Payable " + totalPayable);
                                            }
                                        }

                                        if (totalPayable == amountPaid)
                                        {
                                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                            }
                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                {
                                                    if (merchantAmount == amountPaid)
                                                    {
                                                        amountDue = (decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee)) + noGoodCheckFee;
                                                    }

                                                    if (merchantAmount < amountPaid)
                                                    {
                                                        amountDue = (amountPaid - merchantAmount) + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                    }

                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                    getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;

                                                    switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                    {
                                                        case 1:
                                                        case 2:
                                                        case 3:
                                                            transCodesList.Add(TransactionCodes.RecordManagement123);
                                                            break;
                                                        case 4:
                                                            transCodesList.Add(TransactionCodes.RecordManagementOther);
                                                            break;

                                                    }
                                                }
                                                else
                                                {
                                                    crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                }
                                            }
                                        }

                                        if (totalPayable > amountPaid)
                                        {
                                            crmTrace.AppendLine("If totalpayable is greater than amount paid");

                                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                amountDue = totalPayable - amountPaid;
                                            }

                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                {
                                                    if (merchantAmount == amountPaid)
                                                    {
                                                        amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                        crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                    }

                                                    if (merchantAmount < amountPaid)
                                                    {
                                                        amountDue = (amountPaid - merchantAmount) + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                        crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                    }
                                                }
                                                else
                                                {
                                                    amountDue = totalPayable - amountPaid;
                                                }
                                            }

                                            if (amountDue > getRefund)
                                            {

                                                crmTrace.AppendLine("If amount due is greater than refund");
                                                amountDue = amountDue - getRefund;
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));

                                                getFeeParameterResponse.Entities[0].Attributes["dobnyc_legalizationfilingfees"] = amountDue;

                                                #region outofscope
                                                //switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                //{
                                                //    case 4:
                                                //        if (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value != ((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                //        {
                                                //            jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money((decimal.Parse(fcObject.RecordManagementFee) - recormManagementFee)));
                                                //            getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee] = decimal.Parse(fcObject.RecordManagementFee) - recormManagementFee;
                                                //        }
                                                //        break;

                                                //    case 1:
                                                //    case 2:
                                                //    case 3:
                                                //        if (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value == 4)
                                                //        {
                                                //            jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money((recormManagementFee - decimal.Parse(fcObject.RecordManagementFee))));
                                                //            getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee] = recormManagementFee - decimal.Parse(fcObject.RecordManagementFee);
                                                //        }
                                                //        break;
                                                //}
                                                #endregion

                                            }
                                            else if (amountDue < getRefund)
                                            {

                                                refund = getRefund - amountDue;
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                            }

                                        }
                                        else if (totalPayable < amountPaid)
                                        {
                                            crmTrace.AppendLine("If amount paid is less than totalpayable");
                                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                refund = amountPaid - totalPayable;
                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                {
                                                    if (merchantAmount == amountPaid)
                                                    {
                                                        amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) - getRefund;
                                                        crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                    }

                                                    if (merchantAmount < amountPaid)
                                                    {
                                                        merchantAmount = merchantAmount + noGoodCheckFee - existingNoGoodCheckFee;
                                                        if (merchantAmount == getRefund)
                                                        {
                                                            amountDue = amountPaid - merchantAmount;
                                                            refund = merchantAmount - getRefund;
                                                        }

                                                        if (merchantAmount < getRefund)
                                                        {
                                                            refund = getRefund - merchantAmount;
                                                            amountDue = (decimal)0;
                                                        }

                                                        if (merchantAmount > getRefund)
                                                        {
                                                            refund = (decimal)0;
                                                            amountDue = merchantAmount - getRefund;
                                                        }
                                                        crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                    }
                                                }

                                                else
                                                {
                                                    refund = amountPaid - totalPayable;
                                                }
                                            }

                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                                            #region out of scope
                                            //if (decimal.Parse(fcObject.LegalizationFilingFee) != legalFilingFee)
                                            //{
                                            //    if (((Money)preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value == ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value)
                                            //    {
                                            //        switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                            //        {
                                            //            case 1:
                                            //            case 2:
                                            //            case 3:
                                            //                if (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value == 4)
                                            //                {
                                            //                    refund = getRefund - amountDue;
                                            //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                            //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse(fcObject.LegalizationFilingFee)));
                                            //                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                            //                }
                                            //                break;

                                            //            case 4:
                                            //                switch (((OptionSetValue)preImage.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                            //                {
                                            //                    case 1:
                                            //                    case 2:
                                            //                    case 3:
                                            //                        refund = getRefund - amountDue;
                                            //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                            //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse(fcObject.LegalizationFilingFee)));
                                            //                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                            //                        break;
                                            //                }
                                            //                break;

                                            //        }
                                            //    }
                                            //    else if (((Money)preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value != ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value)
                                            //    {
                                            //        refund = amountPaid - totalPayable;
                                            //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                            //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse(fcObject.LegalizationFilingFee)));
                                            //        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                            //    }
                                            //}
                                            #endregion
                                        }
                                    }

                                    if (refund == 0)
                                    {

                                        transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);
                                        crmTrace.AppendLine("transacodes Response " + transCodesResponse.Entities.Count.ToString());


                                        //Build Transaction codes
                                        foreach (var transCodes in transCodesResponse.Entities)
                                        {
                                            if ((bool)transCodes.Attributes[TransactionCodeAttributeNames.IsLegalizationFee] == true)
                                            {
                                                transCodesList.Add(transCodes.Attributes[TransactionCodeAttributeNames.TransCode].ToString());
                                            }
                                        }

                                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                        {
                                            crmTrace.AppendLine("No good check ");
                                            if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                            {
                                                crmTrace.AppendLine("No good check - Add Transaction Code for No Good Check Bucket - Start");
                                                transCodesList.Add(TransactionCodes.CheckBounceFee);
                                                crmTrace.AppendLine("No good check - Add     Transaction Code for No Good Check Bucket - End");
                                            }
                                        }

                                        if (amountPaid == 0)
                                        {
                                            switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                            {
                                                case 1:
                                                case 2:
                                                case 3:
                                                    transCodesList.Add(TransactionCodes.RecordManagement123);
                                                    break;
                                                case 4:
                                                    transCodesList.Add(TransactionCodes.RecordManagementOther);
                                                    break;

                                            }
                                        }

                                        crmTrace.AppendLine("No. of Transaction codes " + transCodesList.Count.ToString());

                                        //Create Transaction history records based on the transaction codes and the calulated filingfees and record management fees
                                        transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                                        crmTrace.AppendLine(transHistoryGuids.Count.ToString());

                                        crmTrace.AppendLine("Job filing update with transaction history guid Done");
                                        if (amountPaid == 0)
                                        {
                                            #region ALT BIS Job
                                            //         if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                            //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                            //         {

                                            //             recordManagementFee = decimal.Parse(fcObject.RecordManagementFee);
                                            //             crmTrace.AppendLine("Record Management Fee");
                                            //             totalPayable = (decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee));
                                            //             totalPayable = totalPayable - recordManagementFee;
                                            //             crmTrace.AppendLine("Total Amount" + totalPayable);
                                            //             fcObject.RecordManagementFee = "0";
                                            //             crmTrace.AppendLine("record management fee " + fcObject.RecordManagementFee);
                                            //             fcObject.TotalFee = "" + totalPayable;
                                            //             crmTrace.AppendLine("totalPayable ");

                                            //         }
                                            #endregion
                                            crmTrace.AppendLine("If amount paid is 0 ");
                                            amountDue = decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee);

                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                        }
                                        //Create Payment history
                                        FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                                        crmTrace.AppendLine("Payment History Create and Job filing Update with payment history guid done.");
                                        crmTrace.AppendLine("End Fee Calculation for Legalization Job Job ");
                                    }
                                    jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse("0")));
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse(fcObject.LegalizationFilingFee)));
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(fcObject.RecordManagementFee)));
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money(decimal.Parse(fcObject.LegalizationFilingFee) + decimal.Parse(fcObject.RecordManagementFee)));
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                                    jobFiling.Id = targetEntity.Id;
                                    jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                    service.Update(jobFiling);
                                }
                            }
                            break;

                        #endregion

                        case 3:
                            #region New Job + Legalization

                            if (estJobCost != 0 && estJobCostLegal != 0)
                            {

                                if (filingType == 1 || filingType == 3)
                                {
                                    #region Delete if payment is not Posted
                                    if (messageName == "UPDATE")
                                    {
                                        if ((preImage.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) && (preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID] != null)))
                                        {
                                            phGuid = preImage.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();
                                            crmTrace.AppendLine("payment history  for new job + legalization" + " " + phGuid);
                                            try
                                            {
                                                phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);
                                                if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                                                {
                                                    crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());
                                                    if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                                    {
                                                        service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                                        crmTrace.AppendLine("delete payment history- new job + legalization");
                                                        //Entity jobFilingUpdate = new Entity();
                                                        //jobFilingUpdate.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                                                        //jobFilingUpdate.Id = targetEntity.Id;
                                                        //service.Update(jobFilingUpdate);

                                                    }
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee - PaymentHistory already deleted ", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                                            }
                                        }
                                    }

                                    #endregion
                                    crmTrace.AppendLine("Start Fee Calculation for New Job + Legalization ");
                                    formulaeName = FeeCalculationHelper.BuildCalcName(targetEntity, crmTrace);
                                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(formulaeName, service, crmTrace);
                                    fcObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estJobCost);
                                    crmTrace.AppendLine(fcObject.NewWorkFilingFee + " " + fcObject.LegalizationFilingFee);
                                    legalFeeObject = FeeCalculationHelper.CalculateFilingFees(service, targetEntity, crmTrace, getFeeParameterResponse, estJobCostLegal);
                                    crmTrace.AppendLine(legalFeeObject.NewWorkFilingFee + " " + legalFeeObject.LegalizationFilingFee);
                                    transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);

                                    //Build Transaction codes
                                    foreach (var transCodes in transCodesResponse.Entities)
                                    {
                                        transCodesList.Add(transCodes.Attributes[TransactionCodeAttributeNames.TransCode].ToString());
                                    }
                                    transCodesList.Remove(TransactionCodes.CheckBounceFee);

                                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                    {
                                        crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                        if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                        {
                                            crmTrace.AppendLine("No good check - Add Transaction Code for No Good Check Bucket - Start");
                                            //checkBounceParameter = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.NoGoodCheckFee, service, crmTrace);
                                            //checkBounceTransactionCode = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, checkBounceParameter, targetEntity);
                                            transCodesList.Add(TransactionCodes.CheckBounceFee);

                                            switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                            {
                                                case 1:
                                                case 2:
                                                case 3:
                                                    transCodesList.Remove(TransactionCodes.RecordManagement123);
                                                    break;

                                                case 4:
                                                    transCodesList.Remove(TransactionCodes.RecordManagementOther);
                                                    break;
                                            }
                                            crmTrace.AppendLine("No good check - Add  Transaction Code for No Good Check Bucket - End");
                                        }

                                    }
                                    //Adding fees to the collection. Can be used while creating transaction history record.
                                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                                    {

                                        if (amountPaid != 0)
                                        {
                                            totalPayable = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee));
                                            #region ALT BIS Job
                                            //   if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                            //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                            //   {
                                            //       recordManagementFee = decimal.Parse(legalFeeObject.RecordManagementFee);
                                            //       crmTrace.AppendLine("Record Management Fee");
                                            //       totalPayable = decimal.Parse(fcObject.TotalFee);
                                            //       totalPayable = totalPayable - recordManagementFee;
                                            //       crmTrace.AppendLine("Total Amount" + totalPayable);
                                            //       legalFeeObject.RecordManagementFee = "0";
                                            //       crmTrace.AppendLine("record management fee " + legalFeeObject.RecordManagementFee);
                                            //       fcObject.TotalFee = "" + totalPayable;
                                            //       crmTrace.AppendLine("totalPayable ");

                                            //   }
                                            #endregion
                                            if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                totalPayable = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee));
                                                crmTrace.AppendLine("total Payable " + totalPayable);
                                            }

                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                            {
                                                if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                {
                                                    crmTrace.AppendLine("In case of more than 1 no good check fee, total payable changes to total fee + already paid no good check fee amount");
                                                    totalPayable = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee)) + existingNoGoodCheckFee;
                                                    crmTrace.AppendLine("total Payable " + totalPayable);
                                                }
                                                else
                                                {
                                                    totalPayable = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee));
                                                    crmTrace.AppendLine("total Payable " + totalPayable);
                                                }
                                            }

                                            //check if the new filing fees and exisitng filing fees are the same and proceed further only if they aren't
                                            if (totalPayable == amountPaid)
                                            {
                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                }
                                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        crmTrace.AppendLine("merchant amount " + merchantAmount);
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee)) + noGoodCheckFee;
                                                            crmTrace.AppendLine("amountdue " + amountDue);
                                                        }
                                                        crmTrace.AppendLine("merchant amount " + merchantAmount);
                                                        if (merchantAmount < amountPaid)
                                                        {

                                                            amountDue = (amountPaid - merchantAmount) + (noGoodCheckFee - existingNoGoodCheckFee);
                                                            crmTrace.AppendLine("amountdue " + amountDue + " amountpaid: " + amountPaid);
                                                        }
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;

                                                        switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                        {
                                                            case 1:
                                                            case 2:
                                                            case 3:
                                                                transCodesList.Add(TransactionCodes.RecordManagement123);
                                                                break;

                                                            case 4:
                                                                transCodesList.Add(TransactionCodes.RecordManagementOther);
                                                                break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        crmTrace.AppendLine("If amount paid and totalpayable are equal");
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(decimal.Parse("0")));
                                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                    }
                                                }
                                            }

                                            if (totalPayable > amountPaid)
                                            {
                                                crmTrace.AppendLine("If totalpayable is greater than amount paid");
                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    amountDue = totalPayable - amountPaid;
                                                }

                                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(decimal.Parse("0")));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }

                                                        if (merchantAmount < amountPaid)
                                                        {
                                                            amountDue = (amountPaid - merchantAmount) + (noGoodCheckFee - existingNoGoodCheckFee) + existingAmountdue;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        amountDue = totalPayable - amountPaid;
                                                    }
                                                }
                                                switch (((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.BuildingType]).Value)
                                                {
                                                    case 1:
                                                    case 2:
                                                    case 3:
                                                        transCodesList.Remove(TransactionCodes.RecordManagement123);
                                                        break;

                                                    case 4:
                                                        transCodesList.Remove(TransactionCodes.RecordManagementOther);
                                                        break;
                                                }
                                                if (amountDue > getRefund)
                                                {
                                                    amountDue = amountDue - getRefund;
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                    if (decimal.Parse(fcObject.NewWorkFilingFee) > newWorkFilingFee)
                                                    {
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_filingfees"] = amountDue;
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_legalizationfilingfees"] = 0;
                                                    }
                                                    if (decimal.Parse(legalFeeObject.LegalizationFilingFee) > legalFilingFee)
                                                    {
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_legalizationfilingfees"] = amountDue;
                                                        getFeeParameterResponse.Entities[0].Attributes["dobnyc_filingfees"] = 0;
                                                    }

                                                }
                                                else if (amountDue < getRefund)
                                                {
                                                    refund = getRefund - amountDue;
                                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                }

                                            }
                                            else if (totalPayable < amountPaid)
                                            {
                                                crmTrace.AppendLine("If amount paid is leass than totalpayable");

                                                if (!targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                    refund = amountPaid - totalPayable;
                                                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                                                {
                                                    crmTrace.AppendLine("No good check - If amount paid and totalpayable are equal");
                                                    if ((bool)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag] == true)
                                                    {
                                                        if (merchantAmount == amountPaid)
                                                        {
                                                            amountDue = merchantAmount + (noGoodCheckFee - existingNoGoodCheckFee) - getRefund;
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }

                                                        if (merchantAmount < amountPaid)
                                                        {
                                                            merchantAmount = merchantAmount + noGoodCheckFee - existingNoGoodCheckFee;
                                                            if (merchantAmount == getRefund)
                                                            {
                                                                amountDue = amountPaid - merchantAmount;
                                                                refund = merchantAmount - getRefund;
                                                            }

                                                            if (merchantAmount < getRefund)
                                                            {
                                                                refund = getRefund - merchantAmount;
                                                                amountDue = (decimal)0;
                                                            }

                                                            if (merchantAmount > getRefund)
                                                            {
                                                                refund = (decimal)0;
                                                                amountDue = merchantAmount - getRefund;
                                                            }
                                                            crmTrace.AppendLine("No good check - Amount Due: " + amountDue);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                                                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                                                            //jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                                                            getFeeParameterResponse.Entities[0].Attributes["dobnyc_checkbouncefee"] = noGoodCheckFee;
                                                        }
                                                    }

                                                    else
                                                    {
                                                        refund = amountPaid - totalPayable;
                                                    }
                                                }
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(refund));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.PaymentHistoryGUID, string.Empty);
                                            }
                                        }

                                        //Create a query and retrieve the transaction codes 
                                        if (refund == 0)
                                        {
                                            crmTrace.AppendLine(transCodesList.Count.ToString());
                                            //Create Transaction history records based on the transaction codes and the calulated filingfees and record management fees
                                            if (amountPaid == 0)
                                            {
                                                totalPayable = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee));
                                                crmTrace.AppendLine(fcObject.TotalFee);

                                                #region ALT BIS Job
                                                //       if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation) && targetEntity[JobFilingEntityAttributeName.AlternateJobInBISAssociation] != null &&
                                                //targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation) == true)
                                                //       {
                                                //           recordManagementFee = decimal.Parse(legalFeeObject.RecordManagementFee);
                                                //           crmTrace.AppendLine("Record Management Fee");
                                                //           totalPayable = decimal.Parse(fcObject.TotalFee);
                                                //           totalPayable = totalPayable - recordManagementFee;
                                                //           crmTrace.AppendLine("Total Amount" + totalPayable);
                                                //           legalFeeObject.RecordManagementFee = "0";
                                                //           crmTrace.AppendLine("record management fee " + legalFeeObject.RecordManagementFee);
                                                //           fcObject.TotalFee = "" + totalPayable;
                                                //           crmTrace.AppendLine("totalPayable ");

                                                //       }

                                                #endregion

                                                if (getFeeParameterResponse.Entities[0].Attributes.Contains("dobnyc_legalizationfilingfees"))
                                                {
                                                    getFeeParameterResponse.Entities[0].Attributes.Remove("dobnyc_legalizationfilingfees");
                                                    getFeeParameterResponse.Entities[0].Attributes.Add("dobnyc_legalizationfilingfees", legalFeeObject.LegalizationFilingFee);
                                                }
                                                amountDue = (decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee));
                                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money(amountDue));
                                            }

                                            transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                                            //Create Payment history
                                            FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, amountDue);
                                            crmTrace.AppendLine("Create Payment history done ");
                                            crmTrace.AppendLine(targetEntity.Id.ToString());
                                            jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                            service.Update(jobFiling);
                                            crmTrace.AppendLine("End Fee Calculation for New+Legalization Job ");
                                        }
                                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                        jobFiling.Id = targetEntity.Id;
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, new Money((decimal.Parse(fcObject.NewWorkFilingFee) + decimal.Parse(legalFeeObject.LegalizationFilingFee) + decimal.Parse(legalFeeObject.RecordManagementFee))));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.LegalizationFilingFee, new Money(decimal.Parse(legalFeeObject.LegalizationFilingFee)));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, new Money(decimal.Parse(fcObject.NewWorkFilingFee)));
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, new Money(decimal.Parse(legalFeeObject.RecordManagementFee)));
                                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, new Money(decimal.Parse("0")));
                                        service.Update(jobFiling);
                                    }
                                }
                                if (filingType == 2)
                                {
                                    JobFilingPAAHandler.CalculatePAA(service, targetEntity, crmTrace, preImage, messageName);
                                }
                            }
                            break;

                            #endregion
                    }
                }
                #endregion
               
                #region Adjustment Calculation
                // check if is job submitted or corrections completed is true and for loc adjustment check if the job status is LOC Requested. 
                crmTrace.AppendLine("Adjustment module");
                if ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true)
                    || (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true)
                    || (targetEntity.Contains(JobFilingEntityAttributeName.JobStatus) ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value == (int)JobStatus.LOCRequested :
                    preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value == (int)JobStatus.LOCRequested))
                {
                   
                    if (refund != 0 || getRefund != 0)
                    {
                        //if filing type is PAA
                        if (filingType == 2)
                        {
                            crmTrace.AppendLine("Update Payment history with IsPosted as true in case of PAA- Start ");
                            jobFiling = new Entity();
                            Entity paymentHistory = new Entity();
                            if (!targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                                targetEntity.Attributes.Add(FeeTypeName.IsPaa, true);

                            if (targetEntity.Attributes.Contains(FeeTypeName.CustomPhGuid))
                            {
                                if (refund != 0)
                                {
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(refund));
                                    targetEntity.Attributes.Add(FeeTypeName.CustomIsPaymentPosted, true);
                                }
                                if (getRefund != 0 && refund == 0)
                                {
                                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(getRefund));
                                    targetEntity.Attributes.Add(FeeTypeName.CustomIsPaymentPosted, true);
                                }

                                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                                paymentHistory.Id = new Guid(targetEntity.Attributes[FeeTypeName.CustomPhGuid].ToString());
                                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                                crmTrace.AppendLine("Update Payment history with IsPosted as true in case of PAA- End ");
                                service.Update(paymentHistory);
                            }
                        }
                        else
                        {
                            transCodesList = new List<string>();
                            crmTrace.AppendLine("Create Payment History for Adjustment - Start");
                            jobFiling = new Entity();
                            getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.Adjustment, service, crmTrace);
                            if (refund != 0)
                            {
                                getFeeParameterResponse.Entities[0].Attributes.Add(FeeSchemaNames.NewFilingFeeSchemaName, refund);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(refund));
                                //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid - refund));
                                targetEntity.Attributes.Add("CustomePaymentPosted", true);

                            }
                            if (getRefund != 0 && refund == 0)
                            {
                                getFeeParameterResponse.Entities[0].Attributes.Add(FeeSchemaNames.NewFilingFeeSchemaName, getRefund);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(getRefund));
                                //jobFiling.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(amountPaid - getRefund));
                                targetEntity.Attributes.Add("CustomePaymentPosted", true);
                            }

                            crmTrace.AppendLine("Create transaction code for Adjustment - Start");
                            transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);

                            foreach (var transCodes in transCodesResponse.Entities)
                            {
                                crmTrace.AppendLine("Add transaction codes to transcodes collection - Start");
                                transCodesList.Add(transCodes.Attributes[TransactionCodeAttributeNames.TransCode].ToString());
                                crmTrace.AppendLine("Add transaction codes to transcodes collection  - End");
                            }
                            crmTrace.AppendLine("Create transaction code for Adjustment - End");
                            crmTrace.AppendLine("Create Payment Bucket for Adjustment - Start");
                            transHistoryGuids = FeeCalculationHelper.CreateEntityTransCodes(crmTrace, service, transCodesList, getFeeParameterResponse, targetEntity, transCodesResponse, preImage);
                            crmTrace.AppendLine("Create Payment Bucket for Adjustment - End");
                            FeeCalculationHelper.CreatePaymentHistory(service, crmTrace, targetEntity, transHistoryGuids, 0);
                            crmTrace.AppendLine("Create Payment History for Adjustment - End");
                        }

                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Id = targetEntity.Id;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                        jobFiling.Attributes.Remove(JobFilingEntityAttributeName.FilingStatus);
                        service.Update(jobFiling);
                    }
                }
                #endregion
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "testing purpose  - CalculateFee", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalc - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }
    }
}
