﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class DelegatesEmailsHandler : PluginHandlerBase
    {
        public static Entity JobFilingEmails_AddDelegates_Inspectors(IOrganizationService service, Entity targetEntity, EntityReference JobFilingApplication, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression delegatesCondition = new ConditionExpression();
                EntityCollection delegatesCollection = new EntityCollection();
                EntityCollection toList = new EntityCollection();
                EntityCollection ccList = new EntityCollection();                
                bool allowDelegateEmails = false;
                bool addSIPIinEmail = false; // flag to add Special Inspectors/Progress Inspectors in Emails
                bool addTR3StakeholdersinEmail = false; // flag to add TR3 Concrete Producer and Concrete Testing Lab Director in Emails
                bool isCC = false;
                string emailSubject = targetEntity.GetAttributeValue<string>(EmailEntityAttributeName.Subject);
                emailSubject = emailSubject.ToUpper();
                crmTrace.AppendLine("Email Subject: "+ emailSubject);

                
                string fetch = string.Format(FetchXml.GetCustomConfigByKeyLike, DelegateEmailConfigKeys.DelegateEmailSubject);
                crmTrace.AppendLine("fetch: " + fetch);
                EntityCollection CustomConfigResponse_Email = service.RetrieveMultiple(new FetchExpression(fetch));
                crmTrace.AppendLine("CustomConfigResponse_Email.Entities.Count: " + CustomConfigResponse_Email.Entities.Count);

                
                if (CustomConfigResponse_Email != null && CustomConfigResponse_Email.Entities.Count > 0)
                {
                    crmTrace.AppendLine("CustomConfigResponse_Email.Entities.Count: " + CustomConfigResponse_Email.Entities.Count);
                    foreach (Entity delegateEmailConfig in CustomConfigResponse_Email.Entities)
                    {
                        crmTrace.AppendLine("Subject: " + delegateEmailConfig.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Name).ToUpper());
                        if (emailSubject.Contains(delegateEmailConfig.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Name).ToUpper()))
                        {
                            isCC = delegateEmailConfig.Contains(CustomConfigurationEntityAttributeName.Key) ? delegateEmailConfig.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key).Contains(DelegateEmailConfigKeys.DelegateEmailSubjectCC) :false;                            
                            allowDelegateEmails = true;
                            crmTrace.AppendLine("Need to add Delegate in CC/TO list. isCC: " + isCC);
                            addSIPIinEmail = delegateEmailConfig.Contains(CustomConfigurationEntityAttributeName.Key) ? delegateEmailConfig.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key).Contains(DelegateEmailConfigKeys.AddInspectors) : false;
                            crmTrace.AppendLine("addSIPIinEmail: " + addSIPIinEmail);
                            addTR3StakeholdersinEmail = delegateEmailConfig.Contains(CustomConfigurationEntityAttributeName.Key) ? delegateEmailConfig.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key).Contains(DelegateEmailConfigKeys.AddTR3Stakeholders) : false;
                            crmTrace.AppendLine("addTR3StakeholdersinEmail: " + addTR3StakeholdersinEmail);
                            break;
                        }
                    }
                }

                                
                #region Retrieve All Delegates of the Job Filing
                if (allowDelegateEmails)
                {
                    //Get To and CC List of the email
                    toList = targetEntity.GetAttributeValue<EntityCollection>(EmailEntityAttributeName.To);
                    if (toList != null && toList.Entities.Count > 0)
                        crmTrace.AppendLine("Existing To List Count: " + toList.Entities.Count);

                    if(targetEntity.Contains(EmailEntityAttributeName.Cc))
                    ccList = targetEntity.GetAttributeValue<EntityCollection>(EmailEntityAttributeName.Cc);

                    if (ccList != null && ccList.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Existing CC List Count: " + ccList.Entities.Count);
                    }
                       

                    crmTrace.AppendLine("Email Regarding Job Filing Application: " + JobFilingApplication.LogicalName);
                    crmTrace.AppendLine("Email Regarding Job Filing Application Id: " + JobFilingApplication.Id.ToString());

                    delegatesCondition = CreateConditionExpression(DelegatesEntityAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingApplication.Id.ToString() });
                    delegatesCollection = RetrieveMultiple(service, DelegatesEntityAttributeNames.EntityLogicalName, new string[] { DelegatesEntityAttributeNames.GoToContact, DelegatesEntityAttributeNames.Name }, new ConditionExpression[] { delegatesCondition }, LogicalOperator.And);

                    if (delegatesCollection != null && delegatesCollection.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("DelegatesCollection.Entities.Count: " + delegatesCollection.Entities.Count);
                        foreach (Entity delegateRec in delegatesCollection.Entities)
                        {
                            Guid delegateGuid = ((EntityReference)delegateRec[DelegatesEntityAttributeNames.GoToContact]).Id;
                            crmTrace.AppendLine("DelegateGuid: " + delegateRec.Id.ToString());
                            Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                            crmTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                            toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, delegateGuid);
                            crmTrace.AppendLine("Added Guid.");
                            if (isCC)
                            {
                                if (!ccList.Entities.Contains(toParty))
                                    ccList.Entities.Add(toParty);
                            }
                            else
                            {
                                if (!toList.Entities.Contains(toParty))
                                    toList.Entities.Add(toParty);
                            }
                                
                            crmTrace.AppendLine("Added toParty.");
                        }
                    }

                    #region Send Emails to Progress Inspectors and Special Inspectors
                    if (addSIPIinEmail)
                    {
                        string[] ColumnNames_Progress = new string[] { ProgressInspectionCategoryAttributeNames.ProgressInspector };
                        ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingApplication.Id.ToString() });
                        ConditionExpression progressInspCondition2 = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.ProgressInspector, ConditionOperator.NotNull, new string[] { });
                        EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ColumnNames_Progress, new ConditionExpression[] { progressInspCondition, progressInspCondition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("progressInspResponse.Entities.Count: " + progressInspResponse.Entities.Count);
                        if (progressInspResponse != null && progressInspResponse.Entities.Count > 0)
                        {
                            foreach (Entity prgInspection in progressInspResponse.Entities)
                            {
                                if (prgInspection.Contains(ProgressInspectionCategoryAttributeNames.ProgressInspector))
                                {
                                    Guid ProgressInspectorGuid = ((EntityReference)prgInspection[ProgressInspectionCategoryAttributeNames.ProgressInspector]).Id;
                                    Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                                    crmTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                                    toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, ProgressInspectorGuid);
                                    crmTrace.AppendLine("Added Guid.");
                                    if (isCC)
                                    {
                                        if (!ccList.Entities.Contains(toParty))
                                            ccList.Entities.Add(toParty);
                                    }
                                    else
                                    {
                                        if (!toList.Entities.Contains(toParty))
                                            toList.Entities.Add(toParty);
                                    }
                                    crmTrace.AppendLine("Added toParty.");
                                }
                            }
                        }

                        string[] ColumnNames_Special = new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspector };
                        ConditionExpression SpecialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { JobFilingApplication.Id.ToString() });
                        ConditionExpression SpecialInspCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspector, ConditionOperator.NotNull, new string[] { });
                        EntityCollection SpecialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, ColumnNames_Special, new ConditionExpression[] { SpecialInspCondition, SpecialInspCondition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("SpecialInspResponse.Entities.Count: " + SpecialInspResponse.Entities.Count);
                        if (SpecialInspResponse != null && SpecialInspResponse.Entities.Count > 0)
                        {
                            foreach (Entity spclInspection in SpecialInspResponse.Entities)
                            {
                                if (spclInspection.Contains(SpecialInspectionCategoriesAttributeNames.SpecialInspector))
                                {
                                    Guid SpecialInspectorGuid = ((EntityReference)spclInspection[SpecialInspectionCategoriesAttributeNames.SpecialInspector]).Id; Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                                    crmTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                                    toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, SpecialInspectorGuid);
                                    crmTrace.AppendLine("Added Guid.");
                                    if (isCC)
                                    {
                                        if (!ccList.Entities.Contains(toParty))
                                            ccList.Entities.Add(toParty);
                                    }
                                    else
                                    {
                                        if (!toList.Entities.Contains(toParty))
                                            toList.Entities.Add(toParty);
                                    }
                                    crmTrace.AppendLine("Added toParty.");
                                }
                            }
                        }
                    }

                    #endregion

                    #region Add Concrete Producer and Concrete Testing Lab Director in Email
                    if(addTR3StakeholdersinEmail)
                    {
                        string[] ColumnNames = new string[] { TR3Directors.ConcreteProducerName, TR3Directors.TR3DirectorEmail };
                        ConditionExpression condition = CreateConditionExpression(TR3TechnicalReportEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { JobFilingApplication.Id.ToString() });
                        EntityCollection TR3Reports = RetrieveMultiple(service, TR3TechnicalReportEntityAttribute.EntityLogicalName, ColumnNames, new ConditionExpression[] { condition }, LogicalOperator.And);
                        crmTrace.AppendLine("TR3Reports count : " + TR3Reports.Entities.Count);
                        if (TR3Reports != null && TR3Reports.Entities.Count > 0)
                        {
                            foreach (Entity TR3 in TR3Reports.Entities)
                            {
                                Guid producerId = TR3.Contains(TR3Directors.ConcreteProducerName)?((EntityReference)TR3[TR3Directors.ConcreteProducerName]).Id : Guid.Empty;
                                crmTrace.AppendLine("producerId: " + producerId.ToString());
                                if (producerId != Guid.Empty)
                                {
                                    Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                                    crmTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                                    toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, producerId);
                                    crmTrace.AppendLine("Added Guid.");
                                    if (isCC)
                                    {
                                        if (!ccList.Entities.Contains(toParty))
                                            ccList.Entities.Add(toParty);
                                    }
                                    else
                                    {
                                        if (!toList.Entities.Contains(toParty))
                                            toList.Entities.Add(toParty);
                                    }

                                    crmTrace.AppendLine("Added toParty.");
                                }

                                Guid directorId = TR3.Contains(TR3Directors.TR3DirectorEmail) ? ((EntityReference)TR3[TR3Directors.TR3DirectorEmail]).Id : Guid.Empty;
                                crmTrace.AppendLine("directorId: " + directorId.ToString());
                                if (directorId != Guid.Empty)
                                {
                                    Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                                    crmTrace.AppendLine("toParty: " + toParty.LogicalName.ToString());
                                    toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, directorId);
                                    crmTrace.AppendLine("Added Guid.");
                                    if (isCC)
                                    {
                                        if (!ccList.Entities.Contains(toParty))
                                            ccList.Entities.Add(toParty);
                                    }
                                    else
                                    {
                                        if (!toList.Entities.Contains(toParty))
                                            toList.Entities.Add(toParty);
                                    }

                                    crmTrace.AppendLine("Added toParty.");
                                }

                            }
                        }

                    }
                    #endregion

                    if (toList != null && toList.Entities.Count > 0)
                        crmTrace.AppendLine("Total To list Count: " + toList.Entities.Count);
                    if (ccList != null && ccList.Entities.Count > 0)
                        crmTrace.AppendLine("Total CC list Count: " + ccList.Entities.Count);

                    if (isCC)
                        targetEntity[EmailEntityAttributeName.Cc] = ccList;
                    else
                        targetEntity[EmailEntityAttributeName.To] = toList;
                }
                else
                {
                    crmTrace.AppendLine("No Emails to Delegates.");
                }
                #endregion
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", null, crmTrace.ToString(), null, null);

                return targetEntity;
            }
            #region catch
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nInnerException:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - JobFilingEmails_AddDelegates_Inspectors", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            #endregion
        }

        public static Entity AddPERAInL2RequestEmails(IOrganizationService service, Entity targetEntity, EntityReference L2Request, StringBuilder crmTrace)
        {
            try
            {
                #region Declaration
                ConditionExpression violationCodeCondition = new ConditionExpression();
                EntityCollection violationCodeCollection = new EntityCollection();
                EntityCollection existingToList = new EntityCollection();
                string[] customConfigColumnNames = { CustomConfigurationEntityAttributeName.Name, CustomConfigurationEntityAttributeName.Key };
                bool allowREDTPERAEmails = false;
                string emailSubject = targetEntity.GetAttributeValue<string>(EmailEntityAttributeName.Subject).ToUpper();
                crmTrace.AppendLine("Email Subject: " + emailSubject);
                #endregion

                #region Check for L2 Request Emails by Subject
                ConditionExpression L2RequestEmailSubjectCondition = CreateConditionExpression(CustomConfigurationEntityAttributeName.Key, ConditionOperator.Equal, new string[] { L2RequestEmailsConfigKeys.L2RequestApplicantEmailSubject });
                EntityCollection L2RequestEmailSubjectCollection = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, customConfigColumnNames, new ConditionExpression[] { L2RequestEmailSubjectCondition }, LogicalOperator.Or);

                if (L2RequestEmailSubjectCollection != null && L2RequestEmailSubjectCollection.Entities.Count > 0)
                {
                    crmTrace.AppendLine("L2RequestEmailSubjectCollection.Entities.Count: " + L2RequestEmailSubjectCollection.Entities.Count);
                    foreach (Entity L2RequestEmailSubject in L2RequestEmailSubjectCollection.Entities)
                    {
                        crmTrace.AppendLine("Subject: " + L2RequestEmailSubject.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Name).ToUpper());
                        if (emailSubject.StartsWith(L2RequestEmailSubject.GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Name).ToUpper(), StringComparison.CurrentCulture))
                        {
                            allowREDTPERAEmails = true;
                            crmTrace.AppendLine("Need to add REDT PE/RA in 'To' list.");
                            break;
                        }
                    }
                }
                #endregion

                #region Add REDT PE/RA to L2 Request
                if (allowREDTPERAEmails)
                {
                    #region Get To List of the email
                    existingToList = targetEntity.GetAttributeValue<EntityCollection>(EmailEntityAttributeName.To);
                    if (existingToList != null && existingToList.Entities.Count > 0)
                        crmTrace.AppendLine("Existing To List Count: " + existingToList.Entities.Count);
                    #endregion

                    crmTrace.AppendLine("Email Regarding L2Request: " + L2Request.LogicalName);
                    crmTrace.AppendLine("Email Regarding L2Request Id: " + L2Request.Id.ToString());

                    violationCodeCondition = CreateConditionExpression(ViolationsCodesAttributeNames.GoToL2Request, ConditionOperator.Equal, new string[] { L2Request.Id.ToString() });
                    violationCodeCollection = RetrieveMultiple(service, ViolationsCodesAttributeNames.EntityLogicalName, new string[] { ViolationsCodesAttributeNames.REDTApplicant, ViolationsCodesAttributeNames.ViolationNumber }, new ConditionExpression[] { violationCodeCondition }, LogicalOperator.And);

                    if (violationCodeCollection != null && violationCodeCollection.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("violationCodeCollection.Entities.Count: " + violationCodeCollection.Entities.Count);
                        foreach (Entity violationCodeRecord in violationCodeCollection.Entities)
                        {
                            Guid REDTPERAGuid = ((EntityReference)violationCodeRecord[ViolationsCodesAttributeNames.REDTApplicant]).Id;
                            crmTrace.AppendLine("ViolationCode Guid: " + violationCodeRecord.Id.ToString());

                            Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                            crmTrace.AppendLine("toParty: " + toParty.LogicalName);
                            toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, REDTPERAGuid);
                            crmTrace.AppendLine("Added Guid.");

                            if (!existingToList.Entities.Contains(toParty))
                            {
                                existingToList.Entities.Add(toParty);
                                targetEntity[EmailEntityAttributeName.To] = existingToList;
                            }

                            crmTrace.AppendLine("Added toParty.");
                        }
                    }
                }
                #endregion

                return targetEntity;
            }

            #region catch
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception: " + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Fault Exception."));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Timeout Exception."), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "DelegatesEmailsHandler - AddPERAInL2RequestEmails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Exception."), null);
                return targetEntity;
            }
            #endregion

        }

    }
}
