﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobFilingFeeCalculationHandler : PluginHandlerBase
    {



        public static void CalculateFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {

            #region Varibale Declarations

            string formulaeName = string.Empty;
            decimal totalJobCost = 0;
            Dictionary<string, int> preimageValues = new Dictionary<string, int>();
            decimal calculatedJobCost = 0;
            decimal refund = 0;

            #endregion


            crmTrace.AppendLine("Get Values from PreImage");
            preimageValues = ImageValues(preImage, crmTrace);
            crmTrace.AppendLine("Get Values from PreImage - End");

            crmTrace.AppendLine("Get the Calculation Name Value");
            formulaeName = BuildCalcName(preimageValues, crmTrace);
            crmTrace.AppendLine("Get the Calculation Name Value - End." + formulaeName);

            crmTrace.AppendLine("Fee type value:" + preimageValues[JobFilingEntityAttributeName.FeeType]);

            switch (preimageValues[JobFilingEntityAttributeName.FeeType])
            {

                case FeeType.FilingFees:
                    crmTrace.AppendLine("Case value = 1" );
                    totalJobCost = CalculateFilingFees(service, targetEntity, crmTrace, preImage, preimageValues, formulaeName);
                    throw new Exception(totalJobCost.ToString());
                    crmTrace.AppendLine("Upate Filing Fees" + totalJobCost);

                    Money totalJobCostMon = new Money(totalJobCost);
                    Entity jobFiling = new Entity();
                    jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingFees, totalJobCostMon);
                    jobFiling.Id = targetEntity.Id;
                    
                    UpdateEntity(service, jobFiling);

                    crmTrace.AppendLine("Update Filing Fees - done");
                    break;


                case FeeType.PermitRenewal:
                    PermitRenewal(service, targetEntity, crmTrace, preImage, formulaeName);
                    break;

                case FeeType.CheckBounceFee:
                    CheckBounce(service, targetEntity, crmTrace, preImage, formulaeName);
                    break;
            }

            try
            {

                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingFees))
                //    calculatedJobCost = decimal.Parse(preImage[JobFilingEntityAttributeName.FilingFees].ToString());

                //if (totalJobCost < calculatedJobCost)
                //{
                //    totalJobCost = calculatedJobCost;
                //    refund = calculatedJobCost - totalJobCost;
                //}

                CreatePaymentHistory(service, crmTrace, preImage);


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        #region Construct Calculation Name from Values from
        public static string BuildCalcName(Dictionary<string, int> imageValues, StringBuilder Trace)
        {
            Guid trackingGuid = Guid.NewGuid();
            Trace.AppendLine("Enter BuildCalcName Function");
            int feeVal = imageValues[JobFilingEntityAttributeName.FeeType];
            int buildVal = imageValues[JobFilingEntityAttributeName.BuildingType];

            Trace.AppendLine("feeVal=" + feeVal);
            Trace.AppendLine("buildVal=" + buildVal);

            //This method retutns the Calculation Name(formulae name) to retrieve the 
            //appropriate record to calculate the Filing fee from the Filing Fee Calculation Configuration entity
            
            string calcName = string.Empty;
            try
            {
                if (feeVal != 1)
                {
                    switch (feeVal)
                    {
                        case 1:
                            calcName = FeeTypeName.FilingFees;
                            break;
                        case 2:
                            calcName = FeeTypeName.PermitRenewal;
                            break;
                        case 3:
                            calcName = FeeTypeName.AHV;
                            break;
                        case 4:
                            calcName = FeeTypeName.CheckBounceFee;
                            break;

                    }
                }

                else
                {
                    switch (buildVal)
                    {
                        case 1:
                            calcName = BuildingTypeName.familyHouse123 + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                            break;
                        case 2:
                            calcName = BuildingTypeName.familyHouseOther + " " + "ALT2" + " " + FeeTypeName.FilingFees;
                            break;

                    }
                }
                Trace.AppendLine("Exit BuildCalcName Function " + calcName);
                return calcName;
             
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, Trace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return calcName;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, Trace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return calcName;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", null, Trace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return calcName;
            }

        }
        #endregion


        #region Filing Fees Calculation
        public static decimal CalculateFilingFees(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, Dictionary<string, int> imageValues, string formulaeName)
        {
            decimal totalJobCost = 0;

            try
            {
                int minFilingFee = 0;
                int recordManFee = 0;
                int legalMin = 0;
                int legalMul = 0;
                decimal tier1Cost = 0;
                decimal tier2Cost = 0;
                decimal diffJobCost = 0;
                decimal interJobCost = 0;
                decimal estJobCost = ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]).Value;

                if (estJobCost > 5000)
                {
                    diffJobCost = (estJobCost - 5000) / 1000;
                }

                crmTrace.AppendLine("Fee Calculation started!");
                ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
                EntityCollection calcResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.Tier1CostFee, FeeCalculationConfigurationAttributeNames.Tier2CostFee, FeeCalculationConfigurationAttributeNames.RecordManagementFee, FeeCalculationConfigurationAttributeNames.MinFilingFee, FeeCalculationConfigurationAttributeNames.LegalizationMinFee, FeeCalculationConfigurationAttributeNames.LegalizationFeeMul }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                crmTrace.AppendLine("Entity Collection Completed");
                crmTrace.AppendLine("Respone count" + calcResponse.Entities.Count);


                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                    minFilingFee = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString().Trim());

                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                    tier1Cost = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier1CostFee].ToString().Trim());

                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier2CostFee))
                    tier2Cost = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier2CostFee].ToString().Trim());

                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                    recordManFee = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString().Trim());

                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationMinFee))
                    legalMin = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationMinFee].ToString().Trim());

                if (calcResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationFeeMul))
                    legalMul = int.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.LegalizationFeeMul].ToString().Trim());
                #region Calculation Logic
                //If JobType is NewJob
                QueryExpression ieQuery = RetrieveIntersectEntity(crmTrace, calcResponse, targetEntity);
                List<string> tcodes = new List<string>();
                tcodes.Add("121");
                if (imageValues[JobFilingEntityAttributeName.BuildingType] == (int)BuildingType.familyHouse123)
                {


                    tcodes.Add("198");
                    if (estJobCost <= 5000)
                    {
                        crmTrace.AppendLine("Estimated Job Cost < 5000");
                        interJobCost = minFilingFee;
                        totalJobCost = interJobCost + recordManFee;

                        calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                        crmTrace.AppendLine("call create entity transaction code function");
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                    if (estJobCost > 5000)
                    {
                        crmTrace.AppendLine("Estimated Job Cost > 5000");
                        interJobCost = (minFilingFee + (diffJobCost * tier1Cost));
                        totalJobCost = interJobCost + recordManFee;
                        calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                    if (imageValues[JobFilingEntityAttributeName.JobType] == (int)JobType.Legal)
                    {
                        crmTrace.AppendLine("Legal Filing - 123 Family");
                        tcodes.Add("808");
                        totalJobCost = 4 * totalJobCost;

                        if (totalJobCost < legalMin)
                        {
                            totalJobCost = legalMin;
                        }
                        calcResponse.Entities[0].Attributes.Add("dobnyc_legalfilingfees", totalJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                }


                else
                {
                    tcodes.Add("199");
                    if (estJobCost <= 3000)
                    {
                        crmTrace.AppendLine("Estimated Job Cost < 3000");

                        totalJobCost = interJobCost + recordManFee;
                        calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                    if (estJobCost > 3000 & estJobCost <= 5000)
                    {
                        crmTrace.AppendLine("Estimated Job Cost between 3000 and 5000");
                        interJobCost = minFilingFee + (2 * tier1Cost);
                        totalJobCost = interJobCost + recordManFee;
                        calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                    if (estJobCost > 5000)
                    {
                        crmTrace.AppendLine("Estimated Job Cost > 5000");
                        interJobCost = minFilingFee + (2 * tier1Cost) + (diffJobCost * tier2Cost);
                        totalJobCost = interJobCost + recordManFee;
                        calcResponse.Entities[0].Attributes.Add("dobnyc_filingfees", interJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);
                    }

                    if (imageValues[JobFilingEntityAttributeName.JobType] == (int)JobType.Legal)
                    {
                        crmTrace.AppendLine("Legal Other");
                        tcodes.Add("808");
                        totalJobCost = 14 * totalJobCost;

                        if (totalJobCost < legalMin)
                        {
                            totalJobCost = legalMin;
                        }
                        calcResponse.Entities[0].Attributes.Add("dobnyc_legalfilingfees", totalJobCost);
                        CreateEntityTransCodes(crmTrace, ieQuery, service, preImage, tcodes, calcResponse);


                    }

                }
                crmTrace.AppendLine("Fee Calculation End");

                return totalJobCost;
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return totalJobCost;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return totalJobCost;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CalculateFilingFees", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return totalJobCost;
            }
        }

        #endregion


        #region Get Values from Entity
        public static Dictionary<string, int> ImageValues(Entity preImage, StringBuilder crmTrace)
        {
            Guid trackingGuid = Guid.NewGuid();
            Dictionary<string, int> imageValues = new Dictionary<string, int>();

            try
            {
                int buildingTypeVal = 0;
                int jobTypeVal = 0;
                int feeTypeVal = 0;
                
                crmTrace.AppendLine("Retrieve Building Type");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                {
                    buildingTypeVal = ((OptionSetValue)preImage[JobFilingEntityAttributeName.BuildingType]).Value;
                    imageValues.Add(JobFilingEntityAttributeName.BuildingType, buildingTypeVal);
                    crmTrace.AppendLine("Retrieve Building Type:" + buildingTypeVal);
                }

                crmTrace.AppendLine("Retrieve Fee Type Value");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FeeType))
                {
                    feeTypeVal = ((OptionSetValue)preImage[JobFilingEntityAttributeName.FeeType]).Value;
                    crmTrace.AppendLine("Retrieve Fee Type Value" + feeTypeVal);

                    imageValues.Add(JobFilingEntityAttributeName.FeeType, feeTypeVal);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName))
                {
                    jobTypeVal = ((OptionSetValue)preImage[JobFilingEntityAttributeName.JobType]).Value;

                    imageValues.Add(JobFilingEntityAttributeName.JobType, jobTypeVal);
                }


                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - ImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }


        #endregion


        #region Queryexpression for Retrieving from Transhistory Intersect Entity
        public static QueryExpression RetrieveIntersectEntity(StringBuilder crmTrace, EntityCollection calcResponse, Entity targetEntity)
        {
            crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity");
            QueryExpression query = new QueryExpression()
            {
                EntityName = TransactionCodeAttributeNames.EntityLogicalName,
                ColumnSet = new ColumnSet(TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory, TransactionCodeAttributeNames.RevenueSource,
                TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText, TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.TransType, TransactionCodeAttributeNames.FeeSchemaName),
                LinkEntities = 
                        {
                            new LinkEntity()    
                            {
                                
                                LinkFromEntityName = TransactionCodeAttributeNames.EntityLogicalName,
                                LinkFromAttributeName = TransactionCodeAttributeNames.Id,
                                LinkToEntityName = FeeCalculationTransactionCodeIntersect.EntityLogicalName,
                                LinkToAttributeName = TransactionCodeAttributeNames.Id,
                                LinkCriteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions = 
                                    {
                                        new ConditionExpression
                                        {
                                            AttributeName = FeeCalculationConfigurationAttributeNames.Id,
                                            Operator = ConditionOperator.Equal,
                                            Values = { calcResponse.Entities[0].Id }
                                        }
                                    }
                                }
                            }
                        }
            };
            return query;
        }
        #endregion


        #region Create Transaction History based on Transaction Codes
        public static void CreateEntityTransCodes(StringBuilder crmTrace, QueryExpression query, IOrganizationService service, Entity preImage, List<string> transCodes, EntityCollection entity)
        {
            try
            {
                crmTrace.AppendLine("Create Transaction history - Start");
                EntityCollection transCollection = service.RetrieveMultiple(query);
                foreach (var tcollection in transCollection.Entities)
                {

                    Entity transHistory = new Entity();
                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                   // transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                    if (preImage.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, preImage.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName]);
                    if (tcollection.Contains(TransactionCodeAttributeNames.FeeSchemaName))
                        if (entity.Entities[0].Contains(tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString()))
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, entity.Entities[0].Attributes[tcollection.Attributes[TransactionCodeAttributeNames.FeeSchemaName].ToString()].ToString());

                    for (int i = 0; i < transCodes.Count; i++)
                    {
                        if (transCodes[i] == tcollection.Attributes[TransactionCodeAttributeNames.TransCode].ToString())
                        {
                            service.Create(transHistory);
                        }
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }
        #endregion


        #region Create Transaction history
        public static void CreateTransactionHistory(QueryExpression query, IOrganizationService service, Entity preImage, string fees)
        {
            EntityCollection transCollection = service.RetrieveMultiple(query);
            foreach (var tcollection in transCollection.Entities)
            {

                Entity transHistory = new Entity();
                transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, preImage.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName]);
                //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fees);
                service.Create(transHistory);

            }
        }
        #endregion


        #region AHV
        //public static void AFVCalculation(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string formulaeName)
        //{
        //    decimal afvFee13 = 0;
        //    decimal afvFee46 = 0;
        //    decimal afvFee79 = 0;
        //    decimal afvFee1012 = 0;
        //    decimal afvFee1314 = 0;
        //    decimal afvDailyFee = 0;

        //    ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
        //    EntityCollection afvResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.Days13, FeeCalculationConfigurationAttributeNames.Days46, FeeCalculationConfigurationAttributeNames.Days79, FeeCalculationConfigurationAttributeNames.Days1012, FeeCalculationConfigurationAttributeNames.Days1012, FeeCalculationConfigurationAttributeNames.DailyFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvFee13 = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvFee46 = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvFee79 = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvFee1012 = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvFee1314 = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());

        //    if (afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13))
        //        afvDailyFee = decimal.Parse(afvResponse.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Days13).ToString());



        //}
        #endregion

        public static void PermitRenewal(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string formulaeName)
        {

            try
            {
                crmTrace.AppendLine("Start PermitRenewal Method");
                ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
                EntityCollection prResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.PermitRenewalFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                string prFees = prResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PermitRenewalFee].ToString();

                QueryExpression prQuery = RetrieveIntersectEntity(crmTrace, prResponse, targetEntity);
                CreateTransactionHistory(prQuery, service, preImage, prFees);
                crmTrace.AppendLine("End PermitRenewal Method");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - PermitRenewal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static void CheckBounce(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, string formulaeName)
        {

            try
            {
                crmTrace.AppendLine("Start CheckBounce Method");
                ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });
                EntityCollection cbResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.CheckBounce }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                string cbFees = cbResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce].ToString();

                QueryExpression prQuery = RetrieveIntersectEntity(crmTrace, cbResponse, targetEntity);
                CreateTransactionHistory(prQuery, service, preImage, cbFees);
                crmTrace.AppendLine("Start CheckBounce Method");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CheckBounce", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        #region Create Payment History
        public static void CreatePaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity preImage)
        {

            try
            {
                crmTrace.AppendLine("Start CreatePaymentHistory method ");
                Entity paymentHistory = new Entity();
                Guid paymentHistoryId = Guid.Empty;
                string jobNumber = string.Empty;
                EntityReferenceCollection tHistory = new EntityReferenceCollection();


                if (preImage.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                    jobNumber = preImage.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();

                ConditionExpression jobNumberCondition = CreateConditionExpression(TransactionHistoryAttributeNames.JobNumber, ConditionOperator.Equal, new string[] { jobNumber });
                EntityCollection thResponse = RetrieveMultiple(service, TransactionHistoryAttributeNames.EntityLogicalName, new string[] { TransactionHistoryAttributeNames.JobNumber }, new ConditionExpression[] { jobNumberCondition }, LogicalOperator.And);


                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, jobNumber);

                paymentHistoryId = service.Create(paymentHistory);

                //else
                //    paymentHistoryId = thResponse.Entities[0].Id;


                if (thResponse != null && thResponse.Entities != null && thResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("tHResponse count: " + thResponse.Entities.Count);
                    for (int i = 0; i < thResponse.Entities.Count; i++)
                        tHistory.Add(new EntityReference(TransactionHistoryAttributeNames.EntityLogicalName, thResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for Plan Examiner Objections");
                    service.Associate(PaymentHistoryAttributeNames.EntityLogicalName, paymentHistoryId, new Relationship(PaymentHistoryAttributeNames.PaymentHistTransHistRelationShipName), tHistory);
                    crmTrace.AppendLine("End Association for Plan Examiner Objections");
                }
                crmTrace.AppendLine("Start CreatePaymentHistory method ");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingFeeCalculationHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


            #endregion

        }




    }
}