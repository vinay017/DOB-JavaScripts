﻿using System;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class AcrafNumberGeneratorHandler : PluginHandlerBase
    {
        public static void AcrafNumberGenerator(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            Entity acrafConfigEntity = new Entity();
            Entity acrafNumberEntity = new Entity();
            string fiscal = string.Empty;
            string adminno = string.Empty;
            string acrafSequence = string.Empty;
            string acrafNumber = string.Empty;
            string sequenceNumber = string.Empty;

            try
            {
                crmTrace.AppendLine("Enter Number Generator");
                ConditionExpression acrafNumberCondition = CreateConditionExpression(AcrafAutoNumberAttributeNames.Name, ConditionOperator.Equal, new string[] { "Acraf Info" });
                EntityCollection acrafResponse = RetrieveMultiple(service, AcrafAutoNumberAttributeNames.EntityLogicalName, new string[] { AcrafAutoNumberAttributeNames.AcrafFiscalYear,AcrafAutoNumberAttributeNames.AcrafAdminCenter,
                AcrafAutoNumberAttributeNames.AcrafSequenceNumber}, new ConditionExpression[] { acrafNumberCondition }, LogicalOperator.And);

                crmTrace.AppendLine(acrafResponse.Entities.Count.ToString());

                if (acrafResponse.Entities[0].Attributes.Contains(AcrafAutoNumberAttributeNames.AcrafFiscalYear))
                    fiscal = acrafResponse.Entities[0].Attributes[AcrafAutoNumberAttributeNames.AcrafFiscalYear].ToString();

                if (acrafResponse.Entities[0].Attributes.Contains(AcrafAutoNumberAttributeNames.AcrafAdminCenter))
                    adminno = acrafResponse.Entities[0].Attributes[AcrafAutoNumberAttributeNames.AcrafAdminCenter].ToString();

                if (acrafResponse.Entities[0].Attributes.Contains(AcrafAutoNumberAttributeNames.AcrafSequenceNumber))
                    acrafSequence = acrafResponse.Entities[0].Attributes[AcrafAutoNumberAttributeNames.AcrafSequenceNumber].ToString();

                acrafNumber = fiscal + adminno + acrafSequence;
                crmTrace.AppendLine("acraf number created" + acrafNumber);

                acrafConfigEntity.Attributes.Add(AcrafConfigurationAttributeNames.Name, acrafNumber);
                DateTime currentdate = DateTime.Now;
                acrafConfigEntity.Attributes.Add(AcrafConfigurationAttributeNames.AcrafCreatedOn,currentdate.Date);
                acrafConfigEntity.LogicalName = AcrafConfigurationAttributeNames.EntityLogicalName;
                acrafConfigEntity.Id = targetEntity.Id;
                crmTrace.AppendLine(targetEntity.Id.ToString());

                service.Update(acrafConfigEntity);

                crmTrace.AppendLine((int.Parse(acrafResponse.Entities[0].Attributes[AcrafAutoNumberAttributeNames.AcrafSequenceNumber].ToString()) + 1).ToString());

                sequenceNumber = (int.Parse(acrafResponse.Entities[0].Attributes[AcrafAutoNumberAttributeNames.AcrafSequenceNumber].ToString()) + 1).ToString();

                switch (sequenceNumber.Length)
                {
                    case 1:
                        sequenceNumber = "0" + "0" + sequenceNumber;
                        break;

                    case 2:
                        sequenceNumber = "0" + sequenceNumber;
                        break;
                }

                crmTrace.AppendLine("Sequence Number " + sequenceNumber);

                //Update sequence number
                acrafNumberEntity.LogicalName = AcrafAutoNumberAttributeNames.EntityLogicalName;
                acrafNumberEntity.Attributes.Add(AcrafAutoNumberAttributeNames.AcrafSequenceNumber, sequenceNumber);
                acrafNumberEntity.Id = acrafResponse.Entities[0].Id;
                service.Update(acrafNumberEntity);

                
                crmTrace.AppendLine("Updated Acraf Sequence Number ");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AcrafNumberGeneratorHandler - AcrafNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
