﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Crm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    class FeeCalculationStandardizationHandler : PluginHandlerBase
    {
        /// <summary>
        /// This function reads the associated worktypes for the jobfiling and make the respective worktype flags to true in feeobject
        /// </summary>
        /// <param name="preImage"></param>
        /// <param name="targetEntity"></param>
        /// <param name="fcObject"></param>
        /// <param name="crmTrace"></param>
        public static void setWorktypeFlagsinFeeObject(Entity targetEntity, FeeCalculationObject fcObject, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start: setWorktypeFlagsinFeeObject");
                string[] workTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                if (workTypes.Length > 0)
                {
                    crmTrace.AppendLine("Start:worktype  split successful no of worktypes: " + workTypes.Length);
                    foreach (string workType in workTypes)
                    {
                        switch (workType.ToUpper())
                        {
                            case "BE":
                                {
                                    crmTrace.AppendLine("Boilers Flag True");
                                    fcObject.IsBE = true;
                                    break;
                                }
                            case "MS":
                                {
                                    crmTrace.AppendLine("Mechanical Flag True");
                                    fcObject.IsMS = true;
                                    break;
                                }
                            case "ST":
                                {
                                    crmTrace.AppendLine("Structural Flag True");
                                    fcObject.IsST = true;
                                    break;
                                }
                            case "PL":

                                {
                                    crmTrace.AppendLine("PL Flag True");
                                    fcObject.IsPL = true;
                                    break;
                                }
                            case "SP":

                                {
                                    crmTrace.AppendLine("SP Flag True");
                                    fcObject.IsSP = true;
                                    break;
                                }

                            case "SD":
                                {
                                    crmTrace.AppendLine("SD Flag True");
                                    fcObject.IsSD = true;
                                    break;
                                }
                            case "CC":

                                {
                                    crmTrace.AppendLine("CurbCut Flag True");
                                    fcObject.IsCC = true;
                                    break;
                                }
                            case "AN":

                                {
                                    crmTrace.AppendLine("ANtenna Flag True");
                                    fcObject.IsAN = true;
                                    break;
                                }
                            case "FN":

                                {
                                    crmTrace.AppendLine("FN Flag True");
                                    fcObject.IsFN = true;
                                    break;
                                }
                            case "SH":

                                {
                                    crmTrace.AppendLine("SH Flag True");
                                    fcObject.IsSH = true;
                                    break;
                                }
                            case "SF":

                                {
                                    crmTrace.AppendLine("SF Flag True");
                                    fcObject.IsSF = true;
                                    break;
                                }
                            case "SG":

                                {
                                    crmTrace.AppendLine("signs Flag True");
                                    fcObject.IsSG = true;
                                    break;
                                }
                            case "PA":

                                {
                                    crmTrace.AppendLine("PA Flag True");
                                    fcObject.IsPA = true;
                                    break;
                                }
                            case "TPA":
                            case "TA":

                                {
                                    crmTrace.AppendLine("signs Flag True");
                                    fcObject.IsTPA = true;
                                    break;
                                }
                            case "EL":

                                {
                                    crmTrace.AppendLine("Electrical Flag True");
                                    fcObject.IsEL = true;
                                    break;
                                }
                            case "GC":

                                {
                                    crmTrace.AppendLine("GC Flag True");
                                    fcObject.IsGC = true;
                                    break;
                                }
                        }


                    }
                }



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setWorktypeFlagsinFeeObject", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }

        /// <summary>
        /// This Method is used to calculte fees for all worktypes and set the basic fee fields in jobfiling
        /// 
        /// add any special fee ralated fields for different work types in fee object eg:(TPA Late Fees)
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="fcObject"></param>
        public static void CalculateFeeStandarization(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, FeeCalculationObject fcObject)
        {
            try
            {


                #region Calculate NB fee--Filng Fee,Legalization Fee,SubSequent Fee,PAA Fee,NoGood Check Fee,Conjution Fee

                checkFeeRelatedFalgs(service, crmTrace, targetEntity, preImage, fcObject);

                #region separate Blocks for each worktype

                #region BE worktype
                if (fcObject.IsBE)
                {
                    BoilersBuild_FeeCalculation(service, targetEntity, preImage, crmTrace, fcObject);
                }
                #endregion

                #region MS  ST PL SP SD AN worktype
                else if (fcObject.IsMS || fcObject.IsST || fcObject.IsSP || fcObject.IsPL || fcObject.IsSD || fcObject.IsAN || fcObject.IsGC)
                {
                    crmTrace.AppendLine("MS ST PL SP SD  Work Type fee calculations");
                    MSBuild_FeeCalculation(service, targetEntity, preImage, crmTrace, fcObject);
                }
                #endregion

                #region CC

                else if (fcObject.IsCC)
                {
                    crmTrace.AppendLine("CC Worktype fee calculations");
                    CCBuild_FeeCalculation(service, targetEntity, preImage, crmTrace, fcObject);
                }
                #endregion

                #endregion

                setBasicFeesRelatedtoFalgs(service, crmTrace, targetEntity, preImage, fcObject);

                #endregion

                #region Set AmoutDue,FilingFee,TotalFee,LegalizationFee,PAAFee,ConjuctionFee,RMFee,NoGoodCheckFee

                #region Set Retrieved Object Values

                crmTrace.AppendLine("Entered LegalizationFilingFee block ");
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.LegalizationFilingFee, new Money(fcObject.LegalizationFilingFees));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NewWorkFilingFee, new Money(fcObject.BEMSSTFilingfee));  // set the other filing fee to zero.

                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(fcObject.TotalFees));
                //  CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(feeObject.AssociatedjobFee));
                //  CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(existingamountPaid));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.RecordManagementFee, new Money(fcObject.RecordManagementFees));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.NoGoodCheckFee, new Money(fcObject.NoGoodCheckFee));
                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.PAAFee, new Money(fcObject.PAAFees));
                crmTrace.AppendLine("fcObject.PAAFees : " + fcObject.PAAFees);
                crmTrace.AppendLine("if total filing fee is less that amount paid");

                if (fcObject.TotalFees < fcObject.ExistingAmountPaid)
                {

                    /// special logic for PAA 
                    /// 1) if PAA is not fee xempt and no fee is paid on PAA then there will not be adjustment we have to charge $100 as amount due and refund = Paafee+refund
                    /// 
                    #region PAA Special Scenario- Adjustment 
                    if (!isPostedPaymentHistories(service, crmTrace, targetEntity) && fcObject.IsPAA) //user not paid anything,PAA and there is adjustment
                    {
                        crmTrace.AppendLine("PAA Special Scenario Adjustment");
                        fcObject.Adjustment = (fcObject.ExistingAmountPaid - fcObject.TotalFees);
                        fcObject.Adjustment = fcObject.Adjustment + fcObject.PAAFees;
                        fcObject.amountDue = fcObject.PAAFees;
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(fcObject.amountDue));

                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(fcObject.Adjustment));

                    }
                    #endregion
                    else
                    {
                        crmTrace.AppendLine("Job filing  Entity for Update - Populate Adjustment Amount");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(0));
                        fcObject.amountDue = 0;
                        fcObject.Adjustment = (fcObject.ExistingAmountPaid - fcObject.TotalFees);
                        crmTrace.AppendLine("fcObject.Adjustment :" + fcObject.Adjustment);

                        targetEntity.SetAttributeValue(JobFilingEntityAttributeName.Refund, new Money(fcObject.Adjustment));

                        // CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(fcObject.Adjustment));
                        // using the adjustment fromshared variables


                    }

                }
                else
                {
                    ///Special Logic For PAA
                    ///1)if no fee is paid  on non fee exempt paa and amount due is >=0 and lessthan 100  then update amount due= paa fee and adjustment= paafee-actual amount due
                    ///
                    #region PAA Special Logic
                    if (!isPostedPaymentHistories(service, crmTrace, targetEntity) && fcObject.IsPAA && !fcObject.IsFeeExempt && fcObject.amountDue < fcObject.PAAFees) //user not paid any amount on paa , paa is non fee exempt,AD<paafee
                    {
                        crmTrace.AppendLine("PAA Special Scenario Amount due less tahn 100");
                        fcObject.Adjustment = fcObject.PAAFees - fcObject.amountDue;
                        fcObject.amountDue = fcObject.PAAFees;
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(fcObject.amountDue));

                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(fcObject.Adjustment));

                    }
                    #endregion
                    else
                    {
                        crmTrace.AppendLine("Job filing FAB4 Entity for Update - Populate Amount Due" + fcObject.amountDue);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountDue, new Money(fcObject.amountDue));
                        fcObject.Adjustment = 0;
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(fcObject.Adjustment));

                    }

                }



                if (fcObject.IsConjunction)
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(fcObject.InConjunctionFee));
                    crmTrace.AppendLine("ForTransaction history creation purposes assigning inconjunction fee to bemestfee and make inconjunction fee zero");
                    fcObject.BEMSSTFilingfee = fcObject.InConjunctionFee;
                    fcObject.InConjunctionFee = 0;
                }
                else
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.InConjunctionFee, new Money(0));
                    fcObject.InConjunctionFee = 0;
                }




                #endregion



                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - CalculateFeeNewBuildings", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }


        /// <summary>
        /// set all fe related flags such as feeexempt,incinjunction,legalization,PAA 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="fcObject"></param>
        public static void checkFeeRelatedFalgs(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, FeeCalculationObject fcObject)
        {
            try
            {
                bool isRequiredtomeetNB = false;

                #region feeexempt
                crmTrace.AppendLine("feeexempt based on owner type");
                fcObject.OwnerType = targetEntity.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement) && targetEntity[JobFilingEntityAttributeName.OwnerTypePW1Statement] != null ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value : preImage.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement) && preImage[JobFilingEntityAttributeName.OwnerTypePW1Statement] != null ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value : 0;
                //bool nonProfit = targetEntity.Contains(JobFilingEntityAttributeName.NonProfitFlag) && targetEntity[JobFilingEntityAttributeName.NonProfitFlag] != null ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NonProfitFlag) : preImage.Contains(JobFilingEntityAttributeName.NonProfitFlag) && preImage[JobFilingEntityAttributeName.NonProfitFlag] != null ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.NonProfitFlag) : false;

                // throw new Exception("nonProfit" + nonProfit);
                if (fcObject.OwnerType == (int)OwnerTypeJobFiling.SCA || fcObject.OwnerType == (int)OwnerTypeJobFiling.NYCAgency || fcObject.OwnerType == (int)OwnerTypeJobFiling.OtherGovernment || fcObject.OwnerType == (int)OwnerTypeJobFiling.SpecifNYCHAHHCicUser || fcObject.OwnerType == (int)OwnerTypeJobFiling.NonProfit) //for individual and null value considering not fee exempt
                {
                    crmTrace.AppendLine(" not a feeexempt ");
                    fcObject.IsFeeExempt = true;
                }
                else
                {
                    crmTrace.AppendLine("  feeexempt ");
                    fcObject.IsFeeExempt = false;
                }

                crmTrace.AppendLine("feeexempt " + fcObject.IsFeeExempt);
                #endregion


                #region inconjunction
                crmTrace.AppendLine("inconjunction");
                fcObject.IsConjunction = targetEntity.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && targetEntity[JobFilingEntityAttributeName.IsConjunctionJob] != null ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) : preImage.Contains(JobFilingEntityAttributeName.IsConjunctionJob) && preImage[JobFilingEntityAttributeName.IsConjunctionJob] != null ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob) : false;
                crmTrace.AppendLine("inconjunction " + fcObject.IsConjunction);
                #endregion

                #region legalization
                crmTrace.AppendLine("legalization ");
                fcObject.IsLegalization = (targetEntity.Contains(JobFilingEntityAttributeName.JobType) && targetEntity[JobFilingEntityAttributeName.JobType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobType).Value == (int)JobType.Legal) ? true : false;
                crmTrace.AppendLine("legalization " + fcObject.IsLegalization);
                #endregion

                #region PAA

                fcObject.IsPAA = (targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity[JobFilingEntityAttributeName.FilingTypeAttributeName] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA) ? true : (preImage.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && preImage[JobFilingEntityAttributeName.FilingTypeAttributeName] != null && preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA) ? true : false;
                crmTrace.AppendLine("fcObject.IsPAA  " + fcObject.IsPAA);
                #endregion


                #region jobStatus used only for loc initiated
                fcObject.JobStatus = targetEntity.Contains(JobFilingEntityAttributeName.JobStatus) && targetEntity[JobFilingEntityAttributeName.JobStatus] != null ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value : preImage.Contains(JobFilingEntityAttributeName.JobStatus) && preImage[JobFilingEntityAttributeName.JobStatus] != null ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value : 0;
                crmTrace.AppendLine("fcObject.JobStatus " + fcObject.JobStatus);
                #endregion

                #region FilingTypeAttributeName
                crmTrace.AppendLine("Filing Type");
                if (targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.IF)
                {
                    crmTrace.AppendLine("Filing Type initial");
                    fcObject.FilingType = (int)FilingTypes.IF;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                {
                    crmTrace.AppendLine("Filing Type PAA");
                    fcObject.FilingType = (int)FilingTypes.PA;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF))
                {
                    crmTrace.AppendLine("Filing Type Subsequent");
                    fcObject.FilingType = (int)FilingTypes.SF;
                }
                #endregion

                #region Job Type
                fcObject.jobType = (targetEntity.Contains(JobFilingEntityAttributeName.JobTypeMultiStake) && targetEntity[JobFilingEntityAttributeName.JobTypeMultiStake] != null) ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value : (preImage.Contains(JobFilingEntityAttributeName.JobTypeMultiStake) && preImage[JobFilingEntityAttributeName.JobTypeMultiStake] != null) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value : 0;
                crmTrace.AppendLine(" fcObject.jobType  " + fcObject.jobType);
                #endregion

                #region AlterationCofo-Big Alt
                isRequiredtomeetNB = targetEntity.Contains(JobFilingEntityAttributeName.RequiredtomeetNewBuilding) && targetEntity[JobFilingEntityAttributeName.RequiredtomeetNewBuilding] != null ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.RequiredtomeetNewBuilding) : preImage.Contains(JobFilingEntityAttributeName.RequiredtomeetNewBuilding) && preImage[JobFilingEntityAttributeName.RequiredtomeetNewBuilding] != null ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.RequiredtomeetNewBuilding) : false;
                fcObject.isAlterationCofoBigAlt = (fcObject.jobType == (int)ActualjobType.AlterationCofo && isRequiredtomeetNB) ? true : false;
                crmTrace.AppendLine("  fcObject.isAlterationCofoBigAlt  " + fcObject.isAlterationCofoBigAlt);
                #endregion




            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - checkFeeRelatedFalgs", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }



        public static string BoilerNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int borough, int occupancyType)
        {
            string TrackingNumberFormatted = string.Empty;
            try
            {
                decimal AutoNumber = 0;

                int PaddingNumber = 0;
                char ElevatorsPaddingChar = 'X';
                string trackingNumber = "{0}{1}{2}{3}"; //{borough}{10digitnumber}{occupancytype}{ 4 digit serialNumber hardcoded to 1111}

                // Get Current counter Value
                Entity response = GetBoilerDeviceIdConfig(service, targetEntity, BoilerMasterDevice.EntityLogicalName, crmTrace);

                if (response != null && response.Contains(AutoNumberEntityAttribute.FacadesCounter) && response.Contains(AutoNumberEntityAttribute.FacadesPaddingNumber) && response.Contains(AutoNumberEntityAttribute.FacadesPaddingCharacter))
                {
                    AutoNumber = response.GetAttributeValue<decimal>(AutoNumberEntityAttribute.FacadesCounter);
                    crmTrace.AppendLine("facadesAutoNumber" + AutoNumber);
                    PaddingNumber = Convert.ToInt32(response.GetAttributeValue<string>(AutoNumberEntityAttribute.FacadesPaddingNumber));
                    crmTrace.AppendLine("facadesPaddingNumber" + PaddingNumber);
                    ElevatorsPaddingChar = char.Parse(response.Attributes[AutoNumberEntityAttribute.FacadesPaddingCharacter].ToString());
                    crmTrace.AppendLine("facadesPaddingChar" + ElevatorsPaddingChar);
                }

                TrackingNumberFormatted = String.Format(trackingNumber, borough, Math.Round(AutoNumber, 0).ToString().PadLeft(PaddingNumber, ElevatorsPaddingChar), (occupancyType == 2) ? "N" : "Y", "1111");

                UpdateCounter(service, AutoNumber, response);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }

            return TrackingNumberFormatted;
        }


        /// <summary>
        /// This Function is used to generate boiler master device number based on borough and occupancy type
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="borough"></param>
        /// <param name="BoilerDevice"></param>
        /// <returns></returns>
        public static string GenerateBoilerDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int borough, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType)
        {
            //here target entity is rolling or moving device type
            string TrackingNumberFormatted = string.Empty;
            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");

            try
            {


                // Set Tracking Number format


                TrackingNumberFormatted = BoilerNumber(service, targetEntity, crmTrace, borough, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.OccupancyType).Value);


                if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation)
                {
                    crmTrace.AppendLine("In New Installation Fill the Boiler Device Number with newly generated number");

                    CommonPluginLibrary.SetAttributeValue(BoilerDevice, BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber, TrackingNumberFormatted);
                    CommonPluginLibrary.SetAttributeValue(BoilerDevice, BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber, TrackingNumberFormatted);//requested by haritha 

                }

                crmTrace.AppendLine("Setting Name to NYC Device ID");
                CommonPluginLibrary.SetAttributeValue(BoilerDevice, BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute, TrackingNumberFormatted);

                if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement)
                {
                    crmTrace.AppendLine("In Replacement Fill the tracking number with newly generated number"); //In replacement we have to show both old and new boiler numbers so storing it in tracking number

                    crmTrace.AppendLine("In replacement we have to show both old and new boiler numbers so storing it in tracking number");
                    CommonPluginLibrary.SetAttributeValue(BoilerDevice, BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber, TrackingNumberFormatted);
                }

                //Set the Device Status to Work in Progress only for New Installation


                crmTrace.AppendLine("GenerateNycDeviceNumber Number Ended");



                // Update Auto Number counter value by 1





                return TrackingNumberFormatted;
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return TrackingNumberFormatted;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TrackingNumberFormatted;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GenerateBoilerDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TrackingNumberFormatted;
            }
            #endregion
        }



        /// <summary>
        /// This Function is the main method that gets called when boiler is permit issued
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="scopeType">represents boiler ,fb,fs</param>
        /// 
        /// <returns></returns>
        public static void BoilerMainMethod(IOrganizationService serviceConnector, Entity preTargetEntity, StringBuilder customTrace, int scopeType)
        {

            customTrace.AppendLine("Entered BoilerMainMethod method");
            int ScopeOfWSorkType = 0;

            try
            {

                EntityCollection BoilerScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(serviceConnector, preTargetEntity, customTrace);
                if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0 && BoilerScopeOfWorkCollection.Entities[0][BEScopeOfWorkEntityAttribute.ScopeOfWSorkType] != null)
                {

                    ScopeOfWSorkType = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ScopeOfWSorkType).Value;
                    customTrace.AppendLine("ScopeOfWSorkType " + ScopeOfWSorkType);
                }

                if (scopeType > 0 && ScopeOfWSorkType > 0)
                {

                    BoilerMainMethodHelper(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, scopeType, ScopeOfWSorkType);
                    #region sync Scope of work fields PAA records
                    // Get all PAA records which are not approved and Scope of work fields.
                    EntityCollection PAARecords = FeeCalculationStandardizationHandler.GetPAARecordforJobFiling(serviceConnector, preTargetEntity, customTrace);
                    if (PAARecords != null && PAARecords.Entities.Count > 0)
                    {

                        customTrace.AppendLine("PAA Records" + PAARecords.Entities.Count.ToString());
                        //get all boiler devices for the PAA
                        foreach (Entity PAARecord in PAARecords.Entities)
                        {
                            EntityCollection PAABoilerScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(serviceConnector, PAARecord, customTrace);
                            if (PAABoilerScopeOfWorkCollection.Entities.Count > 0)
                            {
                                Entity SOWBE = new Entity(BEScopeOfWorkEntityAttribute.EntityLogicalName);
                                if (BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.BoilerNames) && BoilerScopeOfWorkCollection.Entities[0].Attributes[BEScopeOfWorkEntityAttribute.BoilerNames] != null)
                                {
                                    SOWBE.Attributes.Add(BEScopeOfWorkEntityAttribute.BoilerNames, BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.BoilerNames));
                                }
                                if (BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.existingBoilerNumbers) && BoilerScopeOfWorkCollection.Entities[0].Attributes[BEScopeOfWorkEntityAttribute.existingBoilerNumbers] != null)
                                {
                                    SOWBE.Attributes.Add(BEScopeOfWorkEntityAttribute.existingBoilerNumbers, BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.existingBoilerNumbers));
                                }
                                if (BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers) && BoilerScopeOfWorkCollection.Entities[0].Attributes[BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers] != null)
                                {
                                    SOWBE.Attributes.Add(BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers, BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers));
                                }
                                SOWBE.Id = PAABoilerScopeOfWorkCollection.Entities[0].Id;
                                serviceConnector.Update(SOWBE);
                            }
                        }
                        #endregion

                    }
                }

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }





        /// <summary>
        /// This Function is the main method that gets called when boiler I1,S1 Application is Approved to update existing boiler details on master
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="scopeType">represents boiler ,fb,fs</param>
        /// 
        /// <returns></returns>
        public static void BoilerExistingDeviceMainMethod(IOrganizationService serviceConnector, Entity preTargetEntity, StringBuilder customTrace, int scopeType)
        {

            customTrace.AppendLine("Entered BoilerExistingDeviceMainMethod method");
            int ScopeOfWSorkType = 0;

            try
            {

                EntityCollection BoilerScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(serviceConnector, preTargetEntity, customTrace);
                if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0 && BoilerScopeOfWorkCollection.Entities[0][BEScopeOfWorkEntityAttribute.ScopeOfWSorkType] != null)
                {

                    ScopeOfWSorkType = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ScopeOfWSorkType).Value;
                    customTrace.AppendLine("ScopeOfWSorkType " + ScopeOfWSorkType);
                }

                if (scopeType > 0 && ScopeOfWSorkType > 0)
                {

                    ExistingBoilerMainMethodHelper(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, scopeType, ScopeOfWSorkType);

                }





            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerExistingDeviceMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }











        public static void BoilerPAAMainMethod(IOrganizationService serviceConnector, Entity preTargetEntity, Guid parentJobGuid, StringBuilder customTrace)
        {

            customTrace.AppendLine("Entered BoilerMainMethod method");
            int ScopeOfWSorkType = 0;
            int scopeType = 0;
            try
            {

                Entity parentJobFiling = Retrieve(serviceConnector, new string[] { JobFilingEntityAttributeName.CurrentFilingStatusAttributeName, JobFilingEntityAttributeName.BEScopeIncludesBL }, parentJobGuid, JobFilingEntityAttributeName.EntityLogicalName);
                //allow only if I1 is permit issued and permit entire
                if (parentJobFiling != null && parentJobFiling.Id != null && parentJobFiling.Contains(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName) && parentJobFiling[JobFilingEntityAttributeName.CurrentFilingStatusAttributeName] != null && (parentJobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PermitEntire || parentJobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PermitIssued))
                {

                    EntityCollection BoilerScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(serviceConnector, preTargetEntity, customTrace);
                    if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0 && BoilerScopeOfWorkCollection.Entities[0][BEScopeOfWorkEntityAttribute.ScopeOfWSorkType] != null)
                    {

                        ScopeOfWSorkType = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ScopeOfWSorkType).Value;
                        customTrace.AppendLine("ScopeOfWSorkType " + ScopeOfWSorkType);
                    }
                    scopeType = parentJobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value;
                    customTrace.AppendLine("scopeType " + scopeType);

                    if (scopeType > 0 && ScopeOfWSorkType > 0)
                    {
                        BoilerPaaMainMethodHelper(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, scopeType, ScopeOfWSorkType);

                    }


                }






            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPAAMainMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }




        /// <summary>
        /// Get the Boiler Scope of work Details from jobfiling
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="customTrace"></param>
        /// <returns></returns>
        public static EntityCollection getBoilerScopeOfWorkDetailsFromJF(IOrganizationService serviceConnector, Entity preTargetEntity, StringBuilder customTrace)
        {
            ConditionExpression transactionCodeCondition = CreateConditionExpression(BEScopeOfWorkEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { preTargetEntity.Id.ToString() });
            EntityCollection BoilerScopeOfWorkCollection = RetrieveMultiple(serviceConnector, BEScopeOfWorkEntityAttribute.EntityLogicalName, new string[] {
                                                      BEScopeOfWorkEntityAttribute.BoilerScope,BEScopeOfWorkEntityAttribute.FBScope,BEScopeOfWorkEntityAttribute.FSScope,BEScopeOfWorkEntityAttribute.ExistingEnergySource, BEScopeOfWorkEntityAttribute.ScopeOfWSorkType,BEScopeOfWorkEntityAttribute.FSScope,BEScopeOfWorkEntityAttribute.BoilerEnergySource,BEScopeOfWorkEntityAttribute.NoDeviceFound,BEScopeOfWorkEntityAttribute.FuelstorageApplianceConnected,BEScopeOfWorkEntityAttribute.BoilerNames,BEScopeOfWorkEntityAttribute.existingBoilerNumbers,BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And, BEScopeOfWorkEntityAttribute.CreatedOn, OrderType.Descending, 1);
            return BoilerScopeOfWorkCollection;
        }
        /// <summary>
        /// Based on existing or proposed retreive the details
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="BoilerScopeOfWorkCollection"></param>
        /// <param name="customTrace"></param>
        /// <param name="existingorProposed"></param>
        /// <returns></returns>
        public static EntityCollection getBoilerBuildDeviceDetailsFromScopeOfWork(IOrganizationService serviceConnector, Entity preTargetEntity, EntityCollection BoilerScopeOfWorkCollection, StringBuilder customTrace, int existingorProposed)
        {
            EntityCollection BoilerBuildDevices = new EntityCollection();
            if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0)
            {
                customTrace.AppendLine("3)Loop through all devices and create a number");



                ConditionExpression transactionCodeCondition = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerScopeofworkid, ConditionOperator.Equal, new string[] { BoilerScopeOfWorkCollection.Entities[0].Id.ToString() });
                ConditionExpression transactionCodeCondition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet, ConditionOperator.Equal, existingorProposed);
                BoilerBuildDevices = RetrieveMultiple(serviceConnector, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] {

                    BoilerBuildDeviceDetailsEntityAttribute.BoilerRating,BoilerBuildDeviceDetailsEntityAttribute.ProposedBoilerType,BoilerBuildDeviceDetailsEntityAttribute.MaximumAllowableWorkingPressure,BoilerBuildDeviceDetailsEntityAttribute.BoilerClassification,
                    BoilerBuildDeviceDetailsEntityAttribute.NumberOfModules,BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo,BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation,BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing,
                    BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith,BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialOther,BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial,BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther,
                    BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerPendingDetails,BoilerBuildDeviceDetailsEntityAttribute.FBPendingDetails,BoilerBuildDeviceDetailsEntityAttribute.FSPendingDetails,BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource,




                        BoilerBuildDeviceDetailsEntityAttribute.FSComments,BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler,BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner,
                        BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage,BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2,BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber,
                        BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil,BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS, BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank,BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled,
                        BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity,BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway,BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas,
                        BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage,BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName,BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther,
                        BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber,BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN,BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes,
                        BoilerBuildDeviceDetailsEntityAttribute.BoilerInputCapacity,BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner,BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber,BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute,
                        BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment,BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName,BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting, BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity,BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign, BoilerBuildDeviceDetailsEntityAttribute.BoilerComments,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate,BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour,BoilerBuildDeviceDetailsEntityAttribute.BurnerComments,BoilerBuildDeviceDetailsEntityAttribute.BurnerType,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber,BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber,  BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer, BoilerBuildDeviceDetailsEntityAttribute.OccupancyType,BoilerBuildDeviceDetailsEntityAttribute.SerialNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerModel,
                        BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial,BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor,BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress,BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther,
                        BoilerBuildDeviceDetailsEntityAttribute.BTU,BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer,BoilerBuildDeviceDetailsEntityAttribute.Locatedin,BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup,BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup,
                        BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber,BoilerBuildDeviceDetailsEntityAttribute.Efficiency,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerStatus,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerClassification,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerRating,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerMaxWorkingPressure,
                        BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi,BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther,BoilerBuildDeviceDetailsEntityAttribute.InternalAccess,BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance,BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet,BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup, BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource,BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers,BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber,BoilerBuildDeviceDetailsEntityAttribute.ParentBBD},
                  new ConditionExpression[] { transactionCodeCondition, transactionCodeCondition1 }, LogicalOperator.And);
            }
            return BoilerBuildDevices;
        }


        /// <summary>
        /// Based on existing or proposed retreive the details
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="BoilerScopeOfWorkCollection"></param>
        /// <param name="customTrace"></param>
        /// <param name="existingorProposed"></param>
        /// <returns></returns>
        public static EntityCollection getBoilerBuildDeviceDetailsFromJobfiling(IOrganizationService serviceConnector, Entity PAARecord, Entity BoilerDevice)
        {

            ConditionExpression transactionCodeCondition = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { PAARecord.Id.ToString() });
            ConditionExpression transactionCodeCondition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.ParentBBD, ConditionOperator.Equal, BoilerDevice.Id.ToString());
            EntityCollection PAABoilerBuildDevices = RetrieveMultiple(serviceConnector, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { },
            new ConditionExpression[] { transactionCodeCondition, transactionCodeCondition1 }, LogicalOperator.And);

            return PAABoilerBuildDevices;
        }

        public static EntityCollection getBoilerBuildDeviceDetailsonBoiler(IOrganizationService serviceConnector, Guid BoilerId)
        {

            ConditionExpression Condition = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler, ConditionOperator.Equal, new string[] { BoilerId.ToString() });

            EntityCollection BoilerBuildDevices = RetrieveMultiple(serviceConnector, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { },
            new ConditionExpression[] { Condition }, LogicalOperator.And);

            return BoilerBuildDevices;
        }


        /// <summary>
        /// This function is used to update all FB devices status to void for a given master device
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="BoilerMaster"></param>
        /// <param name="customTrace"></param>
        public static void UpdateFBDevicestoVoid(IOrganizationService serviceConnector, Entity BoilerMaster, StringBuilder customTrace)
        {
            EntityCollection BoilerBuildDevices = new EntityCollection();

            Entity temp = new Entity(FulelBurnerMaster.EntityLogicalName);
            customTrace.AppendLine("3)Loop through all devices and update the status to void");



            ConditionExpression transactionCodeCondition = CreateConditionExpression(FulelBurnerMaster.BoilerMasterLookup, ConditionOperator.Equal, new string[] { BoilerMaster.Id.ToString() });

            BoilerBuildDevices = RetrieveMultiple(serviceConnector, FulelBurnerMaster.EntityLogicalName, new string[] {

                    FulelBurnerMaster.EntityNameAttribute},
              new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

            if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
            {
                customTrace.AppendLine("Updation of devices start");
                foreach (Entity FuelBurner in BoilerBuildDevices.Entities)
                {
                    temp = new Entity(FulelBurnerMaster.EntityLogicalName);
                    temp.SetAttributeValue(FulelBurnerMaster.FuelBurnerStatus, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));
                    temp.Id = FuelBurner.Id;
                    serviceConnector.Update(temp);
                }
                customTrace.AppendLine("Updation of devices End");
            }


        }


        /// <summary>
        /// This function is used to update all FS devices status to void for a given master device
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="BoilerMaster"></param>
        /// <param name="customTrace"></param>
        public static void UpdateFSDevicestoVoid(IOrganizationService serviceConnector, Entity BoilerMaster, StringBuilder customTrace)
        {
            EntityCollection BoilerBuildDevices = new EntityCollection();

            Entity temp = new Entity(FulelStorageMaster.EntityLogicalName);
            customTrace.AppendLine("3)Loop through all devices and update the status to void");



            ConditionExpression transactionCodeCondition = CreateConditionExpression(FulelStorageMaster.BoilerMasterLookup, ConditionOperator.Equal, new string[] { BoilerMaster.Id.ToString() });

            BoilerBuildDevices = RetrieveMultiple(serviceConnector, FulelStorageMaster.EntityLogicalName, new string[] {

                    FulelBurnerMaster.EntityNameAttribute},
              new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

            if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
            {
                customTrace.AppendLine("Updation of devices start");
                foreach (Entity FuelStorage in BoilerBuildDevices.Entities)
                {
                    temp = new Entity(FulelStorageMaster.EntityLogicalName);
                    temp.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));
                    temp.Id = FuelStorage.Id;
                    serviceConnector.Update(temp);
                }
                customTrace.AppendLine("Updation of devices End");
            }


        }







        /// <summary>
        /// This Function is the main Business Logic for Boiler work type -permit entire
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="crmTrace"></param>
        /// 
        /// 
        /// <returns></returns>
        public static void BoilerMainMethodHelper(IOrganizationService serviceConnector, Entity preTargetEntity, EntityCollection BoilerScopeOfWorkCollection, StringBuilder customTrace, int scopeType, int ScopeOfWSorkType)
        {

            customTrace.AppendLine("Entered BoilerMainMethod method");
            Entity BeScope = new Entity();
            string tempNumber = string.Empty;
            string commaSeparatedNumber = string.Empty;
            string commaSeparatedNewBoilerNumber = string.Empty;
            String Associateddevicenumber = string.Empty;

            try
            {

                if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0)
                {


                    customTrace.AppendLine("3)Loop through all devices and create a number");
                    EntityCollection BoilerBuildDevices = getBoilerBuildDeviceDetailsFromScopeOfWork(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, (int)ExistingProposedOptionSet.Proposed); // On Permit Entire get only the Proposed Devices
                    if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
                    {
                        customTrace.AppendLine("4)Call Number Generation Method for each boiler new device and create new master Boiler Device");

                        foreach (Entity BoilerDevice in BoilerBuildDevices.Entities)
                        {
                            int existingnergysource = 0;
                            EntityCollection ExistingDeviceCollection = new EntityCollection();
                            Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

                            if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup] != null)
                            {
                                customTrace.AppendLine("test");
                                Guid Existingdevideid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup).Id;
                                ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId, ConditionOperator.Equal, Existingdevideid.ToString());
                                ExistingDeviceCollection = RetrieveMultiple(serviceConnector, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
                                customTrace.AppendLine("test1");
                            }
                            if (ExistingDeviceCollection != null && ExistingDeviceCollection.Entities.Count > 0)
                            {
                                existing = ExistingDeviceCollection.Entities[0];
                                if (ExistingDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource))
                                {
                                    customTrace.AppendLine("test3");
                                    existingnergysource = ExistingDeviceCollection.Entities[0].GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;
                                    customTrace.AppendLine("test4");
                                }
                            }
                            else

                            {

                                existing = BoilerDevice;
                            }


                            if (shouldCreateAnyNewDevice(scopeType, ScopeOfWSorkType, BoilerDevice))
                            {
                                if (shouldCreateNewBoilerDevice(scopeType, ScopeOfWSorkType)) //Number Generation should only trigger for Boiler Device creation only
                                {
                                    customTrace.AppendLine("5)Create New Device and new number");
                                    tempNumber = GenerateBoilerDeviceNumber(serviceConnector, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName).Value, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType);

                                }
                                else
                                {
                                    tempNumber = BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute] != null ? BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) : string.Empty;
                                }

                                customTrace.AppendLine("Creation of new boiler device started");
                                CreateBoilerMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, string.IsNullOrEmpty(tempNumber) ? (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber] != null ? BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber) : string.Empty) : tempNumber, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType, BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null ? BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id : new Guid());

                            }
                            else
                            {

                                customTrace.AppendLine("5)Update the Device based on existing Number");
                                UpdateBoilerMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType, existingnergysource);
                                tempNumber = BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute] != null ? BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) : string.Empty;
                                if (tempNumber.Length < 16)
                                {
                                    if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber))
                                    {
                                        tempNumber = BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                    }
                                }
                            }
                            if (tempNumber.Length >= 16)
                            {
                                #region frame comma separated name
                                if (commaSeparatedNumber == string.Empty)
                                {
                                    commaSeparatedNumber = tempNumber;
                                    if (scopeType != (int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification)
                                    {
                                        commaSeparatedNewBoilerNumber = BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                        commaSeparatedNumber = "";
                                    }


                                    if (scopeType == (int)BoilerScopeIncludes.Boiler && (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement))
                                    {
                                        commaSeparatedNewBoilerNumber = BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                    }

                                }
                                else
                                {
                                    commaSeparatedNumber = commaSeparatedNumber + "," + tempNumber;
                                    if (scopeType != (int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification)
                                    {
                                        commaSeparatedNewBoilerNumber = commaSeparatedNewBoilerNumber + "," + BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                        commaSeparatedNumber = "";
                                    }

                                    if (scopeType == (int)BoilerScopeIncludes.Boiler && (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement))
                                    {
                                        commaSeparatedNewBoilerNumber = commaSeparatedNewBoilerNumber + "," + BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                    }

                                }
                            }

                            #endregion

                            #region Associated boiler devices comma separated
                            ConditionExpression condition2 = new ConditionExpression("dobnyc_abd_boilerbuilddevicedetails", ConditionOperator.Equal, BoilerDevice.Id.ToString());
                            EntityCollection AssociatedDevices = RetrieveMultiple(serviceConnector, "dobnyc_associatedboilerdevices", new string[] { }, new ConditionExpression[] { condition2 }, LogicalOperator.And);
                            if (AssociatedDevices != null && AssociatedDevices.Entities.Count > 0)
                            {

                                foreach (Entity AssociatedDevice in AssociatedDevices.Entities)
                                {
                                    string Devicenumber = AssociatedDevice.GetAttributeValue<string>("dobnyc_name");
                                    if (Associateddevicenumber == string.Empty)
                                    {
                                        Associateddevicenumber = Devicenumber;
                                    }
                                    else
                                    {
                                        Associateddevicenumber = Associateddevicenumber + "," + Devicenumber;
                                    }

                                }
                            }
                            #endregion

                            #region sync PAA records
                            // Get all PAA records which are not approved and update the Devicenumber and lookup fields.
                            EntityCollection PAARecords = FeeCalculationStandardizationHandler.GetPAARecordforJobFiling(serviceConnector, preTargetEntity, customTrace);
                            if (PAARecords != null && PAARecords.Entities.Count > 0)
                            {

                                customTrace.AppendLine("PAA Records" + PAARecords.Entities.Count.ToString());
                                //get all boiler devices for the PAA
                                foreach (Entity PAARecord in PAARecords.Entities)
                                {
                                    //Retrieve Device Details of PAA for this parent BBD.
                                    EntityCollection PAABoilerBuildDevices = getBoilerBuildDeviceDetailsFromJobfiling(serviceConnector, PAARecord, BoilerDevice); // Proposed PAA device
                                    if (PAABoilerBuildDevices.Entities.Count > 0)
                                    {
                                        customTrace.AppendLine("PAA PAABoilerBuildDevices" + PAABoilerBuildDevices.Entities.Count.ToString());
                                        Entity BBD = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber));
                                        }
                                        if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) && BoilerDevice.Attributes[BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute] != null)
                                        {
                                            BBD.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute));
                                        }
                                        BBD.Id = PAABoilerBuildDevices.Entities[0].Id;
                                        serviceConnector.Update(BBD);
                                    }
                                }
                            }
                            #endregion

                        }
                        customTrace.AppendLine("commaSeparatedNumber : " + commaSeparatedNumber);
                        customTrace.AppendLine("commaSeparatedNewBoilerNumber : " + commaSeparatedNewBoilerNumber);
                    }


                    #region Update commaSeparatedNumber on Scope of Work
                    customTrace.AppendLine("Update commaSeparatedNumber on Scope of Work");

                    BeScope = new Entity(BEScopeOfWorkEntityAttribute.EntityLogicalName);
                    if (commaSeparatedNumber != null && commaSeparatedNumber != string.Empty)
                    {
                        BeScope.Attributes.Add(BEScopeOfWorkEntityAttribute.BoilerNames, commaSeparatedNumber);
                    }
                    if (commaSeparatedNewBoilerNumber != null && commaSeparatedNewBoilerNumber != string.Empty)
                    {
                        BeScope.Attributes.Add(BEScopeOfWorkEntityAttribute.existingBoilerNumbers, commaSeparatedNewBoilerNumber);
                    }
                    if (Associateddevicenumber != null && Associateddevicenumber != string.Empty)
                    {
                        BeScope.Attributes.Add(BEScopeOfWorkEntityAttribute.AssociatedDeviceNumbers, Associateddevicenumber);
                    }

                    BeScope.Id = BoilerScopeOfWorkCollection.Entities[0].Id;
                    serviceConnector.Update(BeScope);
                    customTrace.AppendLine("BeScope updated with  commaSeparatedNumber");

                    #endregion

                }



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }


        /// <summary>
        /// This Function is the main Business Logic for Boiler work type -Approved
        /// Updating boiler device and creating new FB, FS device based on Scope of work scope include checkboxes
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="crmTrace"></param>
        /// 
        /// 
        /// <returns></returns>
        public static void ExistingBoilerMainMethodHelper(IOrganizationService serviceConnector, Entity preTargetEntity, EntityCollection BoilerScopeOfWorkCollection, StringBuilder customTrace, int scopeType, int ScopeOfWSorkType)
        {

            customTrace.AppendLine("Entered ExistingBoilerMainMethodHelper method");
            Entity BeScope = new Entity();
            string tempNumber = string.Empty;
            string commaSeparatedNumber = string.Empty;
            string commaSeparatedNewBoilerNumber = string.Empty;
            BoilerPendingDetails BPD = new BoilerPendingDetails();
            Entity MasterDevice = new Entity();
            Entity BoilerMasterDeviceCollection = new Entity();
            EntityCollection collection = new EntityCollection();
            Guid BoilerMasterDeviceId = new Guid();

            try
            {

                if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0)
                {
                    customTrace.AppendLine("3)Loop through all devices and Update master boiler or cretae new FB ,FS");
                    EntityCollection BoilerBuildDevices = getBoilerBuildDeviceDetailsFromScopeOfWork(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, (int)ExistingProposedOptionSet.Existing); // On Permit Entire get only the Proposed Devices
                    if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
                    {
                        customTrace.AppendLine("4)Call Number Generation Method for each boiler new device and create new master Boiler Device");

                        foreach (Entity BoilerDevice in BoilerBuildDevices.Entities)
                        {

                            int existingnergysource = 0;
                            EntityCollection ExistingDeviceCollection = new EntityCollection();
                            Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);
                            if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource] != null)
                            {
                                existingnergysource = BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;

                            }
                            existing = BoilerDevice;
                            setBoilerPendingFlags(BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], BPD, customTrace); //set the pending falgs and scope flags

                            if (shouldPerformAnyActionOnExistingDevice(scopeType, ScopeOfWSorkType, BPD) || (existingnergysource == 1 || existingnergysource == 4))
                            {

                                #region Update Boiler with existing details

                                customTrace.AppendLine("Updating Existing Boiler Details");
                                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                                {

                                    //get the master device id by using device number then update the required fields.
                                    MasterDevice = new Entity(BoilerMasterDevice.EntityLogicalName);

                                    BoilerMasterDeviceCollection = Retrieve(serviceConnector, new string[] {
                                    BoilerMasterDevice.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);

                                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                                    {
                                        BoilerMasterDeviceId = BoilerMasterDeviceCollection.Id;
                                        if (BPD.BoilerDetailsPending) //Update Boiler Fields only when scope is Boiler
                                        {
                                            customTrace.AppendLine("Boiler device details to Master device - Start This should update only when we receive pass final on permit");
                                            AddBoilerDeviceDetailsToMaster(preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], MasterDevice, ScopeOfWSorkType, existingnergysource);
                                            MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                                            serviceConnector.Update(MasterDevice);


                                        }

                                    }
                                }



                                #endregion

                                #region FB  Existing Details Pending
                                if ((BPD.BoilerDetailsPending && existingnergysource != 3) && BoilerMasterDeviceCollection.Id != null)
                                {
                                    //before creating new FB verify that boiler has any active FB . if present update the FB details else create


                                    MasterDevice = new Entity(FulelBurnerMaster.EntityLogicalName);
                                    collection = shouldCreateNewFBExisting(BoilerMasterDeviceCollection, serviceConnector, customTrace);
                                    if (collection != null && collection.Entities.Count > 0)
                                    {
                                        customTrace.AppendLine("FB Present so update the FB");
                                        customTrace.AppendLine("Fuel burner device details to Master device Burner present- Start");
                                        AddFuelBurnerDeviceDetailsToMaster(preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], MasterDevice, scopeType, ScopeOfWSorkType, existing);
                                        MasterDevice.Id = collection.Entities[0].Id;
                                        serviceConnector.Update(MasterDevice);
                                        customTrace.AppendLine("associate the FB master to existing BBD");
                                        BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, collection.Entities[0].ToEntityReference());

                                    }
                                    else
                                    {
                                        customTrace.AppendLine("Create new FB with FB Existing Details as there is no FB connected to boiler");
                                        customTrace.AppendLine("Fuel burner Not Present in BBD so Create - Start");
                                        CreateFuelBurnerMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, existing);
                                        customTrace.AppendLine("Update the FB lookup on boiler device"); //already set the FB lookup on create method

                                    }

                                    serviceConnector.Update(BoilerDevice);
                                }

                                #endregion

                                #region FS Existing Details Pending
                                if ((existingnergysource == 1 || existingnergysource == 4) || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank || BPD.Nodevicefound)

                                {
                                    customTrace.AppendLine("Create new FS with FS Existing Details ");
                                    customTrace.AppendLine("Fuel Storage device Not Present on BBD Create One FS - Start");
                                    MasterDevice = new Entity(FulelStorageMaster.EntityLogicalName);
                                    collection = new EntityCollection();
                                    if (BoilerMasterDeviceCollection.Id != null)
                                    {
                                        collection = shouldCreateNewFSExisting(BoilerMasterDeviceCollection, serviceConnector, customTrace);
                                    }

                                    if (collection != null && collection.Entities.Count > 0)
                                    {
                                        customTrace.AppendLine("Fuel Storage device exists for the master so update  - Start");
                                        AddFuelStorageDeviceDetailsToMaster(preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], MasterDevice, scopeType, ScopeOfWSorkType, existing);
                                        MasterDevice.Id = collection.Entities[0].Id;
                                        serviceConnector.Update(MasterDevice);
                                        customTrace.AppendLine("associate the Fs master to existing BBD");

                                    }
                                    else
                                    {
                                        if (!BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup))
                                        {
                                            customTrace.AppendLine("Create new FS with FS Existing Details ");
                                            customTrace.AppendLine("Fuel Storage device Not Present on BBD Create One FS - Start");

                                            CreateFuelStorageMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, existing);
                                            customTrace.AppendLine("Update the Fs lookup on boiler device"); //already set the Fs lookup on create method
                                        }

                                    }

                                    serviceConnector.Update(BoilerDevice);

                                }
                                #endregion


                            }


                            #region Update FB FS Proposed Device Lookups with Existing FB FS Lookups

                            updateFBFSLookupsOnProposedDevice(BoilerDevice, serviceConnector, customTrace);

                            #endregion
                            int FuelstorageApplianceConnected = 0;

                            if (BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.FuelstorageApplianceConnected))
                            {
                                FuelstorageApplianceConnected = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.FuelstorageApplianceConnected).Value;
                            }
                            if ((ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank) || (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank) && FuelstorageApplianceConnected == 1)
                            {
                                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber))
                                {
                                    tempNumber = BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber);
                                }


                                if (commaSeparatedNumber == string.Empty)
                                {
                                    commaSeparatedNumber = tempNumber;

                                }
                                else
                                {
                                    commaSeparatedNumber = commaSeparatedNumber + "," + tempNumber;

                                }
                                #region Update commaSeparatedNumber on Scope of Work
                                customTrace.AppendLine("Update commaSeparatedNumber on Scope of Work");
                                if (commaSeparatedNumber != string.Empty)
                                {
                                    BeScope = new Entity(BEScopeOfWorkEntityAttribute.EntityLogicalName);
                                    BeScope.Attributes.Add(BEScopeOfWorkEntityAttribute.existingBoilerNumbers, commaSeparatedNumber);
                                    BeScope.Id = BoilerScopeOfWorkCollection.Entities[0].Id;
                                    serviceConnector.Update(BeScope);
                                    customTrace.AppendLine("BeScope updated with  commaSeparatedNumber");

                                }
                                #endregion

                            }


                        }

                    }




                }



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - ExistingBoilerMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }



        public static void BoilerPaaMainMethodHelper(IOrganizationService serviceConnector, Entity preTargetEntity, EntityCollection BoilerScopeOfWorkCollection, StringBuilder customTrace, int scopeType, int ScopeOfWSorkType)
        {

            customTrace.AppendLine("Entered BoilerPaaMainMethodHelper method");
            Entity BeScope = new Entity();
            string tempNumber = string.Empty;
            string commaSeparatedNumber = string.Empty;
            string commaSeparatedNewBoilerNumber = string.Empty;

            try
            {

                if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0)
                {
                    customTrace.AppendLine("3)Loop through all devices and create a number");
                    EntityCollection BoilerBuildDevices = getBoilerBuildDeviceDetailsFromScopeOfWork(serviceConnector, preTargetEntity, BoilerScopeOfWorkCollection, customTrace, (int)ExistingProposedOptionSet.Proposed); //IN PAA always call proposed
                    if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
                    {
                        customTrace.AppendLine("4)Call Number Generation Method for each boiler new device and create new master Boiler Device");

                        foreach (Entity BoilerDevice in BoilerBuildDevices.Entities)
                        {

                            customTrace.AppendLine("5)Update the Device based on existing Number");


                            UpdatePAABoilerMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType);


                        }

                    }




                }



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preTargetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPaaMainMethodHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }



        /// <summary>
        /// This Function will determine whether any new device is being created or not.
        /// </summary>
        /// <param name="scopeType"></param>
        /// <param name="ScopeOfWSorkType"></param>
        /// <param name="BoilerBuildDevice"></param>
        /// <returns></returns>
        public static bool shouldCreateAnyNewDevice(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {

            if (shouldCreateNewBoilerDevice(scopeType, ScopeOfWSorkType) || shouldCreateNewBurnerDevice(scopeType, ScopeOfWSorkType, BoilerBuildDevice) || shouldCreateNewFuelStorageDevice(scopeType, ScopeOfWSorkType, BoilerBuildDevice))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public static void updateFBFSLookupsOnProposedDevice(Entity ExistingBoilerDevice, IOrganizationService serviceConnector, StringBuilder customTrace)
        {
            EntityCollection ProposedDeviceCollection = new EntityCollection();
            Entity Proposed = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);
            try
            {
                //get the proposed device info from existing 
                //then check if proposed has data then do not fill else fill

                ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup, ConditionOperator.Equal, ExistingBoilerDevice.Id.ToString());
                ProposedDeviceCollection = RetrieveMultiple(serviceConnector, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
                if (ProposedDeviceCollection != null && ProposedDeviceCollection.Entities.Count > 0)
                {

                    customTrace.AppendLine("Proposed device found update start");
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null && !ProposedDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup))
                    {
                        customTrace.AppendLine("Proposed device FuelBurnerMasterLookup");
                        Proposed.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, ExistingBoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup));
                    }
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null && !ProposedDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup))
                    {
                        customTrace.AppendLine("Proposed device FuelStorageMasterLookup");
                        Proposed.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup, ExistingBoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup));
                        //Proposed.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber, ExistingBoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Name);
                    }
                    customTrace.AppendLine("Proposed device found update middle");
                    Proposed.Id = ProposedDeviceCollection.Entities[0].Id;
                    serviceConnector.Update(Proposed);
                    customTrace.AppendLine("Proposed device found update End");
                }

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ExistingBoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - updateFBFSLookupsOnProposedDevice", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }


        public static EntityCollection shouldCreateNewFBExisting(Entity MasterBoiler, IOrganizationService serviceConnector, StringBuilder customTrace)
        {
            EntityCollection FBCollection = new EntityCollection();
            try
            {
                ConditionExpression condition1 = new ConditionExpression(FulelBurnerMaster.BoilerMasterLookup, ConditionOperator.Equal, MasterBoiler.Id.ToString());


                FBCollection = RetrieveMultiple(serviceConnector, FulelBurnerMaster.EntityLogicalName, new string[] { FulelBurnerMaster.EntityNameAttribute }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFBExisting", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion



            return FBCollection;
        }

        public static EntityCollection shouldCreateNewFSExisting(Entity MasterBoiler, IOrganizationService serviceConnector, StringBuilder customTrace)
        {
            EntityCollection FSCollection = new EntityCollection();
            try
            {
                ConditionExpression condition1 = new ConditionExpression(FulelStorageMaster.BoilerMasterLookup, ConditionOperator.Equal, MasterBoiler.Id.ToString());
                ConditionExpression condition2 = new ConditionExpression(FulelStorageMaster.FuelStorageStatus, ConditionOperator.NotIn, new object[] { (int)BoilerDeviceStatus.voidRemoved, (int)BoilerDeviceStatus.Removed });

                FSCollection = RetrieveMultiple(serviceConnector, FulelStorageMaster.EntityLogicalName, new string[] { FulelStorageMaster.EntityNameAttribute }, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(MasterBoiler.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - shouldCreateNewFSExisting", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion



            return FSCollection;
        }





        /// <summary>
        /// This Function determines whether to update master device with existing device details or not
        /// </summary>
        /// <param name="scopeType"></param>
        /// <param name="ScopeOfWSorkType"></param>
        /// <param name="BoilerBuildDevice"></param>
        /// <returns></returns>
        public static bool shouldPerformAnyActionOnExistingDevice(int scopeType, int ScopeOfWSorkType, BoilerPendingDetails BPD)
        {
            ///check existing device pending flags if any flag is yes then this function return true



            if (BPD.BoilerDetailsPending || BPD.FBDetailsPending || BPD.FSDetailsPending || BPD.Nodevicefound || BPD.FSScope)
            {

                return true;

            }

            return false;

        }


        public static void setBoilerPendingFlags(Entity BoilerBuildDevice, Entity BoilerScope, BoilerPendingDetails BPD, StringBuilder customTrace)
        {

            BPD.BoilerDetailsPending = BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerPendingDetails) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerPendingDetails] != null ? BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.BoilerPendingDetails) : false;
            customTrace.AppendLine("BPD.BoilerDetailsPending" + BPD.BoilerDetailsPending);
            BPD.FBDetailsPending = BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FBPendingDetails) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.FBPendingDetails] != null ? BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.FBPendingDetails) : false;
            customTrace.AppendLine("BPD.FBDetailsPending" + BPD.FBDetailsPending);
            BPD.FSDetailsPending = BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSPendingDetails) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.FSPendingDetails] != null ? BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.FSPendingDetails) : false;
            customTrace.AppendLine("BPD.FSDetailsPending" + BPD.FSDetailsPending);
            BPD.BoilerScope = BoilerScope.Contains(BEScopeOfWorkEntityAttribute.BoilerScope) && BoilerScope[BEScopeOfWorkEntityAttribute.BoilerScope] != null ? BoilerScope.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.BoilerScope) : false;
            customTrace.AppendLine("BPD.BoilerScope" + BPD.BoilerScope);
            BPD.FBScope = BoilerScope.Contains(BEScopeOfWorkEntityAttribute.FBScope) && BoilerScope[BEScopeOfWorkEntityAttribute.FBScope] != null ? BoilerScope.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FBScope) : false;
            customTrace.AppendLine("BPD.FBScope" + BPD.FBScope);
            BPD.FSScope = BoilerScope.Contains(BEScopeOfWorkEntityAttribute.FSScope) && BoilerScope[BEScopeOfWorkEntityAttribute.FSScope] != null ? BoilerScope.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FSScope) : false;
            customTrace.AppendLine(" BPD.FSScope" + BPD.FSScope);
            BPD.Nodevicefound = BoilerScope.Contains(BEScopeOfWorkEntityAttribute.NoDeviceFound) && BoilerScope[BEScopeOfWorkEntityAttribute.NoDeviceFound] != null ? BoilerScope.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.NoDeviceFound) : false;
            customTrace.AppendLine(" BPD.NoDeviceFound" + BPD.Nodevicefound);




        }







        /// <summary>
        /// This function determines whether should we create Master Boiler device or update the device
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldCreateNewBoilerDevice(int scopeType, int ScopeOfWSorkType)
        {
            if ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) ||
               (scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement))
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This Function determines whether should we create new Burner or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldCreateNewBurnerDevice(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {
            if ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) ||
                (scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement) && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement))
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This Function determines whether should we create new FS or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldCreateNewFuelStorageDevice(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {
            //Fuel Storage is based on two falgs if any one is true we have to create the device
            if ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||
                (scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelStorage && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelStorage && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement))
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This Function determines whether should we create new Burner or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldCreateNewBurnerDevice_Modification(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {
            if ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification) && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) ||

                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification))

            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This Function determines whether should we create new FS or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldCreateNewFuelStorageDevice_Modification(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {
            //Fuel Storage is based on two falgs if any one is true we have to create the device
            if ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||

                (scopeType == (int)(int)BoilerScopeIncludes.FuelBurner && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification) && ((BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage))) ||

                (scopeType == (int)(int)BoilerScopeIncludes.FuelStorage && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification) ||
                (scopeType == (int)(int)BoilerScopeIncludes.FuelStorage && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] == null) || //in abandanded of tank FS not present in our system
                (scopeType == (int)(int)BoilerScopeIncludes.FuelStorage && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] == null) //In removal of tank Fs not present in our system
                )

            {
                return true;

            }
            else
            {
                return false;
            }
        }



        /// <summary>
        /// Update master boiler device based on the new boiler device created in build.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="TrackingNumberFormatted"></param>
        /// <param name="BoilerDevice"></param>
        public static void UpdateBoilerMasterDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType, int existingnergysource)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");
            Entity MasterDevice = new Entity();
            Entity BoilerMasterDeviceCollection = new Entity();
            Guid BoilerMasterDeviceId = new Guid(); // used to capture the boiler Master Id
            try
            {

                EntityCollection ExistingDeviceCollection = new EntityCollection();
                Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup] != null)
                {

                    Guid Existingdevideid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup).Id;
                    ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId, ConditionOperator.Equal, Existingdevideid.ToString());
                    ExistingDeviceCollection = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
                    existing = ExistingDeviceCollection.Entities[0];
                }
                else

                    existing = BoilerDevice;
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                {

                    //get the master device id by using device number then update the required fields.
                    MasterDevice = new Entity(BoilerMasterDevice.EntityLogicalName);

                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        BoilerMasterDevice.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        BoilerMasterDeviceId = BoilerMasterDeviceCollection.Id;
                        if (scopeType == (int)BoilerScopeIncludes.Boiler) //Update Boiler Fields only when scope is Boiler
                        {
                            crmTrace.AppendLine("Boiler device details to Master device - Start This should update only when we receive pass final on permit");
                            //AddBoilerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, ScopeOfWSorkType);
                            //MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                            //service.Update(MasterDevice);


                        }

                    }
                }
                #region Fuel Burner Update
                //if fuel burner lookup is not filled then create the new one
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null)
                {

                    MasterDevice = new Entity(FulelBurnerMaster.EntityLogicalName);

                    crmTrace.AppendLine("Fuel burner Update Details- Start");
                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        FulelBurnerMaster.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup).Id, FulelBurnerMaster.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        //crmTrace.AppendLine("Fuel burner device details to Master device Burner present- Start");
                        //AddFuelBurnerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, existing);
                        //MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                        //service.Update(MasterDevice);

                    }

                }

                else
                {

                    if (shouldCreateNewBurnerDevice_Modification(scopeType, ScopeOfWSorkType, BoilerDevice)) //create only if one of the conditions met
                    {
                        crmTrace.AppendLine("Fuel burner Not Present in BBD so Create - Start");
                        if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FBScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FBScope) == true)
                        {
                            CreateFuelBurnerMasterDeviceNumber(service, targetEntity, crmTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, BoilerDevice);
                        }
                        else
                        {
                            CreateFuelBurnerMasterDeviceNumber(service, targetEntity, crmTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, existing);
                        }
                        crmTrace.AppendLine("Update the FB lookup on boiler device"); //already set the FB lookup on create method
                        service.Update(BoilerDevice);
                    }

                }
                #endregion
                #region Fuel Storage Update
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                {

                    MasterDevice = new Entity(FulelStorageMaster.EntityLogicalName);
                    crmTrace.AppendLine("Fuel Storage Update Details- Start");

                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        FulelStorageMaster.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Id, FulelStorageMaster.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        //if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank)
                        //{
                        //    crmTrace.AppendLine("Fuel Storage SOW Removaloftank");
                        //    MasterDevice.Attributes.Add(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));

                        //}


                        //crmTrace.AppendLine("Fuel Storage device details to Master device - Start");
                        // AddFuelStorageDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, existing);
                        //MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                        //service.Update(MasterDevice);

                        #region Update Latest Active FS after removal or abandand (Requirement Changed to show list of FS)
                        //if (BoilerMasterDeviceId != null && BoilerMasterDeviceId != new Guid() && (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank))
                        //{
                        //    //Clear the latest FS lookup  and if there is any other Active FS link it
                        //    crmTrace.AppendLine("Clear the latest FS lookup  and if there is any other Active FS link it - Start");
                        //    MasterDevice = new Entity();
                        //    ConditionExpression transactionCodeCondition = CreateConditionExpression(FulelStorageMaster.BoilerMasterLookup, ConditionOperator.Equal, new string[] { BoilerMasterDeviceId.ToString() });
                        //    ConditionExpression transactionCodeCondition2 = CreateConditionExpression(FulelStorageMaster.FuelStorageStatus, ConditionOperator.Equal, new object[] { (int)BoilerScopeOfWorkType.Active });
                        //    EntityCollection BoilerScopeOfWorkCollection = RetrieveMultiple(service, FulelStorageMaster.EntityLogicalName, new string[] {
                        //                              FulelStorageMaster.EntityNameAttribute,FulelStorageMaster.CreatedOn}, new ConditionExpression[] { transactionCodeCondition, transactionCodeCondition2 }, LogicalOperator.And, FulelStorageMaster.CreatedOn, OrderType.Descending, 1);
                        //    if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0)
                        //    {
                        //        crmTrace.AppendLine("another FS present so Link it to master");
                        //        MasterDevice.Attributes.Add(BoilerMasterDevice.LatestFuelBurnerDevice, BoilerScopeOfWorkCollection.Entities[0].ToEntityReference());
                        //    }
                        //    else
                        //    {
                        //        crmTrace.AppendLine("No FS  so clear the lookup");
                        //        MasterDevice.Attributes.Add(BoilerMasterDevice.LatestFuelBurnerDevice, null);
                        //    }
                        //    MasterDevice.Id = BoilerMasterDeviceId;
                        //    service.Update(MasterDevice);
                        //    crmTrace.AppendLine("Clear the latest FS lookup  and if there is any other Active FS link it - End");

                        //}
                        #endregion
                    }

                }
                else
                {
                    if (shouldCreateNewFuelStorageDevice_Modification(scopeType, ScopeOfWSorkType, BoilerDevice))
                    {
                        crmTrace.AppendLine("Fuel Storage device Not Present on BBD Create One FS - Start");
                        if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FSScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FSScope) == true)
                        {
                            CreateFuelStorageMasterDeviceNumber(service, targetEntity, crmTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, BoilerDevice);
                            crmTrace.AppendLine("Update the Fs lookup on boiler device"); //already set the Fs lookup on create method
                        }
                        else
                        {
                            CreateFuelStorageMasterDeviceNumber(service, targetEntity, crmTrace, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute), BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, BoilerMasterDeviceId, existing);
                        }
                        service.Update(BoilerDevice);
                    }

                }
                #endregion



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }

        /// <summary>
        /// This function updates the master boiler device when paa is approved if I1 is permit entire 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="BoilerScopeOfWork"></param>
        /// <param name="scopeType"></param>
        /// <param name="ScopeOfWSorkType"></param>
        public static void UpdatePAABoilerMasterDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");
            Entity MasterDevice = new Entity();
            Entity BoilerMasterDeviceCollection = new Entity();
            Guid BoilerMasterDeviceId = new Guid(); // used to capture the boiler Master Id
            try
            {
                int existingnergysource = 0;
                EntityCollection ExistingDeviceCollection = new EntityCollection();
                Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup] != null)
                {

                    Guid Existingdevideid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup).Id;
                    ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId, ConditionOperator.Equal, Existingdevideid.ToString());
                    ExistingDeviceCollection = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
                    existing = ExistingDeviceCollection.Entities[0];
                }
                else
                    existing = BoilerDevice;
                crmTrace.AppendLine("ExistingDeviceCollection Retrieve method");

                if (ExistingDeviceCollection.Entities.Count > 0 && ExistingDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource) && ExistingDeviceCollection.Entities[0].Attributes[BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource] != null)
                {
                    crmTrace.AppendLine("ExistingDeviceCollection Retrieve method- Entered");
                    existingnergysource = ExistingDeviceCollection.Entities[0].GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;
                }


                crmTrace.AppendLine("ExistingDeviceCollection Retrieve method - End");

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                {

                    //get the master device id by using device number then update the required fields.
                    MasterDevice = new Entity(BoilerMasterDevice.EntityLogicalName);

                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        BoilerMasterDevice.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        BoilerMasterDeviceId = BoilerMasterDeviceCollection.Id;
                        if (scopeType == (int)BoilerScopeIncludes.Boiler && (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement)) //Update Boiler Fields only when scope is Boiler
                        {
                            crmTrace.AppendLine("Boiler device details to Master device - Start This should update only when we receive pass final on permit");
                            AddBoilerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, ScopeOfWSorkType, existingnergysource);
                            MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                            service.Update(MasterDevice);


                        }

                    }
                }
                #region Fuel Burner Update
                //if fuel burner lookup is not filled then create the new one
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null)
                {

                    MasterDevice = new Entity(FulelBurnerMaster.EntityLogicalName);

                    crmTrace.AppendLine("Fuel burner Update Details- Start");
                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        FulelBurnerMaster.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup).Id, FulelBurnerMaster.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FBScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FBScope) == true)
                        {
                            crmTrace.AppendLine("Fuel burner device details to Master device Burner present- Start");
                            AddFuelBurnerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, BoilerDevice);
                        }
                        else
                        {
                            AddFuelBurnerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, existing);
                        }
                        MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                        service.Update(MasterDevice);

                    }

                }


                #endregion
                #region Fuel Storage Update
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                {

                    MasterDevice = new Entity(FulelStorageMaster.EntityLogicalName);
                    crmTrace.AppendLine("Fuel Storage Update Details- Start");

                    BoilerMasterDeviceCollection = Retrieve(service, new string[] {
                        FulelStorageMaster.EntityNameAttribute}, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Id, FulelStorageMaster.EntityLogicalName);

                    if (BoilerMasterDeviceCollection != null && BoilerMasterDeviceCollection.Id != null)
                    {
                        if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.AbandoningofTank || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.RemovalofTank)
                        {
                            crmTrace.AppendLine("Fuel Storage SOW Removaloftank");
                            MasterDevice.Attributes.Add(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));

                        }


                        crmTrace.AppendLine("Fuel Storage device details to Master device - Start");
                        if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FSScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FSScope) == true)
                        {

                            AddFuelStorageDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, BoilerDevice);
                        }
                        else
                        {
                            AddFuelStorageDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, scopeType, ScopeOfWSorkType, existing);

                        }
                        MasterDevice.Id = BoilerMasterDeviceCollection.Id;
                        service.Update(MasterDevice);


                    }

                }
                #endregion



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdatePAABoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            #endregion
        }







        /// <summary>
        /// create master boiler device - No MasterId -Null
        /// This will also called to create Fuel Burner and Fuel Storage . Send MasterId with boiler master device ID
        /// Also Update Boiler build Device Details with Boiler Master Lookup
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="TrackingNumberFormatted"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="masterId">will be null when it is called for Boiler.otherwise it will have value</param>
        public static void CreateBoilerMasterDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, string TrackingNumberFormatted, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType, Guid masterId)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");
            Entity MasterDevice = new Entity(BoilerMasterDevice.EntityLogicalName);
            Guid FBMasterId = new Guid();
            Guid FSMasterId = new Guid();

            try
            {

                int existingnergysource = 0;
                EntityCollection ExistingDeviceCollection = new EntityCollection();
                Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup] != null)
                {
                    Guid Existingdevideid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup).Id;
                    ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId, ConditionOperator.Equal, Existingdevideid.ToString());
                    ExistingDeviceCollection = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);

                }
                if (ExistingDeviceCollection != null && ExistingDeviceCollection.Entities.Count > 0)
                {
                    existing = ExistingDeviceCollection.Entities[0];
                    if (ExistingDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource))
                    {
                        existingnergysource = ExistingDeviceCollection.Entities[0].GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;
                    }

                }
                else
                {
                    existing = BoilerDevice;
                }

                if (shouldCreateNewBoilerDevice(scopeType, ScopeOfWSorkType))
                {


                    MasterDevice.SetAttributeValue(BoilerMasterDevice.EntityNameAttribute, TrackingNumberFormatted);
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.boilerStatus, new OptionSetValue((int)BoilerDeviceStatus.workinprogress));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.IsHistoric, false);//when creating new device set the historic flag to false
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Bin, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString());
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Block, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Block).ToString());
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Borough, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.HouseNumber, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.StreetName, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Street));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Lot, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Lot).ToString());
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Aptno, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.AptCondonosAttributeName));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Zipcode, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ZipAttributeName));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.PermZipcode, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ZipAttributeName));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.boilerNumber, TrackingNumberFormatted.Substring(0, 11));
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.SerialNumber, "1111");

                    if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement)//on;ly in replacement
                    {
                        crmTrace.AppendLine("Entered Replacement so  updating the boiler lookup");
                        MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerMasterReplacementLookup, new EntityReference(BoilerMasterDevice.EntityLogicalName, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id));

                        //Fill the Replacement Boiler lookup on Boiler Build device details
                        crmTrace.AppendLine("Fill the Replacement Boiler lookup on Boiler Build device details");
                        BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.ReplacedBoilerDevice, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler));

                    }


                    AddBoilerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterDevice, ScopeOfWSorkType, existingnergysource);

                    masterId = service.Create(MasterDevice);
                    crmTrace.AppendLine("update the new boiler on boilerbuilddevice");
                    BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler, new EntityReference(BoilerMasterDevice.EntityLogicalName, masterId));
                }


                #region After Creation Of Mater -Check for FB and FS

                crmTrace.AppendLine("After Creation Of Mater -Check for FB and FS");

                if (shouldCreateNewBurnerDevice(scopeType, ScopeOfWSorkType, BoilerDevice))
                {
                    //Create Master Fuel Burner 

                    if ((BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FBScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FBScope) == true) || (scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation))
                    {
                        crmTrace.AppendLine("Create Master Fuel Burner- Start proposed");
                        FBMasterId = CreateFuelBurnerMasterDeviceNumber(service, targetEntity, crmTrace, TrackingNumberFormatted, BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, masterId, BoilerDevice);
                    }
                    else
                    {
                        crmTrace.AppendLine("Create Master Fuel Burner- Start existing");
                        FBMasterId = CreateFuelBurnerMasterDeviceNumber(service, targetEntity, crmTrace, TrackingNumberFormatted, BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, masterId, existing);
                    }


                }
                if (shouldCreateNewFuelStorageDevice(scopeType, ScopeOfWSorkType, BoilerDevice))
                {
                    if ((BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.FSScope) && BoilerScopeOfWork.GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FSScope) == true) || ((scopeType == (int)(int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation) && ((BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2] != null && BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2)) || (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage] != null && BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage)))))
                    {

                        //Create Master Fuel Storage
                        crmTrace.AppendLine("Create Master Fuel Storage");
                        FSMasterId = CreateFuelStorageMasterDeviceNumber(service, targetEntity, crmTrace, TrackingNumberFormatted, BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, masterId, BoilerDevice);
                    }
                    else
                    {
                        //Create Master Fuel Storage
                        crmTrace.AppendLine("Create Master Fuel Storage");
                        FSMasterId = CreateFuelStorageMasterDeviceNumber(service, targetEntity, crmTrace, TrackingNumberFormatted, BoilerDevice, BoilerScopeOfWork, scopeType, ScopeOfWSorkType, masterId, existing);
                    }
                }
                #endregion


                #region Update the Master Boiler Device with latest FS and FB
                //if (masterId != null && masterId != new Guid())
                //{

                //    crmTrace.AppendLine("Upadte  Master Boiler with latest FB and FS ");
                //    Entity BLMasterDevice = new Entity();
                //    if (FBMasterId != null && FBMasterId != new Guid())
                //        BLMasterDevice.SetAttributeValue(BoilerMasterDevice.LatestFuelBurnerDevice, new EntityReference(FulelBurnerMaster.EntityLogicalName, FBMasterId));
                //    if (FSMasterId != null && FSMasterId != new Guid())
                //        BLMasterDevice.SetAttributeValue(BoilerMasterDevice.LatestFuelStorageDevice, new EntityReference(FulelStorageMaster.EntityLogicalName, FSMasterId));
                //    BLMasterDevice.Id = masterId;
                //    service.Update(BLMasterDevice);
                //    crmTrace.AppendLine("Upadte  Master Boiler with latest FB and FS-End ");
                //}

                #endregion




                service.Update(BoilerDevice);

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateBoilerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }





        public static Guid CreateFuelBurnerMasterDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, string TrackingNumberFormatted, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType, Guid MasterDeviceId, Entity ExistingDeviceDetails)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");
            Entity MasterFuelBurnerDevice = new Entity(FulelBurnerMaster.EntityLogicalName);

            Guid masterId = new Guid();
            try
            {

                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.EntityNameAttribute, "FB-" + TrackingNumberFormatted);

                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Bin, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString());
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Block, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Block).ToString());
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Borough, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName));
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.HouseNumber, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber));
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.StreetName, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Street));
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Lot, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Lot).ToString());
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Aptno, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.AptCondonosAttributeName));
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.Zipcode, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ZipAttributeName));
                MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.BoilerMasterLookup, new EntityReference(BoilerMasterDevice.EntityLogicalName, MasterDeviceId));

                if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification)
                {
                    Entity temp = Retrieve(service, new string[] { BoilerMasterDevice.boilerStatus }, MasterDeviceId, BoilerMasterDevice.EntityLogicalName);
                    crmTrace.AppendLine("Replacement and modification of FB sos tatus is active-pending");
                    if (temp != null && temp.Contains(BoilerMasterDevice.boilerStatus) && temp[BoilerMasterDevice.boilerStatus] != null)
                    {
                        MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.FuelBurnerStatus, new OptionSetValue(temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value));
                    }

                }
                else
                {
                    MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.FuelBurnerStatus, new OptionSetValue((int)BoilerDeviceStatus.workinprogress));
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement)//on;ly in replacement
                {
                    crmTrace.AppendLine("Entered Replacement so  updating the boiler lookup");
                    MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.FuelBurnerSelfLookup, new EntityReference(FulelBurnerMaster.EntityLogicalName, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup).Id));
                }

                AddFuelBurnerDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterFuelBurnerDevice, scopeType, ScopeOfWSorkType, ExistingDeviceDetails);

                masterId = service.Create(MasterFuelBurnerDevice);

                crmTrace.AppendLine("update the new boiler on boilerbuilddevice" + masterId.ToString());
                crmTrace.AppendLine("update the new boiler on boilerbuilddevice");
                BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, new EntityReference(FulelBurnerMaster.EntityLogicalName, masterId));

                crmTrace.AppendLine("FuelBurnerMasterLookup filled");

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
            return masterId;
        }


        public static Guid CreateFuelStorageMasterDeviceNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, string TrackingNumberFormatted, Entity BoilerDevice, Entity BoilerScopeOfWork, int scopeType, int ScopeOfWSorkType, Guid MasterDeviceId, Entity existing)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");
            Entity MasterFuelStorageDevice = new Entity(FulelStorageMaster.EntityLogicalName);
            Guid masterId = new Guid();
            try
            {




                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.EntityNameAttribute, "FS-" + TrackingNumberFormatted);

                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Bin, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString());
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Block, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Block).ToString());
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Borough, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName));
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.HouseNumber, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber));
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.StreetName, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Street));
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Lot, targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.Lot).ToString());
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Aptno, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.AptCondonosAttributeName));
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.Zipcode, targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ZipAttributeName));

                if (MasterDeviceId == new Guid())
                {
                    crmTrace.AppendLine("Boiler is not attached to FS so fill the job Filing Lookup");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.JobFilingLookup, targetEntity.ToEntityReference());
                }
                else
                {
                    crmTrace.AppendLine("Boiler is attached to FS");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.BoilerMasterLookup, new EntityReference(BoilerMasterDevice.EntityLogicalName, MasterDeviceId));
                }


                if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Modification || ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation)
                {

                    if (MasterDeviceId != new Guid())
                    {
                        Entity temp = Retrieve(service, new string[] { BoilerMasterDevice.boilerStatus }, MasterDeviceId, BoilerMasterDevice.EntityLogicalName);
                        crmTrace.AppendLine("Replacement and modification of FS sos tatus is ");
                        if (temp != null && temp.Contains(BoilerMasterDevice.boilerStatus) && temp[BoilerMasterDevice.boilerStatus] != null)
                        {
                            MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue(temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value));
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("Replacement and modification of FS sos tatus is active-pending");
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.workinprogress));
                    }

                }
                //else if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation)
                //{

                //    if (MasterDeviceId != new Guid())
                //    {
                //        Entity temp = Retrieve(service, new string[] { BoilerMasterDevice.boilerStatus }, MasterDeviceId, BoilerMasterDevice.EntityLogicalName);
                //        crmTrace.AppendLine("Replacement and modification of FS sos tatus is ");
                //        if (temp != null && temp.Contains(BoilerMasterDevice.boilerStatus) && temp[BoilerMasterDevice.boilerStatus] != null)
                //        {
                //            MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue(temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value));
                //        }
                //    }
                //    else
                //    {
                //        crmTrace.AppendLine("NewInstallation of FS sos tatus is workinprogress");
                //        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.activePendingInspections));
                //    }

                //}
                else
                {
                    crmTrace.AppendLine("Replacement and RemovalofTank of FS sos tatus is voidRemoved");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.workinprogress));
                }


                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement)//on;ly in replacement
                {
                    crmTrace.AppendLine("Entered Replacement so  updating the boiler lookup");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FuelStorageSelfLookup, new EntityReference(FulelStorageMaster.EntityLogicalName, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Id));
                }

                AddFuelStorageDeviceDetailsToMaster(targetEntity, crmTrace, BoilerDevice, BoilerScopeOfWork, MasterFuelStorageDevice, scopeType, ScopeOfWSorkType, existing);

                masterId = service.Create(MasterFuelStorageDevice);


                crmTrace.AppendLine("update the new boiler on boilerbuilddevice");
                BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup, new EntityReference(FulelStorageMaster.EntityLogicalName, masterId));
                crmTrace.AppendLine("Retrieve the Name of FS- Start");
                Entity FSDeviceNumber = service.Retrieve(FulelStorageMaster.EntityLogicalName, masterId, new ColumnSet(new string[] { FulelStorageMaster.EntityNameAttribute }));
                crmTrace.AppendLine("update FSDeviceNumber");
                BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.FSDeviceNumber, FSDeviceNumber.GetAttributeValue<string>(FulelStorageMaster.EntityNameAttribute));
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] == null)
                {
                    crmTrace.AppendLine("update New Boiler ID");
                    BoilerDevice.SetAttributeValue(BoilerBuildDeviceDetailsEntityAttribute.NewDeviceNumber, FSDeviceNumber.GetAttributeValue<string>(FulelStorageMaster.EntityNameAttribute));
                }

            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFuelBurnerMasterDeviceNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
            return masterId;

        }





        /// <summary>
        /// This Function is used to add all the attributes and their values to masterFuelBurnerdevice from dependent entities
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="BoilerScopeOfWork"></param>
        /// <param name="MasterDevice"></param>
        public static void AddFuelBurnerDeviceDetailsToMaster(Entity targetEntity, StringBuilder crmTrace, Entity BoilerDevice, Entity BoilerScopeOfWork, Entity MasterBurnerDevice, int scopeType, int ScopeOfWSorkType, Entity ExistingDeviceDetails)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered AddFuelBurnerDeviceDetailsToMaster method");

            try
            {





                #region Burner Details


                /*
                    #region Burner Details
        public const string BurnerManufacturer = "dobnyc_bbd_bu_burnermanufacturer";
         public const string BurnerApplianceConnectedTo = "dobnyc_bbd_bu_typeofappliance";
        public const string FDNYPermitNumber = "dobnyc_bbd_fs_fdnypermitnumber";
        public const string BurnerModelNumber = "dobnyc_bbd_bu_modelnumber";
        public const string BurnerULCSAETLNumber = "dobnyc_bbd_bu_ulcsaetlothernumber";
        public const string BurnerProposedEnergySource = "dobnyc_bbd_bu_proposedenergysource";
        public const string BurnerExistingEnergySource = "dobnyc_bbd_bu_existingenergysource";
        public const string BurnerIsThisExisting = "dobnyc_bbd_bu_sthisanexistingburner";
        public const string BurnerDoesDualCapability = "dobnyc_bbd_bu_burnerhavedualburning";
        public const string BurnerInputCapacity = "dobnyc_bbd_bu_inputcapacitybtu";
        public const string BurnerFiringRate = "dobnyc_bbd_bu_firingrategphapplicableforoil";
        public const string BurnerFiringBTUHour = "dobnyc_bbd_bu_firingbtuhourappli";
        public const string BurnerComments = "dobnyc_bbd_bu_burnercomments";
        public const string BurnerType = "dobnyc_bbd_bu_typeofburner";
        #endregion
                 */
                crmTrace.AppendLine("BurnerFiringBTUHour");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour] != null)
                {
                    crmTrace.AppendLine(" BoilerDevice BurnerFiringBTUHour" + BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour].ToString());
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringBTUHour, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour] != null)
                    {
                        crmTrace.AppendLine("ExistingDeviceDetails BurnerFiringBTUHour");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringBTUHour, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour]);
                    }
                    else
                    {
                        crmTrace.AppendLine(" Empty BurnerFiringBTUHour");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringBTUHour, string.Empty);
                    }
                }

                crmTrace.AppendLine("BurnerComments");

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments] != null)
                {
                    crmTrace.AppendLine(" BoilerDevice BurnerComments");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerComments, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments]);

                }
                else
                {

                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments] != null)
                    {
                        crmTrace.AppendLine(" ExistingDeviceDetails BurnerComments");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerComments, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments]);
                    }
                    else
                    {
                        crmTrace.AppendLine(" Empty BurnerComments");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerComments, string.Empty);
                    }
                }


                crmTrace.AppendLine("BurnerListingAgencyName");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName] != null)
                {
                    crmTrace.AppendLine("BurnerListingAgencyName");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyName, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName] != null)
                    {
                        crmTrace.AppendLine("BurnerListingAgencyName");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyName, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerListingAgencyName");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyName, new OptionSetValue(-1));
                    }
                }

                crmTrace.AppendLine("BurnerCertificationNumber");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber] != null)
                {
                    crmTrace.AppendLine("BurnerCertificationNumber");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerCertificationNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber].ToString());

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber] != null)
                    {

                        crmTrace.AppendLine("BurnerCertificationNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerCertificationNumber, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber].ToString());
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerCertificationNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerCertificationNumber, string.Empty);
                    }

                }
                crmTrace.AppendLine("ReplacingBurner");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner] != null)
                {
                    crmTrace.AppendLine("ReplacingBurner");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.ReplacingBurner, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner] != null)
                    {
                        crmTrace.AppendLine("ReplacingBurner");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.ReplacingBurner, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner]);
                    }
                    else
                    {
                        crmTrace.AppendLine("ReplacingBurner");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.ReplacingBurner, false);
                    }
                }
                crmTrace.AppendLine("DualBurningCapacity");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity] != null)
                {
                    crmTrace.AppendLine("DualBurningCapacity");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.DualBurningCapacity, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity] != null)
                    {
                        crmTrace.AppendLine("DualBurningCapacity");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.DualBurningCapacity, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity]);
                    }
                    else
                    {
                        crmTrace.AppendLine("DualBurningCapacity");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.DualBurningCapacity, false);
                    }

                }
                crmTrace.AppendLine("BurnerListingAgencyOther");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther] != null)
                {
                    crmTrace.AppendLine("BurnerListingAgencyOther");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyOther, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther] != null)
                    {

                        crmTrace.AppendLine("BurnerListingAgencyOther");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyOther, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther]);

                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerListingAgencyOther");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerListingAgencyOther, string.Empty);
                    }

                }


                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource] != null)
                //{
                //    crmTrace.AppendLine("BurnerExistingEnergySource");
                //    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerExistingEnergySource, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource]);


                //}
                crmTrace.AppendLine("BurnerIsThisExisting");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting] != null)
                {
                    crmTrace.AppendLine("BurnerIsThisExisting");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerIsThisExisting, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting] != null)
                    {
                        crmTrace.AppendLine("BurnerIsThisExisting");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerIsThisExisting, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerIsThisExisting");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerIsThisExisting, false);
                    }
                }
                crmTrace.AppendLine("BurnerDoesDualCapability");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability] != null)
                {
                    crmTrace.AppendLine("BurnerDoesDualCapability");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerDoesDualCapability, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability] != null)
                    {
                        crmTrace.AppendLine("BurnerDoesDualCapability");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerDoesDualCapability, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerDoesDualCapability");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerDoesDualCapability, false);
                    }


                }
                crmTrace.AppendLine("BurnerInputCapacity");

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity] != null)
                {
                    crmTrace.AppendLine("BurnerInputCapacity");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerInputCapacity, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity] != null)
                    {
                        crmTrace.AppendLine("BurnerInputCapacity");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerInputCapacity, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerInputCapacity");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerInputCapacity, string.Empty);
                    }

                }
                crmTrace.AppendLine("BurnerFiringRate");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate] != null)
                {
                    crmTrace.AppendLine("BurnerFiringRate");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringRate, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate] != null)
                    {
                        crmTrace.AppendLine("BurnerFiringRate");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringRate, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerFiringRate");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerFiringRate, string.Empty);
                    }
                }
                crmTrace.AppendLine("BurnerApplianceConnectedTo");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo] != null)
                {
                    crmTrace.AppendLine("BurnerApplianceConnectedTo");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerApplianceConnectedTo, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo] != null)
                    {
                        crmTrace.AppendLine("BurnerApplianceConnectedTo");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerApplianceConnectedTo, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerApplianceConnectedTo");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerApplianceConnectedTo, new OptionSetValue(-1));
                    }
                }
                crmTrace.AppendLine("BurnerModelNumber");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber] != null)
                {
                    crmTrace.AppendLine("BurnerModelNumber");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerModelNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber] != null)
                    {
                        crmTrace.AppendLine("BurnerModelNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerModelNumber, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerModelNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerModelNumber, string.Empty);
                    }
                }
                crmTrace.AppendLine("BurnerULCSAETLNumber");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber] != null)
                {
                    crmTrace.AppendLine("BurnerULCSAETLNumber");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerULCSAETLNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber] != null)
                    {

                        crmTrace.AppendLine("BurnerULCSAETLNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerULCSAETLNumber, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerULCSAETLNumber");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerULCSAETLNumber, string.Empty);
                    }
                }
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource] != null)
                //{
                //    crmTrace.AppendLine("BurnerProposedEnergySource");
                //    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerProposedEnergySource, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource]);
                //    if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation)
                //    {
                //        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerExistingEnergySource, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource]);
                //    }

                //}
                crmTrace.AppendLine("BurnerManufacturer");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer] != null)
                {
                    crmTrace.AppendLine("BurnerManufacturer");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerManufacturer, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer]);

                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer] != null)
                    {
                        crmTrace.AppendLine("BurnerManufacturer");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerManufacturer, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerManufacturer");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerManufacturer, string.Empty);
                    }
                }
                crmTrace.AppendLine("BurnerType");

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerType) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerType] != null)
                {
                    crmTrace.AppendLine("BurnerType");
                    MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerType, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerType]);


                }
                else
                {
                    if (ExistingDeviceDetails.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerType) && ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerType] != null)
                    {
                        crmTrace.AppendLine("BurnerType");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerType, ExistingDeviceDetails[BoilerBuildDeviceDetailsEntityAttribute.BurnerType]);
                    }
                    else
                    {
                        crmTrace.AppendLine("BurnerType");
                        MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.BurnerType, new OptionSetValue(-1));
                    }
                }
                #endregion
                crmTrace.AppendLine("fields ended");
                MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.LatestBoilerBuildDevice, BoilerDevice.ToEntityReference());
                MasterBurnerDevice.SetAttributeValue(FulelBurnerMaster.SourceUpdate, new OptionSetValue(3));




                crmTrace.AppendLine("Burner device details to Master device - End");



            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelBurnerDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }





        /// <summary>
        /// This Function is used to add all the attributes and their values to masterdevice from dependent entities
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="BoilerScopeOfWork"></param>
        /// <param name="MasterDevice"></param>
        public static void AddFuelStorageDeviceDetailsToMaster(Entity targetEntity, StringBuilder crmTrace, Entity BoilerDevice, Entity BoilerScopeOfWork, Entity MasterFuelStorageDevice, int scopeType, int ScopeOfWSorkType, Entity ExistingBoilerDevice)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered AddFuelStorageDeviceDetailsToMaster method");

            try
            {


                #region FS Details

                /*
#region Fuel Storage
public const string FSComments = "dobnyc_bbd_fs_commentsfs";
public const string FSProposedGrdaeOil = "dobnyc_bbd_fs_proposedgradeofoil";
public const string FSExistingGrdaeOil = "dobnyc_bbd_fs_existinggradeofoil";
public const string FSLocationOfFS = "dobnyc_bbd_fs_locationoffuelstorage";
public const string FSExistingStorageTank = "dobnyc_bbd_fs_isthisanexistingfuelstoragetank";
public const string FSHowTanksInstalled = "dobnyc_bbd_fs_howarethetanksinstalled";
public const string FSTotalTankCapacity = "dobnyc_bbd_fs_totaltankcapacitygal";
public const string FSBuildingAdjacentLineOfSubway = "dobnyc_bbd_fs_tankinabuildingadjacentto";
public const string FSabandedResultOfOiltoGas = "dobnyc_bbd_fs_beingabandonedremovedasares";
public const string FSApplianceFuelStorage = "dobnyc_bbd_fs_typeofapplianceisthefuelstorage";

#endregion
       */

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS] != null)
                {
                    crmTrace.AppendLine("FSLocationOfFS");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSLocationOfFS, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSLocationOfFS, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSLocationOfFS, new OptionSetValue(-1));
                    }
                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank] != null)
                {
                    crmTrace.AppendLine("FSExistingStorageTank");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingStorageTank, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingStorageTank, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingStorageTank, false);
                    }

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber] != null)
                {
                    crmTrace.AppendLine("FDNYPermitNumber");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FDNYPermitNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FDNYPermitNumber, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FDNYPermitNumber, string.Empty);
                    }
                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber] != null)
                {
                    crmTrace.AppendLine("FSFloorNumber");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSFloorNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSFloorNumber, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSFloorNumber, string.Empty);
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity] != null)
                {
                    crmTrace.AppendLine("FSTotalTankCapacity");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSTotalTankCapacity, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity] != null)
                    {

                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSTotalTankCapacity, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSTotalTankCapacity, string.Empty);
                    }

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage] != null)
                {
                    crmTrace.AppendLine("FSApplianceFuelStorage");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSApplianceFuelStorage, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSApplianceFuelStorage, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSApplianceFuelStorage, new OptionSetValue(-1));
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance] != null)
                {
                    crmTrace.AppendLine("OtherFuelStorageAppliance");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.OtherFuelStorageAppliance, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.OtherFuelStorageAppliance, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.OtherFuelStorageAppliance]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.OtherFuelStorageAppliance, string.Empty);
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas] != null)
                {
                    crmTrace.AppendLine("FSabandedResultOfOiltoGas");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSabandedResultOfOiltoGas, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas] != null)
                    {

                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSabandedResultOfOiltoGas, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSabandedResultOfOiltoGas, false);
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway] != null)
                {
                    crmTrace.AppendLine("FSBuildingAdjacentLineOfSubway");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSBuildingAdjacentLineOfSubway, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSBuildingAdjacentLineOfSubway, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSBuildingAdjacentLineOfSubway, false);
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled] != null)
                {
                    crmTrace.AppendLine("FSHowTanksInstalled");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSHowTanksInstalled, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSHowTanksInstalled, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSHowTanksInstalled, new OptionSetValue(-1));
                    }
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSComments) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments] != null)
                {
                    crmTrace.AppendLine("FSComments");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSComments, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSComments) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSComments, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments]);
                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSComments, string.Empty);
                    }
                }



                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil] != null)
                {
                    crmTrace.AppendLine("FSExistingGrdaeOil");
                    MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingGrdaeOil, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil]);

                }
                else
                {
                    if (ExistingBoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil) && ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil] != null)
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingGrdaeOil, ExistingBoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil]);

                    }
                    else
                    {
                        MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.FSExistingGrdaeOil, new OptionSetValue(-1));

                    }
                }
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.LatestBoilerBuildDevice, BoilerDevice.ToEntityReference());
                MasterFuelStorageDevice.SetAttributeValue(FulelStorageMaster.SourceUpdate, new OptionSetValue(3));
                #endregion


                crmTrace.AppendLine("Boiler device details to Master device - End");











            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddFuelStorageDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }





        /// <summary>
        /// This Function is used to add all the attributes and their values to masterdevice from dependent entities
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="BoilerScopeOfWork"></param>
        /// <param name="MasterDevice"></param>
        public static void AddBoilerDeviceDetailsToMaster(Entity targetEntity, StringBuilder crmTrace, Entity BoilerDevice, Entity BoilerScopeOfWork, Entity MasterDevice, int ScopeOfWSorkType, int existingnergysource)
        {
            //here target entity is rolling or moving device type

            crmTrace.AppendLine("Entered GenerateBoilerDeviceNumber method");

            try
            {
                #region Boiler Device Details
                crmTrace.AppendLine("IsHistoric-False making that device has up to date data.");
                MasterDevice.SetAttributeValue(BoilerMasterDevice.IsDeviceDetailsPending, false);


                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerInputCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerInputCapacity] != null)
                {
                    crmTrace.AppendLine("SerialNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerInputCapacity, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerInputCapacity));

                }
                else
                {
                    crmTrace.AppendLine("SerialNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerInputCapacity, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN] != null)
                {
                    crmTrace.AppendLine("IsAssociatedWithCOGEN");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.IsAssociatedWithCOGEN, BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign] != null)
                {
                    crmTrace.AppendLine("BoilerDesign");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerDesign, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign));

                }
                else
                {
                    crmTrace.AppendLine("BoilerDesign");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerDesign, new OptionSetValue(-1));

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerComments) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerComments] != null)
                {
                    crmTrace.AppendLine("BoilerComments");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerComments, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerComments));

                }
                else
                {
                    crmTrace.AppendLine("BoilerComments");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerComments, string.Empty);

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor] != null)
                {
                    crmTrace.AppendLine("ServiceLocationFloor");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ServiceLocationFloor, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor));

                }
                else
                {
                    crmTrace.AppendLine("ServiceLocationFloor");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ServiceLocationFloor, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes] != null)
                {
                    crmTrace.AppendLine("IsBoilerEquippedWithManholes");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.IsBoilerEquippedWithManholes, BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes));

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment] != null)
                {
                    crmTrace.AppendLine("IsBoilerHeatingaSingleAppartment");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.IsBoilerHeatingaSingleAppartment, BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.OccupancyType) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.OccupancyType] != null)
                {
                    crmTrace.AppendLine("IsBoilerHeatingaSingleAppartment");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.occupancyType, new OptionSetValue(BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.OccupancyType).Value));

                }
                else
                {
                    crmTrace.AppendLine("IsBoilerHeatingaSingleAppartment");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.occupancyType, new OptionSetValue(-1));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther] != null)
                {
                    crmTrace.AppendLine("BoilerListingAgencyNameOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerListingAgencyOther, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyNameOther));

                }
                else
                {
                    crmTrace.AppendLine("BoilerListingAgencyNameOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerListingAgencyOther, string.Empty);

                }


                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName] != null)
                {
                    crmTrace.AppendLine("BoilerListingAgencyName");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerListingAgencyName, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName));

                }
                else
                {
                    crmTrace.AppendLine("BoilerListingAgencyName");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerListingAgencyName, new OptionSetValue(-1));

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber] != null)
                {
                    crmTrace.AppendLine("BoilerCertificationNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerCertificationNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber).ToString());

                }
                else
                {
                    crmTrace.AppendLine("BoilerCertificationNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerCertificationNumber, string.Empty);

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers] != null)
                {
                    crmTrace.AppendLine("Quantity of Boilers");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.QuantityofBoilers, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.QuantityofBoilers).ToString());

                }
                else
                {
                    crmTrace.AppendLine("Quantity of Boilers");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.QuantityofBoilers, string.Empty);

                }



                crmTrace.AppendLine("Boiler device details to Master device - Start");
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.SerialNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.SerialNumber] != null)
                {
                    crmTrace.AppendLine("SerialNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.SerialNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.SerialNumber));

                }
                else
                {
                    crmTrace.AppendLine("SerialNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.SerialNumber, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial] != null)
                {
                    crmTrace.AppendLine("constructionMaterial");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.constructionMaterial, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial));

                }
                else
                {
                    crmTrace.AppendLine("constructionMaterial");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.constructionMaterial, new OptionSetValue(-1));

                }


                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther] != null)
                {
                    crmTrace.AppendLine("constructionMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.constructionMaterialOther, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.constructionMaterialOther));

                }
                else
                {
                    crmTrace.AppendLine("constructionMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.constructionMaterialOther, string.Empty);

                }


                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber] != null)
                {
                    crmTrace.AppendLine("NationalBoardNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.NationalBoardNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber));

                }
                else
                {
                    crmTrace.AppendLine("NationalBoardNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.NationalBoardNumber, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerModel) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerModel] != null)
                {
                    crmTrace.AppendLine("BoilerModel");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerModel, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerModel));

                }
                else
                {
                    crmTrace.AppendLine("BoilerModel");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerModel, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.Efficiency) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.Efficiency] != null)
                {
                    crmTrace.AppendLine("Efficiency");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Efficiency, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.Efficiency));

                }
                else

                {
                    crmTrace.AppendLine("Efficiency");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Efficiency, string.Empty);

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi] != null)
                {
                    crmTrace.AppendLine("PressureSettingOfreliefValvepsi");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.PressureSettingOfreliefValvepsi, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi));

                }
                else
                {
                    crmTrace.AppendLine("PressureSettingOfreliefValvepsi");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.PressureSettingOfreliefValvepsi, string.Empty);


                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.InternalAccess) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.InternalAccess] != null)
                {
                    crmTrace.AppendLine("PressureSettingOfreliefValvepsi");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.InternalAccess, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.InternalAccess));

                }
                else
                {
                    crmTrace.AppendLine("PressureSettingOfreliefValvepsi");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.InternalAccess, new OptionSetValue(-1));

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BTU) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BTU] != null)
                {
                    crmTrace.AppendLine("BTU");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BTU, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BTU));

                }
                else
                {
                    crmTrace.AppendLine("BTU");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BTU, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer] != null)
                {
                    crmTrace.AppendLine("BoilerManufacturer");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerManufacturer, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer));

                }
                else
                {
                    crmTrace.AppendLine("BoilerManufacturer");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerManufacturer, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.Locatedin) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.Locatedin] != null)
                {
                    crmTrace.AppendLine("Locatedin");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Locatedin, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.Locatedin));

                }
                else
                {
                    crmTrace.AppendLine("Locatedin");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.Locatedin, string.Empty);

                }






                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerClassification) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerClassification] != null)
                {
                    crmTrace.AppendLine("BoilerClassification");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerClassification1, new OptionSetValue(BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerClassification).Value));

                }
                else
                {
                    crmTrace.AppendLine("BoilerClassification");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerClassification1, new OptionSetValue(-1));
                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.MaximumAllowableWorkingPressure) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.MaximumAllowableWorkingPressure] != null)
                {
                    crmTrace.AppendLine("MaximumAllowableWorkingPressure");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.MaximumAllowableWorkingPressure, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.MaximumAllowableWorkingPressure));

                }
                else
                {
                    crmTrace.AppendLine("MaximumAllowableWorkingPressure");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.MaximumAllowableWorkingPressure, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ProposedBoilerType) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ProposedBoilerType] != null)
                {
                    crmTrace.AppendLine("ExistingBoilerType");

                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerType, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.ProposedBoilerType));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerRating) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerRating] != null)
                {
                    crmTrace.AppendLine("BoilerRating");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerRating, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerRating));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.NumberOfModules) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.NumberOfModules] != null)
                {
                    crmTrace.AppendLine("NumberOfModules");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.NumberOfModules, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.NumberOfModules));


                }
                else
                {
                    crmTrace.AppendLine("NumberOfModules");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.NumberOfModules, string.Empty);

                }


                #region Chimney Info

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo] != null)
                {
                    crmTrace.AppendLine("ChimneyApplianceConnectedTo");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyApplianceConnectedTo, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyApplianceConnectedTo));

                }
                else
                {
                    crmTrace.AppendLine("ChimneyApplianceConnectedTo");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyApplianceConnectedTo, new OptionSetValue(-1));


                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation] != null)
                {
                    crmTrace.AppendLine("ChimneyIsNewInstallation");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyIsNewInstallation, BoilerDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyIsNewInstallation));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing] != null)
                {
                    crmTrace.AppendLine("ChimneyChooseFollowing");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyChooseFollowing, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyChooseFollowing));

                }
                else
                {
                    crmTrace.AppendLine("ChimneyChooseFollowing");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyChooseFollowing, new OptionSetValue(-1));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith] != null)
                {
                    crmTrace.AppendLine("ChimneyMaterialLinedWith");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyMaterialLinedWith, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialLinedWith));


                }
                else
                {
                    crmTrace.AppendLine("ChimneyChooseFollowing");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyMaterialLinedWith, new OptionSetValue(-1));

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialOther) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialOther] != null)
                {
                    crmTrace.AppendLine("ChimneyMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyMaterialOther, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.ChimneyMaterialOther));


                }
                else
                {
                    crmTrace.AppendLine("ChimneyMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ChimneyMaterialOther, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial] != null)
                {
                    crmTrace.AppendLine("VentApprovedMaterial");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.VentApprovedMaterial, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.VentApprovedMaterial));


                }
                else
                {
                    crmTrace.AppendLine("VentApprovedMaterial");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.VentApprovedMaterial, new OptionSetValue(-1));

                }

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther] != null)
                {
                    crmTrace.AppendLine("VentMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.VentMaterialOther, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.VentMaterialOther));

                }
                else
                {
                    crmTrace.AppendLine("VentMaterialOther");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.VentMaterialOther, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber] != null)
                {
                    crmTrace.AppendLine("AssociatedJobNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.AssociatedJobNumber, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.AssociatedJobNumber));


                }
                else
                {
                    crmTrace.AppendLine("AssociatedJobNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.AssociatedJobNumber, string.Empty);

                }
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress] != null)
                {
                    crmTrace.AppendLine("ServiceLocationAddress");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ServicingLocationAddress, BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress));


                }
                else
                {
                    crmTrace.AppendLine("AssociatedJobNumber");
                    MasterDevice.SetAttributeValue(BoilerMasterDevice.ServicingLocationAddress, string.Empty);

                }

                #endregion








                #region Burner Details




                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour] != null)
                //{
                //    crmTrace.AppendLine("BurnerFiringBTUHour");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerFiringBTUHour, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerComments) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments] != null)
                //{
                //    crmTrace.AppendLine("BurnerComments");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerComments, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerComments]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerType) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerType] != null)
                //{
                //    crmTrace.AppendLine("BurnerType");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerType, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerType]);

                //}





                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource] != null)
                //{
                //    crmTrace.AppendLine("BurnerExistingEnergySource");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerExistingEnergySource, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerExistingEnergySource]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting] != null)
                //{
                //    crmTrace.AppendLine("BurnerIsThisExisting");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerIsThisExisting, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability] != null)
                //{
                //    crmTrace.AppendLine("BurnerDoesDualCapability");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerDoesDualCapability, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity] != null)
                //{
                //    crmTrace.AppendLine("BurnerInputCapacity");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerInputCapacity, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate] != null)
                //{
                //    crmTrace.AppendLine("BurnerFiringRate");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerFiringRate, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo] != null)
                //{
                //    crmTrace.AppendLine("BurnerApplianceConnectedTo");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerApplianceConnectedTo, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber] != null)
                //{
                //    crmTrace.AppendLine("FDNYPermitNumber");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FDNYPermitNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber] != null)
                //{
                //    crmTrace.AppendLine("BurnerModelNumber");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerModelNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber] != null)
                //{
                //    crmTrace.AppendLine("BurnerULCSAETLNumber");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerULCSAETLNumber, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource] != null)
                //{
                //    crmTrace.AppendLine("BurnerProposedEnergySource");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerProposedEnergySource, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerProposedEnergySource]);

                //}





                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer] != null)
                //{
                //    crmTrace.AppendLine("BurnerManufacturer");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BurnerManufacturer, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer]);

                //}

                #endregion



                #region FS Details



                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS] != null)
                //{
                //    crmTrace.AppendLine("FSLocationOfFS");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSLocationOfFS, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank] != null)
                //{
                //    crmTrace.AppendLine("FSExistingStorageTank");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSExistingStorageTank, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity] != null)
                //{
                //    crmTrace.AppendLine("FSTotalTankCapacity");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSTotalTankCapacity, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity]);

                //}
                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage] != null)
                //{
                //    crmTrace.AppendLine("FSApplianceFuelStorage");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSApplianceFuelStorage, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage]);

                //}


                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas] != null)
                //{
                //    crmTrace.AppendLine("FSabandedResultOfOiltoGas");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSabandedResultOfOiltoGas, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway] != null)
                //{
                //    crmTrace.AppendLine("FSTotalTankCapacity");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSBuildingAdjacentLineOfSubway, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled] != null)
                //{
                //    crmTrace.AppendLine("FSHowTanksInstalled");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSHowTanksInstalled, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSComments) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments] != null)
                //{
                //    crmTrace.AppendLine("FSComments");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSComments, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSComments]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSProposedGrdaeOil) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSProposedGrdaeOil] != null)
                //{
                //    crmTrace.AppendLine("FSProposedGrdaeOil");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSProposedGrdaeOil, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSProposedGrdaeOil]);

                //}

                //if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil] != null)
                //{
                //    crmTrace.AppendLine("FSExistingGrdaeOil");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.FSExistingGrdaeOil, BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil]);

                //}


                #endregion


                crmTrace.AppendLine("Boiler device details to Master device - End");

                #endregion



                #region Scope of Work to Master Device

                #region Comented - Should move from Scope of work to device details

                //crmTrace.AppendLine("Boiler Scope of Work details to Master device - Start");

                //if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.BoilerClassification) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.BoilerClassification] != null)
                //{
                //    crmTrace.AppendLine("BoilerClassification");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerClassification, new OptionSetValue(BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerClassification).Value));

                //}

                //if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure] != null)
                //{
                //    crmTrace.AppendLine("MaximumAllowableWorkingPressure");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.MaximumAllowableWorkingPressure, BoilerScopeOfWork.GetAttributeValue<string>(BEScopeOfWorkEntityAttribute.MaximumAllowableWorkingPressure));

                //}
                //if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.ExistingBoilerType) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.ExistingBoilerType] != null && ScopeOfWSorkType != (int)BoilerScopeOfWorkType.NewInstallation)
                //{
                //    crmTrace.AppendLine("ExistingBoilerType");

                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerType, BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ExistingBoilerType));



                //}
                //if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.BoilerType) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.BoilerType] != null)
                //{
                //    crmTrace.AppendLine("BoilerType");
                //    if (ScopeOfWSorkType == (int)BoilerScopeOfWorkType.NewInstallation)
                //    {
                //        MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerType, BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerType));
                //    }
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.ProposedBoilerType, BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerType));

                //}
                //if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.BoilerRating) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.BoilerRating] != null)
                //{
                //    crmTrace.AppendLine("BoilerRating");
                //    MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerRating, BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerRating));

                //}

                #endregion
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet] != null && BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.existingProposedOptionSet).Value == (int)ExistingProposedOptionSet.Proposed)
                {

                    if (BoilerScopeOfWork.Contains(BEScopeOfWorkEntityAttribute.BoilerEnergySource) && BoilerScopeOfWork[BEScopeOfWorkEntityAttribute.BoilerEnergySource] != null)
                    {
                        MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerEnergySource, BoilerScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerEnergySource));

                    }
                    else
                    {
                        crmTrace.AppendLine("ExistingEnergySource");
                        if (existingnergysource != 0)
                        {
                            MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerEnergySource, new OptionSetValue(existingnergysource));

                        }

                    }
                }

                else
                {
                    if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource] != null && ScopeOfWSorkType != (int)BoilerScopeOfWorkType.NewInstallation)
                    {
                        crmTrace.AppendLine("ExistingEnergySource");

                        MasterDevice.SetAttributeValue(BoilerMasterDevice.BoilerEnergySource, BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource));

                    }
                }



                #endregion
                MasterDevice.SetAttributeValue(BoilerMasterDevice.LatestBoilerBuildDevice, BoilerDevice.ToEntityReference());

                MasterDevice.SetAttributeValue(BoilerMasterDevice.SourceUpdate, new OptionSetValue(3));


            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AddBoilerDeviceDetailsToMaster", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            #endregion
        }

        public static void UpdateCounter(IOrganizationService service, decimal AutoNumber, Entity response)
        {
            Entity autoNumber = new Entity();
            autoNumber.LogicalName = AutoNumberEntityAttribute.EntityLogicalName;
            autoNumber.Attributes.Add(AutoNumberEntityAttribute.FacadesCounter, (AutoNumber + 1));
            autoNumber.Id = response.Id;
            UpdateEntity(service, autoNumber);
        }
        /// <summary>
        /// get the autonumber config for boilers
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="queryString"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static Entity GetBoilerDeviceIdConfig(IOrganizationService service, Entity targetEntity, string queryString, StringBuilder crmTrace)
        {
            Entity retval = null;


            try
            {
                crmTrace.AppendLine("Start Retrieve Id");



                crmTrace.AppendLine("Start Framing  fetchXML  ");
                string fetchXML = @"<?xml version='1.0'?>
                                <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                                  <entity name='dobnyc_autonumberentity'>
                                    <attribute name='dobnyc_autonumberentityid'/>
                                    <attribute name='dobnyc_name'/>
                                    <attribute name='createdon'/>
                                    <attribute name='dobnyc_facadespaddingnumber'/>
                                    <attribute name='dobnyc_facadespaddingcharacter'/>
                                    <attribute name='dobnyc_facadescounter'/>
                                    <order descending='false' attribute='dobnyc_name'/>
                                    <filter type='and'>
                                      <condition attribute='dobnyc_name' value='" + queryString + @"' operator='eq'/>
                                    </filter>
                                  </entity>
                                </fetch>";

                EntityCollection response = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("End Framing and execute fetchXML  ");

                if (response != null && response.Entities.Count > 0)
                {
                    retval = response[0];
                }
            }
            #region catch 
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("GetDeviceId", "CRM", "FeeCalculationStandardizationHandler - GetBoilerDeviceIdConfig", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            #endregion

            return retval;
        }



        /// <summary>
        /// This Method is used to set the basic fees in feeobject based on the flags flingfee,RMGMT,Legal,PAA,amountpaid,ngc,amountdue
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="fcObject"></param>
        public static void setBasicFeesRelatedtoFalgs(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Entity preImage, FeeCalculationObject fcObject)
        {
            try
            {
                crmTrace.AppendLine("setBasicFeesRelatedtoFalgs");





                #region legalization and normal filings

                if (fcObject.IsLegalization)
                {
                    crmTrace.AppendLine("legalization so setting filng fee as 0 ");
                    #region new legalization fee logic
                    ///1) if the legalization violation number is present or violation flag is true then legalization fee=filing fee
                    ///2)if violation flag is not present then legl fee = legal fee +filing fee
                    ///

                    bool legalViolationFalg = targetEntity.Contains(JobFilingEntityAttributeName.LegalizationViolationflag) && targetEntity[JobFilingEntityAttributeName.LegalizationViolationflag] != null ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.LegalizationViolationflag) : preImage.Contains(JobFilingEntityAttributeName.LegalizationViolationflag) && preImage[JobFilingEntityAttributeName.LegalizationViolationflag] != null ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.LegalizationViolationflag) : false;
                    if (legalViolationFalg)
                    {
                        crmTrace.AppendLine("legalViolationFalg is true so setting legal fee to filing fee ");
                        //fcObject.LegalizationFilingFees = fcObject.BEMSSTFilingfee;
                        fcObject.LegalizationFilingFees = 0;
                    }
                    else
                    {
                        crmTrace.AppendLine("legalViolationFalg is false so setting legal fee to filing fee + legal fee ");
                        //fcObject.LegalizationFilingFees = fcObject.LegalizationFilingFees + fcObject.BEMSSTFilingfee;
                        fcObject.LegalizationFilingFees = fcObject.LegalizationFilingFees;
                    }

                    #endregion

                    //fcObject.BEMSSTFilingfee = 0;
                    fcObject.InConjunctionFee = 0;
                }
                else
                {
                    crmTrace.AppendLine("New filing so setting legal fee,inconjunction fee as 0");
                    fcObject.LegalizationFilingFees = 0;
                    fcObject.InConjunctionFee = 0;
                }
                #endregion

                #region PAA
                if (!fcObject.IsPAA)
                {
                    crmTrace.AppendLine("Not PAA so setting paafee as 0 ");
                    fcObject.PAAFees = 0;
                }



                #endregion


                #region inconjunction
                crmTrace.AppendLine("inconjunction");
                if (fcObject.IsConjunction)
                {
                    crmTrace.AppendLine("inconjunction set recordmgmt fee 0");
                    fcObject.RecordManagementFees = 0;

                    fcObject.InConjunctionFee = 130; //Falt Fee 
                    crmTrace.AppendLine("inconjunction set recordmgmt fee,BEMSSTFilingfee,LegalizationFilingFees to 0 and legalization flag to false");
                    fcObject.BEMSSTFilingfee = 0;
                    fcObject.LegalizationFilingFees = 0;
                    fcObject.IsLegalization = false;// have to assign normal transaction codes


                }
                crmTrace.AppendLine("inconjunction " + fcObject.IsConjunction);
                #endregion

                #region feeexempt
                crmTrace.AppendLine("feeexempt");
                if (fcObject.IsFeeExempt)
                {
                    crmTrace.AppendLine("fee exempt Set All fees to zero");
                    fcObject.BEMSSTFilingfee = 0;
                    fcObject.RecordManagementFees = 0;
                    fcObject.LegalizationFilingFees = 0;
                    fcObject.PAAFees = 0;
                    fcObject.InConjunctionFee = 0;
                }


                #endregion

                #region nogoodcheck,amountpaid,amountdue

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) || preImage.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))//  Targetentity condition  will be executed  only in PAA Create
                {
                    crmTrace.AppendLine("Existing amount paid");
                    fcObject.ExistingAmountPaid = targetEntity.Contains(JobFilingEntityAttributeName.AmountPaid) && targetEntity[JobFilingEntityAttributeName.AmountPaid] != null ? ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value : (preImage.Contains(JobFilingEntityAttributeName.AmountPaid) && preImage[JobFilingEntityAttributeName.AmountPaid] != null) ? ((Money)preImage.Attributes[JobFilingEntityAttributeName.AmountPaid]).Value : 0;
                    crmTrace.AppendLine("Existing amount paid" + fcObject.ExistingAmountPaid);



                }
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) || preImage.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee))
                {
                    fcObject.NoGoodCheckFee = targetEntity.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFee] != null ? ((Money)targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFee]).Value : (preImage.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && preImage[JobFilingEntityAttributeName.NoGoodCheckFee] != null) ? ((Money)preImage.Attributes[JobFilingEntityAttributeName.NoGoodCheckFee]).Value : 0;
                    crmTrace.AppendLine("Existing NoGoodCheckFee" + fcObject.NoGoodCheckFee);
                }

                crmTrace.AppendLine("fcObject.TotalFees " + fcObject.TotalFees);
                fcObject.amountDue = fcObject.TotalFees - fcObject.ExistingAmountPaid;
                crmTrace.AppendLine("AmountDue " + fcObject.amountDue);
                #endregion



                #region FilingTypeAttributeName
                crmTrace.AppendLine("Filing Type");
                if (targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.IF)
                {
                    crmTrace.AppendLine("Filing Type initial");
                    fcObject.FilingType = (int)FilingTypes.IF;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.PA))
                {
                    crmTrace.AppendLine("Filing Type PAA");
                    fcObject.FilingType = (int)FilingTypes.PA;
                }
                else if ((targetEntity.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName) && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value == (int)FilingTypes.SF))
                {
                    crmTrace.AppendLine("Filing Type Subsequent");
                    fcObject.FilingType = (int)FilingTypes.SF;
                }
                #endregion



                // throw new Exception(crmTrace.ToString());
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - setBasicFeesRelatedtoFalgs", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        /// <summary>
        /// based on building type and work type build the fee config name 
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="identifier"></param>
        /// <returns></returns>
        public static string BuildFormualeName(Entity targetEntity, Entity preImage, StringBuilder crmTrace, string identifier, FeeCalculationObject fcobject)
        {
            try
            {

                string calcName = string.Empty;
               

                crmTrace.AppendLine("Enter BuildCalcName Function");

                switch(fcobject.jobType)
                {
                    case (int)ActualjobType.Alteration:
                        {
                            calcName = FeeCalculationStandardizationHandler.BuildFormualeNameForAlteration(targetEntity, preImage, crmTrace, identifier, fcobject);
                            break;
                        }
                    case (int)ActualjobType.NewBuilding:
                        {
                            calcName = FeeCalculationStandardizationHandler.BuildFormualeNameForNB(targetEntity, preImage, crmTrace, identifier, fcobject);
                            break;
                        }
                    case (int)ActualjobType.AlterationCofo:
                        {
                            if(fcobject.isAlterationCofoBigAlt)
                            {
                                calcName = FeeCalculationStandardizationHandler.BuildFormualeNameForAlterationCofo(targetEntity, preImage, crmTrace, identifier, fcobject);
                            }
                            else
                            {
                                calcName = FeeCalculationStandardizationHandler.BuildFormualeNameForAlterationCofo(targetEntity, preImage, crmTrace, identifier, fcobject);
                            }
                           
                            break;
                        }
                }











                //switch (fcobject.BuildingType)
                //{
                //    case 1:
                //    case 2:


                //        {
                //            crmTrace.AppendLine("123 Building Type");

                //            if (fcobject.IsBE)
                //            {
                //                crmTrace.AppendLine("IsBE BEScopeBoiler123Family calc");
                //                calcName = FeeConfigName.BEScopeBoiler123Family;
                //            }

                //            else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsMS MS123FamilyFees calc");
                //                calcName = FeeConfigName.MS123FamilyFees;
                //            }
                //            else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsST ST123FamilyFees calc");
                //                calcName = FeeConfigName.ST123FamilyFees;
                //            }
                //            else if (fcobject.IsGC)
                //            {
                //                crmTrace.AppendLine("GC ST123FamilyFees calc");
                //                calcName = FeeConfigName.GC123FamilyFees;
                //            }
                //            else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                //            {
                //                crmTrace.AppendLine(" PLSPSD123FamilyFees calc");
                //                calcName = FeeConfigName.PLSPSD123FamilyFees;
                //            }
                //            else if (fcobject.IsCC)
                //            {
                //                crmTrace.AppendLine(" CurbCut123FilingFees calc");
                //                calcName = FeeConfigName.CurbCut123FilingFees;
                //            }
                //            else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                //            {
                //                crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                //                calcName = FeeConfigName.FAB4_3Sign;
                //            }

                //            break;
                //        }

                //    case 3:

                //        {
                //            crmTrace.AppendLine("3 Building Type");

                //            if (fcobject.IsBE)
                //            {
                //                crmTrace.AppendLine("IsBE BEScopeBoiler3Family calc");
                //                calcName = FeeConfigName.BEScopeBoiler3Family;
                //            }

                //            else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsMS MS3FamilyFees calc");
                //                calcName = FeeConfigName.MS3FamilyFees;
                //            }
                //            else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsST ST3FamilyFees calc");
                //                calcName = FeeConfigName.ST3FamilyFees;
                //            }
                //            else if (fcobject.IsGC)
                //            {
                //                crmTrace.AppendLine("IsGC ST3FamilyFees calc");
                //                calcName = FeeConfigName.GC3FamilyFees;
                //            }
                //            else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                //            {
                //                crmTrace.AppendLine(" PLSPSD3FamilyFees calc");
                //                calcName = FeeConfigName.PLSPSD3FamilyFees;
                //            }
                //            else if (fcobject.IsCC)
                //            {
                //                crmTrace.AppendLine(" CurbCut3FilingFees calc");
                //                calcName = FeeConfigName.CurbCut3FilingFees;
                //            }
                //            else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                //            {
                //                crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                //                calcName = FeeConfigName.FAB4_3Sign;
                //            }

                //            break;
                //        }


                //    case 4:
                //        {
                //            crmTrace.AppendLine("Others Building Type");
                //            if (fcobject.IsBE)
                //            {
                //                crmTrace.AppendLine("IsMS  calc");
                //                buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                //                TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                //                if (buildingStories > 7 || TotalSquarFeet >= 100000)
                //                {
                //                    crmTrace.AppendLine("IsMS BEOtherFamilyMorethan7Stories calc");
                //                    calcName = FeeConfigName.BEScopeBoilerOtherFamily;
                //                }
                //                else
                //                {
                //                    crmTrace.AppendLine("IsMS BEOtherFamilyLessThan7Stories calc");
                //                    calcName = FeeConfigName.BEScopeBoilerOtherFamily;
                //                }

                //            }
                //            else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsMS  calc");
                //                buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                //                TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                //                if (buildingStories > 7 || TotalSquarFeet >= 100000)
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                //                    calcName = FeeConfigName.MSOtherFamilyMorethan7Stories;
                //                }
                //                else
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                //                    calcName = FeeConfigName.MSOtherFamilyLessThan7Stories;
                //                }

                //            }
                //            else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                //            {
                //                crmTrace.AppendLine("IsMS  calc");
                //                buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                //                TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                //                if (buildingStories > 7 || TotalSquarFeet >= 100000)
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                //                    calcName = FeeConfigName.STOtherFamilyMorethan7Stories;
                //                }
                //                else
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                //                    calcName = FeeConfigName.STOtherFamilyLessthan7Stories;
                //                }

                //            }
                //            else if (fcobject.IsGC)
                //            {
                //                crmTrace.AppendLine("IsGC  calc");
                //                buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                //                TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                //                if (buildingStories > 7 || TotalSquarFeet >= 100000)
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                //                    calcName = FeeConfigName.GCOtherFamilyMorethan7Stories;
                //                }
                //                else
                //                {
                //                    crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                //                    calcName = FeeConfigName.GCOtherFamilyLessthan7Stories;
                //                }
                //            }
                //            else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                //            {
                //                crmTrace.AppendLine(" PLSPSDOthersFamilyFees calc");
                //                calcName = FeeConfigName.PLSPSDOthersFamilyFees;
                //            }

                //            else if (fcobject.IsCC)
                //            {
                //                crmTrace.AppendLine(" CurbCutOtherFilingFees calc");
                //                calcName = FeeConfigName.CurbCutOtherFilingFees;
                //            }
                //            else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                //            {
                //                crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                //                calcName = FeeConfigName.FAB4_3Sign;
                //            }

                //            break;
                //        }
                //}

                crmTrace.AppendLine("Exit BuildCalcName Function " + calcName);
                return calcName;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - CalculateFilingFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildCalcName", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildCalcName", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildCalcName", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }

        }


        public static string BuildFormualeNameForAlteration(Entity targetEntity, Entity preImage, StringBuilder crmTrace, string identifier, FeeCalculationObject fcobject)
        {
            string calcName = string.Empty;
            int buildingStories = 0;
            double TotalSquarFeet = 0;
            try
            {
                if (fcobject.FilingType == (int)FilingType.NewJobFiling || fcobject.FilingType == (int)FilingType.SubSq)
                {


                    switch (fcobject.BuildingType)
                    {
                        case 1:
                        case 2:


                            {
                                crmTrace.AppendLine("123 Building Type");

                                if (fcobject.IsBE)
                                {
                                    crmTrace.AppendLine("IsBE BEScopeBoiler123Family calc");
                                    calcName = FeeConfigName.BEScopeBoiler123Family;
                                }

                                else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsMS MS123FamilyFees calc");
                                    calcName = FeeConfigName.MS123FamilyFees;
                                }
                                else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsST ST123FamilyFees calc");
                                    calcName = FeeConfigName.ST123FamilyFees;
                                }
                                else if (fcobject.IsGC)
                                {
                                    crmTrace.AppendLine("GC ST123FamilyFees calc");
                                    calcName = FeeConfigName.GC123FamilyFees;
                                }
                                else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                                {
                                    crmTrace.AppendLine(" PLSPSD123FamilyFees calc");
                                    calcName = FeeConfigName.PLSPSD123FamilyFees;
                                }
                                else if (fcobject.IsCC)
                                {
                                    crmTrace.AppendLine(" CurbCut123FilingFees calc");
                                    calcName = FeeConfigName.CurbCut123FilingFees;
                                }
                                else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                                {
                                    crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                                    calcName = FeeConfigName.FAB4_3Sign;
                                }

                                break;
                            }

                        case 3:

                            {
                                crmTrace.AppendLine("3 Building Type");

                                if (fcobject.IsBE)
                                {
                                    crmTrace.AppendLine("IsBE BEScopeBoiler3Family calc");
                                    calcName = FeeConfigName.BEScopeBoiler3Family;
                                }

                                else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsMS MS3FamilyFees calc");
                                    calcName = FeeConfigName.MS3FamilyFees;
                                }
                                else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsST ST3FamilyFees calc");
                                    calcName = FeeConfigName.ST3FamilyFees;
                                }
                                else if (fcobject.IsGC)
                                {
                                    crmTrace.AppendLine("IsGC ST3FamilyFees calc");
                                    calcName = FeeConfigName.GC3FamilyFees;
                                }
                                else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                                {
                                    crmTrace.AppendLine(" PLSPSD3FamilyFees calc");
                                    calcName = FeeConfigName.PLSPSD3FamilyFees;
                                }
                                else if (fcobject.IsCC)
                                {
                                    crmTrace.AppendLine(" CurbCut3FilingFees calc");
                                    calcName = FeeConfigName.CurbCut3FilingFees;
                                }
                                else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                                {
                                    crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                                    calcName = FeeConfigName.FAB4_3Sign;
                                }

                                break;
                            }


                        case 4:
                            {
                                crmTrace.AppendLine("Others Building Type");
                                if (fcobject.IsBE)
                                {
                                    crmTrace.AppendLine("IsMS  calc");
                                    buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                                    TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                                    if (buildingStories > 7 || TotalSquarFeet >= 100000)
                                    {
                                        crmTrace.AppendLine("IsMS BEOtherFamilyMorethan7Stories calc");
                                        calcName = FeeConfigName.BEScopeBoilerOtherFamily;
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("IsMS BEOtherFamilyLessThan7Stories calc");
                                        calcName = FeeConfigName.BEScopeBoilerOtherFamily;
                                    }

                                }
                                else if (fcobject.IsMS || (fcobject.IsMS && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsMS  calc");
                                    buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                                    TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                                    if (buildingStories > 7 || TotalSquarFeet >= 100000)
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                                        calcName = FeeConfigName.MSOtherFamilyMorethan7Stories;
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                                        calcName = FeeConfigName.MSOtherFamilyLessThan7Stories;
                                    }

                                }
                                else if (fcobject.IsST || (fcobject.IsST && fcobject.IsGC))
                                {
                                    crmTrace.AppendLine("IsMS  calc");
                                    buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                                    TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                                    if (buildingStories > 7 || TotalSquarFeet >= 100000)
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                                        calcName = FeeConfigName.STOtherFamilyMorethan7Stories;
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                                        calcName = FeeConfigName.STOtherFamilyLessthan7Stories;
                                    }

                                }
                                else if (fcobject.IsGC)
                                {
                                    crmTrace.AppendLine("IsGC  calc");
                                    buildingStories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && targetEntity[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) && preImage[JobFilingEntityAttributeName.ProposeeBuildingStories] != null ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;

                                    TotalSquarFeet = targetEntity.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && targetEntity[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : preImage.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea) && preImage[JobFilingEntityAttributeName.TotalConstructionFloorArea] != null ? preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea) : 0;
                                    if (buildingStories > 7 || TotalSquarFeet >= 100000)
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyMorethan7Stories calc");
                                        calcName = FeeConfigName.GCOtherFamilyMorethan7Stories;
                                    }
                                    else
                                    {
                                        crmTrace.AppendLine("IsMS MSOtherFamilyLessThan7Stories calc");
                                        calcName = FeeConfigName.GCOtherFamilyLessthan7Stories;
                                    }
                                }
                                else if (fcobject.IsSP || fcobject.IsPL || fcobject.IsSD || fcobject.IsAN)
                                {
                                    crmTrace.AppendLine(" PLSPSDOthersFamilyFees calc");
                                    calcName = FeeConfigName.PLSPSDOthersFamilyFees;
                                }

                                else if (fcobject.IsCC)
                                {
                                    crmTrace.AppendLine(" CurbCutOtherFilingFees calc");
                                    calcName = FeeConfigName.CurbCutOtherFilingFees;
                                }
                                else if (fcobject.IsSG || fcobject.IsSF || fcobject.IsSH || fcobject.IsFN)
                                {
                                    crmTrace.AppendLine(" FAB4 only for NO GOOD CHECK calc");
                                    calcName = FeeConfigName.FAB4_3Sign;
                                }

                                break;
                            }
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlteration", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            return calcName;
        }

        public static string BuildFormualeNameForAlterationCofo(Entity targetEntity, Entity preImage, StringBuilder crmTrace, string identifier, FeeCalculationObject fcobject)
        {
            try
            {

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForAlterationCofo", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            return "";
        }
        public static string BuildFormualeNameForNB(Entity targetEntity, Entity preImage, StringBuilder crmTrace, string identifier, FeeCalculationObject fcobject)
        {
            try
            {

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.LogicalName.ToString(), "CRM", "FeeCalculationStandardizationHandler - BuildFormualeNameForNB", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            return "";
        }
        /// <summary>
        /// get the details from fee config entity
        /// </summary>
        /// <param name="crmTrace"></param>
        /// <param name="service"></param>
        /// <param name="formulaeName"></param>
        /// <returns></returns>
        public static EntityCollection RetrieveFee(StringBuilder crmTrace, IOrganizationService service, string formulaeName)
        {
            crmTrace.AppendLine("Start: retrieve fee..");
            ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { formulaeName });

            return (RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName,
                  new string[] { FeeCalculationConfigurationAttributeNames.MinFilingFee, FeeCalculationConfigurationAttributeNames.Tier1CostFee,
                        FeeCalculationConfigurationAttributeNames.CheckBounce, FeeCalculationConfigurationAttributeNames.PaaFee, FeeCalculationConfigurationAttributeNames.InConjunctionJobFee,
                     FeeCalculationConfigurationAttributeNames.Tier2CostFee,FeeCalculationConfigurationAttributeNames.RecordManagementFee,FeeCalculationConfigurationAttributeNames.LegalizationFeeMul,FeeCalculationConfigurationAttributeNames.LegalizationMinFee,FeeCalculationConfigurationAttributeNames.LegalizationMaxFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And));
        }

        /// <summary>
        /// get the fees from the config calculate filing fee and legalization fee based on rules and asssign to fee object
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        public static void BoilersBuild_FeeCalculation(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            #region Formulae for Construction Fence
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

                Filing Fee:
                    Filing Fee =$130(flat)

                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region set variables
                decimal minFee = 0;
                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;



                #endregion



                {
                    #region Fee Calculation for Construction Fence

                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = BuildFormualeName(targetEntity, preImage, crmTrace, JobFilingEntityAttributeName.BoilersBuildIdentifier, feeObject);

                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = RetrieveFee(crmTrace, service, formulaeName);

                    WhichEstimatedCost(targetEntity, service, crmTrace, preImage, feeObject);
                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                        feeObject.Tier1CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee);
                    crmTrace.AppendLine("tier1 cost Fee - End" + feeObject.Tier1CostFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier2CostFee))
                        feeObject.Tier2CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier2CostFee);
                    crmTrace.AppendLine("Tier2 Cost Fee - End" + feeObject.Tier2CostFee);
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                    {
                        if (feeObject.BoilerEnergySource == (int)BoilerEnergySource.Oil)
                        {
                            feeObject.BEMSSTFilingfee = 130;
                        }
                        else
                        {
                            minFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee));
                            if (feeObject.BuildingType > 0 && feeObject.BuildingType < 4)
                            {
                                #region 123family calculation

                                FilingFeeBasicFormula(targetEntity, service, crmTrace, preImage, feeObject, minFee, 5000); //for MS basic min estimated cost is 5000


                                #endregion
                            }
                            else
                            {
                                FilingFeeBasicFormula(targetEntity, service, crmTrace, preImage, feeObject, minFee, 3000); //for MS basic min estimated cost is 3000

                            }
                        }

                        crmTrace.AppendLine("Variable minFilingFee - End" + feeObject.BEMSSTFilingfee);
                    }
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        feeObject.RecordManagementFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee));
                    crmTrace.AppendLine("Variable RecordManagementFee - End" + feeObject.RecordManagementFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee))
                        feeObject.LegalizationFilingFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee);
                    crmTrace.AppendLine("legalizationmultiplier Fee - End" + feeObject.LegalizationFilingFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                        feeObject.PAAFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PAAFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee) && retrieveFeeCollection.Entities[0][FeeCalculationConfigurationAttributeNames.InConjunctionJobFee] != null)
                        feeObject.InConjunctionFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<string>(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee));
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.InConjunctionFee);



                    #endregion
                }


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilersBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
        }


        /// <summary>
        /// get the fees from the config calculate filing fee and legalization fee based on rules and asssign to fee object
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        public static void MSBuild_FeeCalculation(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            #region Formulae for Construction Fence
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

                Filing Fee:
                 123   DOB fee 
                = $130 + (20000 – 5000)/1000 *$2.60
                = $169

               Others DOB fee 
                = $225 + (20000 – 5000)/1000 *$10.30
                = $379.50
                DOB fee 
                = $225 + (20000 – 5000)/1000 *$10.30
                = $379.50



                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region set variables

                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFee = 0;


                #endregion



                {
                    #region Fee Calculation for Construction Fence

                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = BuildFormualeName(targetEntity, preImage, crmTrace, JobFilingEntityAttributeName.BoilersBuildIdentifier, feeObject);

                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = RetrieveFee(crmTrace, service, formulaeName);


                    WhichEstimatedCost(targetEntity, service, crmTrace, preImage, feeObject);

                    //feeObject.EstimatedCost= (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedCostFinal).Value > 0) || (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalizationJobCostFinal) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostFinal).Value > 0)
                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee));
                    crmTrace.AppendLine("Variable minFilingFee - End" + feeObject.BEMSSTFilingfee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        feeObject.RecordManagementFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee));
                    crmTrace.AppendLine("Variable RecordManagementFee - End" + feeObject.RecordManagementFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee))
                        feeObject.LegalizationFilingFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee);
                    crmTrace.AppendLine("legalizationmultiplier Fee - End" + feeObject.LegalizationFilingFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                        feeObject.PAAFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PAAFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                        feeObject.Tier1CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee);
                    crmTrace.AppendLine("tier1 cost Fee - End" + feeObject.Tier1CostFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier2CostFee))
                        feeObject.Tier2CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier2CostFee);
                    crmTrace.AppendLine("Tier2 Cost Fee - End" + feeObject.Tier2CostFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee) && retrieveFeeCollection.Entities[0][FeeCalculationConfigurationAttributeNames.InConjunctionJobFee] != null && !feeObject.IsConjunction)
                        feeObject.InConjunctionFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<string>(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee));
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.InConjunctionFee);



                    if (feeObject.BuildingType > 0 && feeObject.BuildingType < 4)
                    {
                        #region 123family calculation

                        FilingFeeBasicFormula(targetEntity, service, crmTrace, preImage, feeObject, minFee, 5000); //for MS basic min estimated cost is 5000


                        #endregion
                    }
                    else
                    {
                        FilingFeeBasicFormula(targetEntity, service, crmTrace, preImage, feeObject, minFee, 3000); //for MS basic min estimated cost is 3000

                    }


                    #endregion
                }


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
        }



        /// <summary>
        /// get the fees from the config calculate filing fee and legalization fee based on rules and asssign to fee object
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        public static void CCBuild_FeeCalculation(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            #region Formulae for Construction Fence
            /* Fee is Independent on the Size of the shed field

                Record Management Fee : $45 - 1,2,3 family
                                        $165 - Others

               DOB fee
                 = $130 + (5 * $3)
                = $ 145

               Others DOB fee 
               DOB fee
                 =$130 + (5*$6)
                =$160

                Total Fee = Filing Fee +   Record Management Fee 

                Inconjunction :
                      Filing fee = Filing Fee + 0(Record Management Fee)
        */
            #endregion

            try
            {
                #region set variables

                string formulaeName = string.Empty;
                EntityCollection retrieveFeeCollection = null;
                decimal minFee = 0;
                Entity Curbcut = new Entity();

                #endregion



                {
                    #region Fee Calculation for Construction Fence

                    crmTrace.AppendLine("formulae Name" + formulaeName);
                    formulaeName = BuildFormualeName(targetEntity, preImage, crmTrace, JobFilingEntityAttributeName.BoilersBuildIdentifier, feeObject);

                    Guid CCQuestionnaire = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCQuestionnaire) && targetEntity[JobFilingEntityAttributeName.CCQuestionnaire] != null ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.CCQuestionnaire).Id : (preImage.Attributes.Contains(JobFilingEntityAttributeName.CCQuestionnaire) && preImage[JobFilingEntityAttributeName.CCQuestionnaire] != null) ? preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.CCQuestionnaire).Id : new Guid();

                    if (CCQuestionnaire != Guid.Empty && CCQuestionnaire != null)
                    {
                        crmTrace.AppendLine("Retrieve the curb cut questionnaire id and Size of cut value- Start");
                        Curbcut = service.Retrieve(CurbCutQuestionnaireAttributeNames.EntityLogicalName, CCQuestionnaire, new ColumnSet(new string[] { CurbCutQuestionnaireAttributeNames.SizeofCut }));
                        crmTrace.AppendLine("Retrieve the curb cut questionnaire id and Size of cut value -End");
                    }
                    else
                    {
                        crmTrace.AppendLine("curncut questionaries not present so return");
                        return;
                    }

                    //Get fee calculation configuartion attributes 
                    crmTrace.AppendLine("get fee calculation configuration attributes");
                    retrieveFeeCollection = RetrieveFee(crmTrace, service, formulaeName);


                    WhichEstimatedCost(targetEntity, service, crmTrace, preImage, feeObject);

                    //feeObject.EstimatedCost= (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedCostFinal).Value > 0) || (targetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalizationJobCostFinal) && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostFinal).Value > 0)
                    //Get variables from fee calculation configuration entity
                    crmTrace.AppendLine("Variable Assignments - Start");
                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.MinFilingFee))
                        minFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.MinFilingFee));
                    crmTrace.AppendLine("Variable minFilingFee - End" + feeObject.BEMSSTFilingfee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.RecordManagementFee))
                        feeObject.RecordManagementFees = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.RecordManagementFee));
                    crmTrace.AppendLine("Variable RecordManagementFee - End" + feeObject.RecordManagementFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee))
                        feeObject.LegalizationFilingFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.LegalizationMaxFee);
                    crmTrace.AppendLine("legalizationmultiplier Fee - End" + feeObject.LegalizationFilingFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.PaaFee))
                        feeObject.PAAFees = retrieveFeeCollection.Entities[0].GetAttributeValue<int>(FeeCalculationConfigurationAttributeNames.PaaFee);
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.PAAFees);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.Tier1CostFee))
                        feeObject.Tier1CostFee = retrieveFeeCollection.Entities[0].GetAttributeValue<decimal>(FeeCalculationConfigurationAttributeNames.Tier1CostFee);
                    crmTrace.AppendLine("tier1 cost Fee - End" + feeObject.Tier1CostFee);

                    if (retrieveFeeCollection.Entities[0].Contains(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee) && retrieveFeeCollection.Entities[0][FeeCalculationConfigurationAttributeNames.InConjunctionJobFee] != null)
                        feeObject.InConjunctionFee = Convert.ToDecimal(retrieveFeeCollection.Entities[0].GetAttributeValue<string>(FeeCalculationConfigurationAttributeNames.InConjunctionJobFee));
                    crmTrace.AppendLine("PAA cost Fee - End" + feeObject.InConjunctionFee);


                    if (Curbcut != null && Curbcut.Id != null && Curbcut.Contains(CurbCutQuestionnaireAttributeNames.SizeofCut) && Curbcut[CurbCutQuestionnaireAttributeNames.SizeofCut] != null)
                    {
                        feeObject.BEMSSTFilingfee = (minFee + (Convert.ToDecimal(Curbcut.GetAttributeValue<double>(CurbCutQuestionnaireAttributeNames.SizeofCut)) * feeObject.Tier1CostFee));

                        crmTrace.AppendLine("feeObject.BEMSSTFilingfee - End" + feeObject.BEMSSTFilingfee);

                    }


                    #endregion
                }


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - MSBuild_FeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

                throw ex;
            }
        }


        /// <summary>
        /// This method is used to get all specail inspections for job filing and verify those are all certified or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static bool IsSpecialInspectionsCertified(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {



            try
            {


                EntityCollection specialInspections = new EntityCollection();
                ConditionExpression condition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                specialInspections = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests, SpecialInspectionCategoriesAttributeNames.CertificateOfCompletionStatement }, new ConditionExpression[] { condition }, LogicalOperator.And);
                if (specialInspections != null && specialInspections.Entities.Count > 0)
                {
                    foreach (Entity SpecialInspection in specialInspections.Entities)
                    {
                        if (!(
                            (SpecialInspection.Contains(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests) && SpecialInspection[SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests] != null && SpecialInspection.GetAttributeValue<bool>(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests)) && //icertifytest should be true
                            (SpecialInspection.Contains(SpecialInspectionCategoriesAttributeNames.CertificateOfCompletionStatement) && SpecialInspection[SpecialInspectionCategoriesAttributeNames.CertificateOfCompletionStatement] != null && SpecialInspection.GetAttributeValue<bool>(SpecialInspectionCategoriesAttributeNames.CertificateOfCompletionStatement)) //certifiaction statement should be true
                            )
                            )
                        {
                            crmTrace.AppendLine("ICertifyCompleteInspectionsTests or CertificateOfCompletionStatement anyone of them  may be false");
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine(" No specialInspections found for the jobfiling so return true");
                    return true;

                }





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            crmTrace.AppendLine(" Caught error so returning false");
            return false;
        }


        public static bool IsCoCNeeded(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {



            try
            {


                EntityCollection MSScopeofWorks = new EntityCollection();
                ConditionExpression condition = CreateConditionExpression(MHScopeofworkAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                MSScopeofWorks = RetrieveMultiple(service, MHScopeofworkAttributeNames.EntityLogicalName, new string[] { MHScopeofworkAttributeNames.isCoCNeeded }, new ConditionExpression[] { condition }, LogicalOperator.And);
                if (MSScopeofWorks != null && MSScopeofWorks.Entities.Count > 0)
                {
                    foreach (Entity SpecialInspection in MSScopeofWorks.Entities)
                    {
                        if (
                            (SpecialInspection.Contains(MHScopeofworkAttributeNames.isCoCNeeded) && SpecialInspection[MHScopeofworkAttributeNames.isCoCNeeded] != null && SpecialInspection.GetAttributeValue<bool>(MHScopeofworkAttributeNames.isCoCNeeded))  //icertifytest should be true

                            )

                        {
                            crmTrace.AppendLine("isCoCNeeded Yes");
                            return true;
                        }

                    }
                }
                else
                {
                    crmTrace.AppendLine(" No isCoCNeeded found for the jobfiling so return false");
                    return false;

                }





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsCoCNeeded", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            crmTrace.AppendLine(" Caught error so returning false");
            return false;
        }



        /// <summary>
        /// This method is used to get all TR2TechnicalReport for job filing
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static EntityCollection GetTR2TechnicalReport(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {

            EntityCollection TR3s = new EntityCollection();

            try
            {


                ConditionExpression Tr3condition = new ConditionExpression();

                Entity Tr2Record = new Entity();
                crmTrace.AppendLine("4)get the Tr2 record id");
                Tr3condition = CreateConditionExpression(TR2TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                TR3s = RetrieveMultiple(service, TR2TechnicalReport.EntityLogicalName, new string[] { TR3TechnicalReport.Name }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);






            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

            return TR3s;
        }
        /// <summary>
        /// This method is used to get all TR2TechnicalReport for job filing
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static EntityCollection GetPAARecordforJobFiling(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            EntityCollection PAA = new EntityCollection();

            try
            {


                ConditionExpression PAAcondition1 = new ConditionExpression();
                ConditionExpression PAAcondition2 = new ConditionExpression();
                Entity Tr2Record = new Entity();
                crmTrace.AppendLine("get the PAA records");

                PAAcondition1 = CreateConditionExpression(JobFilingEntityAttributeName.ParentJobFilingAttributeName, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                PAAcondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingStatus, ConditionOperator.NotEqual, new string[] { ((int)CurrentFilingStatus.Approved).ToString() });
                PAA = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { }, new ConditionExpression[] { PAAcondition1, PAAcondition2 }, LogicalOperator.And);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetPAARecordforJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

            return PAA;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity">Tr2TechnicalReport</param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static EntityCollection GetTR2TestReportFromTR2TechnicalReport(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {

            EntityCollection TR3s = new EntityCollection();

            try
            {


                ConditionExpression Tr3condition = new ConditionExpression();

                Entity Tr2Record = new Entity();

                Tr3condition = CreateConditionExpression(TR2TestReport.GotoTr2report, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                TR3s = RetrieveMultiple(service, TR2TestReport.EntityLogicalName, new string[] { TR2TestReport.Name }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);






            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsSpecialInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

            return TR3s;
        }




        /// <summary>
        /// This method will return all tr3mixes associated to jobfiling
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity">jobfiling</param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static EntityCollection GetTR3MixassociatedtoJobFiling(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            EntityCollection Tr3mixs = new EntityCollection();// holds tr3 mix associated to one tr3 director
            EntityCollection TR3s = new EntityCollection();
            ConditionExpression Tr3condition = new ConditionExpression();
            EntityCollection fullTr3mixs = new EntityCollection(); //holds all tr3 mixes 
            try
            {


                //Tr3condition = CreateConditionExpression(TR3TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                //TR3s = RetrieveMultiple(service, TR3TechnicalReport.EntityLogicalName, new string[] { TR3TechnicalReport.Name }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                //crmTrace.AppendLine("TR3s count : " + TR3s.Entities.Count);
                //if (TR3s != null && TR3s.Entities.Count > 0)
                //{
                crmTrace.AppendLine("2) loop through each tr3 and get the Tr3 Directors ");
                //foreach (Entity Tr3 in TR3s.Entities)
                //  {
                Tr3condition = CreateConditionExpression(TR3Director.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection TR3Directors = RetrieveMultiple(service, TR3Director.EntityLogicalName, new string[] { TR3Director.Name, TR3Director.CPBusinessaddesss,
                                TR3Director.CPBusinesCity, TR3Director.CPBusinesFax, TR3Director.CPBusinesName, TR3Director.CPBusinesNameLookup, TR3Director.CPBusinesState, TR3Director.CPBusinesTelephone,
                                TR3Director.CPBusinesZip, TR3Director.CPLicenseLookup, TR3Director.CPName, TR3Director.CPNameLookup, TR3Director.CPDate, TR3Director.NRMCAExpirationDate }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                crmTrace.AppendLine("TR3Directors count : " + TR3Directors.Entities.Count);
                if (TR3Directors != null && TR3Directors.Entities.Count > 0)
                {
                    crmTrace.AppendLine("3) loop through each director and get the Tr3 Mixs and store in one collection ");
                    foreach (Entity Tr3director in TR3Directors.Entities)
                    {
                        Tr3condition = CreateConditionExpression(TR3MixEntityAttribute.GotoTRTechnicalreport, ConditionOperator.Equal, new string[] { Tr3director.Id.ToString() });
                        Tr3mixs = RetrieveMultiple(service, TR3MixEntityAttribute.EntityLogicalName, new string[] { TR3MixEntityAttribute.EntityNameAttribute, TR3MixEntityAttribute.MixType, TR3MixEntityAttribute.SpecifiedStrength, TR3MixEntityAttribute.SpecifiedTestAge }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                        crmTrace.AppendLine("Tr3mixs count : " + Tr3mixs.Entities.Count);
                        foreach (Entity Tr3mix in Tr3mixs.Entities)
                        {
                            crmTrace.AppendLine("add all mixes to one collection");

                            fullTr3mixs.Entities.Add(Tr3mix);


                        }



                    }
                }
                // }
                //}





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTR3MixassociatedtoJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

            return fullTr3mixs;
        }



        /// <summary>
        /// This method is used to get all  job filing details from Tr3 mix
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> TR3 Mix </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static Entity GetJobfilingDetailsFromTR3Mix(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {

            Entity JobFiling = new Entity();

            try
            {

                if (targetEntity.Contains(TR3MixEntityAttribute.GotoTRTechnicalreport) && targetEntity[TR3MixEntityAttribute.GotoTRTechnicalreport] != null)
                {
                    Entity Tr3Director = service.Retrieve(TR3Director.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(TR3MixEntityAttribute.GotoTRTechnicalreport).Id, new ColumnSet(new string[] {TR3Director.Name, TR3Director.CPBusinessaddesss,
                                TR3Director.CPBusinesCity, TR3Director.CPBusinesFax, TR3Director.CPBusinesName, TR3Director.CPBusinesNameLookup, TR3Director.CPBusinesState, TR3Director.CPBusinesTelephone,
                                TR3Director.CPBusinesZip, TR3Director.CPLicenseLookup, TR3Director.CPName, TR3Director.CPNameLookup, TR3Director.CPDate,TR3Director.GotoTR3Technicalreport }));
                    crmTrace.AppendLine("Get the TR3 main details from Tr3 director");
                    if (Tr3Director.Id != null && Tr3Director.Contains(TR3Director.GotoTR3Technicalreport) && Tr3Director[TR3Director.GotoTR3Technicalreport] != null)
                    {

                        crmTrace.AppendLine("Tr3Director Found ");

                        Entity Tr3Main = service.Retrieve(TR3TechnicalReport.EntityLogicalName, Tr3Director.GetAttributeValue<EntityReference>(TR3Director.GotoTR3Technicalreport).Id, new ColumnSet(new string[] {TR3TechnicalReport.GotoJobFiling
                                }));
                        crmTrace.AppendLine("Get the job filing from tr3main");
                        if (Tr3Main.Id != null && Tr3Main.Contains(TR3TechnicalReport.GotoJobFiling) && Tr3Main[TR3TechnicalReport.GotoJobFiling] != null)
                        {
                            crmTrace.AppendLine("Tr3Main Found ");
                            JobFiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, Tr3Main.GetAttributeValue<EntityReference>(TR3TechnicalReport.GotoJobFiling).Id, new ColumnSet(new string[] {JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.IsHistoricJobFiling,JobFilingEntityAttributeName.FilingStatus,JobFilingEntityAttributeName.FilingNumberAttributeName,JobFilingEntityAttributeName.ProjectNumberAttributeName,JobFilingEntityAttributeName.HouseNumber,JobFilingEntityAttributeName.Street,JobFilingEntityAttributeName.ApplicantPerson
                                }));


                        }
                    }
                }







            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetJobfilingDetailsFromTR3Mix", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

            return JobFiling;
        }



        /// <summary>
        /// This method is used to get all specail inspections for job filing and verify those are all certified or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static void CreateTR2TestReport(IOrganizationService service, Entity Tr3mix, Entity Tr3director, Entity Tr2Record, StringBuilder crmTrace)
        {



            try
            {

                #region Create Tr2testReport
                Entity Tr2test = new Entity(TR2TestReport.EntityLogicalName);
                Tr2test.SetAttributeValue(TR2TestReport.Name, "TR2 TEST REPORT");
                crmTrace.AppendLine("SpecifiedStrength");
                Tr2test.SetAttributeValue(TR2TestReport.SpecifiedStrength, Convert.ToInt32(Tr3mix.GetAttributeValue<decimal>(TR3MixEntityAttribute.SpecifiedStrength)));
                crmTrace.AppendLine("SpecifiedTestAge");
                Tr2test.SetAttributeValue(TR2TestReport.SpecifiedTestAge, Convert.ToInt32(Tr3mix.GetAttributeValue<decimal>(TR3MixEntityAttribute.SpecifiedTestAge)));
                crmTrace.AppendLine("GotoTr3mix");
                Tr2test.SetAttributeValue(TR2TestReport.GotoTr3mix, Tr3mix.ToEntityReference());
                crmTrace.AppendLine("Sequence Number");
                Tr2test.SetAttributeValue(TR2TestReport.SequenceNumber, Tr3mix.GetAttributeValue<int>(TR3MixEntityAttribute.SequenceNumber));
                crmTrace.AppendLine("GotoTr2report");
                Tr2test.SetAttributeValue(TR2TestReport.GotoTr2report, Tr2Record.ToEntityReference());
                if (Tr3director.Contains(TR3Director.CPBusinessaddesss) && Tr3director[TR3Director.CPBusinessaddesss] != null)
                {
                    crmTrace.AppendLine("CPBusinessaddesss");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinessaddesss, Tr3director[TR3Director.CPBusinessaddesss]);

                }
                if (Tr3director.Contains(TR3Director.CPBusinesCity) && Tr3director[TR3Director.CPBusinesCity] != null)
                {
                    crmTrace.AppendLine("CPBusinesCity");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesCity, Tr3director[TR3Director.CPBusinesCity]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesFax) && Tr3director[TR3Director.CPBusinesFax] != null)
                {
                    crmTrace.AppendLine("CPBusinesFax");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesFax, Tr3director[TR3Director.CPBusinesFax]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesName) && Tr3director[TR3Director.CPBusinesName] != null)
                {
                    crmTrace.AppendLine("CPBusinesName");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesName, Tr3director[TR3Director.CPBusinesName]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesNameLookup) && Tr3director[TR3Director.CPBusinesNameLookup] != null)
                {
                    crmTrace.AppendLine("CPBusinesNameLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesNameLookup, Tr3director[TR3Director.CPBusinesNameLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesState) && Tr3director[TR3Director.CPBusinesState] != null)
                {
                    crmTrace.AppendLine("CPBusinesState");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesState, Tr3director[TR3Director.CPBusinesState]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesTelephone) && Tr3director[TR3Director.CPBusinesTelephone] != null)
                {
                    crmTrace.AppendLine("CPBusinesTelephone");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesTelephone, Tr3director[TR3Director.CPBusinesTelephone]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesZip) && Tr3director[TR3Director.CPBusinesZip] != null)
                {
                    crmTrace.AppendLine("CPBusinesZip");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesZip, Tr3director[TR3Director.CPBusinesZip]);
                }

                if (Tr3director.Contains(TR3Director.CPLicenseLookup) && Tr3director[TR3Director.CPLicenseLookup] != null)
                {
                    crmTrace.AppendLine("CPLicenseLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPLicenseLookup, Tr3director[TR3Director.CPLicenseLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPName) && Tr3director[TR3Director.CPName] != null)
                {
                    crmTrace.AppendLine("CPName");
                    Tr2test.SetAttributeValue(TR2TestReport.CPName, Tr3director[TR3Director.CPName]);
                }

                if (Tr3director.Contains(TR3Director.CPNameLookup) && Tr3director[TR3Director.CPNameLookup] != null)
                {
                    crmTrace.AppendLine("CPNameLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPNameLookup, Tr3director[TR3Director.CPNameLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPDate) && Tr3director[TR3Director.CPDate] != null)
                {
                    crmTrace.AppendLine("CPDate");
                    Tr2test.SetAttributeValue(TR2TestReport.CPDate, Tr3director[TR3Director.CPDate]);

                }

                if (Tr3director.Contains(TR3Director.NRMCAExpirationDate) && Tr3director[TR3Director.NRMCAExpirationDate] != null)
                {
                    crmTrace.AppendLine("NRMCA Expiration Date");
                    Tr2test.Attributes.Add(TR2TestReport.NRMCAExpirationDate, Tr3director[TR3Director.NRMCAExpirationDate]);

                }
                if (Tr3director.Contains(TR3Director.TR3TrackingNumber) && Tr3director[TR3Director.TR3TrackingNumber] != null)
                {
                    crmTrace.AppendLine("TR3TrackingNumber");
                    Tr2test.Attributes.Add(TR2TestReport.TR3TrackingNumber, Tr3director[TR3Director.TR3TrackingNumber]);

                }

                service.Create(Tr2test);
                #endregion





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

        }

        /// <summary>
        /// This method is used to get all specail inspections for job filing and verify those are all certified or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static void CreateTR2TestReportonPAA(IOrganizationService service, Entity Tr3mix, Entity Tr3director, Entity Tr2Record, StringBuilder crmTrace, Guid TR2record)
        {



            try
            {

                #region Create Tr2testReport
                Entity Tr2test = new Entity(TR2TestReport.EntityLogicalName);
                Tr2test.SetAttributeValue(TR2TestReport.Name, "TR2 TEST REPORT");
                crmTrace.AppendLine("SpecifiedStrength");
                Tr2test.SetAttributeValue(TR2TestReport.SpecifiedStrength, Convert.ToInt32(Tr3mix.GetAttributeValue<decimal>(TR3MixEntityAttribute.SpecifiedStrength)));
                crmTrace.AppendLine("SpecifiedTestAge");
                Tr2test.SetAttributeValue(TR2TestReport.SpecifiedTestAge, Convert.ToInt32(Tr3mix.GetAttributeValue<decimal>(TR3MixEntityAttribute.SpecifiedTestAge)));
                crmTrace.AppendLine("GotoTr3mix");
                Tr2test.SetAttributeValue(TR2TestReport.GotoTr3mix, Tr3mix.ToEntityReference());
                crmTrace.AppendLine("GotoTr2report");
                Tr2test.SetAttributeValue(TR2TestReport.GotoTr2report, new EntityReference(TR2TechnicalReport.EntityLogicalName, TR2record));
                if (Tr3director.Contains(TR3Director.CPBusinessaddesss) && Tr3director[TR3Director.CPBusinessaddesss] != null)
                {
                    crmTrace.AppendLine("CPBusinessaddesss");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinessaddesss, Tr3director[TR3Director.CPBusinessaddesss]);

                }
                if (Tr3director.Contains(TR3Director.CPBusinesCity) && Tr3director[TR3Director.CPBusinesCity] != null)
                {
                    crmTrace.AppendLine("CPBusinesCity");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesCity, Tr3director[TR3Director.CPBusinesCity]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesFax) && Tr3director[TR3Director.CPBusinesFax] != null)
                {
                    crmTrace.AppendLine("CPBusinesFax");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesFax, Tr3director[TR3Director.CPBusinesFax]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesName) && Tr3director[TR3Director.CPBusinesName] != null)
                {
                    crmTrace.AppendLine("CPBusinesName");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesName, Tr3director[TR3Director.CPBusinesName]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesNameLookup) && Tr3director[TR3Director.CPBusinesNameLookup] != null)
                {
                    crmTrace.AppendLine("CPBusinesNameLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesNameLookup, Tr3director[TR3Director.CPBusinesNameLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesState) && Tr3director[TR3Director.CPBusinesState] != null)
                {
                    crmTrace.AppendLine("CPBusinesState");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesState, Tr3director[TR3Director.CPBusinesState]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesTelephone) && Tr3director[TR3Director.CPBusinesTelephone] != null)
                {
                    crmTrace.AppendLine("CPBusinesTelephone");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesTelephone, Tr3director[TR3Director.CPBusinesTelephone]);
                }

                if (Tr3director.Contains(TR3Director.CPBusinesZip) && Tr3director[TR3Director.CPBusinesZip] != null)
                {
                    crmTrace.AppendLine("CPBusinesZip");
                    Tr2test.SetAttributeValue(TR2TestReport.CPBusinesZip, Tr3director[TR3Director.CPBusinesZip]);
                }

                if (Tr3director.Contains(TR3Director.CPLicenseLookup) && Tr3director[TR3Director.CPLicenseLookup] != null)
                {
                    crmTrace.AppendLine("CPLicenseLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPLicenseLookup, Tr3director[TR3Director.CPLicenseLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPName) && Tr3director[TR3Director.CPName] != null)
                {
                    crmTrace.AppendLine("CPName");
                    Tr2test.SetAttributeValue(TR2TestReport.CPName, Tr3director[TR3Director.CPName]);
                }

                if (Tr3director.Contains(TR3Director.CPNameLookup) && Tr3director[TR3Director.CPNameLookup] != null)
                {
                    crmTrace.AppendLine("CPNameLookup");
                    Tr2test.SetAttributeValue(TR2TestReport.CPNameLookup, Tr3director[TR3Director.CPNameLookup]);
                }

                if (Tr3director.Contains(TR3Director.CPDate) && Tr3director[TR3Director.CPDate] != null)
                {
                    crmTrace.AppendLine("CPDate");
                    Tr2test.SetAttributeValue(TR2TestReport.CPDate, Tr3director[TR3Director.CPDate]);

                }

                if (Tr3director.Contains(TR3Director.NRMCAExpirationDate) && Tr3director[TR3Director.NRMCAExpirationDate] != null)
                {
                    crmTrace.AppendLine("NRMCA Expiration Date");
                    Tr2test.Attributes.Add(TR2TestReport.NRMCAExpirationDate, Tr3director[TR3Director.NRMCAExpirationDate]);

                }
                if (Tr3director.Contains(TR3Director.TR3TrackingNumber) && Tr3director[TR3Director.TR3TrackingNumber] != null)
                {
                    crmTrace.AppendLine("TR3TrackingNumber");
                    Tr2test.Attributes.Add(TR2TestReport.TR3TrackingNumber, Tr3director[TR3Director.TR3TrackingNumber]);

                }

                service.Create(Tr2test);
                #endregion





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Tr3mix.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTR2TestReport", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }

        }
        /// <summary>
        /// This method is used to get all progress inspections for job filing and verify those are all certified or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static bool IsProgressInspectionsCertified(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {



            try
            {

                bool finalflag = true;
                EntityCollection specialInspections = new EntityCollection();
                ConditionExpression condition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression condition1 = new ConditionExpression(ProgressInspectionCategoryAttributeNames.InspectionType, ConditionOperator.Equal, 1);
                specialInspections = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, new string[] { ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests, ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement }, new ConditionExpression[] { condition, condition1 }, LogicalOperator.And);
                if (specialInspections != null && specialInspections.Entities.Count > 0)
                {
                    foreach (Entity SpecialInspection in specialInspections.Entities)
                    {
                        crmTrace.AppendLine("specialInspections.Entities" + specialInspections.Entities.Count);
                        if (!(
                            (SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests) && SpecialInspection[ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests)) && //icertifytest should be true
                            (SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement) && SpecialInspection[ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.CertificateOfCompletionStatement)) //certifiaction statement should be true
                            )
                            )
                        {
                            crmTrace.AppendLine("ICertifyCompleteInspectionsTests or CertificateOfCompletionStatement anyone of them  may be false" + SpecialInspection.Id);
                            finalflag = false;
                            return finalflag;
                        }
                        else
                        {
                            finalflag = true;
                        }
                    }
                }

                return finalflag;


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            crmTrace.AppendLine(" Caught error so returning false");
            return false;
        }


        public static bool IsProgressEnergyCodeInspectionsCertified(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {



            try
            {

                bool finalflag = true;
                EntityCollection specialInspections = new EntityCollection();
                ConditionExpression condition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                ConditionExpression condition1 = new ConditionExpression(ProgressInspectionCategoryAttributeNames.InspectionType, ConditionOperator.Equal, 2);
                specialInspections = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, new string[] { ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests, ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionStattement, ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionA, ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionB }, new ConditionExpression[] { condition, condition1 }, LogicalOperator.And);
                if (specialInspections != null && specialInspections.Entities.Count > 0)
                {
                    foreach (Entity SpecialInspection in specialInspections.Entities)
                    {
                        crmTrace.AppendLine("specialInspections.Entities" + specialInspections.Entities.Count);
                        if (!(
                            (SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests) && SpecialInspection[ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests)) && //icertifytest should be true
                            (SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionStattement) && SpecialInspection[ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionStattement] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionStattement)) &&
                            ((SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionA) && SpecialInspection[ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionA] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionA) ||
                            (SpecialInspection.Contains(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionB) && SpecialInspection[ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionB] != null && SpecialInspection.GetAttributeValue<bool>(ProgressInspectionCategoryAttributeNames.EnergyCodeCerificateofCompletionB))) //certifiaction statement should be true
                            )
                            ))
                        {
                            crmTrace.AppendLine("ICertifyCompleteInspectionsTests or CertificateOfCompletionStatement anyone of them  may be false" + SpecialInspection.Id);
                            finalflag = false;
                            return finalflag;
                        }
                        else
                        {
                            finalflag = true;
                        }
                    }
                }
                return finalflag;




            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsProgressInspectionsCertified", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            crmTrace.AppendLine(" Caught error so returning false");
            return false;
        }


        /// <summary>
        /// This method is used to get all TR2 inspections for job filing and verify those are all Ready for signoff or not
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"> Job Filing </param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <returns></returns>
        public static bool IsTR2InspectionsReadyforSignoff(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {



            try
            {


                EntityCollection specialInspections = new EntityCollection();
                ConditionExpression condition = CreateConditionExpression(TR2TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                specialInspections = RetrieveMultiple(service, TR2TechnicalReport.EntityLogicalName, new string[] { TR2TechnicalReport.isAllConcreteWorkDone, TR2TechnicalReport.isJobReadyForSignOff }, new ConditionExpression[] { condition }, LogicalOperator.And);
                if (specialInspections != null && specialInspections.Entities.Count > 0)
                {
                    foreach (Entity SpecialInspection in specialInspections.Entities)
                    {
                        if (!(
                            (SpecialInspection.Contains(TR2TechnicalReport.isAllConcreteWorkDone) && SpecialInspection[TR2TechnicalReport.isAllConcreteWorkDone] != null && SpecialInspection.GetAttributeValue<bool>(TR2TechnicalReport.isAllConcreteWorkDone)) && //icertifytest should be true
                            (SpecialInspection.Contains(TR2TechnicalReport.isJobReadyForSignOff) && SpecialInspection[TR2TechnicalReport.isJobReadyForSignOff] != null && SpecialInspection.GetAttributeValue<bool>(TR2TechnicalReport.isJobReadyForSignOff)) //certifiaction statement should be true
                            )
                            )
                        {
                            crmTrace.AppendLine("isAllConcreteWorkDone : " + (SpecialInspection.Contains(TR2TechnicalReport.isAllConcreteWorkDone) && SpecialInspection[TR2TechnicalReport.isAllConcreteWorkDone] != null ? SpecialInspection.GetAttributeValue<bool>(TR2TechnicalReport.isAllConcreteWorkDone) : false));
                            crmTrace.AppendLine("isJobReadyForSignOff : " + (SpecialInspection.Contains(TR2TechnicalReport.isJobReadyForSignOff) && SpecialInspection[TR2TechnicalReport.isJobReadyForSignOff] != null ? SpecialInspection.GetAttributeValue<bool>(TR2TechnicalReport.isJobReadyForSignOff) : false));
                            crmTrace.AppendLine("isAllConcreteWorkDone or isJobReadyForSignOff anyone of them  may be false");
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    crmTrace.AppendLine(" No TR2 Inspections found for the jobfiling so return true");
                    return true;

                }





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));


            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - IsTR2InspectionsReadyforSignoff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);


            }
            crmTrace.AppendLine(" Caught error so returning false");
            return true;
        }




        /// <summary>
        /// this function can be used to calculate filing fee which has following formula 
        ///  feeObject.BEMSSTFilingfee = minFee + (how many thousands * feeObject.Tier1CostFee);
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="serviceConnector"></param>
        /// <param name="customTrace"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="feeObject"></param>


        public static void FilingFeeBasicFormula(Entity targetEntity, IOrganizationService serviceConnector, StringBuilder crmTrace, Entity preTargetEntity, FeeCalculationObject feeObject, decimal minFee, decimal minimumEstimatedCost)
        {
            try
            {
                decimal diffJobCost = 0;
                #region 123family calculation
                if (feeObject.EstimatedCost > minimumEstimatedCost)
                {
                    crmTrace.AppendLine("Fee Calculation formulae - ongoing");
                    diffJobCost = Math.Ceiling((feeObject.EstimatedCost - minimumEstimatedCost) / 1000);
                }

                if (feeObject.EstimatedCost <= minimumEstimatedCost && feeObject.EstimatedCost != 0)
                {
                    crmTrace.AppendLine("feeObject.EstimatedCost <= minimumEstimatedCost && feeObject.EstimatedCost != 0");
                    feeObject.BEMSSTFilingfee = minFee;

                }
                else if (feeObject.EstimatedCost > minimumEstimatedCost)
                {
                    crmTrace.AppendLine("feeObject.EstimatedCost > minimumEstimatedCost");
                    crmTrace.AppendLine("feeObject.Tier1CostFee" + feeObject.Tier1CostFee);
                    crmTrace.AppendLine("minFee" + minFee);
                    crmTrace.AppendLine("diffJobCost" + diffJobCost);
                    if (minFee > 0 && feeObject.Tier1CostFee > 0)
                    {
                        crmTrace.AppendLine("Entered minFee > 0 && feeObject.Tier1CostFee > 0");
                        if (feeObject.BuildingType == 4)
                        {
                            //  diffJobCost = Math.Ceiling((feeObject.EstimatedCost - minimumEstimatedCost) / 1000);

                            if (diffJobCost <= 2)
                            {
                                crmTrace.AppendLine("diffJobCost <= 2");
                                feeObject.BEMSSTFilingfee = minFee + (diffJobCost * feeObject.Tier1CostFee);
                            }
                            else if (diffJobCost > 2)
                            {
                                crmTrace.AppendLine("diffJobCost > 2");

                                if (feeObject.IsSP || feeObject.IsPL || feeObject.IsSD || feeObject.IsAN)
                                {
                                    crmTrace.AppendLine("feeObject.IsSP || feeObject.IsPL || feeObject.IsSD || feeObject.IsAN");

                                    feeObject.BEMSSTFilingfee = minFee + (2 * feeObject.Tier1CostFee) + ((diffJobCost - 2) * feeObject.Tier2CostFee);
                                }
                                else if (feeObject.IsMS || feeObject.IsST || feeObject.IsBE)
                                {
                                    crmTrace.AppendLine("feeObject.IsMS || feeObject.IsST");

                                    feeObject.BEMSSTFilingfee = minFee + (diffJobCost * feeObject.Tier1CostFee);
                                }
                            }

                        }
                        else
                        {
                            crmTrace.AppendLine("feeObject.BuildingType != 4 ");
                            feeObject.BEMSSTFilingfee = minFee + (diffJobCost * feeObject.Tier1CostFee);

                        }
                    }

                }
                else if (feeObject.EstimatedCost == 0)
                {
                    crmTrace.AppendLine("Estimated Job Cost is 0 -  Start ");
                    feeObject.BEMSSTFilingfee = 0;

                }
                #endregion

                crmTrace.AppendLine("feeObject.EstimatedCost" + feeObject.EstimatedCost + "feeObject.BEMSSTFilingfee" + feeObject.BEMSSTFilingfee);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - FilingFeeBasicFormula", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }


        }



        /// <summary>
        /// This method will set the estimated cost on fee object based on scenario
        ///  1) New filing :estimated job cost
        ///  2)Legalization: estimated  job cost legal
        ///  3)LOC new filing :Estimated job cost final
        ///  4)LOC Legalization :Estimated jobal Cost Legal
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="serviceConnector"></param>
        /// <param name="customTrace"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="feeObject"></param>

        public static void WhichEstimatedCost(Entity targetEntity, IOrganizationService serviceConnector, StringBuilder customTrace, Entity preTargetEntity, FeeCalculationObject feeObject)
        {
            try
            {
                customTrace.AppendLine("WhichEstimatedCost method Statrted");
                if (feeObject.IsLegalization)
                {

                    if (feeObject.JobStatus == (int)JobStatus.LOCRequested || feeObject.FilingStatus == (int)CurrentFilingStatus.PermitEntire)
                    {
                        customTrace.AppendLine("LOC Estimated Cost Statrted");
                        customTrace.AppendLine("LOC Legalization Estimated Cost ");
                        feeObject.EstimatedCost = targetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost) && targetEntity[JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost) && preTargetEntity[JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost] != null ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalWorkFinalCost).Value : 0;


                    }
                    else
                    {
                        customTrace.AppendLine(" Legalization Estimated Cost ");
                        feeObject.EstimatedCost = targetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName) && targetEntity[JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName) && preTargetEntity[JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName] != null ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedLegalizationJobCostAtributeName).Value : 0;
                    }

                }
                else
                {
                    if (feeObject.JobStatus == (int)JobStatus.LOCRequested || feeObject.FilingStatus == (int)CurrentFilingStatus.PermitEntire)
                    {
                        customTrace.AppendLine("LOC normal Estimated Cost ");
                        feeObject.EstimatedCost = targetEntity.Contains(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost) && targetEntity[JobFilingEntityAttributeName.EstimatedNewWorkFinalCost] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost) && preTargetEntity[JobFilingEntityAttributeName.EstimatedNewWorkFinalCost] != null ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost).Value : 0;
                    }
                    else
                    {
                        customTrace.AppendLine(" normal Estimated Cost ");
                        feeObject.EstimatedCost = targetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostAttributeName) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCostAttributeName] != null ? targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCostAttributeName).Value : preTargetEntity.Contains(JobFilingEntityAttributeName.EstimatedJobCostAttributeName) && preTargetEntity[JobFilingEntityAttributeName.EstimatedJobCostAttributeName] != null ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCostAttributeName).Value : 0;
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - WhichEstimatedCost", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }


        }






        public static Guid CreateUpdatePaymentHistoryRecord(IOrganizationService service, Entity targetEntity, Entity PreImage, string PHCreateUpdate, bool IsPaymentPosted, StringBuilder crmTrace, decimal AmountDue)
        {
            try
            {
                Guid paymenthistory = new Guid();


                if (PHCreateUpdate == "Create")
                {
                    string jobNumber = string.Empty;
                    Entity paymentHistory = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                    EntityReference jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                        jobNumber = targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();
                    crmTrace.AppendLine("create CreateUpdatePaymentHistoryRecord  - start");
                    paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])).ToString())))
                            paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));
                    if (IsPaymentPosted)
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                    if (targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                            if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])).ToString())))
                                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.ParentJobFilng, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])));

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.BuildingType, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType));
                    }
                    crmTrace.AppendLine("IsPosted : " + paymentHistory.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted));
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                    {
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.EstimatedJobCost, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost));
                    }
                    paymenthistory = service.Create(paymentHistory);
                    targetEntity.SetAttributeValue(JobFilingEntityAttributeName.PaymentHistoryGUID, paymenthistory.ToString());
                }
                else if (PHCreateUpdate == "Update")
                {
                    string PaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : PreImage.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID);
                    Entity ExistingPH = service.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(true));
                    string jobNumber = string.Empty;
                    EntityReference jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                        jobNumber = targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName].ToString();
                    crmTrace.AppendLine("Update CreateUpdatePaymentHistoryRecord  - start");
                    ExistingPH.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    //   ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                        if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])).ToString())))
                            ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField])));
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.FilingFees));
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));

                    if (IsPaymentPosted)
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.IsPosted, true);


                    if (targetEntity.Attributes.Contains(FeeTypeName.IsPaa))
                        if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName))
                            if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])).ToString())))
                                ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.ParentJobFilng, ((EntityReference)(targetEntity.Attributes[JobFilingEntityAttributeName.ParentJobFilingAttributeName])));

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType) && targetEntity[JobFilingEntityAttributeName.BuildingType] != null)
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.BuildingType, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType));
                    }

                    if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost) && targetEntity[JobFilingEntityAttributeName.EstimatedJobCost] != null)
                    {
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.EstimatedJobCost, targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.EstimatedJobCost));
                    }
                    service.Update(ExistingPH);
                    paymenthistory = new Guid(PaymentHistoryGUID);
                    targetEntity.SetAttributeValue(JobFilingEntityAttributeName.PaymentHistoryGUID, paymenthistory.ToString());
                }
                crmTrace.AppendLine("create  Payment History Record - End");
                return paymenthistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //  throw ex;
                return new Guid();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
                return new Guid();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreatePaymentHistoryRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
                return new Guid();
            }
        }



        public static Guid CreateUpdatePaymentHistoryRecordOp49(IOrganizationService service, Entity targetEntity, Entity PreImage, string PHCreateUpdate, bool IsPaymentPosted, StringBuilder crmTrace, decimal AmountDue)
        {
            try
            {
                Guid paymenthistory = new Guid();


                if (PHCreateUpdate == "Create")
                {
                    string jobNumber = string.Empty;
                    Entity paymentHistory = new Entity(PaymentHistoryAttributeNames.EntityLogicalName);
                    EntityReference jobFilingIdReference = new EntityReference(OP49EntityAttributeNames.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(OP49EntityAttributeNames.Name))
                        jobNumber = targetEntity.Attributes[OP49EntityAttributeNames.Name].ToString();
                    crmTrace.AppendLine("create CreateUpdatePaymentHistoryRecord  - start");
                    paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.GoToOP49, jobFilingIdReference);

                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.OP49Fees));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));
                    if (IsPaymentPosted)
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);

                    paymenthistory = service.Create(paymentHistory);
                    targetEntity.SetAttributeValue(OP49EntityAttributeNames.PhGuid, paymenthistory.ToString());

                }
                else if (PHCreateUpdate == "Update")
                {
                    string PaymentHistoryGUID = targetEntity.Attributes.Contains(OP49EntityAttributeNames.PhGuid) ? targetEntity.GetAttributeValue<string>(OP49EntityAttributeNames.PhGuid) : PreImage.GetAttributeValue<string>(OP49EntityAttributeNames.PhGuid);
                    Entity ExistingPH = service.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(true));
                    string jobNumber = string.Empty;
                    EntityReference jobFilingIdReference = new EntityReference(OP49EntityAttributeNames.EntityLogicalName, targetEntity.Id);
                    if (targetEntity.Contains(OP49EntityAttributeNames.Name))
                        jobNumber = targetEntity.Attributes[OP49EntityAttributeNames.Name].ToString();
                    crmTrace.AppendLine("Update CreateUpdatePaymentHistoryRecord  - start");
                    ExistingPH.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.JobNumber, jobNumber);
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.GoToOP49, jobFilingIdReference);

                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.OP49Fees));
                    ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.TotalFees, new Money(AmountDue));
                    if (IsPaymentPosted)
                        ExistingPH.SetAttributeValue(PaymentHistoryAttributeNames.IsPosted, true);
                    service.Update(ExistingPH);
                    paymenthistory = new Guid(PaymentHistoryGUID);
                    targetEntity.SetAttributeValue(OP49EntityAttributeNames.PhGuid, paymenthistory.ToString());
                }
                crmTrace.AppendLine("create  Payment History Record - End");
                return paymenthistory;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //  throw ex;
                return new Guid();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
                return new Guid();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateUpdatePaymentHistoryRecordOp49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
                return new Guid();
            }
        }




        /// <summary>
        /// This method used to create Payment History and Transaction History based on fees calculated
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <param name="feeObject"></param>
        public static void AfterFeeCalculation(Entity targetEntity, string PaymentHistoryGUID, IOrganizationService serviceConnector, StringBuilder customTrace, Entity preTargetEntity, FeeCalculationObject feeObject)
        {
            try
            {
                customTrace.AppendLine("AfterFeeCalculation started!!! ");
                #region payment History


                PaymentHistoryGUID = targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) && targetEntity[JobFilingEntityAttributeName.PaymentHistoryGUID] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID) && preTargetEntity[JobFilingEntityAttributeName.PaymentHistoryGUID] != null ? preTargetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.PaymentHistoryGUID) : string.Empty;
                customTrace.AppendLine("PaymentHistoryGUID ");
                if (feeObject.amountDue > 0 || feeObject.Adjustment > 0)
                {
                    #region PH Guid Present
                    if (PaymentHistoryGUID != null && !string.IsNullOrEmpty(PaymentHistoryGUID))
                    {
                        Entity PH = serviceConnector.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(PaymentHistoryAttributeNames.IsPosted, PaymentHistoryAttributeNames.NoGoodCheckFlag));


                        if (PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted) == true || PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.NoGoodCheckFlag) == true)
                        {
                            customTrace.AppendLine("PaymentHistoryGUID present is already posted so create new");
                            //create newPH
                            PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecord(serviceConnector, targetEntity, preTargetEntity, "Create", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                        }
                        else
                        {
                            //update the paymenthistory
                            customTrace.AppendLine("Delete the TH's so that new TH can be added");
                            #region Delete and recreate Transaction Histories for existing PH
                            string fetch = string.Format(FetchXml.GetTransactionHistorytoDelete, PaymentHistoryGUID);
                            EntityCollection TH_response = serviceConnector.RetrieveMultiple(new FetchExpression(fetch));
                            if (TH_response.Entities.Count > 0)
                            {
                                for (int i = 0; i <= TH_response.Entities.Count - 1; i++)
                                {
                                    serviceConnector.Delete(TransactionHistoryAttributeNames.EntityLogicalName, (Guid)TH_response.Entities[i].Attributes[TransactionHistoryAttributeNames.TransactionHistoryId]);
                                }
                            }
                            #endregion
                            customTrace.AppendLine("PaymentHistoryGUID present is not posted so update old pH");
                            PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecord(serviceConnector, targetEntity, preTargetEntity, "Update", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                        }

                    }
                    #endregion

                    #region No PH Guid
                    else
                    {
                        customTrace.AppendLine("PaymentHistoryGUID is not present so create new");
                        PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecord(serviceConnector, targetEntity, preTargetEntity, "Create", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                    }
                    #endregion

                    #region Transaction History
                    customTrace.AppendLine("create TH for the PH above");
                    FeeCalculationStandardizationHandler.CreateFAB4TransactionHistoryRecords(targetEntity, new Guid(PaymentHistoryGUID), serviceConnector, customTrace, preTargetEntity, feeObject);
                    #endregion

                }

                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }


        }



        /// <summary>
        /// This method used to create Payment History and Transaction History based on fees calculated for OP49
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <param name="feeObject"></param>
        public static void AfterFeeCalculationOP49(Entity targetEntity, string PaymentHistoryGUID, IOrganizationService serviceConnector, StringBuilder customTrace, Entity preTargetEntity, FeeCalculationObject feeObject)
        {
            try
            {
                customTrace.AppendLine("AfterFeeCalculationOP49 started!!! ");
                #region payment History


                PaymentHistoryGUID = targetEntity.Attributes.Contains(OP49EntityAttributeNames.PhGuid) && targetEntity[OP49EntityAttributeNames.PhGuid] != null ? targetEntity.GetAttributeValue<string>(OP49EntityAttributeNames.PhGuid) : preTargetEntity.Attributes.Contains(OP49EntityAttributeNames.PhGuid) && preTargetEntity[OP49EntityAttributeNames.PhGuid] != null ? preTargetEntity.GetAttributeValue<string>(OP49EntityAttributeNames.PhGuid) : string.Empty;
                customTrace.AppendLine("PaymentHistoryGUID ");
                if (feeObject.amountDue > 0 || feeObject.Adjustment > 0)
                {
                    #region PH Guid Present
                    if (PaymentHistoryGUID != null && !string.IsNullOrEmpty(PaymentHistoryGUID))
                    {
                        Entity PH = serviceConnector.Retrieve(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(PaymentHistoryGUID), new ColumnSet(PaymentHistoryAttributeNames.IsPosted, PaymentHistoryAttributeNames.NoGoodCheckFlag));


                        if (PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.IsPosted) == true || PH.GetAttributeValue<bool>(PaymentHistoryAttributeNames.NoGoodCheckFlag) == true)
                        {
                            customTrace.AppendLine("PaymentHistoryGUID present is already posted so create new");
                            //create newPH
                            //PHPostedFlag
                            PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecordOp49(serviceConnector, targetEntity, preTargetEntity, "Create", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                        }
                        else
                        {
                            //update the paymenthistory
                            customTrace.AppendLine("Delete the TH's so that new TH can be added");
                            #region Delete and recreate Transaction Histories for existing PH
                            string fetch = string.Format(FetchXml.GetTransactionHistorytoDelete, PaymentHistoryGUID);
                            EntityCollection TH_response = serviceConnector.RetrieveMultiple(new FetchExpression(fetch));
                            if (TH_response.Entities.Count > 0)
                            {
                                for (int i = 0; i <= TH_response.Entities.Count - 1; i++)
                                {
                                    serviceConnector.Delete(TransactionHistoryAttributeNames.EntityLogicalName, (Guid)TH_response.Entities[i].Attributes[TransactionHistoryAttributeNames.TransactionHistoryId]);
                                }
                            }
                            #endregion
                            customTrace.AppendLine("PaymentHistoryGUID present is not posted so update old pH");
                            PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecordOp49(serviceConnector, targetEntity, preTargetEntity, "Update", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                        }

                    }
                    #endregion

                    #region No PH Guid
                    else
                    {
                        customTrace.AppendLine("PaymentHistoryGUID is not present so create new");
                        PaymentHistoryGUID = FeeCalculationStandardizationHandler.CreateUpdatePaymentHistoryRecordOp49(serviceConnector, targetEntity, preTargetEntity, "Create", feeObject.PHPostedFlag, customTrace, feeObject.amountDue).ToString();
                    }
                    #endregion

                    #region Transaction History
                    customTrace.AppendLine("create TH for the PH above");
                    FeeCalculationStandardizationHandler.CreateFAB4TransactionHistoryRecordsOp49(targetEntity, new Guid(PaymentHistoryGUID), serviceConnector, customTrace, preTargetEntity, feeObject);
                    #endregion

                }

                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AfterFeeCalculationOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }


        }



        /// <summary>
        /// to calculate adjustment  on file on corrections completed and LOC requested
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="PaymentHistoryGUID"></param>
        /// <param name="serviceConnector"></param>
        /// <param name="customTrace"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="feeObject"></param>
        public static void OnFileCorrectionsCompletedLOCRequested(Entity targetEntity, IOrganizationService serviceConnector, StringBuilder customTrace, Entity preTargetEntity, FeeCalculationObject feeObject)
        {
            try
            {
                customTrace.AppendLine("OnFileCorrectionsCompletedLOCRequested started!!! ");

                #region On File -isSubmitted YES 
                // for setting temporary adjustment to final adjustment on filing
                if (
                    (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true)//Normal preview to file Adjustment
                    || (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && preTargetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true) //Correction Submission Adjustment

                    || (targetEntity.Contains(JobFilingEntityAttributeName.JobStatus) && targetEntity[JobFilingEntityAttributeName.JobStatus] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value == (int)JobStatus.LOCRequested)//LOC Final Job cost .--Adjustment
                    )
                {

                    customTrace.AppendLine("target entity submitted" + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) + "Pretarget corrections :" + preTargetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) + "target corrections " + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted));
                    customTrace.AppendLine("On File  -Start");
                    #region  Fee Calculation File- Setting Adjustment Values
                    feeObject.Adjustment = preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.Refund) && preTargetEntity[JobFilingEntityAttributeName.Refund] != null && preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value > 0 ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.Refund).Value : 0;
                    customTrace.AppendLine("Get Adjustment Final  :" + feeObject.Adjustment);
                    feeObject.ExistingAmountPaid = preTargetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid) && preTargetEntity[JobFilingEntityAttributeName.AmountPaid] != null && preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value > 0 ? preTargetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AmountPaid).Value : 0;
                    customTrace.AppendLine("Get ExistingAmountPaid Final  :" + feeObject.ExistingAmountPaid);

                    if (feeObject.Adjustment != 0)
                    {
                        customTrace.AppendLine("On File  SET Adjustment -Start");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AdjustmentFinal, new Money(feeObject.Adjustment));//this field will be cleared by refund email workflow.As they configured email on this field
                        customTrace.AppendLine("set amount paid = prev amount paid- refund");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.AmountPaid, new Money(feeObject.ExistingAmountPaid - feeObject.Adjustment));
                        feeObject.PHPostedFlag = true;

                        customTrace.AppendLine("On File  SET Adjustment -END");
                    }
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.Refund, new Money(decimal.Parse("0")));
                    customTrace.AppendLine("On File  -END");
                    #endregion

                }
                #endregion


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedLOCRequested", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }


        }


        /// <summary>
        /// to calculate adjustment  on file on corrections completed and LOC requested
        /// </summary>
        /// <param name="targetEntity"></param>
        /// <param name="PaymentHistoryGUID"></param>
        /// <param name="serviceConnector"></param>
        /// <param name="customTrace"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="feeObject"></param>
        public static void OnFileCorrectionsCompletedOP49(Entity targetEntity, IOrganizationService serviceConnector, StringBuilder customTrace, Entity preTargetEntity, FeeCalculationObject feeObject)
        {
            try
            {
                customTrace.AppendLine("OnFileCorrectionsCompletedLOCRequested started!!! ");

                #region On File -isSubmitted YES 
                // for setting temporary adjustment to final adjustment on filing
                if ((targetEntity.Attributes.Contains(OP49EntityAttributeNames.IsSubmitted) && targetEntity[OP49EntityAttributeNames.IsSubmitted] != null && targetEntity.GetAttributeValue<bool>(OP49EntityAttributeNames.IsSubmitted) == true))//Normal preview to file Adjustment)
                {

                    customTrace.AppendLine("On File  -Start");
                    #region  Fee Calculation File- Setting Adjustment Values
                    feeObject.Adjustment = preTargetEntity.Attributes.Contains(OP49EntityAttributeNames.Refund) && preTargetEntity[OP49EntityAttributeNames.Refund] != null && preTargetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.Refund).Value > 0 ? preTargetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.Refund).Value : 0;
                    customTrace.AppendLine("Get Adjustment Final  :" + feeObject.Adjustment);
                    feeObject.ExistingAmountPaid = preTargetEntity.Attributes.Contains(OP49EntityAttributeNames.AmountPaid) && preTargetEntity[OP49EntityAttributeNames.AmountPaid] != null && preTargetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountPaid).Value > 0 ? preTargetEntity.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountPaid).Value : 0;
                    customTrace.AppendLine("Get ExistingAmountPaid Final  :" + feeObject.ExistingAmountPaid);
                    if (feeObject.Adjustment != 0)
                    {

                        customTrace.AppendLine("set amount paid = prev amount paid- refund");
                        CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.AmountPaid, new Money(feeObject.ExistingAmountPaid - feeObject.Adjustment));
                        feeObject.PHPostedFlag = true;

                        customTrace.AppendLine("On File  SET Adjustment -END");
                    }
                    CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.Refund, new Money(decimal.Parse("0")));
                    customTrace.AppendLine("On File  -END");
                    #endregion

                }
                #endregion


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - OnFileCorrectionsCompletedOP49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                // throw ex;
            }


        }







        /// <summary>
        /// This function has all the conditions for when a particular transaction histrory should create and associate it to PH
        /// </summary>
        /// <param name="SharedVariables"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        ///
        /// <returns></returns>

        public static void CreateFAB4TransactionHistoryRecords(Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace, Entity preImage, FeeCalculationObject feeObject)
        {
            try
            {

                /// ALL PAA Conditions will fall under existing amount paid has value and amount due is greater than zero.

                #region User does not pay anything till now

                if (feeObject.ExistingAmountPaid == 0)
                {


                    createTransactionHistoryUserPaidZeroAmount(service, targetEntity, crmTrace, feeObject, paymentHistoryId);

                    //  for adjustment
                    if ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted) && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true && feeObject.Adjustment > 0)//Preview to file Adjustment
                        || (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted) && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true && feeObject.Adjustment > 0)//Correction Resubmission Adjustment
                        || (targetEntity.Contains(JobFilingEntityAttributeName.JobStatus) && targetEntity[JobFilingEntityAttributeName.JobStatus] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value == (int)JobStatus.LOCRequested && preImage.Attributes.Contains(JobFilingEntityAttributeName.Sign) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true && feeObject.Adjustment > 0)//LOC Signs Submission portal will not send Signs work type flag so using preimage.--Adjustment scenario
                        )
                    {
                        crmTrace.AppendLine("Condition Expression for Adjustment");
                        transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.Adjustment, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }
                    //fee exempt PAA
                    if (feeObject.PAAFees > 0 && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    {
                        //do not add paa TH to PH if application has any PH  with is posted true because they paid initially.
                        if (!isPostedPaymentHistories(service, crmTrace, targetEntity))
                        {

                            if (feeObject.amountDue > 0 && feeObject.amountDue < 100) //IN PAA amount due is <100 because he decreased the estimated cost then amount due results in value less than 100 $
                            {
                                //when Amount Due <100 in PAA then we have to add two TH's 1)PAA-$100 2)Overage Payment- $(100-amount due)
                                crmTrace.AppendLine("Condition Expression for PAA FEE");
                                transactionHistoryHelper(Fab4_TransactionCodes.PAA, new decimal(100), targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for PAA FEE-End");

                                feeObject.amountDue = 100 - feeObject.amountDue;
                                crmTrace.AppendLine("set amount due for overage pament" + feeObject.amountDue);
                                crmTrace.AppendLine("Condition Expression for Overage payment  FEE");
                                transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for Overage payment FEE-End");

                                feeObject.amountDue = 0;//clear the amount due after setting in PAA FEE
                            }
                            else
                            {
                                crmTrace.AppendLine("Condition Expression for PAA FEE");
                                transactionHistoryHelper(Fab4_TransactionCodes.PAA, feeObject.PAAFees, targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for PAA FEE-End");
                            }




                        }

                    }
                }

                #endregion

                #region user Paid some Amount
                else if (feeObject.ExistingAmountPaid > 0)
                {

                    crmTrace.AppendLine("user Paid some Amount" + feeObject.amountDue);


                    //If user needs to pay some amount because of adding new work type or chnaging size of shed
                    if (feeObject.amountDue > 0)
                    {

                        decimal amountDue = feeObject.amountDue;
                        crmTrace.AppendLine("If user needs to pay some amount because of adding new work type or chnaging size of shed");

                        ///for CT,SS,Record MGMT Fee (Based on inconjunction flag) transaction codes only added when preimage is null or false and target entity is true
                        ///For SWS Two cases
                        ///1)Is SWS is newely added i.e.preimage is null or false and target is true
                        ///2)size of shed is changed -Check preimage and target then subtract
                        ///

                        ///1)check job type is paa and paa fee >0
                        ///if yes then check any payment posted flags are present if yes then do not create TH for PAA if no  then create one.
                        ///
                        //This will execute  only when PAA has fee and filingtype is PAA

                        if (feeObject.PAAFees > 0 && targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        {
                            //do not add paa TH to PH if application has any PH  with is posted true because they paid initially.
                            crmTrace.AppendLine("do not add paa TH to PH if application has any PH  with is posted true because they paid initially.");

                            if (!isPostedPaymentHistories(service, crmTrace, targetEntity))
                            {


                                #region PAA Transaction Code Login when amount due is less than 100 for sign work type
                                if (feeObject.amountDue > 0 && feeObject.amountDue < 100)//IN PAA amount due is <100 because he decreased the estimated cost then amount due results in value less than 100 $
                                {
                                    //when Amount Due <100 in PAA then we have to add two TH's 1)PAA-$100 2)Overage Payment- $(100-amount due)
                                    crmTrace.AppendLine("Condition Expression for PAA FEE");
                                    transactionHistoryHelper(Fab4_TransactionCodes.PAA, new decimal(100), targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for PAA FEE-End");

                                    amountDue = 100 - amountDue;

                                    crmTrace.AppendLine("set amount due for overage pament" + amountDue);
                                    crmTrace.AppendLine("Condition Expression for Overage payment Signs  FEE");
                                    transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for Overage payment FEE Signs-End");

                                    amountDue = 0;//clear the amount due after setting in PAA FEE
                                }
                                else
                                {
                                    crmTrace.AppendLine("Condition Expression for PAA FEE");
                                    transactionHistoryHelper(Fab4_TransactionCodes.PAA, feeObject.PAAFees, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for PAA FEE-End");
                                    amountDue = amountDue - feeObject.PAAFees;
                                }
                                #endregion




                            }
                            #region PAA Fee Exempt to Non Fee Exempt

                            if (preImage.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) == false)
                            {

                                createTransactionHistoryUserPaidZeroAmount(service, targetEntity, crmTrace, feeObject, paymentHistoryId);
                                amountDue = 0;
                                // throw new Exception(" PreImage" + preImage.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) + "targetEntity.Contains(Jo" + targetEntity.Contains(JobFilingEntityAttributeName.IsFeeExemptAttributename) + "targetEntity.GetAttributeValue<bool>" + targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) + "preimage value" + preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFeeExemptAttributename) + "feeObject.AmountDue" + feeObject.AmountDue);
                            }
                            #endregion

                        }

                        #region Legalization and Normal Job

                        #region legal job- Amount due is split between record mgmt fee and legal fee
                        if (feeObject.IsLegalization && amountDue > 0)
                        {
                            //Newly Added inconjumction Flag
                            if (preImage.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) == false)
                            {
                                if (feeObject.RecordManagementFees > 0 && feeObject.RecordManagementFees == 45 && amountDue > 0)//for 123 family
                                {
                                    //create trans history for RecordMGMT
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_123family, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-End");
                                    amountDue = amountDue - feeObject.RecordManagementFees;
                                }
                                else if (feeObject.RecordManagementFees > 0 && feeObject.RecordManagementFees == 165 && amountDue > 0)//for others
                                {
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT Other after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_Others, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                    amountDue = amountDue - feeObject.RecordManagementFees;
                                }

                            }
                            if (amountDue > 0)
                            {
                                if (feeObject.BuildingType == 1 || feeObject.BuildingType == 2)
                                {
                                    crmTrace.AppendLine("Create Transaction History for Legalization  after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.ST, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for Legalization  after amount paid-Start");
                                }
                                else
                                {
                                    crmTrace.AppendLine("Create Transaction History for Legalization  after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.ST, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for Legalization  after amount paid-Start");
                                }


                                amountDue = 0;
                            }
                        }

                        #endregion

                        #region Normal Job-Splits amount to different worktypes
                        else
                        {
                            crmTrace.AppendLine("Normal Job-Splits amount to different worktypes");

                            #region CF,SF,RecordMGMT
                            if (preImage.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && targetEntity.Attributes.Contains(JobFilingEntityAttributeName.InConjunctionFlag) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) != targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.InConjunctionFlag) == false)
                            {
                                if (feeObject.RecordManagementFees > 0 && feeObject.RecordManagementFees == 45 && amountDue > 0)//for 123 family
                                {
                                    //create trans history for RecordMGMT
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_123family, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-End");
                                    amountDue = amountDue - feeObject.RecordManagementFees;
                                }
                                else if (feeObject.RecordManagementFees > 0 && feeObject.RecordManagementFees == 165 && amountDue > 0)//for others
                                {
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT Other after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_Others, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for RecordMGMT 123 after amount paid-Start");
                                    amountDue = amountDue - feeObject.RecordManagementFees;
                                }

                            }

                            if (feeObject.IsBE)
                            {
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for BE after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.BE, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for BE after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }

                            }
                            #region added for GC
                            else if ((feeObject.IsMS && feeObject.IsGC) || (feeObject.IsST && feeObject.IsGC) || feeObject.IsGC)
                            {
                                //this might change once requirement is fianlized.
                                //any filing combined with GC or individual GC should use GC transaction code
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for MS after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.GC, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for MS after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }


                            }
                            #endregion
                            else if (feeObject.IsMS)
                            {
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for MS after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.MS, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for MS after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }

                            }
                            else if (feeObject.IsST)
                            {
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for ST after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.ST, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for ST after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }
                            }

                            else if (feeObject.IsPL || feeObject.IsSP || feeObject.IsSD || feeObject.IsAN)
                            {
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for PLSPSDAN after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.PLSPSD, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for PLSPSDAN after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }
                            }
                            else if (feeObject.IsCC)
                            {
                                if (feeObject.BEMSSTFilingfee > 0 && amountDue > 0)
                                {
                                    //create trans history for CF
                                    crmTrace.AppendLine("Create Transaction History for CC after amount paid-Start");
                                    transactionHistoryHelper(Fab4_TransactionCodes.CC, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                                    crmTrace.AppendLine("Create Transaction History for CC after amount paid-End");
                                    amountDue = amountDue - amountDue;
                                }
                            }
                            #endregion


                        }
                        #endregion

                        #endregion






                    }
                    //existing amount paid>0  then adjustment.
                    if ((targetEntity.Contains(JobFilingEntityAttributeName.IsJobSubmitted)
                        && targetEntity[JobFilingEntityAttributeName.IsJobSubmitted] != null
                        && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobSubmitted) == true
                        && feeObject.Adjustment > 0)
                        || (targetEntity.Contains(JobFilingEntityAttributeName.IsCorrectionCompleted)
                            && targetEntity[JobFilingEntityAttributeName.IsCorrectionCompleted] != null
                            && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsCorrectionCompleted) == true
                            && feeObject.Adjustment > 0)
                        || (targetEntity.Contains(JobFilingEntityAttributeName.JobStatus)
                            && targetEntity[JobFilingEntityAttributeName.JobStatus] != null
                            && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value == (int)JobStatus.LOCRequested && feeObject.Adjustment > 0)
                        //&& preImage.Attributes.Contains(JobFilingEntityAttributeName.Sign) && preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true)
                        //LOC Signs Submission portal will not send Signs work type flag so using preimage.--Adjustment scenario
                        )
                    {
                        // if Filing is PAA and we have a Adjustment then we have to add two transaction codes 1 for PAA default $100 and one with Overage payment with adjustment amount.

                        if (targetEntity.Contains(JobFilingEntityAttributeName.FilingType) && targetEntity[JobFilingEntityAttributeName.FilingType] != null && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                        {
                            if (!isPostedPaymentHistories(service, crmTrace, targetEntity))// if there is no payment made in PAA
                            {
                                crmTrace.AppendLine("if Filing is PAA and we have a Adjustment then we have to add two transaction codes 1 for PAA default $100 and one with Overage payment with adjustment amount.");


                                crmTrace.AppendLine("Condition Expression for PAA FEE-Adjustments");
                                transactionHistoryHelper(Fab4_TransactionCodes.PAA, new decimal(100), targetEntity, paymentHistoryId, service, crmTrace);
                                crmTrace.AppendLine("Create Transaction History for PAA FEE-End");


                            }

                        }
                        crmTrace.AppendLine("Condition Expression for Adjustment");
                        transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.Adjustment, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }

                }
                #endregion

                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "TESTING PURPOSE TraceCRM", "Fab4FeeCalculationHandler - Testing", null, crmTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecords", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }


        }







        public static void CreateFAB4TransactionHistoryRecordsOp49(Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace, Entity preImage, FeeCalculationObject feeObject)
        {
            try
            {

                /// ALL PAA Conditions will fall under existing amount paid has value and amount due is greater than zero.

                #region User does not pay anything till now

                if (feeObject.ExistingAmountPaid == 0)
                {


                    if (feeObject.BEMSSTFilingfee > 0)
                    {


                        crmTrace.AppendLine("Create Transaction History for Op49  fee-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.Op49FilingFee, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Op49  fee-End");


                    }


                    if (feeObject.RecordManagementFees > 0)
                    {
                        crmTrace.AppendLine("Create Transaction History for Op49 late fee RecordMGMT-Start 123");
                        transactionHistoryHelper(Fab4_TransactionCodes.Op49Latefee, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Op49 late fee RecordMGMT-End 123");

                    }


                }

                #endregion

                #region user Paid some Amount
                else if (feeObject.ExistingAmountPaid > 0)
                {

                    crmTrace.AppendLine("user Paid some Amount" + feeObject.amountDue);


                    //If user needs to pay some amount because of changing the inspection date resluted in late fee
                    if (feeObject.amountDue > 0)
                    {

                        decimal amountDue = feeObject.amountDue;
                        crmTrace.AppendLine("If user needs to pay some amount because of adding new work type or chnaging size of shed");

                        crmTrace.AppendLine("Create Transaction History for Op49 late fee after amount paid-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.Op49Latefee, amountDue, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Op49 late fee after amount paid-End");


                    }

                    //existing amount paid>0  then adjustment.
                    if ((targetEntity.Contains(OP49EntityAttributeNames.IsSubmitted) && targetEntity[OP49EntityAttributeNames.IsSubmitted] != null && targetEntity.GetAttributeValue<bool>(OP49EntityAttributeNames.IsSubmitted) == true && feeObject.Adjustment > 0)

                        )
                    {
                        // if Filing is PAA and we have a Adjustment then we have to add two transaction codes 1 for PAA default $100 and one with Overage payment with adjustment amount.
                        crmTrace.AppendLine("Condition Expression for Adjustment");
                        transactionHistoryHelper(Fab4_TransactionCodes.OVERAGE_PAYMENT, feeObject.Adjustment, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for Adjustment-End");
                    }



                }
                #endregion



            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateFAB4TransactionHistoryRecordsOp49", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }


        }







        /// <summary>
        /// this function is used to create transaction history based on transcode passed
        /// </summary>
        /// <param name="fab4transcodes"></param>
        /// <param name="transFee"></param>
        /// <param name="targetEntity"></param>
        /// <param name="paymentHistoryId"></param>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        public static void transactionHistoryHelper(string fab4transcodes, decimal transFee, Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("COndition expression for" + fab4transcodes);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransCode, ConditionOperator.Equal, new string[] { fab4transcodes });
                crmTrace.AppendLine("get transaction code for" + fab4transcodes);
                EntityCollection transactioncodeResponse = GetTransactionCodes(service, targetEntity, crmTrace, condition);
                if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                {
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                    Guid transHistoryGuids = (CreateTransactionHistory(crmTrace, service, targetEntity.Id, paymentHistoryId, transactioncodeResponse.Entities[0], new Money(transFee)));
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }

        }

        public static void transactionHistoryHelperUsingTransText(string fab4transcodes, decimal transFee, Entity targetEntity, Guid paymentHistoryId, IOrganizationService service, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("COndition expression for" + fab4transcodes);
                ConditionExpression condition = CreateConditionExpression(TransactionCodeAttributeNames.TransactionText, ConditionOperator.Equal, new string[] { fab4transcodes });
                crmTrace.AppendLine("get transaction code for" + fab4transcodes);
                EntityCollection transactioncodeResponse = GetTransactionCodes(service, targetEntity, crmTrace, condition);
                if (transactioncodeResponse != null && transactioncodeResponse.Entities != null)
                {
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                    Guid transHistoryGuids = (CreateTransactionHistory(crmTrace, service, targetEntity.Id, paymentHistoryId, transactioncodeResponse.Entities[0], new Money(transFee)));
                    crmTrace.AppendLine("create transaction history for" + fab4transcodes);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - transactionHistoryHelper", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }

        }



        /// <summary>
        /// This function will return whether the jobfiling has any PH with is posted true 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="crmTrace"></param>
        /// <param name="targetEntity"></param>
        /// <returns></returns>
        public static bool isPostedPaymentHistories(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity)
        {
            try
            {

                //retreive the Job filing application field and Is posted equals to NO
                crmTrace.AppendLine("Fetch Xml for retrieving Job filing application and Is posted value NO ");
                string fetchXML = @"<?xml version='1.0'?>
                            <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0' no-lock='true'>
                            <entity name='dobnyc_paymenthistory'>
                            <attribute name='createdon'/>
                            <attribute name='dobnyc_invoicenumber'/>
                            <attribute name='dobnyc_paymenthistoryid'/>
                            <order descending='false' attribute='createdon'/>
                            <filter type='and'>
                            <condition attribute='dobnyc_jobfilinglookup' value='" + targetEntity.Id + @"' 
                            uitype='dobnyc_jobfiling' operator='eq'/>
                            <condition attribute='dobnyc_isposted' value='1' operator='eq'/>
                            </filter>
                            </entity>
                            </fetch>";
                crmTrace.AppendLine("End fetch xml for retrieving OldPhhistory ");
                crmTrace.AppendLine("Old Paymnet history from FetchXml- Start");
                EntityCollection OldPhhistory = service.RetrieveMultiple(new FetchExpression(fetchXML));
                crmTrace.AppendLine("Old Paymnet history from FetchXml- end" + OldPhhistory.Entities.Count);
                if (OldPhhistory.Entities.Count > 0)
                {
                    return true;
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - isPostedPaymentHistories", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            return false;
        }


        /// <summary>
        /// Used for all transaction histories if user did not pay amount till now.
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        /// <param name="paymentHistoryId"></param>
        public static void createTransactionHistoryUserPaidZeroAmount(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject, Guid paymentHistoryId)
        {
            try
            {
                #region Legalization and Normal job
                #region Legalization Job - filing fee will be accounted to single Legalization transaction code
                //if (feeObject.IsLegalization)
                //{
                if (feeObject.LegalizationFilingFees > 0)
                {
                    #region 1, 2 family
                    if (feeObject.BuildingType == 1 || feeObject.BuildingType == 2)
                    {
                        crmTrace.AppendLine("Create Transaction History for Legalization User doesn't pay any amount");
                        transactionHistoryHelperUsingTransText(Fab4_TransactionCodes.Legalization12family, feeObject.LegalizationFilingFees, targetEntity, paymentHistoryId, service, crmTrace); //added landmarkfee for signs
                        crmTrace.AppendLine("Create Transaction History for Legalization User doesn't pay any amount");
                    }
                    #endregion
                    #region 3 family ,other
                    else
                    {
                        crmTrace.AppendLine("Create Transaction History for Legalization User doesn't pay any amount");
                        transactionHistoryHelperUsingTransText(Fab4_TransactionCodes.Legalization3familyOther, feeObject.LegalizationFilingFees, targetEntity, paymentHistoryId, service, crmTrace); //added landmarkfee for signs
                        crmTrace.AppendLine("Create Transaction History for Legalization User doesn't pay any amount");
                    }
                    #endregion

                }
                //}
                #endregion

                #region Normal Job - filing fee splits across different work types and their respective transaction code.
                //else
                //{


                if (feeObject.BEMSSTFilingfee > 0)
                {

                    #region Based on Work type  Trans Code
                    if (feeObject.IsBE)
                    {
                        crmTrace.AppendLine("Create Transaction History for BE-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.BE, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for BE-End");
                    }
                    #region added for GC
                    else if ((feeObject.IsMS && feeObject.IsGC) || (feeObject.IsST && feeObject.IsGC) || feeObject.IsGC)
                    {
                        //this might change once requirement is fianlized.
                        //any filing combined with GC or individual GC should use GC transaction code
                        crmTrace.AppendLine("Create Transaction History for MS-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.GC, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for MS-End");
                    }
                    #endregion
                    else if (feeObject.IsMS)
                    {
                        crmTrace.AppendLine("Create Transaction History for MS-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.MS, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for MS-End");
                    }
                    else if (feeObject.IsST)
                    {
                        crmTrace.AppendLine("Create Transaction History for ST-Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.ST, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for ST-End");
                    }

                    else if (feeObject.IsPL || feeObject.IsSP || feeObject.IsSD || feeObject.IsAN)
                    {
                        crmTrace.AppendLine("Create Transaction History for PLSPSDAN Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.PLSPSD, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for PLSPSDAN-End");

                    }
                    else if (feeObject.IsCC)
                    {
                        crmTrace.AppendLine("Create Transaction History for cc Start");
                        transactionHistoryHelper(Fab4_TransactionCodes.CC, feeObject.BEMSSTFilingfee, targetEntity, paymentHistoryId, service, crmTrace);
                        crmTrace.AppendLine("Create Transaction History for cc-End");
                    }

                    #endregion

                    // get transaction codes  

                }

                //}
                #endregion
                #endregion
                if (feeObject.RecordManagementFees > 0 && (feeObject.BuildingType == FAB4BuildingType.familyHouse1 || feeObject.BuildingType == FAB4BuildingType.familyHouse2 || feeObject.BuildingType == FAB4BuildingType.familyHouse3))
                {
                    crmTrace.AppendLine("Create Transaction History for RecordMGMT-Start 123");
                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_123family, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                    crmTrace.AppendLine("Create Transaction History for RecordMGMT-End 123");

                }
                //record management fee  has two different Fee values based on building type
                if (feeObject.RecordManagementFees > 0 && feeObject.BuildingType == FAB4BuildingType.familyHouseOther)
                {
                    crmTrace.AppendLine("Create Transaction History for RecordMGMT-Start other");
                    transactionHistoryHelper(Fab4_TransactionCodes.RecordManagement_Others, feeObject.RecordManagementFees, targetEntity, paymentHistoryId, service, crmTrace);
                    crmTrace.AppendLine("Create Transaction History for RecordMGMT-End other");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                //throw ex;
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                //throw ex;
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                //throw ex;
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FeeCalculationStandardizationHandler - createTransactionHistoryUserPaidZeroAmount", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static EntityCollection GetTransactionCodes(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, ConditionExpression condition)
        {
            crmTrace.AppendLine("Get transaction codes");

            EntityCollection transCodesResponse = new EntityCollection();
            try
            {
                #region retrieve Transaction Code Info
                crmTrace.AppendLine("Retrieve the transaction code information : started");
                EntityCollection transactioncodeResponse = RetrieveMultiple(service, TransactionCodeAttributeNames.EntityLogicalName, new string[] {
                TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory,
                TransactionCodeAttributeNames.RevenueSource, TransactionCodeAttributeNames.SubSource,TransactionCodeAttributeNames.FeeSchemaName,TransactionCodeAttributeNames.TransactionText,
                TransactionCodeAttributeNames.TransType}, new ConditionExpression[] { condition }, LogicalOperator.Or);
                crmTrace.AppendLine("Retrieve the transaction code information : ended");

                #endregion

                return transactioncodeResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetTransactionCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void GetBuildingTypeZoningcharactersticsInformation(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace, FeeCalculationObject FeeObject)
        {
            crmTrace.AppendLine("Get transaction codes");
            Guid zoningGuid = new Guid();
            Entity zoningCharacterstics = new Entity();
            try
            {

                #region retrieve Transaction Code Info

                zoningGuid = targetEntity.Contains(JobFilingEntityAttributeName.zoningCharactersticsLookup) && targetEntity[JobFilingEntityAttributeName.zoningCharactersticsLookup] != null ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.zoningCharactersticsLookup).Id : preTargetEntity.Contains(JobFilingEntityAttributeName.zoningCharactersticsLookup) && preTargetEntity[JobFilingEntityAttributeName.zoningCharactersticsLookup] != null ? preTargetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.zoningCharactersticsLookup).Id : new Guid();
                if (zoningGuid != new Guid())
                {
                    zoningCharacterstics = Retrieve(service, new string[] {
                ZoningCharactersticsPW1AttributeNames.BuildingType}, zoningGuid, ZoningCharactersticsPW1AttributeNames.EntityLogicalName);

                    if (zoningCharacterstics != null && zoningCharacterstics.Id != null)
                    {

                        if (zoningCharacterstics.Contains(ZoningCharactersticsPW1AttributeNames.BuildingType) && zoningCharacterstics[ZoningCharactersticsPW1AttributeNames.BuildingType] != null)
                        {
                            FeeObject.BuildingType = zoningCharacterstics.GetAttributeValue<OptionSetValue>(ZoningCharactersticsPW1AttributeNames.BuildingType).Value;
                            crmTrace.AppendLine(" ZoningCharactersticsPW1AttributeNames BuildingType " + FeeObject.BuildingType);
                        }
                    }
                }
                #endregion
                //ConditionExpression condition = new ConditionExpression(ZoningCharactersticsPW1AttributeNames.JobFilingGuid, ConditionOperator.Equal, targetEntity.Id);
                //crmTrace.AppendLine("Retrieve the ZoningCharactersticsPW1AttributeNames information : started");
                //EntityCollection transactioncodeResponse = RetrieveMultiple(service, ZoningCharactersticsPW1AttributeNames.EntityLogicalName, new string[] {
                //ZoningCharactersticsPW1AttributeNames.BuildingType}, new ConditionExpression[] { condition }, LogicalOperator.Or);
                //crmTrace.AppendLine("Retrieve the ZoningCharactersticsPW1AttributeNames information : ended");

                //

                //if (transactioncodeResponse != null && transactioncodeResponse.Entities.Count > 0)
                //{
                //    crmTrace.AppendLine(" ZoningCharactersticsPW1AttributeNames Count " + transactioncodeResponse.Entities.Count);
                //    if (transactioncodeResponse.Entities[0].Contains(ZoningCharactersticsPW1AttributeNames.BuildingType) && transactioncodeResponse.Entities[0][ZoningCharactersticsPW1AttributeNames.BuildingType] != null)
                //    {
                //        FeeObject.BuildingType = transactioncodeResponse.Entities[0].GetAttributeValue<OptionSetValue>(ZoningCharactersticsPW1AttributeNames.BuildingType).Value;
                //        crmTrace.AppendLine(" ZoningCharactersticsPW1AttributeNames BuildingType " + FeeObject.BuildingType);
                //    }
                //}


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

        public static void GetBoilerEnergysource(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace, FeeCalculationObject FeeObject)
        {
            crmTrace.AppendLine("Get Boiler Energy Source");
            Guid JobfilingGuid = new Guid();
            int BoilerenergySource = 0;
            Entity BoilerScopeofwork = new Entity();
            try
            {

                #region retrieve Boiler Energy Source Code

                JobfilingGuid = targetEntity.Id;
                if (JobfilingGuid != new Guid())
                {
                    EntityCollection BoilerScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(service, targetEntity, crmTrace);
                    EntityCollection BoilerBuildDevices = getBoilerBuildDeviceDetailsFromScopeOfWork(service, preTargetEntity, BoilerScopeOfWorkCollection, crmTrace, (int)ExistingProposedOptionSet.Existing);

                    if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0 && BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.BoilerEnergySource))
                    {

                        BoilerenergySource = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.BoilerEnergySource).Value;
                        FeeObject.BoilerEnergySource = BoilerenergySource;
                        crmTrace.AppendLine("BoilerenergySource " + BoilerenergySource);
                    }
                    else if (BoilerScopeOfWorkCollection != null && BoilerScopeOfWorkCollection.Entities.Count > 0 && BoilerScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.FuelstorageApplianceConnected))
                    {
                        int FuelstorageApplianceConnected = BoilerScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.FuelstorageApplianceConnected).Value;
                        if (FuelstorageApplianceConnected == 2 || FuelstorageApplianceConnected == 3)
                        {
                            BoilerenergySource = (int)BoilerEnergySource.Oil;
                            FeeObject.BoilerEnergySource = BoilerenergySource;
                            crmTrace.AppendLine("BoilerenergySource " + BoilerenergySource);
                        }
                    }
                    else
                    {
                        if (BoilerBuildDevices != null && BoilerBuildDevices.Entities.Count > 0)
                        {
                            foreach (Entity BoilerDevice in BoilerBuildDevices.Entities)
                            {
                                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource] != null)
                                {

                                    BoilerenergySource = BoilerDevice.GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;

                                }

                            }
                            crmTrace.AppendLine("BoilerenergySource " + BoilerenergySource);
                            FeeObject.BoilerEnergySource = BoilerenergySource;
                        }

                    }
                }



                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - GetZoningcharactersticsInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }
        public static Guid CreateTransactionHistory(StringBuilder crmTrace, IOrganizationService service, Guid Jobid, Guid PaymentHistoryId, Entity TransCodeId, Money fee)
        {
            crmTrace.AppendLine("Create Transaction history...");
            try
            {
                Entity transHistory = null;
                if (!string.IsNullOrEmpty(Jobid.ToString()) && !string.IsNullOrEmpty(fee.ToString()))
                {
                    crmTrace.AppendLine("Create Transaction history - Start");
                    transHistory = new Entity();

                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    if (TransCodeId.LogicalName == TransactionCodeAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.ToEntityReference());
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionCodeAttributeNames.TransCode));
                    }
                    // this if block will be executed in EOD handler.
                    else if (TransCodeId.LogicalName == TransactionHistoryAttributeNames.EntityLogicalName)
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, TransCodeId.GetAttributeValue<EntityReference>(TransactionHistoryAttributeNames.TransactionCodeId));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.TransCode));
                    }
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, TransCodeId.GetAttributeValue<string>(TransactionHistoryAttributeNames.JobNumber));
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.PaymentInvoice, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, PaymentHistoryId));

                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, fee);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, TransCodeId.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, TransCodeId.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, TransCodeId.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, TransCodeId.Attributes[TransactionCodeAttributeNames.SubSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, TransCodeId.Attributes[TransactionCodeAttributeNames.TransactionText]);

                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, TransCodeId.Attributes[TransactionCodeAttributeNames.TransType]);
                    Guid Id = service.Create(transHistory);
                    crmTrace.AppendLine("Create Transaction history - end");

                    return Id;
                }
                else
                    return new Guid();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Jobid.ToString(), "CRM", "FeeCalculationStandardizationHandler - CreateTransactionHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }




        /// <summary>
        /// This is the generic method to update the Master Boiler,burner,storage device statuses based on the isnpection results
        /// </summary>
        /// <param name="service"></param>
        /// <param name="masterDeviceStatusFieldSchemaName"></param>
        /// <param name="BoilerBuildDeviceLookupSchemaName"></param>
        /// <param name="scopeOfWorkType"></param>
        /// <param name="replacementLookupSchemaName"></param>
        /// <param name="masterDeviceEntityname"></param>
        /// <param name="BoilerDevice"></param>
        /// <param name="crmTrace"></param>
        public static void UpdateMasterStatusGenericMethod(IOrganizationService service, string masterDeviceStatusFieldSchemaName, string BoilerBuildDeviceLookupSchemaName, int scopeOfWorkType, string replacementLookupSchemaName, string masterDeviceEntityname, Entity BoilerDevice, int deviceStatus, StringBuilder crmTrace)
        {
            Entity masterDevice = new Entity(masterDeviceEntityname);
            try
            {
                crmTrace.AppendLine("Update BBD Lookup Master Device to Active");

                crmTrace.AppendLine("replacementLookupSchemaName : " + replacementLookupSchemaName + " BoilerBuildDeviceLookupSchemaName :" + BoilerBuildDeviceLookupSchemaName + " masterDeviceEntityname: " + masterDeviceEntityname);

                if (scopeOfWorkType == (int)BoilerScopeOfWorkType.NewInstallation || scopeOfWorkType == (int)BoilerScopeOfWorkType.Modification || scopeOfWorkType == (int)BoilerScopeOfWorkType.Replacement)
                {
                    masterDevice.SetAttributeValue(masterDeviceStatusFieldSchemaName, new OptionSetValue(deviceStatus));
                    masterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceLookupSchemaName).Id;
                    service.Update(masterDevice);
                }


                //masterDeviceStatusFieldSchemaName,BoilerBuildDeviceLookup,scopeofworktype,columsetschemaname(replacementlookup),masterdeviceentityname

                if (scopeOfWorkType == (int)BoilerScopeOfWorkType.Replacement)
                {
                    crmTrace.AppendLine("Boiler Replacement -status - Update   Master Device self lookup to Void");
                    masterDevice = new Entity(masterDeviceEntityname);
                    //
                    crmTrace.AppendLine("Get the Old master Device Id");
                    Entity CurrentMasterDevice = Retrieve(service, new string[] { replacementLookupSchemaName }, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceLookupSchemaName).Id, masterDeviceEntityname);
                    if (CurrentMasterDevice != null && CurrentMasterDevice.Id != null && CurrentMasterDevice.Contains(replacementLookupSchemaName) && CurrentMasterDevice[replacementLookupSchemaName] != null)
                    {
                        crmTrace.AppendLine("Update the old master Device Status to Void");

                        masterDevice.SetAttributeValue(masterDeviceStatusFieldSchemaName, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));
                        masterDevice.Id = CurrentMasterDevice.GetAttributeValue<EntityReference>(replacementLookupSchemaName).Id;
                        service.Update(masterDevice);
                    }
                }

                if (scopeOfWorkType == (int)BoilerScopeOfWorkType.AbandoningofTank || scopeOfWorkType == (int)BoilerScopeOfWorkType.RemovalofTank)
                {
                    crmTrace.AppendLine("FS Only AbandoningofTank, RemovalofTank");
                    masterDevice.SetAttributeValue(masterDeviceStatusFieldSchemaName, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));
                    masterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceLookupSchemaName).Id;
                    service.Update(masterDevice);
                }

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(string.Empty, "CRM", "FeeCalculationStandardizationHandler - UpdateMasterStatusGenericMethod", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(string.Empty, "CRM", "FeeCalculationStandardizationHandler - UpdateMasterStatusGenericMethod", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }

        }


        public static void UpdateBoilerDeviceStatusonPassFinal(IOrganizationService service, Entity JobFiling, StringBuilder crmTrace, Entity BoilerDevice, int scopeType, int scopeOfWorkType)
        {
            Entity masterDevice = new Entity();
            Entity temp = new Entity();
            try
            {
                #region Boilers

                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null && scopeType == (int)BoilerScopeIncludes.Boiler)
                {

                    crmTrace.AppendLine("UpdateBoilerDeviceStatusonPassFinal-Boilers should not update the status for Boilers");

                    temp = Retrieve(service, new string[] { BoilerMasterDevice.boilerStatus }, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);
                    crmTrace.AppendLine("Replacement and modification of FB sos tatus is active-pending");


                    //  UpdateMasterStatusGenericMethod(service, BoilerMasterDevice.boilerStatus, BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler, scopeOfWorkType, BoilerMasterDevice.BoilerMasterReplacementLookup, BoilerMasterDevice.EntityLogicalName, BoilerDevice, crmTrace);

                    #region  original logic before making geneic
                    //crmTrace.AppendLine("Update BBD Lookup Master Device to Active");
                    //masterDevice.SetAttributeValue(BoilerMasterDevice.boilerStatus, new OptionSetValue((int)BoilerDeviceStatus.active));
                    //masterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id;
                    //service.Update(masterDevice);

                    ////masterDeviceStatusFieldSchemaName,BoilerBuildDeviceLookup,scopeofworktype,columsetschemaname(replacementlookup),masterdeviceentityname

                    //if(scopeOfWorkType==(int)BoilerScopeOfWorkType.Replacement)
                    //{
                    //    crmTrace.AppendLine("Boiler Replacement -status - Update   Master Device self lookup to Void");
                    //    masterDevice = new Entity();
                    //    //
                    //    crmTrace.AppendLine("Get the Old master Device Id");
                    //    Entity CurrentMasterDevice = Retrieve(service, new string[] { BoilerMasterDevice.BoilerMasterReplacementLookup }, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);
                    //    if(CurrentMasterDevice!=null && CurrentMasterDevice.Id!=null && CurrentMasterDevice.Contains(BoilerMasterDevice.BoilerMasterReplacementLookup) && CurrentMasterDevice[BoilerMasterDevice.BoilerMasterReplacementLookup] != null)
                    //    {
                    //        crmTrace.AppendLine("Update the old master Device Status to Void");

                    //        masterDevice.SetAttributeValue(BoilerMasterDevice.boilerStatus, new OptionSetValue((int)BoilerDeviceStatus.voidRemoved));
                    //        masterDevice.Id = CurrentMasterDevice.GetAttributeValue<EntityReference>(BoilerMasterDevice.BoilerMasterReplacementLookup).Id;
                    //        service.Update(masterDevice);
                    //    }
                    //}
                    #endregion

                }

                #endregion

                #region Burner
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null)
                {
                    if (temp != null && temp.Contains(BoilerMasterDevice.boilerStatus) && temp[BoilerMasterDevice.boilerStatus] != null)
                    {
                        crmTrace.AppendLine("UpdateBoilerDeviceStatusonPassFinal-Burner  set status same as boiler");
                        UpdateMasterStatusGenericMethod(service, FulelBurnerMaster.FuelBurnerStatus, BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup, scopeOfWorkType, FulelBurnerMaster.FuelBurnerSelfLookup, FulelBurnerMaster.EntityLogicalName, BoilerDevice, temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value, crmTrace);

                    }


                }
                #endregion

                #region Storage
                if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                {
                    if (temp != null && temp.Contains(BoilerMasterDevice.boilerStatus) && temp[BoilerMasterDevice.boilerStatus] != null)
                    {
                        crmTrace.AppendLine("UpdateBoilerDeviceStatusonPassFinal-Burner  set status same as boiler");
                        UpdateMasterStatusGenericMethod(service, FulelStorageMaster.FuelStorageStatus, BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup, scopeOfWorkType, FulelStorageMaster.FuelStorageSelfLookup, FulelStorageMaster.EntityLogicalName, BoilerDevice, temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value, crmTrace);
                        // MasterFuelBurnerDevice.SetAttributeValue(FulelBurnerMaster.FuelBurnerStatus, new OptionSetValue(temp.GetAttributeValue<OptionSetValue>(BoilerMasterDevice.boilerStatus).Value));
                    }
                    else
                    {
                        crmTrace.AppendLine("UpdateBoilerDeviceStatusonPassFinal-Storage not connected to boiler");
                        UpdateMasterStatusGenericMethod(service, FulelStorageMaster.FuelStorageStatus, BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup, scopeOfWorkType, FulelStorageMaster.FuelStorageSelfLookup, FulelStorageMaster.EntityLogicalName, BoilerDevice, (int)BoilerDeviceStatus.active, crmTrace);
                    }


                }
                #endregion




            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - UpdateBoilerDeviceStatusonPassFinal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }



        /// <summary>
        /// This Function determines whether should we associate Burners or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldAssociateBurnerDevice(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {
            if (scopeType == (int)BoilerScopeIncludes.Boiler && ScopeOfWSorkType == (int)BoilerScopeOfWorkType.Replacement && BoilerBuildDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner) && BoilerBuildDevice[BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner] != null && BoilerBuildDevice.GetAttributeValue<bool>(BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner))


            {
                return false;

            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// This Function determines whether should we create new FS or not
        /// </summary>
        /// <param name="scopeType">Boiler,Burner,FS</param>
        /// <param name="ScopeOfWSorkType">New Installation,Modification,Replacement</param>
        /// <returns></returns>
        public static bool shouldAssociateFuelStorageDevice(int scopeType, int ScopeOfWSorkType, Entity BoilerBuildDevice)
        {

            return true;
            //always assocaite all FS to newly created Boiler
        }



        public static void AssociateBurnersfromOldMasterGuid(IOrganizationService service, StringBuilder crmTrace, Entity BoilerDevice, int scopeType, int scopeOfWorkType, Guid oldMasterDeviceGuid, Guid newMasterDeviceGuid)
        {
            Entity tempBurner = new Entity(FulelBurnerMaster.EntityLogicalName);
            try
            {
                crmTrace.AppendLine("AssociateBurnersfromOldMasterGuid Strted");
                ConditionExpression transactionCodeCondition = CreateConditionExpression(FulelBurnerMaster.BoilerMasterLookup, ConditionOperator.Equal, new string[] { oldMasterDeviceGuid.ToString() });
                EntityCollection FuelBurnersCollection = RetrieveMultiple(service, FulelBurnerMaster.EntityLogicalName, new string[] {
                                                      FulelBurnerMaster.EntityNameAttribute}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);
                if (FuelBurnersCollection != null && FuelBurnersCollection.Entities.Count > 0)
                {
                    crmTrace.AppendLine("FuelBurnersCollection.Entities.Count " + FuelBurnersCollection.Entities.Count);
                    foreach (Entity FuelBurner in FuelBurnersCollection.Entities)
                    {
                        crmTrace.AppendLine("Fuel Burner Association to new master " + FuelBurner.Id);
                        tempBurner = new Entity(FulelBurnerMaster.EntityLogicalName);
                        tempBurner.SetAttributeValue(FulelBurnerMaster.BoilerMasterLookup, new EntityReference(BoilerMasterDevice.EntityLogicalName, newMasterDeviceGuid));
                        tempBurner.Id = FuelBurner.Id;
                        service.Update(tempBurner);
                    }
                }

                crmTrace.AppendLine("Get the Old master details ");
                Entity OldMaster = service.Retrieve(BoilerMasterDevice.EntityLogicalName, oldMasterDeviceGuid, new ColumnSet(new string[] { BoilerMasterDevice.LatestFuelBurnerDevice }));

                if (OldMaster != null && OldMaster.Id != null && OldMaster.Contains(BoilerMasterDevice.LatestFuelBurnerDevice) && OldMaster[BoilerMasterDevice.LatestFuelBurnerDevice] != null)
                {
                    crmTrace.AppendLine("Update the latest boiler master device with fuel burner ");
                    tempBurner = new Entity(BoilerMasterDevice.EntityLogicalName);
                    tempBurner.SetAttributeValue(BoilerMasterDevice.LatestFuelBurnerDevice, new EntityReference(FulelBurnerMaster.EntityLogicalName, OldMaster.GetAttributeValue<EntityReference>(BoilerMasterDevice.LatestFuelBurnerDevice).Id));
                    tempBurner.Id = newMasterDeviceGuid;
                    service.Update(tempBurner);
                }
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersfromOldMasterGuid", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersfromOldMasterGuid", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }




        }


        public static void AssociateFuelStoragesfromOldMasterGuid(IOrganizationService service, StringBuilder crmTrace, Entity BoilerDevice, int scopeType, int scopeOfWorkType, Guid oldMasterDeviceGuid, Guid newMasterDeviceGuid)
        {
            Entity tempBurner = new Entity(FulelStorageMaster.EntityLogicalName);
            ConditionExpression transactionCodeCondition = CreateConditionExpression(FulelStorageMaster.BoilerMasterLookup, ConditionOperator.Equal, new string[] { oldMasterDeviceGuid.ToString() });
            EntityCollection FuelStorageCollection = RetrieveMultiple(service, FulelStorageMaster.EntityLogicalName, new string[] {
                                                      FulelStorageMaster.EntityNameAttribute}, new ConditionExpression[] { transactionCodeCondition }, LogicalOperator.And);

            if (FuelStorageCollection != null && FuelStorageCollection.Entities.Count > 0)
            {
                crmTrace.AppendLine("FuelBurnersCollection.Entities.Count " + FuelStorageCollection.Entities.Count);
                foreach (Entity FuelBurner in FuelStorageCollection.Entities)
                {
                    crmTrace.AppendLine("Fuel Burner Association to new master " + FuelBurner.Id);
                    tempBurner = new Entity(FulelStorageMaster.EntityLogicalName);
                    tempBurner.SetAttributeValue(FulelStorageMaster.BoilerMasterLookup, new EntityReference(BoilerMasterDevice.EntityLogicalName, newMasterDeviceGuid));
                    tempBurner.Id = FuelBurner.Id;
                    service.Update(tempBurner);
                }
            }

        }



        public static void AssociateBurnersFuelStoragesToNewBoiler(IOrganizationService service, StringBuilder crmTrace, Entity BoilerDevice, int scopeType, int scopeOfWorkType)
        {
            try
            {
                Guid newMasterDeviceGuid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id;
                Guid oldMasterDeviceGuid = new Guid();
                crmTrace.AppendLine("newMasterDeviceGuid: " + newMasterDeviceGuid);
                Entity CurrentMasterDevice = Retrieve(service, new string[] { BoilerMasterDevice.BoilerMasterReplacementLookup }, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id, BoilerMasterDevice.EntityLogicalName);
                if (CurrentMasterDevice != null && CurrentMasterDevice.Id != null && CurrentMasterDevice.Contains(BoilerMasterDevice.BoilerMasterReplacementLookup) && CurrentMasterDevice[BoilerMasterDevice.BoilerMasterReplacementLookup] != null)
                {
                    oldMasterDeviceGuid = CurrentMasterDevice.GetAttributeValue<EntityReference>(BoilerMasterDevice.BoilerMasterReplacementLookup).Id;
                }
                if (oldMasterDeviceGuid != new Guid())
                {
                    if (shouldAssociateBurnerDevice(scopeType, scopeOfWorkType, BoilerDevice))
                    {
                        crmTrace.AppendLine("shouldAssociateBurnerDevice: true");
                        AssociateBurnersfromOldMasterGuid(service, crmTrace, BoilerDevice, scopeType, scopeOfWorkType, oldMasterDeviceGuid, newMasterDeviceGuid);
                    }

                    if (shouldAssociateFuelStorageDevice(scopeType, scopeOfWorkType, BoilerDevice))
                    {
                        crmTrace.AppendLine("shouldAssociateFuelStorageDevice: true");
                        AssociateFuelStoragesfromOldMasterGuid(service, crmTrace, BoilerDevice, scopeType, scopeOfWorkType, oldMasterDeviceGuid, newMasterDeviceGuid);
                    }


                }




            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - AssociateBurnersFuelStoragesToNewBoiler", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }

        }




        /// <summary>
        /// Get the Boiler Scope of work Details from jobfiling
        /// </summary>
        /// <param name="serviceConnector"></param>
        /// <param name="preTargetEntity"></param>
        /// <param name="customTrace"></param>
        /// <returns></returns>
        public static Entity getBoilerScopeOfWorkDetailsFromBoilerDevice(IOrganizationService serviceConnector, Entity preTargetEntity, StringBuilder customTrace)
        {

            Entity BoilerScopeOfWorkCollection = Retrieve(serviceConnector, new string[] { BEScopeOfWorkEntityAttribute.ExistingEnergySource, BEScopeOfWorkEntityAttribute.ScopeOfWSorkType, BEScopeOfWorkEntityAttribute.BoilerEnergySource, BEScopeOfWorkEntityAttribute.FBScope, BEScopeOfWorkEntityAttribute.FSScope, BEScopeOfWorkEntityAttribute.BoilerScope }, preTargetEntity.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.BoilerScopeofworkid).Id, BEScopeOfWorkEntityAttribute.EntityLogicalName);

            return BoilerScopeOfWorkCollection;
        }

        public static Entity getBoilerBuildDeviceDetailsFromDevice(IOrganizationService serviceConnector, Entity preTargetEntity, StringBuilder customTrace)
        {
            Entity BoilerBuildDevices = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);
            if (preTargetEntity != null && preTargetEntity.Id != null)
            {
                customTrace.AppendLine("3)Loop through all devices and create a number");




                BoilerBuildDevices = Retrieve(serviceConnector, new string[] {

                        BoilerBuildDeviceDetailsEntityAttribute.FSComments,BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler,BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelBurner,
                        BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage,BoilerBuildDeviceDetailsEntityAttribute.IsSameScopeOFWorkForFuelStorage2,BoilerBuildDeviceDetailsEntityAttribute.BurnerCertificationNumber,
                        BoilerBuildDeviceDetailsEntityAttribute.FSExistingGrdaeOil,BoilerBuildDeviceDetailsEntityAttribute.FSLocationOfFS, BoilerBuildDeviceDetailsEntityAttribute.FSExistingStorageTank,BoilerBuildDeviceDetailsEntityAttribute.FSHowTanksInstalled,
                        BoilerBuildDeviceDetailsEntityAttribute.FSTotalTankCapacity,BoilerBuildDeviceDetailsEntityAttribute.FSBuildingAdjacentLineOfSubway,BoilerBuildDeviceDetailsEntityAttribute.FSabandedResultOfOiltoGas,
                        BoilerBuildDeviceDetailsEntityAttribute.FSApplianceFuelStorage,BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyName,BoilerBuildDeviceDetailsEntityAttribute.BurnerListingAgencyOther,
                        BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber,BoilerBuildDeviceDetailsEntityAttribute.IsAssociatedWithCOGEN,BoilerBuildDeviceDetailsEntityAttribute.IsBoilerEquippedWithManholes,
                        BoilerBuildDeviceDetailsEntityAttribute.BoilerInputCapacity,BoilerBuildDeviceDetailsEntityAttribute.ReplacingBurner,BoilerBuildDeviceDetailsEntityAttribute.DualBurningCapacity,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerULCSAETLNumber,BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute,
                        BoilerBuildDeviceDetailsEntityAttribute.IsBoilerHeatingaSingleAppartment,BoilerBuildDeviceDetailsEntityAttribute.BoilerListingAgencyName,BoilerBuildDeviceDetailsEntityAttribute.BoilerCertificationNumber,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerIsThisExisting, BoilerBuildDeviceDetailsEntityAttribute.BurnerDoesDualCapability,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerInputCapacity,BoilerBuildDeviceDetailsEntityAttribute.BoilerDesign, BoilerBuildDeviceDetailsEntityAttribute.BoilerComments,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringRate,BoilerBuildDeviceDetailsEntityAttribute.BurnerFiringBTUHour,BoilerBuildDeviceDetailsEntityAttribute.BurnerComments,BoilerBuildDeviceDetailsEntityAttribute.BurnerType,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerModelNumber,BoilerBuildDeviceDetailsEntityAttribute.FDNYPermitNumber,  BoilerBuildDeviceDetailsEntityAttribute.BurnerApplianceConnectedTo,
                        BoilerBuildDeviceDetailsEntityAttribute.BurnerManufacturer, BoilerBuildDeviceDetailsEntityAttribute.OccupancyType,BoilerBuildDeviceDetailsEntityAttribute.SerialNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerModel,
                        BoilerBuildDeviceDetailsEntityAttribute.constructionMaterial,BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationFloor,BoilerBuildDeviceDetailsEntityAttribute.FSFloorNumber,BoilerBuildDeviceDetailsEntityAttribute.ServiceLocationAddress,
                        BoilerBuildDeviceDetailsEntityAttribute.BTU,BoilerBuildDeviceDetailsEntityAttribute.BoilerManufacturer,BoilerBuildDeviceDetailsEntityAttribute.Locatedin,BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup,BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup,
                        BoilerBuildDeviceDetailsEntityAttribute.NationalBoardNumber,BoilerBuildDeviceDetailsEntityAttribute.BoilerDeviceNumber,BoilerBuildDeviceDetailsEntityAttribute.Efficiency,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerStatus,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerClassification,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerRating,BoilerBuildDeviceDetailsEntityAttribute.AccelaBoilerMaxWorkingPressure,
                        BoilerBuildDeviceDetailsEntityAttribute.PressureSettingOfreliefValvepsi,BoilerBuildDeviceDetailsEntityAttribute.InternalAccess}, preTargetEntity.Id, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

            }
            return BoilerBuildDevices;
        }





        public static void BoilerCreateUpdateDeviceonAccelaResults(IOrganizationService service, Entity BoilerDevice, StringBuilder crmTrace)
        {
            try
            {
                int scopeType = 0, ScopeOfWSorkType = 0;
                string tempNumber = string.Empty;
                crmTrace.AppendLine("Get the Job filing Details");

                Entity jobFiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling).Id, new Microsoft.Xrm.Sdk.Query.ColumnSet(new string[] { JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.BEScopeIncludesBL, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.FilingStatus }));

                if (jobFiling != null && jobFiling.Id != null)
                {
                    crmTrace.AppendLine("Check if jobfiling is boiler work type");
                    if (jobFiling.Id != null && (jobFiling.Contains(JobFilingEntityAttributeName.BEScopeIncludesBL) && jobFiling[JobFilingEntityAttributeName.BEScopeIncludesBL] != null))//work for only new jobfilings only

                    {
                        scopeType = jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value;


                    }
                }

                Entity ScopeOfWork = getBoilerScopeOfWorkDetailsFromBoilerDevice(service, BoilerDevice, crmTrace);

                if (ScopeOfWork != null && ScopeOfWork.Id != null)
                {
                    ScopeOfWSorkType = ScopeOfWork.GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ScopeOfWSorkType).Value;
                }


                Entity bbd_BoilerDevice = getBoilerBuildDeviceDetailsFromDevice(service, BoilerDevice, crmTrace);

                if (shouldCreateAnyNewDevice(scopeType, ScopeOfWSorkType, BoilerDevice))
                {
                    if (shouldCreateNewBoilerDevice(scopeType, ScopeOfWSorkType)) //Number Generation should only trigger for Boiler Device creation only
                    {
                        crmTrace.AppendLine("5)Create New Device and new number");
                        //  tempNumber = GenerateBoilerDeviceNumber(serviceConnector, preTargetEntity, customTrace, preTargetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName).Value, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType);

                    }
                    else
                    {
                        tempNumber = BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute] != null ? BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute) : string.Empty;
                    }

                    crmTrace.AppendLine("Creation of new boiler device started");
                    CreateBoilerMasterDeviceNumber(service, jobFiling, crmTrace, string.IsNullOrEmpty(tempNumber) ? (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber] != null ? BoilerDevice.GetAttributeValue<string>(BoilerBuildDeviceDetailsEntityAttribute.TrackingNumber) : string.Empty) : tempNumber, bbd_BoilerDevice, ScopeOfWork, scopeType, ScopeOfWSorkType, bbd_BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && bbd_BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null ? bbd_BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id : new Guid());
                }
                else
                {

                    crmTrace.AppendLine("5)Update the Device based on existing Number");
                    // UpdateBoilerMasterDeviceNumber(serviceConnector, preTargetEntity, customTrace, BoilerDevice, BoilerScopeOfWorkCollection.Entities[0], scopeType, ScopeOfWSorkType);

                }





            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(BoilerDevice.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }


        }




        public static void BoilerPassFinalResult(IOrganizationService service, Entity JobFiling, StringBuilder crmTrace)
        {
            try
            {


                crmTrace.AppendLine("1)Get the Scope of work fields from jobfiling");


                int scopeType, scopeOfWorkType;
                bool FBScope = false;
                bool FSScope = false;
                Entity MasterDevice = new Entity(BoilerMasterDevice.EntityLogicalName);
                Entity FSMasterDevice = new Entity(FulelStorageMaster.EntityLogicalName);
                Entity FBMasterDevice = new Entity(FulelBurnerMaster.EntityLogicalName);
                crmTrace.AppendLine("ScopeOfWorkCollection retrieve");
                EntityCollection ScopeOfWorkCollection = getBoilerScopeOfWorkDetailsFromJF(service, JobFiling, crmTrace);
                crmTrace.AppendLine("ScopeOfWorkCollection retrieve" + ScopeOfWorkCollection.Entities.Count);

                if (ScopeOfWorkCollection != null && ScopeOfWorkCollection.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ScopeOfWorkCollection.Entities.Count");
                    scopeOfWorkType = ScopeOfWorkCollection.Entities[0].GetAttributeValue<OptionSetValue>(BEScopeOfWorkEntityAttribute.ScopeOfWSorkType).Value;
                    crmTrace.AppendLine("scopeOfWorkType " + scopeOfWorkType);

                    if (ScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.FBScope))
                    {

                        FBScope = ScopeOfWorkCollection.Entities[0].GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FBScope);
                        crmTrace.AppendLine(FBScope.ToString());

                    }
                    if (ScopeOfWorkCollection.Entities[0].Contains(BEScopeOfWorkEntityAttribute.FSScope))
                    {
                        FSScope = ScopeOfWorkCollection.Entities[0].GetAttributeValue<bool>(BEScopeOfWorkEntityAttribute.FSScope);
                        crmTrace.AppendLine(crmTrace.ToString());
                    }
                    scopeType = JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BEScopeIncludesBL).Value;
                    crmTrace.AppendLine(scopeType.ToString());

                    crmTrace.AppendLine("2)Get BBD from Scope of work");
                    EntityCollection BoilerBuildDevicesCollection = getBoilerBuildDeviceDetailsFromScopeOfWork(service, JobFiling, ScopeOfWorkCollection, crmTrace, (int)ExistingProposedOptionSet.Proposed);//In Pass final always get the proposed devices
                    EntityCollection BoilerBuildDevicesCollectionExisting = getBoilerBuildDeviceDetailsFromScopeOfWork(service, JobFiling, ScopeOfWorkCollection, crmTrace, (int)ExistingProposedOptionSet.Existing);//In Pass final always get the proposed devices

                    if (BoilerBuildDevicesCollectionExisting != null && BoilerBuildDevicesCollectionExisting.Entities.Count > 0)
                    {
                        foreach (Entity BoilerDevice in BoilerBuildDevicesCollectionExisting.Entities)
                        {
                            if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                            {
                                Guid FuelStorageid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Id;

                                if (scopeOfWorkType == (int)BoilerScopeOfWorkType.AbandoningofTank)
                                {
                                    crmTrace.AppendLine("FS Status");
                                    FSMasterDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.Abandoned));
                                    if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                                    {
                                        Guid Boilerid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id;
                                        MasterDevice.SetAttributeValue(BoilerMasterDevice.LatestFuelStorageDevice, null);
                                        MasterDevice.Id = Boilerid;
                                        service.Update(MasterDevice);
                                    }

                                }
                                if (scopeOfWorkType == (int)BoilerScopeOfWorkType.RemovalofTank)
                                {
                                    crmTrace.AppendLine("FS Status");
                                    FSMasterDevice.SetAttributeValue(FulelStorageMaster.FuelStorageStatus, new OptionSetValue((int)BoilerDeviceStatus.Removed));
                                    if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler] != null)
                                    {
                                        Guid Boilerid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id;
                                        MasterDevice.SetAttributeValue(BoilerMasterDevice.LatestFuelStorageDevice, null);
                                        MasterDevice.Id = Boilerid;
                                        service.Update(MasterDevice);
                                    }

                                }

                                FSMasterDevice.Id = FuelStorageid;
                                service.Update(FSMasterDevice);


                            }
                        }
                    }


                    if (BoilerBuildDevicesCollection != null && BoilerBuildDevicesCollection.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("3)for each boiler update the status");
                        foreach (Entity BoilerDevice in BoilerBuildDevicesCollection.Entities)
                        {
                            int existingnergysource = 0;
                            EntityCollection ExistingDeviceCollection = new EntityCollection();
                            Entity existing = new Entity(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName);

                            if (BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup] != null)
                            {
                                Guid Existingdevideid = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.existingBoilerBuildDeviceLookup).Id;
                                ConditionExpression condition1 = new ConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId, ConditionOperator.Equal, Existingdevideid.ToString());
                                ExistingDeviceCollection = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { }, new ConditionExpression[] { condition1 }, LogicalOperator.And, "createdon", OrderType.Descending, 1);

                            }
                            if (ExistingDeviceCollection != null && ExistingDeviceCollection.Entities.Count > 0)
                            {

                                existing = ExistingDeviceCollection.Entities[0];
                                if (ExistingDeviceCollection.Entities[0].Contains(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource))
                                {
                                    existingnergysource = ExistingDeviceCollection.Entities[0].GetAttributeValue<OptionSetValue>(BoilerBuildDeviceDetailsEntityAttribute.BoilerEnergySource).Value;
                                }

                            }
                            else
                            {
                                existing = BoilerDevice;
                            }
                            UpdateBoilerDeviceStatusonPassFinal(service, JobFiling, crmTrace, BoilerDevice, scopeType, scopeOfWorkType);

                            if (scopeOfWorkType == (int)BoilerScopeOfWorkType.Modification && scopeType == (int)BoilerScopeIncludes.Boiler)
                            {
                                AddBoilerDeviceDetailsToMaster(JobFiling, crmTrace, BoilerDevice, ScopeOfWorkCollection.Entities[0], MasterDevice, scopeOfWorkType, existingnergysource);
                                MasterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.GotoBoiler).Id;
                                service.Update(MasterDevice);

                            }
                            if (scopeOfWorkType == (int)BoilerScopeOfWorkType.Modification && FBScope && BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup] != null)
                            {

                                AddFuelBurnerDeviceDetailsToMaster(JobFiling, crmTrace, BoilerDevice, ScopeOfWorkCollection.Entities[0], FBMasterDevice, scopeType, scopeOfWorkType, BoilerDevice);
                                FBMasterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelBurnerMasterLookup).Id;
                                service.Update(FBMasterDevice);

                            }
                            if (scopeOfWorkType == (int)BoilerScopeOfWorkType.Modification && FSScope && BoilerDevice.Contains(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup) && BoilerDevice[BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup] != null)
                            {
                                AddFuelStorageDeviceDetailsToMaster(JobFiling, crmTrace, BoilerDevice, ScopeOfWorkCollection.Entities[0], FSMasterDevice, scopeType, scopeOfWorkType, BoilerDevice);
                                FSMasterDevice.Id = BoilerDevice.GetAttributeValue<EntityReference>(BoilerBuildDeviceDetailsEntityAttribute.FuelStorageMasterLookup).Id;
                                service.Update(FSMasterDevice);

                            }


                            //if (scopeType == (int)BoilerScopeIncludes.Boiler && scopeOfWorkType == (int)BoilerScopeOfWorkType.Replacement)
                            //{
                            //    //Associate Old Boiler Burners and Fuel Storages to Newly created Boiler
                            //    crmTrace.AppendLine("3)Associate Old Boiler Burners and Fuel Storages to Newly created Boiler");
                            //    AssociateBurnersFuelStoragesToNewBoiler(service, crmTrace, BoilerDevice, scopeType, scopeOfWorkType);
                            //}
                        }
                    }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), "CRM", "FeeCalculationStandardizationHandler - BoilerPassFinalResult", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }

        public static void DeactivateExceptionDocument(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            ConditionExpression documentListCondition = new ConditionExpression(
                            DocumentListEntityAttributeName.DocumentListtoJobfiling,
                            ConditionOperator.Equal,
                           targetEntity.Id);
            ConditionExpression RejectedStatus = new ConditionExpression(DocumentListEntityAttributeName.DocumentStatus, ConditionOperator.In, new int[] { 4 });
            QueryExpression query = new QueryExpression(DocumentListEntityAttributeName.EntityLogicalName);
            query.ColumnSet = new ColumnSet(DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.DocumentStatus, DocumentListEntityAttributeName.DocumentListId);
            query.Criteria.FilterOperator = LogicalOperator.And;
            query.Criteria.AddCondition(documentListCondition);
            query.Criteria.AddCondition(RejectedStatus);
            EntityCollection documentListResponse = service.RetrieveMultiple(query);
            if (documentListResponse.Entities.Count > 0)
            {
                DeactivateRecord(crmTrace, DocumentListEntityAttributeName.EntityLogicalName, documentListResponse[0].Id, service);
                //service.Delete(DocumentListEntityAttributeName.EntityLogicalName, documentListResponse[0].Id);
            }


        }
        //Deactivate a record
        public static void DeactivateRecord(StringBuilder crmTrace, string entityName, Guid recordId, IOrganizationService organizationService)
        {
            try
            {
                var cols = new ColumnSet(new[] { "statecode", "statuscode" });
                crmTrace.AppendLine(" Deactivate Record Started");
                //Check if it is Active or not
                var entity = organizationService.Retrieve(entityName, recordId, cols);

                if (entity != null && entity.GetAttributeValue<OptionSetValue>("statecode").Value == 0)
                {
                    //StateCode = 1 and StatusCode = 2 for deactivating Account or Contact
                    SetStateRequest setStateRequest = new SetStateRequest()
                    {
                        EntityMoniker = new EntityReference
                        {
                            Id = recordId,
                            LogicalName = entityName,
                        },
                        State = new OptionSetValue(1),
                        Status = new OptionSetValue(2)
                    };
                    organizationService.Execute(setStateRequest);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(recordId.ToString(), SourceChannel.CRM, "JobFilingSupersedingHandler - DeactivateRecord", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    }
}
