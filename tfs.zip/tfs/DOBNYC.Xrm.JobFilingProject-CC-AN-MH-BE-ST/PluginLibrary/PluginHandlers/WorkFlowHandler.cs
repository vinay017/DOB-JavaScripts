﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class WorkFlowHandler : PluginHandlerBase
    {
        public static void JobFilingWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("JobFilingWorkFlows Started!");

                #region Superseding DP Request
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupersedingRequestStatus))
                {
                    int currentSupersedingRequestStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.SupersedingRequestStatus).Value;
                    crmTrace.AppendLine("currentSupersedingRequestStatus: " + currentSupersedingRequestStatus.ToString());
                    int PreviousSupersedingRequestStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.SupersedingRequestStatus).Value;
                    crmTrace.AppendLine("PreviousSupersedingRequestStatus: " + PreviousSupersedingRequestStatus.ToString());

                    if (currentSupersedingRequestStatus != PreviousSupersedingRequestStatus)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Superseding DP- Job Filing - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                    }
                }

                #endregion

                #region Job Filing - Master Workflow
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                {
                    int currentFilingStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                    crmTrace.AppendLine("currentFilingStatus: " + currentFilingStatus.ToString());
                    int PreviousFilingStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                    crmTrace.AppendLine("PreviousFilingStatus: " + PreviousFilingStatus.ToString());

                    if (currentFilingStatus != PreviousFilingStatus && PreviousFilingStatus != (int)CurrentFilingStatus.OnHold_NoGoodCheck)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Job Filing - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);

                        //Guid processId2 = new Guid(GetProcessId(service, "workflow", "name", "Email Notifications").Id.ToString());
                        //crmTrace.AppendLine("processId2:  " + processId2.ToString());
                        //ExecuteWorkflow(service, processId2, targetEntity.Id);
                 
                    }
                }
                #endregion

                #region Job LOC - Master Workflow
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobStatus))
                //{
                //    int CurrentJobStatus = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                //    if (CurrentJobStatus == (int)JobStatus.LOCIssued)
                //    {
                //        crmTrace.AppendLine("Start  LOC Email Process: " + PluginHelperStrings.UpdateMessageName);
                //        JobFilingLOCHandler.SendEmail(service, targetEntity, crmTrace);
                //        crmTrace.AppendLine("End  LOC Email Process: " + PluginHelperStrings.UpdateMessageName);

                //    }
                //}
                #endregion
                crmTrace.AppendLine("JobFilingWorkFlows Completed!");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - JobFilingWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void WorkPermitWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("WorkPermitWorkFlow Started!");
                #region WorkPermit Workflows
                //if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.IsWorkPermitSubmitted) || targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.WorkPermitStatus))
                if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.WorkPermitStatus))
                {
                    //bool isWorkPermitSubmitted = targetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.IsWorkPermitSubmitted);
                    //crmTrace.AppendLine("isWorkPermitSubmitted : " + isWorkPermitSubmitted.ToString());

                    //#region Work Permit - Master Work Flow  On Submit
                    //if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.IsWorkPermitSubmitted) && isWorkPermitSubmitted == true)
                    //{
                    //    Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Work Permit - Master Work Flow").Id.ToString());
                    //    crmTrace.AppendLine("processId:  " + processId.ToString());
                    //    ExecuteWorkflow(service, processId, targetEntity.Id);
                    //    return;
                    //}
                    //#endregion

                    int currentWorkPermitStatus = targetEntity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.WorkPermitStatus).Value;
                    crmTrace.AppendLine("currentWorkPermitStatus: " + currentWorkPermitStatus.ToString());
                    int PreviousWorkPermitStatus = preImage.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.WorkPermitStatus).Value;
                    crmTrace.AppendLine("PreviousWorkPermitStatus: " + PreviousWorkPermitStatus.ToString());

                    #region Work Permit - Master Work Flow On Status Change
                    if (currentWorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignment ||
                        currentWorkPermitStatus == (int)WorkpermitStatus.QAReview ||
                        currentWorkPermitStatus == (int)WorkpermitStatus.PermitIssued ||
                        currentWorkPermitStatus == (int)WorkpermitStatus.QAFailed ||
                        currentWorkPermitStatus == (int)WorkpermitStatus.L2ApprovedQAReview ||
                        currentWorkPermitStatus == (int)WorkpermitStatus.L2ApprovedProfCertQAReview||
                        currentWorkPermitStatus == (int)WorkpermitStatus.PermitSignedoff
                        )
                    {
                        if (currentWorkPermitStatus != PreviousWorkPermitStatus)
                        {
                            Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Work Permit - Master Work Flow").Id.ToString());
                            crmTrace.AppendLine("processId:  " + processId.ToString());
                            ExecuteWorkflow(service, processId, targetEntity.Id);
                        }
                    }
                    #endregion

                    #region Work Permit Sign off - Master Work Flow
                    // Old Signoff Logic Commented on 06/30/2017
                    //if (currentWorkPermitStatus == (int)WorkpermitStatus.AccelaWTSignoff ||
                    //    currentWorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignmentforSignoff ||
                    //    currentWorkPermitStatus == (int)WorkpermitStatus.QAReviewforSignoff ||
                    //    currentWorkPermitStatus == (int)WorkpermitStatus.PermitSignedoff ||
                    //    currentWorkPermitStatus == (int)WorkpermitStatus.ObjectionstoSignoff ||
                    //    currentWorkPermitStatus == (int)WorkpermitStatus.PermitSignedoff)
                    //{
                    //    if (currentWorkPermitStatus != PreviousWorkPermitStatus)
                    //    {
                    //        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Work Permit Sign off - Master Work Flow").Id.ToString());
                    //        crmTrace.AppendLine("processId:  " + processId.ToString());
                    //        ExecuteWorkflow(service, processId, targetEntity.Id);
                    //    }
                    //}
                    #endregion


                }

                    #endregion

                crmTrace.AppendLine("WorkPermitWorkFlow Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WorkPermitWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void WithdrawalWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("WithdrawalWorkFlow Started!");
                #region WorkPermit Workflows
                if (targetEntity.Attributes.Contains(WithdrawalRequestEntityAttributeName.IsSubmitted) || targetEntity.Attributes.Contains(WithdrawalRequestEntityAttributeName.WithdrawalStatus))
                {
                    bool isWithdrawalSubmitted = targetEntity.GetAttributeValue<bool>(WithdrawalRequestEntityAttributeName.IsSubmitted);
                    crmTrace.AppendLine("isWorkPermitSubmitted : " + isWithdrawalSubmitted.ToString());

                    #region Withdrawal Request - Master Work Flow  On Submit
                    if (targetEntity.Attributes.Contains(WithdrawalRequestEntityAttributeName.IsSubmitted) && isWithdrawalSubmitted == true)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Withdrawal Request _ Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                        return;
                    }
                    #endregion

                    int currentWithdrawalStatus = targetEntity.GetAttributeValue<OptionSetValue>(WithdrawalRequestEntityAttributeName.WithdrawalStatus).Value;
                    crmTrace.AppendLine("currentWithdrawalStatus: " + currentWithdrawalStatus.ToString());
                    int PreviousWithdrawalStatus = preImage.GetAttributeValue<OptionSetValue>(WithdrawalRequestEntityAttributeName.WithdrawalStatus).Value;
                    crmTrace.AppendLine("PreviousWorkPermitStatus: " + PreviousWithdrawalStatus.ToString());

                    #region Withdrawal Request - Withdrawal Request _ Master Workflow On Status Change
                      if (currentWithdrawalStatus != PreviousWithdrawalStatus)
                        {
                            Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Withdrawal Request _ Master Workflow").Id.ToString());
                            crmTrace.AppendLine("processId:  " + processId.ToString());
                            ExecuteWorkflow(service, processId, targetEntity.Id);
                        }
                    
                    #endregion
                                    
                }

                #endregion

                crmTrace.AppendLine("WithdrawalWorkFlow Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - WithdrawalWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SupersedingWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("SupersedingWorkFlow Started!");
                #region Superseding Workflows
                if (targetEntity.Attributes.Contains(SupersedingRequestEntityAttributeName.SupersedingRequestStatus))
                {
                    int currentSupersedingStatus = targetEntity.GetAttributeValue<OptionSetValue>(SupersedingRequestEntityAttributeName.SupersedingRequestStatus).Value;
                    crmTrace.AppendLine("currentSupersedingStatus: " + currentSupersedingStatus.ToString());
                    int PreviousSupersedingStatus = preImage.GetAttributeValue<OptionSetValue>(SupersedingRequestEntityAttributeName.SupersedingRequestStatus).Value;
                    crmTrace.AppendLine("PreviousSupersedingStatus: " + PreviousSupersedingStatus.ToString());

                    #region Superseding Request - Superseding Request _ Master Workflow On Status Change
                    if (currentSupersedingStatus != PreviousSupersedingStatus)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Superseding Request - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                    }

                    #endregion

                }

                #endregion

                crmTrace.AppendLine("SupersedingWorkFlow Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - SupersedingWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AddressChangeWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("AddressChangeWorkFlow Started!");
                #region AddressChange Workflows
                if (targetEntity.Attributes.Contains(AddressChangeRequestsEntityAttributeName.IsSubmitted) || targetEntity.Attributes.Contains(AddressChangeRequestsEntityAttributeName.RequestStatus))
                {
                    bool isAddressChangeSubmitted = targetEntity.GetAttributeValue<bool>(AddressChangeRequestsEntityAttributeName.IsSubmitted);
                    crmTrace.AppendLine("isAddressChangeSubmitted : " + isAddressChangeSubmitted.ToString());

                    #region Address Change Request - Workflow  On Submit
                    if (targetEntity.Attributes.Contains(AddressChangeRequestsEntityAttributeName.IsSubmitted) && isAddressChangeSubmitted == true)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Address Change Request - Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                        return;
                    }
                    #endregion

                    int currentRequestStatus = targetEntity.GetAttributeValue<OptionSetValue>(AddressChangeRequestsEntityAttributeName.RequestStatus).Value;
                    crmTrace.AppendLine("currentWithdrawalStatus: " + currentRequestStatus.ToString());
                    int PreviousRequestStatus = preImage.GetAttributeValue<OptionSetValue>(AddressChangeRequestsEntityAttributeName.RequestStatus).Value;
                    crmTrace.AppendLine("PreviousWorkPermitStatus: " + PreviousRequestStatus.ToString());

                    #region Withdrawal Request - Withdrawal Request _ Master Workflow On Status Change
                    if (currentRequestStatus != PreviousRequestStatus)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "Address Change Request - Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                    }

                    #endregion

                }

                #endregion

                crmTrace.AppendLine("AddressChangeWorkFlow Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AddressChangeWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void AHVWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("AHVWorkFlow Started!");
                #region AHVWorkFlow 
                if (targetEntity.Contains(AfterHourVarianceAttributeNames.AHVPermitStatus) && preImage.Contains(AfterHourVarianceAttributeNames.AHVPermitStatus)) //added because on save of AHV integartion is not sending AHVpermitstatus
                {
                    int currentAHVStatus = targetEntity.GetAttributeValue<OptionSetValue>(AfterHourVarianceAttributeNames.AHVPermitStatus).Value;
                    crmTrace.AppendLine("currentAHVStatus: " + currentAHVStatus.ToString());
                    int PreviousAHVStatus = preImage.GetAttributeValue<OptionSetValue>(AfterHourVarianceAttributeNames.AHVPermitStatus).Value;
                    crmTrace.AppendLine("PreviousAHVStatus: " + PreviousAHVStatus.ToString());

                    int typeofPermit = preImage.GetAttributeValue<OptionSetValue>(PW5AfterHoursAttributeNames.TypeofPermit).Value;
                    crmTrace.AppendLine("typeofPermit: " + typeofPermit.ToString());

                    #region AHV - Master Workflow On Status Change
                    if (currentAHVStatus != PreviousAHVStatus)
                    {
                        if (typeofPermit != (int)TypeofAHVPermit.CraneNotice && typeofPermit != (int)TypeofAHVPermit.MasterRigger && typeofPermit != (int)TypeofAHVPermit.OnsiteWaiver)
                        {
                            Guid processId = new Guid(GetProcessId(service, "workflow", "name", "AHV - Master Workflow").Id.ToString());
                            crmTrace.AppendLine("processId:  " + processId.ToString());
                            ExecuteWorkflow(service, processId, targetEntity.Id);
                        }
                        else
                        {
                            string WFname = "CN AHV - Master Workflow";
                            if (typeofPermit == (int)TypeofAHVPermit.MasterRigger)
                                WFname = "MasterRigger AHV - Master Workflow";
                            Guid processId = new Guid(GetProcessId(service, "workflow", "name", WFname).Id.ToString());
                            crmTrace.AppendLine("processId:  " + processId.ToString());
                            ExecuteWorkflow(service, processId, targetEntity.Id);
                        }


                        #region Create Build Trace - 4/17/2019
                        if (currentAHVStatus == (int)AHVPermitStatus.Approved)
                        {
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "Approved", crmTrace);
                        }
                        if (currentAHVStatus == (int)AHVPermitStatus.AHVPermitIssued)
                        {
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "AHV Permit Issued", crmTrace);
                        }
                        if (currentAHVStatus == (int)AHVPermitStatus.AHVPermitRejected)
                        {
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "AHV Permit Rejected", crmTrace);
                        }
                        if (currentAHVStatus == (int)AHVPermitStatus.OnHoldNoGoodCheck)
                        {
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "On Hold-No Good Check", crmTrace);
                        }
                        #endregion
                    }

                    #endregion
                }

                #endregion

                crmTrace.AppendLine("AHVWorkFlow Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - AHVWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void LOCRequestWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("LOC Request Workflow Started!");
                #region LOC Request Workflows
                //if (targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.IsSubmitted) || preImage.Attributes.Contains(LOCPW7EntityAttributeName.IsSubmitted))
                //{
                //    bool isLOCSubmitted = targetEntity.GetAttributeValue<bool>(LOCPW7EntityAttributeName.IsSubmitted);
                //    crmTrace.AppendLine("isLOCSubmitted : " + isLOCSubmitted.ToString());

                //    #region LOC - Master Workflow  On Submit
                //    if (targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.IsSubmitted) && isLOCSubmitted)
                //    {
                //        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "LOC - Master Workflow").Id.ToString());
                //        crmTrace.AppendLine("processId:  " + processId.ToString());
                //        ExecuteWorkflow(service, processId, targetEntity.Id);
                //        return;
                //    }
                //    #endregion
                //}

                if (targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.LOCRequestStatus))
                {
                    int currentLOCRequestStatus = targetEntity.GetAttributeValue<OptionSetValue>(LOCPW7EntityAttributeName.LOCRequestStatus).Value;
                    crmTrace.AppendLine("currentLOCRequestStatus: " + currentLOCRequestStatus.ToString());

                    int previousLOCStatus = preImage.GetAttributeValue<OptionSetValue>(LOCPW7EntityAttributeName.LOCRequestStatus).Value;
                    crmTrace.AppendLine("previousLOCStatus: " + previousLOCStatus.ToString());

                    #region LOC - Master Workflow On Status Change
                    if (currentLOCRequestStatus != previousLOCStatus)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "LOC - Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);

                        #region Update Filing Status and Pemrits on LOC Issued
                        if (currentLOCRequestStatus == (int)LOCRequestStatus.LOCIssued)
                        {
                            JobFilingLOCHandler.UpdateJobFilingStatus_LOC(service, preImage, JobFilingEntityAttributeName.FilingStatus, (int)CurrentFilingStatus.SignedOff, crmTrace);
                            JobFilingLOCHandler.UpdatePermits_LOCIssued(service, preImage, crmTrace);
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "LOC Issued",crmTrace);
                        }
                        #endregion

                        #region Objections to LOC 
                        if (currentLOCRequestStatus == (int)LOCRequestStatus.Reject)
                        {
                            SubmitHandler.CreateBuildTrace(service, targetEntity, preImage, "Objections to LOC", crmTrace);
                        }
                        #endregion
                    }
                    #endregion
                }
                
                #endregion

                crmTrace.AppendLine("LOC Request Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - LOC Request Workflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void PACORequestWorkFlow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            try
            {
                crmTrace.AppendLine("PACORequestWorkFlow Started!");
                #region PACORequestWorkFlows

                if (targetEntity.Attributes.Contains(PlaceofAssemblySpaceInformation.PACOreportStatus))
                {
                    int currentReportStatus = targetEntity.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value;

                    crmTrace.AppendLine("currentReportStatus: " + currentReportStatus.ToString());

                    int previousReportStatus = preImage.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value;
                    crmTrace.AppendLine("previousReportStatus: " + previousReportStatus.ToString());

                    #region PACO - Master Workflow On Status Change
                    if (currentReportStatus != previousReportStatus)
                    {
                        Guid processId = new Guid(GetProcessId(service, "workflow", "name", "PACO – Master Workflow").Id.ToString());
                        crmTrace.AppendLine("processId:  " + processId.ToString());
                        ExecuteWorkflow(service, processId, targetEntity.Id);
                    }
                    #endregion
                }

                #endregion

                crmTrace.AppendLine("PACO Request Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - PACORequestWorkFlow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void OP49MasterWorkflow(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("OP49 - Master Workflow Started!");
                #region OP49MasterWorkflow
                Guid processId = new Guid(GetProcessId(service, "workflow", "name", "OP49 - Master Workflow").Id.ToString());
                crmTrace.AppendLine("processId:  " + processId.ToString());
                ExecuteWorkflow(service, processId, targetEntity.Id);
                crmTrace.AppendLine("OP49 - Master Workflow  Completed!");
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkFlowHandler - OP49MasterWorkflow", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void ExecuteWorkflow(IOrganizationService connector, Guid workflowId, Guid entityId)
        {
            try
            {
                ExecuteWorkflowRequest request = new ExecuteWorkflowRequest
                {
                    EntityId = entityId,
                    WorkflowId = workflowId
                };

                connector.Execute(request);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public static Entity GetProcessId(IOrganizationService service, string EntityLogicalName, string SearchFieldName, object SearchValue)
        {
            EntityLogicalName = EntityLogicalName.ToLower();
            SearchFieldName = SearchFieldName.ToLower();
            QueryExpression query = new QueryExpression(EntityLogicalName);
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition(new ConditionExpression(SearchFieldName, ConditionOperator.Equal, SearchValue));
            query.Criteria.AddCondition(new ConditionExpression("type", ConditionOperator.Equal, 1));

            try
            {
                EntityCollection response = service.RetrieveMultiple(query);
                if (response != null && response.Entities.Count > 0)
                    return response.Entities[0];
                else { return null; }

            }
            catch (Exception ex)
            {
                //Do error hadling
                throw ex;
            }

        }  // getProcessId ends here

    } //class ends
} // namespace ends
