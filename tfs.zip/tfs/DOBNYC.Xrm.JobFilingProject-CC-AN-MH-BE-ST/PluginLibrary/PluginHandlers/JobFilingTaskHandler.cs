﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobFilingTaskHandler : PluginHandlerBase
    {
        public static void AssociateObjectionsOnTask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateObjectionsOnTask Plan Examiner started!");
                ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.JobFilingObjectionsId, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                EntityCollection objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                EntityReferenceCollection objections = new EntityReferenceCollection();
                //Guid OldPlanExaminerTaskid = Guid.Empty;
                crmTrace.AppendLine("Initialized objectionCondition Plan Examiner Condition Expression");
                if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("objecttionResponse count: " + objecttionResponse.Entities.Count);
                    for (int i = 0; i < objecttionResponse.Entities.Count; i++)
                        objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objecttionResponse.Entities[i].Id));
                    // OldPlanExaminerTaskid = ((EntityReference)(objecttionResponse.Entities[i].Attributes[ObjectionsEntityAttributeNames.PlanExaminerObjectionsId])).Id;

                    //crmTrace.AppendLine("Start Dis-association for Plan Examiner Objections");
                    //service.Disassociate(TaskEntityAttributeNames.EntityLogicalName, OldPlanExaminerTaskid, new Relationship(TaskEntityAttributeNames.PlanExaminerObjections), objections);
                    //crmTrace.AppendLine("End Dis-association for Plan Examiner Objections");

                    crmTrace.AppendLine("Start Association for Plan Examiner Objections");
                    //Multiple Stakeholders - SPE Task Completion: Start
                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsMultiStakesForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsMultiStakesForm) == true)
                        && (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSecondaryPETaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsSecondaryPETaskForm) == true))
                    {
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.SecondaryPlanExaminerObjectionsRelationShipName), objections);
                    }
                    else
                    {
                    //Multiple Stakeholders - SPE Task Completion: End
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.PlanExaminerObjectionsRelationShipName), objections);
                    }
                    crmTrace.AppendLine("End Association for Plan Examiner Objections");
                }


                crmTrace.AppendLine("AssociateObjectionsOnTask Plan Examiner End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void UpdateDocumentsOnTask(IOrganizationService service, Entity preImage_jobFilingRecord, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("UpdateDocumentsOnTask  started!");
                #region Get Open task for Job Filing
                ConditionExpression taskCondition1 = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { preImage_jobFilingRecord.Id.ToString() });
                ConditionExpression taskCondition2 = CreateConditionExpression(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, new object[] { TaskEntitySatus.Open });
                EntityCollection taskresponse = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.CurrentFilingStatus }, new ConditionExpression[] { taskCondition1, taskCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the Open Tasks");
                if ((taskresponse == null) || (taskresponse.Entities.Count == 0))
                    return;
                crmTrace.AppendLine("taskresponse count: " + taskresponse.Entities.Count);
                crmTrace.AppendLine("taskresponse.Entities[0].Id: " + taskresponse.Entities[0].Id);

                #endregion
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { preImage_jobFilingRecord.Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.Equal, new object[] { (int)CurrentFilingStatus.Approved });
                ConditionExpression documentCondition3 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.NotEqual, new object[] { (int)CurrentFilingStatus.SignedOff });
                EntityCollection documentResponse = new EntityCollection();
                int filingstatus = preImage_jobFilingRecord.Contains(JobFilingEntityAttributeName.FilingStatus) ? preImage_jobFilingRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value : (int)CurrentFilingStatus.PreFiling;
                crmTrace.AppendLine("filingstatus: " + filingstatus);
                if (filingstatus == (int)CurrentFilingStatus.PendingPlanExaminer || filingstatus == (int)CurrentFilingStatus.PlanExaminerReview || filingstatus == (int)CurrentFilingStatus.CheifPlanExaminerReview)
                documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And); 

                if (filingstatus == (int)CurrentFilingStatus.ProfCertQAinReview || filingstatus == (int)CurrentFilingStatus.PendingProfCertQAReview || filingstatus == (int)CurrentFilingStatus.PendingProfCertQAAssignment || filingstatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview)
                    documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition3 }, LogicalOperator.And); 

                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));
                    if (filingstatus == (int)CurrentFilingStatus.PlanExaminerReview)
                    {
                        crmTrace.AppendLine("Start Association for Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.PlanExaminerDocumentsRelationShipName), documents);
                        crmTrace.AppendLine("End Association for Plan Examiner Documents");
                    }
                    if(filingstatus == (int)CurrentFilingStatus.PendingPlanExaminer || filingstatus == (int)CurrentFilingStatus.CheifPlanExaminerReview)
                    {
                        crmTrace.AppendLine("Start Association for Chief Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.ChiefPlanExaminerDocumentsRelationShipName), documents);
                        crmTrace.AppendLine("End Association for Chief Plan Examiner Documents");
                    }
                    if (filingstatus == (int)CurrentFilingStatus.ProfCertQAinReview || filingstatus == (int)CurrentFilingStatus.PendingProfCertQAReview || filingstatus == (int)CurrentFilingStatus.PendingProfCertQAAssignment || filingstatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview)
                    {
                        crmTrace.AppendLine("Start Association for QA Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.ProfCertQADocumentsRelationShipName), documents);
                        crmTrace.AppendLine("End Association for QA Documents");

                    }

                }
                crmTrace.AppendLine("UpdateDocumentsOnTask End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage_jobFilingRecord.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateDocumentsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnPETask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask Plan Examiner started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.Equal, new object[] { (int)CurrentFilingStatus.Approved });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);  // Select PlanExaminerObjections from ObjectionsEntity where JobFilingObjectionsId = target task entity Regarding Object
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for Plan Examiner Documents");
                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsMultiStakesForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsMultiStakesForm) == true)
                                && (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSecondaryPETaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsSecondaryPETaskForm) == true))
                    {
                        crmTrace.AppendLine("Start Association for Second Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.SPEDocumentsRelationShipName), documents);
                    }
                    else
                    {
                        crmTrace.AppendLine("Start Association for Primary Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.PlanExaminerDocumentsRelationShipName), documents);
                    }
                    
                    crmTrace.AppendLine("End Association for Plan Examiner Documents");
                }
                crmTrace.AppendLine("AssociateDocumentsOnPETask Plan Examiner End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnPETask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnCPETask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask Chief Plan Examiner started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.Equal, new object[] { (int)CurrentFilingStatus.Approved });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);  // Select PlanExaminerObjections from ObjectionsEntity where JobFilingObjectionsId = target task entity Regarding Object
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for Chief Plan Examiner Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.ChiefPlanExaminerDocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for Chief Plan Examiner Documents");
                }



                crmTrace.AppendLine("AssociateObjectionsOnTask Chief Plan Examiner End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCPETask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnQATask_Signoff(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask QA started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.NotEqual, new object[] { (int)CurrentFilingStatus.SignedOff });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);  // Select PlanExaminerObjections from ObjectionsEntity where JobFilingObjectionsId = target task entity Regarding Object
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for QA Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QADocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for QA Documents");
                }



                crmTrace.AppendLine("AssociateObjectionsOnTask QA End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask_Signoff", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }



        }

        public static void AssociateDocumentsOnQATask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)  // Also used for LOC
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask QA started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);  // Select PlanExaminerObjections from ObjectionsEntity where JobFilingObjectionsId = target task entity Regarding Object
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for QA Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QADocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for QA Documents");
                }



                crmTrace.AppendLine("AssociateObjectionsOnTask QA End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }



        public static void AssociateDevicesOnAllTasks(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                EntityCollection documentResponse = new EntityCollection();

                crmTrace.AppendLine("GetAllBoilersFromJobFiling  started!");
                ConditionExpression documentCondition = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });

                documentResponse = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - GetAllBoilersFromJobFiling TEsting1 ", null, "" + documentResponse.Entities.Count, null, null);

                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for QA Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(BoilerBuildDeviceDetailsEntityAttribute.AllTaskFormLookupRelation), documents);
                    crmTrace.AppendLine("End Association for QA Documents");
                }



                crmTrace.AppendLine("AssociateDocumentsOnProfCertQATask  End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDevicesOnPESPE(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                EntityCollection documentResponse = new EntityCollection();

                crmTrace.AppendLine("GetAllBoilersFromJobFiling  started!");
                ConditionExpression documentCondition = CreateConditionExpression(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });

                documentResponse = RetrieveMultiple(service, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, new string[] { BoilerBuildDeviceDetailsEntityAttribute.EntityNameAttribute }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - GetAllBoilersFromJobFiling TEsting1 ", null, "" + documentResponse.Entities.Count, null, null);

                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - GetAllBoilersFromJobFiling TEsting2 ", null, "" + documentResponse.Entities.Count, null, null);
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for Plan Examiner Documents");
                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsMultiStakesForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsMultiStakesForm) == true)
                                && (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSecondaryPETaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsSecondaryPETaskForm) == true))
                    {
                        crmTrace.AppendLine("Start Association for Second Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(BoilerBuildDeviceDetailsEntityAttribute.SecondaryPELookupRelation), documents);
                    }
                    else
                    {
                        crmTrace.AppendLine("Start Association for Primary Plan Examiner Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(BoilerBuildDeviceDetailsEntityAttribute.PrimaryPELookupRelation), documents);
                    }
                }



                crmTrace.AppendLine("AssociateDevicesOnPESPE  End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDevicesOnPESPE", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }


       

        public static void AssociateDocumentsOnProfCertQATask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnProfCertQATask  started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.NotEqual, new object[] { (int)CurrentFilingStatus.SignedOff });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);  // Select PlanExaminerObjections from ObjectionsEntity where JobFilingObjectionsId = target task entity Regarding Object
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for QA Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.ProfCertQADocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for QA Documents");
                }



                crmTrace.AppendLine("AssociateDocumentsOnProfCertQATask  End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnProfCertQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateWorkPermitsOnQATask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateWorkPermitsOnQATask QA started!");
                ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id.ToString() });
                ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.In, new object[] { (int)WorkpermitStatus.ProfCertQAReview, (int)WorkpermitStatus.L2ApprovedProfCertQAReview });
                EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus }, new ConditionExpression[] { workPermitCondition, workPermitCondition2 }, LogicalOperator.And);  
                EntityReferenceCollection workPermits = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the workPermits for the regardingObjectId(job filing) in task");
                if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("workPermitResponse count: " + workPermitResponse.Entities.Count);
                    for (int i = 0; i < workPermitResponse.Entities.Count; i++)
                        workPermits.Add(new EntityReference(WorkPermitEntityAttributeName.EntityLogicalName, workPermitResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for QA workPermits");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QAWorkPermitsRelationShipName), workPermits);
                    crmTrace.AppendLine("End Association for QA workPermits");
                }



                crmTrace.AppendLine("AssociateWorkPermitsOnQATask QA End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateWorkPermitsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateJobFilingsOnQATask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("AssociateJobFilingsOnQATask QA started!");
                #region Old LOC Logic
                ////ConditionExpression JobFilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { targetEntity.GetAttributeValue<string>(TaskEntityAttributeNames.JobNumber) });
                ////EntityCollection JobFilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { JobFilingEntityAttributeName.JobFilingId }, new ConditionExpression[] { JobFilingCondition }, LogicalOperator.And);
                ////EntityReferenceCollection JobFilings = new EntityReferenceCollection();

                //crmTrace.AppendLine("Got all the JobFilings for the job number in task");
                //if (JobFilingResponse != null && JobFilingResponse.Entities != null && JobFilingResponse.Entities.Count > 0)
                //{
                //    crmTrace.AppendLine("JobFilingResponse count: " + JobFilingResponse.Entities.Count);
                //    for (int i = 0; i < JobFilingResponse.Entities.Count; i++)
                //        JobFilings.Add(new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFilingResponse.Entities[i].Id));

                //    crmTrace.AppendLine("Start Association for QA JobFilings");
                //    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QAJobFilingRelationShipName), JobFilings);
                //    crmTrace.AppendLine("End Association for QA JobFilings");
                //}
                #endregion
                #region New LOC Logic
                if(targetEntity.Contains(TaskEntityAttributeNames.ClickheretogotoJobFiling))
                {
                    EntityReference jf_ref = targetEntity.GetAttributeValue<EntityReference>(TaskEntityAttributeNames.ClickheretogotoJobFiling);
                    EntityReferenceCollection JobFilings = new EntityReferenceCollection();
                    JobFilings.Add(jf_ref);
                    crmTrace.AppendLine("Start Association for QA JobFilings");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QAJobFilingRelationShipName), JobFilings);
                    crmTrace.AppendLine("End Association for QA JobFilings");
                }

                #endregion

                crmTrace.AppendLine("AssociateJobFilingsOnQATask QA End!");


            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateJobFilingsOnQATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnTask_Withdrawal(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int WithdrawalRequestStatus)
        {

            try
            {
                
                    crmTrace.AppendLine("AssociateDocumentsOnTask Withdrawal started!");

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoWithdrawalRequest, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoWithdrawalRequest])).Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));
                       
                        // If Withdrawal Status is Pending QA Assignment or QA Review
                        if (WithdrawalRequestStatus == (int)WithdrawalStatus.PendingQAAssignment || WithdrawalRequestStatus == (int)WithdrawalStatus.QAReview)
                        {
                            crmTrace.AppendLine("Start Association for QA Supervisor Documents");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QADocumentsRelationShipName), documents);
                            crmTrace.AppendLine("End Association for QA Supervisor Documents");
                        }

                        // If Withdrawal Status is Pending PE Assignment 
                        if (WithdrawalRequestStatus == (int)WithdrawalStatus.PendingPlanExaminerAssignment)
                        {
                            crmTrace.AppendLine("Start Association for Chief Plan Examiner Documents");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.ChiefPlanExaminerDocumentsRelationShipName), documents);
                            crmTrace.AppendLine("End Association for Chief Plan Examiner Documents");
                        }

                        // If Withdrawal Status is Plan Examiner Review 
                        if (WithdrawalRequestStatus == (int)WithdrawalStatus.PlanExaminerReview)
                        {
                            crmTrace.AppendLine("Start Association for Plan Examiner Documents");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.PlanExaminerDocumentsRelationShipName), documents);
                            crmTrace.AppendLine("End Association for Plan Examiner Documents");
                        }

                }

                crmTrace.AppendLine("AssociateObjectionsOnTask  Withdrawal End!");
                   
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }



        }

        public static void AssociateDocumentsOnTask_Superseding(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int SupersedingRequestStatus)
        {

            try
            {

                crmTrace.AppendLine("AssociateDocumentsOnTask Superseding started!");

                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoSupersedingRequest, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoSupersedingRequest])).Id.ToString() });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");

                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    // If Superseding Status is Pending QA Assignment or QA Review
                    if (SupersedingRequestStatus == (int)SupersedingStatus.PendingQAAssignment || SupersedingRequestStatus == (int)SupersedingStatus.QAReview)
                    {
                        crmTrace.AppendLine("Start Association for QA Supervisor Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QADocumentsRelationShipName), documents);
                        crmTrace.AppendLine("End Association for QA Supervisor Documents");
                    }
                                      
                }

                crmTrace.AppendLine("AssociateObjectionsOnTask  Superseding End!");

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnTask_WorkPermit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int WorkPermitStatus)
        {

            try
            {

                crmTrace.AppendLine("AssociateDocumentsOnTask WorkPermit started!");
                EntityCollection documentResponse = new EntityCollection();

                if (WorkPermitStatus == (int)WorkpermitStatus.QAReviewforSignoff || WorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignmentforSignoff)
                {
                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id.ToString() });
                    documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
             
                }
                else
                {
                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id.ToString() });
                    ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.NotEqual, new object[] { (int)CurrentFilingStatus.SignedOff });
                    documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                }
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");

                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    // If WorkPermit Status is Pending QA Assignment or QA Review
                    if (WorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignment || WorkPermitStatus == (int)WorkpermitStatus.QAReview || WorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignmentforSignoff ||WorkPermitStatus == (int)WorkpermitStatus.QAReviewforSignoff || WorkPermitStatus == (int)WorkpermitStatus.L2ApprovedQAReview)
                    {
                        crmTrace.AppendLine("Start Association for QA Supervisor Documents");
                        service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.QADocumentsRelationShipName), documents);
                        crmTrace.AppendLine("End Association for QA Supervisor Documents");
                    }

                }

                crmTrace.AppendLine("AssociateDocumentsOnTask_WorkPermit End!");

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnTask_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateObjectionsOnTask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, bool isChiefPlanExaimerTask)
        {

            try
            {
                crmTrace.AppendLine("AssociateObjectionsOnTask started!");
                int numberofRecordReturn = 2;
                ConditionExpression taskRegardingCondition = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression taskCurrentFilingStatusCondition = CreateConditionExpression(TaskEntityAttributeNames.CurrentFilingStatus, ConditionOperator.Equal, new string[] { ((int)CurrentFilingStatus.PlanExaminerReview).ToString() });
                Guid taskGuid = Guid.Empty;
                EntityCollection objecttionResponse;
                crmTrace.AppendLine("Initialized Task Condition Expression");
                EntityCollection response = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.RegardingObjectId }, new ConditionExpression[] { taskRegardingCondition, taskCurrentFilingStatusCondition }, LogicalOperator.And, TaskEntityAttributeNames.ModifiedOn, OrderType.Descending, numberofRecordReturn);
                if (response != null && response.Entities != null && response.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Response count: " + response.Entities.Count);
                    if (response.Entities.Count == 2)
                    {
                        ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { response.Entities[0].Id.ToString() });
                        ConditionExpression objectionCondition2 = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { response.Entities[1].Id.ToString() });
                        objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition, objectionCondition2 }, LogicalOperator.Or);
                    }
                    else
                    {
                        ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { response.Entities[0].Id.ToString() });
                        objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                    }
                    EntityReferenceCollection objections = new EntityReferenceCollection();
                    crmTrace.AppendLine("Initialized objectionCondition Condition Expression");
                    if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("objecttionResponse count: " + objecttionResponse.Entities.Count);
                        for (int i = 0; i < objecttionResponse.Entities.Count; i++)
                            objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objecttionResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start Association for Cheif Plan Examiner Objections");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.CheifPlanExaminerObjectionsRelationShipName), objections);
                        crmTrace.AppendLine("End Association for Cheif Plan Examiner Objections");
                    }

                }
                crmTrace.AppendLine("AssociateObjectionsOnTask End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateObjectionsOnJobFiling(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int FilingStatus)
        {

            try
            {
                crmTrace.AppendLine("AssociateObjectionsOnJobFiling started!");

                // objections will only added by Plan Examiner and Chief Plan Examiner (special first time  case)

                if (FilingStatus == (int)CurrentFilingStatus.CheifPlanExaminerReview)
                {
                    
                    ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.ChiefPlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                    EntityReferenceCollection objections = new EntityReferenceCollection();
                    crmTrace.AppendLine("Initialized JobFilingobjectionCondition Condition Expression");
                    if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("JobFilingobjecttionResponse count: " + objecttionResponse.Entities.Count);
                        for (int i = 0; i < objecttionResponse.Entities.Count; i++)
                            objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objecttionResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from Cheif Plan Examiner Objections");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id, new Relationship(JobFilingEntityAttributeName.ObjectionRelationshipNameOnJobFiling), objections);
                        crmTrace.AppendLine("End JobFiling Association from Cheif Plan Examiner Objections");
                    }
                }

                if (FilingStatus == (int)CurrentFilingStatus.PlanExaminerReview)
                {
                    //Multiple Stakeholders - SPE Task Completion: Start
                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsMultiStakesForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsMultiStakesForm) == true)
                        && (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSecondaryPETaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsSecondaryPETaskForm) == true))
                    {
                        crmTrace.AppendLine("AssociateObjectionsOnJobFiling after SPE started!");
                        ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.SecondPlanExaminerObjections, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection objectionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.SecondPlanExaminerObjections }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                        EntityReferenceCollection objections = new EntityReferenceCollection();

                        ConditionExpression taskCondition1 = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                        ConditionExpression taskCondition2 = CreateConditionExpression(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, new object[] { TaskEntitySatus.Open });
                        ConditionExpression taskCondition3 = CreateConditionExpression(TaskEntityAttributeNames.IsMultiStakesForm, ConditionOperator.Equal, new object[] { true });
                        ConditionExpression taskCondition4 = CreateConditionExpression(TaskEntityAttributeNames.IsSecondaryPETaskForm, ConditionOperator.Equal, new object[] { false });
                        EntityCollection taskresponse = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.CurrentFilingStatus }, new ConditionExpression[] { taskCondition1, taskCondition2, taskCondition3, taskCondition4 }, LogicalOperator.And);
                        crmTrace.AppendLine("Open Task Count: " + taskresponse.Entities.Count);
                        if ((taskresponse == null) || (taskresponse.Entities.Count == 0))
                            return;
                     
                        crmTrace.AppendLine("Initialized JobFilingobjectionCondition Secondary Plan Examiner Condition Expression");
                        if (objectionResponse != null && objectionResponse.Entities != null && objectionResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("JobFilingobjectionResponse count: " + objectionResponse.Entities.Count);
                            for (int i = 0; i < objectionResponse.Entities.Count; i++)
                                objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objectionResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start JobFiling Association from  Secondary Plan Examiner Objections");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.PlanExaminerObjectionsRelationShipName), objections);
                            //service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.CheifPlanExaminerObjectionsRelationShipName), objections);
                            crmTrace.AppendLine("End JobFiling Association from  Secondary Plan Examiner Objections");
                        }
                    }                                     
                    else
                    {
                        //Multiple Stakeholders - SPE Task Completion: End
                        crmTrace.AppendLine("AssociateObjectionsOnJobFiling after PE started!");
                        ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                        EntityReferenceCollection objections = new EntityReferenceCollection();
                        crmTrace.AppendLine("Initialized JobFilingobjectionCondition Plan Examiner Condition Expression");
                        if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("JobFilingobjecttionResponse count: " + objecttionResponse.Entities.Count);
                            for (int i = 0; i < objecttionResponse.Entities.Count; i++)
                                objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objecttionResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start JobFiling Association from  Plan Examiner Objections");
                            service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id, new Relationship(JobFilingEntityAttributeName.ObjectionRelationshipNameOnJobFiling), objections);
                            crmTrace.AppendLine("End JobFiling Association from  Plan Examiner Objections");
                        }
                    }
                    crmTrace.AppendLine("AssociateObjectionsOnJobFiling after PE End!");
                }
                crmTrace.AppendLine("AssociateObjectionsOnJobFiling End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateObjectionsOnJobFiling(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace) //not used currently
        {

            try
            {
                crmTrace.AppendLine("AssociateObjectionsOnJobFiling after PE started!");
                ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.And);
                EntityReferenceCollection objections = new EntityReferenceCollection();
                crmTrace.AppendLine("Initialized JobFilingobjectionCondition Plan Examiner Condition Expression");
                if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("JobFilingobjecttionResponse count: " + objecttionResponse.Entities.Count);
                    for (int i = 0; i < objecttionResponse.Entities.Count; i++)
                        objections.Add(new EntityReference(ObjectionsEntityAttributeNames.EntityLogicalName, objecttionResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start JobFiling Association from  Plan Examiner Objections");
                    service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id, new Relationship(JobFilingEntityAttributeName.ObjectionRelationshipNameOnJobFiling), objections);
                    crmTrace.AppendLine("End JobFiling Association from  Plan Examiner Objections");
                }


                crmTrace.AppendLine("AssociateObjectionsOnJobFiling after PE End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateObjectionsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnJobFiling(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int FilingStatus)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnJobFiling started!");
                // If Current Filing Status is Pending QA Assignment or QA Review
                if (FilingStatus == (int)CurrentFilingStatus.PendingQAAssignment || FilingStatus == (int)CurrentFilingStatus.QAReview || FilingStatus == (int)CurrentFilingStatus.PendingProfCertQAAssignment
                    || FilingStatus == (int)CurrentFilingStatus.PendingProfCertQAReview || FilingStatus == (int)CurrentFilingStatus.ProfCertQAinReview || FilingStatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.QADocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.QADocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  QA Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  QA Documents");

                    }

                }

                // If Current Filing Status is Pending PE Assignment
                if (FilingStatus == (int)CurrentFilingStatus.PendingPlanExaminer || FilingStatus == (int)CurrentFilingStatus.CheifPlanExaminerReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.ChiefPlanExaminerDocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.ChiefPlanExaminerDocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  Chief Plan Examiner Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  Chief Plan Examiner Documents");

                    }

                }

                // If Current Filing Status is Plan Examiner Review
                if (FilingStatus == (int)CurrentFilingStatus.PlanExaminerReview)
                {
                    //Multiple Stakeholders - SPE Documents Assignment: Start
                    if ((targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsMultiStakesForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsMultiStakesForm) == true)
                        && (targetEntity.Attributes.Contains(TaskEntityAttributeNames.IsSecondaryPETaskForm) && targetEntity.GetAttributeValue<bool>(TaskEntityAttributeNames.IsSecondaryPETaskForm) == true))
                    {
                        crmTrace.AppendLine("Document merge from SPE to PE task form: Started!");

                        ConditionExpression SPEDocumentCondition = CreateConditionExpression(DocumentListEntityAttributeName.SecondPlanExaminerDocuments, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection SPEDocumentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.SecondPlanExaminerDocuments }, new ConditionExpression[] { SPEDocumentCondition }, LogicalOperator.And);
                        EntityReferenceCollection SPEDocuments = new EntityReferenceCollection();

                        ConditionExpression taskCondition1 = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                        ConditionExpression taskCondition2 = CreateConditionExpression(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, new object[] { TaskEntitySatus.Open });
                        ConditionExpression taskCondition3 = CreateConditionExpression(TaskEntityAttributeNames.IsMultiStakesForm, ConditionOperator.Equal, new object[] { true });
                        ConditionExpression taskCondition4 = CreateConditionExpression(TaskEntityAttributeNames.IsSecondaryPETaskForm, ConditionOperator.Equal, new object[] { false });
                        EntityCollection taskresponse = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.CurrentFilingStatus }, new ConditionExpression[] { taskCondition1, taskCondition2, taskCondition3, taskCondition4 }, LogicalOperator.And);
                        crmTrace.AppendLine("Open Task Count: " + taskresponse.Entities.Count);
                        if ((taskresponse == null) || (taskresponse.Entities.Count == 0))
                            return;
                        crmTrace.AppendLine("taskresponse.Entities[0].Id: " + taskresponse.Entities[0].Id);
                        crmTrace.AppendLine("Got all SPE documents");

                        if (SPEDocumentResponse != null && SPEDocumentResponse.Entities != null && SPEDocumentResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("SPE Document count: " + SPEDocumentResponse.Entities.Count);
                            for (int i = 0; i < SPEDocumentResponse.Entities.Count; i++)
                                SPEDocuments.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, SPEDocumentResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start Document Association from  Secondary Plan Examiner Documents");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskresponse.Entities[0].Id, new Relationship(TaskEntityAttributeNames.PlanExaminerDocumentsRelationShipName), SPEDocuments);
                            crmTrace.AppendLine("End Document Association from  Secondary Plan Examiner Documents");
                        }
                        crmTrace.AppendLine("Document merge from SPE to PE task form: Ended!");
                    }
                    else
                    {
                        //Multiple Stakeholders - SPE Documents Assignment: End
                        ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.PlanExaminerDocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.PlanExaminerDocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                        EntityReferenceCollection documents = new EntityReferenceCollection();

                        crmTrace.AppendLine("Got all the documents - PE");

                        if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                            for (int i = 0; i < documentResponse.Entities.Count; i++)
                                documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start JobFiling Association from  Plan Examiner Documents");
                            service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                            crmTrace.AppendLine("End JobFiling Association from  Plan Examiner Documents");
                        }

                        //Multiple Stakeholders - SPE Task Completion: Start
                        //Close SPE task form
                        crmTrace.AppendLine("Get ID of open SPE task");
                        ConditionExpression taskCondition5 = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                        ConditionExpression taskCondition6 = CreateConditionExpression(TaskEntityAttributeNames.IsMultiStakesForm, ConditionOperator.Equal, new object[] { true });
                        ConditionExpression taskCondition7 = CreateConditionExpression(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, new object[] { TaskEntitySatus.Open });
                        ConditionExpression taskCondition8 = CreateConditionExpression(TaskEntityAttributeNames.IsSecondaryPETaskForm, ConditionOperator.Equal, new object[] { true });

                        EntityCollection SPEtaskresponse = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.CurrentFilingStatus }, new ConditionExpression[] { taskCondition5, taskCondition6, taskCondition7, taskCondition8 }, LogicalOperator.And);
                        crmTrace.AppendLine("Open SPE Task Count: " + SPEtaskresponse.Entities.Count);
                        if ((SPEtaskresponse == null) || (SPEtaskresponse.Entities.Count == 0))
                            return;

                        Guid SPETaskGuid = SPEtaskresponse.Entities[0].Id;
                        crmTrace.AppendLine("Open SPE task id: " + SPEtaskresponse.Entities[0].Id.ToString());
                        crmTrace.AppendLine("Update SPE Task status: Start");

                        //Multiple Stakeholders - Get any objection on SPE
                        ConditionExpression objectionCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.PlanExaminerObjectionsId, ConditionOperator.Equal, new string[] { SPETaskGuid.ToString() });
                        EntityCollection objecttionResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.PlanExaminerObjectionsId }, new ConditionExpression[] { objectionCondition }, LogicalOperator.Or);

                        //Multiple Stakeholders - Set the status of objections to Auto closed before auto completing the SPE task.
                        if (objecttionResponse != null && objecttionResponse.Entities != null && objecttionResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("objecttionResponse count: " + objecttionResponse.Entities.Count);
                            foreach (var item in objecttionResponse.Entities)
                            {
                                Entity Objection = new Entity(ObjectionsEntityAttributeNames.EntityLogicalName);
                                Objection.Id = item.Id;
                                Objection.Attributes.Add(ObjectionsEntityAttributeNames.Objectionstatus, new OptionSetValue(5)); // 5 - Auto Closed
                                service.Update(Objection);
                            }
                         }

                        SetStateRequest setStateRequest = new SetStateRequest();
                        setStateRequest.EntityMoniker = new EntityReference(TaskEntityAttributeNames.EntityLogicalName, SPETaskGuid);
                        setStateRequest.State = new OptionSetValue(1);  // StateCode - 1: Completed
                        setStateRequest.Status = new OptionSetValue(5); // StatusCode - 5: Completed

                        SetStateResponse setStateResponse = (SetStateResponse)service.Execute(setStateRequest);

                        crmTrace.AppendLine("Update SPE Task status: End - Completed");
                        //Multiple Stakeholders - SPE Task Completion: End
                    }
                }

                crmTrace.AppendLine("AssociateDocumentsOnJobFiling End!");
                // throw new Exception(" crmTrace: " + crmTrace.ToString());
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnJobFiling_Withdrawal(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int WithdrawalRequestStatus)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_Withdrawal started!");
                // If Withdrawal Status is Pending QA Assignment or QA Review
                if (WithdrawalRequestStatus == (int)WithdrawalStatus.PendingQAAssignment || WithdrawalRequestStatus == (int)WithdrawalStatus.QAReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.QADocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.QADocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  QA Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  QA Documents");

                    }

                }

                // If Withdrawal Status is Pending PE Assignment
                if (WithdrawalRequestStatus == (int)WithdrawalStatus.PendingPlanExaminerAssignment)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.ChiefPlanExaminerDocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.ChiefPlanExaminerDocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  Chief Plan Examiner Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  Chief Plan Examiner Documents");

                    }

                }

                // If Withdrawal Status is Plan Examiner Review
                if (WithdrawalRequestStatus == (int)WithdrawalStatus.PlanExaminerReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.PlanExaminerDocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.PlanExaminerDocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  Plan Examiner Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  Plan Examiner Documents");

                    }

                }
                
                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_Withdrawal End!");
               // throw new Exception(" crmTrace: " + crmTrace.ToString());
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnJobFiling_Superseding(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int SupersedingRequestStatus)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_Superseding started!");
                // If Withdrawal Status is Pending QA Assignment or QA Review
                if (SupersedingRequestStatus == (int)SupersedingStatus.PendingQAAssignment || SupersedingRequestStatus == (int)SupersedingStatus.QAReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.QADocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.QADocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  QA Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  QA Documents");

                    }

                }

                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_Superseding End!");
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_Superseding", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void AssociateDocumentsOnJobFiling_WorkPermit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int WorkPermitStatus)
        {

            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_WorkPermit started!");
                // If Withdrawal Status is Pending QA Assignment or QA Review
                if (WorkPermitStatus == (int)WorkpermitStatus.PendingQAAssignment || WorkPermitStatus == (int)WorkpermitStatus.QAReview)
                {

                    ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.QADocumentsid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.QADocumentsid }, new ConditionExpression[] { documentCondition }, LogicalOperator.And);
                    EntityReferenceCollection documents = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the documents");

                    if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Document count: " + documentResponse.Entities.Count);
                        for (int i = 0; i < documentResponse.Entities.Count; i++)
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                        crmTrace.AppendLine("Start JobFiling Association from  QA Documents");
                        service.Associate(JobFilingEntityAttributeName.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id, new Relationship(JobFilingEntityAttributeName.DocumentListRelationshipNameOnJobFiling), documents);
                        crmTrace.AppendLine("End JobFiling Association from  QA Documents");

                    }

                }

                crmTrace.AppendLine("AssociateDocumentsOnJobFiling_WorkPermit End!");
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnJobFiling_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void UpdateWorkPermits_ProfDecision(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int qaDecision)
        {

            try
            {
                crmTrace.AppendLine("UpdateWorkPermits_ProfDecision started!");
                // If Withdrawal Status is Pending QA Assignment or QA Review
                

                    ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.ProfCertTaskId_QAPermit, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus }, new ConditionExpression[] { workPermitCondition }, LogicalOperator.And);
                    
                    crmTrace.AppendLine("Got all the Permits associated to the task form");
                    crmTrace.AppendLine("workPermitResponse Count: " + workPermitResponse.Entities.Count);

                    if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                    {
                        for (int i = 0; i < workPermitResponse.Entities.Count; i++)  
                        {
                            crmTrace.AppendLine("Start Updating Workpermit: " + i);
                            Entity entity = (Entity)workPermitResponse.Entities[i];
                            Guid permitGuid = entity.Id;

                            Entity workPermit = new Entity();
                            workPermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                            workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, permitGuid);
                            if (qaDecision == (int)QADecision.QAFailed)
                            {
                                workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.QAFailed));
                                workPermit.Attributes.Add(WorkPermitEntityAttributeName.IsWorkPermitSubmitted, false);
                            }
                            if (qaDecision == (int)QADecision.PermitIssued)
                            {
                                workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitIssued));
                            }
                            if (qaDecision == (int)QADecision.RequiresL2)
                            {
                                workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PendingL2Review));
                            }
                            workPermit.Attributes.Add(WorkPermitEntityAttributeName.AddedbeforeProfReview, true);
                            service.Update(workPermit);
                            crmTrace.AppendLine("End Updating Workpermit: " + i);
                        }

                    }
                crmTrace.AppendLine("UpdateWorkPermits_ProfDecision End!");
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermits_ProfDecision", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        //Multiple Stakeholders - Central Assigner Task Creation: Start
        public static void AssociateDocumentsOnCATask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask Central Assigner..started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.PriortoStatus, ConditionOperator.Equal, new object[] { (int)CurrentFilingStatus.Approved });
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                        documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                    crmTrace.AppendLine("Start Association for Central Assigner Documents");
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.CentralAssignerDocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for Central Assigner Documents");
                }
                crmTrace.AppendLine("AssociateObjectionsOnTask Central Assigner.. End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnCATask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        //Multiple Stakeholders - Central Assigner Task Creation: End

        //PW1 Standardization - BCDBC Task Creation: Start
        public static void AssociateDocumentsOnBCDBCTask(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("AssociateDocumentsOnTask BCDBC..started!");
                ConditionExpression documentCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id.ToString() });
                ConditionExpression documentCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentStatus, ConditionOperator.Equal, new object[] { (int)DocumentStatus.Submitted});
                EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition, documentCondition2 }, LogicalOperator.And);
                EntityReferenceCollection documents = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                    for (int i = 0; i < documentResponse.Entities.Count; i++)
                    {
                        string documentName = ((EntityReference)documentResponse[i][DocumentListEntityAttributeName.DocumentName]).Name;
                        if (documentName.ToUpper() == DocumentTypeNames.ConcreteTestingExceptionReport)
                        {
                            crmTrace.AppendLine("Document Name: " + documentName);
                            documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));
                        }                        
                    }   

                    crmTrace.AppendLine("Start Association for BCDBCDocuments");
                    crmTrace.AppendLine("BCDBC Task Id: " + targetEntity.Id.ToString());
                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.TR2TechReportsDocumentsRelationShipName), documents);
                    crmTrace.AppendLine("End Association for BCDBC Documents");
                }
                crmTrace.AppendLine("AssociateObjectionsOnTask BCDBC.. End!");
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnBCDBCTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        //PW1 Standardization - BCDBC Task Creation: End

        #region L2 Documents association on Tasks
        public static void AssociateDocumentsOnL2Tasks(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("AssociateDocumentsOnL2Tasks ..started!");
            try
            {
                Entity L2RequestEntity = service.Retrieve(L2RequestAttributeNames.EntityLogicalName, ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.RegardingObjectId])).Id, new ColumnSet(L2RequestAttributeNames.GoToJobFiling, L2RequestAttributeNames.RequestStatus, L2RequestAttributeNames.TrackingNumber));
                crmTrace.AppendLine("Fetch L2 Request Entity Details.");
                if (L2RequestEntity != null)
                {
                    int l2RequestStatus = 0;
                    if (L2RequestEntity.Attributes.Contains(L2RequestAttributeNames.RequestStatus))
                    {
                        l2RequestStatus = L2RequestEntity.GetAttributeValue<OptionSetValue>(L2RequestAttributeNames.RequestStatus).Value;
                    }

                    crmTrace.AppendLine("l2RequestStatus: " + l2RequestStatus);

                    if (l2RequestStatus != 0)
                    {
                        
                        ConditionExpression documentCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.GoToL2Request, ConditionOperator.Equal, new string[] { L2RequestEntity.Id.ToString() });
                        EntityCollection documentResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.CreatedDueto }, new ConditionExpression[] { documentCondition1 }, LogicalOperator.And);
                        EntityReferenceCollection documents = new EntityReferenceCollection();

                        crmTrace.AppendLine("Got all the documents for the regardingObjectId(job filing) in task");
                        if (documentResponse != null && documentResponse.Entities != null && documentResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("documentResponse count: " + documentResponse.Entities.Count);
                            for (int i = 0; i < documentResponse.Entities.Count; i++)
                                documents.Add(new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentResponse.Entities[i].Id));

                            crmTrace.AppendLine("Start Association for Documents");
                            switch (l2RequestStatus)
                            {
                                case 2: // Central Assigner Task
                                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.CentralAssignerDocumentsRelationShipName), documents);
                                    break;
                                case 3: // CPE/ACPE Task
                                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.ChiefPlanExaminerDocumentsRelationShipName), documents);
                                    break;
                                case 4: // PE Task
                                    service.Associate(TaskEntityAttributeNames.EntityLogicalName, targetEntity.Id, new Relationship(TaskEntityAttributeNames.PlanExaminerDocumentsRelationShipName), documents);
                                    break;
                                default:
                                    crmTrace.AppendLine("Different L2 Request Status.");
                                    break;
                            }                            
                            crmTrace.AppendLine("End Association for Documents");
                        }
                    }
                }                
                crmTrace.AppendLine("AssociateObjectionsOnTask Central Assigner.. End!");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", null, crmTrace.ToString(), null, null);
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception: " + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - AssociateDocumentsOnL2Tasks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        #region Update Work Permit on L2 Actions
        public static void UpdateWorkPermitsOnL2Actions(IOrganizationService service, Entity targetEntity, int currentFilingStatus, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("UpdateWorkPermitsOnL2Actions started!");

                string jobFilingId = ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id.ToString();

                ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingId });
                ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, new object[] { (int)WorkpermitStatus.PendingL2Review });
                EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus }, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                EntityReferenceCollection workPermits = new EntityReferenceCollection();

                crmTrace.AppendLine("Got all the workPermits for the regardingObjectId(job filing) in task");
                if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                {
                    for (int i = 0; i < workPermitResponse.Entities.Count; i++)
                    {
                        crmTrace.AppendLine("Start Updating Workpermit forL2: " + i);
                        Entity entity = workPermitResponse.Entities[i];
                        Guid permitGuid = entity.Id;

                        Entity workPermit = new Entity();
                        workPermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                        workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, permitGuid);

                        if (currentFilingStatus == (int)CurrentFilingStatus.PendingL2Review)
                            workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.L2ApprovedProfCertQAReview));
                        else if ((currentFilingStatus == (int)CurrentFilingStatus.Approved) || (currentFilingStatus == (int)CurrentFilingStatus.PermitEntire) || (currentFilingStatus == (int)CurrentFilingStatus.PermitIssued))
                            workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.L2ApprovedQAReview));
                        
                        service.Update(workPermit);
                        crmTrace.AppendLine("End Updating Workpermit for L2: " + i);
                    }
                }
                crmTrace.AppendLine("UpdateWorkPermitsOnL2Actions End!");
            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details: " + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateWorkPermitsOnL2Actions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion

        #region Update Job Filing Status based on L2 Actions
        public static void UpdateJobFilingStatusOnL2Actions(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("UpdateJobFilingStatusOnL2Actions started!");

                Guid jobFilingId = ((EntityReference)(targetEntity.Attributes[TaskEntityAttributeNames.ClickheretogotoJobFiling])).Id;
                crmTrace.AppendLine("jobFilingId: " + jobFilingId.ToString());
                Entity jobFilingEntity = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, jobFilingId, new ColumnSet(JobFilingEntityAttributeName.FilingStatus));

                int currentFilingStatus = 0;

                if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                {
                    currentFilingStatus = jobFilingEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                }

                crmTrace.AppendLine("currentFilingStatus:" + currentFilingStatus);
                Entity jobFiling = new Entity();
                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingId);
                if(currentFilingStatus == (int)CurrentFilingStatus.PendingL2Review)
                    jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.L2ApprovedProfCertQAReview));

                service.Update(jobFiling);
                crmTrace.AppendLine("End Updating Job Filing Status:");

                #region Update Work Permits according to the JF Status
                UpdateWorkPermitsOnL2Actions(service, targetEntity, currentFilingStatus, crmTrace);
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\nFault Exception Details: " + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nTimeout Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingTaskHandler - UpdateJobFilingStatusOnL2Actions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInner Exception Details: " + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion
    }
}
