﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginLibrary;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class OP49FeeCalculationHandler : PluginHandlerBase
    {
        /// <summary>
        /// used to calculate initial filing fee of op49
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject"></param>
        public static void SetOP49InitialFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            crmTrace.AppendLine("Setting OP49 Filing Fee - Start");
            try
            {
                #region OP49 Initial Fee Calculation
                if (targetEntity.LogicalName == OP49EntityAttributeNames.EntityLogicalName)
                {
                    crmTrace.AppendLine("NOTE: Feeobject.BEMSSTFilingfee treated as initial filing fee for op49 . Feeobject.RecordManagementFees  will be treated as late filing fee");
                    crmTrace.AppendLine("Retrieve OP49 Fee Configuration record.");
                    EntityCollection RetreivedFeeConfig = new EntityCollection();
                    RetreivedFeeConfig = service.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.SetOP49InitialFilingFee, OP49EntityAttributeNames.OP49InitialFilingFeeConfig)));
                    if (RetreivedFeeConfig.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("RetreivedFeeConfig.Entities.Count: " + RetreivedFeeConfig.Entities.Count);
                        crmTrace.AppendLine("Min Fee from config: " + RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString());
                        crmTrace.AppendLine("Rec Fee from config: " + RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString());

                        feeObject.BEMSSTFilingfee = Convert.ToDecimal(RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.MinFilingFee].ToString());
                        // Money zeroAmount = new Money(Convert.ToDecimal(RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.RecordManagementFee].ToString()));
                        feeObject.Tier1CostFee = Convert.ToDecimal(RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier1CostFee].ToString());
                        feeObject.Tier2CostFee = Convert.ToDecimal(RetreivedFeeConfig.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Tier2CostFee].ToString());
                        //  CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.FilingFee, new Money(feeObject.BEMSSTFilingfee));


                    }
                }
                #endregion
                crmTrace.AppendLine("Setting OP49 Filing Fee as $45 - End");

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "OP49FeeCalculationHandler - SetOP49InitialFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }

        /// <summary>
        /// This Function is Used to Calculate Late Filing Fee for OP49 and set the amount due,filing fee,latefiling fee
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="feeObject">Used to set amountdue filing fee,late fee and other fee attributes</param>

        public static void CalculateOP49LateFilingFee(IOrganizationService service, Entity targetEntity, Entity PreImage, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {
            try
            {
                EntityCollection elv3ActiveNRFCollection = new EntityCollection(), elv29ActiveNRFCollection = new EntityCollection();
                DateTime annualInspectionDate = targetEntity.Contains(OP49EntityAttributeNames.InspectionDate) && targetEntity[OP49EntityAttributeNames.InspectionDate] != null ? Convert.ToDateTime(targetEntity.GetAttributeValue<DateTime>(OP49EntityAttributeNames.InspectionDate).ToShortDateString()) : PreImage.Contains(OP49EntityAttributeNames.InspectionDate) && PreImage[OP49EntityAttributeNames.InspectionDate] != null ? Convert.ToDateTime(PreImage.GetAttributeValue<DateTime>(OP49EntityAttributeNames.InspectionDate).ToShortDateString()) : new DateTime(); //Annual Inspection Date (either from target or Preimage)
                DateTime submissionDate = Convert.ToDateTime(DateTime.Now.ToShortDateString()); //Submision Date is today 
                decimal numberOfDays;
                feeObject.NoGoodCheckFee = PreImage.Contains(OP49EntityAttributeNames.NoGoodCheckFee) && PreImage[OP49EntityAttributeNames.NoGoodCheckFee] != null && PreImage.GetAttributeValue<Money>(OP49EntityAttributeNames.NoGoodCheckFee).Value > 0 ? PreImage.GetAttributeValue<Money>(OP49EntityAttributeNames.NoGoodCheckFee).Value : 0;
                feeObject.ExistingAmountPaid = PreImage.Contains(OP49EntityAttributeNames.AmountPaid) && PreImage[OP49EntityAttributeNames.AmountPaid] != null && PreImage.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountPaid).Value > 0 ? PreImage.GetAttributeValue<Money>(OP49EntityAttributeNames.AmountPaid).Value : 0;
                crmTrace.AppendLine("prevAmountPaid: " + feeObject.ExistingAmountPaid);
                decimal perMonthPenalty = 0, perYearPenalty = 0; //these fields will be determine the monthly penalty,yearly penalty based on device status
                #region All Fee exempt and Non-fee exmpt filings have to pay the late filing fee penalities 
                numberOfDays = Convert.ToInt32((submissionDate.AddDays(1) - annualInspectionDate.AddDays(1)).TotalDays); //Submission Date is Today - Annual Inspection Date (either from target or Preimage)
                crmTrace.AppendLine("Number Of Days from Annual Inspection Date: " + numberOfDays);

                #region Calculate Late Fee
                perMonthPenalty = feeObject.Tier1CostFee;
                perYearPenalty = feeObject.Tier2CostFee;
                if (numberOfDays <= 30)
                {
                    crmTrace.AppendLine(" Number of days <=30 days so No late filing fee charged");
                    feeObject.RecordManagementFees = 0;
                }
                else if (numberOfDays > 30)
                {
                    numberOfDays = numberOfDays - 30;
                    decimal thirtyDayCycles = numberOfDays / 30;
                    thirtyDayCycles = Math.Ceiling(thirtyDayCycles);
                    if (thirtyDayCycles >= 10)
                        feeObject.RecordManagementFees = perYearPenalty;
                    else
                        feeObject.RecordManagementFees = perMonthPenalty * thirtyDayCycles;
                }
                #endregion

                crmTrace.AppendLine("Late Filing Fees: " + feeObject.RecordManagementFees);

                targetEntity.SetAttributeValue(OP49EntityAttributeNames.LateFee, new Money(feeObject.RecordManagementFees));

                crmTrace.AppendLine("Set Filing Fee : " + feeObject.BEMSSTFilingfee);
                targetEntity.SetAttributeValue(OP49EntityAttributeNames.FilingFee, new Money(feeObject.BEMSSTFilingfee));

                crmTrace.AppendLine("Set Filing Fee : " + feeObject.NoGoodCheckFee);
                targetEntity.SetAttributeValue(OP49EntityAttributeNames.NoGoodCheckFee, new Money(feeObject.NoGoodCheckFee));

                crmTrace.AppendLine("Set Total Fee : " + feeObject.TotalFees);

                if (feeObject.TotalFees < feeObject.ExistingAmountPaid)
                {
                    crmTrace.AppendLine("Job filing  Entity for Update - Populate Adjustment Amount");
                    CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.AmountDue, new Money(0));
                    feeObject.amountDue = 0;
                    CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.Refund, new Money(feeObject.ExistingAmountPaid - feeObject.TotalFees));
                    // using the adjustment fromshared variables
                    feeObject.Adjustment = (feeObject.ExistingAmountPaid - feeObject.TotalFees);
                }
                else
                {
                    crmTrace.AppendLine("Job filing FAB4 Entity for Update - Populate Amount Due" + feeObject.amountDue);
                    feeObject.amountDue = feeObject.TotalFees - feeObject.ExistingAmountPaid;
                    CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.AmountDue, new Money(feeObject.amountDue)); //amountdue=TotalFee-Amount paid

                    CommonPluginLibrary.SetAttributeValue(targetEntity, OP49EntityAttributeNames.Refund, new Money(0));
                    feeObject.Adjustment = 0;
                }
                crmTrace.AppendLine("Set AmountDue : " + feeObject.amountDue);
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "-OP49FeeCalculationHandler-CalculateOP49LateFilingFee - Execute method Fault exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "-OP49FeeCalculationHandler-CalculateOP49LateFilingFee- Execute method Fault exception", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", " -OP49FeeCalculationHandler-CalculateOP49LateFilingFee- Execute method TimeOut exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "- OP49FeeCalculationHandler-CalculateOP49LateFilingFee- Execute method TimeOut exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", " -OP49FeeCalculationHandler-CalculateOP49LateFilingFee- Execute method exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "-OP49FeeCalculationHandler-CalculateOP49LateFilingFee - Execute method exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
 