﻿using System;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class InvoiceNumberHandler : PluginHandlerBase
    {
        public static void InvoiceNumberGenerator(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            crmTrace.AppendLine("Variable Declarations - Start");
            Entity autoNumber = new Entity();
            Entity paymentHistory = new Entity();

            string invoiceSequenceNumber = string.Empty;
            string adminno = string.Empty;
            string invoiceNum = string.Empty;
            string sequenceNumber = string.Empty;
            crmTrace = new StringBuilder();
            StringBuilder buildSeqNum = new StringBuilder();
            ConditionExpression acrafNumberCondition = new ConditionExpression();
            crmTrace.AppendLine("Variable Declarations - End");

            try
            {
                crmTrace.AppendLine("Enter Invoice Number Generator");
                ConditionExpression autoNumbercondition = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { "Invoice Sequence Number" });
                EntityCollection autonumberResponse = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.InvoiceSequenceNumber, JobAutoNumberEntityAttribute.AdminCenterNo }, new ConditionExpression[] { autoNumbercondition }, LogicalOperator.And);

                crmTrace.AppendLine(autonumberResponse.Entities.Count.ToString());

                if (autonumberResponse.Entities[0].Attributes.Contains(JobAutoNumberEntityAttribute.AdminCenterNo))
                    adminno = autonumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.AdminCenterNo].ToString();

                if (autonumberResponse.Entities[0].Attributes.Contains(JobAutoNumberEntityAttribute.InvoiceSequenceNumber))
                    invoiceSequenceNumber = autonumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.InvoiceSequenceNumber].ToString();

                #region Acraf Number on Payment History

                EntityCollection acrafNumberCollection = RetrieveMultiple(service, AcrafConfigurationAttributeNames.EntityLogicalName, new string[] { AcrafConfigurationAttributeNames.Name }, new ConditionExpression[] { }, LogicalOperator.And, AcrafConfigurationAttributeNames.CreatedOn, OrderType.Descending, 1);

                #endregion

                invoiceNum = adminno + invoiceSequenceNumber;
                crmTrace.AppendLine("acraf number created" + invoiceNum);

                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.EntityNameAttribute, invoiceNum);
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.InvoiceNumber, invoiceNum);
                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;
                if (acrafNumberCollection.Entities.Count > 0)
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.AcrafNumber, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, acrafNumberCollection.Entities[0].Id));
                paymentHistory.Id = targetEntity.Id;
                crmTrace.AppendLine(targetEntity.Id.ToString());

                service.Update(paymentHistory);

                sequenceNumber = (int.Parse(invoiceSequenceNumber.ToString()) + 1).ToString();
                for (int i = 0; i < 7 - sequenceNumber.Length; i++)
                {
                    buildSeqNum.Append("0");
                }

                sequenceNumber = buildSeqNum.ToString() + sequenceNumber;

                crmTrace.AppendLine("Sequence Number " + sequenceNumber);

                //Update sequence number
                autoNumber.LogicalName = JobAutoNumberEntityAttribute.EntityLogicalName;
                autoNumber.Attributes.Add(JobAutoNumberEntityAttribute.InvoiceSequenceNumber, sequenceNumber);
                autoNumber.Id = autonumberResponse.Entities[0].Id;
                service.Update(autoNumber);

                crmTrace.AppendLine("Updated Invoice Sequence Number ");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "InvoiceNumberHandler - InvoiceNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
