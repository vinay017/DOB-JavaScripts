﻿using System;
using System.Collections.Generic;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class PW5AfterHourVarianceFeeCalcHandler : PluginHandlerBase
    {

        public static Entity getJobFilingDetails(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage)
        {
            Entity jobfiling = new Entity();
            try
            {

                if (targetEntity.LogicalName == PW5AfterHoursAttributeNames.EntityLogicalName)
                {
                    crmTrace.AppendLine("target entity is PW5AfterHoursAttributeNames.EntityLogicalName");
                    if ((targetEntity.Contains(PW5AfterHoursAttributeNames.JobFilingLookUp) && targetEntity[PW5AfterHoursAttributeNames.JobFilingLookUp] != null) || (preImage.Contains(PW5AfterHoursAttributeNames.JobFilingLookUp) && preImage[PW5AfterHoursAttributeNames.JobFilingLookUp] != null))
                    {
                        crmTrace.AppendLine("target entity has job filing lookup");
                        jobfiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(PW5AfterHoursAttributeNames.JobFilingLookUp).Id, new ColumnSet(JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.OwnerTypePW1Statement));
                        if (jobfiling.Id != null && jobfiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && jobfiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null)
                        {
                            return jobfiling;
                        }
                        else
                        {
                            return jobfiling;
                        }
                    }
                    else
                    {
                        return jobfiling;
                    }
                }
                return jobfiling;

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                //throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return jobfiling;
            }
            catch (TimeoutException ex)
            {
                //throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return jobfiling;
            }
            catch (Exception ex)
            {
                // throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - getJobFilingDetails", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return jobfiling;
            }
        }





        public static void CalculateFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, string messageName, Entity preImage)
        {
            #region Varibale Declarations
            decimal applicationFee = 0;
            Dictionary<string, int> preimageValues = new Dictionary<string, int>();
            decimal dailyFee = 0;
            int totalNoOfDays = 0;
            int ahvPermitStatus = 0;
            string transHistoryGuid = string.Empty; ;
            List<string> tCodeList = new List<string>();
            EntityReference workPermitGuid = new EntityReference();
            EntityReference jobFilingId = new EntityReference();
            Entity ahvEntity = new Entity();
            decimal filingFees = 0;
            string phGuid = string.Empty;
            decimal amountPaid = 0;
            decimal amountDue = 0;
            decimal existingFilingFee = 0;
            decimal existingRefund = 0;
            string thGuid = string.Empty;
            Entity phResponse = new Entity();
            #endregion
            try
            {
                #region check jobfiling is newone or old

                Entity JobFiling = getJobFilingDetails(service, targetEntity, crmTrace, preImage);
                bool feeExempt = false;
                #endregion


                crmTrace.AppendLine("Calculate Fee Method: Fee Calculation - Start");
                crmTrace.AppendLine("Set Variables - Start");
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.NumberOfDays))
                    totalNoOfDays = int.Parse(targetEntity[PW5AfterHoursAttributeNames.NumberOfDays].ToString());
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.AHVPermitStatus))
                    ahvPermitStatus = ((OptionSetValue)targetEntity[PW5AfterHoursAttributeNames.AHVPermitStatus]).Value;
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.RelatedWorkPermit))
                    workPermitGuid = (EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.RelatedWorkPermit];
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName))
                    filingFees = (decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName];
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.AmountDue))
                    amountDue = (decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AmountDue];
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.AmountPaid))
                    amountPaid = (decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AmountPaid];
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName))
                    existingFilingFee = (decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName];

                #region added for AHV Refund
                crmTrace.AppendLine("Get the AHV Refund Value ");
                if (targetEntity.Contains(PW5AfterHoursAttributeNames.AhvRefundAmount))
                {
                    existingRefund = targetEntity.GetAttributeValue<Money>(PW5AfterHoursAttributeNames.AhvRefundAmount).Value;
                    crmTrace.AppendLine("AHV Refund Value: " + existingRefund);
                }
                #endregion 
                crmTrace.AppendLine("Set Variables - End");

                #region Delete if payment is not Posted
                if (ahvPermitStatus != 0)
                {
                    crmTrace.AppendLine("ahvPermitStatus != 0 :  " + ahvPermitStatus);
                    if (messageName.ToUpper() == "UPDATE" && (ahvPermitStatus == 7))
                    {
                        crmTrace.AppendLine("UPDATE");
                        if ((preImage.Attributes.Contains(PW5AfterHoursAttributeNames.PaymentHistoryGuid) && (preImage.Attributes[PW5AfterHoursAttributeNames.PaymentHistoryGuid] != null)))
                        {
                            crmTrace.AppendLine("PaymentHistoryGuid");
                            phGuid = preImage.Attributes[PW5AfterHoursAttributeNames.PaymentHistoryGuid].ToString();

                            crmTrace.AppendLine("transaction history " + thGuid + " " + phGuid);
                            phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);

                            crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());

                            if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                            {
                                crmTrace.AppendLine("PaymentHistoryAttributeNames.IsPosted");
                                if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                            }

                        }

                    }
                }

                #endregion

                crmTrace.AppendLine("Is AHV application is fee exempt-start");
                //Fee Exempt for AHV Application added on 10/28/17 for nov release.
                #region Is AHV Fee Exempt

                if (JobFiling.Id != null && JobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && JobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && JobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling))
                {
                    crmTrace.AppendLine("For Historic job filings fee exempt ahv");
                    if (targetEntity.Contains(PW5AfterHoursAttributeNames.IsFeeExempt) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsFeeExempt) == true)
                    {

                        ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVDailyFeeAttributeName, decimal.Zero);

                        crmTrace.AppendLine("Make Application fee and and existing filing fee 0");
                        applicationFee = 0;
                        existingFilingFee = 0;

                        feeExempt = true;
                        ///If amount is paid already and  making AHV fee exempt then add the amount paid to refund.
                        ///On file create  PH with adjustment if we have any refund available.
                        ///onfile we will clear adjustment and subtract the adjustment from amount paid.



                    }
                    crmTrace.AppendLine("Is AHV application is fee exempt- end");
                }
                else
                {
                    crmTrace.AppendLine("For New job filings fee exempt ahv");
                    if (JobFiling.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement) && JobFiling[JobFilingEntityAttributeName.OwnerTypePW1Statement] != null)
                    {
                        int ownerType = JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value;
                        if (ownerType == (int)OwnerTypeJobFiling.SCA || ownerType == (int)OwnerTypeJobFiling.NYCAgency || ownerType == (int)OwnerTypeJobFiling.OtherGovernment || ownerType == (int)OwnerTypeJobFiling.SpecifNYCHAHHCicUser) //for individual and null value considering not fee exempt
                        {
                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVDailyFeeAttributeName, decimal.Zero);

                            crmTrace.AppendLine("Make Application fee and and existing filing fee 0");
                            applicationFee = 0;
                            existingFilingFee = 0;
                            feeExempt = true;
                        }

                    }

                }


                #endregion

                crmTrace.AppendLine("Retrieve AHV Fee- Start");
                ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { FeeCalculationConfigurationAttributeNames.AHVFormulaeName });
                EntityCollection calcResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.Days13, FeeCalculationConfigurationAttributeNames.Days46, FeeCalculationConfigurationAttributeNames.Days79, FeeCalculationConfigurationAttributeNames.Days1012, FeeCalculationConfigurationAttributeNames.Days1314, FeeCalculationConfigurationAttributeNames.DailyFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.DailyFee))
                    dailyFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.DailyFee].ToString());
                crmTrace.AppendLine("Retrieve AHV Fee- End");

                #region Fee Calculation
                crmTrace.AppendLine("AHV permit status " + ahvPermitStatus.ToString());

                if (totalNoOfDays <= 14)
                {
                    if (ahvPermitStatus == (int)AHVPermitStatus.PreFiling)
                    {
                        crmTrace.AppendLine("Application Fee Calculation Started");
                        if (!feeExempt)
                        {
                            if (totalNoOfDays >= 1 && totalNoOfDays <= 3)
                            {
                                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.Days13))
                                    applicationFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Days13].ToString());
                                crmTrace.AppendLine(applicationFee.ToString());
                            }
                            else if (totalNoOfDays >= 4 && totalNoOfDays <= 6)
                            {
                                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.Days46))
                                    applicationFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Days46].ToString());
                                crmTrace.AppendLine(applicationFee.ToString());
                            }
                            else if (totalNoOfDays >= 7 && totalNoOfDays <= 9)
                            {
                                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.Days79))
                                    applicationFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Days79].ToString());
                                crmTrace.AppendLine(applicationFee.ToString());
                            }
                            else if (totalNoOfDays >= 10 && totalNoOfDays <= 12)
                            {
                                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.Days1012))
                                    applicationFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Days1012].ToString());
                                crmTrace.AppendLine(applicationFee.ToString());
                            }
                            else if (totalNoOfDays >= 13 && totalNoOfDays <= 14)
                            {
                                if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.Days1314))
                                    applicationFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.Days1314].ToString());
                                crmTrace.AppendLine(applicationFee.ToString());
                            }

                            #region Crane AHV
                            if(targetEntity.Contains(PW5AfterHoursAttributeNames.TypeofPermit))
                            {
                                int typeofPermit = targetEntity.GetAttributeValue<OptionSetValue>(PW5AfterHoursAttributeNames.TypeofPermit).Value;
                                crmTrace.AppendLine("typeofPermit: " + typeofPermit);
                                if (typeofPermit == (int)TypeofAHVPermit.CraneNotice || typeofPermit == (int)TypeofAHVPermit.MasterRigger || typeofPermit == (int)TypeofAHVPermit.OnsiteWaiver)
                                {
                                    if(targetEntity.Contains(PW5AfterHoursAttributeNames.NumberofDaysInspectorReq))
                                    {
                                        crmTrace.AppendLine("targetEntity.Contains(PW5AfterHoursAttributeNames.NumberofDaysInspectorReq)");
                                        int noDaysInspectorReq = targetEntity.GetAttributeValue<int>(PW5AfterHoursAttributeNames.NumberofDaysInspectorReq);
                                        crmTrace.AppendLine("noDaysInspectorReq: " + noDaysInspectorReq);
                                        if(noDaysInspectorReq > 0)
                                        {
                                            decimal appFee = applicationFee;
                                            applicationFee = appFee + (750 * noDaysInspectorReq);
                                            crmTrace.AppendLine("applicationFee: " + applicationFee);
                                        }
                                    }
                                }

                            }

                            #endregion
                        }


                        crmTrace.AppendLine("amountPaid: " + amountPaid);
                        // tCodeList.Add(TransactionCodes.AHVApplicationFee); //Commented because everytime appFee Transcode is getting added even in Adjustment scenarios So moved to Payment History Creation Block
                        if (amountPaid == 0)
                        {
                            crmTrace.AppendLine(amountPaid.ToString());
                            amountDue = applicationFee;
                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, amountDue);
                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName, applicationFee);
                        }

                        else if (amountPaid != 0)
                        {


                            crmTrace.AppendLine(applicationFee + " " + amountDue);
                            if (applicationFee == amountPaid)
                            {
                                amountDue = 0;
                                existingRefund = 0;
                                //return;
                            }

                            else if (applicationFee > amountPaid)
                            {
                                amountDue = applicationFee - amountPaid;
                                existingRefund = 0;
                            }

                            else if (applicationFee < amountPaid)
                            {
                                //Calculate  Adjustment and add it to existing adjustment
                                //Make amountdue=0
                                crmTrace.AppendLine("Calculate Refund Start");
                                amountDue = 0;
                                existingRefund = (amountPaid - applicationFee);
                                crmTrace.AppendLine(" Refund :" + existingRefund);
                                //  return;
                            }

                            //ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName, applicationFee);
                            //ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVTotalFeeAttributeName, existingFilingFee + applicationFee);
                            //ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, amountDue);
                            //ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AhvRefundAmount, existingRefund);

                            ahvEntity.Attributes[PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName] = applicationFee;
                            crmTrace.AppendLine("AHVFilingFeeAttributeName Set: " + applicationFee);
                            ahvEntity.Attributes[PW5AfterHoursAttributeNames.AHVTotalFeeAttributeName] =  applicationFee;
                            crmTrace.AppendLine("AHVTotalFeeAttributeName Set: " + (applicationFee));
                            ahvEntity.Attributes[PW5AfterHoursAttributeNames.AmountDue] = amountDue;
                            crmTrace.AppendLine("AmountDue Set: " + amountDue);
                            ahvEntity.Attributes[PW5AfterHoursAttributeNames.AhvRefundAmount] = new Money(existingRefund);
                            crmTrace.AppendLine("AhvRefundAmount Set: " + existingRefund);


                        }
                    }

                    else if (ahvPermitStatus == (int)CurrentFilingStatus.Approved)
                    {                       
                            if ((decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AmountDue] == 0 && (decimal)targetEntity.Attributes[PW5AfterHoursAttributeNames.AmountPaid] != 0 && !feeExempt)//If Fee exempt there is no fee calculation
                            {
                                applicationFee = totalNoOfDays * dailyFee;
                                amountDue = amountDue + applicationFee;
                                tCodeList.Add(TransactionCodes.AHVPermitFee);
                                ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVDailyFeeAttributeName, applicationFee);
                                ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVTotalFeeAttributeName, dailyFee + applicationFee);
                                //ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AHVFilingFeeAttributeName, decimal.Parse("0"));
                                ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AmountDue, amountDue);
                                crmTrace.AppendLine(applicationFee + " " + ahvEntity.Attributes[PW5AfterHoursAttributeNames.AmountDue]);
                            }
                            else
                            {
                                return;
                            }
                        
                        
                    }

                    #endregion
                    #region Payment History Creation
                    if (amountDue > 0) //Normal Case -That means User has to pay some amount so wer have to create payment history
                    {
                        if (ahvPermitStatus == (int)AHVPermitStatus.PreFiling)
                        {
                            tCodeList.Add(TransactionCodes.AHVApplicationFee);
                        }
                        crmTrace.AppendLine("Build Query for Retrieving Transaction code- Start");
                        QueryExpression ieQuery = RetrieveIntersectEntity(crmTrace, calcResponse, targetEntity);
                        crmTrace.AppendLine("Build Query for Retrieving Transaction code- End");

                        crmTrace.AppendLine("Create Transaction history - Start");
                        //Create Transaction history
                        transHistoryGuid = CreateEntityTransCodes(crmTrace, ieQuery, service, targetEntity, tCodeList, amountDue.ToString());
                        crmTrace.AppendLine("Create Transaction history - End");

                        crmTrace.AppendLine("Create Payment history - Start");
                        phGuid = CreatePaymentHistory(service, crmTrace, targetEntity, new Guid(transHistoryGuid), amountDue,JobFiling);
                        crmTrace.AppendLine("Create Payment history - End");

                        ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.TransactionHistoryGuid, transHistoryGuid);
                        ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.PaymentHistoryGuid, phGuid);

                    }
                    else //1)Amount due=0 No action needed  2) On File Adjustment then create PH with Overage Payment TH
                    {
                        //throw new Exception("Test"+existingRefund);
                        crmTrace.AppendLine("Check onFile refund>0 Start");
                        if (targetEntity.Contains(PW5AfterHoursAttributeNames.IsSubmitted) && targetEntity.GetAttributeValue<bool>(PW5AfterHoursAttributeNames.IsSubmitted) == true && existingRefund > 0)// On FIle check we have any refund available
                        {

                            tCodeList.Add(TransactionCodes.Adjustment);
                            crmTrace.AppendLine("Build Query for Retrieving Transaction code- Start");
                            QueryExpression ieQuery = RetrieveIntersectEntity(crmTrace, calcResponse, targetEntity);
                            crmTrace.AppendLine("Build Query for Retrieving Transaction code- End");

                            crmTrace.AppendLine("Create Transaction history - Start");
                            //Create Transaction history
                            transHistoryGuid = CreateEntityTransCodes(crmTrace, ieQuery, service, targetEntity, tCodeList, existingRefund.ToString());//send existing refund in TH
                            crmTrace.AppendLine("Create Transaction history - End");

                            crmTrace.AppendLine("Create Payment history - Start");
                            phGuid = CreatePaymentHistory(service, crmTrace, targetEntity, new Guid(transHistoryGuid), amountDue,JobFiling);
                            crmTrace.AppendLine("Create Payment history - End");

                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.TransactionHistoryGuid, transHistoryGuid);
                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.PaymentHistoryGuid, phGuid);
                            //clear existing refund field 
                            //subtract the refund from Amount paid.
                            amountPaid = amountPaid - existingRefund;
                            crmTrace.AppendLine("Adjustment case amount paid:" + amountPaid);
                            ahvEntity.Attributes.Add(PW5AfterHoursAttributeNames.AmountPaid, (amountPaid));
                            crmTrace.AppendLine("clear the refund in Adjustment case");
                            existingRefund = 0;

                            ahvEntity.Attributes.Remove(PW5AfterHoursAttributeNames.AhvRefundAmount); //Because we already added in above so removing in adjustment then add with zero
                            ahvEntity.Attributes[PW5AfterHoursAttributeNames.AhvRefundAmount] = new Money(existingRefund);

                        }
                    }
                    #endregion


                    #region Update AHV 
                    ahvEntity.LogicalName = PW5AfterHoursAttributeNames.EntityLogicalName;
                    ahvEntity.Id = targetEntity.Id;

                    service.Update(ahvEntity);
                    #endregion

                    crmTrace.AppendLine("Calculate Fee Method: Fee Calculation - End");

                }
                 DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - TEST", null, crmTrace.ToString(), null, null);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                //throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                //throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                // throw (ex);
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #region Queryexpression for Retrieving from Transhistory Intersect Entity
        public static QueryExpression RetrieveIntersectEntity(StringBuilder crmTrace, EntityCollection calcResponse, Entity targetEntity)
        {
            crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity");
            try
            {
                QueryExpression query = new QueryExpression()
                {

                    EntityName = TransactionCodeAttributeNames.EntityLogicalName,
                    ColumnSet = new ColumnSet(TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory, TransactionCodeAttributeNames.RevenueSource,
                    TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText, TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.TransType, TransactionCodeAttributeNames.FeeSchemaName),
                    LinkEntities =
                        {
                    new LinkEntity()
                    {

                        LinkFromEntityName = TransactionCodeAttributeNames.EntityLogicalName,
                        LinkFromAttributeName = TransactionCodeAttributeNames.Id,
                        LinkToEntityName = FeeCalculationTransactionCodeIntersect.EntityLogicalName,
                        LinkToAttributeName = TransactionCodeAttributeNames.Id,
                        LinkCriteria = new FilterExpression
                        {
                            FilterOperator = LogicalOperator.And,
                            Conditions =
                                    {
                                        new ConditionExpression
                                        {
                                            AttributeName = FeeCalculationConfigurationAttributeNames.Id,
                                            Operator = ConditionOperator.Equal,
                                            Values = { calcResponse.Entities[0].Id }
                                        }
                                    }
                        }
                    }
                        }
                };
                return query;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        #endregion


        #region Create Transaction History based on Transaction Codes
        public static string CreateEntityTransCodes(StringBuilder crmTrace, QueryExpression query, IOrganizationService service, Entity targetEntity, List<string> transCodes, string appFee)
        {
            Guid transHistoryId = new Guid();
            crmTrace.AppendLine("Create Transaction history - Start");
            EntityCollection transCollection = service.RetrieveMultiple(query);
            try
            {
                foreach (var tcollection in transCollection.Entities)
                {

                    Entity transHistory = new Entity();
                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                    //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, new Money(decimal.Parse(appFee)));
                    if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.JobFilingLookUp))
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.JobFilingLookUp]).Name);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, new EntityReference(TransactionCodeAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.JobFilingLookUp]).Id));
                    }
                    //transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCodeLookup, new EntityReference(TransactionCodeAttributeNames.EntityLogicalName, tcollection.Id));

                    for (int i = 0; i < transCodes.Count; i++)
                    {
                        if (transCodes[i] == tcollection.Attributes[TransactionCodeAttributeNames.TransCode].ToString())
                        {
                            transHistoryId = service.Create(transHistory);
                        }
                    }
                }
                return transHistoryId.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return transHistoryId.ToString();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return transHistoryId.ToString();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return transHistoryId.ToString();
            }
        }
        #endregion


        #region Create Payment History
        public static string CreatePaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Guid tHistoryId, decimal amountDue,Entity JobFiling)
        {
            crmTrace.AppendLine("");
            Entity paymentHistory = new Entity();
            Guid paymentHistoryId = Guid.Empty;
            crmTrace.AppendLine("CreatePaymentHistory: Build Transaction history Entity Reference for Association - Start");
            EntityReferenceCollection tHistory = new EntityReferenceCollection();
            tHistory.Add(new EntityReference(TransactionHistoryAttributeNames.EntityLogicalName, tHistoryId));
            crmTrace.AppendLine("CreatePaymentHistory: Build Transaction history Entity Reference for Association - End");
            try
            {
                #region Create PaymentHistory    
                crmTrace.AppendLine("CreatePaymentHistory: Build PaymentHistory Object for Creation- Start");
                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;

                //Job Filing
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.JobFilingLookUp))
                {
                    if(JobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && JobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling]!=null && JobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling))
                    {
                        #region For Old Job Filing
                        crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage for old jobfiling- Start");
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.JobFilingLookUp]).Name);
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.JobFilingLookUp]).Id));
                        #endregion
                    }

                    else
                    {
                        #region For New Job Filing
                        crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage for new jobfiling - Start");
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, (targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVname]).ToString());
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.GoToAHV, targetEntity.ToEntityReference());
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.JobFilingLookUp]).Id));//will separate out in maf pacakage
                        #endregion
                    }

                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.AHV));
                    crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage - End");
                }

                //For Electrical
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.ElectricalLookUp))
                {
                    crmTrace.AppendLine("CreatePaymentHistory: Set Electrical Lookup to PaymentHistory - Start");
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.ElectricalLookUp, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[PW5AfterHoursAttributeNames.ElectricalLookUp]).Id));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.ElectricalAHV));
                    crmTrace.AppendLine("CreatePaymentHistory: Set Electrical Lookup to PaymentHistory - End");
                }

                #region Crane AHV
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.CraneNotice))
                {
                    crmTrace.AppendLine("CreatePaymentHistory: Set Crane AHV Lookup to PaymentHistory - Start");
                    crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage for new jobfiling - Start");
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, (targetEntity.Attributes[PW5AfterHoursAttributeNames.AHVname]).ToString());
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.GoToAHV, targetEntity.ToEntityReference());
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.CraneAHV));
                    crmTrace.AppendLine("CreatePaymentHistory: Set Crane AHV Lookup to PaymentHistory - End");
                }
                #endregion
                #region Adjustment Case
                if (amountDue == 0)//Passing zero in Adjustment cases 
                {
                    crmTrace.AppendLine("Make PH isposted true");
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.IsPosted, true);
                }
                #endregion
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, new Money(amountDue));
                if (targetEntity.Attributes.Contains(PW5AfterHoursAttributeNames.License))
                    if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[PW5AfterHoursAttributeNames.License])).ToString())))
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[PW5AfterHoursAttributeNames.License])));
                crmTrace.AppendLine("CreatePaymentHistory: Build PaymentHistory Object for Creation- End");
                paymentHistoryId = service.Create(paymentHistory);
                #endregion

                crmTrace.AppendLine("Start Association for Payment history");
                service.Associate(PaymentHistoryAttributeNames.EntityLogicalName, paymentHistoryId, new Relationship(PaymentHistoryAttributeNames.PaymentHistTransHistRelationShipName), tHistory);
                crmTrace.AppendLine("End Association for Payment history");
                return paymentHistoryId.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return paymentHistoryId.ToString();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return paymentHistoryId.ToString();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PW5AfterHourVarianceFeeCalcHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return paymentHistoryId.ToString();
            }
            #endregion

        }

    }
}