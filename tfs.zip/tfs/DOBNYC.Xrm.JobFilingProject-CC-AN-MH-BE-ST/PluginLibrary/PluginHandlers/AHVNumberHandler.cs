﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class AHVNumberHandler : PluginHandlerBase
    {
        public static Entity GenerateAHVNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            
            string borough = string.Empty;
            string AHVformatString = "{0}{1}";
            string AHVFormatted = string.Empty;
            
            try
            {

                if (targetEntity.Attributes.Contains(AfterHourVarianceAttributeNames.Borough))
                    borough = Enum.GetName(typeof(Borough), ((OptionSetValue)targetEntity.Attributes[AfterHourVarianceAttributeNames.Borough]).Value);

                Random rnd = new Random();
                int sevenDigitRandom = rnd.Next(1000000, 9999999);
                AHVFormatted = String.Format(AHVformatString, borough, sevenDigitRandom.ToString());
                crmTrace.AppendLine("AHVFormatted: " + AHVFormatted);
                if (!targetEntity.Attributes.Contains(AfterHourVarianceAttributeNames.AHVPermitNumber))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, AfterHourVarianceAttributeNames.AHVPermitNumber, AHVFormatted);

                }
                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "AHVNumberHandler - GenerateAHVNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

      

    } // class ends here
}// namespace ends here
