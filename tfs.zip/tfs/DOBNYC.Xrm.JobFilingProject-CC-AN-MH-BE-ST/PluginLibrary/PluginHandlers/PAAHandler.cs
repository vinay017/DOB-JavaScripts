﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using DOB.Logging;
using Microsoft.Xrm.Client;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class PAAHandler : PluginHandlerBase
    {
        public static void ChangeTrace(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder customTrace, Entity preImage)
        {
            try
            {

                #region PW1 Section
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    customTrace.AppendLine("targetEntity" + targetEntity.LogicalName);
                    if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingType) && preImage.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName) && preImage.Attributes.Contains(JobFilingEntityAttributeName.FilingStatus))
                    {

                        int filingType = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                        int filingStatus = preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                        if ((filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview))
                        {
                            if (filingType == (int)FilingType.PAA)
                            {
                                customTrace.AppendLine("filingType" + filingType);
                                EntityReference parentJobFiling = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName);
                                Entity parentEntity = PluginHandlerBase.Retrieve(serviceConnector, null, parentJobFiling.Id, JobFilingEntityAttributeName.EntityLogicalName);
                                customTrace.AppendLine("imagevalues started");
                                Dictionary<string, string> pw1ImageValues = new Dictionary<string, string>();
                                pw1ImageValues = PW1ImageValues(parentEntity, customTrace);
                                customTrace.AppendLine("imagevalues ended");
                                customTrace.AppendLine("Get Values from JobFiling TargetEntity");
                                foreach (var item in pw1ImageValues)
                                {
                                    //Prepare jobFilingchangeset entity
                                    Entity jobFilingchangeset = new Entity();
                                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;
                                    customTrace.AppendLine("loop started");
                                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                                    {
                                        customTrace.AppendLine("For Field: " + item.Key.ToString());
                                        string newValue = SetNewValueBasedOnType(serviceConnector, targetEntity, customTrace, preImage, item);
                                        string oldValue = item.Value.ToString();
                                        if (item.Key.ToString() == JobFilingEntityAttributeName.EstimatedJobCost || item.Key.ToString() == JobFilingEntityAttributeName.EstimatedJobCostLegal)
                                        {
                                            if (newValue.Contains("."))
                                            {
                                                string[] newVal = newValue.ToString().Split('.');
                                                if (newVal[1] == "0000" || newVal[1] == "00")
                                                    newValue = newVal[0];

                                            }
                                            string[] est = oldValue.Split('.');
                                            if (est[1] == "0000")
                                                oldValue = est[0];
                                        }
                                        if (!newValue.Trim().Equals(oldValue.Trim()))
                                        {
                                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), serviceConnector);
                                            customTrace.AppendLine("loop started:" + item.Key.ToString());
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                                            //Set NewValue to changeSet entity based on Type of Attribute    
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, "Job filing");
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                                            if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingTypeAttributeName))
                                            {
                                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName));

                                            }
                                            else
                                            {
                                                jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, parentEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName));

                                            }
                                            serviceConnector.Create(jobFilingchangeset);
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
                #endregion PW1Section
                #region Scopeofwork
                if (targetEntity.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    //Retrive filingid & systemid from current scopeofwork
                    customTrace.AppendLine("TEST");
                    EntityReference jobFilingLookUp = preImage.GetAttributeValue<EntityReference>(ScopeOfWorkEntityAttributeName.GoToJobFiling);
                    EntityReference systemLookUp = preImage.GetAttributeValue<EntityReference>(ScopeOfWorkEntityAttributeName.System);

                    // Retrieve parent jobfilingid
                    Entity jobFilingEntity = PluginHandlerBase.Retrieve(serviceConnector, new string[] { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName, JobFilingEntityAttributeName.FilingTypeAttributeName }, jobFilingLookUp.Id, JobFilingEntityAttributeName.EntityLogicalName);
                    Guid parentJobFiling = jobFilingEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;

                    ConditionExpression condition1 = CreateConditionExpression(ScopeOfWorkEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { parentJobFiling.ToString() });
                    ConditionExpression condition2 = CreateConditionExpression(ScopeOfWorkEntityAttributeName.System, ConditionOperator.Equal, new string[] { systemLookUp.Id.ToString() });

                    EntityCollection parentscopeRecords = RetrieveMultiple(serviceConnector, ScopeOfWorkEntityAttributeName.EntityLogicalName, null, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.And);
                    if (parentscopeRecords.Entities.Count > 0)
                    {
                        Entity parentscope = parentscopeRecords.Entities[0];
                        int filingType = ((OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        int filingStatus = ((OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                        if ((filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview))
                        {
                            if (filingType == (int)FilingType.PAA)
                            {
                                Dictionary<string, string> scopeImageValues = new Dictionary<string, string>();
                                scopeImageValues = ScopeOfWorkImageValues(parentscope, customTrace);
                                foreach (var item in scopeImageValues)
                                {
                                    customTrace.AppendLine("loop PreImage For:" + targetEntity.LogicalName);
                                    Entity jobFilingchangeset = new Entity();
                                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;

                                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                                    {
                                        string newValue = SetNewValueBasedOnType(serviceConnector, targetEntity, customTrace, preImage, item);
                                        string oldValue = item.Value.ToString();
                                        if (!newValue.Trim().Equals(oldValue.Trim()))
                                        {
                                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), serviceConnector);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFilingLookUp.Id));
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                                            OptionSetValue filingstatus = (OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName];
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, new OptionSetValue(filingstatus.Value));
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, "Scope Of Work");
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                                            serviceConnector.Create(jobFilingchangeset);
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
                #endregion scopeofwork
                #region workcostdetails
                if (targetEntity.LogicalName == WorkCostDetailsAttributeNames.EntityLogicalName && targetEntity.LogicalName != null)
                {
                    //Retrive filingid & systemid from current scopeofwork
                    EntityReference jobFilingLookUp = preImage.GetAttributeValue<EntityReference>(WorkCostDetailsAttributeNames.GoToJobFiling);
                    OptionSetValue workCategory = preImage.GetAttributeValue<OptionSetValue>(WorkCostDetailsAttributeNames.WorkCategory);

                    // Retrieve parent jobfilingid
                    Entity jobFilingEntity = PluginHandlerBase.Retrieve(serviceConnector, new string[] { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName, JobFilingEntityAttributeName.FilingTypeAttributeName }, jobFilingLookUp.Id, JobFilingEntityAttributeName.EntityLogicalName);
                    Guid parentJobFiling = jobFilingEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;

                    ConditionExpression condition1 = CreateConditionExpression(WorkCostDetailsAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { parentJobFiling.ToString() });
                    ConditionExpression condition2 = CreateConditionExpression(WorkCostDetailsAttributeNames.WorkCategory, ConditionOperator.Equal, new string[] { workCategory.Value.ToString() });

                    EntityCollection parentCostDetailRecords = RetrieveMultiple(serviceConnector, WorkCostDetailsAttributeNames.EntityLogicalName, null, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.And);
                    if (parentCostDetailRecords.Entities.Count > 0)
                    {
                        Entity parentCostDetail = parentCostDetailRecords.Entities[0];
                        int filingType = ((OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingType]).Value;
                        int filingStatus = ((OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                        if ((filingStatus != (int)CurrentFilingStatus.PreFiling && filingStatus != (int)CurrentFilingStatus.DesignProfessionalReview))
                        {
                            if (filingType == (int)FilingType.PAA)
                            {
                                Dictionary<string, string> workImageValues = new Dictionary<string, string>();
                                workImageValues = WorkCostDetailsValues(parentCostDetail, customTrace);
                                foreach (var item in workImageValues)
                                {
                                    customTrace.AppendLine("loop PreImage For:" + targetEntity.LogicalName);
                                    Entity jobFilingchangeset = new Entity();
                                    jobFilingchangeset.LogicalName = FilingChangeSetAttributeNames.EntityLogicalName;

                                    if (targetEntity.Attributes.Contains(item.Key.ToString()))
                                    {
                                        string newValue = SetNewValueBasedOnType(serviceConnector, targetEntity, customTrace, preImage, item);
                                        string oldValue = item.Value.ToString();
                                        if (item.Key.ToString() == WorkCostDetailsAttributeNames.UnitCost || item.Key.ToString() == WorkCostDetailsAttributeNames.TotalCost)
                                        {
                                            if (newValue.Contains("."))
                                            {
                                                string[] newVal = newValue.ToString().Split('.');
                                                if (newVal[1] == "0000" || newVal[1] == "00")
                                                    newValue = newVal[0];

                                            }
                                            string[] est = oldValue.Split('.');
                                            if (est[1] == "0000")
                                                oldValue = est[0];
                                        }
                                        if (!newValue.Trim().Equals(oldValue.Trim()))
                                        {
                                            string fieldDisplayName = GetAttributeDisplayName(targetEntity.LogicalName, item.Key.ToString(), serviceConnector);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.JobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFilingLookUp.Id));
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.NewValue, newValue);
                                            OptionSetValue filingstatus = (OptionSetValue)jobFilingEntity.Attributes[JobFilingEntityAttributeName.FilingTypeAttributeName];
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.CurrentFilingStatus, new OptionSetValue(filingstatus.Value));
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.OldValue, oldValue);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Name, item.Key.ToString());
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Field, fieldDisplayName);
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.Entity, "Work Cost Detail");
                                            jobFilingchangeset.Attributes.Add(FilingChangeSetAttributeNames.EntityName, targetEntity.LogicalName);
                                            serviceConnector.Create(jobFilingchangeset);
                                        }

                                    }
                                }
                            }
                        }
                    }

                }
                #endregion

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - ChangeTrace", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void PAAPostApproval(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, FeeCalculationObject feeObject)
        {

            try
            {
                crmTrace.AppendLine("Start PAAPostApproval process! ");

                GetJobFilingEntityColumnSet columnsSet = new GetJobFilingEntityColumnSet();
                Entity currentPAARecord = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(true));
                Guid ParentJobGuid = ((EntityReference)currentPAARecord[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                crmTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());

                crmTrace.AppendLine("ParentRecord Attribute count: " + currentPAARecord.Attributes.Count);

                ColumnSet columns = new ColumnSet(new string[] { JobFilingEntityAttributeName.JobDescription, JobFilingEntityAttributeName.CurrentFilingStatusAttributeName, JobFilingEntityAttributeName.PlaceOfAssemblyLookUp,  JobFilingEntityAttributeName.OwnerLeaseHolder,
                        JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization,
                        JobFilingEntityAttributeName.OwnerTypePW1Statement });
                Entity ParentJobRecord = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid, columns);

                #region Compare job description

                string parent_JobDesc = ParentJobRecord.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescription);
                crmTrace.AppendLine("parent_JobDesc: " + parent_JobDesc);

                string pAA_JobDesc = currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescription);
                crmTrace.AppendLine("pAA_JobDesc: " + pAA_JobDesc);

                #endregion

                #region If Job Description is Changed

                // bool isJobDesChanged = currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsJobDescriptionChanged);
                //crmTrace.AppendLine("isJobDesChanged: " + isJobDesChanged.ToString());
                if (parent_JobDesc != pAA_JobDesc)
                {
                    #region Old Commented PAA logic
                    //#region Check if PAA is for Plumbing
                    //bool PlumbingCheckBox = currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    //crmTrace.AppendLine("PlumbingCheckBox : " + PlumbingCheckBox.ToString());
                    //if (PlumbingCheckBox == true)
                    //{
                    //    crmTrace.AppendLine("Retrieving all the Work permits with PL worktype of Parent Job Filing and Inactivating them - Started ");
                    //    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                    //    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                    //    ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Plumbing });
                    //    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                    //    crmTrace.AppendLine("workPermitResponse count: " + workPermitResponse.Entities.Count);
                    //    if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                    //    {
                    //        foreach (Entity workpermit in workPermitResponse.Entities)
                    //        {
                    //            InactiveWorkPermit(service, workpermit, crmTrace);

                    //        }

                    //    }

                    //}

                    //#endregion

                    //#region Check if PAA is for Sprinkler
                    //bool SprinklerCheckBox = currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    //crmTrace.AppendLine("SprinklerCheckBox : " + SprinklerCheckBox.ToString());
                    //if (SprinklerCheckBox == true)
                    //{
                    //    crmTrace.AppendLine("Retrieving all the Work permits with SP worktype of Parent Job Filing and Inactivating them - Started ");
                    //    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                    //    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                    //    ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Sprinkler });
                    //    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                    //    if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                    //    {
                    //        foreach (Entity workpermit in workPermitResponse.Entities)
                    //        {
                    //            InactiveWorkPermit(service, workpermit, crmTrace);

                    //        }

                    //    }

                    //}

                    //#endregion

                    //#region Check if PAA is for StandPipe
                    //bool SDCheckBox = currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    //crmTrace.AppendLine("SDCheckBox : " + SDCheckBox.ToString());
                    //if (SDCheckBox == true)
                    //{
                    //    crmTrace.AppendLine("Retrieving all the Work permits with SD worktype of Parent Job Filing and Inactivating them - Started ");
                    //    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                    //    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                    //    ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Standpipe });
                    //    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                    //    if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                    //    {
                    //        foreach (Entity workpermit in workPermitResponse.Entities)
                    //        {
                    //            InactiveWorkPermit(service, workpermit, crmTrace);

                    //        }

                    //    }

                    //}

                    //#endregion

                    #endregion

                    #region New PAA Logic
                    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                    ConditionExpression workPermitCondition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("workPermitResponse count: " + workPermitResponse.Entities.Count);
                    if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                    {
                        foreach (Entity workpermit in workPermitResponse.Entities)
                        {
                            UpdateJobDesc_WorkPermit(service, workpermit, pAA_JobDesc, crmTrace);

                        }

                    }

                    #endregion

                }

                #endregion

                #region Compare Work on Floors and Upate on Work Permits
                string parent_workonfloors = ParentJobRecord.GetAttributeValue<string>(JobFilingEntityAttributeName.WorkonFloorsAttributeName);
                crmTrace.AppendLine("parent_workonfloors: " + parent_workonfloors);

                string pAA_workonfloors = currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.WorkonFloorsAttributeName);
                crmTrace.AppendLine("pAA_workonfloors: " + pAA_workonfloors);

                if (parent_workonfloors != pAA_workonfloors)
                {
                    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                    ConditionExpression workPermitCondition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1, workPermitCondition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("workPermitResponse count: " + workPermitResponse.Entities.Count);
                    if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                    {
                        foreach (Entity workpermit in workPermitResponse.Entities)
                        {
                            UpdateWorkonFloors_WorkPermit(service, workpermit, pAA_workonfloors, crmTrace);

                        }

                    }
                }

                #endregion

                #region Retrieving all the Related Entities records of Parent Job Filing and Deleting them
                crmTrace.AppendLine("Retrieving all the Related Entities records of Parent Job Filing and Deleting them - Started ");

                EntityCollection ParentScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, ScopeOfWorkEntityAttributeName.GoToJobFiling);
                if (ParentScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentScopeofWork.Entities.Count: " + ParentScopeofWork.Entities.Count);
                    DeleteEntityCollection2(service, ParentScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentScopeofWork");
                }

                EntityCollection ParentFenceScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, FenceScopeofWorkAttributeNames.EntityLogicalName, FenceScopeofWorkAttributeNames.GotoJobFiling);
                if (ParentFenceScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentFenceScopeofWork.Entities.Count: " + ParentFenceScopeofWork.Entities.Count);
                    DeleteEntityCollection2(service, ParentFenceScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentFenceScopeofWork");
                }

                #region Boiler Scope of Work
                EntityCollection ParentBoilerScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, BEScopeOfWorkEntityAttribute.EntityLogicalName, BEScopeOfWorkEntityAttribute.GotoJobFiling);
                if (ParentBoilerScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentBoilerScopeofWork.Entities.Count: " + ParentBoilerScopeofWork.Entities.Count);
                    DeleteEntityCollection2(service, ParentBoilerScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentBoilerScopeofWork");
                }

                EntityCollection ParentBoilerDevices = RetrieveRelatedEntities(service, ParentJobGuid, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling);
                if (ParentBoilerDevices.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentBoilerDevices.Entities.Count: " + ParentBoilerDevices.Entities.Count);
                    DeleteEntityCollection2(service, ParentBoilerDevices, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentBoilerDevices");
                }

                #endregion

                EntityCollection ParentSWSScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, SHScopeofWorkAttributeNames.EntityLogicalName, SHScopeofWorkAttributeNames.GotoJobFiling);
                if (ParentSWSScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentSWSScopeofWork.Entities.Count: " + ParentSWSScopeofWork.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSWSScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSWSScopeofWork");
                }
                #region Delete MechanicalScopeOfWork
                EntityCollection ParentMSScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, MHScopeofworkAttributeNames.EntityLogicalName, MHScopeofworkAttributeNames.GotoJobFiling);
                // throw new Exception("ParentMSScopeofWork.Entities.Count: " + ParentMSScopeofWork.Entities.Count);
                if (ParentMSScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentMSScopeofWork.Entities.Count: " + ParentMSScopeofWork.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentMSScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentMSScopeofWork");
                }
                #endregion
                #region Delete ST ScopeOfWork
                EntityCollection ParentSTScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, STScopeOfWorkEntityAttribute.EntityLogicalName, STScopeOfWorkEntityAttribute.GoToJobFiling);
                if (ParentSTScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentSTScopeofWork.Entities.Count: " + ParentSTScopeofWork.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSTScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSTScopeofWork");
                }
                #endregion
                #region Delete SCOPE OF WORK QUESTIONNAIRE
                EntityCollection ParentSCOPEOFWORKQUESTIONNAIRE = RetrieveRelatedEntities(service, ParentJobGuid, ScopeofWorkQuestionnaire.EntityLogicalName, ScopeofWorkQuestionnaire.GotoJobFiling);
                if (ParentSCOPEOFWORKQUESTIONNAIRE.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentSCOPEOFWORKQUESTIONNAIRE.Entities.Count: " + ParentSCOPEOFWORKQUESTIONNAIRE.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSCOPEOFWORKQUESTIONNAIRE, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSCOPEOFWORKQUESTIONNAIRE");
                }
                #endregion
                #region Delete SPSD ScopeOfWork
                EntityCollection ParentSPSDScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, SPSDScopeOfWorkEntityAttribute.EntityLogicalName, SPSDScopeOfWorkEntityAttribute.GoToJobFiling);
                //EntityCollection PAASTScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, STScopeOfWorkEntityAttribute.EntityLogicalName, STScopeOfWorkEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("PAASTScopeofWork Count: " + ParentSPSDScopeofWork.Entities.Count.ToString());
                if (ParentSPSDScopeofWork.Entities.Count > 0)
                {
                    //// AdjustedPAASTScopeofWork = new EntityCollection();
                    //for (int j = 0; j < ParentSPSDScopeofWork.Entities.Count; j++)
                    //{
                    //    EntityCollection ParentScopeOfWorkCommonFloor = RetrieveRelatedEntities(service, ParentJobGuid, ScopeOfWorkonFloorEntityAttribute.EntityLogicalName, ScopeOfWorkonFloorEntityAttribute.GoToJobFiling);
                    //    if (ParentScopeOfWorkCommonFloor.Entities.Count > 0)
                    //    {
                    //        crmTrace.AppendLine("ParentScopeOfWorkCommonFloor.Entities.Count: " + ParentScopeOfWorkCommonFloor.Entities.Count.ToString());
                    //        DeleteEntityCollection2(service, ParentScopeOfWorkCommonFloor, crmTrace);
                    //        crmTrace.AppendLine("Retrieved and Deleted all ParentScopeOfWorkCommonFloor");
                    //    }
                    //}

                    crmTrace.AppendLine("ParentSPSDScopeofWork.Entities.Count: " + ParentSPSDScopeofWork.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSPSDScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSPSDScopeofWork");
                }

                #endregion

                #region Delete PL ScopeOfWork
                EntityCollection ParentPLcopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, SOWCommonWorkTypesEntityAttribute.EntityLogicalName, SOWCommonWorkTypesEntityAttribute.GoToJobFiling);
                //EntityCollection PAASTScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, STScopeOfWorkEntityAttribute.EntityLogicalName, STScopeOfWorkEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("PAASTScopeofWork Count: " + ParentSPSDScopeofWork.Entities.Count.ToString());
                if (ParentPLcopeofWork.Entities.Count > 0)
                {
                    // AdjustedPAASTScopeofWork = new EntityCollection();
                    for (int j = 0; j < ParentPLcopeofWork.Entities.Count; j++)
                    {
                        EntityCollection ParentSPSDScopeOfWorkCommonFloor = RetrieveRelatedEntities(service, ParentJobGuid, SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName, SPSDCommonWorkOnFloorEntityAttribute.GoToJobFiling);
                        if (ParentSPSDScopeOfWorkCommonFloor.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("ParentSPSDScopeOfWorkCommonFloor.Entities.Count: " + ParentSPSDScopeOfWorkCommonFloor.Entities.Count.ToString());
                            DeleteEntityCollection2(service, ParentSPSDScopeOfWorkCommonFloor, crmTrace);
                            crmTrace.AppendLine("Retrieved and Deleted all ParentSPSDScopeOfWorkCommonFloor");
                        }
                    }

                    crmTrace.AppendLine("ParentPLcopeofWork.Entities.Count: " + ParentPLcopeofWork.Entities.Count);
                    DeleteEntityCollection2(service, ParentPLcopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentPLcopeofWork");
                }

                #endregion

                #region Delete ST TR2
                EntityCollection ParentSTTR2 = RetrieveRelatedEntities(service, ParentJobGuid, TR2TechnicalReport.EntityLogicalName, TR2TechnicalReport.GotoJobFiling);
                EntityCollection PAASTTR2 = RetrieveRelatedEntities(service, currentPAARecord.Id, TR2TechnicalReport.EntityLogicalName, TR2TechnicalReport.GotoJobFiling);
                crmTrace.AppendLine("ParentSTTR2.Entities.Count: " + ParentSTTR2.Entities.Count.ToString());
                crmTrace.AppendLine("PAASTTR2.Entities.Count: " + PAASTTR2.Entities.Count.ToString());
                
                if (ParentSTTR2.Entities.Count > 0 && PAASTTR2.Entities.Count == 0)
                {
                    crmTrace.AppendLine("ParentSTTR2.Entities.Count: " + ParentSTTR2.Entities.Count.ToString());
                    crmTrace.AppendLine("PAASTTR2.Entities.Count: " + PAASTTR2.Entities.Count.ToString());
                    
                    DeleteEntityCollection2(service, ParentSTTR2, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSTTR2");
                }

                #endregion
                #region Delete ST TR3
                // Retrieve PAA TR3 first and check if TR3 exists

                EntityCollection ParentSTTR3 = RetrieveRelatedEntities(service, ParentJobGuid, TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3TechnicalReportEntityAttribute.GotoJobFiling);

                EntityCollection PAASTTR3 = RetrieveRelatedEntities(service, currentPAARecord.Id, TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3TechnicalReportEntityAttribute.GotoJobFiling);
                // Retrieve PAA TR3 first and check if TR3 exists on Parent
                if (ParentSTTR3.Entities.Count > 0 && PAASTTR3.Entities.Count == 0)
                {
                    // If exists check TR3 Exists on PAA
                    crmTrace.AppendLine("ParentSTTR2.Entities.Count: " + ParentSTTR3.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSTTR3, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSTTR3");
                }

                #endregion

                EntityCollection ParentSFScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, ScaffoldScopeofWorkAttributeNames.GotoJobFiling);
                if (ParentSFScopeofWork.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentSFScopeofWork.Entities.Count: " + ParentSFScopeofWork.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSFScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSFScopeofWork");
                }

                EntityCollection ParentCostDetails = RetrieveRelatedEntities(service, ParentJobGuid, WorkCostDetailsAttributeNames.EntityLogicalName, WorkCostDetailsAttributeNames.GoToJobFiling);
                if (ParentCostDetails.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentCostDetails.Entities.Count: " + ParentCostDetails.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentCostDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentCostDetails");
                }

                //Added by SN on 1/16/2019
                //Zoning ZoningCharactersticsPW1AttributeNames
                EntityCollection ParentZoningCharacterstics = RetrieveRelatedEntities(service, ParentJobGuid, ZoningCharactersticsPW1AttributeNames.EntityLogicalName, ZoningCharactersticsPW1AttributeNames.JobFilingGuid);
                if (ParentZoningCharacterstics.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentZoningCharacterstics.Entities.Count: " + ParentZoningCharacterstics.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentZoningCharacterstics, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentZoningCharacterstics");
                }



                //EntityCollection ParentWorkOnFloorDetails = RetrieveRelatedEntities(service, ParentJobGuid, WorkOnFloorEntityAttributeName.EntityLogicalName, WorkOnFloorEntityAttributeName.GoToJobFiling);
                //crmTrace.AppendLine("ParentWorkOnFloorDetails.Entities.Count: " + ParentWorkOnFloorDetails.Entities.Count.ToString());
                //if (ParentWorkOnFloorDetails.Entities.Count > 0)
                //{
                //    crmTrace.AppendLine("ParentWorkOnFloorDetails.Entities.Count: " + ParentWorkOnFloorDetails.Entities.Count.ToString());
                //    DeleteEntityCollection2(service, ParentWorkOnFloorDetails, crmTrace);
                //    crmTrace.AppendLine("Retrieved and Deleted all ParentWorkOnFloorDetails ");
                //}

                #region Antenna Curb Cut PAA Changes
                EntityCollection ParentAnSOWDetails = RetrieveRelatedEntities(service, ParentJobGuid, AntennaScopeOfWorkEntityAttributeName.EntityLogicalName, AntennaScopeOfWorkEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("ParentAnSOWDetails.Entities.Count: " + ParentAnSOWDetails.Entities.Count.ToString());
                if (ParentAnSOWDetails.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentAnSOWDetails.Entities.Count: " + ParentAnSOWDetails.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentAnSOWDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentAnSOWDetails ");
                }

                EntityCollection ParentANDS1Details = RetrieveRelatedEntities(service, ParentJobGuid, AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName, AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("ParentANDS1Details.Entities.Count: " + ParentANDS1Details.Entities.Count.ToString());
                if (ParentANDS1Details.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentANDS1Details.Entities.Count: " + ParentANDS1Details.Entities.Count);
                    DeleteEntityCollection2(service, ParentANDS1Details, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentANDS1Details ");
                }

                EntityCollection ParentCCQDetails = RetrieveRelatedEntities(service, ParentJobGuid, CurbCutQuestionnaireEntityAttributeName.EntityLogicalName, CurbCutQuestionnaireEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("ParentCCQDetails.Entities.Count.ToString(): " + ParentCCQDetails.Entities.Count);
                if (ParentCCQDetails.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentCCQDetails.Entities.Count: " + ParentCCQDetails.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentCCQDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentCCQDetails ");
                }

                #region Delegates - Delete
                EntityCollection ParentDelegatesDetails = RetrieveRelatedEntities(service, ParentJobGuid, DelegatesEntityAttributeNames.EntityLogicalName, DelegatesEntityAttributeNames.GoToJobFiling);
                crmTrace.AppendLine("ParentDelegatesDetails.Entities.Count: " + ParentDelegatesDetails.Entities.Count.ToString());
                if (ParentDelegatesDetails.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentDelegatesDetails.Entities.Count: " + ParentDelegatesDetails.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentDelegatesDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentDelegatesDetails ");

                }
                #endregion                
                #endregion

                //#region PA PAA Changes
                //EntityCollection ParentPlaceOfAssemblySpaceInfo = RetrieveRelatedEntities(service, ParentJobGuid, PlaceofAssemblySpaceInformation.EntityLogicalName, PlaceofAssemblySpaceInformation.jobFilingID);
                //crmTrace.AppendLine("ParentPlaceOfAssemblySpaceInfo.Entities.Count: " + ParentPlaceOfAssemblySpaceInfo.Entities.Count);
                //if (ParentPlaceOfAssemblySpaceInfo.Entities.Count > 0)
                //{
                //    crmTrace.AppendLine("ParentPlaceOfAssemblySpaceInfo.Entities.Count: " + ParentPlaceOfAssemblySpaceInfo.Entities.Count);
                //    DeleteEntityCollection2(service, ParentPlaceOfAssemblySpaceInfo, crmTrace);
                //    crmTrace.AppendLine("Retrieved and Deleted all ParentPlaceOfAssemblySpaceInfo ");
                //}
                //#endregion


                #region TPA PAA Changes
                EntityCollection ParentTempPlaceOfAssemblySpaceInfo = RetrieveRelatedEntities(service, ParentJobGuid, TempororayPlaceOfAssembly.EntityLogicalName, TempororayPlaceOfAssembly.jobfilingLookup);
                crmTrace.AppendLine("ParentTempPlaceOfAssemblySpaceInfo.Entities.Count: " + ParentTempPlaceOfAssemblySpaceInfo.Entities.Count.ToString());
                if (ParentTempPlaceOfAssemblySpaceInfo.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentPlaceOfAssemblySpaceInfo.Entities.Count: " + ParentTempPlaceOfAssemblySpaceInfo.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentTempPlaceOfAssemblySpaceInfo, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentTempPlaceOfAssemblySpaceInfo ");
                }
                #endregion
                service.Update(ParentJobRecord);

                crmTrace.AppendLine("Retrieving all the Related Entities records of Parent Job Filing and Deleting them - Ended ");
                #endregion

                # region Retrieving all the Related Entities records of PAA and Creating in ParentJob
                crmTrace.AppendLine("Retrieving all the Related Entities records of PAA and Creating in ParentJob - Started ");

                #region ScopeofWork
                EntityCollection PAAScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, ScopeOfWorkEntityAttributeName.EntityLogicalName, ScopeOfWorkEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("PAAScopeofWork Count: " + PAAScopeofWork.Entities.Count.ToString());
                if (PAAScopeofWork.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAAScopeofWork.Entities.Count; j++)
                    {
                        Entity PAAScopeofWorkRecord = (Entity)PAAScopeofWork.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, PAAScopeofWorkRecord, ParentJobGuid, crmTrace);
                        AdjustedPAAScopeofWork.Entities.Add(temp);

                    }

                    crmTrace.AppendLine("AdjustedPAAScopeofWork Count: " + AdjustedPAAScopeofWork.Entities.Count.ToString());
                    CreateEntityCollection2(service, AdjustedPAAScopeofWork, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAScopeofWork in Parent");
                }
                #endregion

                #region AN Scope of Work
                EntityCollection PAAANSOWDetails = RetrieveRelatedEntities(service, targetEntity.Id, AntennaScopeOfWorkEntityAttributeName.EntityLogicalName, AntennaScopeOfWorkEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("PAAANSOWDetails Count: " + PAAANSOWDetails.Entities.Count);
                if (PAAANSOWDetails.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAANSOWDetails = new EntityCollection();
                    foreach (Entity ent in PAAANSOWDetails.Entities)
                    {
                        Entity PAAANSOWDetailsRecord = ent;
                        Entity temp = CreateAntennaCurbCutClonelist(service, PAAANSOWDetailsRecord, ParentJobGuid, crmTrace);
                        if (temp.Id != null)
                        {
                            ParentJobRecord.Attributes.Add(JobFilingEntityAttributeName.GoToAntennaScopeofWork, new EntityReference(AntennaScopeOfWorkEntityAttributeName.EntityLogicalName, temp.Id));
                        }
                        AdjustedPAAANSOWDetails.Entities.Add(temp);
                    }
                    CreateEntityCollection2(service, AdjustedPAAANSOWDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAANSOWDetails in Parent");
                }
                #endregion

                #region BE Scope of work
                EntityCollection BEScopeOfWorkDetails = RetrieveRelatedEntities(service, targetEntity.Id, BEScopeOfWorkEntityAttribute.EntityLogicalName, BEScopeOfWorkEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("BEScopeOfWorkDetails Count: " + BEScopeOfWorkDetails.Entities.Count);
                if (BEScopeOfWorkDetails.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAANSOWDetails = new EntityCollection();
                    foreach (Entity ent in BEScopeOfWorkDetails.Entities)
                    {
                        Entity PAAANSOWDetailsRecord = ent;
                        Entity temp = CreateBESOWClonelist(service, PAAANSOWDetailsRecord, ParentJobGuid, crmTrace);

                        AdjustedPAAANSOWDetails.Entities.Add(temp);
                    }
                    CreateEntityCollection2(service, AdjustedPAAANSOWDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAANSOWDetails in Parent");
                }


                #endregion

                #region BE Devices
                EntityCollection BEDevices = RetrieveRelatedEntities(service, targetEntity.Id, BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling);
                crmTrace.AppendLine("BEDevices Count: " + BEDevices.Entities.Count);
                if (BEDevices.Entities.Count > 0)
                {
                    
                    #region Master Boiler device updates
                    //1)Check i1 filing status id filing status is not in permit issued and permit entire do not touch master device.
                    //2)if i1 is permit entire then  check the scope of work of PAA if it is new installation and replacement of boiler then update them  for burner and fuel storage always update them
                    crmTrace.AppendLine("Update Master Device when PAA is approved if I1 is permit entire and permit issued");
                    FeeCalculationStandardizationHandler.BoilerPAAMainMethod(service, targetEntity, ParentJobGuid, crmTrace);
                    #endregion
                    Guid BDGuid;
                    EntityCollection AdjustedPAAANSOWDetails = new EntityCollection();
                    foreach (Entity ent in BEDevices.Entities)
                    {
                        Entity PAAANSOWDetailsRecord = ent;
                        Entity temp = CreateBEDevicesClonelist(service, PAAANSOWDetailsRecord, ParentJobGuid, crmTrace);
                        BDGuid = service.Create(temp);
                        EntityCollection AssociatedBoilerDevices = RetrieveRelatedEntities(service, ent.Id, "dobnyc_associatedboilerdevices", "dobnyc_abd_boilerbuilddevicedetails");
                        if (AssociatedBoilerDevices.Entities.Count > 0)
                        {
                            for (int K = 0; K < AssociatedBoilerDevices.Entities.Count; K++)
                            {
                                Entity AssDevice = (Entity)AssociatedBoilerDevices.Entities[K];
                                Entity AssDevices = new Entity();
                                Guid AssDeviceGuid;
                                Entity AssDeviceresponse = service.Retrieve("dobnyc_associatedboilerdevices", AssDevice.Id, new ColumnSet(true));
                                AssDevices = EntityExtensions.Clone(AssDeviceresponse, false);

                                AssDevices.Attributes.Remove("dobnyc_abd_boilerbuilddevicedetails");
                                AssDevices.Attributes.Remove("dobnyc_associatedboilerdevicesid");
                                AssDevices.Attributes.Add("dobnyc_abd_boilerbuilddevicedetails", new EntityReference("dobnyc_associatedboilerdevices", BDGuid));
                                AssDevices.Id = Guid.NewGuid();
                                AssDeviceGuid = service.Create(AssDevices);
                                crmTrace.AppendLine("AssDeviceGuid ID :" + AssDeviceGuid);
                            }
                        }
                        //CreateEntityCollection2(service, AdjustedPAAANSOWDetails, crmTrace);
                        crmTrace.AppendLine("Retrieved and Created all PAAANSOWDetails in Parent");
                    }
                }
                #endregion

                #region AN DS1
                EntityCollection PAAANDS1Details = RetrieveRelatedEntities(service, targetEntity.Id, AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName, AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("PAAANDS1Details Count: " + PAAANDS1Details.Entities.Count);
                if (PAAANDS1Details.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAANDS1Details = new EntityCollection();
                    foreach (Entity ent in PAAANDS1Details.Entities)
                    {
                        Entity PAAANDS1DetailsRecord = ent;
                        Entity temp = CreateAntennaCurbCutClonelist(service, PAAANDS1DetailsRecord, ParentJobGuid, crmTrace);
                        if (temp.Id != null)
                        {
                            ParentJobRecord.Attributes.Add(JobFilingEntityAttributeName.GoToAntennaDS1, new EntityReference(AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName, temp.Id));
                        }
                        AdjustedPAAANDS1Details.Entities.Add(temp);
                    }
                    CreateEntityCollection2(service, AdjustedPAAANDS1Details, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAANDS1Details in Parent");
                }
                #endregion

                #region CCQ
                EntityCollection PAACCQDetails = RetrieveRelatedEntities(service, targetEntity.Id, CurbCutQuestionnaireEntityAttributeName.EntityLogicalName, CurbCutQuestionnaireEntityAttributeName.GoToJobFiling);
                crmTrace.AppendLine("PAACCQDetails Count: " + PAACCQDetails.Entities.Count);
                if (PAACCQDetails.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAACCQDetails = new EntityCollection();
                    foreach (Entity ent in PAACCQDetails.Entities)
                    {
                        Entity PAACCQDetailsRecord = ent;
                        Entity temp = CreateAntennaCurbCutClonelist(service, PAACCQDetailsRecord, ParentJobGuid, crmTrace);
                        if (temp.Id != null)
                        {
                            ParentJobRecord.Attributes.Add(JobFilingEntityAttributeName.GoToCurbCutQuestionnaire, new EntityReference(CurbCutQuestionnaireEntityAttributeName.EntityLogicalName, temp.Id));
                        }
                        AdjustedPAACCQDetails.Entities.Add(temp);
                    }
                    CreateEntityCollection2(service, AdjustedPAACCQDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAACCQDetails in Parent");
                }
                #endregion

                #region Work Cost Details                
                EntityCollection PAAWorkCostDetails = RetrieveRelatedEntities(service, targetEntity.Id, WorkCostDetailsAttributeNames.EntityLogicalName, WorkCostDetailsAttributeNames.GoToJobFiling);
                crmTrace.AppendLine("PAAWorkCostDetails Count: " + PAAWorkCostDetails.Entities.Count);
                if (PAAWorkCostDetails.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAWorkCostDetails = new EntityCollection();
                    for (int j = 0; j < PAAWorkCostDetails.Entities.Count; j++)
                    {
                        Entity PAAWorkCostDetailsRecord = (Entity)PAAWorkCostDetails.Entities[j];
                        Entity temp = CreateWorkCostDetailslist(service, PAAWorkCostDetailsRecord, ParentJobGuid, crmTrace);
                        AdjustedPAAWorkCostDetails.Entities.Add(temp);

                    }
                    CreateEntityCollection2(service, AdjustedPAAWorkCostDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAWorkCostDetails in Parent");
                }
                #endregion
                //Added by SN on 1/16/2019
                #region Zoning Characterisitics
                EntityCollection PAAZoningCharacteristics = RetrieveRelatedEntities(service, targetEntity.Id, ZoningCharactersticsPW1AttributeNames.EntityLogicalName, ZoningCharactersticsPW1AttributeNames.JobFilingGuid);

                crmTrace.AppendLine("ZoningCharacteristics Count: " + PAAZoningCharacteristics.Entities.Count);
                if (PAAZoningCharacteristics.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAZoningCharacteristics = new EntityCollection();
                    for (int j = 0; j < PAAZoningCharacteristics.Entities.Count; j++)
                    {
                        Entity PAAZoningCharacteristicsRecord = (Entity)PAAZoningCharacteristics.Entities[j];
                        Entity temp = CreateZoningCharacteristicslist(service, PAAZoningCharacteristicsRecord, ParentJobGuid, crmTrace);
                        AdjustedPAAZoningCharacteristics.Entities.Add(temp);

                    }
                    CreateEntityCollection2(service, AdjustedPAAZoningCharacteristics, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAAZoningCharacteristics in Parent");
                }
                #endregion

                #region Special Inspection Categories deletion
                EntityCollection ParentSpecialInspectionCategories = RetrieveRelatedEntities(service, ParentJobGuid, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                if (ParentSpecialInspectionCategories.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentSpecialInspectionCategories.Entities.Count: " + ParentSpecialInspectionCategories.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentSpecialInspectionCategories, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentSpecialInspectionCategories ");
                }
                #endregion
                #region Progress Inspection Categories deletion
                EntityCollection ParentProgressInspectionCategories = RetrieveRelatedEntities(service, ParentJobGuid, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                if (ParentProgressInspectionCategories.Entities.Count > 0)
                {
                    crmTrace.AppendLine("ParentProgressInspectionCategories.Entities.Count: " + ParentProgressInspectionCategories.Entities.Count.ToString());
                    DeleteEntityCollection2(service, ParentProgressInspectionCategories, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all ParentProgressInspectionCategories ");
                }
                #endregion
                #region Special Inspection Categories
                EntityCollection PAASpecialInspectionCategories = RetrieveRelatedEntities(service, targetEntity.Id, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                crmTrace.AppendLine("PAASpecialInspectionCategories Count: " + PAASpecialInspectionCategories.Entities.Count);
                if (PAASpecialInspectionCategories.Entities.Count > 0)
                {
                    //EntityCollection AdjustedPAASpecialInspectionCategories = new EntityCollection();
                    Dictionary<Entity, Entity> dict = new Dictionary<Entity, Entity>();
                    for (int j = 0; j < PAASpecialInspectionCategories.Entities.Count; j++)
                    {
                        Entity temp = null;
                        Entity temDoc = null;
                        Entity PAASpecialInspectionCategoriesRecord = (Entity)PAASpecialInspectionCategories.Entities[j];
                        temp = CreateSpecialInspectionCategorieslist(service, PAASpecialInspectionCategoriesRecord, ParentJobGuid, crmTrace);
                        //AdjustedPAASpecialInspectionCategories.Entities.Add(temp);
                        EntityCollection documentsrelated = GetDocumentRegarding_SICandPIC(service, PAASpecialInspectionCategoriesRecord, crmTrace);
                        crmTrace.AppendLine("documentsrelated Count: " + documentsrelated.Entities.Count);
                        if (documentsrelated != null && documentsrelated.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Adding document to temp doc ");
                            temDoc = documentsrelated.Entities[0];
                            crmTrace.AppendLine("temDoc.LogicalName:  " + temDoc.LogicalName);
                        }
                        crmTrace.AppendLine("Adding Entities in Dictionary");
                        dict.Add(temp, temDoc);
                        crmTrace.AppendLine("Added Entities in Dictionary");
                    }
                    //CreateEntityCollection2(service, AdjustedPAASpecialInspectionCategories, crmTrace);
                    CreateEntities_FromDictionary(service, dict, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAASpecialInspectionCategories in Parent");
                    //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", null, crmTrace.ToString(), null, null);
                }
                #endregion

                #region Progress Inspection Categories
                EntityCollection PAAProgressInspectionCategories = RetrieveRelatedEntities(service, targetEntity.Id, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                crmTrace.AppendLine("PAAProgressInspectionCategories Count: " + PAAProgressInspectionCategories.Entities.Count);
                if (PAAProgressInspectionCategories.Entities.Count > 0)
                {
                    Dictionary<Entity, Entity> dict = new Dictionary<Entity, Entity>();
                    for (int j = 0; j < PAAProgressInspectionCategories.Entities.Count; j++)
                    {
                        Entity temp = null;
                        Entity temDoc = null;
                        Entity PAAProgressInspectionCategoriesRecord = (Entity)PAAProgressInspectionCategories.Entities[j];
                        temp = CreateProgressInspectionCategorieslist(service, PAAProgressInspectionCategoriesRecord, ParentJobGuid, crmTrace);
                        //AdjustedPAASpecialInspectionCategories.Entities.Add(temp);
                        EntityCollection documentsrelated = GetDocumentRegarding_SICandPIC(service, PAAProgressInspectionCategoriesRecord, crmTrace);
                        crmTrace.AppendLine("documentsrelated Count: " + documentsrelated.Entities.Count);
                        if (documentsrelated != null && documentsrelated.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Adding document to temp doc ");
                            temDoc = documentsrelated.Entities[0];
                            crmTrace.AppendLine("temDoc.LogicalName:  " + temDoc.LogicalName);
                        }
                        crmTrace.AppendLine("Adding Entities in Dictionary");
                        dict.Add(temp, temDoc);
                        crmTrace.AppendLine("Added Entities in Dictionary");
                    }
                    //CreateEntityCollection2(service, AdjustedPAASpecialInspectionCategories, crmTrace);
                    CreateEntities_FromDictionary(service, dict, crmTrace);
                    #region to be removed
                    //EntityCollection AdjustedPAAProgressInspectionCategories = new EntityCollection();
                    //for (int j = 0; j < PAAProgressInspectionCategories.Entities.Count; j++)
                    //{
                    //    Entity PAAProgressInspectionCategoriesRecord = (Entity)PAAProgressInspectionCategories.Entities[j];
                    //    Entity temp = CreateProgressInspectionCategorieslist(service, PAAProgressInspectionCategoriesRecord, ParentJobGuid, crmTrace);
                    //    AdjustedPAAProgressInspectionCategories.Entities.Add(temp);

                    //}
                    //CreateEntityCollection2(service, AdjustedPAAProgressInspectionCategories, crmTrace);
                    #endregion
                    crmTrace.AppendLine("Retrieved and Created all PAAProgressInspectionCategories in Parent");
                }
                #endregion

                //#region Work On Floor Details
                //EntityCollection PAAWorkOnFloorDetails = RetrieveRelatedEntities(service, targetEntity.Id, WorkOnFloorEntityAttributeName.EntityLogicalName, WorkOnFloorEntityAttributeName.GoToJobFiling);
                //crmTrace.AppendLine("PAAWorkOnFloorDetails Count: " + PAAWorkOnFloorDetails.Entities.Count);
                //if (PAAWorkOnFloorDetails.Entities.Count > 0)
                //{
                //    EntityCollection AdjustedPAAWorkOnFloorDetails = new EntityCollection();
                //    for (int j = 0; j < PAAWorkOnFloorDetails.Entities.Count; j++)
                //    {
                //        Entity PAAWorkOnFloorDetailsRecord = (Entity)PAAWorkOnFloorDetails.Entities[j];
                //        Entity temp = CreateWorkOnFloorDetailslist(service, PAAWorkOnFloorDetailsRecord, ParentJobGuid, crmTrace);
                //        AdjustedPAAWorkOnFloorDetails.Entities.Add(temp);
                //    }
                //    CreateEntityCollection2(service, AdjustedPAAWorkOnFloorDetails, crmTrace);
                //    crmTrace.AppendLine("Retrieved and Created all PAAWorkOnFloorDetails in Parent");
                //}
                //#endregion

                #region Delegates
                EntityCollection PAADelegatesDetails = RetrieveRelatedEntities(service, targetEntity.Id, DelegatesEntityAttributeNames.EntityLogicalName, DelegatesEntityAttributeNames.GoToJobFiling);
                crmTrace.AppendLine("PAADelegatesDetails Count: " + PAADelegatesDetails.Entities.Count);
                if (PAADelegatesDetails.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAADelegatesDetails = new EntityCollection();
                    for (int d = 0; d < PAADelegatesDetails.Entities.Count; d++)
                    {
                        Entity PAADelegatesDetailsRecord = (Entity)PAADelegatesDetails.Entities[d];
                        Entity temp = CreateDelegatesClonelist(service, PAADelegatesDetailsRecord, ParentJobGuid, crmTrace);
                        AdjustedPAADelegatesDetails.Entities.Add(temp);
                    }
                    CreateEntityCollection2(service, AdjustedPAADelegatesDetails, crmTrace);
                    crmTrace.AppendLine("Retrieved and Created all PAADelegatesDetails in Parent");
                }
                #endregion

                service.Update(ParentJobRecord);

                #region FenceScopeofWork
                Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                crmTrace.AppendLine("Construction Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence));
                if ((currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) && currentPAARecord[JobFilingEntityAttributeName.ConstructionFence] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true) || feeObject.IsFN)
                {
                    //Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                    EntityCollection PAAFenceScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, FenceScopeofWorkAttributeNames.EntityLogicalName, FenceScopeofWorkAttributeNames.GotoJobFiling);
                    crmTrace.AppendLine("PAAFenceScopeofWork Count: " + PAAFenceScopeofWork.Entities.Count);
                    if (PAAFenceScopeofWork.Entities.Count > 0)
                    {
                        EntityCollection AdjustedPAAFenceScopeofWork = new EntityCollection();
                        for (int j = 0; j < PAAFenceScopeofWork.Entities.Count; j++)
                        {
                            Entity FencePAAScopeofWorkRecord = (Entity)PAAFenceScopeofWork.Entities[j];
                            Entity temp = CreateScopeofWorklist(service, FencePAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                            Guid fnGuid = service.Create(temp);
                            UpdateParent.Attributes.Add(JobFilingEntityAttributeName.FenceScopeofWorklookup, new EntityReference(FenceScopeofWorkAttributeNames.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                        }


                    }
                }

                #endregion
                crmTrace.AppendLine("SupportedScaffold Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.SupportedScaffold) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold));
                #region ScaffoldScopeofWork
                if ((currentPAARecord.Contains(JobFilingEntityAttributeName.SupportedScaffold) && currentPAARecord[JobFilingEntityAttributeName.SupportedScaffold] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true)|| feeObject.IsSF)
                {
                    // Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                    Dictionary<Entity, Entity> dict = new Dictionary<Entity, Entity>();
                    EntityCollection PAAScaffoldScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, ScaffoldScopeofWorkAttributeNames.GotoJobFiling);
                    crmTrace.AppendLine("PAAScaffoldScopeofWork Count: " + PAAScaffoldScopeofWork.Entities.Count);
                    if (PAAScaffoldScopeofWork.Entities.Count > 0)
                    {
                        EntityCollection AdjustedPAAFenceScopeofWork = new EntityCollection();
                        for (int j = 0; j < PAAScaffoldScopeofWork.Entities.Count; j++)
                        {
                            Entity FencePAAScopeofWorkRecord = (Entity)PAAScaffoldScopeofWork.Entities[j];
                            Entity temp = CreateScopeofWorklist(service, FencePAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                            Guid sfGuid = service.Create(temp);
                            UpdateParent.Attributes.Add(JobFilingEntityAttributeName.ScaffoldScopeofWorklookup, new EntityReference(ScaffoldScopeofWorkAttributeNames.EntityLogicalName, sfGuid));//Replacing parent SF Lookup

                            EntityCollection addressrelated = GetAffectedAddress_SFSWSSCopeOfWorks(service, FencePAAScopeofWorkRecord, crmTrace);
                            crmTrace.AppendLine("documentsrelated Count: " + addressrelated.Entities.Count);
                            if (addressrelated != null && addressrelated.Entities.Count > 0)
                            {
                                foreach (Entity tempAddr in addressrelated.Entities)
                                {
                                    Entity CloneAddr = new Entity(DOBAddress.EntityLogicalName);
                                    CloneAddr.Attributes.Add(DOBAddress.HouseNumber, tempAddr.GetAttributeValue<string>(DOBAddress.HouseNumber));
                                    CloneAddr.Attributes.Add(DOBAddress.StretName, tempAddr.GetAttributeValue<string>(DOBAddress.StretName));
                                    CloneAddr.Attributes.Add(DOBAddress.Borough, tempAddr.GetAttributeValue<OptionSetValue>(DOBAddress.Borough));
                                    CloneAddr.Attributes.Add(DOBAddress.SFLookup, new EntityReference(ScaffoldScopeofWorkAttributeNames.EntityLogicalName, sfGuid));
                                    service.Create(CloneAddr);
                                }
                            }



                        }


                    }
                }

                #endregion
                crmTrace.AppendLine("SidewalkShed Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.SidewalkShed) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed));
                #region SWSScopeofWork
                if ((currentPAARecord.Contains(JobFilingEntityAttributeName.SidewalkShed) && currentPAARecord[JobFilingEntityAttributeName.SidewalkShed] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true)|| feeObject.IsSH)
                {

                    EntityCollection PAASWSScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, SHScopeofWorkAttributeNames.EntityLogicalName, SHScopeofWorkAttributeNames.GotoJobFiling);
                    crmTrace.AppendLine("PAASWSScopeofWork Count: " + PAASWSScopeofWork.Entities.Count);
                    if (PAASWSScopeofWork.Entities.Count > 0)
                    {
                        EntityCollection AdjustedPAAFenceScopeofWork = new EntityCollection();
                        for (int j = 0; j < PAASWSScopeofWork.Entities.Count; j++)
                        {
                            Entity FencePAAScopeofWorkRecord = (Entity)PAASWSScopeofWork.Entities[j];
                            Entity temp = CreateScopeofWorklist(service, FencePAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.

                            Guid swsGuid = service.Create(temp);
                            UpdateParent.Attributes.Add(JobFilingEntityAttributeName.SHScopeofWorklookup, new EntityReference(SHScopeofWorkAttributeNames.EntityLogicalName, swsGuid));//Replacing Parent SWS Lookup

                            EntityCollection addressrelated = GetAffectedAddress_SFSWSSCopeOfWorks(service, FencePAAScopeofWorkRecord, crmTrace);
                            crmTrace.AppendLine("documentsrelated Count: " + addressrelated.Entities.Count);
                            if (addressrelated != null && addressrelated.Entities.Count > 0)
                            {
                                foreach (Entity tempAddr in addressrelated.Entities)
                                {
                                    Entity CloneAddr = new Entity(DOBAddress.EntityLogicalName);
                                    CloneAddr.Attributes.Add(DOBAddress.HouseNumber, tempAddr.GetAttributeValue<string>(DOBAddress.HouseNumber));
                                    CloneAddr.Attributes.Add(DOBAddress.StretName, tempAddr.GetAttributeValue<string>(DOBAddress.StretName));
                                    CloneAddr.Attributes.Add(DOBAddress.Borough, tempAddr.GetAttributeValue<OptionSetValue>(DOBAddress.Borough));
                                    CloneAddr.Attributes.Add(DOBAddress.SWSLookup, new EntityReference(SHScopeofWorkAttributeNames.EntityLogicalName, swsGuid));
                                    service.Create(CloneAddr);
                                }
                            }

                        }


                    }
                }
                #endregion


                #region MHScopeofWork
                //Entity JFUpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                crmTrace.AppendLine("Construction Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence));
                //  if (currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) && currentPAARecord[JobFilingEntityAttributeName.ConstructionFence] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                //  {
                //Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                EntityCollection PAAMHScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, MHScopeofworkAttributeNames.EntityLogicalName, MHScopeofworkAttributeNames.GotoJobFiling);
                crmTrace.AppendLine("PAAMHScopeofWork Count: " + PAAMHScopeofWork.Entities.Count);
                if (PAAMHScopeofWork.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAAMHScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAAMHScopeofWork.Entities.Count; j++)
                    {
                        Entity MHPAAScopeofWorkRecord = (Entity)PAAMHScopeofWork.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, MHPAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                        Guid fnGuid = service.Create(temp);
                        // UpdateParent.Attributes.Add(JobFilingEntityAttributeName.FenceScopeofWorklookup, new EntityReference(FenceScopeofWorkAttributeNames.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                    }


                }
                //  }

                #endregion
                #region STScopeofWork
                //Entity JFUpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                // crmTrace.AppendLine("Construction Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence));
                //  if (currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) && currentPAARecord[JobFilingEntityAttributeName.ConstructionFence] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                //  {
                //Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                EntityCollection PAAScopeOfWorkQuestionaire = RetrieveRelatedEntities(service, targetEntity.Id, ScopeofWorkQuestionnaire.EntityLogicalName, ScopeofWorkQuestionnaire.GotoJobFiling);
                crmTrace.AppendLine("PAASTScopeofWork Count: " + PAAScopeOfWorkQuestionaire.Entities.Count);
                if (PAAScopeOfWorkQuestionaire.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAASTScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAAScopeOfWorkQuestionaire.Entities.Count; j++)
                    {
                        Entity PAAScopeOfWorkQuestionaireRecord = (Entity)PAAScopeOfWorkQuestionaire.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, PAAScopeOfWorkQuestionaireRecord, ParentJobGuid, crmTrace);//have to modify this method.
                        Guid fnGuid = service.Create(temp);
                        UpdateParent.Attributes.Add(JobFilingEntityAttributeName.ScopeofworkQuestionnaireLookup, new EntityReference(ScopeofWorkQuestionnaire.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                    }


                }
                //  }

                #endregion

                #region STScopeofWork
                //Entity JFUpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                // crmTrace.AppendLine("Construction Fence " + currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) + " Value:" + currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence));
                //  if (currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) && currentPAARecord[JobFilingEntityAttributeName.ConstructionFence] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true)
                //  {
                //Entity UpdateParent = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                EntityCollection PAASTScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, STScopeOfWorkEntityAttribute.EntityLogicalName, STScopeOfWorkEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("PAASTScopeofWork Count: " + PAASTScopeofWork.Entities.Count);
                if (PAASTScopeofWork.Entities.Count > 0)
                {
                    EntityCollection AdjustedPAASTScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAASTScopeofWork.Entities.Count; j++)
                    {
                        Entity STPAAScopeofWorkRecord = (Entity)PAASTScopeofWork.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, STPAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                        Guid fnGuid = service.Create(temp);
                        UpdateParent.Attributes.Add(JobFilingEntityAttributeName.STScopeofworkLookup, new EntityReference(STScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                    }


                }
                //  }

                #endregion
                #region TR3 Reports
                EntityCollection STTR3 = RetrieveRelatedEntities(service, targetEntity.Id, TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3TechnicalReportEntityAttribute.GotoJobFiling);
                EntityCollection parentSTTR3 = RetrieveRelatedEntities(service, ParentJobGuid, TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3TechnicalReportEntityAttribute.GotoJobFiling);
                Guid TR3Guid;
                if (STTR3.Entities.Count > 0 && parentSTTR3.Entities.Count == 0)
                {

                    for (int j = 0; j < STTR3.Entities.Count; j++)
                    {
                        Entity TR3TechnicalReport = (Entity)STTR3.Entities[j];
                        Entity CS = new Entity();
                       
                        if (TR3TechnicalReport.LogicalName == TR3TechnicalReportEntityAttribute.EntityLogicalName)
                        {
                            Entity response = service.Retrieve(TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3TechnicalReport.Id, new ColumnSet(true));
                            CS = EntityExtensions.Clone(response, false);

                            CS.Attributes.Remove(TR3TechnicalReportEntityAttribute.GotoJobFiling);
                            CS.Attributes.Remove(TR3TechnicalReportEntityAttribute.ID);
                            CS.Attributes.Add(TR3TechnicalReportEntityAttribute.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                            CS.Id = Guid.NewGuid();
                            crmTrace.AppendLine("TR3TechnicalReport CS ID :" + CS.Id.ToString());
                            TR3Guid = service.Create(CS);
                            // Get Related TR3 Mixes for TR3 Technical Report
                            EntityCollection TR3Mixes = RetrieveRelatedEntities(service, TR3TechnicalReport.Id, TR3Mix.EntityLogicalName, TR3Mix.GoToTR3Directors);
                            if (TR3Mixes.Entities.Count > 0)
                            {
                                for (int K = 0; K < TR3Mixes.Entities.Count; K++)
                                {
                                    Entity TR3Mixobj = (Entity)TR3Mixes.Entities[K];
                                    Entity Mix = new Entity();
                                    Guid MixGuid;
                                    if (TR3Mixobj.LogicalName == TR3Mix.EntityLogicalName)
                                    {
                                        Entity Mixresponse = service.Retrieve(TR3Mix.EntityLogicalName, TR3Mixobj.Id, new ColumnSet(true));
                                        Mix = EntityExtensions.Clone(Mixresponse, false);

                                        Mix.Attributes.Remove(TR3Mix.ID);
                                        Mix.Attributes.Remove(TR3Mix.GoToTR3Directors);
                                        Mix.Attributes.Remove(TR3Mix.IsMixcreatedonPAA);
                                        Mix.Attributes.Add(TR3Mix.GoToTR3Directors, new EntityReference(TR3TechnicalReportEntityAttribute.EntityLogicalName, TR3Guid));
                                        Mix.Id = Guid.NewGuid();
                                        Mix.Attributes.Add(TR3Mix.IsMixcreatedonPAA, true);
                                        crmTrace.AppendLine("TR3TechnicalReport Mixresponse ID :" + Mixresponse.Id.ToString());
                                        MixGuid = service.Create(Mix);
                                        crmTrace.AppendLine("TR3TechnicalReport MixGuid ID :" + MixGuid);
                                        EntityCollection TR3MixDocument = RetrieveRelatedEntities(service, TR3Mixobj.Id, DocumentListEntityAttributeName.EntityLogicalName, DocumentListEntityAttributeName.GotoTr3Mix);
                                        if (TR3MixDocument.Entities.Count > 0)
                                        {
                                            Entity MixDocobj = (Entity)TR3MixDocument.Entities[0];
                                            Entity MixDoc = new Entity();
                                            Entity MixDocresponse = service.Retrieve(DocumentListEntityAttributeName.EntityLogicalName, MixDocobj.Id, new ColumnSet(true));
                                            MixDoc = EntityExtensions.Clone(MixDocresponse, false);
                                            MixDoc.Attributes.Remove(DocumentListEntityAttributeName.GotoTr3Mix);
                                            MixDoc.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                                            MixDoc.Attributes.Remove(DocumentListEntityAttributeName.GoToTR3TechReports);
                                            MixDoc.Attributes.Add(DocumentListEntityAttributeName.GotoTr3Mix, new EntityReference(TR3Mix.EntityLogicalName, MixGuid));
                                            MixDoc.Attributes.Add(DocumentListEntityAttributeName.GoToTR3TechReports, new EntityReference(TR3Mix.EntityLogicalName, TR3Guid));
                                            MixDoc.Id = Guid.NewGuid();
                                            crmTrace.AppendLine("TR3TechnicalReport MixDocresponse ID :" + MixDoc.Id.ToString());
                                            service.Create(MixDoc);
                                        }
                                        EntityCollection TR3MixIngridient = RetrieveRelatedEntities(service, TR3Mixobj.Id, TR3MixIngredients.EntityLogicalName, TR3MixIngredients.GoToTR3);
                                        if (TR3MixIngridient.Entities.Count > 0)
                                        {
                                            for (int L = 0; L < TR3MixIngridient.Entities.Count; L++)
                                            {
                                                Entity TR3MixIngridientobj = (Entity)TR3MixIngridient.Entities[L];
                                                Entity MixIngre = new Entity();
                                                Entity MixIngridients = service.Retrieve(TR3MixIngredients.EntityLogicalName, TR3MixIngridientobj.Id, new ColumnSet(true));
                                                MixIngre = EntityExtensions.Clone(MixIngridients, false);
                                                MixIngre.Attributes.Remove(TR3MixIngredients.GoToTR3);
                                                MixIngre.Attributes.Remove(TR3MixIngredients.TR3MixIngredientsid);
                                                MixIngre.Attributes.Add(TR3MixIngredients.GoToTR3, new EntityReference(TR3Mix.EntityLogicalName, MixGuid));
                                                MixIngre.Id = Guid.NewGuid();
                                                crmTrace.AppendLine("TR3TechnicalReport MixIngridients ID :" + MixIngre.Id.ToString());
                                                service.Create(MixIngre);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                #region TR2 Reports
                EntityCollection TR2Director = RetrieveRelatedEntities(service, targetEntity.Id, TR2TechnicalReport.EntityLogicalName, TR2TechnicalReport.GotoJobFiling);
                EntityCollection ParentTR2Director = RetrieveRelatedEntities(service, ParentJobGuid, TR2TechnicalReport.EntityLogicalName, TR2TechnicalReport.GotoJobFiling);
                crmTrace.AppendLine("TR2Report Count: " + TR2Director.Entities.Count);
                Entity Tr2Record = new Entity();
                Guid TR2Record;
                if (TR2Director.Entities.Count > 0 && ParentTR2Director.Entities.Count == 0)
                {
                    for (int j = 0; j < TR2Director.Entities.Count; j++)
                    {
                        Entity TechnicalReports = (Entity)TR2Director.Entities[j];

                        if (TechnicalReports.LogicalName == TR2TechnicalReport.EntityLogicalName)
                        {
                            Entity response = service.Retrieve(TR2TechnicalReport.EntityLogicalName, TechnicalReports.Id, new ColumnSet(true));
                            Tr2Record = EntityExtensions.Clone(response, false);

                            Tr2Record.Attributes.Remove(TR2TechnicalReport.GotoJobFiling);
                            Tr2Record.Attributes.Remove(TR2TechnicalReport.TR2TechnicalReportId);
                            Tr2Record.Attributes.Add(TR2TechnicalReport.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                            Tr2Record.Id = Guid.NewGuid();
                            crmTrace.AppendLine("TR2TechnicalReport Tr2Record ID :" + Tr2Record.Id.ToString());
                        }
                        TR2Record = service.Create(Tr2Record);

                        ConditionExpression Tr3condition = new ConditionExpression();
                        ConditionExpression Tr4condition = new ConditionExpression();
                        EntityCollection TR3s = new EntityCollection();

                        Tr3condition = CreateConditionExpression(TR3Director.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                        Tr4condition = new ConditionExpression(TR3Director.designApplicantCheckBox, ConditionOperator.Equal, true); //get TR3 directors only whose attestation is completed.
                        EntityCollection TR3Directors = RetrieveMultiple(service, TR3Director.EntityLogicalName, new string[] { TR3Director.Name, TR3Director.CPBusinessaddesss,
                                TR3Director.CPBusinesCity, TR3Director.CPBusinesFax, TR3Director.CPBusinesName, TR3Director.CPBusinesNameLookup, TR3Director.CPBusinesState, TR3Director.CPBusinesTelephone,
                                TR3Director.CPBusinesZip, TR3Director.CPLicenseLookup, TR3Director.CPName, TR3Director.CPNameLookup, TR3Director.CPDate, TR3Director.NRMCAExpirationDate,TR3Director.TR3TrackingNumber }, new ConditionExpression[] { Tr3condition, Tr4condition }, LogicalOperator.And);
                        crmTrace.AppendLine("TR3Directors count : " + TR3Directors.Entities.Count);
                        if (TR3Directors != null && TR3Directors.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("3) loop through each director and get the Tr3 Mixs and store in one collection ");
                            foreach (Entity Tr3director in TR3Directors.Entities)
                            {
                                Tr3condition = CreateConditionExpression(TR3MixEntityAttribute.GotoTRTechnicalreport, ConditionOperator.Equal, new string[] { Tr3director.Id.ToString() });
                                EntityCollection Tr3mixs = RetrieveMultiple(service, TR3MixEntityAttribute.EntityLogicalName, new string[] { TR3MixEntityAttribute.EntityNameAttribute, TR3MixEntityAttribute.MixType, TR3MixEntityAttribute.SpecifiedStrength, TR3MixEntityAttribute.SpecifiedTestAge }, new ConditionExpression[] { Tr3condition }, LogicalOperator.And);
                                crmTrace.AppendLine("Tr3mixs count : " + Tr3mixs.Entities.Count);
                                foreach (Entity Tr3mix in Tr3mixs.Entities)
                                {
                                    crmTrace.AppendLine("5) Create the Tr2testreport on the tr2resport for all the tr3mix's in global collection.");

                                    FeeCalculationStandardizationHandler.CreateTR2TestReportonPAA(service, Tr3mix, Tr3director, Tr2Record, crmTrace, TR2Record);


                                }

                            }
                        }
                    }
                }
                #endregion
            

                #region SPSDScopeofWork
                EntityCollection PAASPSDScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, SPSDScopeOfWorkEntityAttribute.EntityLogicalName, SPSDScopeOfWorkEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("PAASPSDScopeofWork Count: " + PAASPSDScopeofWork.Entities.Count);
                if (PAASPSDScopeofWork.Entities.Count > 0)
                {
                    //EntityCollection AdjustedPAASTScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAASPSDScopeofWork.Entities.Count; j++)
                    {
                        Entity SPSDPAAScopeofWorkRecord = (Entity)PAASPSDScopeofWork.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, SPSDPAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                        Guid fnGuid = service.Create(temp);
                        // UpdateParent.Attributes.Add(JobFilingEntityAttributeName.STScopeofworkLookup, new EntityReference(STScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                        //Create scopeofworkonfloors
                        //EntityCollection PAAscopeofworkonfloors = RetrieveRelatedEntities(service, targetEntity.Id, ScopeOfWorkonFloorEntityAttribute.EntityLogicalName, ScopeOfWorkonFloorEntityAttribute.GoToJobFiling);

                        ConditionExpression condition1 = CreateConditionExpression(ScopeOfWorkonFloorEntityAttribute.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression condition2 = CreateConditionExpression(ScopeOfWorkonFloorEntityAttribute.GoToSPSD, ConditionOperator.Equal, new string[] { SPSDPAAScopeofWorkRecord.Id.ToString() });
                        crmTrace.AppendLine("Conditojn query id: " + targetEntity.Id.ToString() + "22" + SPSDPAAScopeofWorkRecord.Id.ToString());
                        EntityCollection PAAscopeofworkonfloors = RetrieveMultiple(service, ScopeOfWorkonFloorEntityAttribute.EntityLogicalName, null, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.And);


                        crmTrace.AppendLine("PAAscopeofworkonfloors Count: " + PAAscopeofworkonfloors.Entities.Count);
                        Entity UpdateSPSDSOW = new Entity(ScopeOfWorkonFloorEntityAttribute.EntityLogicalName);
                        crmTrace.AppendLine("Update the Parent ScopeOfWork on floor");


                        if (PAAscopeofworkonfloors.Entities.Count > 0)
                        {
                            for (int k = 0; k < PAAscopeofworkonfloors.Entities.Count; k++)
                            {
                                Entity SCopeOfWorkOnFloorRecord = (Entity)PAAscopeofworkonfloors.Entities[k];
                                Entity temp1 = CreateScopeofWorklist(service, SCopeOfWorkOnFloorRecord, ParentJobGuid, crmTrace);//have to modify this method.
                                Guid WorkonfloorguidonPAA = SCopeOfWorkOnFloorRecord.GetAttributeValue<EntityReference>(ScopeOfWorkonFloorEntityAttribute.Workonfloorlookup).Id;
                                ColumnSet columnsfloor = new ColumnSet(new string[] { WorkOnFloorEntityAttributeName.initialguid });
                                Entity PAAJobRecordWOF = service.Retrieve(WorkOnFloorEntityAttributeName.EntityLogicalName, WorkonfloorguidonPAA, columnsfloor);
                                string WOFLocationinitialguid = PAAJobRecordWOF.GetAttributeValue<string>(WorkOnFloorEntityAttributeName.initialguid);
                                Guid fnGuid1 = service.Create(temp1);
                                UpdateSPSDSOW.Attributes.Remove(ScopeOfWorkonFloorEntityAttribute.GoToSPSD);//Remvoe PAA Lookup
                                UpdateSPSDSOW.Attributes.Remove(ScopeOfWorkonFloorEntityAttribute.Workonfloorlookup);
                                UpdateSPSDSOW.Id = fnGuid1;
                                service.Update(UpdateSPSDSOW);
                                UpdateSPSDSOW.Attributes.Add(ScopeOfWorkonFloorEntityAttribute.GoToSPSD, new EntityReference(SPSDScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup
                                UpdateSPSDSOW.Attributes.Add(ScopeOfWorkonFloorEntityAttribute.Workonfloorlookup, new EntityReference(WorkOnFloorEntityAttributeName.EntityLogicalName, new Guid(WOFLocationinitialguid)));

                                crmTrace.AppendLine("Update theUpdateSPSDSOW " + PAAscopeofworkonfloors[k].Id.ToString());
                                //UpdateSPSDSOW.Id = fnGuid1;
                                service.Update(UpdateSPSDSOW);
                                // UpdateParent.Attributes.Add(JobFilingEntityAttributeName.STScopeofworkLookup, new EntityReference(STScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup
                            }

                        }

                    }


                }


                #endregion
                #region SOWForCommon Work Types

                EntityCollection PAASOWCommonWorkTypeScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, SOWCommonWorkTypesEntityAttribute.EntityLogicalName, SOWCommonWorkTypesEntityAttribute.GoToJobFiling);
                crmTrace.AppendLine("PAASOWCommonWorkTypeScopeofWork Count: " + PAASOWCommonWorkTypeScopeofWork.Entities.Count);
                if (PAASOWCommonWorkTypeScopeofWork.Entities.Count > 0)
                {
                    //EntityCollection AdjustedPAASTScopeofWork = new EntityCollection();
                    for (int j = 0; j < PAASOWCommonWorkTypeScopeofWork.Entities.Count; j++)
                    {
                        Entity SOWCommomWorkTypePAAScopeofWorkRecord = (Entity)PAASOWCommonWorkTypeScopeofWork.Entities[j];
                        Entity temp = CreateScopeofWorklist(service, SOWCommomWorkTypePAAScopeofWorkRecord, ParentJobGuid, crmTrace);//have to modify this method.
                        Guid fnGuid = service.Create(temp);
                        // UpdateParent.Attributes.Add(JobFilingEntityAttributeName.STScopeofworkLookup, new EntityReference(STScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup

                        //Create scopeofworkonfloors
                        ConditionExpression condition1 = CreateConditionExpression(SPSDCommonWorkOnFloorEntityAttribute.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        ConditionExpression condition2 = CreateConditionExpression(SPSDCommonWorkOnFloorEntityAttribute.GOTOSPSD, ConditionOperator.Equal, new string[] { SOWCommomWorkTypePAAScopeofWorkRecord.Id.ToString() });
                        crmTrace.AppendLine("Conditojn query id: " + targetEntity.Id.ToString() + "22" + SOWCommomWorkTypePAAScopeofWorkRecord.Id.ToString());
                        EntityCollection PAASPSDscopeofworkonfloors = RetrieveMultiple(service, SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName, null, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.And);


                        //EntityCollection PAASPSDscopeofworkonfloors = RetrieveRelatedEntities(service, targetEntity.Id, SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName, SPSDCommonWorkOnFloorEntityAttribute.GoToJobFiling);
                        crmTrace.AppendLine("PAASPSDscopeofworkonfloors Count: " + PAASPSDscopeofworkonfloors.Entities.Count);
                        Entity UpdateSPSDSOWFloor = new Entity(SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName);
                        crmTrace.AppendLine("Update the Parent ScopeOfWork on floor");


                        if (PAASPSDscopeofworkonfloors.Entities.Count > 0)
                        {
                            for (int k = 0; k < PAASPSDscopeofworkonfloors.Entities.Count; k++)
                            {
                                Entity SPSDSCopeOfWorkOnFloorRecord = (Entity)PAASPSDscopeofworkonfloors.Entities[k];
                                Entity temp1 = CreateScopeofWorklist(service, SPSDSCopeOfWorkOnFloorRecord, ParentJobGuid, crmTrace);//have to modify this method.
                                Guid fnGuid1 = service.Create(temp1);
                                UpdateSPSDSOWFloor.Attributes.Remove(SPSDCommonWorkOnFloorEntityAttribute.GOTOSPSD);//Remove PAA Lookup
                                UpdateSPSDSOWFloor.Id = fnGuid1;
                                service.Update(UpdateSPSDSOWFloor);
                                UpdateSPSDSOWFloor.Attributes.Add(SPSDCommonWorkOnFloorEntityAttribute.GOTOSPSD, new EntityReference(SOWCommonWorkTypesEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup
                                //UpdateSPSDSOWFloor.Id = fnGuid1;
                                service.Update(UpdateSPSDSOWFloor);
                                // UpdateParent.Attributes.Add(JobFilingEntityAttributeName.STScopeofworkLookup, new EntityReference(STScopeOfWorkEntityAttribute.EntityLogicalName, fnGuid));//Replacing Parent FN Lookup
                            }

                        }

                    }


                }


                #endregion



                #region Place Of Assembly Information
                if (currentPAARecord.Contains(JobFilingEntityAttributeName.PACheckBox) && currentPAARecord[JobFilingEntityAttributeName.PACheckBox] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == true)
                {

                    Entity ParentJobFiling = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                    ParentJobFiling.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder] = currentPAARecord.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.OwnerLeaseHolder);
                    ParentJobFiling.Attributes[JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization] = currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.Isthedeedholderanonprofitorganization);
                    ParentJobFiling.Attributes[JobFilingEntityAttributeName.OwnerTypePW1Statement] = new OptionSetValue(currentPAARecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value);
                    ParentJobFiling.Id = ParentJobGuid;
                    service.Update(ParentJobFiling);

                    bool PrimaryPlan = true;//Place Of Assembly Approval
                    #region Retriving the Place of Assembly Information
                    EntityCollection PlaceofAssemblySpaceInfoPAA = RetrieveRelatedEntities(service, targetEntity.Id, PlaceofAssemblySpaceInformation.EntityLogicalName, PlaceofAssemblySpaceInformation.jobFilingID);
                    crmTrace.AppendLine("PlaceofAssemblySpaceInformation Count: " + PlaceofAssemblySpaceInfoPAA.Entities.Count);
                    #endregion

                    if (PlaceofAssemblySpaceInfoPAA != null && PlaceofAssemblySpaceInfoPAA.Entities.Count > 0)
                    {

                        Entity PAA_PASinformation = (Entity)PlaceofAssemblySpaceInfoPAA.Entities[0];
                        PrimaryPlan = PAA_PASinformation.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                        crmTrace.AppendLine("Place of assembly space information Intend To update Primary Plans --- " + PrimaryPlan);

                        #region Parent PACO  priorPAnoIfApplicable
                        crmTrace.AppendLine("Start: Parent PACO  priorPAnoIfApplicable Update Completed: ");
                        Entity parentPACORec = new Entity(PlaceofAssemblySpaceInformation.EntityLogicalName);
                        parentPACORec.Id = ParentJobRecord.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp).Id;
                        parentPACORec.Attributes[PlaceofAssemblySpaceInformation.priorPAnoIfApplicable] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.priorPAnoIfApplicable);
                        service.Update(parentPACORec);
                        crmTrace.AppendLine("End: Parent PACO Update priorPAnoIfApplicable Completed: ");
                        #endregion

                        if (PrimaryPlan == true)
                        {
                            #region retreive initial filing place of assembly record where status is not PAA Approved Loop and update the all with PA approved status
                            string[] ColumnNames_PA = new string[] { PlaceofAssemblySpaceInformation.PACOreportStatus };
                            ConditionExpression PACondition1 = CreateConditionExpression(PlaceofAssemblySpaceInformation.jobFilingID, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                            ConditionExpression PACondition2 = CreateConditionExpression(PlaceofAssemblySpaceInformation.PACOreportStatus, ConditionOperator.Equal, new object[] { PACOReportStatus.PACOIssued });
                            EntityCollection PAResponse = RetrieveMultiple(service, PlaceofAssemblySpaceInformation.EntityLogicalName, ColumnNames_PA, new ConditionExpression[] { PACondition1, PACondition2 }, LogicalOperator.And);
                            crmTrace.AppendLine("place of assembly Space Information PAResponse count: " + PAResponse.Entities.Count);
                            if (PAResponse != null && PAResponse.Entities.Count > 0)
                            {
                                foreach (Entity PASpaceInformation in PAResponse.Entities)
                                {
                                    #region Update the PACO StatusPlace Of Assembly Space Information
                                    crmTrace.AppendLine("Start : Update Place Of Assembly Space Information Started! ");

                                    PASpaceInformation.Attributes[PlaceofAssemblySpaceInformation.PACOreportStatus] = new OptionSetValue((int)PACOReportStatus.PAAApproved);
                                    service.Update(PASpaceInformation);
                                    crmTrace.AppendLine("End : Update Place Of Assembly Space Information End! ");
                                    #endregion Update Place Of Assembly Space Information                                                   
                                }
                            }
                            #endregion


                            #region Clone the Place Of Assembly Information
                            Entity temp = CreatePlaceOfAssemblyInformation(service, PAA_PASinformation, ParentJobGuid, crmTrace);
                            Guid PoARecord = service.Create(temp);
                            #endregion
                            #region Update the Parent Job Status
                            int currentFilingStatus = ((OptionSetValue)targetEntity.Attributes[JobFilingEntityAttributeName.FilingStatus]).Value;
                            Entity ParentJF = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                            ParentJF.Attributes[JobFilingEntityAttributeName.PlaceOfAssemblyLookUp] = new EntityReference(PlaceofAssemblySpaceInformation.EntityLogicalName, PoARecord);
                            ParentJF.Attributes[JobFilingEntityAttributeName.LatestPAApprovedDate] = DateTime.UtcNow;
                            ParentJF.Attributes[JobFilingEntityAttributeName.CurrentFilingStatusAttributeName] = new OptionSetValue((int)CurrentFilingStatus.PAAApproved);
                            ParentJF.Attributes[JobFilingEntityAttributeName.islocinitiated] = false;
                            ParentJF.Id = ParentJobGuid;
                            service.Update(ParentJF);
                            #endregion
                            #region Retrieve all associated Place of Assembly Plans
                            QueryByAttribute query = new QueryByAttribute(PlaceofAssemblyPlans.EntityLogicalName);
                            query.AddAttributeValue(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup, PAA_PASinformation.Id);
                            query.ColumnSet = new ColumnSet(true);
                            EntityCollection placeofassemblyplansRequests = service.RetrieveMultiple(query);
                            crmTrace.AppendLine("placeofassemblyplansRequests Count: " + placeofassemblyplansRequests.Entities.Count);
                            if (placeofassemblyplansRequests != null && placeofassemblyplansRequests.Entities.Count > 0)
                            {
                                foreach (Entity ent in placeofassemblyplansRequests.Entities)
                                {
                                    Entity PoAPlantemp = CreatePlaceOfAssemblyPlans(service, ent, PoARecord, crmTrace);
                                    Guid PlaceOfAssemblyRecord = service.Create(PoAPlantemp);
                                }
                            }
                            #endregion

                        }
                        else if (PrimaryPlan == false)
                        {
                            #region retreive initial filing place of assembly records
                            crmTrace.AppendLine("Start: Parent PACO Update Completed: ");
                            Entity parentPACO = new Entity(PlaceofAssemblySpaceInformation.EntityLogicalName);
                            parentPACO.Id = ParentJobRecord.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp).Id;
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.nameOfPAestablishment] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.nameOfPAestablishment);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.isTheJobnoprebis] = PAA_PASinformation.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.isTheJobnoprebis);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.Prebisprovidebin] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.Prebisprovidebin);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.nba1JobnoEstablishingpa] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.nba1JobnoEstablishingpa);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.fdnyopenflamepermitrequired] = PAA_PASinformation.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.fdnyopenflamepermitrequired);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.typeofopenflameused] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.typeofopenflameused);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.otherTypeofFlameUsed] = PAA_PASinformation.GetAttributeValue<string>(PlaceofAssemblySpaceInformation.otherTypeofFlameUsed);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner] = PAA_PASinformation.GetAttributeValue<EntityReference>(PlaceofAssemblySpaceInformation.partyToRenewThePACOifnotowner);
                            parentPACO.Attributes[PlaceofAssemblySpaceInformation.partyToRenewPACO] = new OptionSetValue(PAA_PASinformation.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.partyToRenewPACO).Value);
                            service.Update(parentPACO);
                            crmTrace.AppendLine("End: Parent PACO Update Completed: ");
                            #endregion
                        }
                    }


                }
                #endregion
                #endregion

                #region Temporary Place Of Assembly Information
                if (currentPAARecord.Contains(JobFilingEntityAttributeName.TPACheckBox) && currentPAARecord[JobFilingEntityAttributeName.TPACheckBox] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == true)
                {
                    EntityCollection TPAInfoPAA = RetrieveRelatedEntities(service, targetEntity.Id, TempororayPlaceOfAssembly.EntityLogicalName, TempororayPlaceOfAssembly.jobfilingLookup);
                    crmTrace.AppendLine("TemporaryofAssemblySpaceInformation Count: " + TPAInfoPAA.Entities.Count);
                    if (TPAInfoPAA != null && TPAInfoPAA.Entities.Count > 0)
                    {
                        Entity PAA_TPAinfo = (Entity)TPAInfoPAA.Entities[0];
                        Entity temp = CreateTemporaryPlaceOfAssemblyInformation(service, PAA_TPAinfo, ParentJobGuid, crmTrace);
                        Guid TPARecord = service.Create(temp);

                        Entity ParentJF = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                        ParentJF.Attributes[JobFilingEntityAttributeName.TemporaryPlaceOfAssemblyLookUp] = new EntityReference(TempororayPlaceOfAssembly.EntityLogicalName, TPARecord);
                        ParentJF.Id = ParentJobGuid;
                        service.Update(ParentJF);


                        /// Get the realted to Temporary Place of AssemblySpaceInfoPAA

                        #region Retrieve all associated Event Dates
                        QueryByAttribute query = new QueryByAttribute(TPAEventDates.EntityLogicalName);
                        query.AddAttributeValue(TPAEventDates.TPALookup, PAA_TPAinfo.Id);
                        query.ColumnSet = new ColumnSet(true);
                        EntityCollection TPAEventDatesRequests = service.RetrieveMultiple(query);
                        crmTrace.AppendLine("TPAEventDates Count: " + TPAEventDatesRequests.Entities.Count);
                        if (TPAEventDatesRequests != null && TPAEventDatesRequests.Entities.Count > 0)
                        {
                            foreach (Entity ent in TPAEventDatesRequests.Entities)
                            {
                                Entity PoAPlantemp = CreateTPAEventDates(service, ent, TPARecord, crmTrace);
                                Guid TPAInfoRecord = service.Create(PoAPlantemp);

                            }

                        }
                        #endregion

                    }

                }

                #endregion
                #region Signs Sub grid
                ///1) Retrieve PAA Signs with is final no
                ///2)Delete I1 Signs with is Final No
                ///3)Check I1 is permit Entire if yes then delete Signs Is Final Yes signs
                ///4)Clone PAA Signs to I1 if permit entire is yes then also create final Signs as well.
                ///
                if ((currentPAARecord.Contains(JobFilingEntityAttributeName.Sign) && currentPAARecord[JobFilingEntityAttributeName.Sign] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign) == true) || feeObject.IsSG)
                {
                    crmTrace.AppendLine("Get All Signs which has is final No in P1");
                    EntityCollection SignsPAACollection = assocaitedSignsFullDetails(service, currentPAARecord, crmTrace);
                    crmTrace.AppendLine("SignsPAACollection Records" + SignsPAACollection.Entities.Count);
                    crmTrace.AppendLine("Get All Signs which has is final No in I1");
                    EntityCollection SignsI1Collection = assocaitedSigns(service, ParentJobRecord, crmTrace);
                    crmTrace.AppendLine("SignsI1Collection Records" + SignsI1Collection.Entities.Count);
                    crmTrace.AppendLine("Check I1 Filing Status");
                    crmTrace.AppendLine("Delete All Signs on I1 including isfinal yes signs as well-Start");
                    if (SignsI1Collection != null && SignsI1Collection.Entities.Count > 0)
                    {
                        foreach (Entity Sign in SignsI1Collection.Entities)
                        {
                            crmTrace.AppendLine("Delete old Sign -start");
                            service.Delete(SignCharactersticsAttributeName.EntityLogicalName, Sign.Id);
                            crmTrace.AppendLine("Delete old Sign - end");
                        }
                    }
                    crmTrace.AppendLine("Delete All Signs on I1 including isfinal yes signs as well-End");
                    if (SignsPAACollection != null && SignsPAACollection.Entities.Count > 0)
                    {
                        CreateSignsOnI1(SignsPAACollection, service, ParentJobRecord, crmTrace, false);
                    }
                    //Start Appending Signs to I1


                    if (ParentJobRecord.Contains(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName) && ParentJobRecord[JobFilingEntityAttributeName.CurrentFilingStatusAttributeName] != null && ParentJobRecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PermitEntire)
                    {
                        CreateSignsOnI1(SignsPAACollection, service, ParentJobRecord, crmTrace, true);
                    }



                }


                crmTrace.AppendLine("Retrieving all the Related Entities records of PAA and Creating in ParentJob - End  ");
                #endregion

                if (((currentPAARecord.Contains(JobFilingEntityAttributeName.ConstructionFence) && currentPAARecord[JobFilingEntityAttributeName.ConstructionFence] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) == true) || feeObject.IsFN) ||
                     ((currentPAARecord.Contains(JobFilingEntityAttributeName.SidewalkShed) && currentPAARecord[JobFilingEntityAttributeName.SidewalkShed] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) == true) || feeObject.IsSH) ||
                     ((currentPAARecord.Contains(JobFilingEntityAttributeName.SupportedScaffold) && currentPAARecord[JobFilingEntityAttributeName.SupportedScaffold] != null && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) == true) || feeObject.IsSF)
                     || feeObject.IsST
                     )
                {
                    crmTrace.AppendLine("Update the Parent Job filing");
                    UpdateParent.Id = ParentJobRecord.Id;
                    service.Update(UpdateParent);
                }
                //if ((currentPAARecord.Contains(JobFilingEntityAttributeName.workTypesTextbox) && currentPAARecord[JobFilingEntityAttributeName.workTypesTextbox] != null && currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox) == "FN") ||
                //    (currentPAARecord.Contains(JobFilingEntityAttributeName.workTypesTextbox) && currentPAARecord[JobFilingEntityAttributeName.workTypesTextbox] != null && currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox) == "SH") ||
                //    (currentPAARecord.Contains(JobFilingEntityAttributeName.workTypesTextbox) && currentPAARecord[JobFilingEntityAttributeName.workTypesTextbox] != null && currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox) == "SF") ||
                //    (currentPAARecord.Contains(JobFilingEntityAttributeName.workTypesTextbox) && currentPAARecord[JobFilingEntityAttributeName.workTypesTextbox] != null && currentPAARecord.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox) == "ST"))
                //{
                //    crmTrace.AppendLine("Update the Parent Job filing");
                //    UpdateParent.Id = ParentJobRecord.Id;
                //    service.Update(UpdateParent);
                //}
                #region Update Plans/Sketch document on Initial Filing
                //EntityCollection planDocs = DocumentItemUploadHandler.RetrievePlansDocument_JobFiling(service, targetEntity.Id, crmTrace);
                //if(planDocs != null && planDocs.Entities.Count > 0)
                //{
                //    Entity doc = planDocs.Entities[0];
                //        string doc_URL = (doc.Contains(DocumentListEntityAttributeName.DocumentURL) && doc.Attributes[DocumentListEntityAttributeName.DocumentURL] != null) ? doc.GetAttributeValue<string>(DocumentListEntityAttributeName.DocumentURL) : string.Empty;
                //        crmTrace.AppendLine("doc_URL:  " + doc_URL);
                //    if (doc_URL != string.Empty)
                //    {
                //        EntityCollection parent_planDocs = DocumentItemUploadHandler.RetrievePlansDocument_JobFiling(service, ParentJobRecord.Id, crmTrace);
                //        if (parent_planDocs != null && parent_planDocs.Entities.Count > 0)
                //        {
                //            Entity parent_doc = parent_planDocs.Entities[0];
                //            parent_doc.Attributes[DocumentListEntityAttributeName.DocumentURL] = doc_URL;
                //            parent_doc.Attributes[DocumentListEntityAttributeName.UploadedDate] = doc.GetAttributeValue<DateTime>(DocumentListEntityAttributeName.UploadedDate);
                //           service.Update(parent_doc);
                //        }
                //    }

                //}
                #endregion

                #region Added 08/20/2018 PA PAA delete initial documents if no intend to change requirements
                bool isPA_CreateallFromPAA = false;
                bool isPAWorkType = false;
                if (currentPAARecord.Contains(JobFilingEntityAttributeName.FilingType) && currentPAARecord.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA &&
                   currentPAARecord.Contains(JobFilingEntityAttributeName.PACheckBox) && currentPAARecord.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))
                {
                    isPAWorkType = true;
                    crmTrace.AppendLine("Start 08/16/2018 PA PAA Do not populate documents if no intend to change requirements");
                    crmTrace.AppendLine("filingType: " + "PAA");
                    if (currentPAARecord.Contains(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp))
                    {
                        ColumnSet columnsPACO = new ColumnSet(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                        Entity placeofAssembly = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, currentPAARecord.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp).Id, columnsPACO);
                        crmTrace.AppendLine("placeofAssembly: " + placeofAssembly.ToString());
                        if (placeofAssembly.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans))
                        {
                            EntityCollection initial_Documents = DocumentItemUploadHandler.RetrieveParentDocuments_PAJobFiling(service, ParentJobGuid, crmTrace);
                            if (initial_Documents != null && initial_Documents.Entities.Count > 0)
                            {
                                crmTrace.AppendLine("initial_Documents.Entities.Count: " + initial_Documents.Entities.Count);
                                foreach (Entity doc in initial_Documents.Entities)
                                    service.Delete(DocumentListEntityAttributeName.EntityLogicalName, doc.Id);
                            }
                            isPA_CreateallFromPAA = true;
                        }
                    }

                }
                #endregion

                
                UpdateParentJob(service, currentPAARecord, crmTrace, ParentJobGuid);

                #region PAA SD3.3 nee changed 01/09/2018
                crmTrace.AppendLine("Retereive all documents on PAA");
                EntityCollection pAA_Documents = DocumentItemUploadHandler.RetrieveParentDocuments_JobFiling(service, targetEntity.Id, crmTrace);
                if (pAA_Documents != null && pAA_Documents.Entities.Count > 0)
                {
                    crmTrace.AppendLine("pAA_Documents.Entities.Count: " + pAA_Documents.Entities.Count);
                    foreach (Entity doc in pAA_Documents.Entities)
                    {
                        Guid documentTypeGuid = doc.GetAttributeValue<EntityReference>(DocumentListEntityAttributeName.DocumentName).Id;
                        crmTrace.AppendLine("documentTypeGuid: " + documentTypeGuid.ToString());
                        crmTrace.AppendLine("documentTypeName: " + doc.GetAttributeValue<EntityReference>(DocumentListEntityAttributeName.DocumentName).Name);
                        var response_tuple = DocumentItemUploadHandler.CheckParentDocumentinParentJob(service, ParentJobGuid, documentTypeGuid, crmTrace);
                        if (response_tuple.Item1 == true)
                        {
                            if (!isPAWorkType)
                            {
                                Entity documentListRecord_Parent = response_tuple.Item2;
                                #region Commented out 01/17/2018
                                //crmTrace.AppendLine("Clone PAA Document which exists in Parent JF ");
                                //Entity cloneDoc = new Entity();
                                //cloneDoc = EntityExtensions.Clone(doc, false);
                                //cloneDoc.Attributes.Remove(DocumentListEntityAttributeName.DocumentListtoJobfiling);
                                //cloneDoc.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                                //cloneDoc.Id = Guid.NewGuid();
                                //cloneDoc.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                                //Guid cloneDocId = service.Create(cloneDoc);
                                //crmTrace.AppendLine("Done creating Clone PAA Document which exists in Parent JF :" + cloneDocId.ToString());
                                //crmTrace.AppendLine("Start - Update the old inital filing document with ParentDocument attribute");
                                //documentListRecord_Parent.Attributes[DocumentListEntityAttributeName.ParentDocumentList] = new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, cloneDocId);
                                //service.Update(documentListRecord_Parent);
                                //crmTrace.AppendLine("Done - Update the old inital filing document with ParentDocument attribute");
                                #endregion

                                #region New Changes 01/17/2018
                                crmTrace.AppendLine("Start - Clone PAA Document which exists in Parent JF, update Intial filing document with all attributes");
                                Entity cloneDoc_PAA = new Entity();
                                cloneDoc_PAA = EntityExtensions.Clone(doc, false);
                                cloneDoc_PAA.Attributes.Remove(DocumentListEntityAttributeName.DocumentListtoJobfiling);
                                cloneDoc_PAA.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                                cloneDoc_PAA.Id = documentListRecord_Parent.Id;
                                service.Update(cloneDoc_PAA);
                                crmTrace.AppendLine("Done - Clone PAA Document which exists in Parent JF, update Intial filing document with all attributes");
                                #endregion

                                #region New Changes 01/17/2018
                                crmTrace.AppendLine("Clone PAA Document which exists in Parent JF ");
                                Entity cloneDoc = new Entity();
                                cloneDoc = EntityExtensions.Clone(documentListRecord_Parent, false);
                                cloneDoc.Id = Guid.NewGuid();
                                cloneDoc.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                                cloneDoc.Attributes[DocumentListEntityAttributeName.ParentDocumentList] = new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, documentListRecord_Parent.Id);
                                Guid cloneDocId = service.Create(cloneDoc);
                                crmTrace.AppendLine("Done creating Clone PAA Document which exists in Parent JF :" + cloneDocId.ToString());

                                #endregion
                            }

                        }
                        else
                        {
                            #region Create document in intial filing if Document Cataogry is Plan
                            if (doc.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentCategory).Value == 1 || isPA_CreateallFromPAA)
                            {
                                Entity cloneDoc_PAA = new Entity();
                                cloneDoc_PAA = EntityExtensions.Clone(doc, false);
                                crmTrace.AppendLine(" Start : --Create document in intial filing if Document Cataogry is Plan/isPA_CreateallFromPAA ");
                                cloneDoc_PAA.Attributes.Remove(DocumentListEntityAttributeName.DocumentListtoJobfiling);
                                cloneDoc_PAA.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                                cloneDoc_PAA.Attributes[DocumentListEntityAttributeName.DocumentListtoJobfiling] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid);
                                cloneDoc_PAA.Id = Guid.NewGuid();
                                service.Create(cloneDoc_PAA);
                                crmTrace.AppendLine(" End : --Create document in intial filing if Document Cataogry is Plan/isPA_CreateallFromPAA ");
                            }
                            #endregion
                        }
                    }
                }
                #endregion

                crmTrace.AppendLine("End PAAPostApproval process! ");


                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - Success Trace", null, crmTrace.ToString(), null, null);
                //DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", "PAA Merge Test", LogLevelL4N.FATAL, null, "\nTimeStamp: " + crmTrace);
                //throw new Exception("Aqib PAA testing");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - PAAPostApproval", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }



        /// <summary>
        /// Used to Create Signs On I1 When PAA is Approved.
        /// </summary>
        /// <param name="SignsResponse"></param>
        /// <param name="service"></param>
        /// <param name="ParentJobFiling"></param>
        /// <param name="crmTrace"></param>
        /// <param name="Identifier">Identifier is used to differentiate NOrmal Signs and LOC Signs Creation</param>
        public static void CreateSignsOnI1(EntityCollection SignsResponse, IOrganizationService service, Entity ParentJobFiling, StringBuilder crmTrace, bool Identifier)
        {
            try
            {


                crmTrace.AppendLine("Total Signs Count: " + SignsResponse.Entities.Count);
                if (SignsResponse != null && SignsResponse.Entities.Count > 0)
                {

                    crmTrace.AppendLine("Clone Signs Start ");
                    foreach (Entity Sign in SignsResponse.Entities)
                    {
                        Entity clonedSign = new Entity(SignCharactersticsAttributeName.EntityLogicalName);
                        if (Sign.Contains(SignCharactersticsAttributeName.signPurpose) && Sign[SignCharactersticsAttributeName.signPurpose] != null)
                        {
                            crmTrace.AppendLine("Set Purpose");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.signPurpose, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.signPurpose));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.isThisProjectingSign) && Sign[SignCharactersticsAttributeName.isThisProjectingSign] != null)
                        {
                            crmTrace.AppendLine("Set isThisProjectingSign");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.isThisProjectingSign, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.isThisProjectingSign));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightFlag] != null)
                        {
                            crmTrace.AppendLine("Set IsRoofSignTightSolidFlag");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.IsRoofSignTightFlag, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IsRoofSignTightFlag));
                        }
                        // if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightSolidFlag) && Sign[SignCharactersticsAttributeName.IsRoofSignTightSolidFlag] != null)
                        if (Identifier == true)
                        {
                            crmTrace.AppendLine("Set isSignFinal");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.IsSignFinal, true);//for Loc Signs it is true
                        }
                        else
                        {
                            crmTrace.AppendLine("Set isSignFinal");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.IsSignFinal, false);//for Loc Signs it is true
                        }

                        if (Sign.Contains(SignCharactersticsAttributeName.HeightAboveTheCurb) && Sign[SignCharactersticsAttributeName.HeightAboveTheCurb] != null)
                        {
                            crmTrace.AppendLine("Set HeightAboveTheCurb");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.HeightAboveTheCurb, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAboveTheCurb));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.SignProjectsByFt) && Sign[SignCharactersticsAttributeName.SignProjectsByFt] != null)
                        {
                            crmTrace.AppendLine("Set SignProjectsByFt");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignProjectsByFt, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.SignProjectsByFt));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignProjectsByIn) && Sign[SignCharactersticsAttributeName.SignProjectsByIn] != null)
                        {
                            crmTrace.AppendLine("Set SignProjectsByIn");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignProjectsByIn, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.SignProjectsByIn));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.HeightAboveTheRoof) && Sign[SignCharactersticsAttributeName.HeightAboveTheRoof] != null)
                        {
                            crmTrace.AppendLine("Set HeightAboveTheRoof");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.HeightAboveTheRoof, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.HeightAboveTheRoof));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.IsRoofSignTightClosedSolid) && Sign[SignCharactersticsAttributeName.IsRoofSignTightClosedSolid] != null)
                        {
                            crmTrace.AppendLine("Set IsRoofSignTightClosedSolid");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.IsRoofSignTightClosedSolid, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.IsRoofSignTightClosedSolid));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignType) && Sign[SignCharactersticsAttributeName.SignType] != null)
                        {
                            crmTrace.AppendLine("Set SignType");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignType, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.SignType));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.TypeOfIllumination) && Sign[SignCharactersticsAttributeName.TypeOfIllumination] != null)
                        {
                            crmTrace.AppendLine("Set TypeofIllumination");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.TypeOfIllumination, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.TypeOfIllumination));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.MaterialOfTheSign) && Sign[SignCharactersticsAttributeName.MaterialOfTheSign] != null)
                        {
                            crmTrace.AppendLine("Set MaterialOfTheSign");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.MaterialOfTheSign, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.MaterialOfTheSign));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignLocation) && Sign[SignCharactersticsAttributeName.SignLocation] != null)
                        {
                            crmTrace.AppendLine("Set SignLocation");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignLocation, Sign.GetAttributeValue<OptionSetValue>(SignCharactersticsAttributeName.SignLocation));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.EstimatedJobCost) && Sign[SignCharactersticsAttributeName.EstimatedJobCost] != null)
                        {
                            crmTrace.AppendLine("Set EstimatedJobCost");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.EstimatedJobCost, Sign.GetAttributeValue<Money>(SignCharactersticsAttributeName.EstimatedJobCost));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSquareFeet) && Sign[SignCharactersticsAttributeName.TotalSquareFeet] != null)
                        {
                            crmTrace.AppendLine("Set TotalSquareFeet");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.TotalSquareFeet, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSquareFeet));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet) && Sign[SignCharactersticsAttributeName.TotalZoningLotFrontageFeet] != null)
                        {
                            crmTrace.AppendLine("Set TotalZoningLotFrontageFeet");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalZoningLotFrontageFeet));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.Weightlbs) && Sign[SignCharactersticsAttributeName.Weightlbs] != null)
                        {
                            crmTrace.AppendLine("Set Weightlbs");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.Weightlbs, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.Weightlbs));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning) && Sign[SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning] != null)
                        {
                            crmTrace.AppendLine("Set TotalSurfaceAreaofallSignsinZoning");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft) && Sign[SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft] != null)
                        {
                            crmTrace.AppendLine("Set TotalSurfaceAreaOfThisSign");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon) && Sign[SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon] != null)
                        {
                            crmTrace.AppendLine("Set MaximumAllowableSurfaceAreaonZon");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.IgnDesignedforChangeableCopy) && Sign[SignCharactersticsAttributeName.IgnDesignedforChangeableCopy] != null)
                        {
                            crmTrace.AppendLine("Set IgnDesignedforChangeableCopy");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.IgnDesignedforChangeableCopy, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.IgnDesignedforChangeableCopy));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign) && Sign[SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign] != null)
                        {
                            crmTrace.AppendLine("Set DoesAnoaChaveanInterestinThisSign");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.OacRegistrationNumber) && Sign[SignCharactersticsAttributeName.OacRegistrationNumber] != null)
                        {
                            crmTrace.AppendLine("Set OacRegistrationNumber");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.OacRegistrationNumber, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.OacRegistrationNumber));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignWording) && Sign[SignCharactersticsAttributeName.SignWording] != null)
                        {
                            crmTrace.AppendLine("Set SignWording");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignWording, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.SignWording));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignRegistrationNumber) && Sign[SignCharactersticsAttributeName.SignRegistrationNumber] != null)
                        {
                            crmTrace.AppendLine("Set SignRegistrationNumber");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignRegistrationNumber, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.SignRegistrationNumber));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.WithInviewofAnarterialHighway) && Sign[SignCharactersticsAttributeName.WithInviewofAnarterialHighway] != null)
                        {
                            crmTrace.AppendLine("Set WithInviewofAnarterialHighway");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.WithInviewofAnarterialHighway, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.WithInviewofAnarterialHighway));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.GistrationNumberHighway) && Sign[SignCharactersticsAttributeName.GistrationNumberHighway] != null)
                        {
                            crmTrace.AppendLine("Set GistrationNumberHighway");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.GistrationNumberHighway, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.GistrationNumberHighway));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.Within200AndWithinViewPark) && Sign[SignCharactersticsAttributeName.Within200AndWithinViewPark] != null)
                        {
                            crmTrace.AppendLine("Set Within200AndWithinViewPark");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.Within200AndWithinViewPark, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.Within200AndWithinViewPark));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore) && Sign[SignCharactersticsAttributeName.DistanceFromPark12AcreorMore] != null)
                        {
                            crmTrace.AppendLine("Set DistanceFromPark12AcreorMore");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.DistanceFromPark12AcreorMore));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.Landmarkfee) && Sign[SignCharactersticsAttributeName.Landmarkfee] != null)
                        {
                            crmTrace.AppendLine("Set landMarkfee");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.Landmarkfee, Sign.GetAttributeValue<decimal>(SignCharactersticsAttributeName.Landmarkfee));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.ParkSignRegistrationNumber) && Sign[SignCharactersticsAttributeName.ParkSignRegistrationNumber] != null)
                        {
                            crmTrace.AppendLine("Set ParkSignRegistrationNumber");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.ParkSignRegistrationNumber, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.ParkSignRegistrationNumber));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.ContactName) && Sign[SignCharactersticsAttributeName.ContactName] != null)
                        {
                            crmTrace.AppendLine("Set ContactName");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.ContactName, Sign.GetAttributeValue<EntityReference>(SignCharactersticsAttributeName.ContactName));
                        }
                        //  if (Sign.Contains(SignCharactersticsAttributeName.GotoJobFiling) && Sign[SignCharactersticsAttributeName.GotoJobFiling] != null)
                        {
                            crmTrace.AppendLine("Set GotoJobFiling");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobFiling.Id));
                        }
                        //
                        if (Sign.Contains(SignCharactersticsAttributeName.RelationshiptoOwner) && Sign[SignCharactersticsAttributeName.RelationshiptoOwner] != null)
                        {
                            crmTrace.AppendLine("Set RelationshiptoOwner");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.RelationshiptoOwner, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.RelationshiptoOwner));
                        }

                        if (Sign.Contains(SignCharactersticsAttributeName.SignatteStation) && Sign[SignCharactersticsAttributeName.SignatteStation] != null)
                        {
                            crmTrace.AppendLine("Set SignatteStation");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignatteStation, Sign.GetAttributeValue<bool>(SignCharactersticsAttributeName.SignatteStation));
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignatureDate) && Sign[SignCharactersticsAttributeName.SignatureDate] != null)
                        {
                            crmTrace.AppendLine("Set SignatureDate");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignatureDate, Sign.GetAttributeValue<DateTime>(SignCharactersticsAttributeName.SignatureDate).Date);
                        }
                        if (Sign.Contains(SignCharactersticsAttributeName.SignaturePersonName) && Sign[SignCharactersticsAttributeName.SignaturePersonName] != null)
                        {
                            crmTrace.AppendLine("Set SignaturePersonName");
                            clonedSign.Attributes.Add(SignCharactersticsAttributeName.SignaturePersonName, Sign.GetAttributeValue<string>(SignCharactersticsAttributeName.SignaturePersonName));
                        }


                        service.Create(clonedSign);


                    }
                    crmTrace.AppendLine("Clone Signs End ");
                }




            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

                // throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("targetEntity.Id.ToString()", "CRM", "PAAHandler - CreateSignsOnI1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw ex;
            }


        }


        /// <summary>
        /// Get All Signs for the Jobfiling Application
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static EntityCollection assocaitedSigns(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            ConditionExpression deviceCondition;
            EntityCollection deviceResponse = new EntityCollection();
            try
            {
                deviceCondition = CreateConditionExpression(SignCharactersticsAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                //  deviceCondition1 = CreateConditionExpression(SignCharactersticsAttributeName.isSignFinal, ConditionOperator.NotEqual, new object[] { true });
                deviceResponse = RetrieveMultiple(service, SignCharactersticsAttributeName.EntityLogicalName, new string[] { SignCharactersticsAttributeName.SignLocation, SignCharactersticsAttributeName.TypeOfIllumination, SignCharactersticsAttributeName.isThisProjectingSign, SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft, SignCharactersticsAttributeName.IsRoofSignTightFlag, SignCharactersticsAttributeName.HeightAboveTheRoof, SignCharactersticsAttributeName.SignType, SignCharactersticsAttributeName.EstimatedJobCost }, new ConditionExpression[] { deviceCondition }, LogicalOperator.And);
                return deviceResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return deviceResponse;
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return deviceResponse;
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return deviceResponse;
                //throw ex;
            }
        }

        /// <summary>
        /// This Method used to get all the signs details which has is final flag no or null
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <returns></returns>
        public static EntityCollection assocaitedSignsFullDetails(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            ConditionExpression deviceCondition, deviceCondition1;
            EntityCollection deviceResponse = new EntityCollection();
            QueryExpression Query = new QueryExpression();
            FilterExpression filter = new FilterExpression();

            try
            {
                deviceCondition = CreateConditionExpression(SignCharactersticsAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                deviceCondition1 = CreateConditionExpression(SignCharactersticsAttributeName.IsSignFinal, ConditionOperator.NotEqual, new object[] { true });
                deviceResponse = RetrieveMultiple(service, SignCharactersticsAttributeName.EntityLogicalName, new string[] { SignCharactersticsAttributeName.SignLocation, SignCharactersticsAttributeName.TypeOfIllumination, SignCharactersticsAttributeName.isThisProjectingSign, SignCharactersticsAttributeName.TotalSurfaceAreaofthisSigninSqft, SignCharactersticsAttributeName.IsRoofSignTightFlag, SignCharactersticsAttributeName.HeightAboveTheRoof, SignCharactersticsAttributeName.SignType, SignCharactersticsAttributeName.EstimatedJobCost, SignCharactersticsAttributeName.signPurpose, SignCharactersticsAttributeName.isThisProjectingSign, SignCharactersticsAttributeName.IsRoofSignTightClosedSolid, SignCharactersticsAttributeName.HeightAboveTheCurb, SignCharactersticsAttributeName.SignProjectsByFt, SignCharactersticsAttributeName.SignProjectsByIn, SignCharactersticsAttributeName.HeightAboveTheRoof, SignCharactersticsAttributeName.IsRoofSignTightClosedSolid, SignCharactersticsAttributeName.TypeOfIllumination, SignCharactersticsAttributeName.MaterialOfTheSign, SignCharactersticsAttributeName.TotalSquareFeet, SignCharactersticsAttributeName.TotalZoningLotFrontageFeet, SignCharactersticsAttributeName.Weightlbs, SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning, SignCharactersticsAttributeName.TotalSurfaceAreaofallSignsinZoning, SignCharactersticsAttributeName.MaximumAllowableSurfaceAreaonZon, SignCharactersticsAttributeName.IgnDesignedforChangeableCopy, SignCharactersticsAttributeName.DoesAnoaChaveanInterestinThisSign, SignCharactersticsAttributeName.OacRegistrationNumber, SignCharactersticsAttributeName.SignWording, SignCharactersticsAttributeName.SignRegistrationNumber, SignCharactersticsAttributeName.WithInviewofAnarterialHighway, SignCharactersticsAttributeName.GistrationNumberHighway, SignCharactersticsAttributeName.Within200AndWithinViewPark, SignCharactersticsAttributeName.DistanceFromPark12AcreorMore, SignCharactersticsAttributeName.Landmarkfee, SignCharactersticsAttributeName.ParkSignRegistrationNumber, SignCharactersticsAttributeName.ContactName, SignCharactersticsAttributeName.RelationshiptoOwner, SignCharactersticsAttributeName.SignatteStation, SignCharactersticsAttributeName.SignatureDate, SignCharactersticsAttributeName.SignaturePersonName }, new ConditionExpression[] { deviceCondition, deviceCondition1 }, LogicalOperator.And);
                return deviceResponse;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return deviceResponse;
                //throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return deviceResponse;
                //throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), "CRM", "PAAHandler - assocaitedSigns", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return deviceResponse;
                //throw ex;
            }
        }
        public static void SupersedingDPPostApproval(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                crmTrace.AppendLine("Start SupersedingDPPostApproval process! ");

                GetJobFilingEntityColumnSet columnsSet = new GetJobFilingEntityColumnSet();
                Entity currentSupersedingDpRecord = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(columnsSet.ColumnNames));
                Guid ParentJobGuid = ((EntityReference)currentSupersedingDpRecord[JobFilingEntityAttributeName.ParentJobFilingAttributeName]).Id;
                crmTrace.AppendLine("ParentJobGuid: " + ParentJobGuid.ToString());

                crmTrace.AppendLine("ParentRecord Attribute count: " + currentSupersedingDpRecord.Attributes.Count);


                #region Inactivating All permits

                crmTrace.AppendLine("Retrieving all the Work permits with of Parent Job Filing and Inactivating them - Started ");
                string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitId, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit };
                ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { ParentJobGuid.ToString() });
                EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition1 }, LogicalOperator.And);
                crmTrace.AppendLine("workPermitResponse count: " + workPermitResponse.Entities.Count);
                if (workPermitResponse != null && workPermitResponse.Entities.Count > 0)
                {
                    foreach (Entity workpermit in workPermitResponse.Entities)
                    {
                        InactiveWorkPermit(service, workpermit, crmTrace);

                    }

                }



                #endregion

                #region Retrieving all the Related Entities records of Parent Job Filing and Deleting them
                crmTrace.AppendLine("Retrieving all the Related Entities records of Parent Job Filing and Deleting them - Started ");

                EntityCollection ParentScopeofWork = RetrieveRelatedEntities(service, ParentJobGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, ScopeOfWorkEntityAttributeName.GoToJobFiling);
                DeleteEntityCollection(service, ParentScopeofWork, crmTrace);
                crmTrace.AppendLine("Retrieved and Deleted all ParentScopeofWork");

                EntityCollection ParentCostDetails = RetrieveRelatedEntities(service, ParentJobGuid, WorkCostDetailsAttributeNames.EntityLogicalName, WorkCostDetailsAttributeNames.GoToJobFiling);
                DeleteEntityCollection(service, ParentCostDetails, crmTrace);
                crmTrace.AppendLine("Retrieved and Deleted all ParentCostDetails");

                EntityCollection ParentSpecialInspectionCategories = RetrieveRelatedEntities(service, ParentJobGuid, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                DeleteEntityCollection(service, ParentSpecialInspectionCategories, crmTrace);
                crmTrace.AppendLine("Retrieved and Deleted all ParentSpecialInspectionCategories ");

                EntityCollection ParentProgressInspectionCategories = RetrieveRelatedEntities(service, ParentJobGuid, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                DeleteEntityCollection(service, ParentProgressInspectionCategories, crmTrace);
                crmTrace.AppendLine("Retrieved and Deleted all ParentProgressInspectionCategories ");

                crmTrace.AppendLine("Retrieving all the Related Entities records of Parent Job Filing and Deleting them - Ended ");
                #endregion

                # region Retrieving all the Related Entities records of Superseding DP and Creating in ParentJob
                crmTrace.AppendLine("Retrieving all the Related Entities records of Superseding DP and Creating in ParentJob - Started ");

                #region ScopeofWork
                EntityCollection PAAScopeofWork = RetrieveRelatedEntities(service, targetEntity.Id, ScopeOfWorkEntityAttributeName.EntityLogicalName, ScopeOfWorkEntityAttributeName.GoToJobFiling);
                EntityCollection AdjustedPAAScopeofWork = new EntityCollection();
                crmTrace.AppendLine("PAAScopeofWork Count: " + PAAScopeofWork.Entities.Count);
                for (int j = 0; j < PAAScopeofWork.Entities.Count; j++)
                {
                    Entity PAAScopeofWorkRecord = (Entity)PAAScopeofWork.Entities[j];
                    Entity temp = CreateScopeofWorklist(service, PAAScopeofWorkRecord, ParentJobGuid, crmTrace);
                    AdjustedPAAScopeofWork.Entities.Add(temp);

                }

                crmTrace.AppendLine("AdjustedPAAScopeofWork Count: " + AdjustedPAAScopeofWork.Entities.Count);
                CreateEntityCollection(service, AdjustedPAAScopeofWork, crmTrace);
                crmTrace.AppendLine("Retrieved and Created all PAAScopeofWork in Parent");
                #endregion

                #region Work Cost Details
                EntityCollection PAAWorkCostDetails = RetrieveRelatedEntities(service, targetEntity.Id, WorkCostDetailsAttributeNames.EntityLogicalName, WorkCostDetailsAttributeNames.GoToJobFiling);
                EntityCollection AdjustedPAAWorkCostDetails = new EntityCollection();
                crmTrace.AppendLine("PAAWorkCostDetails Count: " + PAAWorkCostDetails.Entities.Count);
                for (int j = 0; j < PAAWorkCostDetails.Entities.Count; j++)
                {
                    Entity PAAWorkCostDetailsRecord = (Entity)PAAWorkCostDetails.Entities[j];
                    Entity temp = CreateWorkCostDetailslist(service, PAAWorkCostDetailsRecord, ParentJobGuid, crmTrace);
                    AdjustedPAAWorkCostDetails.Entities.Add(temp);

                }
                CreateEntityCollection(service, AdjustedPAAWorkCostDetails, crmTrace);
                crmTrace.AppendLine("Retrieved and Created all PAAWorkCostDetails in Parent");
                #endregion

                #region Special Inspection Categories
                EntityCollection PAASpecialInspectionCategories = RetrieveRelatedEntities(service, targetEntity.Id, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                EntityCollection AdjustedPAASpecialInspectionCategories = new EntityCollection();
                crmTrace.AppendLine("PAAScopeofWork Count: " + PAAScopeofWork.Entities.Count);
                for (int j = 0; j < PAASpecialInspectionCategories.Entities.Count; j++)
                {
                    Entity PAASpecialInspectionCategoriesRecord = (Entity)PAASpecialInspectionCategories.Entities[j];
                    Entity temp = CreateSpecialInspectionCategorieslist(service, PAASpecialInspectionCategoriesRecord, ParentJobGuid, crmTrace);
                    AdjustedPAASpecialInspectionCategories.Entities.Add(temp);

                }
                CreateEntityCollection(service, AdjustedPAASpecialInspectionCategories, crmTrace);
                crmTrace.AppendLine("Retrieved and Created all PAASpecialInspectionCategories in Parent");
                #endregion

                #region Progress Inspection Categories
                EntityCollection PAAProgressInspectionCategories = RetrieveRelatedEntities(service, targetEntity.Id, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                EntityCollection AdjustedPAAProgressInspectionCategories = new EntityCollection();
                crmTrace.AppendLine("PAAProgressInspectionCategories Count: " + PAAProgressInspectionCategories.Entities.Count);
                for (int j = 0; j < PAAProgressInspectionCategories.Entities.Count; j++)
                {
                    Entity PAAProgressInspectionCategoriesRecord = (Entity)PAAProgressInspectionCategories.Entities[j];
                    Entity temp = CreateProgressInspectionCategorieslist(service, PAAProgressInspectionCategoriesRecord, ParentJobGuid, crmTrace);
                    AdjustedPAAProgressInspectionCategories.Entities.Add(temp);

                }
                CreateEntityCollection(service, AdjustedPAAProgressInspectionCategories, crmTrace);
                crmTrace.AppendLine("Retrieved and Created all PAAProgressInspectionCategories in Parent");
                #endregion

                crmTrace.AppendLine("Retrieving all the Related Entities records of PAA and Creating in ParentJob - End  ");
                #endregion

                UpdateParentJob_Superseded(service, currentSupersedingDpRecord, crmTrace, ParentJobGuid);

                crmTrace.AppendLine("End SupersedingDPPostApproval process! ");

                //throw new Exception("Aqib SupersedingDPPostApproval testing");


            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SupersedingDPPostApproval", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateParentJob(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder crmTrace, Guid ParentJobGuid)
        {
            try
            {
                #region PW1 Section
                crmTrace.AppendLine("UpdateParentJob Started! ");
                Entity parentEntity = new Entity();
                parentEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                parentEntity.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, ParentJobGuid);

                #region Adding Attributes
                crmTrace.AppendLine("Retrieve Owner Type");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement))
                {
                    int OwnerTypePW1Statement = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OwnerTypePW1Statement, new OptionSetValue(OwnerTypePW1Statement));
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OwnerTypePW1Statement, new OptionSetValue(-1));
                }


                crmTrace.AppendLine("Retrieve BuildingsDesign");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingsDesign))
                {
                    bool BuildingsDesign = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.BuildingsDesign);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BuildingsDesign, BuildingsDesign);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BuildingsDesign, null);
                }
                crmTrace.AppendLine("Retrieve Sowrequirethestandpipeservice");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sowrequirethestandpipeservice))
                {
                    bool Sowrequirethestandpipeservice = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sowrequirethestandpipeservice);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Sowrequirethestandpipeservice, Sowrequirethestandpipeservice);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Sowrequirethestandpipeservice, null);
                }
                crmTrace.AppendLine("Retrieve Sowinvolvemorethan5contiguousfloors");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors))
                {
                    bool Sowinvolvemorethan5contiguousfloors = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors, Sowinvolvemorethan5contiguousfloors);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Sowinvolvemorethan5contiguousfloors, null);
                }
                crmTrace.AppendLine("Retrieve PLworkimpactthewatersupply");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PLworkimpactthewatersupply))
                {
                    bool PLworkimpactthewatersupply = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PLworkimpactthewatersupply);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PLworkimpactthewatersupply, PLworkimpactthewatersupply);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PLworkimpactthewatersupply, null);
                }
                crmTrace.AppendLine("Retrieve FeeExemptionRequestNonProfitOwnedOperated");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated))
                {
                    bool FeeExemptionRequestNonProfitOwnedOperated = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated, FeeExemptionRequestNonProfitOwnedOperated);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FeeExemptionRequestNonProfitOwnedOperated, null);
                }
                crmTrace.AppendLine("Retrieve NYCHAHHCNYCAgencyorOwnedOperated");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated))
                {
                    bool NYCHAHHCNYCAgencyorOwnedOperated = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated, NYCHAHHCNYCAgencyorOwnedOperated);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NYCHAHHCNYCAgencyorOwnedOperated, null);
                }
                crmTrace.AppendLine("Retrieve OwnersCertificationsRegardingOccupiedHousing");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing))
                {
                    bool OwnersCertificationsRegardingOccupiedHousing = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing, OwnersCertificationsRegardingOccupiedHousing);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OwnersCertificationsRegardingOccupiedHousing, null);
                }
                crmTrace.AppendLine("Retrieve Thesiteofthebuildingtobealteredordemolished4thcheckbox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox))
                {
                    bool Thesiteofthebuildingtobealteredordemolished4thcheckbox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox, Thesiteofthebuildingtobealteredordemolished4thcheckbox);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Thesiteofthebuildingtobealteredordemolished4thcheckbox, null);
                }
                crmTrace.AppendLine("Retrieve AThesiteofthebuildingtobealteredordemolished");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished))
                {
                    bool AThesiteofthebuildingtobealteredordemolished = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished, AThesiteofthebuildingtobealteredordemolished);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AThesiteofthebuildingtobealteredordemolished, null);
                }
                crmTrace.AppendLine("Retrieve BNotifiedtheNYCHomes");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BNotifiedtheNYCHomes))
                {
                    bool BNotifiedtheNYCHomes = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.BNotifiedtheNYCHomes);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BNotifiedtheNYCHomes, BNotifiedtheNYCHomes);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BNotifiedtheNYCHomes, null);
                }
                crmTrace.AppendLine("Retrieve ProvideDateNYSHCRNotified");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified))
                {
                    DateTime ProvideDateNYSHCRNotified = targetEntity.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProvideDateNYSHCRNotified, ProvideDateNYSHCRNotified);

                }
               
                crmTrace.AppendLine("Retrieve Structuredesignbase");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Structuredesignbase))
                {
                    bool Structuredesignbase = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Structuredesignbase);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Structuredesignbase, Structuredesignbase);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Structuredesignbase, null);
                }
                crmTrace.AppendLine("Retrieve DwellingUnits ");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DwellingUnits))
                {
                    string DwellingUnits = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.DwellingUnits);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DwellingUnits, DwellingUnits);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DwellingUnits, string.Empty);
                }
                crmTrace.AppendLine("Retrieve NYSPELicenseNumber ");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NYSPELicenseNumber))
                {
                    string NYSPELicenseNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.NYSPELicenseNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NYSPELicenseNumber, NYSPELicenseNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NYSPELicenseNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve PlumbingCheckBox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    bool PlumbingCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingCheckBox, PlumbingCheckBox);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingCheckBox, null);
                }
                crmTrace.AppendLine("Retrieve NoTR8InspectionCheckbox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoTR8InspectionCheckbox))
                {
                    bool NoTR8InspectionCheckbox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.NoTR8InspectionCheckbox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NoTR8InspectionCheckbox, NoTR8InspectionCheckbox);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NoTR8InspectionCheckbox, null);
                }

                crmTrace.AppendLine("Retrieve SDCheckBox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SDCheckBox))
                {
                    bool SDCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SDCheckBox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SDCheckBox, SDCheckBox);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SDCheckBox, null);
                }

                crmTrace.AppendLine("Retrieve PlumbingCheckBox Legalization");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization))
                {
                    bool PlumbingCheckBoxLegalization = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingWorkLegalization, PlumbingCheckBoxLegalization);

                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingWorkLegalization, null);
                }

                crmTrace.AppendLine("Retrieve SprinklerCheckBox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    bool SprinklerCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerCheckBox, SprinklerCheckBox);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerCheckBox, null);
                }

                crmTrace.AppendLine("Retrieve SprinklerCheckBox Legalization");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization))
                {
                    bool SprinklerCheckBoxLegalization = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerWorkLegalization, SprinklerCheckBoxLegalization);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerWorkLegalization, null);
                }

                crmTrace.AppendLine("Retrieve Totaljobcost");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalJobCost))
                {
                    Money totaljobcost = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.TotalJobCost]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.TotalJobCost, totaljobcost);
                }
                crmTrace.AppendLine("Retrieve EstimatedJobCost");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))
                {
                    Money jobcost = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCost, jobcost);
                }

                crmTrace.AppendLine("Retrieve TotalConstructionFloorArea");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea))
                {
                    double TotalConstructionFloorArea = targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.TotalConstructionFloorArea, TotalConstructionFloorArea);
                }

                crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode))
                {
                    int Reviewisrequestedunderwhichbuildingcode = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode, new OptionSetValue(Reviewisrequestedunderwhichbuildingcode));
                }

                crmTrace.AppendLine("Retrieve LittleEorRDSite");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LittleEorRDSite))
                {
                    int LittleEorRDSite = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.LittleEorRDSite).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LittleEorRDSite, new OptionSetValue(LittleEorRDSite));
                }

                
                crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork))
                {
                    int RequestingLegalizationofworkwherenowork = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork, new OptionSetValue(RequestingLegalizationofworkwherenowork));
                }

                crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe))
                {
                    int Workincludespermanentremovalofstandpipe = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe, new OptionSetValue(Workincludespermanentremovalofstandpipe));
                }

                crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CompliacnewiththeNYCECC))
                {
                    bool CompliacnewiththeNYCECC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CompliacnewiththeNYCECC);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, CompliacnewiththeNYCECC);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, null);
                }


                crmTrace.AppendLine("Retrieve CodeCompliancePath");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CodeCompliancePath))
                {
                    int CodeCompliancePath = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CodeCompliancePath).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CodeCompliancePath, new OptionSetValue(CodeCompliancePath));
                }
                
                crmTrace.AppendLine("Retrieve EnergyAnalysis");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EnergyAnalysis))
                {
                    int EnergyAnalysis = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.EnergyAnalysis).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EnergyAnalysis, new OptionSetValue(EnergyAnalysis));
                }

                crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExemptfromtheNYCECC))
                {
                    bool ExemptfromtheNYCECC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExemptfromtheNYCECC);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, ExemptfromtheNYCECC);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, null);
                }

                crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt))
                {
                    int ProfessionaljudgementallworkisExempt = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, new OptionSetValue(ProfessionaljudgementallworkisExempt));
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, new OptionSetValue(-1));
                }

                crmTrace.AppendLine("Retrieve ExistingFireAlarm");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingFireAlarm))
                {
                    bool ExistingFireAlarm = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExistingFireAlarm);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingFireAlarm, ExistingFireAlarm);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingFireAlarm, null);
                }

                crmTrace.AppendLine("Retrieve ProposedFireAlarm");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireAlarm))
                {
                    bool ProposedFireAlarm = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedFireAlarm);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireAlarm, ProposedFireAlarm);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireAlarm, null);
                }

                crmTrace.AppendLine("Retrieve ExisitingFireSuppression");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingFireSuppression))
                {
                    bool ExisitingFireSuppression = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExisitingFireSuppression);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, ExisitingFireSuppression);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, null);
                }

                crmTrace.AppendLine("Retrieve ProposedFireSuppression");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireSuppression))
                {
                    bool ProposedFireSuppression = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedFireSuppression);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireSuppression, ProposedFireSuppression);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireSuppression, null);
                }


                crmTrace.AppendLine("Retrieve ExisitingSprinkler");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingSprinkler))
                {
                    bool ExisitingSprinkler = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExisitingSprinkler);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingSprinkler, ExisitingSprinkler);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingSprinkler, null);
                }

                crmTrace.AppendLine("Retrieve ProposedSprinkler");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedSprinkler))
                {
                    bool ProposedSprinkler = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedSprinkler);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedSprinkler, ProposedSprinkler);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedSprinkler, null);
                }

                crmTrace.AppendLine("Retrieve Mixedusebuilding");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Mixedusebuilding))
                {
                    int Mixedusebuilding = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Mixedusebuilding).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Mixedusebuilding, new OptionSetValue(Mixedusebuilding));
                }

                crmTrace.AppendLine("Retrieve ExisitingBuildingStories");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingBuildingStories))
                {
                    int ExisitingBuildingStories = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExisitingBuildingStories);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingBuildingStories, ExisitingBuildingStories);
                }

                crmTrace.AppendLine("Retrieve ProposeeBuildingStories");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories))
                {
                    int ProposeeBuildingStories = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposeeBuildingStories, ProposeeBuildingStories);
                }

                crmTrace.AppendLine("Retrieve ExistingBuildingHeight");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingBuildingHeight))
                {
                    int ExistingBuildingHeight = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingBuildingHeight);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingBuildingHeight, ExistingBuildingHeight);
                }

                crmTrace.AppendLine("Retrieve ProposedBuildingHeight");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight))
                {
                    int ProposedBuildingHeight = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedBuildingHeight, ProposedBuildingHeight);
                }

                crmTrace.AppendLine("Retrieve ExistingDwellingUnits");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingDwellingUnits))
                {
                    int ExistingDwellingUnits = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingDwellingUnits);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingDwellingUnits, ExistingDwellingUnits);
                }

                crmTrace.AppendLine("Retrieve ProposedDwellingUnits");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedDwellingUnits))
                {
                    int ProposedDwellingUnits = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedDwellingUnits);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedDwellingUnits, ProposedDwellingUnits);
                }

                //Added Job Description 08/08/2017 TFS 5567 resolved
                crmTrace.AppendLine("Retrieve JobDescription");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.JobDescription))
                {
                    string JobDescription = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescription);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.JobDescription, JobDescription);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.JobDescription,string.Empty);
                }
                // Added WorkonFloors 08/29/2017 TFS 6123
                crmTrace.AppendLine("Retrieve WorkonFloorsAttributeName");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.WorkonFloorsAttributeName))
                {
                    string WorkonFloorsAttributeName = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.WorkonFloorsAttributeName);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.WorkonFloorsAttributeName, WorkonFloorsAttributeName);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.WorkonFloorsAttributeName, string.Empty);
                }
                crmTrace.AppendLine("Retrieve DEPACPControlNoAttributeName ");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DEPACPControlNoAttributeName))
                {
                    string DEPACPControlNoAttributeName = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.DEPACPControlNoAttributeName);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DEPACPControlNoAttributeName, DEPACPControlNoAttributeName);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DEPACPControlNoAttributeName, string.Empty);
                }
                crmTrace.AppendLine("Retrieve InvestigatorCertificateNumber  ");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.InvestigatorCertificateNumber))
                {
                    string InvestigatorCertificateNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.InvestigatorCertificateNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.InvestigatorCertificateNumber, InvestigatorCertificateNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.InvestigatorCertificateNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Depvariancev5letter");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Depvariancev5letter))
                {
                    bool Depvariancev5letter = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Depvariancev5letter);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Depvariancev5letter, Depvariancev5letter);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Depvariancev5letter, null);
                }
                crmTrace.AppendLine("Retrieve Depacp20acp21asbestos");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Depacp20acp21asbestos))
                {
                    bool Depacp20acp21asbestos = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Depacp20acp21asbestos);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Depacp20acp21asbestos, Depacp20acp21asbestos);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Depacp20acp21asbestos, null);
                }

                parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsPAAinProgress, false);
                crmTrace.AppendLine("Added LatestPAAGuid");
                parentEntity.Attributes.Add(JobFilingEntityAttributeName.LatestPAAGuid, targetEntity.Id.ToString());

                #region Antenna Fields

                crmTrace.AppendLine("Retrieve AlternateJobInBISAssociation");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation))
                {
                    bool AlternateJobInBISAssociation = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AlternateJobInBISAssociation);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AlternateJobInBISAssociation, AlternateJobInBISAssociation);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AlternateJobInBISAssociation, null);
                }

                crmTrace.AppendLine("Retrieve AntennaWorkType");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AntennaWorkType))
                {
                    int AntennaWorkType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.AntennaWorkType).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AntennaWorkType, new OptionSetValue(AntennaWorkType));
                }

                crmTrace.AppendLine("Retrieve BSACalendarNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BSACalendarNumbers))
                {
                    bool BSACalendarNumbers = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.BSACalendarNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BSACalendarNumbers, BSACalendarNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BSACalendarNumbers, null);
                }

                crmTrace.AppendLine("Retrieve CPCCalendarNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CPCCalendarNumbers))
                {
                    bool CPCCalendarNumbers = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CPCCalendarNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CPCCalendarNumbers, CPCCalendarNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CPCCalendarNumbers, null);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibit");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibit))
                {
                    bool CRFNZoningExhibit = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CRFNZoningExhibit);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibit, CRFNZoningExhibit);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibit, null);
                }

                crmTrace.AppendLine("Retrieve CurbCutWorkType");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CurbCutWorkType))
                {
                    int CurbCutWorkType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurbCutWorkType).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CurbCutWorkType, new OptionSetValue(CurbCutWorkType));
                }

                crmTrace.AppendLine("Retrieve Directive14");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Directive14))
                {
                    bool Directive14 = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Directive14);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Directive14, Directive14);
                    crmTrace.AppendLine("Updated Directive14");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Directive14, null);
                }

                crmTrace.AppendLine("Retrieve Districts");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Districts))
                {
                    string Districts = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Districts);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Districts, Districts);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Districts, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExtendHigherThan6Feet");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExtendHigherThan6Feet))
                {
                    bool ExtendHigherThan6Feet = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExtendHigherThan6Feet);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExtendHigherThan6Feet, ExtendHigherThan6Feet);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExtendHigherThan6Feet, null);
                }

                crmTrace.AppendLine("Retrieve HighRiseTeamTrackingNumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber))
                {
                    string HighRiseTeamTrackingNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber, HighRiseTeamTrackingNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve IsAntennaOneMeterinDiameter");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter))
                {
                    bool IsAntennaOneMeterinDiameter = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter, IsAntennaOneMeterinDiameter);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter, null);
                }

                crmTrace.AppendLine("Retrieve IsStructuralWorkIncluded");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsStructuralWorkIncluded))
                {
                    bool IsStructuralWorkIncluded = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsStructuralWorkIncluded);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsStructuralWorkIncluded, IsStructuralWorkIncluded);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsStructuralWorkIncluded, null);
                }

                crmTrace.AppendLine("Retrieve MapNumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MapNumber))
                {
                    string MapNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.MapNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.MapNumber, MapNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.MapNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve OccupyMoreThan5Percent");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OccupyMoreThan5Percent))
                {
                    bool OccupyMoreThan5Percent = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.OccupyMoreThan5Percent);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OccupyMoreThan5Percent, OccupyMoreThan5Percent);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OccupyMoreThan5Percent, null);
                }

                crmTrace.AppendLine("Retrieve Overlays");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Overlays))
                {
                    string Overlays = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Overlays);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Overlays, Overlays);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Overlays, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProvideBSACalendarNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProvideBSACalendarNumbers))
                {
                    string ProvideBSACalendarNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideBSACalendarNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProvideBSACalendarNumbers, ProvideBSACalendarNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProvideBSACalendarNumbers, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProvideCPCCalendarNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers))
                {
                    string ProvideCPCCalendarNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers, ProvideCPCCalendarNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers, string.Empty);
                }
                //crmTrace.AppendLine("Retrieve RelatedAltBISJobNumbers");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RelatedAltBISJobNumbers))
                //{
                //    string RelatedAltBISJobNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedAltBISJobNumbers);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RelatedAltBISJobNumbers, RelatedAltBISJobNumbers);
                //}

                crmTrace.AppendLine("Retrieve RelatedDOBJobNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RelatedDOBJobNumbers))
                {
                    string RelatedDOBJobNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedDOBJobNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RelatedDOBJobNumbers, RelatedDOBJobNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RelatedDOBJobNumbers, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SpecialDistricts");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SpecialDistricts))
                {
                    string SpecialDistricts = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.SpecialDistricts);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SpecialDistricts, SpecialDistricts);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SpecialDistricts, string.Empty);
                }
                crmTrace.AppendLine("Retrieve StructuralStabilityAffected");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StructuralStabilityAffected))
                {
                    bool StructuralStabilityAffected = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralStabilityAffected);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.StructuralStabilityAffected, StructuralStabilityAffected);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.StructuralStabilityAffected, null);
                }

                crmTrace.AppendLine("Retrieve WorkIncludesPartialDemolition");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.WorkIncludesPartialDemolition))
                {
                    bool WorkIncludesPartialDemolition = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.WorkIncludesPartialDemolition);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.WorkIncludesPartialDemolition, WorkIncludesPartialDemolition);
                    crmTrace.AppendLine("Updated WorkIncludesPartialDemolition");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.WorkIncludesPartialDemolition, null);
                }

                crmTrace.AppendLine("Retrieve EstimatedNewWorkFinalCost");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost))
                {
                    Money EstimatedNewWorkFinalCost = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedNewWorkFinalCost]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost, EstimatedNewWorkFinalCost);
                    crmTrace.AppendLine("Updated EstimatedNewWorkFinalCost");
                }

                crmTrace.AppendLine("Retrieve EstimatedJobCostLegal");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                {
                    Money EstimatedJobCostLegal = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, EstimatedJobCostLegal);
                    crmTrace.AppendLine("Updated EstimatedJobCostLegal");
                }

                crmTrace.AppendLine("Retrieve NewWorkFilingFee");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NewWorkFilingFee))
                {
                    Money NewWorkFilingFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.NewWorkFilingFee]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NewWorkFilingFee, NewWorkFilingFee);
                    crmTrace.AppendLine("Updated NewWorkFilingFee");
                }
                crmTrace.AppendLine("Retrieve NoGoodCheck Fee");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFee) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckFee] != null && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.NoGoodCheckFee).Value >= 0)
                {
                    Money NewWorkFilingFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFee]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, NewWorkFilingFee);
                    crmTrace.AppendLine("Updated NoGoodCheck Fee");
                }
                crmTrace.AppendLine("Retrieve NoGoodCheck Count");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckCount) && targetEntity[JobFilingEntityAttributeName.NoGoodCheckCount] != null && targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.NoGoodCheckCount) >= 0)
                {
                    int count = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.NoGoodCheckCount);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckCount, count);
                    crmTrace.AppendLine("Updated NoGoodCheck count");
                }
                crmTrace.AppendLine("Retrieve In conjunction Job Fee");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.InConjunctionFee) && targetEntity[JobFilingEntityAttributeName.InConjunctionFee] != null && targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.InConjunctionFee).Value >= 0)
                {
                    Money NewWorkFilingFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.InConjunctionFee]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.InConjunctionFee, NewWorkFilingFee);
                    crmTrace.AppendLine("Updated InConjunctionFee Fee");
                }
                crmTrace.AppendLine("Retrieve RecordManagementFee");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RecordManagementFee))
                {
                    Money NewWorkFilingFee = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.RecordManagementFee]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RecordManagementFee, NewWorkFilingFee);
                    crmTrace.AppendLine("Updated RecordManagementFee");
                }
                crmTrace.AppendLine("Retrieve Landmarkfee");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LandmarkFee))
                {
                    Money jobcost = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.LandmarkFee]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LandmarkFee, jobcost);
                }


                //ST

                crmTrace.AppendLine("Retrieve Yearforlocallaws");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Yearforlocallaws))
                {
                    string Yearforlocallaws = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Yearforlocallaws);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Yearforlocallaws, Yearforlocallaws);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Yearforlocallaws, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ApplicableStatSection");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ApplicableStatSection))
                {
                    string ApplicableStatSection = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ApplicableStatSection);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ApplicableStatSection, ApplicableStatSection);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ApplicableStatSection, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Easementaggrementname");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Easementaggrementname))
                {
                    string Easementaggrementname = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Easementaggrementname);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Easementaggrementname, Easementaggrementname);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Easementaggrementname, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Modularconstnystate");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystate))
                {
                    bool Modularconstnystate = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Modularconstnystate);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Modularconstnystate, Modularconstnystate);
                    crmTrace.AppendLine("Updated Modularconstnystate");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Modularconstnystate, null);
                }
                crmTrace.AppendLine("Retrieve Modularconstnystatenyc");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystatenyc))
                {
                    bool Modularconstnystatenyc = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Modularconstnystatenyc);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, Modularconstnystatenyc);
                    crmTrace.AppendLine("Updated Modularconstnystatenyc");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, null);
                }


                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Buildinggreater))
                {
                    bool Buildinggreater = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Buildinggreater);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildinggreater, Buildinggreater);
                    crmTrace.AppendLine("Updated Buildinggreater");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildinggreater, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Buildingsgrossfloorarea))
                {
                    bool Buildingsgrossfloorarea = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Buildingsgrossfloorarea);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, Buildingsgrossfloorarea);
                    crmTrace.AppendLine("Updated Buildingsgrossfloorarea");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Areallaspectratiossixorless))
                {
                    bool Areallaspectratiossixorless = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Areallaspectratiossixorless);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, Areallaspectratiossixorless);
                    crmTrace.AppendLine("Updated Areallaspectratiossixorless");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Specialseismicenergy))
                {
                    bool Specialseismicenergy = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Specialseismicenergy);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Specialseismicenergy, Specialseismicenergy);
                    crmTrace.AppendLine("Updated Specialseismicenergy");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Specialseismicenergy, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Doesthebuildingincludeany))
                {
                    bool Doesthebuildingincludeany = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Doesthebuildingincludeany);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, Doesthebuildingincludeany);
                    crmTrace.AppendLine("Updated Doesthebuildingincludeany");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Isthebuildingincludedinstructural))
                {
                    bool Isthebuildingincludedinstructural = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Isthebuildingincludedinstructural);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, Isthebuildingincludedinstructural);
                    crmTrace.AppendLine("Updated Isthebuildingincludedinstructural");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet))
                {
                    bool Buildinghavemorethan50000squarefeet = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, Buildinghavemorethan50000squarefeet);
                    crmTrace.AppendLine("Updated Buildinghavemorethan50000squarefeet");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, null);
                }

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Doanyelementsexcept))
                {
                    bool Doanyelementsexcept = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Doanyelementsexcept);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Doanyelementsexcept, Doanyelementsexcept);
                    crmTrace.AppendLine("Updated Doanyelementsexcept");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Doanyelementsexcept, null);
                }


                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Structuralpeerreview))
                {
                    bool Structuralpeerreview = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Structuralpeerreview);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Structuralpeerreview, Structuralpeerreview);
                    crmTrace.AppendLine("Updated Structuralpeerreview");
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Structuralpeerreview, null);
                }

                crmTrace.AppendLine("Retrieve Associatedbuildingsbulletinnumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber))
                {
                    string Associatedbuildingsbulletinnumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, Associatedbuildingsbulletinnumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TotalFeeAttributeName");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalFeeAttributeName))
                {
                    if (((!targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == false)) &&
                             (!targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == false))
                    {
                        Money TotalFeeAttributeName = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.TotalFeeAttributeName]));
                        decimal TotalFeeAttributeName_adjust = TotalFeeAttributeName.Value - 100;
                        //When we are merging to I1 we have to minus 100$ since we are adding PAA Fee on P1 filing and that should not carry forward to I1.
                        crmTrace.AppendLine("When we are merging to I1 we have to minus 100$ since we are adding PAA Fee on P1 filing and that should not carry forward to I1.");
                        if (TotalFeeAttributeName_adjust >= 0) //bug Fix 20753 for latest filings PAA=0 for fee exempt filings
                        {
                            parentEntity.Attributes.Add(JobFilingEntityAttributeName.TotalFeeAttributeName, new Money(TotalFeeAttributeName_adjust));
                        }

                        crmTrace.AppendLine("Updated TotalFeeAttributeName");
                    }

                }

                //ST

                crmTrace.AppendLine("Retrieve AmountPaid");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountPaid))
                {

                    decimal adjustmentAmount = 0;
                    decimal Adjusted_AmountPaid = 0;
                    Money AmountPaid = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.AmountPaid]));
                    crmTrace.AppendLine("Perform Amount paid calculations only if PAA amount paid is>0");

                    #region bug Fix 20753
                    if (AmountPaid.Value > 0)
                    {
                        crmTrace.AppendLine("if we have adjustment in PAA then we have to subtract that adjustment amount as well when merging to I1");
                        //if we have adjustment in PAA then we have to subtract that adjustment amount as well when merging to I1
                        //get the adjustment Final
                        if (targetEntity.Contains(JobFilingEntityAttributeName.AdjustmentFinal))
                        {
                            crmTrace.AppendLine("get the adjustment Final");
                            adjustmentAmount = targetEntity.GetAttributeValue<Money>(JobFilingEntityAttributeName.AdjustmentFinal).Value;
                        }

                        if (((!targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox) == false)) &&
                           (!targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) || targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox) == false))
                        {
                            if (adjustmentAmount > 0)
                            {
                                crmTrace.AppendLine("get the adjustment Final and adjustmentAmount>0");
                                Adjusted_AmountPaid = AmountPaid.Value - adjustmentAmount - 100;
                            }
                            else
                            {
                                Adjusted_AmountPaid = AmountPaid.Value - 100;
                            }

                            if (Adjusted_AmountPaid >= 0) //update parent jobfiling only if adjusted_amount paid is >=0
                            {
                                crmTrace.AppendLine(" update parent jobfiling only if adjusted_amount paid is >=0 Adjusted_AmountPaid:  " + Adjusted_AmountPaid);
                                parentEntity.Attributes.Add(JobFilingEntityAttributeName.AmountPaid, new Money(Adjusted_AmountPaid));
                                crmTrace.AppendLine("Updated AmountPaid");
                            }

                        }


                    }
                    #endregion

                }

                ///Bug 5519: Fix - Start

                crmTrace.AppendLine("Retrieve FacadeAlternation");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FacadeAlternation))
                {
                    bool FacadeAlternation = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FacadeAlternation);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FacadeAlternation, FacadeAlternation);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FacadeAlternation, null);
                }

                crmTrace.AppendLine("Retrieve AdultEstablishment");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AdultEstablishment))
                {
                    bool AdultEstablishment = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AdultEstablishment);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AdultEstablishment, AdultEstablishment);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AdultEstablishment, null);
                }

                crmTrace.AppendLine("Retrieve QualityHousing");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.QualityHousing))
                {
                    bool QualityHousing = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.QualityHousing);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.QualityHousing, QualityHousing);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.QualityHousing, null);
                }

                crmTrace.AppendLine("Retrieve IsConjunctionJob");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                {
                    bool IsConjunctionJob = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsConjunctionJob);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsConjunctionJob, IsConjunctionJob);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsConjunctionJob, null);
                }

                crmTrace.AppendLine("Retrieve BisRelatedJobNumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BisRelatedJobNumber))
                {
                    string BisRelatedJobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.BisRelatedJobNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BisRelatedJobNumber, BisRelatedJobNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BisRelatedJobNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve AlternateBisRelatedJobNumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber))
                {
                    string AlternateBisRelatedJobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber, AlternateBisRelatedJobNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AlternateBisRelatedJobNumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNRestrictiveDeclaration");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration))
                {
                    bool CRFNRestrictiveDeclaration = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration, CRFNRestrictiveDeclaration);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration, null);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber1");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber1))
                {
                    string CRFNNumber1 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber1);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber1, CRFNNumber1);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber1, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber2");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber2))
                {
                    string CRFNNumber2 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber2);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber2, CRFNNumber2);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber2, string.Empty);
                }
                crmTrace.AppendLine("Retrieve CRFNNumber3");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber3))
                {
                    string CRFNNumber3 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber3);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber3, CRFNNumber3);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber3, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber4");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber4))
                {
                    string CRFNNumber4 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber4);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber4, CRFNNumber4);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNNumber4, string.Empty);
                }
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber1");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1))
                {
                    string CRFNZoningExhibitNumber1 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1, CRFNZoningExhibitNumber1);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1, string.Empty);
                }
                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber2");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2))
                {
                    string CRFNZoningExhibitNumber2 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2, CRFNZoningExhibitNumber2);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber3");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3))
                {
                    string CRFNZoningExhibitNumber3 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3, CRFNZoningExhibitNumber3);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber4");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4))
                {
                    string CRFNZoningExhibitNumber4 = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4, CRFNZoningExhibitNumber4);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsFilingtoAddressViolations");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFilingtoAddressViolations))
                {
                    bool IsFilingtoAddressViolations = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFilingtoAddressViolations);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsFilingtoAddressViolations, IsFilingtoAddressViolations);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsFilingtoAddressViolations, null);
                }

                crmTrace.AppendLine("Retrieve ListViolationsDOBECB");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ListViolationsDOBECB))
                {
                    string ListViolationsDOBECB = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ListViolationsDOBECB);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ListViolationsDOBECB, ListViolationsDOBECB);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ListViolationsDOBECB, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ECBNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ECBNumbers))
                {
                    string ECBNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ECBNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ECBNumbers, ECBNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ECBNumbers, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ConstructionClassification");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionClassification))
                {
                    string ConstructionClassification = string.Empty;
                    EntityReference reqLookUp = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ConstructionClassification);
                    if (reqLookUp != null)
                    {
                        ConstructionClassification = reqLookUp.Name;
                        parentEntity.Attributes.Add(JobFilingEntityAttributeName.ConstructionClassification, new EntityReference(BuildingCharacteristicsClassificationsAttributeNames.EntityLogicalName, reqLookUp.Id));
                    }
                    crmTrace.AppendLine("Retrieve ConstructionClassification:" + ConstructionClassification);
                }

                crmTrace.AppendLine("Retrieve OccupancyClassification");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OccupancyClassification))
                {
                    string OccupancyClassification = string.Empty;
                    EntityReference reqLookUp = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.OccupancyClassification);
                    if (reqLookUp != null)
                    {
                        OccupancyClassification = reqLookUp.Name;
                        parentEntity.Attributes.Add(JobFilingEntityAttributeName.OccupancyClassification, new EntityReference(BuildingCharacteristicsClassificationsAttributeNames.EntityLogicalName, reqLookUp.Id));
                    }
                    crmTrace.AppendLine("Retrieve OccupancyClassification:" + OccupancyClassification);
                }

                crmTrace.AppendLine("Retrieve MultipleDwellingClassification");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MultipleDwellingClassification))
                {
                    string MultipleDwellingClassification = string.Empty;
                    EntityReference reqLookUp = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.MultipleDwellingClassification);
                    if (reqLookUp != null)
                    {
                        MultipleDwellingClassification = reqLookUp.Name;
                        parentEntity.Attributes.Add(JobFilingEntityAttributeName.MultipleDwellingClassification, new EntityReference(BuildingCharacteristicsClassificationsAttributeNames.EntityLogicalName, reqLookUp.Id));
                    }
                    crmTrace.AppendLine("Retrieve MultipleDwellingClassification:" + MultipleDwellingClassification);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsTidalWastelands");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands))
                {

                    bool SiteCharacteristicsTidalWastelands = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands);
                    crmTrace.AppendLine(SiteCharacteristicsTidalWastelands.ToString());
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands, SiteCharacteristicsTidalWastelands);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsCoastalErosionHazardArea");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea))
                {
                    bool SiteCharacteristicsCoastalErosionHazardArea = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea);
                    crmTrace.AppendLine(SiteCharacteristicsCoastalErosionHazardArea.ToString());
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, SiteCharacteristicsCoastalErosionHazardArea);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, null);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFireDistrict");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict))
                {
                    bool SiteCharacteristicsFireDistrict = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict);
                    crmTrace.AppendLine(SiteCharacteristicsFireDistrict.ToString());
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict, SiteCharacteristicsFireDistrict);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict, null);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFreshwaterWetlands");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands))
                {
                    bool SiteCharacteristicsFreshwaterWetlands = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, SiteCharacteristicsFreshwaterWetlands);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, null);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsUrbanRenewal");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal))
                {
                    bool SiteCharacteristicsUrbanRenewal = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal, SiteCharacteristicsUrbanRenewal);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal, null);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFloodHazardArea");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea))
                {
                    bool SiteCharacteristicsFloodHazardArea = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, SiteCharacteristicsFloodHazardArea);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, null);
                }

                crmTrace.AppendLine("Retrieve FloodHzAreaIsSubstantialImprovement");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement))
                {
                    bool FloodHzAreaIsSubstantialImprovement = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement, FloodHzAreaIsSubstantialImprovement);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement, null);
                }

                crmTrace.AppendLine("Retrieve IsFloodHzAreaSubstantiallyDamaged");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged))
                {
                    bool IsFloodHzAreaSubstantiallyDamaged = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged, IsFloodHzAreaSubstantiallyDamaged);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged, null);
                }

                crmTrace.AppendLine("Retrieve FloodHzAreaFloodShieldsProposedWork");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork))
                {
                    bool FloodHzAreaFloodShieldsProposedWork = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork, FloodHzAreaFloodShieldsProposedWork);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork, null);
                }

                crmTrace.AppendLine("Retrieve AsbestosAbatementCompliance");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AsbestosAbatementCompliance))
                {
                    int AsbestosAbatementCompliance = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.AsbestosAbatementCompliance).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AsbestosAbatementCompliance, new OptionSetValue(AsbestosAbatementCompliance));
                }

               

                crmTrace.AppendLine("Retrieve CommentsPWAttributeName");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CommentsPWAttributeName))
                {
                    string CommentsPWAttributeName = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.CommentsPWAttributeName);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, CommentsPWAttributeName);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, string.Empty);
                }
                //St added by sn on1/16/2019


                crmTrace.AppendLine("Retrieve MSWorkIncludesRaisingorMoving");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving))
                {
                    bool MSWorkIncludesRaisingorMoving = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving, MSWorkIncludesRaisingorMoving);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving, null);
                }
                //STWorkOnInterior
                crmTrace.AppendLine("Retrieve STWorkOnInterior");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnInterior))
                {
                    bool STWorkOnInterior = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.STWorkOnInterior);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STWorkOnInterior, STWorkOnInterior);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STWorkOnInterior, null);
                }
                //STWorkOnExterior
                crmTrace.AppendLine("Retrieve STWorkOnExterior");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnExterior))
                {
                    bool STWorkOnExterior = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.STWorkOnExterior);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STWorkOnExterior, STWorkOnExterior);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STWorkOnExterior, null);
                }
                //STRemovingOneOrMoreStories
                crmTrace.AppendLine("Retrieve STRemovingOneOrMoreStories");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.STRemovingOneOrMoreStories))
                {
                    bool STRemovingOneOrMoreStories = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.STRemovingOneOrMoreStories);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STRemovingOneOrMoreStories, STRemovingOneOrMoreStories);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STRemovingOneOrMoreStories, null);
                }
                //STDemolishing50OrMore
                crmTrace.AppendLine("Retrieve STDemolishing50OrMore");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.STDemolishing50OrMore))
                {
                    bool STDemolishing50OrMore = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.STDemolishing50OrMore);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STDemolishing50OrMore, STDemolishing50OrMore);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STDemolishing50OrMore, null);
                }
                //STAlternativeMaterialsOTCR
                crmTrace.AppendLine("Retrieve STAlternativeMaterialsOTCR");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR))
                {
                    bool STAlternativeMaterialsOTCR = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR, STAlternativeMaterialsOTCR);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR, null);
                }

                //END
                crmTrace.AppendLine("Retrieve ComplyingToLocalLaws");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ComplyingToLocalLaws))
                {
                    bool ComplyingToLocalLaws = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ComplyingToLocalLaws);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ComplyingToLocalLaws, ComplyingToLocalLaws);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ComplyingToLocalLaws, null);
                }

                crmTrace.AppendLine("Retrieve ListOfLawNumbers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ListOfLawNumbers))
                {
                    string ListOfLawNumbers = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ListOfLawNumbers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ListOfLawNumbers, ListOfLawNumbers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ListOfLawNumbers, string.Empty);
                }
                ///Bug 5519: Fix - End

                crmTrace.AppendLine("Making Adjustments to 0");
                parentEntity.Attributes.Add(JobFilingEntityAttributeName.AdjustmentFinal, new Money(0));
                crmTrace.AppendLine("Updated Adjustments");

                ///Filing Representative update - Bug 13656: Fix - Start
                crmTrace.AppendLine("Retrieve Owner Representative/Preparer/Filing Representative");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName))
                {
                    string FilingRepresentative = string.Empty;
                    EntityReference FRLookUp = targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.FilingRepresentativeAttributeName);
                    if (FRLookUp != null)
                    {
                        FilingRepresentative = FRLookUp.Name;
                        parentEntity.Attributes.Remove(JobFilingEntityAttributeName.FilingRepresentativeAttributeName);
                        parentEntity.Attributes.Add(JobFilingEntityAttributeName.FilingRepresentativeAttributeName, new EntityReference(ContactEntityAttributeName.EntityLogicalName, FRLookUp.Id));
                    }
                    crmTrace.AppendLine("Retrieve Owner Representative/Preparer/Filing Representative:" + FilingRepresentative);
                }
                //Bug 13656: Fix - End
                #endregion

                #region FAB4 Fields
                crmTrace.AppendLine("Retrieve (SRO) multiple Dwelling");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SROMultiple))
                {
                    string SROMultiple = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.SROMultiple);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SROMultiple, SROMultiple);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SROMultiple, string.Empty);
                }

                crmTrace.AppendLine("Retrieve LoftBoard");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LoftBoard))
                {
                    string LoftBoard = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.LoftBoard);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LoftBoard, LoftBoard);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LoftBoard, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SiteSafetyJob");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SiteSafetyJob))
                {
                    bool SiteSafetyJob = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SiteSafetyJob);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SiteSafetyJob, SiteSafetyJob);
                }
                crmTrace.AppendLine("Retrieve IncludedinLMCC");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.IncludedinLMCC))
                {
                    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IncludedinLMCC);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.IncludedinLMCC, IncludedinLMCC);
                }
                crmTrace.AppendLine("Retrieve heightFt");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.heightFt))
                {
                    double heightFt = targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.heightFt);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.heightFt, heightFt);
                }
                crmTrace.AppendLine("Retrieve constructionMaterial");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.constructionMaterial))
                {
                    string constructionMaterial = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.constructionMaterial);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.constructionMaterial, constructionMaterial);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.constructionMaterial, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SizeoftheShed");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SizeoftheShed))
                {
                    decimal SizeoftheShed = targetEntity.GetAttributeValue<decimal>(JobFilingEntityAttributeName.SizeoftheShed);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SizeoftheShed, SizeoftheShed);
                }
                crmTrace.AppendLine("Retrieve BSAMEAOTCRApprovalNumber");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber))
                {
                    string BSAMEAOTCRApprovalNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber, BSAMEAOTCRApprovalNumber);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.BSAMEAOTCRApprovalNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve fenceConstructionMaterial");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.fenceConstructionMaterial))
                {
                    OptionSetValue fenceConstructionMaterial = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.fenceConstructionMaterial);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.fenceConstructionMaterial, fenceConstructionMaterial);
                }
               
                crmTrace.AppendLine("Retrieve describeOther");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.describeOther))
                {
                    string describeOther = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.describeOther);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.describeOther, describeOther);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.describeOther, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FireProtectionEquipmentExistingStandPipe");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe))
                {
                    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FireProtectionEquipmentExistingStandPipe, IncludedinLMCC);
                }
                crmTrace.AppendLine("Retrieve FireProtectionEquipmentProposedStandPipe");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe))
                {
                    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.FireProtectionEquipmentProposedStandPipe, IncludedinLMCC);
                }
                //crmTrace.AppendLine("Retrieve ExistingFireAlarm");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingFireAlarm))
                //{
                //    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExistingFireAlarm);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingFireAlarm, IncludedinLMCC);
                //}
                //crmTrace.AppendLine("Retrieve ProposedFireAlarm");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireAlarm))
                //{
                //    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedFireAlarm);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireAlarm, IncludedinLMCC);
                //}
                //crmTrace.AppendLine("Retrieve ExisitingSprinkler");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingSprinkler))
                //{
                //    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExisitingSprinkler);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingSprinkler, IncludedinLMCC);
                //}
                //crmTrace.AppendLine("Retrieve ProposedSprinkler");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedSprinkler))
                //{
                //    bool IncludedinLMCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedSprinkler);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedSprinkler, IncludedinLMCC);
                //}

                #endregion

                #region MS Fields

                //Section: Filing Review Type, Work Type/Filing Includes
                crmTrace.AppendLine("Retrieve HeatingSystem");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.HeatingSystem))
                {
                    bool HeatingSystem = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.HeatingSystem);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.HeatingSystem, HeatingSystem);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.HeatingSystem, null);
                }

                crmTrace.AppendLine("Retrieve VentilationSystem");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.VentilationSystem))
                {
                    bool VentilationSystem = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.VentilationSystem);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.VentilationSystem, VentilationSystem);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.VentilationSystem, null);
                }

                crmTrace.AppendLine("Retrieve AirConditioningSystem");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AirConditioningSystem))
                {
                    bool AirConditioningSystem = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AirConditioningSystem);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AirConditioningSystem, AirConditioningSystem);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AirConditioningSystem, null);
                }

                crmTrace.AppendLine("Retrieve Refrigeration");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Refrigeration))
                {
                    bool Refrigeration = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Refrigeration);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Refrigeration, Refrigeration);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Refrigeration, null);
                }

                crmTrace.AppendLine("Retrieve CoolingTowers");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CoolingTowers))
                {
                    bool CoolingTowers = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CoolingTowers);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CoolingTowers, CoolingTowers);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CoolingTowers, null);
                }

                crmTrace.AppendLine("Retrieve AssociatedDuctsAndPiping");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AssociatedDuctsAndPiping))
                {
                    bool AssociatedDuctsAndPiping = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AssociatedDuctsAndPiping);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AssociatedDuctsAndPiping, AssociatedDuctsAndPiping);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.AssociatedDuctsAndPiping, null);
                }

                crmTrace.AppendLine("Retrieve Generator");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Generator))
                {
                    bool Generator = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Generator);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Generator, Generator);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Generator, null);
                }

                crmTrace.AppendLine("Retrieve Other");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Other))
                {
                    bool Other = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Other);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Other, Other);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Other, null);
                }

                crmTrace.AppendLine("Retrieve OtherValues");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.OtherValues))
                {
                    string OtherValues = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.OtherValues);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OtherValues, OtherValues);
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.OtherValues, string.Empty);
                }
                
                #endregion

                #endregion

                serviceConnector.Update(parentEntity);
                crmTrace.AppendLine("UpdateParentJob End! ");
                #endregion PW1Section

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateParentJob_Superseded(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder crmTrace, Guid ParentJobGuid)
        {
            try
            {
                #region PW1 Section
                crmTrace.AppendLine("UpdateParentJob Started! ");
                Entity parentEntity = new Entity();
                parentEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                parentEntity.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, ParentJobGuid);

                #region Adding Superseded Applicant Information PW1
                crmTrace.AppendLine("Retrieve ApplicantPerson");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ApplicantPerson))
                {
                    Guid ApplicantPerson = ((EntityReference)targetEntity.Attributes[JobFilingEntityAttributeName.ApplicantPerson]).Id;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ApplicantPerson, new EntityReference(ContactEntityAttributeName.EntityLogicalName, ApplicantPerson));
                }
                crmTrace.AppendLine("Retrieve LicenseLookupField");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LicenseLookupField))
                {
                    Guid LicenseType = ((EntityReference)targetEntity.Attributes[JobFilingEntityAttributeName.LicenseLookupField]).Id;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LicenseLookupField, new EntityReference(LicenseTypeEntityAttributeName.EntityLogicalName, LicenseType));
                }
                crmTrace.AppendLine("Retrieve ApplicantBusiness");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ApplicantBusiness))
                {
                    string ApplicantBusiness = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.ApplicantBusiness);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ApplicantBusiness, ApplicantBusiness);
                }
                //crmTrace.AppendLine("Retrieve DOBIssuedIdAttributeName");
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DOBIssuedIdAttributeName))
                //{
                //    string DOBIssuedIdAttributeName = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.DOBIssuedIdAttributeName);
                //    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DOBIssuedIdAttributeName, DOBIssuedIdAttributeName);
                //}

                //


                #endregion

                #region Adding Superseded Applicant Information TR8 Legal
                crmTrace.AppendLine("Retrieve DPcheckTR8");

                crmTrace.AppendLine("Retrieve DesignApplicantsStatementsandSignaturesECAAttributeName");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName))
                {
                    bool DesignApplicantsStatementsandSignaturesECAAttributeName = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName, DesignApplicantsStatementsandSignaturesECAAttributeName);
                }

                crmTrace.AppendLine("Retrieve DesignApplicantsStatementsandSignaturesECBAttributeName");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECBAttributeName))
                {
                    bool DesignApplicantsStatementsandSignaturesECBAttributeName = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECBAttributeName);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECBAttributeName, DesignApplicantsStatementsandSignaturesECBAttributeName);
                }



                #endregion

                #region Adding Attributes
                crmTrace.AppendLine("Retrieve PlumbingCheckBox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    bool PlumbingCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingCheckBox, PlumbingCheckBox);

                }

                crmTrace.AppendLine("Retrieve PlumbingCheckBox Legalization");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization))
                {
                    bool PlumbingCheckBoxLegalization = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.PlumbingWorkLegalization, PlumbingCheckBoxLegalization);

                }

                crmTrace.AppendLine("Retrieve SprinklerCheckBox");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    bool SprinklerCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerCheckBox, SprinklerCheckBox);
                }

                crmTrace.AppendLine("Retrieve SprinklerCheckBox Legalization");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization))
                {
                    bool SprinklerCheckBoxLegalization = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.SprinklerWorkLegalization, SprinklerCheckBoxLegalization);
                }

                crmTrace.AppendLine("Retrieve EstimatedJobCost");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))
                {
                    Money jobcost = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]));
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EstimatedJobCost, jobcost);
                }


                crmTrace.AppendLine("Retrieve TotalConstructionFloorArea");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea))
                {
                    double TotalConstructionFloorArea = targetEntity.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.TotalConstructionFloorArea, TotalConstructionFloorArea);
                }

                crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode))
                {
                    int Reviewisrequestedunderwhichbuildingcode = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode, new OptionSetValue(Reviewisrequestedunderwhichbuildingcode));
                }

                crmTrace.AppendLine("Retrieve LittleEorRDSite");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.LittleEorRDSite))
                {
                    int LittleEorRDSite = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.LittleEorRDSite).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.LittleEorRDSite, new OptionSetValue(LittleEorRDSite));
                }

                crmTrace.AppendLine("Retrieve UnmappedCCOStreet");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.UnmappedCCOStreet))
                {
                    int UnmappedCCOStreet = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.UnmappedCCOStreet).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.UnmappedCCOStreet, new OptionSetValue(UnmappedCCOStreet));
                }

                crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork))
                {
                    int RequestingLegalizationofworkwherenowork = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork, new OptionSetValue(RequestingLegalizationofworkwherenowork));
                }

                crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe))
                {
                    int Workincludespermanentremovalofstandpipe = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe, new OptionSetValue(Workincludespermanentremovalofstandpipe));
                }

                crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CompliacnewiththeNYCECC))
                {
                    bool CompliacnewiththeNYCECC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CompliacnewiththeNYCECC);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, CompliacnewiththeNYCECC);
                }


                crmTrace.AppendLine("Retrieve CodeCompliancePath");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CodeCompliancePath))
                {
                    int CodeCompliancePath = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CodeCompliancePath).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.CodeCompliancePath, new OptionSetValue(CodeCompliancePath));
                }

                crmTrace.AppendLine("Retrieve EnergyAnalysis");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.EnergyAnalysis))
                {
                    int EnergyAnalysis = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.EnergyAnalysis).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.EnergyAnalysis, new OptionSetValue(EnergyAnalysis));
                }

                crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExemptfromtheNYCECC))
                {
                    bool ExemptfromtheNYCECC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExemptfromtheNYCECC);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, ExemptfromtheNYCECC);
                }

                crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt))
                {
                    int ProfessionaljudgementallworkisExempt = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, new OptionSetValue(ProfessionaljudgementallworkisExempt));
                }
                else
                {
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, new OptionSetValue(-1));
                }

                crmTrace.AppendLine("Retrieve ExistingFireAlarm");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingFireAlarm))
                {
                    bool ExistingFireAlarm = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExistingFireAlarm);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingFireAlarm, ExistingFireAlarm);
                }

                crmTrace.AppendLine("Retrieve ProposedFireAlarm");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireAlarm))
                {
                    bool ProposedFireAlarm = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedFireAlarm);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireAlarm, ProposedFireAlarm);
                }

                crmTrace.AppendLine("Retrieve ExisitingFireSuppression");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingFireSuppression))
                {
                    bool ExisitingFireSuppression = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExisitingFireSuppression);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, ExisitingFireSuppression);
                }

                crmTrace.AppendLine("Retrieve ProposedFireSuppression");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireSuppression))
                {
                    bool ProposedFireSuppression = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedFireSuppression);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedFireSuppression, ProposedFireSuppression);
                }


                crmTrace.AppendLine("Retrieve ExisitingSprinkler");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingSprinkler))
                {
                    bool ExisitingSprinkler = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExisitingSprinkler);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingSprinkler, ExisitingSprinkler);
                }

                crmTrace.AppendLine("Retrieve ProposedSprinkler");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedSprinkler))
                {
                    bool ProposedSprinkler = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProposedSprinkler);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedSprinkler, ProposedSprinkler);
                }

                crmTrace.AppendLine("Retrieve Mixedusebuilding");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Mixedusebuilding))
                {
                    int Mixedusebuilding = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.Mixedusebuilding).Value;
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.Mixedusebuilding, new OptionSetValue(Mixedusebuilding));
                }

                crmTrace.AppendLine("Retrieve ExisitingBuildingStories");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExisitingBuildingStories))
                {
                    int ExisitingBuildingStories = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExisitingBuildingStories);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExisitingBuildingStories, ExisitingBuildingStories);
                }

                crmTrace.AppendLine("Retrieve ProposeeBuildingStories");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories))
                {
                    int ProposeeBuildingStories = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposeeBuildingStories, ProposeeBuildingStories);
                }

                crmTrace.AppendLine("Retrieve ExistingBuildingHeight");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingBuildingHeight))
                {
                    int ExistingBuildingHeight = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingBuildingHeight);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingBuildingHeight, ExistingBuildingHeight);
                }

                crmTrace.AppendLine("Retrieve ProposedBuildingHeight");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight))
                {
                    int ProposedBuildingHeight = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedBuildingHeight, ProposedBuildingHeight);
                }

                crmTrace.AppendLine("Retrieve ExistingDwellingUnits");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ExistingDwellingUnits))
                {
                    int ExistingDwellingUnits = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingDwellingUnits);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ExistingDwellingUnits, ExistingDwellingUnits);
                }

                crmTrace.AppendLine("Retrieve ProposedDwellingUnits");
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProposedDwellingUnits))
                {
                    int ProposedDwellingUnits = targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedDwellingUnits);
                    parentEntity.Attributes.Add(JobFilingEntityAttributeName.ProposedDwellingUnits, ProposedDwellingUnits);
                }


                parentEntity.Attributes.Add(JobFilingEntityAttributeName.IsPAAinProgress, false);




                #endregion

                serviceConnector.Update(parentEntity);
                crmTrace.AppendLine("UpdateParentJob End! ");
                #endregion PW1Section

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateParentJob_Superseded", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void InactiveWorkPermit(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                #region WorkPermit
                crmTrace.AppendLine("InactiveWorkPermit Started! ");
                Entity workpermit = new Entity();
                workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                crmTrace.AppendLine("WorkPermitid : " + targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitInactive));

                serviceConnector.Update(workpermit);
                crmTrace.AppendLine("InactiveWorkPermit End! ");
                #endregion WorkPermit

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - InactiveWorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateJobDesc_WorkPermit(IOrganizationService serviceConnector, Entity targetEntity, string jobDesc, StringBuilder crmTrace)
        {
            try
            {
                #region WorkPermit
                crmTrace.AppendLine("UpdateJobDesc_WorkPermit Started! ");
                Entity workpermit = new Entity();
                workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                crmTrace.AppendLine("WorkPermitid : " + targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.JobDescription, jobDesc);

                serviceConnector.Update(workpermit);
                crmTrace.AppendLine("UpdateJobDesc_WorkPermit End! ");
                #endregion WorkPermit

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateJobDesc_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateWorkonFloors_WorkPermit(IOrganizationService serviceConnector, Entity targetEntity, string workonfloor, StringBuilder crmTrace)
        {
            try
            {
                #region WorkPermit
                crmTrace.AppendLine("UpdateWorkonFloors_WorkPermit Started! ");
                Entity workpermit = new Entity();
                workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                crmTrace.AppendLine("WorkPermitid : " + targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, targetEntity.Id);
                workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkonFloor, workonfloor);

                serviceConnector.Update(workpermit);
                crmTrace.AppendLine("UpdateWorkonFloors_WorkPermit End! ");
                #endregion WorkPermit

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - UpdateWorkonFloors_WorkPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static Entity CreateScopeofWorklist(IOrganizationService service, Entity currentScopeofWorkRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity CS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);

                #region Scope of Work
                if (currentScopeofWorkRecord.LogicalName == ScopeOfWorkEntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(ScopeOfWorkEntityAttributeName.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(ScopeOfWorkAttributesNames.MetersLocatedatAttributeName));
                    CS.Attributes.Remove(ScopeOfWorkEntityAttributeName.GoToJobFiling);
                    CS.Attributes.Remove(ScopeOfWorkEntityAttributeName.ScopeofWorkId);
                    CS.Attributes.Add(ScopeOfWorkEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("ScopeOfWorkEntityAttributeName CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region FenceScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == FenceScopeofWorkAttributeNames.EntityLogicalName)
                {
                    Entity response = service.Retrieve(FenceScopeofWorkAttributeNames.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(FenceScopeofWorkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(FenceScopeofWorkAttributeNames.GotoJobFiling);
                    CS.Attributes.Remove(FenceScopeofWorkAttributeNames.FenceScopeofWorkId);
                    CS.Attributes.Add(FenceScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("FenceScopeofWorkAttributeNames CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region MHScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == MHScopeofworkAttributeNames.EntityLogicalName)
                {
                    Entity response = service.Retrieve(MHScopeofworkAttributeNames.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(MHScopeofworkAttributeNames.GotoJobFiling);
                    CS.Attributes.Remove(MHScopeofworkAttributeNames.MechanicalScopeofworkid);
                    CS.Attributes.Add(MHScopeofworkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("MHScopeofworkAttributeNames CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region STScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == STScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(STScopeOfWorkEntityAttribute.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(STScopeOfWorkEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(STScopeOfWorkEntityAttribute.STScopeOfWorkid);
                    CS.Attributes.Add(STScopeOfWorkEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("STScopeOfWorkEntityAttribute CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region ScopeofWorkQuestionnaireAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == ScopeofWorkQuestionnaire.EntityLogicalName)
                {
                    Entity response = service.Retrieve(ScopeofWorkQuestionnaire.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(ScopeofWorkQuestionnaire.GotoJobFiling);
                    CS.Attributes.Remove(ScopeofWorkQuestionnaire.SOWQuestionnaireId);
                    CS.Attributes.Add(ScopeofWorkQuestionnaire.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("ScopeofWorkQuestionnaire CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region SPSDScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == SPSDScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(SPSDScopeOfWorkEntityAttribute.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(SPSDScopeOfWorkEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(SPSDScopeOfWorkEntityAttribute.SPSDScopeOfWorkID);
                    CS.Attributes.Add(SPSDScopeOfWorkEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("SPSDScopeOfWorkEntityAttribute CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region SOWCommonWorktypeScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == SOWCommonWorkTypesEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(SOWCommonWorkTypesEntityAttribute.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(SOWCommonWorkTypesEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(SOWCommonWorkTypesEntityAttribute.SOWCommonWorkTypesEntityAttributeId);
                    CS.Attributes.Add(SOWCommonWorkTypesEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("SOWCommonWorkTypesEntityAttribute CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region ScopeofWorkFloorsAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == ScopeOfWorkonFloorEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(ScopeOfWorkonFloorEntityAttribute.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(ScopeOfWorkonFloorEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(ScopeOfWorkonFloorEntityAttribute.ScopeOfWorkonFloorID);
                    CS.Attributes.Add(ScopeOfWorkonFloorEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("ScopeOfWorkonFloorEntityAttribute CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region SPSDScopeofWorkFloorsAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(SPSDCommonWorkOnFloorEntityAttribute.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    // crmTrace.AppendLine("CS attribute House Number :" + CS.GetAttributeValue<string>(MHScopeofworkAttributeNames.FenceHeight));
                    CS.Attributes.Remove(SPSDCommonWorkOnFloorEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(SPSDCommonWorkOnFloorEntityAttribute.SPSDCommonWorkonfloorId);
                    CS.Attributes.Add(SPSDCommonWorkOnFloorEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("SPSDCommonWorkOnFloorEntityAttribute CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region ScaffoldScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == ScaffoldScopeofWorkAttributeNames.EntityLogicalName)
                {
                    Entity response = service.Retrieve(ScaffoldScopeofWorkAttributeNames.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    crmTrace.AppendLine("CS attribute ScaffoldShedType :" + CS.GetAttributeValue<OptionSetValue>(ScaffoldScopeofWorkAttributeNames.ScaffoldShedType).Value);
                    CS.Attributes.Remove(ScaffoldScopeofWorkAttributeNames.GotoJobFiling);
                    CS.Attributes.Remove(ScaffoldScopeofWorkAttributeNames.ScaffoldScopeofWorkId);
                    CS.Attributes.Add(ScaffoldScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("ScaffoldScopeofWorkAttributeNames CS ID :" + CS.Id.ToString());
                }
                #endregion
                #region SHScopeofWorkAttributeNames
                else if (currentScopeofWorkRecord.LogicalName == SHScopeofWorkAttributeNames.EntityLogicalName)
                {
                    Entity response = service.Retrieve(SHScopeofWorkAttributeNames.EntityLogicalName, currentScopeofWorkRecord.Id, columns);


                    CS = EntityExtensions.Clone(response, false);
                    crmTrace.AppendLine("CS attribute ScaffoldShedType :" + CS.GetAttributeValue<OptionSetValue>(SHScopeofWorkAttributeNames.shedType).Value);
                    CS.Attributes.Remove(SHScopeofWorkAttributeNames.GotoJobFiling);
                    CS.Attributes.Remove(SHScopeofWorkAttributeNames.SHScopeofWorkId);
                    CS.Attributes.Add(SHScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("ScaffoldScopeofWorkAttributeNames CS ID :" + CS.Id.ToString());
                }
                #endregion

                return CS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return CS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateScopeofWorklist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
        }

        public static Entity CreateWorkCostDetailslist(IOrganizationService service, Entity currentWorkCostDetailsRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity WCD = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(WorkCostDetailsAttributeNames.EntityLogicalName, currentWorkCostDetailsRecord.Id, columns);


                WCD = EntityExtensions.Clone(response, false);
                WCD.Attributes.Remove(WorkCostDetailsAttributeNames.GoToJobFiling);
                WCD.Attributes.Remove(WorkCostDetailsAttributeNames.WorkCostDetailsId);
                WCD.Attributes.Add(WorkCostDetailsAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                WCD.Id = Guid.NewGuid();
                crmTrace.AppendLine("WCD ID :" + WCD.Id.ToString());

                return WCD;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return WCD;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return WCD;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkCostDetailslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return WCD;
            }
        }
        public static Entity CreateZoningCharacteristicslist(IOrganizationService service, Entity currentZoningCharacteristicsRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity ZC = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(ZoningCharactersticsPW1AttributeNames.EntityLogicalName, currentZoningCharacteristicsRecord.Id, columns);


                ZC = EntityExtensions.Clone(response, false);
                ZC.Attributes.Remove(ZoningCharactersticsPW1AttributeNames.JobFilingGuid);
                ZC.Attributes.Remove(ZoningCharactersticsPW1AttributeNames.ZoningCharactersticsId);
                ZC.Attributes.Add(ZoningCharactersticsPW1AttributeNames.JobFilingGuid, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                ZC.Id = Guid.NewGuid();
                crmTrace.AppendLine("ZC ID :" + ZC.Id.ToString());

                return ZC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return ZC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return ZC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateZoningCharacteristicslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return ZC;
            }
        }

        public static Entity CreatePlaceOfAssemblyInformation(IOrganizationService service, Entity currentplaceofassemblyinformationRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity PAS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, currentplaceofassemblyinformationRecord.Id, columns);

                PAS = EntityExtensions.Clone(response, false);
                PAS.Attributes.Remove(PlaceofAssemblySpaceInformation.jobFilingID);
                PAS.Attributes.Remove(PlaceofAssemblySpaceInformation.ID);
                PAS.Attributes.Remove(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                PAS.Attributes.Remove(PlaceofAssemblySpaceInformation.IntendtochangeOwnerLessee);
                //Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute,JobFilingEntityAttributeName.CurrentFilingStatusAttributeName));
                //PAS.Attributes[PlaceofAssemblySpaceInformation.Name] = JF.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute) + "-PA";
                PAS.Attributes.Add(PlaceofAssemblySpaceInformation.jobFilingID, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                PAS.Id = Guid.NewGuid();
                crmTrace.AppendLine("PAS ID :" + PAS.Id.ToString());

                return PAS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PAS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PAS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PAS;
            }
        }

        public static Entity CreateTemporaryPlaceOfAssemblyInformation(IOrganizationService service, Entity currentTPARecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity TPA = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(TempororayPlaceOfAssembly.EntityLogicalName, currentTPARecord.Id, columns);

                TPA = EntityExtensions.Clone(response, false);
                TPA.Attributes.Remove(TempororayPlaceOfAssembly.jobfilingLookup);
                TPA.Attributes.Remove(TempororayPlaceOfAssembly.ID);
                TPA.Attributes.Add(TempororayPlaceOfAssembly.jobfilingLookup, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                TPA.Id = Guid.NewGuid();
                crmTrace.AppendLine("TPA ID :" + TPA.Id.ToString());

                return TPA;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return TPA;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TPA;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateTemporaryPlaceOfAssemblyInformation", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TPA;
            }
        }
        public static Entity CreatePlaceOfAssemblyPlans(IOrganizationService service, Entity currentplaceofassemblyrecord, Guid PlaceofAssemblySpaceInfoInitial, StringBuilder crmTrace)
        {
            Entity PAS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(PlaceofAssemblyPlans.EntityLogicalName, currentplaceofassemblyrecord.Id, columns);

                PAS = EntityExtensions.Clone(response, false);
                PAS.Attributes.Remove(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup);
                PAS.Attributes.Remove(PlaceofAssemblyPlans.ID);
                PAS.Attributes.Add(PlaceofAssemblyPlans.placeofassemblyspaceinformationLookup, new EntityReference(PlaceofAssemblySpaceInformation.EntityLogicalName, PlaceofAssemblySpaceInfoInitial));
                PAS.Id = Guid.NewGuid();
                crmTrace.AppendLine("PAS ID :" + PAS.Id.ToString());

                return PAS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PAS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PAS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PlaceofAssemblySpaceInfoInitial.ToString(), SourceChannel.CRM, "PAAHandler - CreatePlaceOfAssemblyPlans", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PAS;
            }
        }

        public static Entity CreateTPAEventDates(IOrganizationService service, Entity currentTPAEventrecord, Guid Temporaryplaceofassembly, StringBuilder crmTrace)
        {
            Entity TPAEventDate = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(TPAEventDates.EntityLogicalName, currentTPAEventrecord.Id, columns);

                TPAEventDate = EntityExtensions.Clone(response, false);
                TPAEventDate.Attributes.Remove(TPAEventDates.TPALookup);
                TPAEventDate.Attributes.Remove(TPAEventDates.ID);
                TPAEventDate.Attributes.Add(TPAEventDates.TPALookup, new EntityReference(TPAEventDates.EntityLogicalName, Temporaryplaceofassembly));
                TPAEventDate.Id = Guid.NewGuid();
                crmTrace.AppendLine("TPAEventDate ID :" + TPAEventDate.Id.ToString());

                return TPAEventDate;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return TPAEventDate;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TPAEventDate;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(Temporaryplaceofassembly.ToString(), SourceChannel.CRM, "PAAHandler - CreateTPAEventDates", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return TPAEventDate;
            }
        }
        public static Entity CreateSpecialInspectionCategorieslist(IOrganizationService service, Entity currentSpecialInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity SIC = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, currentSpecialInspectionCategoriesRecord.Id, columns);


                SIC = EntityExtensions.Clone(response, false);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectionCategoriesId);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.CreatedFrom);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.FilingType);
                SIC.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                SIC.Attributes.Add(SpecialInspectionCategoriesAttributeNames.FilingType, new OptionSetValue((int)FilingType.NewJobFiling));
                SIC.Attributes[SpecialInspectionCategoriesAttributeNames.IsCopiedfromPAA] = true;
                SIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("SIC ID :" + SIC.Id.ToString());

                return SIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return SIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateSpecialInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
        }

        public static Entity CreateProgressInspectionCategorieslist(IOrganizationService service, Entity currentProgressInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity PIC = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(ProgressInspectionCategoryAttributeNames.EntityLogicalName, currentProgressInspectionCategoriesRecord.Id, columns);


                PIC = EntityExtensions.Clone(response, false);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ProgressInspectionCategoryId);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.CreatedFrom);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.FilingType);
                PIC.Attributes.Add(ProgressInspectionCategoryAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                PIC.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue((int)FilingType.NewJobFiling));
                PIC.Attributes[ProgressInspectionCategoryAttributeNames.IsCopiedfromPAA] = true;
                PIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("PIC ID :" + PIC.Id.ToString());

                return PIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateProgressInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
        }

        public static Entity CreateDocumentlist(IOrganizationService service, Entity currentDocumentRecord, Entity specialorProgressInspectionRecord, StringBuilder crmTrace)
        {
            Entity Doc = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(DocumentListEntityAttributeName.EntityLogicalName, currentDocumentRecord.Id, columns);

                crmTrace.AppendLine("specialorProgressInspectionRecord ID :" + specialorProgressInspectionRecord.Id.ToString());
                Doc = EntityExtensions.Clone(response, false);
                if (specialorProgressInspectionRecord.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                {
                    Doc.Attributes.Remove(DocumentListEntityAttributeName.GotoSpecialInspection);
                    Doc.Attributes.Add(DocumentListEntityAttributeName.GotoSpecialInspection, new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, specialorProgressInspectionRecord.Id));

                }
                if (specialorProgressInspectionRecord.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                {
                    Doc.Attributes.Remove(DocumentListEntityAttributeName.GotoProgressInspection);
                    Doc.Attributes.Add(DocumentListEntityAttributeName.GotoProgressInspection, new EntityReference(ProgressInspectionCategoryAttributeNames.EntityLogicalName, specialorProgressInspectionRecord.Id));
                }

                Doc.Id = Guid.NewGuid();
                Doc.Attributes.Remove(DocumentListEntityAttributeName.DocumentListId);
                crmTrace.AppendLine("Doc ID :" + Doc.Id.ToString());

                return Doc;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return Doc;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
        }

        public static EntityCollection GetDocumentRegarding_SICandPIC(IOrganizationService service, Entity specialorProgressInspectionRecord, StringBuilder crmTrace)
        {
            EntityCollection Doc = new EntityCollection();
            try
            {
                string progressInspCondition = @"<condition attribute='dobnyc_gotoprogressinspection' operator='eq' uitype='dobnyc_progressinspectioncategory' value='" + specialorProgressInspectionRecord.Id + @"' />";
                string specialInspCondition = @"<condition attribute='dobnyc_gotospecialinspection' operator='eq' uitype='dobnyc_specialinspectioncategories' value='" + specialorProgressInspectionRecord.Id + @"' />";

                string fetchXML = @"<?xml version='1.0'?>
                                <fetch distinct='false' mapping='logical' no-lock='true' output-format='xml-platform' version='1.0'>
                                  <entity name='dobnyc_documentlist'>
                                    <all-attributes />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_parentdocument' operator='null' />
                                      <condition attribute='statuscode' operator='eq' value='1' />
                                      {0}
                                    </filter>
                                  </entity>
                                </fetch>";

                string fetchXMLToExecute = string.Empty;

                if (specialorProgressInspectionRecord.LogicalName == SpecialInspectionCategoriesAttributeNames.EntityLogicalName)
                {
                    fetchXMLToExecute = string.Format(fetchXML, specialInspCondition);
                }
                if (specialorProgressInspectionRecord.LogicalName == ProgressInspectionCategoryAttributeNames.EntityLogicalName)
                {
                    fetchXMLToExecute = string.Format(fetchXML, progressInspCondition);
                }

                crmTrace.AppendLine("fetchXMLToExecute :" + fetchXMLToExecute);

                if (fetchXMLToExecute != string.Empty)
                {
                    Doc = service.RetrieveMultiple(new FetchExpression(fetchXMLToExecute));
                }
                crmTrace.AppendLine("Doc Count :" + Doc.Entities.Count);

                return Doc;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return Doc;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(specialorProgressInspectionRecord.Id.ToString(), SourceChannel.CRM, "PAAHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
        }

        public static EntityCollection GetAffectedAddress_SFSWSSCopeOfWorks(IOrganizationService service, Entity ScopeOfWork, StringBuilder crmTrace)
        {
            EntityCollection Doc = new EntityCollection();
            try
            {
                string swsCondition = @" <condition attribute='dobnyc_f4_addr_sidewalkshedscopeofwork' operator='eq'  uitype='dobnyc_sidewalkshedscopeofwork' value='" + ScopeOfWork.Id + @"' />";
                string sfCondition = @" <condition attribute='dobnyc_addr_scaffoldscopeofwork' operator='eq'  uitype='dobnyc_scaffoldscopeofwork' value='" + ScopeOfWork.Id + @"' />";

                string fetchXML = @"<?xml version='1.0'?>
                                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_dobaddress'>
                                    <attribute name='dobnyc_addr_streetname' />
                                    <attribute name='dobnyc_addr_housenumber' />
                                    <attribute name='dobnyc_addr_borough' />
                                    <attribute name='dobnyc_dobaddressid' />
                                    <order attribute='dobnyc_addr_borough' descending='false' />
                                    <filter type='and'>
                                     {0}
                                    </filter>
                                  </entity>
                                </fetch>";

                string fetchXMLToExecute = string.Empty;

                if (ScopeOfWork.LogicalName == SHScopeofWorkAttributeNames.EntityLogicalName)
                {
                    fetchXMLToExecute = string.Format(fetchXML, swsCondition);
                }
                if (ScopeOfWork.LogicalName == ScaffoldScopeofWorkAttributeNames.EntityLogicalName)
                {
                    fetchXMLToExecute = string.Format(fetchXML, sfCondition);
                }

                crmTrace.AppendLine("fetchXMLToExecute :" + fetchXMLToExecute);

                if (fetchXMLToExecute != string.Empty)
                {
                    Doc = service.RetrieveMultiple(new FetchExpression(fetchXMLToExecute));
                }
                crmTrace.AppendLine("Doc Count :" + Doc.Entities.Count);

                return Doc;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return Doc;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ScopeOfWork.Id.ToString(), SourceChannel.CRM, "PAAHandler - GetAffectedAddress_SFSWSSCopeOfWorks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return Doc;
            }
        }

        public static void DeleteEntityCollection(IOrganizationService service, EntityCollection removeList, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest RemoveRequestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };

                crmTrace.AppendLine(" Request object created");

                // Creates requests for each removeDocumentList record
                crmTrace.AppendLine(" Creating DeleteRequest requests for each removeList record and adding them to Request Object");
                foreach (var entity in removeList.Entities)
                {
                    DeleteRequest deleteRequest = new DeleteRequest { Target = entity.ToEntityReference() };
                    RemoveRequestWithResults.Requests.Add(deleteRequest);
                }
                crmTrace.AppendLine(" DeleteRequest Created requests for each removeList record and added to Request Object");

                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse RemoveResponseWithResults = (ExecuteMultipleResponse)service.Execute(RemoveRequestWithResults);
                foreach (var responseItem in RemoveResponseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Fault.Message);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        } // DeleteEntityCollection Method ends here

        public static void DeleteEntityCollection2(IOrganizationService service, EntityCollection removeList, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Deleting EntityCollection Records");

                foreach (Entity record in removeList.Entities)
                {
                    crmTrace.AppendLine("record.LogicalName: " + record.LogicalName);
                    crmTrace.AppendLine("record.Id: " + record.Id);
                    service.Delete(record.LogicalName, record.Id);
                }

                crmTrace.AppendLine("Done Deleting EntityCollection Records");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateEntityCollection(IOrganizationService service, EntityCollection createList, StringBuilder crmTrace)
        {
            string trackingGuid = Guid.NewGuid().ToString();
            try
            { // Will Create an ExecuteMultipleRequest object (requestWithResults).
                crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };
                crmTrace.AppendLine(" Request object created");
                // Creates requests for each createList record

                crmTrace.AppendLine(" Creating CreateRequest requests for each createList record and adding them to Request Object");
                foreach (var entity in createList.Entities)
                {
                    CreateRequest createRequest = new CreateRequest { Target = entity };
                    requestWithResults.Requests.Add(createRequest);
                }
                crmTrace.AppendLine(" CreateRequest Created requests for each createList record and added to Request Object");

                // Execute
                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

                foreach (var responseItem in responseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Fault);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }  // CreateEntityCollection Method ends here

        public static void CreateEntityCollection2(IOrganizationService service, EntityCollection createList, StringBuilder crmTrace)
        {
            string trackingGuid = Guid.NewGuid().ToString();
            try
            {
                crmTrace.AppendLine("Creating EntityCollection Records");

                foreach (Entity record in createList.Entities)
                {
                    crmTrace.AppendLine("record.LogicalName: " + record.LogicalName);
                    crmTrace.AppendLine("record.Id: " + record.Id);
                    //throw new Exception("record.LogicalName: " + record.LogicalName + "===" + "record.Id: " + record.Id);
                    service.Create(record);
                }

                crmTrace.AppendLine("Done Creating EntityCollection Records");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }

        public static void CreateEntities_FromDictionary(IOrganizationService service, Dictionary<Entity, Entity> entityDict, StringBuilder crmTrace)
        {
            string trackingGuid = Guid.NewGuid().ToString();
            try
            {
                crmTrace.AppendLine("Creating Entity Records");

                foreach (KeyValuePair<Entity, Entity> kvp in entityDict)
                {
                    if (kvp.Key != null)
                    {
                        crmTrace.AppendLine("Key Value pair is not null");
                        Entity SICorPICRecord = kvp.Key;
                        Entity oldDocumentRecord = kvp.Value;
                        crmTrace.AppendLine("SICorPICRecord.LogicalName: " + SICorPICRecord.LogicalName);
                        Guid recordGuid = service.Create(SICorPICRecord);
                        crmTrace.AppendLine("SICorPICRecord.Id: " + SICorPICRecord.Id);
                        if (oldDocumentRecord != null)
                        {
                            crmTrace.AppendLine("oldDocumentRecord.Id: " + oldDocumentRecord.Id);
                            crmTrace.AppendLine("Creating Document Records");
                            Entity newDocRecord = CreateDocumentlist(service, oldDocumentRecord, SICorPICRecord, crmTrace);
                            crmTrace.AppendLine("newDocRecord.id: " + newDocRecord.Id);
                            service.Create(newDocRecord);
                            crmTrace.AppendLine("Created Document Records");
                        }
                    }
                }

                crmTrace.AppendLine("Done Creating Entity Records");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "PAAHandler - CreateEntities_FromDictionary", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }

        public static EntityCollection RetrieveRelatedEntities(IOrganizationService service, Guid targetEntityGuid, string RelatedEntitySchemaName, string RelationshipName)
        {
            ConditionExpression responseCondition = CreateConditionExpression(RelationshipName, ConditionOperator.Equal, new string[] { targetEntityGuid.ToString() });
            FilterExpression filterExpression = new FilterExpression();
            filterExpression.Conditions.AddRange(responseCondition);
            filterExpression.FilterOperator = LogicalOperator.And;

            ColumnSet columns = new ColumnSet(true);
            QueryExpression qe = new QueryExpression();
            qe.EntityName = RelatedEntitySchemaName;
            qe.ColumnSet = new ColumnSet(true);
            qe.Criteria = filterExpression;
            qe.NoLock = true;
            EntityCollection response = service.RetrieveMultiple(qe);


            return response;
        }

        #region Set new value based on type
        private static string SetNewValueBasedOnType(IOrganizationService service, Entity targetEntity, StringBuilder customTrace, Entity preImage, KeyValuePair<string, string> item)
        {
            string newValue = string.Empty;
            try
            {
                customTrace.AppendLine("SetNewValueBasedOnType Started!");
                customTrace.AppendLine("item.Key: " + item.Key);

                string type = string.Empty;

                if (string.IsNullOrEmpty(item.Value))
                {
                    if (targetEntity.Attributes.Contains(item.Key))
                    {
                        if (targetEntity.Attributes[item.Key.ToString()] != null)
                        {
                            if (targetEntity.Attributes[item.Key.ToString()].GetType() != null)
                            {
                                type = targetEntity.Attributes[item.Key.ToString()].GetType().ToString();
                            }
                        }
                    }
                }
                else
                {
                    if (preImage.Attributes.Contains(item.Key))
                    {
                        if (preImage.Attributes[item.Key.ToString()] != null)
                        {
                            if (preImage.Attributes[item.Key.ToString()].GetType() != null)
                            {
                                type = preImage.Attributes[item.Key.ToString()].GetType().ToString();
                            }
                        }
                    }
                }
                customTrace.AppendLine("Get Type :" + type);
                if (type.Equals("Microsoft.Xrm.Sdk.OptionSetValue"))
                {
                    OptionSetValue optionsetObj = targetEntity.GetAttributeValue<OptionSetValue>(item.Key.ToString());
                    if (optionsetObj != null)
                    {
                        int optionsetvalue = optionsetObj.Value;
                        customTrace.AppendLine("Get Values :" + optionsetvalue);
                        string optionsetText = GetOptionsSetTextOnValue(service, targetEntity.LogicalName, item.Key.ToString(), optionsetvalue);
                        customTrace.AppendLine("optionsetText: " + optionsetText);
                        newValue = optionsetText;
                    }
                    else
                    {
                        newValue = string.Empty;
                    }

                }
                else if (type.Equals("Microsoft.Xrm.Sdk.Money"))
                {
                    Money moneyObj = targetEntity.GetAttributeValue<Money>(item.Key.ToString());
                    if (moneyObj != null)
                    {
                        newValue = moneyObj.Value.ToString();

                    }
                    else
                    {
                        newValue = string.Empty;
                    }
                }
                else if (type.Equals("Microsoft.Xrm.Sdk.EntityReference"))
                {
                    EntityReference refobj = targetEntity.GetAttributeValue<EntityReference>(item.Key.ToString());
                    if (refobj != null)
                    {
                        if (refobj.LogicalName == "contact")
                        {
                            Entity refEntity = Retrieve(service, new string[] { "fullname" }, refobj.Id, refobj.LogicalName);
                            string lookupName = refEntity.Attributes["fullname"].ToString();
                            newValue = lookupName;
                        }
                        else
                        {
                            Entity refEntity = Retrieve(service, new string[] { "dobnyc_name" }, refobj.Id, refobj.LogicalName);
                            string lookupName = refEntity.Attributes["dobnyc_name"].ToString();
                            newValue = lookupName;
                        }
                    }
                    else
                    {
                        newValue = string.Empty;
                    }
                }
                else if (type.Equals("System.DateTime"))
                {
                    DateTime dateObj = targetEntity.GetAttributeValue<DateTime>(item.Key.ToString());
                    if (dateObj == DateTime.MinValue)
                    {
                        newValue = string.Empty;

                    }
                    else
                    {
                        newValue = dateObj.ToString();

                    }
                }
                else if (type.Equals("System.Boolean"))
                {
                    bool boolObj = targetEntity.GetAttributeValue<bool>(item.Key.ToString());
                    if (boolObj)
                    {
                        newValue = "Yes";
                    }
                    else
                    {
                        newValue = "No";
                    }
                }
                else if (type.Equals("System.Double"))
                {
                    double value = targetEntity.GetAttributeValue<double>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.Int32"))
                {
                    int value = targetEntity.GetAttributeValue<int>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.Decimal"))
                {
                    decimal value = targetEntity.GetAttributeValue<decimal>(item.Key.ToString());
                    newValue = value.ToString();
                }
                else if (type.Equals("System.String"))
                {
                    string value = targetEntity.GetAttributeValue<string>(item.Key.ToString());
                    if (string.IsNullOrEmpty(value))
                    {
                        newValue = string.Empty;
                    }
                    else
                    {
                        newValue = value;
                    }
                }
                customTrace.AppendLine("SetNewValueBasedOnType Ended!");
                return newValue;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return newValue;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newValue;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", null, customTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "PAAHandler - SetNewValueBasedOnType", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return newValue;
            }
        }
        #endregion
        #region Get Text from optioset value
        public static string GetOptionsSetTextOnValue(IOrganizationService service, string entityName, string attributeName, int selectedValue)
        {
            try
            {
                OptionMetadata[] optionList = null;
                RetrieveAttributeRequest retrieveAttributeRequest = new
                RetrieveAttributeRequest
                {

                    EntityLogicalName = entityName,

                    LogicalName = attributeName,

                    RetrieveAsIfPublished = true

                };
                // Execute the request.
                RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                string restype = retrieveAttributeResponse.AttributeMetadata.GetType().ToString();
                // Access the retrieved attribute.
                if (restype == "Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata")
                {
                    Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata stateatt = (Microsoft.Xrm.Sdk.Metadata.StateAttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
                    optionList = stateatt.OptionSet.Options.ToArray();
                }
                else if (restype == "Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata")
                {
                    Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata retrievedPicklistAttributeMetadata = (Microsoft.Xrm.Sdk.Metadata.PicklistAttributeMetadata)

                    retrieveAttributeResponse.AttributeMetadata;// Get the current options list for the retrieved attribute.
                    optionList = retrievedPicklistAttributeMetadata.OptionSet.Options.ToArray();
                }
                string selectedOptionLabel = string.Empty;
                foreach (OptionMetadata oMD in optionList)
                {
                    if (oMD.Value == selectedValue)
                    {
                        selectedOptionLabel = oMD.Label.UserLocalizedLabel.Label;

                    }

                }
                return selectedOptionLabel;
                //crmTrace.AppendLine("Retrieve OptionText completed!");
            }
            catch (Exception ex)
            {
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "GetOptionsSetTextOnValue", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", (ex.InnerException != null ? ex.InnerException.ToString() : string.Empty), "browserinfo");
                return "Exception";

            }

        }
        #endregion
        #region Get Values from Entity PW1 Section
        public static Dictionary<string, string> PW1ImageValues(Entity preImage, StringBuilder crmTrace)
        {

            #region Get Pre Image values for PW1 Section
            #region Variable Declaration
            string PlumbingCheckBox = string.Empty;
            string SprinklerCheckBox = string.Empty;
            string EstimatedJobCost = string.Empty;
            string EstimatedJobCostLegal = string.Empty;
            string TotalConstructionFloorArea = string.Empty;
            string Reviewisrequestedunderwhichbuildingcode = string.Empty;
            string LittleEorRDSite = string.Empty;
            string UnmappedCCOStreet = string.Empty;
            string RequestingLegalizationofworkwherenowork = string.Empty;
            string Workincludespermanentremovalofstandpipe = string.Empty;
            string CompliacnewiththeNYCECC = string.Empty;
            string CodeCompliancePath = string.Empty;
            string EnergyAnalysis = string.Empty;
            string ExemptfromtheNYCECC = string.Empty;
            string ProfessionaljudgementallworkisExempt = string.Empty;
            string ExistingFireAlarm = string.Empty;
            string ProposedFireAlarm = string.Empty;
            string ExisitingFireSuppression = string.Empty;
            string ProposedFireSuppression = string.Empty;
            string ExisitingSprinkler = string.Empty;
            string ProposedSprinkler = string.Empty;
            string Mixedusebuilding = string.Empty;
            string ExisitingBuildingStories = string.Empty;
            string ProposeeBuildingStories = string.Empty;
            string ExistingBuildingHeight = string.Empty;
            string ProposedBuildingHeight = string.Empty;
            string ExistingDwellingUnits = string.Empty;
            string ProposedDwellingUnits = string.Empty;
            string JobDescription = string.Empty;//dobnyc_jobdescription
            string JobDescriptionLeg = string.Empty;//dobnyc_jobdescriptionlegalization

            //created by SN on 11/19/2018 for new fields
            string MSWorkIncludesRaisingorMoving = string.Empty;
            string STWorkOnInterior = string.Empty;
            string STWorkOnExterior = string.Empty;
            string STRemovingOneOrMoreStories = string.Empty;
            string STDemolishing50OrMore = string.Empty;
            string STAlternativeMaterialsOTCR = string.Empty;
            #region ANCC
            string IsStructuralWorkIncluded = string.Empty;
            string IsAntennaOneMeterinDiameter = string.Empty;
            string OccupyMoreThan5Percent = string.Empty;
            string ExtendHigherThan6Feet = string.Empty;
            string CRFNZoningExhibit = string.Empty;
            string BSACalendarNumbers = string.Empty;
            string ProvideBSACalendarNumbers = string.Empty;
            string CPCCalendarNumbers = string.Empty;
            string ProvideCPCCalendarNumbers = string.Empty;
            string HighRiseTeamTrackingNumber = string.Empty;
            string WorkIncludesPartialDemolition = string.Empty;
            string StructuralStabilityAffected = string.Empty;
            string RelatedDOBJobNumbers = string.Empty;
            string Districts = string.Empty;
            string Overlays = string.Empty;
            string SpecialDistricts = string.Empty;
            string MapNumber = string.Empty;
            string Directive14 = string.Empty;
            string CurbCutWorkType = string.Empty;
            string AntennaWorkType = string.Empty;
            string AlternateJobInBISAssociation = string.Empty;
            string RelatedAltBISJobNumbers = string.Empty;
            string EstimatedNewWorkFinalCost = string.Empty;

            string FacadeAlternation = string.Empty; //Two Options
            string AdultEstablishment = string.Empty; //Two Options
            string QualityHousing = string.Empty; //Two Options
            string IsConjunctionJob = string.Empty; //Two Options
            string BisRelatedJobNumber = string.Empty; //String
            string CRFNRestrictiveDeclaration = string.Empty; // Two Options
            string CRFNNumber1 = string.Empty; //String
            string CRFNNumber2 = string.Empty; //String
            string CRFNNumber3 = string.Empty; //String
            string CRFNNumber4 = string.Empty; //String
            string CRFNZoningExhibitNumber1 = string.Empty; //String
            string CRFNZoningExhibitNumber2 = string.Empty; //String
            string CRFNZoningExhibitNumber3 = string.Empty; //String
            string CRFNZoningExhibitNumber4 = string.Empty; //String
            string IsFilingtoAddressViolations = string.Empty; //Two Options
            string ListViolationsDOBECB = string.Empty; //String
            string ECBNumbers = string.Empty; //String
            string OccupancyClassification = string.Empty; //Option Set
            string ConstructionClassification = string.Empty; //Option Set
            string MultipleDwellingClassification = string.Empty; //Option Set
            string SiteCharacteristicsTidalWastelands = string.Empty; //Two Options
            string SiteCharacteristicsCoastalErosionHazardArea = string.Empty; //Two Options
            string SiteCharacteristicsFireDistrict = string.Empty; //Two Options
            string SiteCharacteristicsFreshwaterWetlands = string.Empty; //Two Options
            string SiteCharacteristicsUrbanRenewal = string.Empty; //Two Options
            string SiteCharacteristicsFloodHazardArea = string.Empty; //Two Options
            string FloodHzAreaIsSubstantialImprovement = string.Empty; //Two Options
            string IsFloodHzAreaSubstantiallyDamaged = string.Empty; //Two Options
            string FloodHzAreaFloodShieldsProposedWork = string.Empty; //Two Options
            string AsbestosAbatementCompliance = string.Empty; // Option Set
            string DEPACPControlNoAttributeName = string.Empty; //String
            string CommentsPWAttributeName = string.Empty; //String
            string ComplyingToLocalLaws = string.Empty; //Two Options
            string ListOfLawNumbers = string.Empty; //String


            //ST created by SN on 01/16/2019

            string ApplicableStatSection = string.Empty; //String
            string Easementaggrementname = string.Empty; //String
            string Associatedbuildingsbulletinnumber = string.Empty; //String


            string Modularconstnystate = string.Empty; //String
            string Modularconstnystatenyc = string.Empty; //String
            string Buildinggreater = string.Empty; //String
            string Buildingsgrossfloorarea = string.Empty; //String
            string Areallaspectratiossixorless = string.Empty; //String
            string Specialseismicenergy = string.Empty; //String
            string Doesthebuildingincludeany = string.Empty; //String
            string Isthebuildingincludedinstructural = string.Empty; //String
            string Buildinghavemorethan50000squarefeet = string.Empty; //String
            string Doanyelementsexcept = string.Empty; //String
            string Structuralpeerreview = string.Empty; //String
            string Yearforlocallaws = string.Empty;

            #endregion

            #region MS Fields
            string HeatingSystem = string.Empty;
            string VentilationSystem = string.Empty;
            string AirConditioningSystem = string.Empty;
            string Refrigeration = string.Empty;
            string CoolingTowers = string.Empty;
            string AssociatedDuctsAndPiping = string.Empty;
            string Generator = string.Empty;
            string Other = string.Empty;
            string OtherValues = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            #endregion



            try
            {
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Yearforlocallaws))
                {
                    crmTrace.AppendLine("Retrieve Yearforlocallaws");
                    Yearforlocallaws = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Yearforlocallaws).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Yearforlocallaws, Yearforlocallaws);
                    crmTrace.AppendLine("Retrieve JobDescription:" + Yearforlocallaws);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Yearforlocallaws, string.Empty);
                }

                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ApplicableStatSection))
                {
                    crmTrace.AppendLine("Retrieve ApplicableStatSection");
                    ApplicableStatSection = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ApplicableStatSection).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ApplicableStatSection, ApplicableStatSection);
                    crmTrace.AppendLine("Retrieve JobDescription:" + ApplicableStatSection);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ApplicableStatSection, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Easementaggrementname))
                {
                    crmTrace.AppendLine("Retrieve Easementaggrementname");
                    Easementaggrementname = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Easementaggrementname).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Easementaggrementname, Easementaggrementname);
                    crmTrace.AppendLine("Retrieve Easementaggrementname:" + Easementaggrementname);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Easementaggrementname, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber))
                {
                    crmTrace.AppendLine("Retrieve Associatedbuildingsbulletinnumber");
                    Associatedbuildingsbulletinnumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, Associatedbuildingsbulletinnumber);
                    crmTrace.AppendLine("Retrieve Associatedbuildingsbulletinnumber:" + Associatedbuildingsbulletinnumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Associatedbuildingsbulletinnumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Structuralpeerreview");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Structuralpeerreview))
                {
                    Structuralpeerreview = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Structuralpeerreview);
                    imageValues.Add(JobFilingEntityAttributeName.Structuralpeerreview, Structuralpeerreview);
                    crmTrace.AppendLine("Retrieve Structuralpeerreview:" + Structuralpeerreview);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Structuralpeerreview, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Doanyelementsexcept");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Doanyelementsexcept))
                {
                    Doanyelementsexcept = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Doanyelementsexcept);
                    imageValues.Add(JobFilingEntityAttributeName.Doanyelementsexcept, Doanyelementsexcept);
                    crmTrace.AppendLine("Retrieve Doanyelementsexcept:" + Doanyelementsexcept);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Doanyelementsexcept, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Buildinghavemorethan50000squarefeet");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet))
                {
                    Buildinghavemorethan50000squarefeet = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet);
                    imageValues.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, Buildinghavemorethan50000squarefeet);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildinghavemorethan50000squarefeet);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildinghavemorethan50000squarefeet, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Isthebuildingincludedinstructural");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Isthebuildingincludedinstructural))
                {
                    Isthebuildingincludedinstructural = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Isthebuildingincludedinstructural);
                    imageValues.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, Isthebuildingincludedinstructural);
                    crmTrace.AppendLine("Retrieve Isthebuildingincludedinstructural:" + Isthebuildingincludedinstructural);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Isthebuildingincludedinstructural, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Doesthebuildingincludeany");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Doesthebuildingincludeany))
                {
                    Doesthebuildingincludeany = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Doesthebuildingincludeany);
                    imageValues.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, Doesthebuildingincludeany);
                    crmTrace.AppendLine("Retrieve Doesthebuildingincludeany:" + Doesthebuildingincludeany);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Doesthebuildingincludeany, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Specialseismicenergy");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Specialseismicenergy))
                {
                    Specialseismicenergy = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Specialseismicenergy);
                    imageValues.Add(JobFilingEntityAttributeName.Specialseismicenergy, Specialseismicenergy);
                    crmTrace.AppendLine("Retrieve Specialseismicenergy:" + Specialseismicenergy);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Specialseismicenergy, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Areallaspectratiossixorless");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Areallaspectratiossixorless))
                {
                    Areallaspectratiossixorless = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Areallaspectratiossixorless);
                    imageValues.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, Areallaspectratiossixorless);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Areallaspectratiossixorless);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Areallaspectratiossixorless, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Buildingsgrossfloorarea");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildingsgrossfloorarea))
                {
                    Buildingsgrossfloorarea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildingsgrossfloorarea);
                    imageValues.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, Buildingsgrossfloorarea);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildingsgrossfloorarea);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildingsgrossfloorarea, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Buildinggreater");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Buildinggreater))
                {
                    Buildinggreater = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Buildinggreater);
                    imageValues.Add(JobFilingEntityAttributeName.Buildinggreater, Buildinggreater);
                    crmTrace.AppendLine("Retrieve Buildinggreater:" + Buildinggreater);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Buildinggreater, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Modularconstnystatenyc");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystatenyc))
                {
                    Modularconstnystatenyc = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Modularconstnystatenyc);
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, Modularconstnystatenyc);
                    crmTrace.AppendLine("Retrieve Modularconstnystatenyc:" + Modularconstnystatenyc);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystatenyc, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Modularconstnystate");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Modularconstnystate))
                {
                    Modularconstnystate = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Modularconstnystate);
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystate, Modularconstnystate);
                    crmTrace.AppendLine("Retrieve Modularconstnystate:" + Modularconstnystate);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Modularconstnystate, string.Empty);
                }
                crmTrace.AppendLine("Retrieve PlumbingCheckBox");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    PlumbingCheckBox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.PlumbingCheckBox);
                    imageValues.Add(JobFilingEntityAttributeName.PlumbingCheckBox, PlumbingCheckBox);
                    crmTrace.AppendLine("Retrieve PlumbingCheckBox:" + PlumbingCheckBox);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.PlumbingCheckBox, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SprinklerCheckBox");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    SprinklerCheckBox = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SprinklerCheckBox);
                    imageValues.Add(JobFilingEntityAttributeName.SprinklerCheckBox, SprinklerCheckBox);
                    crmTrace.AppendLine("Retrieve SprinklerCheckBox:" + SprinklerCheckBox);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SprinklerCheckBox, string.Empty);
                }

                crmTrace.AppendLine("Retrieve EstimatedJobCost");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCost))
                {
                    Money jobcost = ((Money)(preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCost]));
                    EstimatedJobCost = jobcost.Value.ToString();
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCost, EstimatedJobCost);
                    crmTrace.AppendLine("Retrieve EstimatedJobCost:" + EstimatedJobCost);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCost, string.Empty);
                }
                crmTrace.AppendLine("Retrieve EstimatedJobCostLeg");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedJobCostLegal))
                {
                    Money jobcost = ((Money)(preImage.Attributes[JobFilingEntityAttributeName.EstimatedJobCostLegal]));
                    EstimatedJobCostLegal = jobcost.Value.ToString();
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, EstimatedJobCostLegal);
                    crmTrace.AppendLine("Retrieve EstimatedJobCostLegal:" + EstimatedJobCostLegal);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedJobCostLegal, string.Empty);
                }

                crmTrace.AppendLine("Retrieve TotalConstructionFloorArea");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.TotalConstructionFloorArea))
                {
                    TotalConstructionFloorArea = (preImage.GetAttributeValue<double>(JobFilingEntityAttributeName.TotalConstructionFloorArea)).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.TotalConstructionFloorArea, TotalConstructionFloorArea);
                    crmTrace.AppendLine("Retrieve TotalConstructionFloorArea:" + TotalConstructionFloorArea);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.TotalConstructionFloorArea, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.JobDescription))
                {
                    crmTrace.AppendLine("Retrieve JobDescription");
                    JobDescription = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescription).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.JobDescription, JobDescription);
                    crmTrace.AppendLine("Retrieve JobDescription:" + JobDescription);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.JobDescription, string.Empty);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.JobDescriptionLeg))
                {
                    crmTrace.AppendLine("Retrieve JobDescriptionLeg");
                    JobDescriptionLeg = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobDescriptionLeg).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.JobDescriptionLeg, JobDescriptionLeg);
                    crmTrace.AppendLine("Retrieve JobDescriptionLeg:" + JobDescriptionLeg);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.JobDescriptionLeg, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode))
                {
                    Reviewisrequestedunderwhichbuildingcode = preImage.FormattedValues[JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode];
                    imageValues.Add(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode, Reviewisrequestedunderwhichbuildingcode);
                    crmTrace.AppendLine("Retrieve Reviewisrequestedunderwhichbuildingcode:" + Reviewisrequestedunderwhichbuildingcode);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Reviewisrequestedunderwhichbuildingcode, string.Empty);
                }
                crmTrace.AppendLine("Retrieve LittleEorRDSite");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.LittleEorRDSite))
                {
                    LittleEorRDSite = preImage.FormattedValues[JobFilingEntityAttributeName.LittleEorRDSite];
                    imageValues.Add(JobFilingEntityAttributeName.LittleEorRDSite, LittleEorRDSite);
                    crmTrace.AppendLine("Retrieve LittleEorRDSite:" + LittleEorRDSite);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.LittleEorRDSite, string.Empty);
                }
                crmTrace.AppendLine("Retrieve UnmappedCCOStreet");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.UnmappedCCOStreet))
                {
                    UnmappedCCOStreet = preImage.FormattedValues[JobFilingEntityAttributeName.UnmappedCCOStreet];
                    imageValues.Add(JobFilingEntityAttributeName.UnmappedCCOStreet, UnmappedCCOStreet);
                    crmTrace.AppendLine("Retrieve UnmappedCCOStreet:" + UnmappedCCOStreet);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.UnmappedCCOStreet, string.Empty);
                }
                crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork))
                {
                    RequestingLegalizationofworkwherenowork = preImage.FormattedValues[JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork];
                    imageValues.Add(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork, RequestingLegalizationofworkwherenowork);
                    crmTrace.AppendLine("Retrieve RequestingLegalizationofworkwherenowork:" + RequestingLegalizationofworkwherenowork);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.RequestingLegalizationofworkwherenowork, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe))
                {
                    Workincludespermanentremovalofstandpipe = preImage.FormattedValues[JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe];
                    imageValues.Add(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe, Workincludespermanentremovalofstandpipe);
                    crmTrace.AppendLine("Retrieve Workincludespermanentremovalofstandpipe:" + Workincludespermanentremovalofstandpipe);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Workincludespermanentremovalofstandpipe, string.Empty);
                }
                crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CompliacnewiththeNYCECC))
                {
                    CompliacnewiththeNYCECC = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CompliacnewiththeNYCECC);
                    imageValues.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, CompliacnewiththeNYCECC);
                    crmTrace.AppendLine("Retrieve CompliacnewiththeNYCECC:" + CompliacnewiththeNYCECC);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CompliacnewiththeNYCECC, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CodeCompliancePath");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CodeCompliancePath))
                {
                    CodeCompliancePath = preImage.FormattedValues[JobFilingEntityAttributeName.CodeCompliancePath];
                    imageValues.Add(JobFilingEntityAttributeName.CodeCompliancePath, CodeCompliancePath);
                    crmTrace.AppendLine("Retrieve CodeCompliancePath:" + CodeCompliancePath);
                }
                
                crmTrace.AppendLine("Retrieve EnergyAnalysis");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EnergyAnalysis))
                {
                    EnergyAnalysis = preImage.FormattedValues[JobFilingEntityAttributeName.EnergyAnalysis];
                    imageValues.Add(JobFilingEntityAttributeName.EnergyAnalysis, EnergyAnalysis);
                    crmTrace.AppendLine("Retrieve EnergyAnalysis:" + EnergyAnalysis);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.EnergyAnalysis, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExemptfromtheNYCECC))
                {
                    ExemptfromtheNYCECC = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExemptfromtheNYCECC);
                    imageValues.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, ExemptfromtheNYCECC);
                    crmTrace.AppendLine("Retrieve ExemptfromtheNYCECC:" + ExemptfromtheNYCECC);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExemptfromtheNYCECC, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt))
                {
                    ProfessionaljudgementallworkisExempt = preImage.FormattedValues[JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt];
                    imageValues.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, ProfessionaljudgementallworkisExempt);
                    crmTrace.AppendLine("Retrieve ProfessionaljudgementallworkisExempt:" + ProfessionaljudgementallworkisExempt);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProfessionaljudgementallworkisExempt, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExistingFireAlarm");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingFireAlarm))
                {
                    ExistingFireAlarm = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExistingFireAlarm);
                    imageValues.Add(JobFilingEntityAttributeName.ExistingFireAlarm, ExistingFireAlarm);
                    crmTrace.AppendLine("Retrieve ExistingFireAlarm:" + ExistingFireAlarm);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExistingFireAlarm, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposedFireAlarm");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireAlarm))
                {
                    ProposedFireAlarm = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedFireAlarm);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireAlarm, ProposedFireAlarm);
                    crmTrace.AppendLine("Retrieve ProposedFireAlarm:" + ProposedFireAlarm);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireAlarm, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExisitingFireSuppression");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingFireSuppression))
                {
                    ExisitingFireSuppression = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExisitingFireSuppression);
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, ExisitingFireSuppression);
                    crmTrace.AppendLine("Retrieve ExisitingFireSuppression:" + ExisitingFireSuppression);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingFireSuppression, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposedFireSuppression");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedFireSuppression))
                {
                    ProposedFireSuppression = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedFireSuppression);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireSuppression, ProposedFireSuppression);
                    crmTrace.AppendLine("Retrieve ProposedFireSuppression:" + ProposedFireSuppression);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposedFireSuppression, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ExisitingSprinkler");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingSprinkler))
                {
                    ExisitingSprinkler = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExisitingSprinkler);
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingSprinkler, ExisitingSprinkler);
                    crmTrace.AppendLine("Retrieve ExisitingSprinkler:" + ExisitingSprinkler);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingSprinkler, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposedSprinkler");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedSprinkler))
                {
                    ProposedSprinkler = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ProposedSprinkler);
                    imageValues.Add(JobFilingEntityAttributeName.ProposedSprinkler, ProposedSprinkler);
                    crmTrace.AppendLine("Retrieve ProposedSprinkler:" + ProposedSprinkler);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposedSprinkler, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Mixedusebuilding");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Mixedusebuilding))
                {
                    Mixedusebuilding = preImage.FormattedValues[JobFilingEntityAttributeName.Mixedusebuilding];
                    imageValues.Add(JobFilingEntityAttributeName.Mixedusebuilding, Mixedusebuilding);
                    crmTrace.AppendLine("Retrieve Mixedusebuilding:" + Mixedusebuilding);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Mixedusebuilding, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExisitingBuildingStories");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExisitingBuildingStories))
                {
                    ExisitingBuildingStories = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExisitingBuildingStories).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingBuildingStories, ExisitingBuildingStories);
                    crmTrace.AppendLine("Retrieve ExisitingBuildingStories:" + ExisitingBuildingStories);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExisitingBuildingStories, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposeeBuildingStories");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories))
                {
                    ProposeeBuildingStories = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposeeBuildingStories, ProposeeBuildingStories);
                    crmTrace.AppendLine("Retrieve ProposeeBuildingStories:" + ProposeeBuildingStories);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposeeBuildingStories, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExistingBuildingHeight");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingBuildingHeight))
                {
                    ExistingBuildingHeight = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingBuildingHeight).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExistingBuildingHeight, ExistingBuildingHeight);
                    crmTrace.AppendLine("Retrieve ExistingBuildingHeight:" + ExistingBuildingHeight);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExistingBuildingHeight, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposedBuildingHeight");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight))
                {
                    ProposedBuildingHeight = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposedBuildingHeight, ProposedBuildingHeight);
                    crmTrace.AppendLine("Retrieve ProposedBuildingHeight:" + ProposedBuildingHeight);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposedBuildingHeight, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExistingDwellingUnits");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExistingDwellingUnits))
                {
                    ExistingDwellingUnits = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ExistingDwellingUnits).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ExistingDwellingUnits, ExistingDwellingUnits);
                    crmTrace.AppendLine("Retrieve ExistingDwellingUnits:" + ExistingDwellingUnits);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExistingDwellingUnits, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ProposedDwellingUnits");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProposedDwellingUnits))
                {
                    ProposedDwellingUnits = preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedDwellingUnits).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProposedDwellingUnits, ProposedDwellingUnits);
                    crmTrace.AppendLine("Retrieve ProposedDwellingUnits:" + ProposedDwellingUnits);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProposedDwellingUnits, string.Empty);
                }

                #region ANCC
                crmTrace.AppendLine("Retrieve AlternateJobInBISAssociation");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AlternateJobInBISAssociation))
                {
                    AlternateJobInBISAssociation = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AlternateJobInBISAssociation);
                    imageValues.Add(JobFilingEntityAttributeName.AlternateJobInBISAssociation, AlternateJobInBISAssociation);
                    crmTrace.AppendLine("Retrieve AlternateJobInBISAssociation:" + AlternateJobInBISAssociation);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AlternateJobInBISAssociation, string.Empty);
                }

                crmTrace.AppendLine("Retrieve AntennaWorkType");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AntennaWorkType))
                {
                    AntennaWorkType = preImage.FormattedValues[JobFilingEntityAttributeName.AntennaWorkType];
                    imageValues.Add(JobFilingEntityAttributeName.AntennaWorkType, AntennaWorkType);
                    crmTrace.AppendLine("Retrieve AntennaWorkType:" + AntennaWorkType);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AntennaWorkType, string.Empty);
                }

                crmTrace.AppendLine("Retrieve BSACalendarNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BSACalendarNumbers))
                {
                    BSACalendarNumbers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.BSACalendarNumbers);
                    imageValues.Add(JobFilingEntityAttributeName.BSACalendarNumbers, BSACalendarNumbers);
                    crmTrace.AppendLine("Retrieve BSACalendarNumbers:" + BSACalendarNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.BSACalendarNumbers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CPCCalendarNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CPCCalendarNumbers))
                {
                    CPCCalendarNumbers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CPCCalendarNumbers);
                    imageValues.Add(JobFilingEntityAttributeName.CPCCalendarNumbers, CPCCalendarNumbers);
                    crmTrace.AppendLine("Retrieve CPCCalendarNumbers:" + CPCCalendarNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CPCCalendarNumbers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibit");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibit))
                {
                    CRFNZoningExhibit = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CRFNZoningExhibit);
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibit, CRFNZoningExhibit);
                    crmTrace.AppendLine("Retrieve CRFNZoningExhibit:" + CRFNZoningExhibit);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibit, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CurbCutWorkType");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CurbCutWorkType))
                {
                    CurbCutWorkType = preImage.FormattedValues[JobFilingEntityAttributeName.CurbCutWorkType];
                    imageValues.Add(JobFilingEntityAttributeName.CurbCutWorkType, CurbCutWorkType);
                    crmTrace.AppendLine("Retrieve CurbCutWorkType:" + CurbCutWorkType);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CurbCutWorkType, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Directive14");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Directive14))
                {
                    Directive14 = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Directive14);
                    imageValues.Add(JobFilingEntityAttributeName.Directive14, Directive14);
                    crmTrace.AppendLine("Retrieve Directive14:" + Directive14);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Directive14, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ExtendHigherThan6Feet");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ExtendHigherThan6Feet))
                {
                    ExtendHigherThan6Feet = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ExtendHigherThan6Feet);
                    imageValues.Add(JobFilingEntityAttributeName.ExtendHigherThan6Feet, ExtendHigherThan6Feet);
                    crmTrace.AppendLine("Retrieve ExtendHigherThan6Feet:" + ExtendHigherThan6Feet);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ExtendHigherThan6Feet, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsAntennaOneMeterinDiameter");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter))
                {
                    IsAntennaOneMeterinDiameter = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter);
                    imageValues.Add(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter, IsAntennaOneMeterinDiameter);
                    crmTrace.AppendLine("Retrieve IsAntennaOneMeterinDiameter:" + IsAntennaOneMeterinDiameter);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.IsAntennaOneMeterinDiameter, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsStructuralWorkIncluded");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsStructuralWorkIncluded))
                {
                    IsStructuralWorkIncluded = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsStructuralWorkIncluded);
                    imageValues.Add(JobFilingEntityAttributeName.IsStructuralWorkIncluded, IsStructuralWorkIncluded);
                    crmTrace.AppendLine("Retrieve IsStructuralWorkIncluded:" + IsStructuralWorkIncluded);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.IsStructuralWorkIncluded, string.Empty);
                }

                crmTrace.AppendLine("Retrieve OccupyMoreThan5Percent");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OccupyMoreThan5Percent))
                {
                    OccupyMoreThan5Percent = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.OccupyMoreThan5Percent);
                    imageValues.Add(JobFilingEntityAttributeName.OccupyMoreThan5Percent, OccupyMoreThan5Percent);
                    crmTrace.AppendLine("Retrieve OccupyMoreThan5Percent:" + OccupyMoreThan5Percent);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.OccupyMoreThan5Percent, string.Empty);
                }

                crmTrace.AppendLine("Retrieve StructuralStabilityAffected");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.StructuralStabilityAffected))
                {
                    StructuralStabilityAffected = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.StructuralStabilityAffected);
                    imageValues.Add(JobFilingEntityAttributeName.StructuralStabilityAffected, StructuralStabilityAffected);
                    crmTrace.AppendLine("Retrieve StructuralStabilityAffected:" + StructuralStabilityAffected);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.StructuralStabilityAffected, string.Empty);
                }

                crmTrace.AppendLine("Retrieve WorkIncludesPartialDemolition");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.WorkIncludesPartialDemolition))
                {
                    WorkIncludesPartialDemolition = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.WorkIncludesPartialDemolition);
                    imageValues.Add(JobFilingEntityAttributeName.WorkIncludesPartialDemolition, WorkIncludesPartialDemolition);
                    crmTrace.AppendLine("Retrieve WorkIncludesPartialDemolition:" + WorkIncludesPartialDemolition);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.WorkIncludesPartialDemolition, string.Empty);
                }

                crmTrace.AppendLine("Retrieve EstimatedNewWorkFinalCost");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost))
                {
                    Money jobcost = ((Money)(preImage.Attributes[JobFilingEntityAttributeName.EstimatedNewWorkFinalCost]));
                    EstimatedNewWorkFinalCost = jobcost.Value.ToString();
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost, EstimatedNewWorkFinalCost);
                    crmTrace.AppendLine("Retrieve EstimatedNewWorkFinalCost:" + EstimatedNewWorkFinalCost);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.EstimatedNewWorkFinalCost, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Districts");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Districts))
                {
                    Districts = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Districts).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Districts, Districts);
                    crmTrace.AppendLine("Retrieve Districts:" + Districts);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Districts, string.Empty);
                }

                crmTrace.AppendLine("Retrieve HighRiseTeamTrackingNumber");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber))
                {
                    HighRiseTeamTrackingNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber, HighRiseTeamTrackingNumber);
                    crmTrace.AppendLine("Retrieve HighRiseTeamTrackingNumber:" + HighRiseTeamTrackingNumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.HighRiseTeamTrackingNumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve MapNumber");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MapNumber))
                {
                    MapNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.MapNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.MapNumber, MapNumber);
                    crmTrace.AppendLine("Retrieve MapNumber:" + MapNumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.MapNumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Overlays");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Overlays))
                {
                    Overlays = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.Overlays).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.Overlays, Overlays);
                    crmTrace.AppendLine("Retrieve Overlays:" + Overlays);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Overlays, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ProvideBSACalendarNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProvideBSACalendarNumbers))
                {
                    ProvideBSACalendarNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideBSACalendarNumbers).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProvideBSACalendarNumbers, ProvideBSACalendarNumbers);
                    crmTrace.AppendLine("Retrieve ProvideBSACalendarNumbers:" + ProvideBSACalendarNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProvideBSACalendarNumbers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ProvideCPCCalendarNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers))
                {
                    ProvideCPCCalendarNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers, ProvideCPCCalendarNumbers);
                    crmTrace.AppendLine("Retrieve ProvideCPCCalendarNumbers:" + ProvideCPCCalendarNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ProvideCPCCalendarNumbers, string.Empty);
                }

                //crmTrace.AppendLine("Retrieve RelatedAltBISJobNumbers");
                //if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RelatedAltBISJobNumbers))
                //{
                //    RelatedAltBISJobNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedAltBISJobNumbers).ToString();
                //    imageValues.Add(JobFilingEntityAttributeName.RelatedAltBISJobNumbers, RelatedAltBISJobNumbers);
                //    crmTrace.AppendLine("Retrieve RelatedAltBISJobNumbers:" + RelatedAltBISJobNumbers);
                //}
                //else
                //{
                //    imageValues.Add(JobFilingEntityAttributeName.RelatedAltBISJobNumbers, string.Empty);
                //}

                crmTrace.AppendLine("Retrieve RelatedDOBJobNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.RelatedDOBJobNumbers))
                {
                    RelatedDOBJobNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.RelatedDOBJobNumbers).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.RelatedDOBJobNumbers, RelatedDOBJobNumbers);
                    crmTrace.AppendLine("Retrieve RelatedDOBJobNumbers:" + RelatedDOBJobNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.RelatedDOBJobNumbers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SpecialDistricts");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SpecialDistricts))
                {
                    SpecialDistricts = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.SpecialDistricts).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.SpecialDistricts, SpecialDistricts);
                    crmTrace.AppendLine("Retrieve SpecialDistricts:" + SpecialDistricts);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SpecialDistricts, string.Empty);
                }

                ///Bug 5519: Fix - Start

                crmTrace.AppendLine("Retrieve FacadeAlternation");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FacadeAlternation))
                {
                    FacadeAlternation = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FacadeAlternation);
                    imageValues.Add(JobFilingEntityAttributeName.FacadeAlternation, FacadeAlternation);
                    crmTrace.AppendLine("Retrieve FacadeAlternation:" + FacadeAlternation);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.FacadeAlternation, string.Empty);
                }

                crmTrace.AppendLine("Retrieve AdultEstablishment");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AdultEstablishment))
                {
                    AdultEstablishment = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AdultEstablishment);
                    imageValues.Add(JobFilingEntityAttributeName.AdultEstablishment, AdultEstablishment);
                    crmTrace.AppendLine("Retrieve AdultEstablishment:" + AdultEstablishment);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AdultEstablishment, string.Empty);
                }

                crmTrace.AppendLine("Retrieve QualityHousing");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.QualityHousing))
                {
                    QualityHousing = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.QualityHousing);
                    imageValues.Add(JobFilingEntityAttributeName.QualityHousing, QualityHousing);
                    crmTrace.AppendLine("Retrieve QualityHousing:" + QualityHousing);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.QualityHousing, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsConjunctionJob");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsConjunctionJob))
                {
                    IsConjunctionJob = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsConjunctionJob);
                    imageValues.Add(JobFilingEntityAttributeName.IsConjunctionJob, IsConjunctionJob);
                    crmTrace.AppendLine("Retrieve IsConjunctionJob:" + IsConjunctionJob);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.IsConjunctionJob, string.Empty);
                }

                crmTrace.AppendLine("Retrieve BisRelatedJobNumber");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.BisRelatedJobNumber))
                {
                    BisRelatedJobNumber = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.BisRelatedJobNumber).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.BisRelatedJobNumber, BisRelatedJobNumber);
                    crmTrace.AppendLine("Retrieve BisRelatedJobNumber:" + BisRelatedJobNumber);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.BisRelatedJobNumber, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNRestrictiveDeclaration");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration))
                {
                    CRFNRestrictiveDeclaration = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CRFNRestrictiveDeclaration);
                    imageValues.Add(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration, CRFNRestrictiveDeclaration);
                    crmTrace.AppendLine("Retrieve CRFNRestrictiveDeclaration:" + CRFNRestrictiveDeclaration);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNRestrictiveDeclaration, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber1");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber1))
                {
                    CRFNNumber1 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber1).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber1, CRFNNumber1);
                    crmTrace.AppendLine("Retrieve CRFNNumber1:" + CRFNNumber1);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber1, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber2");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber2))
                {
                    CRFNNumber2 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber2).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber2, CRFNNumber2);
                    crmTrace.AppendLine("Retrieve CRFNNumber2:" + CRFNNumber2);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber2, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber3");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber3))
                {
                    CRFNNumber3 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber3).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber3, CRFNNumber3);
                    crmTrace.AppendLine("Retrieve CRFNNumber3:" + CRFNNumber3);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber3, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNNumber4");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNNumber4))
                {
                    CRFNNumber4 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNNumber4).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber4, CRFNNumber4);
                    crmTrace.AppendLine("Retrieve CRFNNumber4:" + CRFNNumber4);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNNumber4, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber1");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1))
                {
                    CRFNZoningExhibitNumber1 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1, CRFNZoningExhibitNumber1);
                    crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber1:" + CRFNZoningExhibitNumber1);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber1, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber2");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2))
                {
                    CRFNZoningExhibitNumber2 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2, CRFNZoningExhibitNumber2);
                    crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber2:" + CRFNZoningExhibitNumber2);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber2, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber3");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3))
                {
                    CRFNZoningExhibitNumber3 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3, CRFNZoningExhibitNumber3);
                    crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber3:" + CRFNZoningExhibitNumber3);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber3, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber4");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4))
                {
                    CRFNZoningExhibitNumber4 = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4, CRFNZoningExhibitNumber4);
                    crmTrace.AppendLine("Retrieve CRFNZoningExhibitNumber4:" + CRFNZoningExhibitNumber4);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CRFNZoningExhibitNumber4, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsFilingtoAddressViolations");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsFilingtoAddressViolations))
                {
                    IsFilingtoAddressViolations = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsFilingtoAddressViolations);
                    imageValues.Add(JobFilingEntityAttributeName.IsFilingtoAddressViolations, IsFilingtoAddressViolations);
                    crmTrace.AppendLine("Retrieve IsFilingtoAddressViolations:" + IsFilingtoAddressViolations);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.IsFilingtoAddressViolations, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ListViolationsDOBECB");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ListViolationsDOBECB))
                {
                    ListViolationsDOBECB = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ListViolationsDOBECB).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ListViolationsDOBECB, ListViolationsDOBECB);
                    crmTrace.AppendLine("Retrieve ListViolationsDOBECB:" + ListViolationsDOBECB);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ListViolationsDOBECB, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ECBNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ECBNumbers))
                {
                    ECBNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ECBNumbers).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ECBNumbers, ECBNumbers);
                    crmTrace.AppendLine("Retrieve ECBNumbers:" + ECBNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ECBNumbers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve OccupancyClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OccupancyClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.OccupancyClassification);
                    if (reqLookUp != null)
                    {
                        OccupancyClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.OccupancyClassification, OccupancyClassification);
                    }
                    crmTrace.AppendLine("Retrieve OccupancyClassification:" + OccupancyClassification);
                }

                crmTrace.AppendLine("Retrieve ConstructionClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ConstructionClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ConstructionClassification);
                    if (reqLookUp != null)
                    {
                        ConstructionClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.ConstructionClassification, ConstructionClassification);
                    }
                    crmTrace.AppendLine("Retrieve ConstructionClassification:" + ConstructionClassification);
                }

                crmTrace.AppendLine("Retrieve MultipleDwellingClassification");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MultipleDwellingClassification))
                {
                    EntityReference reqLookUp = preImage.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.MultipleDwellingClassification);
                    if (reqLookUp != null)
                    {
                        MultipleDwellingClassification = reqLookUp.Name;
                        imageValues.Add(JobFilingEntityAttributeName.MultipleDwellingClassification, MultipleDwellingClassification);
                    }
                    crmTrace.AppendLine("Retrieve MultipleDwellingClassification:" + MultipleDwellingClassification);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsTidalWastelands");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands))
                {
                    SiteCharacteristicsTidalWastelands = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands, SiteCharacteristicsTidalWastelands);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsTidalWastelands:" + SiteCharacteristicsTidalWastelands);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsTidalWastelands, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsCoastalErosionHazardArea");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea))
                {
                    SiteCharacteristicsCoastalErosionHazardArea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, SiteCharacteristicsCoastalErosionHazardArea);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsCoastalErosionHazardArea:" + SiteCharacteristicsCoastalErosionHazardArea);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsCoastalErosionHazardArea, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFireDistrict");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict))
                {
                    SiteCharacteristicsFireDistrict = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict, SiteCharacteristicsFireDistrict);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFireDistrict:" + SiteCharacteristicsFireDistrict);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFireDistrict, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFreshwaterWetlands");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands))
                {
                    SiteCharacteristicsFreshwaterWetlands = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, SiteCharacteristicsFreshwaterWetlands);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFreshwaterWetlands:" + SiteCharacteristicsFreshwaterWetlands);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFreshwaterWetlands, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsUrbanRenewal");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal))
                {
                    SiteCharacteristicsUrbanRenewal = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal, SiteCharacteristicsUrbanRenewal);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsUrbanRenewal:" + SiteCharacteristicsUrbanRenewal);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsUrbanRenewal, string.Empty);
                }

                crmTrace.AppendLine("Retrieve SiteCharacteristicsFloodHazardArea");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea))
                {
                    SiteCharacteristicsFloodHazardArea = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea);
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, SiteCharacteristicsFloodHazardArea);
                    crmTrace.AppendLine("Retrieve SiteCharacteristicsFloodHazardArea:" + SiteCharacteristicsFloodHazardArea);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.SiteCharacteristicsFloodHazardArea, string.Empty);
                }

                crmTrace.AppendLine("Retrieve FloodHzAreaIsSubstantialImprovement");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement))
                {
                    FloodHzAreaIsSubstantialImprovement = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement);
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement, FloodHzAreaIsSubstantialImprovement);
                    crmTrace.AppendLine("Retrieve FloodHzAreaIsSubstantialImprovement:" + FloodHzAreaIsSubstantialImprovement);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaIsSubstantialImprovement, string.Empty);
                }

                crmTrace.AppendLine("Retrieve IsFloodHzAreaSubstantiallyDamaged");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged))
                {
                    IsFloodHzAreaSubstantiallyDamaged = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged);
                    imageValues.Add(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged, IsFloodHzAreaSubstantiallyDamaged);
                    crmTrace.AppendLine("Retrieve IsFloodHzAreaSubstantiallyDamaged:" + IsFloodHzAreaSubstantiallyDamaged);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.IsFloodHzAreaSubstantiallyDamaged, string.Empty);
                }

                crmTrace.AppendLine("Retrieve FloodHzAreaFloodShieldsProposedWork");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork))
                {
                    FloodHzAreaFloodShieldsProposedWork = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork);
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork, FloodHzAreaFloodShieldsProposedWork);
                    crmTrace.AppendLine("Retrieve FloodHzAreaFloodShieldsProposedWork:" + FloodHzAreaFloodShieldsProposedWork);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.FloodHzAreaFloodShieldsProposedWork, string.Empty);
                }

                crmTrace.AppendLine("Retrieve AsbestosAbatementCompliance");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AsbestosAbatementCompliance))
                {
                    AsbestosAbatementCompliance = preImage.FormattedValues[JobFilingEntityAttributeName.AsbestosAbatementCompliance];
                    imageValues.Add(JobFilingEntityAttributeName.AsbestosAbatementCompliance, AsbestosAbatementCompliance);
                    crmTrace.AppendLine("Retrieve AsbestosAbatementCompliance:" + AsbestosAbatementCompliance);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AsbestosAbatementCompliance, string.Empty);
                }

                crmTrace.AppendLine("Retrieve DEPACPControlNoAttributeName");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.DEPACPControlNoAttributeName))
                {
                    DEPACPControlNoAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.DEPACPControlNoAttributeName).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.DEPACPControlNoAttributeName, DEPACPControlNoAttributeName);
                    crmTrace.AppendLine("Retrieve DEPACPControlNoAttributeName:" + DEPACPControlNoAttributeName);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.DEPACPControlNoAttributeName, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CommentsPWAttributeName");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CommentsPWAttributeName))
                {
                    CommentsPWAttributeName = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.CommentsPWAttributeName).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, CommentsPWAttributeName);
                    crmTrace.AppendLine("Retrieve CommentsPWAttributeName:" + CommentsPWAttributeName);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CommentsPWAttributeName, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ComplyingToLocalLaws");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ComplyingToLocalLaws))
                {
                    ComplyingToLocalLaws = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.ComplyingToLocalLaws);
                    imageValues.Add(JobFilingEntityAttributeName.ComplyingToLocalLaws, ComplyingToLocalLaws);
                    crmTrace.AppendLine("Retrieve ComplyingToLocalLaws:" + ComplyingToLocalLaws);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ComplyingToLocalLaws, string.Empty);
                }

                crmTrace.AppendLine("Retrieve ListOfLawNumbers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.ListOfLawNumbers))
                {
                    ListOfLawNumbers = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.ListOfLawNumbers).ToString();
                    imageValues.Add(JobFilingEntityAttributeName.ListOfLawNumbers, ListOfLawNumbers);
                    crmTrace.AppendLine("Retrieve ListOfLawNumbers:" + ListOfLawNumbers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.ListOfLawNumbers, string.Empty);
                }

                ///Bug 5519: Fix - End


                #endregion

                #region ST Fields
                //Added by SN on 11/19/2018 when new fields added
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    MSWorkIncludesRaisingorMoving = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving);
                    imageValues.Add(JobFilingEntityAttributeName.MSWorkIncludesRaisingorMoving, MSWorkIncludesRaisingorMoving);
                    crmTrace.AppendLine("Retrieve MSWorkIncludesRaisingorMoving:" + MSWorkIncludesRaisingorMoving);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnInterior))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    STWorkOnInterior = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STWorkOnInterior);
                    imageValues.Add(JobFilingEntityAttributeName.STWorkOnInterior, STWorkOnInterior);
                    crmTrace.AppendLine("Retrieve STWorkOnInterior:" + STWorkOnInterior);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STWorkOnExterior))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    STWorkOnExterior = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STWorkOnExterior);
                    imageValues.Add(JobFilingEntityAttributeName.STWorkOnExterior, STWorkOnExterior);
                    crmTrace.AppendLine("Retrieve STWorkOnExterior:" + STWorkOnExterior);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STRemovingOneOrMoreStories))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    STRemovingOneOrMoreStories = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STRemovingOneOrMoreStories);
                    imageValues.Add(JobFilingEntityAttributeName.STRemovingOneOrMoreStories, STRemovingOneOrMoreStories);
                    crmTrace.AppendLine("Retrieve STRemovingOneOrMoreStories:" + STRemovingOneOrMoreStories);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STDemolishing50OrMore))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    STDemolishing50OrMore = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STDemolishing50OrMore);
                    imageValues.Add(JobFilingEntityAttributeName.STDemolishing50OrMore, STDemolishing50OrMore);
                    crmTrace.AppendLine("Retrieve STDemolishing50OrMore:" + STDemolishing50OrMore);
                }
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR))
                {
                    crmTrace.AppendLine("Retrieve IsConjunctionJob");
                    STAlternativeMaterialsOTCR = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.STAlternativeMaterialsOTCR);
                    imageValues.Add(JobFilingEntityAttributeName.STAlternativeMaterialsOTCR, STAlternativeMaterialsOTCR);
                    crmTrace.AppendLine("Retrieve STAlternativeMaterialsOTCR:" + STAlternativeMaterialsOTCR);
                }

                #endregion

                #region MS Fields
                crmTrace.AppendLine("Retrieve HeatingSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.HeatingSystem))
                {
                    HeatingSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.HeatingSystem);
                    imageValues.Add(JobFilingEntityAttributeName.HeatingSystem, HeatingSystem);
                    crmTrace.AppendLine("Retrieve HeatingSystem:" + HeatingSystem);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.HeatingSystem, string.Empty);
                }

                crmTrace.AppendLine("Retrieve VentilationSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.VentilationSystem))
                {
                    VentilationSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.VentilationSystem);
                    imageValues.Add(JobFilingEntityAttributeName.VentilationSystem, VentilationSystem);
                    crmTrace.AppendLine("Retrieve VentilationSystem:" + VentilationSystem);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.VentilationSystem, string.Empty);
                }

                crmTrace.AppendLine("Retrieve AirConditioningSystem");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AirConditioningSystem))
                {
                    AirConditioningSystem = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AirConditioningSystem);
                    imageValues.Add(JobFilingEntityAttributeName.AirConditioningSystem, AirConditioningSystem);
                    crmTrace.AppendLine("Retrieve AirConditioningSystem:" + AirConditioningSystem);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AirConditioningSystem, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Refrigeration");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Refrigeration))
                {
                    Refrigeration = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Refrigeration);
                    imageValues.Add(JobFilingEntityAttributeName.Refrigeration, Refrigeration);
                    crmTrace.AppendLine("Retrieve Refrigeration:" + Refrigeration);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Refrigeration, string.Empty);
                }

                crmTrace.AppendLine("Retrieve CoolingTowers");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.CoolingTowers))
                {
                    CoolingTowers = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.CoolingTowers);
                    imageValues.Add(JobFilingEntityAttributeName.CoolingTowers, CoolingTowers);
                    crmTrace.AppendLine("Retrieve CoolingTowers:" + CoolingTowers);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.CoolingTowers, string.Empty);
                }

                crmTrace.AppendLine("Retrieve AssociatedDuctsAndPiping");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.AssociatedDuctsAndPiping))
                {
                    AssociatedDuctsAndPiping = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.AssociatedDuctsAndPiping);
                    imageValues.Add(JobFilingEntityAttributeName.AssociatedDuctsAndPiping, AssociatedDuctsAndPiping);
                    crmTrace.AppendLine("Retrieve AssociatedDuctsAndPiping:" + AssociatedDuctsAndPiping);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.AssociatedDuctsAndPiping, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Generator");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Generator))
                {
                    Generator = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Generator);
                    imageValues.Add(JobFilingEntityAttributeName.Generator, Generator);
                    crmTrace.AppendLine("Retrieve Generator:" + Generator);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Generator, string.Empty);
                }

                crmTrace.AppendLine("Retrieve Other");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.Other))
                {
                    Other = SetBooleanAttribute(preImage, JobFilingEntityAttributeName.Other);
                    imageValues.Add(JobFilingEntityAttributeName.Other, Other);
                    crmTrace.AppendLine("Retrieve Other:" + Other);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.Other, string.Empty);
                }

                crmTrace.AppendLine("Retrieve OtherValues");
                if (preImage.Attributes.Contains(JobFilingEntityAttributeName.OtherValues))
                {
                    OtherValues = preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.OtherValues);
                    imageValues.Add(JobFilingEntityAttributeName.OtherValues, OtherValues);
                    crmTrace.AppendLine("Retrieve OtherValues:" + OtherValues);
                }
                else
                {
                    imageValues.Add(JobFilingEntityAttributeName.OtherValues, string.Empty);
                }
                #endregion

                return imageValues;

            }
            #endregion

            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), "SourceChannel", "PW1ImageValues", crmTrace.ToString(), " PW1ImageValues trace log", "User ID", "UserBrowserInfo");
                DOBLogger.WriteExceptionLog("User ID", "SourceChannel", "PW1ImageValues", ex.Message, DOB.Logging.LogLevelL4N.ERROR, "User ID", "Exception Details", (ex.InnerException != null ? ex.InnerException.ToString() : string.Empty), "browserinfo");
                return imageValues;
                //throw new Exception(ex + " crmTrace: " + crmTrace.ToString());
            }


        }

        #endregion
        #region Get Values from Entity ScopeOfWork

        public static Dictionary<string, string> ScopeOfWorkImageValues(Entity image, StringBuilder crmTrace)
        {

            #region Get Pre Image values for ScopeOfWork Section
            #region Variable Declaration
            string System = string.Empty;
            string WorkTypeCategory = string.Empty;
            string WorkType = string.Empty;
            string FilingScope = string.Empty;
            string Description = string.Empty;
            string UnitLocation = string.Empty;
            string TypeofUnit = string.Empty;
            string TotalInputCapacity = string.Empty;
            string BackFlowPreventerType = string.Empty; //optionset
            string BackFlowPreventerrpzFloor = string.Empty;// string
            string EquipmentType = string.Empty;//optionset
            string BoilerType = string.Empty;//optionset
            string FuelGasType = string.Empty;//optionset
            string FuelGasUse = string.Empty;//optionset
            string PrivateDrainageType = string.Empty;//optionset
            string PrivateDrainageLocation = string.Empty; // string
            string CookingGasUse = string.Empty;  //optionset
            string MetersNumber = string.Empty;  // string
            string MetersLocatedAt = string.Empty; // string
            string EquipmentandAlarms = string.Empty;  //optionset
            string TotalInputCapacityinBTUH = string.Empty; // string
            string NumberofUnits = string.Empty; //whole number
            string Floor = string.Empty; // string
            string NumberofUnitsCogenSystems = string.Empty; //whole number
            string FDNYUtilityApprovals = string.Empty; //optionset
            string FloorCoGEnSystems = string.Empty;  //string
            string FuelGasTypeCogenSystems = string.Empty; //optionset
            string FuelGasUseCogenSystems = string.Empty;  //optionset
            string MedicalOtherGas = string.Empty; //optionset
            string MedicalOtherGasLocatedat = string.Empty;  //string
            string PrivateStorm = string.Empty; //optionset
            string DryWellWorkType = string.Empty;//optionset
            string StormSystems = string.Empty; //optionset
            string StormSystemsLocatedat = string.Empty; //string
            string PoolType = string.Empty;//optionset
            string Describe = string.Empty;// multiple string
            string SprinklerSystem = string.Empty;//optionset
            string HazardType = string.Empty; //optionset
            string SystemType = string.Empty; //optionset
            string WaterMain = string.Empty;//optionset
            string FDC = string.Empty; //optionset
            string Tank = string.Empty;//optionset
            string TypeofPumps = string.Empty;//optionset
            string StandardSprinklerHead = string.Empty;// two options
            string ExtendedCoverageHead = string.Empty; // two options
            string WorkRequiresPenetrationofFireRated = string.Empty;//optionset
            string TypeofSprinklerSystem = string.Empty;//optionset
            string RiserControlValve = string.Empty;// two options
            string RiserSandBranches = string.Empty;// two options
            string BoosterPump = string.Empty;// two options
            string FirePump = string.Empty; // two options
            string DryPumpValve = string.Empty;// two options
            string SpecialServicePump = string.Empty;// two options
            #endregion

            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {


                crmTrace.AppendLine("Retrieve System");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.System))
                {
                    EntityReference systemLookUp = image.GetAttributeValue<EntityReference>(ScopeOfWorkEntityAttributeName.System);
                    if (systemLookUp != null)
                    {
                        System = systemLookUp.Name;
                        imageValues.Add(ScopeOfWorkEntityAttributeName.System, System);
                    }
                    crmTrace.AppendLine("Retrieve System:" + System);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.System, string.Empty);
                }


                crmTrace.AppendLine("Retrieve WorkTypeCategory");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkTypeCategory))
                {
                    WorkTypeCategory = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.WorkTypeCategory).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkTypeCategory, WorkTypeCategory);
                    crmTrace.AppendLine("Retrieve WorkTypeCategory:" + WorkTypeCategory);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkTypeCategory, string.Empty);
                }
                crmTrace.AppendLine("Retrieve WorkType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkType))
                {
                    WorkType = image.FormattedValues[ScopeOfWorkEntityAttributeName.WorkType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkType, WorkType);
                    crmTrace.AppendLine("Retrieve WorkType:" + WorkType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FilingScope");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FilingScope))
                {
                    FilingScope = image.FormattedValues[ScopeOfWorkEntityAttributeName.FilingScope];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FilingScope, FilingScope);
                    crmTrace.AppendLine("Retrieve FilingScope:" + FilingScope);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FilingScope, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Description");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.Description))
                {
                    Description = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Description).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Description, Description);
                    crmTrace.AppendLine("Retrieve Description:" + Description);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Description, string.Empty);
                }
                crmTrace.AppendLine("Retrieve UnitLocation");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.UnitLocation))
                {
                    UnitLocation = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.UnitLocation).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.UnitLocation, UnitLocation);
                    crmTrace.AppendLine("Retrieve UnitLocation:" + UnitLocation);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.UnitLocation, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TypeofUnit");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofUnit))
                {
                    TypeofUnit = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TypeofUnit).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofUnit, TypeofUnit);
                    crmTrace.AppendLine("Retrieve TypeofUnit:" + TypeofUnit);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofUnit, string.Empty);
                }

                crmTrace.AppendLine("Retrieve TotalInputCapacity");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.TotalInputCapacity))
                {
                    TotalInputCapacity = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TotalInputCapacity).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacity, TotalInputCapacity);
                    crmTrace.AppendLine("Retrieve TotalInputCapacity:" + TotalInputCapacity);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacity, string.Empty);
                }

                crmTrace.AppendLine("Retrieve BackFlowPreventerType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.BackFlowPreventerType))
                {
                    BackFlowPreventerType = image.FormattedValues[ScopeOfWorkEntityAttributeName.BackFlowPreventerType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerType, BackFlowPreventerType);
                    crmTrace.AppendLine("Retrieve BackFlowPreventerType:" + BackFlowPreventerType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve BackFlowPreventerrpzFloor");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor))
                {
                    BackFlowPreventerrpzFloor = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor, BackFlowPreventerrpzFloor);
                    crmTrace.AppendLine("Retrieve BackFlowPreventerrpzFloor:" + BackFlowPreventerrpzFloor);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BackFlowPreventerrpzFloor, string.Empty);
                }
                crmTrace.AppendLine("Retrieve EquipmentType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.EquipmentType))
                {
                    EquipmentType = image.FormattedValues[ScopeOfWorkEntityAttributeName.EquipmentType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentType, EquipmentType);
                    crmTrace.AppendLine("Retrieve EquipmentType:" + EquipmentType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve BoilerType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.BoilerType))
                {
                    BoilerType = image.FormattedValues[ScopeOfWorkEntityAttributeName.BoilerType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoilerType, BoilerType);
                    crmTrace.AppendLine("Retrieve BoilerType:" + BoilerType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoilerType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FuelGasType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasType))
                {
                    FuelGasType = image.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasType, FuelGasType);
                    crmTrace.AppendLine("Retrieve FuelGasType:" + FuelGasType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FuelGasUse");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasUse))
                {
                    FuelGasUse = image.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasUse];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUse, FuelGasUse);
                    crmTrace.AppendLine("Retrieve FuelGasUse:" + FuelGasUse);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUse, string.Empty);
                }
                crmTrace.AppendLine("Retrieve PrivateDrainageType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateDrainageType))
                {
                    PrivateDrainageType = image.FormattedValues[ScopeOfWorkEntityAttributeName.PrivateDrainageType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageType, PrivateDrainageType);
                    crmTrace.AppendLine("Retrieve PrivateDrainageType:" + PrivateDrainageType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageType, string.Empty);
                }

                crmTrace.AppendLine("Retrieve PrivateDrainageLocation");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation))
                {
                    PrivateDrainageLocation = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation, PrivateDrainageLocation);
                    crmTrace.AppendLine("Retrieve PrivateDrainageLocation:" + PrivateDrainageLocation);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateDrainageLocation, string.Empty);
                }
                crmTrace.AppendLine("Retrieve CookingGasUse");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.CookingGasUse))
                {
                    CookingGasUse = image.FormattedValues[ScopeOfWorkEntityAttributeName.CookingGasUse];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.CookingGasUse, CookingGasUse);
                    crmTrace.AppendLine("Retrieve CookingGasUse:" + CookingGasUse);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.CookingGasUse, string.Empty);
                }
                crmTrace.AppendLine("Retrieve MetersNumber");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.MetersNumber))
                {
                    MetersNumber = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MetersNumber).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersNumber, MetersNumber);
                    crmTrace.AppendLine("Retrieve MetersNumber:" + MetersNumber);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersNumber, string.Empty);
                }
                crmTrace.AppendLine("Retrieve MetersLocatedAt");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.MetersLocatedAt))
                {
                    MetersLocatedAt = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MetersLocatedAt).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersLocatedAt, MetersLocatedAt);
                    crmTrace.AppendLine("Retrieve MetersLocatedAt:" + MetersLocatedAt);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MetersLocatedAt, string.Empty);
                }
                crmTrace.AppendLine("Retrieve EquipmentandAlarms");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.EquipmentandAlarms))
                {
                    EquipmentandAlarms = image.FormattedValues[ScopeOfWorkEntityAttributeName.EquipmentandAlarms];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentandAlarms, EquipmentandAlarms);
                    crmTrace.AppendLine("Retrieve EquipmentandAlarms:" + EquipmentandAlarms);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.EquipmentandAlarms, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TotalInputCapacityinBTUH");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH))
                {
                    TotalInputCapacityinBTUH = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH, TotalInputCapacityinBTUH);
                    crmTrace.AppendLine("Retrieve TotalInputCapacityinBTUH:" + TotalInputCapacityinBTUH);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TotalInputCapacityinBTUH, string.Empty);
                }
                crmTrace.AppendLine("Retrieve NumberofUnits");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.NumberofUnits))
                {
                    NumberofUnits = image.GetAttributeValue<int>(ScopeOfWorkEntityAttributeName.NumberofUnits).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnits, NumberofUnits);
                    crmTrace.AppendLine("Retrieve NumberofUnits:" + NumberofUnits);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnits, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Floor");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.Floor))
                {
                    Floor = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Floor).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Floor, Floor);
                    crmTrace.AppendLine("Retrieve Floor:" + Floor);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Floor, string.Empty);
                }
                crmTrace.AppendLine("Retrieve NumberofUnitsCogenSystems");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems))
                {
                    NumberofUnitsCogenSystems = image.GetAttributeValue<int>(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems, NumberofUnits);
                    crmTrace.AppendLine("Retrieve NumberofUnitsCogenSystems:" + NumberofUnitsCogenSystems);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.NumberofUnitsCogenSystems, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FDNYUtilityApprovals");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals))
                {
                    FDNYUtilityApprovals = image.FormattedValues[ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals, FDNYUtilityApprovals);
                    crmTrace.AppendLine("Retrieve FDNYUtilityApprovals:" + FDNYUtilityApprovals);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDNYUtilityApprovals, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FloorCoGEnSystems");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems))
                {
                    FloorCoGEnSystems = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems, FloorCoGEnSystems);
                    crmTrace.AppendLine("Retrieve FloorCoGEnSystems:" + FloorCoGEnSystems);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FloorCoGEnSystems, string.Empty);
                }

                crmTrace.AppendLine("Retrieve FuelGasTypeCogenSystems");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems))
                {
                    FuelGasTypeCogenSystems = image.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems, FuelGasTypeCogenSystems);
                    crmTrace.AppendLine("Retrieve FuelGasTypeCogenSystems:" + FuelGasTypeCogenSystems);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasTypeCogenSystems, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FuelGasUseCogenSystems");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems))
                {
                    FuelGasUseCogenSystems = image.FormattedValues[ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems, FuelGasUseCogenSystems);
                    crmTrace.AppendLine("Retrieve FuelGasUseCogenSystems:" + FuelGasUseCogenSystems);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FuelGasUseCogenSystems, string.Empty);
                }
                crmTrace.AppendLine("Retrieve MedicalOtherGas");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.MedicalOtherGas))
                {
                    MedicalOtherGas = image.FormattedValues[ScopeOfWorkEntityAttributeName.MedicalOtherGas];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGas, MedicalOtherGas);
                    crmTrace.AppendLine("Retrieve MedicalOtherGas:" + MedicalOtherGas);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGas, string.Empty);
                }
                crmTrace.AppendLine("Retrieve MedicalOtherGasLocatedat");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat))
                {
                    MedicalOtherGasLocatedat = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat, MedicalOtherGasLocatedat);
                    crmTrace.AppendLine("Retrieve MedicalOtherGasLocatedat:" + MedicalOtherGasLocatedat);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.MedicalOtherGasLocatedat, string.Empty);
                }
                crmTrace.AppendLine("Retrieve PrivateStorm");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.PrivateStorm))
                {
                    PrivateStorm = image.FormattedValues[ScopeOfWorkEntityAttributeName.PrivateStorm];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateStorm, PrivateStorm);
                    crmTrace.AppendLine("Retrieve PrivateStorm:" + PrivateStorm);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PrivateStorm, string.Empty);
                }
                crmTrace.AppendLine("Retrieve DryWellWorkType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.DryWellWorkType))
                {
                    DryWellWorkType = image.FormattedValues[ScopeOfWorkEntityAttributeName.DryWellWorkType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryWellWorkType, DryWellWorkType);
                    crmTrace.AppendLine("Retrieve DryWellWorkType:" + DryWellWorkType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryWellWorkType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve StormSystems");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.StormSystems))
                {
                    StormSystems = image.FormattedValues[ScopeOfWorkEntityAttributeName.StormSystems];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystems, StormSystems);
                    crmTrace.AppendLine("Retrieve StormSystems:" + StormSystems);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystems, string.Empty);
                }
                crmTrace.AppendLine("Retrieve StormSystemsLocatedat");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat))
                {
                    StormSystemsLocatedat = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat, StormSystemsLocatedat);
                    crmTrace.AppendLine("Retrieve StormSystemsLocatedat:" + StormSystemsLocatedat);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StormSystemsLocatedat, string.Empty);
                }
                crmTrace.AppendLine("Retrieve PoolType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.PoolType))
                {
                    PoolType = image.FormattedValues[ScopeOfWorkEntityAttributeName.PoolType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PoolType, PoolType);
                    crmTrace.AppendLine("Retrieve PoolType:" + PoolType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.PoolType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Describe");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.Describe))
                {
                    Describe = image.GetAttributeValue<string>(ScopeOfWorkEntityAttributeName.Describe).ToString();
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Describe, Describe);
                    crmTrace.AppendLine("Retrieve Describe:" + Describe);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Describe, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SprinklerSystem");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.SprinklerSystem))
                {
                    SprinklerSystem = image.FormattedValues[ScopeOfWorkEntityAttributeName.SprinklerSystem];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SprinklerSystem, SprinklerSystem);
                    crmTrace.AppendLine("Retrieve SprinklerSystem:" + SprinklerSystem);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SprinklerSystem, string.Empty);
                }
                crmTrace.AppendLine("Retrieve HazardType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.HazardType))
                {
                    HazardType = image.FormattedValues[ScopeOfWorkEntityAttributeName.HazardType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.HazardType, HazardType);
                    crmTrace.AppendLine("Retrieve HazardType:" + HazardType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.HazardType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SystemType");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.SystemType))
                {
                    SystemType = image.FormattedValues[ScopeOfWorkEntityAttributeName.SystemType];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SystemType, SystemType);
                    crmTrace.AppendLine("Retrieve SystemType:" + SystemType);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SystemType, string.Empty);
                }
                crmTrace.AppendLine("Retrieve WaterMain");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.WaterMain))
                {
                    WaterMain = image.FormattedValues[ScopeOfWorkEntityAttributeName.WaterMain];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WaterMain, WaterMain);
                    crmTrace.AppendLine("Retrieve WaterMain:" + WaterMain);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WaterMain, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FDC");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FDC))
                {
                    FDC = image.FormattedValues[ScopeOfWorkEntityAttributeName.FDC];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDC, FDC);
                    crmTrace.AppendLine("Retrieve FDC:" + FDC);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FDC, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Tank");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.Tank))
                {
                    Tank = image.FormattedValues[ScopeOfWorkEntityAttributeName.Tank];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Tank, Tank);
                    crmTrace.AppendLine("Retrieve Tank:" + Tank);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.Tank, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TypeofPumps");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofPumps))
                {
                    TypeofPumps = image.FormattedValues[ScopeOfWorkEntityAttributeName.TypeofPumps];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofPumps, TypeofPumps);
                    crmTrace.AppendLine("Retrieve TypeofPumps:" + TypeofPumps);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofPumps, string.Empty);
                }
                crmTrace.AppendLine("Retrieve StandardSprinklerHead");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.StandardSprinklerHead))
                {
                    StandardSprinklerHead = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.StandardSprinklerHead);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StandardSprinklerHead, StandardSprinklerHead);
                    crmTrace.AppendLine("Retrieve StandardSprinklerHead:" + StandardSprinklerHead);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.StandardSprinklerHead, string.Empty);
                }
                crmTrace.AppendLine("Retrieve ExtendedCoverageHead");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.ExtendedCoverageHead))
                {
                    ExtendedCoverageHead = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.ExtendedCoverageHead);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.ExtendedCoverageHead, ExtendedCoverageHead);
                    crmTrace.AppendLine("Retrieve ExtendedCoverageHead:" + ExtendedCoverageHead);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.ExtendedCoverageHead, string.Empty);
                }
                crmTrace.AppendLine("Retrieve WorkRequiresPenetrationofFireRated");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated))
                {
                    WorkRequiresPenetrationofFireRated = image.FormattedValues[ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated, WorkRequiresPenetrationofFireRated);
                    crmTrace.AppendLine("Retrieve WorkRequiresPenetrationofFireRated:" + WorkRequiresPenetrationofFireRated);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.WorkRequiresPenetrationofFireRated, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TypeofSprinklerSystem");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem))
                {
                    TypeofSprinklerSystem = image.FormattedValues[ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem];
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem, TypeofSprinklerSystem);
                    crmTrace.AppendLine("Retrieve TypeofSprinklerSystem:" + TypeofSprinklerSystem);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.TypeofSprinklerSystem, string.Empty);
                }
                crmTrace.AppendLine("Retrieve RiserControlValve");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.RiserControlValve))
                {
                    RiserControlValve = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.RiserControlValve);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserControlValve, RiserControlValve);
                    crmTrace.AppendLine("Retrieve RiserControlValve:" + RiserControlValve);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserControlValve, string.Empty);
                }
                crmTrace.AppendLine("Retrieve RiserSandBranches");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.RiserSandBranches))
                {
                    RiserSandBranches = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.RiserSandBranches);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserSandBranches, RiserSandBranches);
                    crmTrace.AppendLine("Retrieve RiserSandBranches:" + RiserSandBranches);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.RiserSandBranches, string.Empty);
                }
                crmTrace.AppendLine("Retrieve BoosterPump");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.BoosterPump))
                {
                    BoosterPump = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.BoosterPump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoosterPump, BoosterPump);
                    crmTrace.AppendLine("Retrieve BoosterPump:" + BoosterPump);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.BoosterPump, string.Empty);
                }
                crmTrace.AppendLine("Retrieve FirePump");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.FirePump))
                {
                    FirePump = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.FirePump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FirePump, FirePump);
                    crmTrace.AppendLine("Retrieve FirePump:" + FirePump);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.FirePump, string.Empty);
                }

                crmTrace.AppendLine("Retrieve DryPumpValve");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.DryPumpValve))
                {
                    DryPumpValve = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.DryPumpValve);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryPumpValve, DryPumpValve);
                    crmTrace.AppendLine("Retrieve DryPumpValve:" + DryPumpValve);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.DryPumpValve, string.Empty);
                }
                crmTrace.AppendLine("Retrieve SpecialServicePump");
                if (image.Attributes.Contains(ScopeOfWorkEntityAttributeName.SpecialServicePump))
                {
                    SpecialServicePump = SetBooleanAttribute(image, ScopeOfWorkEntityAttributeName.SpecialServicePump);
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SpecialServicePump, SpecialServicePump);
                    crmTrace.AppendLine("Retrieve SpecialServicePump:" + SpecialServicePump);
                }
                else
                {
                    imageValues.Add(ScopeOfWorkEntityAttributeName.SpecialServicePump, string.Empty);
                }

                return imageValues;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - ScopeOfWorkImageValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            #endregion
        }
        #endregion
        #region Get Values from WorkCostDetails Entity

        public static Dictionary<string, string> WorkCostDetailsValues(Entity image, StringBuilder crmTrace)
        {
            #region Variable Declaration
            string WorkCategory = string.Empty;
            string WorkScope = string.Empty;
            string DescriptionofWork = string.Empty;
            string UnitCost = string.Empty;
            string AreaUnits = string.Empty;
            string TotalCost = string.Empty;
            string Name = string.Empty;
            #endregion
            Dictionary<string, string> imageValues = new Dictionary<string, string>();
            try
            {
                crmTrace.AppendLine("Retrieve WorkCategory");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.WorkCategory))
                {
                    WorkCategory = image.FormattedValues[WorkCostDetailsAttributeNames.WorkCategory];
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkCategory, WorkCategory);
                    crmTrace.AppendLine("Retrieve WorkCategory:" + WorkCategory);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkCategory, string.Empty);
                }
                crmTrace.AppendLine("Retrieve WorkScope");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.WorkScope))
                {
                    WorkScope = image.FormattedValues[WorkCostDetailsAttributeNames.WorkScope];
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkScope, WorkScope);
                    crmTrace.AppendLine("Retrieve WorkScope:" + WorkScope);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.WorkScope, string.Empty);
                }
                crmTrace.AppendLine("Retrieve DescriptionofWork");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.DescriptionofWork))
                {
                    DescriptionofWork = image.GetAttributeValue<string>(WorkCostDetailsAttributeNames.DescriptionofWork).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.DescriptionofWork, DescriptionofWork);
                    crmTrace.AppendLine("Retrieve DescriptionofWork:" + DescriptionofWork);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.DescriptionofWork, string.Empty);
                }
                crmTrace.AppendLine("Retrieve UnitCost");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.UnitCost))
                {
                    UnitCost = ((Money)(image.Attributes[WorkCostDetailsAttributeNames.UnitCost])).Value.ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.UnitCost, UnitCost);
                    crmTrace.AppendLine("Retrieve UnitCost:" + UnitCost);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.UnitCost, string.Empty);
                }
                crmTrace.AppendLine("Retrieve AreaUnits");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.AreaUnits))
                {
                    AreaUnits = image.GetAttributeValue<int>(WorkCostDetailsAttributeNames.AreaUnits).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.AreaUnits, AreaUnits);
                    crmTrace.AppendLine("Retrieve AreaUnits:" + AreaUnits);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.AreaUnits, string.Empty);
                }
                crmTrace.AppendLine("Retrieve TotalCost");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.TotalCost))
                {
                    TotalCost = ((Money)(image.Attributes[WorkCostDetailsAttributeNames.TotalCost])).Value.ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.TotalCost, TotalCost);
                    crmTrace.AppendLine("Retrieve TotalCost:" + TotalCost);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.TotalCost, string.Empty);
                }
                crmTrace.AppendLine("Retrieve Name");
                if (image.Attributes.Contains(WorkCostDetailsAttributeNames.Name))
                {
                    Name = image.GetAttributeValue<string>(WorkCostDetailsAttributeNames.Name).ToString();
                    imageValues.Add(WorkCostDetailsAttributeNames.Name, Name);
                    crmTrace.AppendLine("Retrieve Name:" + Name);
                }
                else
                {
                    imageValues.Add(WorkCostDetailsAttributeNames.Name, string.Empty);
                }
                return imageValues;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return imageValues;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(image.Id.ToString(), SourceChannel.CRM, "PAAHandler - WorkCostDetailsValues", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return imageValues;
            }
        }
        #endregion
        #region Set boolen value to preImage entity
        private static string SetBooleanAttribute(Entity preImage, string attributeName)
        {
            bool boolObj = preImage.GetAttributeValue<bool>(attributeName);
            if (boolObj)
            {
                attributeName = "Yes";
            }
            else
            {
                attributeName = "No";
            }
            return attributeName;
        }
        #endregion

        public static Entity CreateWorkOnFloorDetailslist(IOrganizationService service, Entity currentWorkonFloorDetailsRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity WOF = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(WorkOnFloorEntityAttributeName.EntityLogicalName, currentWorkonFloorDetailsRecord.Id, columns);


                WOF = EntityExtensions.Clone(response, false);
                WOF.Attributes.Remove(WorkOnFloorEntityAttributeName.GoToJobFiling);
                WOF.Attributes.Remove(WorkOnFloorEntityAttributeName.WorkOnFloorId);
                WOF.Attributes.Add(WorkOnFloorEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                WOF.Id = Guid.NewGuid();
                crmTrace.AppendLine("WOF ID :" + WOF.Id.ToString());

                return WOF;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return WOF;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return WOF;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateWorkOnFloorDetailslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return WOF;
            }
        }

        public static Entity CreateAntennaCurbCutClonelist(IOrganizationService service, Entity currentANCCRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity CS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);

                if (currentANCCRecord.LogicalName == AntennaScopeOfWorkEntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(AntennaScopeOfWorkEntityAttributeName.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(AntennaScopeOfWorkEntityAttributeName.GoToJobFiling);
                    CS.Attributes.Remove(AntennaScopeOfWorkEntityAttributeName.AntennaScopeofWorkId);
                    CS.Attributes.Add(AntennaScopeOfWorkEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }
                else if (currentANCCRecord.LogicalName == AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(AntennaDemolitionSubmittalCertificationEntityAttributeName.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling);
                    CS.Attributes.Remove(AntennaDemolitionSubmittalCertificationEntityAttributeName.AntennaDS1Id);
                    CS.Attributes.Add(AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }
                else if (currentANCCRecord.LogicalName == CurbCutQuestionnaireEntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(CurbCutQuestionnaireEntityAttributeName.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(CurbCutQuestionnaireEntityAttributeName.GoToJobFiling);
                    CS.Attributes.Remove(CurbCutQuestionnaireEntityAttributeName.CurbCutQuestionnaireId);
                    CS.Attributes.Add(CurbCutQuestionnaireEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }
                else if (currentANCCRecord.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(LOCPW7EntityAttributeName.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(LOCPW7EntityAttributeName.GotoJobFiling);
                    CS.Attributes.Remove(LOCPW7EntityAttributeName.LOCRequestId);
                    CS.Attributes.Add(LOCPW7EntityAttributeName.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }
                else if (currentANCCRecord.LogicalName == WorkOnFloorEntityAttributeName.EntityLogicalName)
                {
                    Entity response = service.Retrieve(WorkOnFloorEntityAttributeName.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(WorkOnFloorEntityAttributeName.GoToJobFiling);
                    CS.Attributes.Remove(WorkOnFloorEntityAttributeName.WorkOnFloorId);
                    CS.Attributes.Add(WorkOnFloorEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }

                return CS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return CS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateAntennaCurbCutClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
        }


        public static Entity CreateBESOWClonelist(IOrganizationService service, Entity currentANCCRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity CS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);

                if (currentANCCRecord.LogicalName == BEScopeOfWorkEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(BEScopeOfWorkEntityAttribute.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(BEScopeOfWorkEntityAttribute.GoToJobFiling);
                    CS.Attributes.Remove(BEScopeOfWorkEntityAttribute.BESOWId);
                    CS.Attributes.Add(BEScopeOfWorkEntityAttribute.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }


                return CS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return CS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
        }

        public static Entity CreateBEDevicesClonelist(IOrganizationService service, Entity currentANCCRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity CS = new Entity();
            try
            {
                //get parent jobfiling entity
                Entity jobFiling = new Entity(JobFilingEntityAttributeName.EntityLogicalName);
                jobFiling.Id = ParentJobGuid;
                EntityCollection scopeOfWorks = FeeCalculationStandardizationHandler.getBoilerScopeOfWorkDetailsFromJF(service, jobFiling, crmTrace);
                ColumnSet columns = new ColumnSet(true);

                if (currentANCCRecord.LogicalName == BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName)
                {
                    Entity response = service.Retrieve(BoilerBuildDeviceDetailsEntityAttribute.EntityLogicalName, currentANCCRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling);
                    CS.Attributes.Remove(BoilerBuildDeviceDetailsEntityAttribute.BoilerScopeofworkid);
                    CS.Attributes.Remove(BoilerBuildDeviceDetailsEntityAttribute.BoilerBuildDeviceDetailsId);
                    CS.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    //add scope of work id also
                    if (scopeOfWorks != null && scopeOfWorks.Entities.Count > 0)
                    {
                        CS.Attributes.Add(BoilerBuildDeviceDetailsEntityAttribute.BoilerScopeofworkid, scopeOfWorks.Entities[0].ToEntityReference());

                    }

                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("CS ID :" + CS.Id.ToString());
                }


                return CS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return CS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateBESOWClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
        }

        //Delegates Clone List
        public static Entity CreateDelegatesClonelist(IOrganizationService service, Entity currentDelegatesRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity CS = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);

                if (currentDelegatesRecord.LogicalName == DelegatesEntityAttributeNames.EntityLogicalName)
                {
                    Entity response = service.Retrieve(DelegatesEntityAttributeNames.EntityLogicalName, currentDelegatesRecord.Id, columns);
                    CS = EntityExtensions.Clone(response, false);
                    CS.Attributes.Remove(DelegatesEntityAttributeNames.GoToJobFiling);
                    CS.Attributes.Remove(DelegatesEntityAttributeNames.DelegatesId);
                    CS.Attributes.Add(DelegatesEntityAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                    CS.Id = Guid.NewGuid();
                    crmTrace.AppendLine("Delegates ID :" + CS.Id.ToString());
                }

                return CS;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return CS;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "PAAHandler - CreateDelegatesClonelist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return CS;
            }
        }
    }

}
