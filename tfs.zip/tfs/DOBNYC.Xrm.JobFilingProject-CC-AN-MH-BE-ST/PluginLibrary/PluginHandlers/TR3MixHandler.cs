﻿using System;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using DOB.Logging;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using DOBNYC.XRM.JobFiling.Helpers;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
  public  class TR3MixHandler : PluginHandlerBase
    {
        public static void SetTR3MixNameAndUpdateCounterForTR3Mix(IOrganizationService service, Entity targetEntity, Guid Guid, StringBuilder crmTrace)
        {
            try
            {
                EntityCollection TR3Directors = new EntityCollection();
                EntityCollection ExistingTr3MixCollection = new EntityCollection();
                EntityCollection tempMixes = new EntityCollection();
                string latestTr3MixName = string.Empty;
                crmTrace.AppendLine("Start UpdateCounterForTR3Mix Method ");
                #region Initialize the TR3Mix  Entity
                Entity TR3technicalreport = new Entity();
                TR3technicalreport.LogicalName = TR3TechnicalReportEntityAttribute.EntityLogicalName;
                #endregion
                #region Setting the Varibles
                String Name = "Mix";
                int counter = 0; //intialize the counter is to 0
             
                #endregion
                #region Retrive the  Plan counter from TR3TechnicalReport
                TR3technicalreport = service.Retrieve(TR3TechnicalReportEntityAttribute.EntityLogicalName, Guid, new ColumnSet(new string[] { TR3TechnicalReportEntityAttribute.Tr3MixCounter,TR3TechnicalReportEntityAttribute.GotoJobFiling }));

                //get all the tr3 directors info from tr3maintechnicalreport

                if(TR3technicalreport!=null && TR3technicalreport.Id!=null && TR3technicalreport.Contains(TR3TechnicalReportEntityAttribute.GotoJobFiling) && TR3technicalreport[TR3TechnicalReportEntityAttribute.GotoJobFiling]!=null)
                {
                    crmTrace.AppendLine("get all the tr3 directors info from tr3maintechnicalreport  " );
                    ConditionExpression condition = new ConditionExpression(TR3TechnicalReportEntityAttribute.GotoJobFiling, ConditionOperator.Equal, TR3technicalreport.GetAttributeValue<EntityReference>(TR3TechnicalReportEntityAttribute.GotoJobFiling).Id.ToString());

                    TR3Directors = RetrieveMultiple(service, TR3TechnicalReportEntityAttribute.EntityLogicalName, new string[] { TR3TechnicalReportEntityAttribute.Tr3MixCounter, TR3TechnicalReportEntityAttribute.GotoJobFiling }, new ConditionExpression[] {condition }, LogicalOperator.And);

                    if(TR3Directors!=null&&TR3Directors.Entities.Count>0)
                    {
                        foreach(Entity Tr3Director in TR3Directors.Entities)
                        {
                            //get latest tr3 mix for that director
                            crmTrace.AppendLine("get latest tr3 mix for that director  ");
                            condition = new ConditionExpression(TR3MixEntityAttribute.GotoTRTechnicalreport, ConditionOperator.Equal, Tr3Director.Id.ToString());
                            tempMixes = RetrieveMultiple(service, TR3MixEntityAttribute.EntityLogicalName, new string[] { TR3MixEntityAttribute.EntityNameAttribute,TR3MixEntityAttribute.createdon }, new ConditionExpression[] { condition }, LogicalOperator.And, "createdon", OrderType.Descending, 1);
                            if(tempMixes!=null && tempMixes.Entities.Count>0)
                            {
                                foreach(Entity temp in tempMixes.Entities)
                                {
                                    crmTrace.AppendLine("Add mix to existing");
                                    ExistingTr3MixCollection.Entities.Add(temp);
                                }
                            }

                        }
                    }

                    //get the latest Mix in existing 

                   
                    if(ExistingTr3MixCollection!=null && ExistingTr3MixCollection.Entities.Count>0)
                    {
                        crmTrace.AppendLine("get the latest Mix in existing ");
                        Entity latestEntity = ExistingTr3MixCollection.Entities[0];
                        foreach(Entity latestTR3Mix in ExistingTr3MixCollection.Entities)
                        {
                            if(latestTR3Mix.GetAttributeValue<DateTime>(TR3MixEntityAttribute.createdon) > latestEntity.GetAttributeValue<DateTime>(TR3MixEntityAttribute.createdon))
                            {
                                latestEntity = latestTR3Mix;
                            }
                        }
                        crmTrace.AppendLine("get the latest Mix in existing "+ latestEntity.GetAttributeValue<string>(TR3MixEntityAttribute.EntityNameAttribute));
                        latestTr3MixName = latestEntity.GetAttributeValue<string>(TR3MixEntityAttribute.EntityNameAttribute);
                        counter = Convert.ToInt32(latestTr3MixName.Substring(3)) + 1;


                    }
                    else
                    {
                        crmTrace.AppendLine("It is the first Mix ");
                        counter = 0;
                    }


                }



                crmTrace.AppendLine("counter:  " + counter);
               
                #endregion
                #region Check the counter and Set the TR3 Mix Name and Update the Counter
                if (counter == 0) 
                {
                    #region If the counter is 0 default
                    counter = 1;
                    crmTrace.AppendLine("Start End of setting the TR3MixEntity " + Name + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, TR3MixEntityAttribute.EntityNameAttribute, Name + " " + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, TR3MixEntityAttribute.SequenceNumber, counter);
                    crmTrace.AppendLine("End of setting the TR3MixEntity  " + Name + counter.ToString());
                    #endregion

                    
                }
               else if (counter > 0)
                {
                    #region 
                    crmTrace.AppendLine("Start End of setting the TR3MixEntity " + Name + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, TR3MixEntityAttribute.EntityNameAttribute, Name + " " + counter.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, TR3MixEntityAttribute.SequenceNumber, counter);
                    crmTrace.AppendLine("End of setting the TR3MixEntity  " + Name + counter.ToString());
                    #endregion

                }
                #endregion
                crmTrace.AppendLine("End UpdateCounterForTR3Mix Method ");
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - Final: End ", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix  PA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix  PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - UpdateCounterForTR3Mix PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        //public static void SetTR3DirectorTrackingNumber(IOrganizationService service, Entity targetEntity,  StringBuilder crmTrace)
        //{
        //    try
        //    {
        //        EntityCollection TR3Directors = new EntityCollection();
        //        EntityCollection ExistingTr3MixCollection = new EntityCollection();
        //        EntityCollection tempMixes = new EntityCollection();
        //        string latestTr3MixName = string.Empty;
        //        crmTrace.AppendLine("Start SetTR3DirectorTrackingNumber Method ");
        //        #region Initialize the TR3Mix  Entity
        //        Entity TR3technicalreport = new Entity();
        //        TR3technicalreport.LogicalName = TR3TechnicalReportEntityAttribute.EntityLogicalName;
        //        #endregion
        //        #region Setting the Varibles
                
        //        int counter = 0; //intialize the counter is to 0

        //        #endregion
        //        #region Retrive the  all the tr3 directors from main tr3 guid
                

        //        //get all the tr3 directors info from tr3maintechnicalreport

        //        if (targetEntity != null && targetEntity.Id != null && targetEntity.Contains(TR3TechnicalReportEntityAttribute.GotoTR3) && targetEntity[TR3TechnicalReportEntityAttribute.GotoTR3] != null)
        //        {
        //            crmTrace.AppendLine("get all the tr3 directors info from tr3maintechnicalreport  ");
        //            ConditionExpression condition = new ConditionExpression(TR3TechnicalReportEntityAttribute.GotoTR3, ConditionOperator.Equal, targetEntity.GetAttributeValue<EntityReference>(TR3TechnicalReportEntityAttribute.GotoTR3).Id.ToString());

        //            TR3Directors = RetrieveMultiple(service, TR3TechnicalReportEntityAttribute.EntityLogicalName, new string[] { TR3TechnicalReportEntityAttribute.Tr3MixCounter, TR3TechnicalReportEntityAttribute.GotoTR3 }, new ConditionExpression[] { condition }, LogicalOperator.And, "createdon", OrderType.Descending, 1);

        //            if (TR3Directors != null && TR3Directors.Entities.Count > 0)
        //            {
        //                crmTrace.AppendLine("Directors present so counter +1  ");
        //                counter = TR3Directors.Entities[0].GetAttributeValue<int>(TR3TechnicalReportEntityAttribute.trackingNumber);
        //                crmTrace.AppendLine(" counter "+ counter);
        //                targetEntity.SetAttributeValue(TR3TechnicalReportEntityAttribute.trackingNumber, counter + 1);
        //            }
        //            else
        //            {
        //                //first tr3 director so give tracking number as 1
        //                crmTrace.AppendLine("no directors so it is first   ");
        //                targetEntity.SetAttributeValue(TR3TechnicalReportEntityAttribute.trackingNumber, 1);
        //            }

        //            //get the latest Mix in existing 

                    


        //        }



        //        crmTrace.AppendLine("counter:  " + counter);

        //        #endregion
             
        //        crmTrace.AppendLine("End UpdateCounterForTR3Mix Method ");
        //        // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - Final: End ", null, crmTrace.ToString(), null, null);
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber  PA", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber  PA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber  PA", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber  PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber PA", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - SetTR3DirectorTrackingNumber PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //}

        public static void DeleteTR3MixDocumentList(IOrganizationService service, Entity targetEntity,  StringBuilder crmTrace)
        {
            try
            {
                //get all the documet lists related to Tr3 Mix
                //delete the document list

                ConditionExpression condition = CreateConditionExpression(DocumentListEntityAttributeName.GotoTr3Mix, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                EntityCollection Documents = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName }, new ConditionExpression[] {condition }, LogicalOperator.And);
                crmTrace.AppendLine("Docs count:"+Documents.Entities.Count);
                if(Documents!=null && Documents.Entities.Count>0)
                {
                    foreach(Entity Document in Documents.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName,Document.Id);
                    }
                }
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - testing  PA", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList  PA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList  PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR3MixDocumentList PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


        public static void DeleteTR2TestReport(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                //get all the TR2 test reports related to Tr3 Mix
                //delete the TR2 test reports

                ConditionExpression condition = CreateConditionExpression(TR2TestReport.GotoTr3mix, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                EntityCollection Documents = RetrieveMultiple(service, TR2TestReport.EntityLogicalName, new string[] { TR2TestReport.Name }, new ConditionExpression[] { condition }, LogicalOperator.And);
                crmTrace.AppendLine("Docs count:" + Documents.Entities.Count);
                if (Documents != null && Documents.Entities.Count > 0)
                {
                    foreach (Entity Document in Documents.Entities)
                    {
                        service.Delete(TR2TestReport.EntityLogicalName, Document.Id);
                    }
                }
               // DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - testing  PA", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport  PA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport  PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport  PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport PA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "TR3MixHandler - DeleteTR2TestReport PA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
