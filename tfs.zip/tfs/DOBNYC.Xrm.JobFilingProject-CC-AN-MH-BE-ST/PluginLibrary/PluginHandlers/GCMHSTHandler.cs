﻿using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;
using System;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlersGCMHSTRelatedEntities
{
    public class GCMHSTHandler : PluginHandlerBase
    {
        //public static string CalculatePGL1Insurance(Entity targetEntity, PGL1Object Obj, StringBuilder crmTrace)
        //{
        //    string PGL1_Amount = string.Empty;
        //    try
        //    {
        //        #region
        //        crmTrace.AppendLine("Start CalculatePGL1Insurance");
        //        if (Obj.towerCrane)
        //        {
        //            crmTrace.AppendLine("PGL1_Amount : 80M");
        //            return PGL1_Amount = "80M";
        //        }
        //        else if (Obj.oneTwoFamily && !Obj.depthGreaterthen12 && !Obj.heightGreaterthen35 && !Obj.existingStructure && !Obj.raiseMove_9L)
        //        {
        //            crmTrace.AppendLine("PGL1_Amount : No PGL1 requirement");
        //            return PGL1_Amount = ParameterName.NoPGL1;
        //        }
        //        //else if(Obj.AdjacentStories < 7 && Obj.AdjacentHeight < 75 )
        //        else if (!Obj.oneTwoFamily || Obj.depthGreaterthen12 || Obj.heightGreaterthen35 || Obj.existingStructure)
        //        {
        //            if (Obj.AdjacentStories == (int)NoOfStoriesAdjBuld.Lessthan7 && (Obj.AdjacentHeight == (int)HeightOfAdjBuld.From35to75 || Obj.AdjacentHeight == (int)HeightOfAdjBuld.Lessthan35))
        //            {
        //                if (Obj.Stories < 7 && Obj.Height < 75)
        //                    return PGL1_Amount = "5M";
        //                else if (Obj.Stories <= 14 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else if (Obj.Stories <= 14 && Obj.Height >= 75 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else
        //                    return PGL1_Amount = "25M";
        //            }
        //            //else if(Obj.AdjacentStories <= 14 && Obj.AdjacentHeight < 150)
        //            else if (Obj.AdjacentStories != (int)NoOfStoriesAdjBuld.Morethan14 && Obj.AdjacentHeight != (int)HeightOfAdjBuld.Morethan150)

        //            {
        //                if (Obj.Stories < 7 && Obj.Height < 75)
        //                    return PGL1_Amount = "15M";
        //                else if (Obj.Stories <= 14 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else if (Obj.Stories <= 14 && Obj.Height >= 75 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else
        //                    return PGL1_Amount = "25M";
        //            }
        //            //else if(Obj.AdjacentStories <= 14 && Obj.AdjacentHeight >= 75 && Obj.AdjacentHeight < 150)
        //            else if (Obj.AdjacentStories != (int)NoOfStoriesAdjBuld.Morethan14 && Obj.AdjacentHeight == (int)HeightOfAdjBuld.From76to150)
        //            {
        //                if (Obj.Stories < 7 && Obj.Height < 75)
        //                    return PGL1_Amount = "15M";
        //                else if (Obj.Stories <= 14 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else if (Obj.Stories <= 14 && Obj.Height >= 75 && Obj.Height < 150)
        //                    return PGL1_Amount = "15M";
        //                else
        //                    return PGL1_Amount = "25M";
        //            }
        //            else
        //            {
        //                if (Obj.Stories < 7 && Obj.Height < 75)
        //                    return PGL1_Amount = "25M";
        //                else if (Obj.Stories <= 14 && Obj.Height < 150)
        //                    return PGL1_Amount = "25M";
        //                else if (Obj.Stories <= 14 && Obj.Height >= 75 && Obj.Height < 150)
        //                    return PGL1_Amount = "25M";
        //                else
        //                    return PGL1_Amount = "25M";
        //            }
        //        }
        //        else if (Obj.raiseMove_9L)
        //        {
        //            crmTrace.AppendLine("PGL1_Amount : 2M");
        //            return PGL1_Amount = "2M";
        //        }
        //        crmTrace.AppendLine("End CalculatePGL1Insurance");
        //        #endregion

        //        return PGL1_Amount;

        //    } // try ends here

        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //        return string.Empty;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        return string.Empty;
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - CalculatePGL1Insurance", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        return string.Empty;
        //    }


        //}

        //public static PGL1Object SetPGL1Object(Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        //{
        //    PGL1Object PGL1Obj = new PGL1Object();
        //    try
        //    {
        //        #region
        //        crmTrace.AppendLine("Start SetPGL1Object");
        //        #region Job Filing
        //        if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
        //        {
        //            crmTrace.AppendLine("targetEntity.LogicalName: " + targetEntity.LogicalName.ToString());
        //            int buildingType = targetEntity.Contains(JobFilingEntityAttributeName.BuildingType) ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value :
        //            preImage.Contains(JobFilingEntityAttributeName.BuildingType) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value : 0;
        //            PGL1Obj.oneTwoFamily = buildingType == 1 || buildingType == 2 ? true : false;
        //            crmTrace.AppendLine("PGL1Obj.oneTwoFamily: " + PGL1Obj.oneTwoFamily.ToString());
        //            PGL1Obj.depthGreaterthen12 = targetEntity.Contains(JobFilingEntityAttributeName.ExcavationGreaterthn12) ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExcavationGreaterthn12) :
        //            preImage.Contains(JobFilingEntityAttributeName.ExcavationGreaterthn12) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.ExcavationGreaterthn12) : false;
        //            crmTrace.AppendLine("PGL1Obj.depthGreaterthen12: " + PGL1Obj.depthGreaterthen12.ToString());
        //            PGL1Obj.existingStructure = targetEntity.Contains(JobFilingEntityAttributeName.IsProposedConsOnLot) ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsProposedConsOnLot) :
        //            preImage.Contains(JobFilingEntityAttributeName.IsProposedConsOnLot) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsProposedConsOnLot) : false;
        //            crmTrace.AppendLine("PGL1Obj.existingStructure: " + PGL1Obj.existingStructure.ToString());
        //            int proposedBuldHeight = targetEntity.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight) ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight) :
        //            preImage.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight) ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight) : 0;
        //            PGL1Obj.heightGreaterthen35 = proposedBuldHeight > 35;
        //            crmTrace.AppendLine("PGL1Obj.heightGreaterthen35: " + PGL1Obj.heightGreaterthen35.ToString());
        //            PGL1Obj.raiseMove_9L = targetEntity.Contains(JobFilingEntityAttributeName.WorkIncludesPartialDemolition) ? targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.WorkIncludesPartialDemolition) :
        //            preImage.Contains(JobFilingEntityAttributeName.WorkIncludesPartialDemolition) ? preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.WorkIncludesPartialDemolition) : false;
        //            crmTrace.AppendLine("PGL1Obj.raiseMove_9L: " + PGL1Obj.raiseMove_9L.ToString());

        //            PGL1Obj.AdjacentStories = targetEntity.Contains(JobFilingEntityAttributeName.NoStoriesAdjBuld) ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.NoStoriesAdjBuld).Value :
        //            preImage.Contains(JobFilingEntityAttributeName.NoStoriesAdjBuld) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.NoStoriesAdjBuld).Value : 0;
        //            crmTrace.AppendLine("PGL1Obj.AdjacentStories: " + PGL1Obj.AdjacentStories);
        //            PGL1Obj.AdjacentHeight = targetEntity.Contains(JobFilingEntityAttributeName.HeightAdjBuld) ? targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.HeightAdjBuld).Value :
        //           preImage.Contains(JobFilingEntityAttributeName.HeightAdjBuld) ? preImage.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.HeightAdjBuld).Value : 0;
        //            crmTrace.AppendLine("PGL1Obj.AdjacentHeight: " + PGL1Obj.AdjacentHeight);

        //            PGL1Obj.Stories = targetEntity.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) :
        //           preImage.Contains(JobFilingEntityAttributeName.ProposeeBuildingStories) ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposeeBuildingStories) : 0;
        //            crmTrace.AppendLine("PGL1Obj.Stories: " + PGL1Obj.Stories);
        //            PGL1Obj.Height = targetEntity.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight) ? targetEntity.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight) :
        //           preImage.Contains(JobFilingEntityAttributeName.ProposedBuildingHeight) ? preImage.GetAttributeValue<int>(JobFilingEntityAttributeName.ProposedBuildingHeight) : 0;
        //            crmTrace.AppendLine("PGL1Obj.Height: " + PGL1Obj.Height);
        //        }
        //        #endregion

        //        #region WorkPermit
        //        if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
        //        {
        //            crmTrace.AppendLine("targetEntity.LogicalName: " + targetEntity.LogicalName.ToString());
        //            PGL1Obj.towerCrane = targetEntity.Contains(WorkPermitEntityAttributeName.IsTowerCraneUsed) ? targetEntity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.IsTowerCraneUsed) :
        //           preImage.Contains(WorkPermitEntityAttributeName.IsTowerCraneUsed) ? preImage.GetAttributeValue<bool>(WorkPermitEntityAttributeName.IsTowerCraneUsed) : false;
        //            crmTrace.AppendLine("PGL1Obj.towerCrane: " + PGL1Obj.towerCrane);
        //        }
        //        #endregion
        //        crmTrace.AppendLine("End SetPGL1Object");

        //        #endregion

        //        return PGL1Obj;

        //    } // try ends here

        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //        return PGL1Obj;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        return PGL1Obj;
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetPGL1Object", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //        return PGL1Obj;
        //    }


        //}

        //public static void CreateDelete_GCMHSTRelatedEntities(IOrganizationService service, Entity targetEntity, bool create, string EntityLogicalName, StringBuilder crmTrace)
        //{
        //    try
        //    {
        //        crmTrace.AppendLine("CreateDelete_GCMHSTRelatedEntities Started!");
        //        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute));
        //        string JF_Number = JF.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute);
        //        crmTrace.AppendLine("JF_Number: " + JF_Number);
        //        #region Create FAB4 Scope of Work
        //        if (create)
        //        {
        //            #region SiteSafety
        //            if (EntityLogicalName == SiteSafetyEntityAttributeNames.EntityLogicalName)
        //            {
        //                crmTrace.AppendLine("Start Creating SiteSafety");
        //                Entity SiteSafety = new Entity(SiteSafetyEntityAttributeNames.EntityLogicalName);
        //                SiteSafety.Attributes.Add(SiteSafetyEntityAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
        //                SiteSafety.Attributes.Add(SiteSafetyEntityAttributeNames.Name, JF_Number + "-SiteSafety");
        //                SiteSafety.Attributes.Add(SiteSafetyEntityAttributeNames.SiteSafetyProject, true);
        //                Guid SiteSafety_guid = service.Create(SiteSafety);
        //                crmTrace.AppendLine("End Creating SiteSafety");

        //                crmTrace.AppendLine("Start Update JF SiteSafety Lookups");
        //                targetEntity.Attributes[JobFilingEntityAttributeName.SiteSafety_LookId] = new EntityReference(SiteSafetyEntityAttributeNames.EntityLogicalName, SiteSafety_guid);
        //                service.Update(targetEntity);
        //                crmTrace.AppendLine("End Update JF SiteSafety Lookups");

        //            }
        //            #endregion

        //        }
        //        else
        //        {
        //            #region SiteSafety
        //            if (EntityLogicalName == SiteSafetyEntityAttributeNames.EntityLogicalName)
        //            {
        //                crmTrace.AppendLine("Start Deleting SiteSafety");
        //                ConditionExpression SiteSafetyCondition = CreateConditionExpression(SiteSafetyEntityAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
        //                EntityCollection SiteSafetyResponse = RetrieveMultiple(service, SiteSafetyEntityAttributeNames.EntityLogicalName, new string[] { SiteSafetyEntityAttributeNames.Name }, new ConditionExpression[] { SiteSafetyCondition }, LogicalOperator.And);

        //                if (SiteSafetyResponse != null && SiteSafetyResponse.Entities.Count > 0)
        //                {
        //                    foreach (Entity SiteSafety in SiteSafetyResponse.Entities)
        //                        service.Delete(SiteSafety.LogicalName, SiteSafety.Id);
        //                }
        //                crmTrace.AppendLine("End Deleting SiteSafety");
        //            }
        //            #endregion

        //        }

        //        #endregion

        //        crmTrace.AppendLine("CreateDelete_GCMHSTRelatedEntities Completed!");
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_GCMHSTRelatedEntities", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //}

        //public static void Adjust_SiteSafety_Update(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        //{
        //    try
        //    {
        //        crmTrace.AppendLine("Adjust_SiteSafety Started!");
        //        #region GC Site Safety
        //        if (targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType))
        //        {
        //            if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType) != preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType))
        //            {
        //                if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType))
        //                    CreateDelete_GCMHSTRelatedEntities(service, targetEntity, true, SiteSafetyEntityAttributeNames.EntityLogicalName, crmTrace);
        //                else
        //                    CreateDelete_GCMHSTRelatedEntities(service, targetEntity, false, SiteSafetyEntityAttributeNames.EntityLogicalName, crmTrace);
        //            }

        //        }
        //        #endregion
        //        crmTrace.AppendLine("Adjust_SiteSafety Completed!");
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //    catch (Exception ex)
        //    {
        //        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", null, crmTrace.ToString(), null, null);
        //        DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Adjust_SiteSafety", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
        //    }
        //}

        public static Entity SetBPF_JobFiling(Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                #region SetBPF_JobFiling
                crmTrace.AppendLine("Start SetBPF_JobFiling");
                if ((targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                   || (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed)))
                   || (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold)))
                   || (targetEntity.Contains(JobFilingEntityAttributeName.Sign) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign))))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.FAB4_ProcessId));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.FAB4_StageId));
                    return targetEntity;
                }
                if ((targetEntity.Contains(JobFilingEntityAttributeName.AntennaWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.AntennaWorkType))
                 || (targetEntity.Contains(JobFilingEntityAttributeName.CurbCutWorkType) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CurbCutWorkType))))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.ANCC_ProcessId));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.ANCC_StageId));
                    return targetEntity;
                }
                //if ((targetEntity.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType))
                //  || (targetEntity.Contains(JobFilingEntityAttributeName.MechanicalWorkType) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType)))
                //  || (targetEntity.Contains(JobFilingEntityAttributeName.StructuralWorkType) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralWorkType))))
                //{
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.GCMHST_ProcessId));
                //    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.GCMHST_StageId));
                //    return targetEntity;
                //}
                if ((targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))
                 || (targetEntity.Contains(JobFilingEntityAttributeName.TPACheckBox) && (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox))))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.PAT_PA_ProcessId));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.PAT_PA_StageId));
                    return targetEntity;
                }
                else
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProcessId, new Guid(BPF_JobFiling.PLSPSD_ProcessId));
                    CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.StageId, new Guid(BPF_JobFiling.PLSPSD_StageId));
                }
                crmTrace.AppendLine("Start SetBPF_JobFiling");
                #endregion
                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - SetBPF_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        public static void CreateProgressInspectionCategoryRecordForPA_TPA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CreateProgressInspectionCategoryRecordFor PA/TPA method");


                string[] ColumnNames_CustomConfig = new string[] { CustomConfigurationEntityAttributeName.Key };
                ConditionExpression CustomConfigCondition_Name = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "TR1_PA" });
                EntityCollection CustomConfigResponse = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_Name }, LogicalOperator.And);
                string Key = CustomConfigResponse.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);


                // string inspectionComponentName = "Final";
                string ICId = string.Empty;
                string ICCode = string.Empty;

                string fetchXML = @"<?xml version='1.0'?>
                                      <fetch distinct='true' mapping='logical' output-format='xml-platform' version='1.0'>
                                       <entity name='dobnyc_specialinspectionscomponents'>
                                        <attribute name='dobnyc_specialinspectionscomponentsid' />
                                        <attribute name='dobnyc_code' />
                                        <attribute name='dobnyc_inspectioncomponentguid' />                                        
                                        <order attribute='dobnyc_code' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_code' operator='eq' value='" + Key + @"'/>                                          
                                        </filter>
                                      </entity>
                                    </fetch>";

                crmTrace.AppendLine("fetchXML: " + fetchXML);
                EntityCollection ICResponse = service.RetrieveMultiple(new FetchExpression(fetchXML));
                if (ICResponse.Entities != null && ICResponse.Entities.Count > 0)
                {
                    foreach (Entity icresponse in ICResponse.Entities)
                    {
                        ICId = icresponse.Id.ToString();
                        ICCode = icresponse.GetAttributeValue<string>(InspectionsComponentsEntityAttributeName.CodeSection);
                    }

                    Entity ProgressInspectionCategory = new Entity();
                    ProgressInspectionCategory.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingScope, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.InspectionType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.FilingType, new OptionSetValue(1));
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.CodeSection, ICCode);
                    ProgressInspectionCategory.Attributes.Add(ProgressInspectionCategoryAttributeNames.AddRequirement, new EntityReference(InspectionsComponentsEntityAttributeName.EntityLogicalName, Guid.Parse(ICId)));
                    service.Create(ProgressInspectionCategory);
                }

                crmTrace.AppendLine("End CreateProgressInspectionCategoryRecordFor PA/TPA method");
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "Inspection Components - Record Exists for Final: End ", null, crmTrace.ToString(), null, null);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordFor PA/TPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForPA/TPA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateProgressInspectionCategoryRecordForPA/TPA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdateTR1SpecialInspectionFields(IOrganizationService serviceConnector, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Update TR1 Special Inspcetion Fields Started");
                //Gettting the Job Filling from the Target Entity
                var queryJobFilling = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='dobnyc_mh_mechanicalscopeofwork'>
                                        <attribute name='dobnyc_mh_mechanicalscopeofworkid' />
                                        <attribute name='dobnyc_mh_certificationforlisting' />
                                        <attribute name='dobnyc_mh_modelname' />
                                        <attribute name='dobnyc_mh_manufacturersname' />
                                        <attribute name='dobnyc_mh_gotojobfiling' />
                                        <order attribute='dobnyc_mh_certificationforlisting' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_mh_mechanicalscopeofworkid' operator='eq'  uitype='dobnyc_mh_mechanicalscopeofwork' value='" + targetEntity.Id + "' />" + @"
                                        </filter>
                                      </entity>
                                    </fetch>";
                EntityCollection ecqueryjobFilling = serviceConnector.RetrieveMultiple(new FetchExpression(queryJobFilling));
                if (ecqueryjobFilling.Entities.Count > 0)
                {
                    //If Target Entity Contains Jobfilling ,Get the special Inspection Category
                    Guid jobfillingId = ecqueryjobFilling.Entities[0].GetAttributeValue<EntityReference>("dobnyc_mh_gotojobfiling").Id;
                    var querySpecB = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='dobnyc_specialinspectioncategories'>
                                    <attribute name='dobnyc_specialinspectioncategoriesid' />
                                    <attribute name='dobnyc_completionstatementdate' />
                                    <attribute name='dobnyc_inspectionapplicantnamecompletionstatemen' />
                                    <attribute name='dobnyc_certificateofcompletionstatement' />
                                    <order attribute='dobnyc_completionstatementdate' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='dobnyc_jobfilingtospecialinspectionscaid' operator='eq'  uitype='dobnyc_jobfiling' value='" + jobfillingId + "' />" + @"
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                  </entity>
                                </fetch>";
                    EntityCollection ecspecB = serviceConnector.RetrieveMultiple(new FetchExpression(querySpecB));
                    if (ecspecB.Entities.Count > 0)
                    {  //Updating fields to null
                        foreach (Entity eSpecialB in ecspecB.Entities)
                        {
                            Entity eSpecB = new Entity("dobnyc_specialinspectioncategories");
                            eSpecB.Id = eSpecialB.Id;
                            eSpecB.Attributes["dobnyc_completionstatementdate"] = null;
                            eSpecB.Attributes["dobnyc_inspectionapplicantnamecompletionstatemen"] = null;
                            eSpecB.Attributes["dobnyc_certificateofcompletionstatement"] = false;
                            serviceConnector.Update(eSpecB);
                        }
                    }
                }
                crmTrace.AppendLine("Update TR1 Special Inspcetion Fields Completed");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GCMHSTHandler - Update TR1", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }


    }


    public class PGL1Object
    {
        public bool oneTwoFamily { get; set; }
        public bool towerCrane { get; set; }
        public bool depthGreaterthen12 { get; set; }
        public bool existingStructure { get; set; }
        public bool heightGreaterthen35 { get; set; }
        public bool raiseMove_9L { get; set; }
        public int AdjacentStories { get; set; }
        public int AdjacentHeight { get; set; }
        public int Stories { get; set; }
        public int Height { get; set; }
    }
}

