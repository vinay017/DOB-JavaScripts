﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class FAB4ScopeofWorkHandler : PluginHandlerBase
    {
        public static void Adjust_FAB4ScopeofWork(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Adjust_FAB4ScopeofWork Started!");
                #region FN Scope of Work
               if(targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence))
                {
                    if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, true, FenceScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    else
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, false, FenceScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                }
                #endregion

                #region SF Scope of Work
                if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                {
                    if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold))
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, true, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    else
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, false, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                }
                #endregion

                #region SH Scope of Work
                if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed))
                {
                    if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed))
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, true, SHScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    else
                        CreateDelete_FAB4ScopeofWork(service, targetEntity, false, SHScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                }
                #endregion

                crmTrace.AppendLine("Adjust_FAB4ScopeofWork Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void Adjust_FAB4ScopeofWork_Update(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Adjust_FAB4ScopeofWork Started!");
                #region FN Scope of Work
                if (targetEntity.Contains(JobFilingEntityAttributeName.ConstructionFence))
                {
                    if(targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence) != preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                    {
                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence))
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, true, FenceScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                        else
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, false, FenceScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    }
                    
                }
                #endregion

                #region SF Scope of Work
                if (targetEntity.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                {
                   if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold) != preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold))
                    {
                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold))
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, true, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                        else
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, false, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    }
             
                }
                #endregion

                #region SH Scope of Work
                if (targetEntity.Contains(JobFilingEntityAttributeName.SidewalkShed))
                {
                    if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed) != preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed))
                    {
                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed))
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, true, SHScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                        else
                            CreateDelete_FAB4ScopeofWork(service, targetEntity, false, SHScopeofWorkAttributeNames.EntityLogicalName, crmTrace);
                    }
                        
                }
                #endregion

                crmTrace.AppendLine("Adjust_FAB4ScopeofWork Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - Adjust_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateDelete_FAB4ScopeofWork(IOrganizationService service, Entity targetEntity, bool create, string scopeofWorkEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("CreateDelete_FAB4ScopeofWork Started!");
                Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute));
                string JF_Number = JF.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute);
                crmTrace.AppendLine("JF_Number: " + JF_Number);
                #region Create FAB4 Scope of Work
                if (create)
                {
                    #region FN_SW
                    if (scopeofWorkEntity == FenceScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Creating FN_SW");
                        Entity FN_Scopeofwork = new Entity(FenceScopeofWorkAttributeNames.EntityLogicalName);
                        FN_Scopeofwork.Attributes.Add(FenceScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        FN_Scopeofwork.Attributes.Add(FenceScopeofWorkAttributeNames.Name, JF_Number + "-FN_SW");
                        Guid FN_Scopeofwork_guid = service.Create(FN_Scopeofwork);
                        crmTrace.AppendLine("End Creating FN_SW");

                        crmTrace.AppendLine("Start Update JF FAB4 SW Lookups");
                        targetEntity.Attributes[JobFilingEntityAttributeName.FenceScopeofWorklookup] = new EntityReference(FenceScopeofWorkAttributeNames.EntityLogicalName, FN_Scopeofwork_guid);
                        service.Update(targetEntity);
                        crmTrace.AppendLine("End Update JF FAB4 SW Lookups");

                    }
                    #endregion

                    #region SF_SW
                    if (scopeofWorkEntity == ScaffoldScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Creating SF_SW");
                        Entity SF_Scopeofwork = new Entity(ScaffoldScopeofWorkAttributeNames.EntityLogicalName);
                        SF_Scopeofwork.Attributes.Add(ScaffoldScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        SF_Scopeofwork.Attributes.Add(ScaffoldScopeofWorkAttributeNames.Name, JF_Number + "-SF_SW");
                        //Added because  In portal they have to see null value while creation
                        SF_Scopeofwork.Attributes.Add(ScaffoldScopeofWorkAttributeNames.IsTheSupportedScaffoldGoing, null);
                        SF_Scopeofwork.Attributes.Add(ScaffoldScopeofWorkAttributeNames.IsThereAnyRelatedConstructione, null);


                        Guid SF_Scopeofwork_guid = service.Create(SF_Scopeofwork);
                        crmTrace.AppendLine("End Creating SF_SW");

                        crmTrace.AppendLine("Start Update JF FAB4 SW Lookups");
                        targetEntity.Attributes[JobFilingEntityAttributeName.ScaffoldScopeofWorklookup] = new EntityReference(ScaffoldScopeofWorkAttributeNames.EntityLogicalName, SF_Scopeofwork_guid);
                        service.Update(targetEntity);
                        crmTrace.AppendLine("End Update JF FAB4 SW Lookups");
                    }
                    #endregion

                    #region SH_SW
                    if (scopeofWorkEntity == SHScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Creating SH_SW");
                        Entity SH_Scopeofwork = new Entity(SHScopeofWorkAttributeNames.EntityLogicalName);
                        SH_Scopeofwork.Attributes.Add(SHScopeofWorkAttributeNames.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        SH_Scopeofwork.Attributes.Add(SHScopeofWorkAttributeNames.Name, JF_Number + "-SH_SW");
                        //Added because  In portal they have to see null value while creation
                        SH_Scopeofwork.Attributes.Add(SHScopeofWorkAttributeNames.extendPropertyLines, null);
                        SH_Scopeofwork.Attributes.Add(SHScopeofWorkAttributeNames.relatedConstruction, null);


                        Guid SH_Scopeofwork_guid = service.Create(SH_Scopeofwork);
                        crmTrace.AppendLine("End Creating SH_SW");

                        crmTrace.AppendLine("Start Update JF FAB4 SW Lookups");
                        targetEntity.Attributes[JobFilingEntityAttributeName.SHScopeofWorklookup] = new EntityReference(SHScopeofWorkAttributeNames.EntityLogicalName, SH_Scopeofwork_guid);
                        service.Update(targetEntity);
                        crmTrace.AppendLine("End Update JF FAB4 SW Lookups");
                    }
                    #endregion
                }
                else
                {
                    #region FN_SW
                    if (scopeofWorkEntity == FenceScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Deleting FN_SW");
                        ConditionExpression FN_ScopeofworkCondition = CreateConditionExpression(FenceScopeofWorkAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection FN_ScopeofworkResponse = RetrieveMultiple(service, FenceScopeofWorkAttributeNames.EntityLogicalName, new string[] { FenceScopeofWorkAttributeNames.Name }, new ConditionExpression[] { FN_ScopeofworkCondition }, LogicalOperator.And);

                        if (FN_ScopeofworkResponse != null && FN_ScopeofworkResponse.Entities.Count > 0)
                        {
                            foreach (Entity FN_SW in FN_ScopeofworkResponse.Entities)
                                service.Delete(FN_SW.LogicalName, FN_SW.Id);
                        }
                        crmTrace.AppendLine("End Deleting FN_SW");
                    }
                    #endregion

                    #region SF_SW
                    if (scopeofWorkEntity == ScaffoldScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Deleting SF_SW");
                        ConditionExpression SF_ScopeofworkCondition = CreateConditionExpression(ScaffoldScopeofWorkAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection SF_ScopeofworkResponse = RetrieveMultiple(service, ScaffoldScopeofWorkAttributeNames.EntityLogicalName, new string[] { ScaffoldScopeofWorkAttributeNames.Name }, new ConditionExpression[] { SF_ScopeofworkCondition }, LogicalOperator.And);

                        if (SF_ScopeofworkResponse != null && SF_ScopeofworkResponse.Entities.Count > 0)
                        {
                            foreach (Entity SF_SW in SF_ScopeofworkResponse.Entities)
                                service.Delete(SF_SW.LogicalName, SF_SW.Id);
                        }
                        crmTrace.AppendLine("End Deleting SF_SW");
                    }
                    #endregion

                    #region SH_SW
                    if (scopeofWorkEntity == SHScopeofWorkAttributeNames.EntityLogicalName)
                    {
                        crmTrace.AppendLine("Start Deleting SH_SW");
                        ConditionExpression SH_ScopeofworkCondition = CreateConditionExpression(SHScopeofWorkAttributeNames.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                        EntityCollection SH_ScopeofworkResponse = RetrieveMultiple(service, SHScopeofWorkAttributeNames.EntityLogicalName, new string[] { SHScopeofWorkAttributeNames.Name }, new ConditionExpression[] { SH_ScopeofworkCondition }, LogicalOperator.And);

                        if (SH_ScopeofworkResponse != null && SH_ScopeofworkResponse.Entities.Count > 0)
                        {
                            foreach (Entity SH_SW in SH_ScopeofworkResponse.Entities)
                                service.Delete(SH_SW.LogicalName, SH_SW.Id);
                        }
                        crmTrace.AppendLine("End Deleting SH_SW");
                    }
                    #endregion

                }

                #endregion

                crmTrace.AppendLine("CreateDelete_FAB4ScopeofWork Completed!");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "FAB4ScopeofWorkHandler - CreateDelete_FAB4ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}
