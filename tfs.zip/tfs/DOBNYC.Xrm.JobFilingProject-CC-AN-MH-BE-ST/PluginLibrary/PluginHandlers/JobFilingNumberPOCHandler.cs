﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobFilingNumberPOCHandler : PluginHandlerBase
    {
        public static void JobFilingNumberGenerator(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            Entity entity = null;
            try
            {

                EntityCollection getSequenceNumberResponse = null;
                ConditionExpression autoNumbercondition = CreateConditionExpression(JobAutoNumberEntityAttribute.EntityNameAttribute, ConditionOperator.Equal, new string[] { "Job Sequence Number" });
                getSequenceNumberResponse = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.JobNumberCounterAttribute, JobAutoNumberEntityAttribute.LockRecordAttribute }, new ConditionExpression[] { autoNumbercondition }, LogicalOperator.And);

                if (getSequenceNumberResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Lock The Record on AutoNumber - Start");
                    if (((OptionSetValue)getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.LockRecordAttribute]).Value == 1)
                    {
                        while (((OptionSetValue)getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.LockRecordAttribute]).Value < 2)
                        {
                            getSequenceNumberResponse = RetrieveMultiple(service, JobAutoNumberEntityAttribute.EntityLogicalName, new string[] { JobAutoNumberEntityAttribute.JobNumberCounterAttribute, JobAutoNumberEntityAttribute.LockRecordAttribute }, new ConditionExpression[] { autoNumbercondition }, LogicalOperator.And);
                        }
                    }
                    else if (((OptionSetValue)getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.LockRecordAttribute]).Value == 2)
                    {
                        entity = new Entity(JobAutoNumberEntityAttribute.EntityLogicalName);
                        entity.Id = getSequenceNumberResponse.Entities[0].Id;
                        entity.Attributes.Add(JobAutoNumberEntityAttribute.LockRecordAttribute, new OptionSetValue(1));
                        service.Update(entity);
                        crmTrace.AppendLine("Lock The Record on AutoNumber - End");
                    }

                    crmTrace.AppendLine("Update NumberSequence with Job Number - Start");
                    entity = new Entity(NumberSequenceEntityAttributeNames.EntityLogicalName);
                    entity.Id = targetEntity.Id;

                    entity.Attributes.Add(NumberSequenceEntityAttributeNames.JobFilingNumber, (Convert.ToUInt32(decimal.Parse(getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.JobNumberCounterAttribute].ToString())) + 1).ToString());
                    entity.Attributes.Add(NumberSequenceEntityAttributeNames.PrimaryNameAttribute, (Convert.ToUInt32(decimal.Parse(getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.JobNumberCounterAttribute].ToString())) + 1).ToString());
                    service.Update(entity);
                    crmTrace.AppendLine("Update NumberSequence - End");
                    
                    crmTrace.AppendLine("Update JobFiling with Job Number - Start");
                    Entity jobfiling = new Entity();
                    jobfiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                    jobfiling.Id = ((EntityReference)targetEntity.Attributes[NumberSequenceEntityAttributeNames.JobFilingGUID]).Id;
                    jobfiling.Attributes.Add(JobFilingEntityAttributeName.ProjectNumberAttributeName, (Convert.ToInt32(decimal.Parse(getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.JobNumberCounterAttribute].ToString())) + 1).ToString());
                    jobfiling.Attributes.Add(JobFilingEntityAttributeName.EntityAttributeName, (Convert.ToInt32(decimal.Parse(getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.JobNumberCounterAttribute].ToString())) + 1).ToString());
                    service.Update(jobfiling);
                    crmTrace.AppendLine("Update JobFiling with Job Number - End");

                    crmTrace.AppendLine("Update Job Autonumber Entity with modified sequence number - Start");
                    entity = new Entity(JobAutoNumberEntityAttribute.EntityLogicalName);
                    entity.Id = getSequenceNumberResponse.Entities[0].Id;
                    entity.Attributes.Add(JobAutoNumberEntityAttribute.LockRecordAttribute, new OptionSetValue(2));
                    entity.Attributes.Add(JobAutoNumberEntityAttribute.JobNumberCounterAttribute, (decimal)(getSequenceNumberResponse.Entities[0].Attributes[JobAutoNumberEntityAttribute.JobNumberCounterAttribute]) + 1);
                    service.Update(entity);
                    crmTrace.AppendLine("Update Job Autonumber Entity with modified sequence number - End");

                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingNumberPOCHandler - JobFilingNumberGenerator", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }
    }
}
