﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.ServiceModel;
using System.Text;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class L2NumberGeneratorHandler : PluginHandlerBase
    {
        public static void GenerateL2RequestNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            string jobFiling = string.Empty;            
            int sequenceNumber = 1;

            try
            {
                crmTrace.AppendLine("GenerateL2RequestNumber - Start");
                Guid jobFilingGuid = ((EntityReference)targetEntity.Attributes[L2RequestAttributeNames.GoToJobFiling]).Id;
                string jobFilingName = string.Empty;

                crmTrace.AppendLine("jobFilingGuid: " + jobFilingGuid);

                if (jobFilingGuid != Guid.Empty)
                {
                    #region Get Job Filing Name
                    Entity jobFilingEntity = new Entity();
                    string[] ColumnNames_JobFiling = { JobFilingEntityAttributeName.EntityAttributeName, JobFilingEntityAttributeName.BuildingType, JobFilingEntityAttributeName.NewWorkFilingFee };
                    jobFilingEntity = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                    crmTrace.AppendLine("Get Job Filing Name");
                    if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.EntityAttributeName))
                        jobFilingName = jobFilingEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.EntityAttributeName);

                    #endregion

                    #region Set Sequence Number

                    ConditionExpression L2Condition1 = CreateConditionExpression(L2RequestAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    EntityCollection L2Response = RetrieveMultiple(service, L2RequestAttributeNames.EntityLogicalName, new string[] { L2RequestAttributeNames.TrackingNumber }, new ConditionExpression[] { L2Condition1 }, LogicalOperator.And);

                    crmTrace.AppendLine("L2Request Count: " + L2Response.Entities.Count);

                    if (L2Response.Entities.Count > 0)
                    {
                        sequenceNumber = L2Response.Entities.Count + 1;
                    }

                    #endregion

                    Random rnd = new Random();
                    int nineDigitRandom = rnd.Next(100000000, 999999999);
                    decimal l2Fee = 0;

                    CommonPluginLibrary.SetAttributeValue(targetEntity, L2RequestAttributeNames.Name, nineDigitRandom.ToString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, L2RequestAttributeNames.SequenceNumber, sequenceNumber);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, L2RequestAttributeNames.TrackingNumber, nineDigitRandom.ToString());

                    l2Fee = CalculateL2Fee(service, jobFilingEntity, crmTrace);

                    CommonPluginLibrary.SetAttributeValue(targetEntity, L2RequestAttributeNames.L2Fee, l2Fee);

                    crmTrace.AppendLine("GenerateL2RequestNumber - Updated");
                }
                crmTrace.AppendLine("GenerateL2RequestNumber - End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - FaultException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - TimeoutException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - Exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GenerateL2RequestNumber - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        //For future user - If required.
        public static int GetRandomNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            Random rnd = new Random();
            int random = 0;
            try
            {
                #region Set Tracking Number
                random = rnd.Next(100000000, 999999999);

                ConditionExpression L2Condition = CreateConditionExpression(L2RequestAttributeNames.TrackingNumber, ConditionOperator.Equal, new string[] { random.ToString() });
                EntityCollection L2Response = RetrieveMultiple(service, L2RequestAttributeNames.EntityLogicalName, new string[] { L2RequestAttributeNames.TrackingNumber }, new ConditionExpression[] { L2Condition }, LogicalOperator.And);

                if (L2Response.Entities.Count > 0)
                {
                    random = GetRandomNumber(service, targetEntity, crmTrace);
                }
                #endregion

                return random;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - FaultException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return random;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - TimeoutException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return random;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - Exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - GetRandomNumber - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return random;
            }
        }

        public static void SetL2Fee(IOrganizationService service, Entity targetL2Entity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("SetL2Fee - Start");
                decimal l2Fee = 0;
                #region Get Job Filing Details and update L2 Request with proper L2 Fee
                Guid jobFilingGuid = ((EntityReference)targetL2Entity.Attributes[L2RequestAttributeNames.GoToJobFiling]).Id;
                if (jobFilingGuid != Guid.Empty)
                {
                    Entity jobFilingEntity = new Entity();
                    string[] ColumnNames_JobFiling = { JobFilingEntityAttributeName.EntityAttributeName, JobFilingEntityAttributeName.BuildingType, JobFilingEntityAttributeName.NewWorkFilingFee };
                    jobFilingEntity = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                    crmTrace.AppendLine("Calculate L2 Fee - Start");
                    l2Fee = CalculateL2Fee(service, jobFilingEntity, crmTrace);
                    crmTrace.AppendLine("Calculate L2 Fee - End");

                    Entity L2Request = new Entity();
                    L2Request.LogicalName = L2RequestAttributeNames.EntityLogicalName;
                    L2Request.Id = targetL2Entity.Id;
                    L2Request.Attributes.Add(L2RequestAttributeNames.L2Fee, l2Fee);
                    service.Update(L2Request);
                }
                #endregion
                crmTrace.AppendLine("SetL2Fee - End");

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - FaultException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - TimeoutException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - Exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetL2Entity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - SetL2Fee - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static decimal CalculateL2Fee(IOrganizationService service, Entity jobFilingEntity, StringBuilder crmTrace)
        {
            decimal l2Fee = 0, jobFilingFee = 0;
            int buildingType = 0;
            
            try
            {
                #region Get Job Filing Fee Details
                crmTrace.AppendLine("Get Job Filing Fee");
                if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.NewWorkFilingFee))
                    jobFilingFee = ((Money)(jobFilingEntity.Attributes[JobFilingEntityAttributeName.NewWorkFilingFee])).Value;

                crmTrace.AppendLine("jobFilingFee: " + jobFilingFee);
                #endregion

                #region Get Job Filing Building Type Details
                crmTrace.AppendLine("Get Job Filing Building Type");
                if (jobFilingEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                    buildingType = jobFilingEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value;

                crmTrace.AppendLine("buildingType: " + buildingType);

                if (buildingType == 0)
                {
                    ConditionExpression zoningCondition1 = CreateConditionExpression(ZoningCharactersticsPW1AttributeNames.JobFilingGuid, ConditionOperator.Equal, new string[] { jobFilingEntity.Id.ToString() });
                    EntityCollection zoningResponse = RetrieveMultiple(service, ZoningCharactersticsPW1AttributeNames.EntityLogicalName, new string[] { ZoningCharactersticsPW1AttributeNames.BuildingType }, new ConditionExpression[] { zoningCondition1 }, LogicalOperator.And);
                    if (zoningResponse.Entities.Count > 0)
                    {
                        buildingType = zoningResponse.Entities[0].GetAttributeValue<OptionSetValue>(ZoningCharactersticsPW1AttributeNames.BuildingType).Value;
                        crmTrace.AppendLine("buildingType: " + buildingType);
                    }
                }
                #endregion

                #region Calculate L2 Fee
                if (buildingType == (int)BuildingTypeForL2.Family1 || buildingType == (int)BuildingTypeForL2.Family2 || buildingType == (int)BuildingTypeForL2.Family3)
                {
                    if(jobFilingFee > 0)
                    {
                        l2Fee = (int)L2FeeValues.Family123Times * jobFilingFee;

                        if (l2Fee > (decimal)L2FeeValues.Family123Max)
                        {
                            l2Fee = (decimal)L2FeeValues.Family123Max;
                        }
                        else if (l2Fee < (decimal)L2FeeValues.Family123Min)
                        {
                            l2Fee = (decimal)L2FeeValues.Family123Min;
                        }
                    }
                    else
                    {
                        l2Fee = (decimal)L2FeeValues.Family123Min;
                    }
                }
                else if (buildingType == (int)BuildingTypeForL2.Other)
                {
                    if (jobFilingFee > 0)
                    {
                        l2Fee = (int)L2FeeValues.FamilyOtherTimes * jobFilingFee;

                        if (l2Fee > (decimal)L2FeeValues.FamilyOtherMax)
                        {
                            l2Fee = (decimal)L2FeeValues.FamilyOtherMax;
                        }
                        else if (l2Fee < (decimal)L2FeeValues.FamilyOtherMin)
                        {
                            l2Fee = (decimal)L2FeeValues.FamilyOtherMin;
                        }
                    }
                    else
                    {
                        l2Fee = (decimal)L2FeeValues.FamilyOtherMin;
                    }
                }
                #endregion

                return l2Fee;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - FaultException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - FaultException", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return l2Fee;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - TimeoutException", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - TimeoutException", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return l2Fee;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - Exception", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingEntity.Id.ToString(), SourceChannel.CRM, "GenerateL2RequestNumber - CalculateL2Fee - Exception", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return l2Fee;
            }
        }

    }
}
