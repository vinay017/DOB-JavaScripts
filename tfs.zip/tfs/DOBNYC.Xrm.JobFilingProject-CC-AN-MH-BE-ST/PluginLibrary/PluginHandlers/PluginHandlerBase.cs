﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.Helpers;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk.Metadata;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
        public class PluginHandlerBase
        {

            public static void SetStateDynamic(IOrganizationService connector, string entityName, Guid entityId, int stateCode, int statusCode)
            {
                try
                {
                    SetStateRequest request = new SetStateRequest();
                    request.EntityMoniker = new EntityReference();
                    request.EntityMoniker.Id = entityId;
                    request.EntityMoniker.LogicalName = entityName;
                    request.State = new OptionSetValue(stateCode);
                    request.Status = new OptionSetValue(statusCode);

                    connector.Execute(request);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw ex;
                }
            }

            public static RetrieveResponse RetrieveEntity(IOrganizationService connector, Guid entityId, string entityName)
            {
                try
                {
                    return RetrieveEntity(connector, null, entityId, entityName);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw ex;
                }
            }

            public static RetrieveResponse RetrieveEntity(IOrganizationService connector, string[] columnNames, Guid entityId, string entityName)
            {
                try
                {
                    EntityReference reference = new EntityReference();
                    reference.Id = entityId;
                    reference.LogicalName = entityName;

                    RetrieveRequest request = new RetrieveRequest();
                    request.Target = reference;
                    request.ColumnSet = GenerateColumnSet(columnNames);

                    return (RetrieveResponse)connector.Execute(request);
                }
                catch (Exception ex)
                {
                    ///ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw ex;
                }
            }

            public static Entity Retrieve(IOrganizationService connector, string[] columnNames, Guid entityId, string entityName)
            {
                try
                {
                    ColumnSet columns = GenerateColumnSet(columnNames);
                    return connector.Retrieve(entityName, entityId, columns);
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw ex;
                }
            }

            protected static RetrieveMultipleResponse RetrieveMultipleEntity(IOrganizationService connector, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator)
            {
                try
                {
                    return RetrieveMultipleEntity(connector, entityName, columnNames, conditions, logicalOperator, null);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw ex;
                }
            }

            protected static RetrieveMultipleResponse RetrieveMultipleEntity(IOrganizationService connector, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, PagingInfo pagingInfo)
            {
                try
                {
                    FilterExpression filterExpression = new FilterExpression();
                    filterExpression.Conditions.AddRange(conditions);
                    filterExpression.FilterOperator = logicalOperator;

                    QueryExpression queryExpression = new QueryExpression();
                    queryExpression.ColumnSet = GenerateColumnSet(columnNames);
                    queryExpression.EntityName = entityName;
                    queryExpression.Criteria = filterExpression;
                    queryExpression.NoLock = true;
                    if (pagingInfo != null)
                        queryExpression.PageInfo = pagingInfo;

                    RetrieveMultipleRequest request = new RetrieveMultipleRequest();
                    request.Query = queryExpression;

                    return (RetrieveMultipleResponse)connector.Execute(request);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);

                    throw ex;
                }
            }

        protected static EntityCollection RetrieveMultipleforJobNumber(IOrganizationService connector, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator)
        {
            try
            {
                FilterExpression filterExpression = new FilterExpression();
                filterExpression.Conditions.AddRange(conditions);
                filterExpression.FilterOperator = logicalOperator;

                QueryExpression queryExpression = new QueryExpression();
                queryExpression.ColumnSet = GenerateColumnSet(columnNames);
                queryExpression.EntityName = entityName;
                queryExpression.Criteria = filterExpression;
                queryExpression.NoLock = false;
                return (EntityCollection)connector.RetrieveMultiple(queryExpression);
            }
            catch (Exception ex)
            {
                ///ExceptionLibrary.ExceptionMethods.ProcessException(ex);

                throw;
            }
        }


        protected static EntityCollection RetrieveMultiple(IOrganizationService connector, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator)
            {
                try
                {
                    FilterExpression filterExpression = new FilterExpression();
                    filterExpression.Conditions.AddRange(conditions);
                    filterExpression.FilterOperator = logicalOperator;

                    QueryExpression queryExpression = new QueryExpression();
                    queryExpression.ColumnSet = GenerateColumnSet(columnNames);
                    queryExpression.EntityName = entityName;
                    queryExpression.Criteria = filterExpression;
                    queryExpression.NoLock = true;
                    return (EntityCollection)connector.RetrieveMultiple(queryExpression);
                }
                catch (Exception ex)
                {
                    ///ExceptionLibrary.ExceptionMethods.ProcessException(ex);

                    throw;
                }
            }


            protected static EntityCollection RetrieveMultiple(IOrganizationService connector, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator,string orderbyAttribute, OrderType orderBy,int topRecord)
            {
                try
                {
                    FilterExpression filterExpression = new FilterExpression();
                    filterExpression.Conditions.AddRange(conditions);
                    filterExpression.FilterOperator = logicalOperator;

                    QueryExpression queryExpression = new QueryExpression();
                    queryExpression.ColumnSet = GenerateColumnSet(columnNames);
                    queryExpression.EntityName = entityName;
                    queryExpression.Criteria = filterExpression;
                    queryExpression.Orders.Add(new OrderExpression(orderbyAttribute, orderBy));
                    queryExpression.NoLock=true;
                    queryExpression.TopCount = topRecord;
                    return (EntityCollection)connector.RetrieveMultiple(queryExpression);
                }
                catch (Exception ex)
                {
                    ///ExceptionLibrary.ExceptionMethods.ProcessException(ex);

                    throw;
                }
            }

            protected static RetrieveMultipleResponse RetrieveMultipleEntity(IOrganizationService connector, QueryExpression queryExpression)
            {
                try
                {
                    RetrieveMultipleRequest request = new RetrieveMultipleRequest();
                    request.Query = queryExpression;

                    return (RetrieveMultipleResponse)connector.Execute(request);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static void UpdateEntity(IOrganizationService connector, Entity entity)
            {
                try
                {
                    connector.Update(entity);
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            #region QueryHelper

            protected static QueryExpression CreateQueryExpression(string entityName, string[] columnNames)
            {
                QueryExpression queryExpression = new QueryExpression();
                try
                {
                    queryExpression.EntityName = entityName;
                    queryExpression.ColumnSet = GenerateColumnSet(columnNames);
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }

                return queryExpression;
            }

            protected static QueryExpression CreateQueryExpressionWithAllColumns(string entityName)
            {
                QueryExpression queryExpression = new QueryExpression();
                try
                {
                    queryExpression.EntityName = entityName;
                    queryExpression.ColumnSet = new ColumnSet(true);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
                return queryExpression;
            }

            protected static ConditionExpression CreateConditionExpression(string attributeName, ConditionOperator conditionOperator, object[] conditionValues)
            {
                ConditionExpression conditionExpression = new ConditionExpression();
                try
                {
                    conditionExpression.AttributeName = attributeName;
                    conditionExpression.Operator = conditionOperator;
                    if (conditionValues != null && conditionValues.Length > 0)
                    {
                        conditionExpression.Values.AddRange(conditionValues);
                    }
                }
                catch (Exception ex) {
               // ExceptionLibrary.ExceptionMethods.ProcessException(ex); return null;
            }
                return conditionExpression;
            }

            protected static OrderExpression CreateOrderExpression(string attributeName, OrderType orderType)
            {
                OrderExpression orderExpression = new OrderExpression();
                try
                {
                    orderExpression.AttributeName = attributeName;
                    orderExpression.OrderType = orderType;
                }
                catch (Exception ex) {
                //ExceptionLibrary.ExceptionMethods.ProcessException(ex); return null;
            }
                return orderExpression;
            }

            protected static LinkEntity CreateLinkEntity(string fromEntityName, string fromEntityAttribute, string toEntityName, string toEntityAttribute)
            {
                LinkEntity linkEntity = new LinkEntity();
                try
                {
                    linkEntity.LinkFromEntityName = fromEntityName;
                    linkEntity.LinkFromAttributeName = fromEntityAttribute;
                    linkEntity.LinkToEntityName = toEntityName;
                    linkEntity.LinkToAttributeName = toEntityAttribute;
                }
                catch (Exception ex) { //ExceptionLibrary.ExceptionMethods.ProcessException(ex); 
                                       //return null;
            }
                return linkEntity;
            }

            protected static ColumnSet GenerateColumnSet(string[] columnNames)
            {
                ColumnSet columns = null;
                try
                {
                    if (columnNames == null || columnNames.Length == 0)
                        columns = new ColumnSet(true);
                    else
                        columns = new ColumnSet(columnNames);
                }
                catch (Exception ex) {
               // ExceptionLibrary.ExceptionMethods.ProcessException(ex); return null;
            }
                return columns;

            }
            #endregion

            protected static CreateResponse CreateEntity(IOrganizationService connector, string entityName, AttributeCollection properties)
            {
                try
                {
                    Entity entity = new Entity();
                    entity.LogicalName = entityName;
                    entity.Attributes = properties;

                    CreateRequest request = new CreateRequest();
                    request.Target = entity;

                    return (CreateResponse)connector.Execute(request);

                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static Guid CreateEntity(IOrganizationService connector, Entity entity)
            {
                Guid Id = new Guid();

                try
                {
                    Id = connector.Create(entity);
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
                return Id;

            }



            public static Boolean IsRetrieveMultipleResponseNull(RetrieveMultipleResponse response)
            {
                try
                {
                    if (response == null)
                    {
                        return true;
                    }
                    if (response.EntityCollection == null)
                    {
                        return true;
                    }
                    if (response.EntityCollection.Entities == null)
                    {
                        return true;
                    }

                    if (response.EntityCollection.Entities.Count == 0)
                    {
                        return true;
                    }

                    return false;
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static List<Entity> GetEntityCollectionFromRetrieveMultipleResponse(RetrieveMultipleResponse response)
            {
                try
                {
                    if (IsRetrieveMultipleResponseNull(response))
                        return null;

                    else
                    {
                        List<Entity> dynamicEntityCollection = new List<Entity>();
                        foreach (Entity be in response.EntityCollection.Entities)
                        {
                            dynamicEntityCollection.Add((Entity)be);
                        }
                        return dynamicEntityCollection;
                    }
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }

            }

        public static string ConvertToCRMFormat(string dateString)
        {
            try
            {
                if (!string.IsNullOrEmpty(dateString) && dateString.Length == 10 && !dateString.Contains("0000-00-00"))
                {
                    return dateString.Substring(5, 2) + "/"
                        + dateString.Substring(8, 2) + "/" +
                        dateString.Substring(0, 4);
                }

                if (!string.IsNullOrEmpty(dateString) && dateString.Length == 24 && !dateString.Contains("0000-00-00T00:00:00.000Z"))
                {
                    return dateString.Substring(5, 2) + "/"
                        + dateString.Substring(8, 2) + "/" +
                        dateString.Substring(0, 4) + " " + dateString.Substring(11, 2) + ":" + dateString.Substring(14, 2) + ":" + dateString.Substring(17, 2);
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection GetDublicatedEntities(IOrganizationService connector, string entityName, string[] columnNames, Dictionary<string, string> conditionValues, LogicalOperator logicalOperator, string selfId)
            {
                try
                {

                    List<ConditionExpression> conditionList = new List<ConditionExpression>();
                    foreach (KeyValuePair<string, string> pair in conditionValues)
                    {
                        ConditionExpression temp = new ConditionExpression();
                        temp.AttributeName = pair.Key;
                        temp.Operator = ConditionOperator.Equal;
                        temp.Values.Add(pair.Value);
                        conditionList.Add(temp);
                    }
                    //Exclude the entity itself on Update operations
                    if (!string.IsNullOrEmpty(selfId))
                    {
                        ConditionExpression selfCheck = new ConditionExpression();
                        selfCheck.AttributeName = entityName + "id";
                        selfCheck.Operator = ConditionOperator.NotEqual;
                        selfCheck.Values.Add(selfId);
                        conditionList.Add(selfCheck);
                    }

                    ConditionExpression[] conditionCollection = conditionList.ToArray();
                    RetrieveMultipleResponse response = RetrieveMultipleEntity(connector, entityName, columnNames, conditionCollection, logicalOperator);

                    if (IsRetrieveMultipleResponseNull(response))
                    {
                        return null;
                    }
                    else
                    {
                        return response.EntityCollection;
                    }
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static Entity MergePreImageAndTarget(Entity dynamicTargetEntity, Entity preEntity)
            {
                try
                {
                    if (dynamicTargetEntity == null && preEntity == null) return null;
                    if (preEntity == null) return null;

                    foreach (var item in dynamicTargetEntity.Attributes)
                    {
                        if (preEntity.Attributes.Keys.Contains(item.Key))
                        {
                            preEntity.Attributes[item.Key] = item.Value;
                        }
                        else
                        {
                            preEntity.Attributes.Add(item);
                        }
                    }

                    return preEntity;
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static void AddToQueue(IOrganizationService connector, Guid sourceQueueId, Guid destinationQueueId, string targetEntityName, Guid targetId)
            {
                try
                {
                    AddToQueueRequest routeRequest = null;
                    if (sourceQueueId != Guid.Empty)
                    {
                        routeRequest = new AddToQueueRequest
                        {
                            SourceQueueId = sourceQueueId,
                            Target = new EntityReference(targetEntityName, targetId),
                            DestinationQueueId = destinationQueueId
                        };
                    }
                    else
                    {
                        routeRequest = new AddToQueueRequest
                        {
                            Target = new EntityReference(targetEntityName, targetId),
                            DestinationQueueId = destinationQueueId
                        };
                    }

                    // Execute the Request
                    connector.Execute(routeRequest);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static void ExecuteWorkflow(IOrganizationService connector, Guid workflowId, Guid entityId)
            {
                try
                {
                    ExecuteWorkflowRequest request = new ExecuteWorkflowRequest
                    {
                        EntityId = entityId,
                        WorkflowId = workflowId
                    };

                    connector.Execute(request);
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }



            public static void AssignRecord(IOrganizationService connector, Guid ownerId, string ownerType, string targetEntityName, Guid targetId)
            {
                try
                {
                    AssignRequest assignRequest = new AssignRequest();

                    assignRequest.Assignee = new EntityReference(ownerType, ownerId);
                    assignRequest.Target = new EntityReference(targetEntityName, targetId);

                    // Execute the Request

                    connector.Execute(assignRequest);
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static void DeleteRecord(IOrganizationService connector, string targetEntityName, Guid targetId)
            {
                try
                {

                    // Execute the Request
                    connector.Delete(targetEntityName, targetId);

                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }

            public static RetrieveEntityResponse RetrieveMetadataEntityFields(IOrganizationService connector, string entityName)
            {
                try
                {
                    RetrieveEntityRequest request = new RetrieveEntityRequest
                    {
                        LogicalName = entityName,
                        EntityFilters = Microsoft.Xrm.Sdk.Metadata.EntityFilters.All
                    };

                    return (RetrieveEntityResponse)connector.Execute(request);

                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }



            public static void CreateNote(IOrganizationService connector, string entityId, string entityName, string noteSubject, string noteText)
            {
                try
                {
                    Entity note = new Entity();
                    note.Attributes.Add(AnnotationEntityAttributeNames.SubjectFieldName, noteSubject);

                    EntityReference regarding = new EntityReference();
                    regarding.LogicalName = SystemUserEntityAttributeNames.EntityLogicalName;
                    regarding.Id = new Guid(entityId);

                    note.Attributes.Add(AnnotationEntityAttributeNames.ObjectIdFieldName, regarding);

                    Boolean isDocument = new Boolean();
                    isDocument = false;
                    note.Attributes.Add(AnnotationEntityAttributeNames.IsDocumentFieldName, isDocument);

                    note.Attributes.Add(AnnotationEntityAttributeNames.NoteTextFieldName, noteText);

                    note.Attributes.Add(AnnotationEntityAttributeNames.ObjectIdFieldName, entityName);

                    connector.Create(note);

                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex);
                    throw;
                }
            }




            public static Entity GetTeamByTeamName(IOrganizationService adminConnector, string teamName, string currentCrmUserId)
            {
                try
                {
                    ConditionExpression idCondition = CreateConditionExpression(TeamEntityAttributeNames.NameFieldName, ConditionOperator.Equal, new string[] { teamName });

                    RetrieveMultipleResponse response = RetrieveMultipleEntity(adminConnector, TeamEntityAttributeNames.EntityLogicalName, null, new ConditionExpression[] { idCondition }, LogicalOperator.And);
                    if (response == null || response.EntityCollection == null || response.EntityCollection.Entities == null)
                    {
                        return null;
                    }

                    var entityResponse = response.EntityCollection.Entities[0];
                    return entityResponse;
                }
                catch (Exception ex)
                {
                    //ExceptionLibrary.ExceptionMethods.ProcessException(ex, currentCrmUserId);
                    throw;
                }

            }


            public static Entity GetTeamIdByUserId(IOrganizationService connector, string userID, string teamId, string currentUser)
            {
                try
                {
                    ConditionExpression userIdCondition = CreateConditionExpression(TeamMembershipEntityAttributeNames.SystemUserId, ConditionOperator.Equal, new string[] { userID });
                    ConditionExpression teamIdCondition = CreateConditionExpression(TeamMembershipEntityAttributeNames.TeamId, ConditionOperator.Equal, new string[] { teamId });

                    RetrieveMultipleResponse response = RetrieveMultipleEntity(connector, TeamEntityAttributeNames.EntityLogicalName, new string[] { "teamid" }, new ConditionExpression[] { userIdCondition, teamIdCondition }, LogicalOperator.And);
                    if (response == null || response.EntityCollection == null || response.EntityCollection.Entities == null || response.EntityCollection.Entities.Count <= 0)
                    {
                        return null;
                    }

                    var entityResponse = response.EntityCollection.Entities[0];
                    return entityResponse;
                }
                catch (Exception ex)
                {
                   // ExceptionLibrary.ExceptionMethods.ProcessException(ex, currentUser);
                    throw;
                }
            }


            public static string GetAttributeDisplayName(string entitySchemaName, string attributeSchemaName, IOrganizationService service)
            {
                RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
                {
                    EntityLogicalName = entitySchemaName,
                    LogicalName = attributeSchemaName,
                    RetrieveAsIfPublished = true
                };
                RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
                AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
                return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
            }



        }
    }
