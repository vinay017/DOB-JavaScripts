﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class ObjectionHandler : PluginHandlerBase
    {
        public static void ApprovedObjections(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {
                #region Get all objections related to Job Filing
                ConditionExpression associatedObjCondition = CreateConditionExpression(ObjectionsEntityAttributeNames.JobFilingObjectionsId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection associatedObjResponse = RetrieveMultiple(service, ObjectionsEntityAttributeNames.EntityLogicalName, new string[] { ObjectionsEntityAttributeNames.ApprovedObjection }, new ConditionExpression[] { associatedObjCondition }, LogicalOperator.And);
                crmTrace.AppendLine("associatedObjResponse count:  " + associatedObjResponse.Entities.Count);
                if (associatedObjResponse != null && associatedObjResponse.Entities != null && associatedObjResponse.Entities.Count > 0)
                {

                    for (int j = 0; j < associatedObjResponse.Entities.Count; j++) 
                    {
                        Entity Obj = new Entity();
                        Obj.LogicalName = ObjectionsEntityAttributeNames.EntityLogicalName;
                        crmTrace.AppendLine("associatedObjResponse.Entities[i].Id:" + associatedObjResponse.Entities[j].Id);
                        Obj.Attributes.Add(ObjectionsEntityAttributeNames.EntityIdAttributeName, associatedObjResponse.Entities[j].Id);
                        Obj.Attributes.Add(ObjectionsEntityAttributeNames.ApprovedObjection, true);
                        crmTrace.AppendLine("WorkTypeStatus:" + Obj.Attributes[ObjectionsEntityAttributeNames.ApprovedObjection].ToString());

                        service.Update(Obj);
                    }


                }


                #endregion



            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
             }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "ObjectionHandler - ApprovedObjections", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }



    } // class ends here
}// namespace ends here
