﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Discovery;
using Microsoft.Xrm.Sdk.Client;
using System.IO;



namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class JobFilingLOCHandler : PluginHandlerBase
    {
      
        public static void JobLOCHandler(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int currentFilingStatus)
        {
            
            try
            {
                string[] Column_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName};
                Entity response = Retrieve(service, Column_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);

                string JobNumber = response.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                crmTrace.AppendLine("JobNumber: " + JobNumber);
                bool areAllSignedOff = true;
                EntityCollection jobList = new EntityCollection();
                if (currentFilingStatus == (int)CurrentFilingStatus.SignedOff)
                {
                    crmTrace.AppendLine("Reterieving all the related filings for the job");
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.HouseNumber, JobFilingEntityAttributeName.Street, JobFilingEntityAttributeName.JobDescription };

                    ConditionExpression jobCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { JobNumber });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobCondition }, LogicalOperator.And);
                    crmTrace.AppendLine("Total Filings in Job: " + jobfilingResponse.Entities.Count);

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            Entity entity = (Entity)jobfilingResponse.Entities[i];
                            int status = entity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                            crmTrace.AppendLine("status: " + status);
                            if (status != (int)CurrentFilingStatus.SignedOff)
                                areAllSignedOff = false;

                        }
                        crmTrace.AppendLine("areAllSignedOff:" + areAllSignedOff.ToString());
                        if (areAllSignedOff == true)
                        {
                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobStatus, new OptionSetValue((int)JobStatus.PendingQAAssignmentforLOC));
                            crmTrace.AppendLine("All the related filings for the job areAllSignedOff");
                            for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                            {
                                Entity entity = (Entity)jobfilingResponse.Entities[i];
                                Guid jobFilingGuid = entity.GetAttributeValue<Guid>(JobFilingEntityAttributeName.JobFilingId);
                                crmTrace.AppendLine("jobFilingGuid: " + jobFilingGuid.ToString());
                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobStatus, new OptionSetValue((int)JobStatus.PendingQAAssignmentforLOC));
                                //jobList.Entities.Add(jobFiling);
                                service.Update(jobFiling);
                            }
                            crmTrace.AppendLine("Updating all the filings in the Job");
                            //UpdateListCollection(service, jobList, crmTrace);
                            crmTrace.AppendLine("Updated all the filings in the Job");

                        }

                    }

                    //throw new Exception("LOC Test");  
                }


            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - JobLOCHandler", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }// catch ends here


        } // JobLOCHandler
        public static void ParentJobtoFilingsLOCStatus(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int jobStatus)
        {
            string JobNumber = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
            crmTrace.AppendLine("JobNumber: " + JobNumber);
            
            try
            {
                    crmTrace.AppendLine("Reterieving all the related filings for the job");
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.JobStatus, JobFilingEntityAttributeName.HouseNumber, JobFilingEntityAttributeName.Street, JobFilingEntityAttributeName.JobDescription };

                    ConditionExpression jobCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { JobNumber });
                    ConditionExpression jobCondition2 = CreateConditionExpression(JobFilingEntityAttributeName.ParentJobFilingAttributeName, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobCondition, jobCondition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("Total Filings in Job: " + jobfilingResponse.Entities.Count);

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        
                            //CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobStatus, new OptionSetValue((int)JobStatus.PendingQAAssignmentforLOC));
                            crmTrace.AppendLine("All the related filings for the job areAllSignedOff");
                            for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                            {
                                Entity entity = (Entity)jobfilingResponse.Entities[i];
                                Guid jobFilingGuid = entity.GetAttributeValue<Guid>(JobFilingEntityAttributeName.JobFilingId);
                                crmTrace.AppendLine("jobFilingGuid: " + jobFilingGuid.ToString());
                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobStatus, new OptionSetValue(jobStatus));
                                //jobList.Entities.Add(jobFiling);
                                service.Update(jobFiling);
                            }
                          
                        
                    }

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - ParentJobtoFilingsLOCStatus", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }// catch ends here


        } // ParentJobtoFilingsLOCStatus
        public static void SendEmail(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            try
            {

                string[] Column_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.HouseNumber, JobFilingEntityAttributeName.Street,JobFilingEntityAttributeName.OwnerLeaseHolder,JobFilingEntityAttributeName.ProfessionalCertificate,
                    JobFilingEntityAttributeName.BoroughAttributeName, JobFilingEntityAttributeName.Block,JobFilingEntityAttributeName.Lot, JobFilingEntityAttributeName.BIN, JobFilingEntityAttributeName.SignoffDate, JobFilingEntityAttributeName.ApplicantPerson, JobFilingEntityAttributeName.FilingRepresentativeAttributeName};
                Entity response = Retrieve(service, Column_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);
                string[] ColumnNames_CustomConfig = new string[] { CustomConfigurationEntityAttributeName.Key };
                ConditionExpression CustomConfigCondition_Email = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "EMAIL USER" });
                EntityCollection CustomConfigResponse_Email = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition_Email }, LogicalOperator.And);
                string EmailUser = CustomConfigResponse_Email.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);

                //Get CRM Buildings NYC DEV user Guid
                string[] ColumnNames_User = new string[] { SystemUserEntityAttributeNames.SystemUserIdFieldName };
                ConditionExpression userCondition = CreateConditionExpression(SystemUserEntityAttributeNames.FullNameFieldName, ConditionOperator.Equal, new string[] { EmailUser });
                EntityCollection userResponse = RetrieveMultiple(service, SystemUserEntityAttributeNames.EntityLogicalName, ColumnNames_User, new ConditionExpression[] { userCondition }, LogicalOperator.And);
                Guid EmailUserGuid = userResponse.Entities[0].Id;
                crmTrace.AppendLine("EmailUserGuid: " + EmailUserGuid.ToString());

                String HouseNumber = response.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber);
                crmTrace.AppendLine("HouseNumber: " + HouseNumber);
                String StreetNumber = response.GetAttributeValue<string>(JobFilingEntityAttributeName.Street);
                crmTrace.AppendLine("StreetNumber: " + StreetNumber);
                String JobNumber = response.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                crmTrace.AppendLine("JobNumber: " + JobNumber);
                int Borough_Int = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BoroughAttributeName).Value;
                crmTrace.AppendLine("Borough_Int: " + Borough_Int.ToString());
                String BoroughName = response.FormattedValues[JobFilingEntityAttributeName.BoroughAttributeName]; // Get Optionset name
                crmTrace.AppendLine("Borough: " + BoroughName);
                String Block = response.GetAttributeValue<int>(JobFilingEntityAttributeName.Block).ToString();
                crmTrace.AppendLine("Block: " + Block);
                String Lot = response.GetAttributeValue<int>(JobFilingEntityAttributeName.Lot).ToString();
                crmTrace.AppendLine("Lot: " + Lot);
                String BIN = response.GetAttributeValue<int>(JobFilingEntityAttributeName.BIN).ToString();
                crmTrace.AppendLine("BIN: " + BIN);
                String SignoffDate = response.GetAttributeValue<DateTime>(JobFilingEntityAttributeName.SignoffDate).ToShortDateString();
                crmTrace.AppendLine("SignoffDate: " + SignoffDate);
               EntityReference entityRef = (EntityReference)response.Attributes[JobFilingEntityAttributeName.ApplicantPerson];
                String Applicant = entityRef.Name;
                String ApplicantAddress = string.Empty;
                String ApplicantCity= string.Empty;
                String ApplicantState = string.Empty;
                String ApplicantZip = string.Empty;
                #region Get Applicant Details
                string[] ColumnNames_Contact = new string[] { ContactEntityAttributeName.BusinessAddressContractor, ContactEntityAttributeName.CityContractor, ContactEntityAttributeName.StateContractor, ContactEntityAttributeName.ZipContractor };
                Entity Contactresponse = Retrieve(service, ColumnNames_Contact, entityRef.Id, ContactEntityAttributeName.EntityLogicalName); 
                if(Contactresponse != null)
                {
                    ApplicantAddress = Contactresponse.GetAttributeValue<string>(ContactEntityAttributeName.BusinessAddressContractor);
                    crmTrace.AppendLine("ApplicantAddress: " + ApplicantAddress);
                    ApplicantCity = Contactresponse.GetAttributeValue<string>(ContactEntityAttributeName.CityContractor);
                    crmTrace.AppendLine("ApplicantCity: " + ApplicantCity);
                    ApplicantState = Contactresponse.GetAttributeValue<string>(ContactEntityAttributeName.StateContractor);
                    crmTrace.AppendLine("ApplicantState: " + ApplicantState);
                    ApplicantZip = Contactresponse.GetAttributeValue<string>(ContactEntityAttributeName.ZipContractor);
                    crmTrace.AppendLine("ApplicantZip: " + ApplicantZip);
                   
                }
                #endregion
                crmTrace.AppendLine("Applicant: " + Applicant);
                bool Professional = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                crmTrace.AppendLine("Professional: " + Professional.ToString());
                DateTime date = DateTime.Now;
                String currentdate = date.ToShortDateString();
                crmTrace.AppendLine("currentdate: " + currentdate);
                Guid From = EmailUserGuid; // CRM Buildings NYC DEV User
                crmTrace.AppendLine("From guid: " + From.ToString());

                Guid TO = ((EntityReference)response[JobFilingEntityAttributeName.ApplicantPerson]).Id;
                crmTrace.AppendLine("TO Applicant guid: " + TO.ToString());
                Guid OwnerId = response.Contains(JobFilingEntityAttributeName.OwnerLeaseHolder) && (response.Attributes[JobFilingEntityAttributeName.OwnerLeaseHolder] != null) ? ((EntityReference)response[JobFilingEntityAttributeName.OwnerLeaseHolder]).Id : Guid.Empty;
                crmTrace.AppendLine("OwnerId: " + OwnerId.ToString());
                Guid FRId = response.Contains(JobFilingEntityAttributeName.FilingRepresentativeAttributeName) && (response.Attributes[JobFilingEntityAttributeName.FilingRepresentativeAttributeName] != null)  ? ((EntityReference)response[JobFilingEntityAttributeName.FilingRepresentativeAttributeName]).Id : Guid.Empty;
                crmTrace.AppendLine("FRId: " + FRId.ToString());
                // Reterive LOC Header src

                ConditionExpression CustomConfigCondition = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { "LOC Header" });
                EntityCollection CustomConfigResponse = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition }, LogicalOperator.And);
                string LOCHeaderScr = CustomConfigResponse.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);
                string BoroughCommissionerSignature = string.Empty;
                String Subject = "Letter of Completion for Job # " + JobNumber;
                //test read Html
                string Html = ReadHtml(Professional, Borough_Int);

                if (Borough_Int == (int)Borough.B)
                    BoroughCommissionerSignature = "Brooklyn Borough Commissioner Signature";
                if (Borough_Int == (int)Borough.M)
                    BoroughCommissionerSignature = "Manhattan Borough Commissioner Signature";
                if (Borough_Int == (int)Borough.Q)
                    BoroughCommissionerSignature = "Queens Borough Commissioner Signature";
                if (Borough_Int == (int)Borough.X)
                    BoroughCommissionerSignature = "Bronx Borough Commissioner Signature";
                if (Borough_Int == (int)Borough.S)
                    BoroughCommissionerSignature = "Staten Island Borough Commissioner Signature";

                ConditionExpression CustomConfigCondition2 = CreateConditionExpression(CustomConfigurationEntityAttributeName.Name, ConditionOperator.Equal, new string[] { BoroughCommissionerSignature });
                EntityCollection CustomConfigResponse2 = RetrieveMultiple(service, CustomConfigurationEntityAttributeName.EntityLogicalName, ColumnNames_CustomConfig, new ConditionExpression[] { CustomConfigCondition2 }, LogicalOperator.And);
                string SignatureScr = CustomConfigResponse2.Entities[0].GetAttributeValue<string>(CustomConfigurationEntityAttributeName.Key);


                string description = Html.Replace(HTMLAttributes.PRM_HouseNumber, HouseNumber).Replace(HTMLAttributes.PRM_Modified_On, currentdate).Replace(HTMLAttributes.PRM_StreetName, StreetNumber).Replace(HTMLAttributes.PRM_JobNumber, JobNumber).Replace(HTMLAttributes.PRM_BoroughNYC, BoroughName).Replace(HTMLAttributes.PRM_Block, Block).Replace(HTMLAttributes.PRM_Lot, Lot).Replace(HTMLAttributes.PRM_Bin, BIN).Replace(HTMLAttributes.PRM_Applicant, Applicant).Replace(HTMLAttributes.PRM_ApplicantAddress, ApplicantAddress).Replace(HTMLAttributes.PRM_ApplicantCity, ApplicantCity).Replace(HTMLAttributes.PRM_ApplicantState, ApplicantState).Replace(HTMLAttributes.PRM_ApplicantZip, ApplicantZip).Replace(HTMLAttributes.PRM_Signoff_Date, SignoffDate).Replace(HTMLAttributes.PRM_SignatureSrc, SignatureScr).Replace(HTMLAttributes.PRM_LOCHeaderSrc, LOCHeaderScr);
                crmTrace.AppendLine("description Message:  " + description);

                crmTrace.AppendLine("Email Started!");
                // Create 'From' activity party for the email

                Entity toParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                toParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, TO);
                Entity[] ToOwner = { toParty };

                Entity fromParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                fromParty[ActivityParty.ActivityPartId] = new EntityReference(SystemuserEntityAttributeNames.EntityName, From);
                Entity[] FromAdmin = { fromParty };

                EntityCollection ToCC = new EntityCollection();

                if(OwnerId != Guid.Empty)
                {
                    Entity ccOwnerParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                    ccOwnerParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, OwnerId);
                    ToCC.Entities.Add(ccOwnerParty);
                }

                if (FRId != Guid.Empty)
                {
                    Entity ccFRParty = new Entity(ActivityParty.ActivityPartyEntityLogicalName);
                    ccFRParty[ActivityParty.ActivityPartId] = new EntityReference(ContactEntityAttributeName.EntityLogicalName, FRId);
                    ToCC.Entities.Add(ccFRParty);
                }
                


                // Create an e-mail message
                Entity email = new Entity();
                email.LogicalName = EmailEntityAttributeName.EntityLogicalName;
                email.Attributes.Add(EmailEntityAttributeName.From, FromAdmin);
                email.Attributes.Add(EmailEntityAttributeName.To, ToOwner);
                if(ToCC != null && ToCC.Entities.Count > 0)
                email.Attributes.Add(EmailEntityAttributeName.Cc, ToCC);
                email.Attributes.Add(EmailEntityAttributeName.Subject, Subject);
                email.Attributes.Add(EmailEntityAttributeName.Description, description);
                email.Attributes[EmailEntityAttributeName.Regarding] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, response.Id);

                Guid _emailId = service.Create(email);

           SendEmailRequest sendEmailreq = new SendEmailRequest

           {

               EmailId = _emailId,

               TrackingToken = "",

               IssueSend = true

           };

           SendEmailResponse sendEmailresp = (SendEmailResponse)service.Execute(sendEmailreq);

           if (sendEmailresp != null)

           {

               //Console.WriteLine("Email record created successfully");

               //Console.ReadKey();

           }

           //throw new Exception("Testing LOC Email");

       }
             catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - SendEmail", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        
        public static string ReadHtml(bool Professional, int BoroughNYC)
            {
            string path = string.Empty;
            string strHTML = "Test";
                if (Professional == true)
                {
                    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_All.html";
                    // Old Logic
                    //if(BoroughNYC == (int)Borough.B)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_Brooklyn.html";  // crm server
                    //if(BoroughNYC == (int)Borough.M)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_Mahattan.html";  // crm server
                    //if(BoroughNYC == (int)Borough.Q)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_Queens.html";  // crm server
                    //if(BoroughNYC == (int)Borough.X)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_Bronx.html";  // crm server
                    //if(BoroughNYC == (int)Borough.S)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_PC_StatenIsland.html";  // crm server
                }

                if (Professional == false)
                {
                    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_All.html";
                    // Old Logic
                    //if (BoroughNYC == (int)Borough.B)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_Brooklyn.html";  // crm server
                    //if (BoroughNYC == (int)Borough.M)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_Mahattan.html";  // crm server
                    //if (BoroughNYC == (int)Borough.Q)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_Queens.html";  // crm server
                    //if (BoroughNYC == (int)Borough.X)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_Bronx.html";  // crm server
                    //if (BoroughNYC == (int)Borough.S)
                    //    path = @"D:\CRM2015Server\HTMLTemplate\LOC_SP_StatenIsland.html";  // crm server
                }
                
                if (File.Exists(path))
                {
                     strHTML = File.ReadAllText(path);

                }
                return strHTML;


            }

   

        
        public static void UpdateListCollection(IOrganizationService service, EntityCollection jobList, StringBuilder crmTrace)
        {
            Guid trackingGuid = Guid.NewGuid();
            try
            {
                // Will Update an ExecuteMultipleRequest object (requestWithResults).
                crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };
                crmTrace.AppendLine(" Request object created");
                // Creates requests for each jobList record

                crmTrace.AppendLine(" Creating CreateRequest requests for each jobList record and adding them to Request Object");
                foreach (var entity in jobList.Entities)
                {
                    UpdateRequest updateRequest = new UpdateRequest { Target = entity };
                    requestWithResults.Requests.Add(updateRequest);
                }
                crmTrace.AppendLine(" CreateRequest Created requests for each jobList record and added to Request Object");

                // Execute
                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

                foreach (var responseItem in responseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Response);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }  // UpdateListCollection Method ends here

        public static Entity GenerateLOCNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            string JobFilingNumber = string.Empty;
            string LOCformatString = "{0}{1}";
            string LOCFormatted = string.Empty;

            try
            {

                if (targetEntity.Contains(LOCPW7EntityAttributeName.GotoJobFiling))
                {
                    crmTrace.AppendLine("target contains");
                    EntityReference JobFiling = targetEntity.GetAttributeValue<EntityReference>(LOCPW7EntityAttributeName.GotoJobFiling);
                    Entity jF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, JobFiling.Id, new ColumnSet (JobFilingEntityAttributeName.JobFilingNumAttribute));
                    JobFilingNumber = jF.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute);
                }

                crmTrace.AppendLine("JobFilingNumber: " + JobFilingNumber);

                LOCFormatted = String.Format(LOCformatString, JobFilingNumber, "-LOC");
                crmTrace.AppendLine("LOCFormatted: " + LOCFormatted);
    
                if (!targetEntity.Attributes.Contains(LOCPW7EntityAttributeName.Name))
                {
                    CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.Name, LOCFormatted);

                }
                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - GenerateLOCNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static void UpdateJobFilingStatus_LOC(IOrganizationService service, Entity preImage, string Job_FilingStatusAttibute, int Job_FilingStatus, StringBuilder crmTrace)
        {
            // Method to update Job Status or filing status of Job Filing Record
           try
            {

               
                crmTrace.AppendLine("target contains GotoJobFiling");
                Guid JobFilingId = preImage.GetAttributeValue<EntityReference>(LOCPW7EntityAttributeName.GotoJobFiling).Id;
                crmTrace.AppendLine("JobFilingId: " + JobFilingId.ToString());
               
                Entity jF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute));
                    
                    if (jF != null)
                    {
                        crmTrace.AppendLine("Updating " + Job_FilingStatusAttibute + " : " + Job_FilingStatus);
                        jF.Attributes[Job_FilingStatusAttibute] = new OptionSetValue(Job_FilingStatus);
                        service.Update(jF);
                        crmTrace.AppendLine("Completed Updating JobFiling Job Status : " + Job_FilingStatus);
                    }
                     
                

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdateJobStatus_LOC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void UpdatePermits_LOCIssued(IOrganizationService service, Entity preImage,  StringBuilder crmTrace)
        {
            // Method to update Job Status or filing status of Job Filing Record
            try
            {

                crmTrace.AppendLine("target contains GotoJobFiling");
                    Guid JobFilingId = preImage.GetAttributeValue<EntityReference>(LOCPW7EntityAttributeName.GotoJobFiling).Id;
                    crmTrace.AppendLine("JobFilingId: " + JobFilingId.ToString());
                
                    Entity jF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId, new ColumnSet(JobFilingEntityAttributeName.JobFilingNumAttribute, JobFilingEntityAttributeName.Directive14));
                if (jF != null)
                    {
                        bool directive14 = jF.GetAttributeValue<bool>(JobFilingEntityAttributeName.Directive14);
                        crmTrace.AppendLine("directive14 : " + directive14);
                    
                    if (directive14)
                        {
                            string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.NoWorkCheckBox };
                            ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jF.Id.ToString() });
                            ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, new string[] { ((int)WorkpermitStatus.PermitIssued).ToString() });
                            EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition, workPermitCondition2 }, LogicalOperator.And);
                            crmTrace.AppendLine("workPermitResponse : " + workPermitResponse.Entities.Count);
                        
                        if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                            {
                                foreach(Entity wp in workPermitResponse.Entities)
                                {
                                    wp.Attributes[WorkPermitEntityAttributeName.WorkPermitStatus] = new OptionSetValue((int)WorkpermitStatus.PermitSignedoff);
                                    service.Update(wp);
                                }

                            }

                        }

                    }

                

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(preImage.Id.ToString(), SourceChannel.CRM, "JobFilingLOCHandler - UpdatePermits_LOCIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    } //class ends
} // namespace ends
