﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;
using DOBNYC.XRM.JobFiling.PluginLibrary;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class WaiverDeferralHandler : PluginHandlerBase
    {
        private static IOrganizationService localService;
        private static StringBuilder localCrmTrace;
        private static EntityReference wpRef = null;
        private static EntityReference ahvRef = null;
        private static Entity jobFiling;
        private static bool isProfCert;
        private static bool isPW2;

        public static void CreateTasks(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, bool isAssignedToPEMessage, EntityReference refLinkedEntity)
        {
            try
            {
                localService = service;
                localCrmTrace = crmTrace;
                jobFiling = targetEntity;

                wpRef = null;
                ahvRef = null;

                isProfCert = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                isPW2 = (bool)targetEntity[JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName];

                localCrmTrace.AppendLine("Is Prof. Cert? - " + isProfCert.ToString());
                localCrmTrace.AppendLine("Is PW2? - " + isPW2.ToString());

                #region Fetch all documents associated with the job filing with waiver or deferral requested = yes & submitted

                ConditionExpression jobFilingLinkCondition = new ConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, targetEntity.Id);

                ConditionExpression waiverCondition = new ConditionExpression(DocumentListEntityAttributeName.WaiverRequested, ConditionOperator.Equal, true);
                ConditionExpression deferralCondition = new ConditionExpression(DocumentListEntityAttributeName.DeferralRequested, ConditionOperator.Equal, true);
                ConditionExpression statusCondition = new ConditionExpression(DocumentListEntityAttributeName.DocumentStatus, ConditionOperator.In, new int[] { 23, 24, 25 });

                FilterExpression waiverOrDeferralFilter = new FilterExpression(LogicalOperator.Or) { Conditions = { waiverCondition, deferralCondition } };

                QueryExpression query = new QueryExpression(DocumentListEntityAttributeName.EntityLogicalName);
                query.ColumnSet = new ColumnSet(
                    DocumentListEntityAttributeName.DocumentName,
                    DocumentListEntityAttributeName.WaiverRequested,
                    DocumentListEntityAttributeName.DeferralRequested,
                    DocumentListEntityAttributeName.DocumentStatus,
                    DocumentListEntityAttributeName.PriortoStatus,
                    DocumentListEntityAttributeName.PriortoStage,
                    DocumentListEntityAttributeName.WaiverRejectCounter,
                    DocumentListEntityAttributeName.DeferralRejectCounter,
                    DocumentListEntityAttributeName.Comments,
                    DocumentListEntityAttributeName.AnyWaiverRequest,
                    DocumentListEntityAttributeName.AnyDeferralRequest,
                    DocumentListEntityAttributeName.GotoWorkPermit,
                    DocumentListEntityAttributeName.GotoAHV,
                    DocumentListEntityAttributeName.DocumentClass
                    );
                if (refLinkedEntity == null || refLinkedEntity.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                {
                    query.Criteria.AddCondition(jobFilingLinkCondition);
                }
                else
                {
                    if (refLinkedEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                    {
                        ConditionExpression refLinkedEntityCondition = new ConditionExpression(DocumentListEntityAttributeName.GotoWorkPermit, ConditionOperator.Equal, refLinkedEntity.Id);
                        FilterExpression documentLinkFilter = new FilterExpression(LogicalOperator.Or) { Conditions = { jobFilingLinkCondition, refLinkedEntityCondition } };
                        query.Criteria.AddFilter(documentLinkFilter);
                        wpRef = refLinkedEntity;
                    }
                    else if (refLinkedEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                    {
                        ConditionExpression AHVCondition = new ConditionExpression(DocumentListEntityAttributeName.GotoAHV, ConditionOperator.Equal, refLinkedEntity.Id);
                        query.Criteria.AddCondition(AHVCondition);
                        ahvRef = refLinkedEntity;
                    }
                    isPW2 = true;
                }
                query.Criteria.AddCondition(statusCondition);
                query.Criteria.AddFilter(waiverOrDeferralFilter);
                query.Criteria.FilterOperator = LogicalOperator.And;
                query.NoLock = true;

                EntityCollection documentListResponse = service.RetrieveMultiple(query);
                localCrmTrace.AppendLine("count of documents for which waiver/deferral is requested - " + documentListResponse.Entities.Count);
                #endregion

                #region Process documents and create tasks

                #region locals
                Entity waiverTask1 = null;
                Entity waiverTask2 = null;
                Entity waiverTask3 = null;
                Entity waiverTask4 = null;
                Entity deferralTask1 = null;
                Entity deferralTask2 = null;
                Entity deferralTask3 = null;

                EntityReference waiverTask1Assignee = null;
                EntityReference waiverTask2Assignee = null;
                EntityReference waiverTask3Assignee = null;
                EntityReference waiverTask4Assignee = null;
                EntityReference deferralTask1Assignee = null;
                EntityReference deferralTask2Assignee = null;
                EntityReference deferralTask3Assignee = null;

                bool isFilingAssignedToPE = false;
                if (jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlanExaminerAttributeName) != null)
                {
                    isFilingAssignedToPE = true;
                }
                #endregion

                foreach (Entity document in documentListResponse.Entities)
                {
                    #region process waiver
                    if (document.GetAttributeValue<bool>(DocumentListEntityAttributeName.WaiverRequested))
                    {
                        localCrmTrace.AppendLine("waiver");
                        // Waiver 1st time
                        if ((!document.GetAttributeValue<int?>(DocumentListEntityAttributeName.WaiverRejectCounter).HasValue || document.GetAttributeValue<int?>(DocumentListEntityAttributeName.WaiverRejectCounter).Value == 0))
                        {
                            if (!isProfCert)//standard
                            {

                                if (isAssignedToPEMessage || isFilingAssignedToPE)
                                {
                                    if (waiverTask1Assignee == null)
                                    {
                                        waiverTask1Assignee = jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlanExaminerAttributeName);
                                    }
                                    CreateWaiverDeferralRequest(ref waiverTask1, document, (int)WaiverDeferralType.Waiver, 8, waiverTask1Assignee, "Plan Examiner");
                                    localCrmTrace.AppendLine("w 1 standard");
                                }
                                else
                                {
                                    document[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue((int)DocumentStatus.WaiverPendingPEAssignment);
                                    document[DocumentListEntityAttributeName.AnyWaiverRequest] = true;
                                    localService.Update(document);
                                    localCrmTrace.AppendLine("pending assignment");
                                    continue;
                                }
                            }
                            else//professional cert
                            {
                                if (waiverTask1Assignee == null)
                                {
                                    //waiverTask1Assignee = targetEntity.Contains(JobFilingEntityAttributeName.ParentTeam)? FetchChildTeamRef(targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam).Id.ToString()): FetchTeamRef(TeamNames.TeamProfCertQAAdmin);

                                    if (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == 2)
                                        waiverTask1Assignee = FetchTeamRef(TeamNames.ProfCertPAA_QAAdminTeam);
                                    else
                                    {
                                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName))
                                        {
                                            if (refLinkedEntity != null)
                                            {
                                                if (refLinkedEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                                                {
                                                    waiverTask1Assignee = FetchTeamRef(TeamNames.QATeam_AHV);
                                                    localCrmTrace.AppendLine("w 1 QATeam_AHV");
                                                }
                                                else if (refLinkedEntity.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                                                {
                                                    if (document.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentClass).Value == 1)
                                                    {                                                        
                                                        waiverTask1Assignee = FetchTeamRef(TeamNames.QATeam_LOCTechnicalReview);
                                                        localCrmTrace.AppendLine("w 1 QATeam_LOCTechnicalReview");
                                                    }
                                                    else
                                                    {
                                                        waiverTask1Assignee = FetchTeamRef(TeamNames.QATeam_LOC);
                                                        localCrmTrace.AppendLine("w 1 QATeam_LOC");
                                                    }
                                                }
                                                else
                                                {
                                                    waiverTask1Assignee = FetchTeamRef(TeamNames.ProfCertWithPW2_QAAdminTeam);
                                                    localCrmTrace.AppendLine("w 1 ProfCertWithPW2_QAAdminTeam - 1");
                                                }
                                            }
                                            else
                                            {
                                                waiverTask1Assignee = FetchTeamRef(TeamNames.ProfCertWithPW2_QAAdminTeam);
                                                localCrmTrace.AppendLine("w 1 ProfCertWithPW2_QAAdminTeam - 2");
                                            }

                                        }
                                        else
                                        {
                                            waiverTask1Assignee = FetchTeamRef(TeamNames.ProfCertWithoutPW2_QAAdminTeam);
                                            localCrmTrace.AppendLine("w 1 ProfCertWithoutPW2_QAAdminTeam");
                                        }
                                    }

                                }
                                CreateWaiverDeferralRequest(ref waiverTask1, document, (int)WaiverDeferralType.Waiver, 12, waiverTask1Assignee, "Prof Cert QA Administrator"); //Profcert QA Admin
                                localCrmTrace.AppendLine("w 1 pc");
                            }
                        }
                        // Waiver 2nd time
                        else if (document.GetAttributeValue<int>(DocumentListEntityAttributeName.WaiverRejectCounter) == 1 && !isAssignedToPEMessage)
                        {
                            if (!isProfCert)//standard
                            {
                                if (waiverTask2Assignee == null)
                                {
                                    waiverTask2Assignee = targetEntity.Contains(JobFilingEntityAttributeName.ParentTeam) ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam) : FetchTeamRef(TeamNames.TeamChiefPlanExaminer);

                                }
                                CreateWaiverDeferralRequest(ref waiverTask2, document, (int)WaiverDeferralType.Waiver, 9, waiverTask2Assignee, "Chief Plan Examiner");
                                localCrmTrace.AppendLine("w 2 standard");
                            }
                            else//professional cert
                            {
                                if (waiverTask2Assignee == null)
                                {
                                    //waiverTask2Assignee = targetEntity.Contains(JobFilingEntityAttributeName.ParentTeam) ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam) : FetchTeamRef(TeamNames.TeamProfCertQASupervisor);
                                                                       
                                    if (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == 2)
                                        waiverTask2Assignee = FetchTeamRef(TeamNames.ProfCertPAA_QASupervisorTeam);
                                    else
                                    {
                                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName))
                                        {
                                            if (refLinkedEntity != null)
                                            {
                                                if (refLinkedEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                                                {
                                                    waiverTask2Assignee = FetchTeamRef(TeamNames.TeamQASupervisor_AHV);
                                                    localCrmTrace.AppendLine("w 2 TeamQASupervisor_AHV");
                                                }
                                                else if (refLinkedEntity.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                                                {
                                                    waiverTask2Assignee = FetchTeamRef(TeamNames.TeamQASupervisor_LOC);
                                                    localCrmTrace.AppendLine("w 2 TeamQASupervisor_LOC");
                                                }
                                                else
                                                {
                                                    waiverTask2Assignee = FetchTeamRef(TeamNames.ProfCertWithPW2_QASupervisorTeam);
                                                    localCrmTrace.AppendLine("w 2 ProfCertWithPW2_QASupervisorTeam - 1");
                                                }
                                            }
                                            else
                                            {
                                                waiverTask2Assignee = FetchTeamRef(TeamNames.ProfCertWithPW2_QASupervisorTeam);
                                                localCrmTrace.AppendLine("w 2 ProfCertWithPW2_QASupervisorTeam - 2");
                                            }
                                        }
                                        else
                                        {
                                            waiverTask2Assignee = FetchTeamRef(TeamNames.ProfCertWithoutPW2_QASupervisorTeam);
                                            localCrmTrace.AppendLine("w 2 ProfCertWithoutPW2_QASupervisorTeam");
                                        }
                                    }
                                }
                                CreateWaiverDeferralRequest(ref waiverTask2, document, (int)WaiverDeferralType.Waiver, 13, waiverTask2Assignee, "Prof Cert QA Supervisor"); //Profcert QA supervisor
                                localCrmTrace.AppendLine("w 2 pc");
                            }
                        }
                        // Waiver 3rd time
                        else if (document.GetAttributeValue<int>(DocumentListEntityAttributeName.WaiverRejectCounter) == 2 && !isAssignedToPEMessage)
                        {
                            if (waiverTask3Assignee == null)
                            {
                                waiverTask3Assignee = FetchTeamRef(TeamNames.TeamBoroughCommissioner);
                            }
                            CreateWaiverDeferralRequest(ref waiverTask3, document, (int)WaiverDeferralType.Waiver, 10, waiverTask3Assignee, "Borough Commissioner");
                            localCrmTrace.AppendLine("w 3 standard");
                        }
                        // Waiver 4th time
                        else if (document.GetAttributeValue<int>(DocumentListEntityAttributeName.WaiverRejectCounter) == 3 && !isAssignedToPEMessage)
                        {
                            if (waiverTask4Assignee == null)
                            {
                                waiverTask4Assignee = FetchTeamRef(TeamNames.TeamOpsAdmin);
                            }
                            CreateWaiverDeferralRequest(ref waiverTask4, document, (int)WaiverDeferralType.Waiver, 11, waiverTask4Assignee, "Operations Admin");
                            localCrmTrace.AppendLine("w 4 standard");
                        }
                    }

                    #endregion
                    #region process deferral
                    else if (document.GetAttributeValue<bool>(DocumentListEntityAttributeName.DeferralRequested) && !isAssignedToPEMessage)
                    {
                        localCrmTrace.AppendLine("deferral");
                        //Deferral 1st time
                        if (document.GetAttributeValue<int?>(DocumentListEntityAttributeName.DeferralRejectCounter) == null || !document.GetAttributeValue<int?>(DocumentListEntityAttributeName.DeferralRejectCounter).HasValue || document.GetAttributeValue<int>(DocumentListEntityAttributeName.DeferralRejectCounter) == 0)
                        {
                            if (!isProfCert && targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value == (int)CurrentFilingStatus.PendingPlanExaminer)//standard
                            {
                                if (deferralTask1Assignee == null)
                                {
                                    //deferralTask1Assignee = FetchTeamRef(TeamNames.TeamChiefPlanExaminer);
                                    deferralTask1Assignee = targetEntity.Contains(JobFilingEntityAttributeName.ParentTeam) ? targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentTeam) : FetchTeamRef(TeamNames.TeamChiefPlanExaminer);
                                }
                                CreateWaiverDeferralRequest(ref deferralTask1, document, (int)WaiverDeferralType.Deferral, 16, deferralTask1Assignee, "Chief Plan Examiner");
                                localCrmTrace.AppendLine("d 1 standard");
                            }
                            else if (isProfCert)//professional cert
                            {
                                if (deferralTask1Assignee == null)
                                {
                                    //deferralTask1Assignee = FetchTeamRef(TeamNames.TeamProfCertQASupervisor);


                                    if (targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == 2)
                                        deferralTask1Assignee = FetchTeamRef(TeamNames.ProfCertPAA_QASupervisorTeam);
                                    else
                                    {
                                        if (targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsWorkPermitAvailableAttributeName))
                                            deferralTask1Assignee = FetchTeamRef(TeamNames.ProfCertWithPW2_QASupervisorTeam);
                                        else
                                            deferralTask1Assignee = FetchTeamRef(TeamNames.ProfCertWithoutPW2_QASupervisorTeam);
                                    }
                                }
                                CreateWaiverDeferralRequest(ref deferralTask1, document, (int)WaiverDeferralType.Deferral, 19, deferralTask1Assignee, "Prof Cert QA Supervisor");
                                localCrmTrace.AppendLine("d 1 pc");
                            }
                        }
                        //Deferral 2nd time
                        else if (document.GetAttributeValue<int>(DocumentListEntityAttributeName.DeferralRejectCounter) == 1)
                        {
                            if (deferralTask2Assignee == null)
                            {
                                deferralTask2Assignee = FetchTeamRef(TeamNames.TeamBoroughCommissioner);
                            }
                            CreateWaiverDeferralRequest(ref deferralTask2, document, (int)WaiverDeferralType.Deferral, 17, deferralTask2Assignee, "Borough Commissioner");
                            localCrmTrace.AppendLine("d 2 standard");
                        }
                        //Deferral 3rd time
                        else if (document.GetAttributeValue<int>(DocumentListEntityAttributeName.DeferralRejectCounter) == 2)
                        {
                            if (deferralTask3Assignee == null)
                            {
                                deferralTask3Assignee = FetchTeamRef(TeamNames.TeamOpsAdmin);
                            }
                            CreateWaiverDeferralRequest(ref deferralTask3, document, (int)WaiverDeferralType.Deferral, 18, deferralTask3Assignee, "Operations Admin");
                            localCrmTrace.AppendLine("d 3 standard");
                        }
                    }
                    #endregion
                }

                #endregion

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", null, localCrmTrace.ToString(), null, null);
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateTasks", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void SubmitTask(IOrganizationService service, EntityReference targetEntityRef, StringBuilder crmTrace)
        {
            try
            {
                localService = service;
                localCrmTrace = crmTrace;
                //Retrieve all associated Waiver Deferral - Task Intersect records
                QueryByAttribute query = new QueryByAttribute(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
                query.AddAttributeValue(WaiverDeferralRequestEntityAttributeName.TaskId, targetEntityRef.Id);
                query.ColumnSet = new ColumnSet(true);
                EntityCollection waiverdeferralRequests = service.RetrieveMultiple(query);
                bool deactivateRequest;
                //Process each waiver/deferral
                foreach (Entity waiverdeferralRequest in waiverdeferralRequests.Entities)
                {
                    deactivateRequest = false;
                    Entity documentList = service.Retrieve(
                        DocumentListEntityAttributeName.EntityLogicalName,
                        waiverdeferralRequest.GetAttributeValue<EntityReference>(WaiverDeferralRequestEntityAttributeName.DocumentListId).Id,
                        new ColumnSet(new string[] { DocumentListEntityAttributeName.WaiverRejectCounter, DocumentListEntityAttributeName.DeferralRejectCounter, DocumentListEntityAttributeName.DocumentStatus }));
                    int type = waiverdeferralRequest.GetAttributeValue<OptionSetValue>(WaiverDeferralRequestEntityAttributeName.Type).Value;
                    int action = waiverdeferralRequest.GetAttributeValue<OptionSetValue>(WaiverDeferralRequestEntityAttributeName.Action).Value;

                    if (type == 1)
                    {
                        documentList[DocumentListEntityAttributeName.WaiverRequested] = false;
                        if (action == 1)// waiver approve
                        {
                            ApproveWaiver(documentList);
                            deactivateRequest = true;
                        }
                        else if (action == 2)// waiver reject
                        {
                            RejectWaiver(documentList);
                            deactivateRequest = true;
                        }
                    }
                    else if (type == 2)
                    {
                        documentList[DocumentListEntityAttributeName.DeferralRequested] = false;
                        if (action == 1)// deferral approve
                        {
                            documentList[DocumentListEntityAttributeName.PriortoStatus] = waiverdeferralRequest.GetAttributeValue<OptionSetValue>(WaiverDeferralRequestEntityAttributeName.DeferToStage);
                            switch (waiverdeferralRequest.GetAttributeValue<OptionSetValue>(WaiverDeferralRequestEntityAttributeName.DeferToStage).Value)
                            {
                                case 10:
                                    documentList[DocumentListEntityAttributeName.PriortoStage] = "Permit Issuance";
                                    break;
                                case 18:
                                    documentList[DocumentListEntityAttributeName.PriortoStage] = "Letter of Completion";
                                    break;
                                default:
                                    documentList[DocumentListEntityAttributeName.PriortoStage] = waiverdeferralRequest.FormattedValues[WaiverDeferralRequestEntityAttributeName.DeferToStage];
                                    break;
                            }
                            ApproveDeferral(documentList);
                            deactivateRequest = true;
                        }
                        else if (action == 2)// deferral reject
                        {
                            RejectDeferral(documentList);
                            deactivateRequest = true;
                        }
                    }
                    if (deactivateRequest)
                    {
                        SetStateDynamic(localService, WaiverDeferralRequestEntityAttributeName.EntityLogicalName, waiverdeferralRequest.Id, 1, 2);
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntityRef.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - SubmitTask", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateOverrideWaiverHistory(Entity document, int action, IOrganizationService service, StringBuilder customTrace)
        {
            try
            {
                localService = service;
                localCrmTrace = customTrace;
                localCrmTrace.AppendLine("Override Trace History Begin");
                Entity tempRequest = new Entity(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Type] = new OptionSetValue((int)WaiverDeferralType.Waiver);
                tempRequest[WaiverDeferralRequestEntityAttributeName.PriorToStatus] = document.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.PriortoStatus);
                tempRequest[WaiverDeferralRequestEntityAttributeName.PriorToStage] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.PriortoStage);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Name] = "CPE Waiver Override Action";
                tempRequest[WaiverDeferralRequestEntityAttributeName.Role] = "Chief Plan Examiner";
                tempRequest[WaiverDeferralRequestEntityAttributeName.DocumentListId] = new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, document.Id);
                tempRequest[WaiverDeferralRequestEntityAttributeName.RequestorComments] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.Comments);
                tempRequest[WaiverDeferralRequestEntityAttributeName.ActionComments] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.OverrideWaiverComments);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Action] = new OptionSetValue(action);
                Guid requestId = localService.Create(tempRequest);
                localCrmTrace.AppendLine(string.Format("New Waiver/Deferral request {0} created", requestId.ToString()));
                //Create association in self relationship for history
                AssociateWithPastRequests(document.Id, requestId);
                localCrmTrace.AppendLine("History Created");
                SetStateDynamic(localService, WaiverDeferralRequestEntityAttributeName.EntityLogicalName, requestId, 1, 2);
                localCrmTrace.AppendLine("deactivated");
                localCrmTrace.AppendLine("Override Trace History End");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateOverrideWaiverHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        private static void CreateWaiverDeferralRequest(ref Entity task, Entity document, int typeWaiverDeferral, int nextDocumentStatus, EntityReference assignee, string roleName)
        {
            try
            {
                localCrmTrace.AppendLine("CreateWaiverDeferralRequest");
                if (task == null)
                {
                    CreateTask(ref task, nextDocumentStatus, assignee, typeWaiverDeferral, roleName);
                }
                Entity tempRequest = new Entity(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
                string name = string.Empty;
                if (typeWaiverDeferral == 1)
                {
                    name = string.Format("Waiver Request for Job# {0} Filing# {1}",
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName),
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName));
                    tempRequest[WaiverDeferralRequestEntityAttributeName.Type] = new OptionSetValue((int)WaiverDeferralType.Waiver);
                }
                else if (typeWaiverDeferral == 2)
                {
                    name = string.Format("Deferral Request for Job# {0} Filing# {1}",
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName),
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName));
                    tempRequest[WaiverDeferralRequestEntityAttributeName.Type] = new OptionSetValue((int)WaiverDeferralType.Deferral);
                }
                tempRequest[WaiverDeferralRequestEntityAttributeName.PriorToStatus] = document.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.PriortoStatus);
                tempRequest[WaiverDeferralRequestEntityAttributeName.PriorToStage] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.PriortoStage);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Name] = name.Length > 100 ? name.Substring(0, 100) : name;
                tempRequest[WaiverDeferralRequestEntityAttributeName.Role] = roleName.Length > 100 ? roleName.Substring(0, 100) : roleName;
                tempRequest[WaiverDeferralRequestEntityAttributeName.DocumentListId] = new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, document.Id);
                tempRequest[WaiverDeferralRequestEntityAttributeName.TaskId] = new EntityReference(TaskEntityAttributeNames.EntityLogicalName, task.Id);
                tempRequest[WaiverDeferralRequestEntityAttributeName.RequestorComments] = document.GetAttributeValue<string>(DocumentListEntityAttributeName.Comments);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Applicant] = jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ApplicantPerson);
                tempRequest[WaiverDeferralRequestEntityAttributeName.FilingOwner] = jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.OwnerLeaseHolder);
                tempRequest[WaiverDeferralRequestEntityAttributeName.Owner] = assignee;
                tempRequest[WaiverDeferralRequestEntityAttributeName.WorkPermit] = isPW2;
                tempRequest[WaiverDeferralRequestEntityAttributeName.ProfCert] = isProfCert;
                Guid requestId = localService.Create(tempRequest);

                localCrmTrace.AppendLine(string.Format("New Waiver/Deferral request {0} created", requestId.ToString()));

                //Create association in self relationship for history
                AssociateWithPastRequests(document.Id, requestId);

                localCrmTrace.AppendLine("History");

                //Update Document List Status
                Entity doc = new Entity(document.LogicalName);
                doc.Id = document.Id;
                doc[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue(nextDocumentStatus);
                if (!document.GetAttributeValue<bool>(DocumentListEntityAttributeName.AnyWaiverRequest) && typeWaiverDeferral == 1)
                {
                    doc[DocumentListEntityAttributeName.AnyWaiverRequest] = true;
                }
                else if (!document.GetAttributeValue<bool>(DocumentListEntityAttributeName.AnyDeferralRequest) && typeWaiverDeferral == 2)
                {
                    doc[DocumentListEntityAttributeName.AnyDeferralRequest] = true;
                }
                UpdateDocumentList(doc);

                localCrmTrace.AppendLine("Document status updated");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(document.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - CreateWaiverDeferralRequest", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        private static void AssociateWithPastRequests(Guid documentId, Guid currentRequestId)
        {
            QueryExpression query = new QueryExpression(WaiverDeferralRequestEntityAttributeName.EntityLogicalName);
            query.ColumnSet = new ColumnSet(new string[] { WaiverDeferralRequestEntityAttributeName.DocumentListId });
            query.Criteria = new FilterExpression(LogicalOperator.And);
            query.Criteria.AddCondition(WaiverDeferralRequestEntityAttributeName.DocumentListId, ConditionOperator.Equal, documentId);
            query.Criteria.AddCondition(WaiverDeferralRequestEntityAttributeName.WaiverDeferralRequestId, ConditionOperator.NotEqual, currentRequestId);
            EntityCollection requests = localService.RetrieveMultiple(query);

            if (requests.Entities.Count == 0) return;

            EntityReferenceCollection pastRequests = new EntityReferenceCollection();

            foreach (Entity request in requests.Entities)
            {
                pastRequests.Add(new EntityReference(WaiverDeferralRequestEntityAttributeName.EntityLogicalName, request.Id));
            }

            AssociateRequest assocReq = new AssociateRequest();
            assocReq.Relationship = new Relationship("dobnyc_dobnyc_waiverdeferraltaskintersect_dobnyc");
            assocReq.Relationship.PrimaryEntityRole = EntityRole.Referencing;
            assocReq.Target = new EntityReference(WaiverDeferralRequestEntityAttributeName.EntityLogicalName, currentRequestId);
            assocReq.RelatedEntities = pastRequests;
            localService.Execute(assocReq);

        }

        private static void CreateTask(ref Entity task, int documentStatus, EntityReference assignee, int type, string roleName)
        {
            //--.Fetch open task code here
            string fetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='task'>
                                    <attribute name='activityid' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='dobnyc_task_clickheretogotojobfiling' operator='eq' value='" + jobFiling.Id + @"' />
                                    </filter>
                                    <link-entity name='dobnyc_waiverdeferraltaskintersect' from='dobnyc_taskid' to='activityid' alias='ao'>
                                      <link-entity name='dobnyc_documentlist' from='dobnyc_documentlistid' to='dobnyc_documentlistid' alias='ap'>
                                        <filter type='and'>
                                          <condition attribute='dobnyc_documentstatus' operator='eq' value='" + documentStatus.ToString() + @"' />
                                        </filter>
                                      </link-entity>
                                    </link-entity>
                                   </entity>
                                  </fetch>";
            localCrmTrace.AppendLine("Job Filing - " + jobFiling.Id.ToString());
            EntityCollection records = localService.RetrieveMultiple(new FetchExpression(fetchXml));
            if (records.Entities.Count == 1)
            {
                task = records.Entities[0];
                localCrmTrace.AppendLine(string.Format("open task {0} found", task.Id.ToString()));
            }
            else
            {
                string taskSubject = string.Format("{0} Document {1} Request Task form for Job# {2} Filing# {3}",
                    roleName,
                    type == 1 ? "Waiver" : "Deferral",
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName),
                    jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName));
                task = new Entity(TaskEntityAttributeNames.EntityLogicalName);
                task[TaskEntityAttributeNames.ClickheretogotoJobFiling] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFiling.Id);
                //task[TaskEntityAttributeNames.RegardingObjectId] = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jobFiling.Id);
                task[TaskEntityAttributeNames.Subject] = taskSubject.Length > 200 ? taskSubject.Substring(0, 200) : taskSubject;
                task[TaskEntityAttributeNames.TaskForm] = new OptionSetValue(10);// waiver deferral task form
                task[TaskEntityAttributeNames.OwnerId] = assignee;
                task[TaskEntityAttributeNames.JobNumber] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                task[TaskEntityAttributeNames.FilingNumber] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                task[TaskEntityAttributeNames.CurrentFilingStatus] = jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName);
                task[TaskEntityAttributeNames.Address] = jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.HouseNumber) + ", " + jobFiling.GetAttributeValue<string>(JobFilingEntityAttributeName.Street);
                task[TaskEntityAttributeNames.PropertyProfile] = jobFiling.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PropertProfileId);
                task.Id = localService.Create(task);
                localCrmTrace.AppendLine(string.Format("new task {0} created", taskSubject));
            }
        }

        private static EntityReference FetchTeamRef(string name)
        {
            EntityReference teamRef = null;
            try
            {
                QueryByAttribute query = new QueryByAttribute(TeamEntityAttributeNames.EntityLogicalName);
                query.AddAttributeValue(TeamEntityAttributeNames.NameFieldName, name);
                query.ColumnSet = new ColumnSet(new string[] { TeamEntityAttributeNames.TeamIdByFieldName, TeamEntityAttributeNames.NameFieldName });
                EntityCollection results = localService.RetrieveMultiple(query);
                if (results.Entities.Count == 1)
                {
                    teamRef = new EntityReference(TeamEntityAttributeNames.EntityLogicalName, results.Entities[0].Id);
                    localCrmTrace.AppendLine(string.Format("FetchTeamRef {0} {1}", name, teamRef.Id.ToString()));
                }
                else
                {
                    throw new Exception(string.Format("Team with name {0} not found", name));
                }
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - FetchTeamRef", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - FetchTeamRef", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            return teamRef;
        }

        private static EntityReference FetchChildTeamRef(string ParentTeamId)
        {
            EntityReference teamRef = null;
            try
            {
                EntityCollection ChildTeam = localService.RetrieveMultiple(new FetchExpression(string.Format(FetchXml.GetChildTeam, ParentTeamId)));
                if (ChildTeam != null && ChildTeam.Entities.Count > 0)
                {
                    teamRef = new EntityReference(TeamEntityAttributeNames.EntityLogicalName, ChildTeam.Entities[0].Id);
                    localCrmTrace.AppendLine(string.Format("FetchChildTeamRef {0} {1}", ParentTeamId, teamRef.Id.ToString()));
                }
                else
                {
                    throw new Exception(string.Format("Team with ParentTeamId {0} not found", ParentTeamId));
                }

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - FetchChildTeamRef", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFiling.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - FetchChildTeamRef", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            return teamRef;
        }

        private static void ApproveWaiver(Entity documentList)
        {
            //Update document list - status, waiver requested, is submitted 
            documentList[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue((int)DocumentStatus.WaiverApproved);
            UpdateDocumentList(documentList);
        }

        private static void RejectWaiver(Entity documentList)
        {
            //Update document list - status, waiver requested, is submitted, reject counter
            documentList[DocumentListEntityAttributeName.WaiverRejectCounter] = IncrementCounter(documentList.GetAttributeValue<int?>(DocumentListEntityAttributeName.WaiverRejectCounter));
            documentList[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue((int)DocumentStatus.WaiverRejected);
            UpdateDocumentList(documentList);
        }

        private static void ApproveDeferral(Entity documentList)
        {
            //Update document list - status, deferral requested, is submitted 
            documentList[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue((int)DocumentStatus.DeferralApproved);
            UpdateDocumentList(documentList);
        }

        private static void RejectDeferral(Entity documentList)
        {
            //Update document list - status, waiver requested, is submitted, reject counter
            documentList[DocumentListEntityAttributeName.DocumentStatus] = new OptionSetValue((int)DocumentStatus.DeferralRejected);
            documentList[DocumentListEntityAttributeName.DeferralRejectCounter] = IncrementCounter(documentList.GetAttributeValue<int?>(DocumentListEntityAttributeName.DeferralRejectCounter));
            UpdateDocumentList(documentList);
        }

        private static void UpdateDocumentList(Entity documentList)
        {
            try
            {
                localService.Update(documentList);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - UpdateDocumentList", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - UpdateDocumentList", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - UpdateDocumentList", null, localCrmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(documentList.Id.ToString(), SourceChannel.CRM, "WaiverDeferralHandler - UpdateDocumentList", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        private static object IncrementCounter(int? counter)
        {
            if (counter.HasValue) return counter + 1;
            else return 1;
        }
    }
}
