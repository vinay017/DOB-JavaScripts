﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class SubmitHandler : PluginHandlerBase
    {
        public static Entity JobFilingSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_JobFiling = new string[] {
                            JobFilingEntityAttributeName.ProfessionalCertificate, JobFilingEntityAttributeName.RevertedtoDPfrom,JobFilingEntityAttributeName.FilingTypeAttributeName,
                            JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.JobStatus,JobFilingEntityAttributeName.PACheckBox,
                            JobFilingEntityAttributeName.IsPAAbyModifyingPW1Section3or12, JobFilingEntityAttributeName.CreateaSupersedingRequest,
                            JobFilingEntityAttributeName.SupersedingRequestStatus, JobFilingEntityAttributeName.JobTypeMultiStake,JobFilingEntityAttributeName.IsExistingProdAlterationJob, JobFilingEntityAttributeName.JobFilingNumAttribute, JobFilingEntityAttributeName.IsHistoricJobFiling};
                Entity response = Retrieve(service, Column_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);

                bool proCert = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                crmTrace.AppendLine("proCert: " + proCert.ToString());
                int revertDP = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.RevertedtoDPfrom).Value;
                crmTrace.AppendLine("revertDP: " + revertDP.ToString());
                int currentFillingStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                crmTrace.AppendLine("currentFillingStatus: " + currentFillingStatus.ToString());
                int jobStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobStatus).Value;
                crmTrace.AppendLine("JobStatus: " + jobStatus.ToString());
                bool pAAbyMod3or12 = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPAAbyModifyingPW1Section3or12);
                crmTrace.AppendLine("pAAbyMod3or12: " + pAAbyMod3or12.ToString());
                bool CreateSuperseding = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.CreateaSupersedingRequest);
                crmTrace.AppendLine("CreateSuperseding: " + CreateSuperseding.ToString());
                int SupersedingRequestStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.SupersedingRequestStatus).Value;
                crmTrace.AppendLine("SupersedingRequestStatus: " + SupersedingRequestStatus.ToString());
                //int JobTypeMultiStake = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.JobTypeMultiStake).Value;
                //crmTrace.AppendLine("currentFillingStatus: " + JobTypeMultiStake.ToString());
                bool IsExistingProdAlterationJob = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsExistingProdAlterationJob);
                crmTrace.AppendLine("currentFillingStatus: " + IsExistingProdAlterationJob.ToString());
                bool currentPA = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox);
                crmTrace.AppendLine("currentPlace Of Assembly: " + currentPA);
                int filingType = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingTypeAttributeName).Value;
                crmTrace.AppendLine("filingType: " + filingType);
                #region Superseding Submit

                if (CreateSuperseding == true)
                {
                    if (SupersedingRequestStatus == (int)SupersedingStatus.PreFiling)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SupersedingRequestStatus, new OptionSetValue((int)SupersedingStatus.PendingQAAssignment));
                    }
                    if (SupersedingRequestStatus == (int)SupersedingStatus.Objections)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.SupersedingRequestStatus, new OptionSetValue((int)SupersedingStatus.QAReview));
                    }

                    return targetEntity;
                }

                #endregion

                if (jobStatus == (int)JobStatus.JobinProcess)
                {
                    #region Job in Process

                    if (currentFillingStatus == (int)CurrentFilingStatus.MinorMajorObjections ||
                        currentFillingStatus == (int)CurrentFilingStatus.Incomplete ||
                        currentFillingStatus == (int)CurrentFilingStatus.PreFiling ||
                        currentFillingStatus == (int)CurrentFilingStatus.DesignProfessionalReview ||
                        currentFillingStatus == (int)CurrentFilingStatus.QAFailed)
                    {
                        ///<summary>
                        ///  JobTypeMultiStake - Included with multistake changes. 
                        ///  1- Alteration - All exisitng production filing
                        ///  2- Alternation(New) - All new alteration filings 
                        ///  3- New Builings
                        /// </summary>

                        if (IsExistingProdAlterationJob == true)
                        {
                            ///<summary>
                            ///  Earlier to MultiStake Changes- Implementation
                            ///  </summary>
                            ///  
                            if (proCert == true)
                            {
                                crmTrace.AppendLine("Professional Certification ");
                                switch (revertDP)
                                {
                                    case (int)RevertedtoDPfrom.None:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAAssignment));
                                        DateTime currentdate = DateTime.Now;
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProfCertQASupervisorAssignedDate, currentdate.Date);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, currentdate.Date);
                                        break;
                                    case (int)RevertedtoDPfrom.QAFailed:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.QAReview));
                                        break;
                                    case (int)RevertedtoDPfrom.ProfCertQAFailed:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAReview));
                                        break;
                                    default:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAAssignment));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate,  DateTime.Now.Date);
                                        break;
                                }

                            }
                            if (proCert == false)
                            {
                                crmTrace.AppendLine("Standard Plan ");
                                switch (revertDP)
                                {
                                    case (int)RevertedtoDPfrom.None:
                                        if (currentFillingStatus == (int)CurrentFilingStatus.PreFiling || currentFillingStatus == (int)CurrentFilingStatus.DesignProfessionalReview)
                                        {
                                            crmTrace.AppendLine("PreFiling or Design Professional Review ");
                                            CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                            if (pAAbyMod3or12 == true)
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingQAAssignment));
                                            else
                                            {
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingPlanExaminer));
                                                DateTime currentdate = DateTime.Now;
                                                CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.CPEAssignedDate, currentdate.Date);
                                                
                                            }
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        }

                                        break;

                                    case (int)RevertedtoDPfrom.CPEIncomplete:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingPlanExaminer));
                                        break;

                                    case (int)RevertedtoDPfrom.CPEObjections:
                                        if (currentFillingStatus == (int)CurrentFilingStatus.Approved)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PlanExaminerReview));
                                            DateTime currentdate = DateTime.Now;
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ResubmitDate, currentdate.Date);
                                        }
                                        break;

                                    case (int)RevertedtoDPfrom.PEObjections:
                                        if (currentFillingStatus == (int)CurrentFilingStatus.Approved)
                                        {
                                            break;
                                        }
                                        else
                                        {
                                            CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PlanExaminerReview));
                                            DateTime currentdate = DateTime.Now;
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ResubmitDate, currentdate.Date);
                                        }
                                        break;

                                    case (int)RevertedtoDPfrom.QAFailed:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.QAReview));
                                        break;
                                    default:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingPlanExaminer));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        break;
                                }
                            }
                        }
                        else
                        {
                            ///<summary>
                            ///  MultiStake Changes- Implementation
                            ///  </summary>
                            if (proCert == true)
                            {
                                crmTrace.AppendLine("Professional Certification ");
                                switch (revertDP)
                                {
                                    case (int)RevertedtoDPfrom.None:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAAssignment));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ProfCertQASupervisorAssignedDate, DateTime.Now.Date);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        break;
                                    case (int)RevertedtoDPfrom.QAFailed:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.QAReview));
                                        break;
                                    case (int)RevertedtoDPfrom.ProfCertQAFailed:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAReview));
                                        break;
                                    default:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingProfCertQAAssignment));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        break;
                                }

                            }
                            if (proCert == false)
                            {
                                crmTrace.AppendLine("Standard Plan ");
                                switch (revertDP)
                                {
                                    case (int)RevertedtoDPfrom.None:
                                        if (currentFillingStatus == (int)CurrentFilingStatus.PreFiling || currentFillingStatus == (int)CurrentFilingStatus.DesignProfessionalReview)
                                        {
                                            crmTrace.AppendLine("PreFiling or Design Professional Review ");
                                            CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingCPEACPEAssignment));
                                            CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        }
                                        break;

                                    case (int)RevertedtoDPfrom.CPEIncomplete:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingPlanExaminer));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ResubmitDate, DateTime.Now.Date);
                                        break;

                                    case (int)RevertedtoDPfrom.CPEObjections:

                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PlanExaminerReview));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ResubmitDate, DateTime.Now.Date);
                                        break;

                                    case (int)RevertedtoDPfrom.PEObjections:
                                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PlanExaminerReview));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.ResubmitDate, DateTime.Now.Date);
                                        break;

                                    default:
                                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PendingPlanExaminer));
                                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.FilingDate, DateTime.Now.Date);
                                        break;
                                }
                            }
                        }

                    }
                    #endregion
                }
                #region Place of Assembly PAA Submit- Check the place of assembly Intend to check plans is true
                if (currentPA == true && filingType == (int)FilingTypes.PA)
                {
                    if (PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA(service, targetEntity, crmTrace))
                    {
                        EntityCollection ProgressInspectionCategoryinfo = RetrieveRelatedEntities(service, targetEntity.Id, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                        crmTrace.AppendLine("PROGRESS INSPECTION CATEGORY Count: " + ProgressInspectionCategoryinfo.Entities.Count);
                        if (ProgressInspectionCategoryinfo != null && ProgressInspectionCategoryinfo.Entities.Count > 0)
                        {
                            foreach (Entity item in ProgressInspectionCategoryinfo.Entities)
                            {
                                item.Attributes[ProgressInspectionCategoryEntityAttributeName.ICertifyCompleteInspectionsTests] = false; 
                                item.Attributes[ProgressInspectionCategoryEntityAttributeName.CertificateOfCompletionStatement] = false;
                                item.Attributes[ProgressInspectionCategoryEntityAttributeName.ProgressCompletionName] = null;
                                item.Attributes[ProgressInspectionCategoryEntityAttributeName.ProgressCompletionDate] = null;
                                item.Attributes[ProgressInspectionCategoryEntityAttributeName.CertificateofCompleteInspections] = null;
                                service.Update(item);
                                crmTrace.AppendLine("PROGRESS INSPECTION CATEGORY Update Completed: ");                               
                            }

                        }
                    }
                }
                #endregion
                else
                {
                    if (jobStatus == (int)JobStatus.ObjectionstoLOC)
                    {
                        CommonPluginLibrary.SetAttributeValue(targetEntity, JobFilingEntityAttributeName.JobStatus, new OptionSetValue((int)JobStatus.QAReviewforLOC));
                    }

                }

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", null, crmTrace.ToString(), null, null);
                return targetEntity;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - JobFilingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        private static bool PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            bool PrimaryPlanFlag = false;
            try
            {
                EntityCollection PlaceofAssemblySpaceInfoPAA = RetrieveRelatedEntities(service, targetEntity.Id, PlaceofAssemblySpaceInformation.EntityLogicalName, PlaceofAssemblySpaceInformation.jobFilingID);
                crmTrace.AppendLine("PlaceofAssemblySpaceInformation Count: " + PlaceofAssemblySpaceInfoPAA.Entities.Count);
                if (PlaceofAssemblySpaceInfoPAA != null && PlaceofAssemblySpaceInfoPAA.Entities.Count > 0)
                {
                    Entity PAA_PASinformation = (Entity)PlaceofAssemblySpaceInfoPAA.Entities[0];
                    PrimaryPlanFlag = PAA_PASinformation.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                    crmTrace.AppendLine("Place of assembly space information Intend To update Primary Plans flag ---" + PrimaryPlanFlag);
                    if (PrimaryPlanFlag == true)
                    {
                        return PrimaryPlanFlag;
                    }
                }
                return PrimaryPlanFlag;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PrimaryPlanFlag;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PrimaryPlanFlag;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PlaceOfAssemblyIntendToUpdatePrimaryPlanforPAA", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PrimaryPlanFlag;
            }

        }

        public static Entity WorkPermitSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_WorkPermit = new string[] { WorkPermitEntityAttributeName.GotoJobFiling, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.AddedbeforeProfReview, WorkPermitEntityAttributeName.TrackingNumber };
                Entity response = Retrieve(service, Column_WorkPermit, targetEntity.Id, WorkPermitEntityAttributeName.EntityLogicalName);

                int currentWorkPermitStatus = response.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.WorkPermitStatus).Value;
                crmTrace.AppendLine("currentWorkPermitStatus: " + currentWorkPermitStatus.ToString());

                #region WorkPermit Status
                Guid jobFilingGuid = ((EntityReference)response[WorkPermitEntityAttributeName.GotoJobFiling]).Id;
                string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.BoroughAttributeName,
                   JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.SupersedingRequestStatus, JobFilingEntityAttributeName.FilingType,
                   JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription, JobFilingEntityAttributeName.SupersedingRequesterId, JobFilingEntityAttributeName.ProfessionalCertificate,
                   JobFilingEntityAttributeName.ApplicantPerson,  JobFilingEntityAttributeName.SupersedingWorkpermit};


                crmTrace.AppendLine("Retreive Regarding Job Filing Record");
                ConditionExpression jobFilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                EntityCollection JFresponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobFilingCondition }, LogicalOperator.And);
                crmTrace.AppendLine("Retreived Regarding Job Filing Record");
                bool profcert = JFresponse.Entities[0].GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                int filingStatus = JFresponse.Entities[0].GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                crmTrace.AppendLine("profcert: " + profcert);
                crmTrace.AppendLine("filingStatus: " + filingStatus);
                #endregion
                DateTime currentdate = DateTime.Now;

                if (currentWorkPermitStatus == (int)WorkpermitStatus.PendingforSubmission)
                {
                    if ((profcert == true) && (filingStatus == (int)CurrentFilingStatus.PreFiling || filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview || filingStatus == (int)CurrentFilingStatus.PendingProfCertQAAssignment || filingStatus == (int)CurrentFilingStatus.PendingProfCertQAReview || filingStatus == (int)CurrentFilingStatus.ProfCertQAinReview || filingStatus == (int)CurrentFilingStatus.QAFailed || filingStatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview ))
                    {
                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                        CreateBuildTrace(service, targetEntity, response, "Prof Cert QA Review", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.ProfCertQAReview));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PermitSubmittedDated, currentdate.Date);
                    }
                    else
                    {
                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PendingQAAssignment));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PermitSubmittedDated, currentdate.Date);
                    }
                    //throw new Exception("Permit TEST");
                }

                bool addedAfterProfReview = response.GetAttributeValue<bool>(WorkPermitEntityAttributeName.AddedbeforeProfReview);
                crmTrace.AppendLine("addedAfterProfReview: " + addedAfterProfReview);

                if (currentWorkPermitStatus == (int)WorkpermitStatus.QAFailed && addedAfterProfReview == false)
                {
                    CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.QAReview));
                }
                if (currentWorkPermitStatus == (int)WorkpermitStatus.QAFailed && addedAfterProfReview == true)
                {
                    CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                    CreateBuildTrace(service, targetEntity, response, "Prof Cert QA Review", crmTrace);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.ProfCertQAReview));
                }
                if (currentWorkPermitStatus == (int)WorkpermitStatus.ObjectionstoSignoff)
                {
                    CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.QAReviewforSignoff));
                }

                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WorkPermitSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static Entity WithdrawalSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_Withdrawal = new string[] { WithdrawalRequestEntityAttributeName.WithdrawalStatus };
                Entity response = Retrieve(service, Column_Withdrawal, targetEntity.Id, WithdrawalRequestEntityAttributeName.EntityLogicalName);

                int currentWithdrawalStatus = response.GetAttributeValue<OptionSetValue>(WithdrawalRequestEntityAttributeName.WithdrawalStatus).Value;
                crmTrace.AppendLine("currentWithdrawalStatus: " + currentWithdrawalStatus.ToString());
                if (currentWithdrawalStatus == (int)WithdrawalStatus.PreFiling)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WithdrawalRequestEntityAttributeName.WithdrawalStatus, new OptionSetValue((int)WithdrawalStatus.PendingQAAssignment));
                if (currentWithdrawalStatus == (int)WithdrawalStatus.QAFailed)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WithdrawalRequestEntityAttributeName.WithdrawalStatus, new OptionSetValue((int)WithdrawalStatus.QAReview));
                if (currentWithdrawalStatus == (int)WithdrawalStatus.WithdrawalObjections)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WithdrawalRequestEntityAttributeName.WithdrawalStatus, new OptionSetValue((int)WithdrawalStatus.QAReview));


                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - WithdrawalSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static Entity SupersedingSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_Superseding = new string[] { SupersedingRequestEntityAttributeName.SupersedingRequestStatus };
                Entity response = Retrieve(service, Column_Superseding, targetEntity.Id, SupersedingRequestEntityAttributeName.EntityLogicalName);

                int currentSupersedingStatus = response.GetAttributeValue<OptionSetValue>(SupersedingRequestEntityAttributeName.SupersedingRequestStatus).Value;
                crmTrace.AppendLine("currentSupersedingStatus: " + currentSupersedingStatus.ToString());

                if (currentSupersedingStatus == (int)SupersedingStatus.PreFiling)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, SupersedingRequestEntityAttributeName.SupersedingRequestStatus, new OptionSetValue((int)SupersedingStatus.PendingQAAssignment));
                if (currentSupersedingStatus == (int)SupersedingStatus.Objections)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, SupersedingRequestEntityAttributeName.SupersedingRequestStatus, new OptionSetValue((int)SupersedingStatus.QAReview));


                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - SupersedingSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static Entity AddressChangeSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_AddressChange = new string[] { AddressChangeRequestsEntityAttributeName.RequestStatus };
                Entity response = Retrieve(service, Column_AddressChange, targetEntity.Id, AddressChangeRequestsEntityAttributeName.EntityLogicalName);

                int currentRequestStatus = response.GetAttributeValue<OptionSetValue>(AddressChangeRequestsEntityAttributeName.RequestStatus).Value;
                crmTrace.AppendLine("currentRequestStatus: " + currentRequestStatus.ToString());

                if (currentRequestStatus == (int)AddressChangeStatus.Reject)
                    CommonPluginLibrary.SetAttributeValue(targetEntity, AddressChangeRequestsEntityAttributeName.RequestStatus, new OptionSetValue((int)AddressChangeStatus.PendingQAReview));


                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AddressChangeSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static Entity AHVSubmit(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                string[] Column_AHV = new string[] { AfterHourVarianceAttributeNames.AHVPermitStatus, AfterHourVarianceAttributeNames.VarianceType, AfterHourVarianceAttributeNames.AllowRenewal, AfterHourVarianceAttributeNames.IsFeeExempt, AfterHourVarianceAttributeNames.AHVPermitNumber, AfterHourVarianceAttributeNames.JobFiling };
                Entity response = Retrieve(service, Column_AHV, targetEntity.Id, AfterHourVarianceAttributeNames.EntityLogicalName);

                int currentAHVPermitStatus = response.GetAttributeValue<OptionSetValue>(AfterHourVarianceAttributeNames.AHVPermitStatus).Value;
                crmTrace.AppendLine("currentWorkPermitStatus: " + currentAHVPermitStatus.ToString());
                int varianceType = response.GetAttributeValue<OptionSetValue>(AfterHourVarianceAttributeNames.VarianceType).Value;
                crmTrace.AppendLine("VarianceType: " + varianceType.ToString());

                if (varianceType == (int)VarianceType.Intial)
                {
                    if (currentAHVPermitStatus == (int)AHVRequestStatus.PreFiling)
                    {
                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, AfterHourVarianceAttributeNames.AHVPermitStatus, new OptionSetValue((int)AHVRequestStatus.PendingQAAssignment));
                    }

                    if (currentAHVPermitStatus == (int)AHVRequestStatus.OnHold)
                    {
                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, AfterHourVarianceAttributeNames.AHVPermitStatus, new OptionSetValue((int)AHVRequestStatus.QAReview));
                    }
                }

                if (varianceType == (int)VarianceType.Renewal)
                {
                    bool isfeeExempt = response.GetAttributeValue<bool>(AfterHourVarianceAttributeNames.IsFeeExempt);
                    crmTrace.AppendLine("isfeeExemt: " + isfeeExempt.ToString());
                    if (isfeeExempt)
                    {
                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, AfterHourVarianceAttributeNames.AHVPermitStatus, new OptionSetValue((int)AHVRequestStatus.AHVPermitIssued));
                        //CreateBuildTrace(service, targetEntity, response, "AHV Permit Issued", crmTrace);
                    }
                    else
                    {
                        CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, AfterHourVarianceAttributeNames.AHVPermitStatus, new OptionSetValue((int)AHVRequestStatus.Approved));
                        //CreateBuildTrace(service, targetEntity, response, "Approved", crmTrace);
                    }
                }


                    return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - AHVSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }

        public static Entity LOCRequestSubmit(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {
            try
            {
                string[] Column_LOCRequest = new string[] { LOCPW7EntityAttributeName.LOCRequestStatus, LOCPW7EntityAttributeName.HasTechnicalDocuments, LOCPW7EntityAttributeName.RejectedFrom, LOCPW7EntityAttributeName.Name, LOCPW7EntityAttributeName.GotoJobFiling };
                Entity response = Retrieve(service, Column_LOCRequest, targetEntity.Id, LOCPW7EntityAttributeName.EntityLogicalName);

                int currentLOCRequestStatus = response.GetAttributeValue<OptionSetValue>(LOCPW7EntityAttributeName.LOCRequestStatus).Value;
                int rejectedFrom = response.GetAttributeValue<OptionSetValue>(LOCPW7EntityAttributeName.RejectedFrom).Value;
                bool hasTechnicalDocuments = response.GetAttributeValue<bool>(LOCPW7EntityAttributeName.HasTechnicalDocuments);

                crmTrace.AppendLine("currentLOCRequest: " + currentLOCRequestStatus.ToString());
                crmTrace.AppendLine("rejectedFrom: " + rejectedFrom.ToString());
                crmTrace.AppendLine("hasTechnicalDocuments: " + hasTechnicalDocuments.ToString());

                switch (rejectedFrom)
                {
                    case (int)LOCRejectedFrom.None:
                        if (hasTechnicalDocuments)
                        {
                            DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOC Request: Has Technical Documents", null, crmTrace.ToString(), null, null);
                            CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                            CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRequestStatus, new OptionSetValue((int)LOCRequestStatus.LOCTechnicalReview));
                            CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.InitialFilingDate, DateTime.Now);
                            JobFilingLOCHandler.UpdateJobFilingStatus_LOC(service, preImage, JobFilingEntityAttributeName.JobStatus, (int)JobStatus.LOCRequested, crmTrace);
                            break;
                        }
                        else
                        {
                            DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOC Request: Doesnot has Technical Documents", null, crmTrace.ToString(), null, null);
                            CreateBuildTrace(service, targetEntity, response, "Filed", crmTrace);
                            CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRequestStatus, new OptionSetValue((int)LOCRequestStatus.PendingQAAssignmentforLOC));
                            CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.InitialFilingDate, DateTime.Now);
                            JobFilingLOCHandler.UpdateJobFilingStatus_LOC(service, preImage, JobFilingEntityAttributeName.JobStatus, (int)JobStatus.LOCRequested, crmTrace);
                            break;
                        }

                    case (int)LOCRejectedFrom.LOCTechnicalReview:
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOC Request: Techincal Review", null, crmTrace.ToString(), null, null);
                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRequestStatus, new OptionSetValue((int)LOCRequestStatus.LOCTechnicalReview));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRejectedDate, DateTime.Now);
                        break;

                    case (int)LOCRejectedFrom.LOCQAReview:
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOC Request: QA Review", null, crmTrace.ToString(), null, null);
                        CreateBuildTrace(service, targetEntity, response, "Resubmitted", crmTrace);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRequestStatus, new OptionSetValue((int)LOCRequestStatus.QAReviewforLOC));
                        CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRejectedDate, DateTime.Now);
                        break;

                    default:
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "LOC Request: Pre-Filing", null, crmTrace.ToString(), null, null);
                        CommonPluginLibrary.SetAttributeValue(targetEntity, LOCPW7EntityAttributeName.LOCRequestStatus, new OptionSetValue((int)LOCRequestStatus.Pre_Filing));
                        break;
                }
                return targetEntity;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - LOCRequestStatus", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
        }
        /// <summary>
        /// this method is used to handle the logic for  filing of PASpaceInformation 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="crmTrace"></param>
        /// <param name="preImage"></param>
        /// <returns></returns>
        public static void PASpaceInfoSubmit(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {

            try
            {


                int currentRequestStatus = targetEntity.Contains(PlaceofAssemblySpaceInformation.PACOreportStatus) ? targetEntity.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value : preImage.GetAttributeValue<OptionSetValue>(PlaceofAssemblySpaceInformation.PACOreportStatus).Value;

                crmTrace.AppendLine("currentRequestStatus Completed: " + currentRequestStatus.ToString());


                switch (currentRequestStatus)
                {
                    case (int)PACOReportStatus.PreFiling:
                        {
                            crmTrace.AppendLine(" In PreFiling set status to ProfCertQAAssignment: ");
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.PACOreportStatus, new OptionSetValue((int)PACOReportStatus.ProfCertQAAssignment));
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.FilingDate, DateTime.UtcNow );
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.RequestedDate, DateTime.UtcNow);
                            break;
                        }
                    case (int)PACOReportStatus.QAFailed:
                        {
                            crmTrace.AppendLine(" In QAFailed set status to ProfCertQAReview: ");
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.PACOreportStatus, new OptionSetValue((int)PACOReportStatus.ProfCertQAReview));
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.FilingDate, DateTime.UtcNow);
                            break;
                        }
                    default:
                        {
                            crmTrace.AppendLine(" In PreFiling set status to ProfCertQAAssignment: ");
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.PACOreportStatus, new OptionSetValue((int)PACOReportStatus.ProfCertQAAssignment));
                            targetEntity.SetAttributeValue(PlaceofAssemblySpaceInformation.FilingDate, DateTime.UtcNow);
                            break;
                        }
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));

            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - PASpaceInfoSubmit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);

            }
        }
        public static EntityCollection RetrieveRelatedEntities(IOrganizationService service, Guid targetEntityGuid, string RelatedEntitySchemaName, string RelationshipName)
        {
                ConditionExpression responseCondition = CreateConditionExpression(RelationshipName, ConditionOperator.Equal, new string[] { targetEntityGuid.ToString() });
                FilterExpression filterExpression = new FilterExpression();
                filterExpression.Conditions.AddRange(responseCondition);
                filterExpression.FilterOperator = LogicalOperator.And;
                ColumnSet columns = new ColumnSet(true);
                QueryExpression qe = new QueryExpression();
                qe.EntityName = RelatedEntitySchemaName;
                qe.ColumnSet = new ColumnSet(true);
                qe.Criteria = filterExpression;
                qe.NoLock = true;
                EntityCollection response = service.RetrieveMultiple(qe);
                return response;
        }
        /// <summary>
        /// This method create new trace history
        /// </summary>
        /// <param name="service"></param>
        /// <param name="targetEntity"></param>
        /// <param name="preImage"></param>
        /// <param name="Action"></param>
        /// <param name="crmTrace"></param>
        public static void CreateBuildTrace(IOrganizationService service, Entity targetEntity, Entity preImage, string Action, StringBuilder crmTrace)
        {
            try
            {
                System.Threading.Thread.Sleep(2000);
                crmTrace.AppendLine("Start CreateBuildTrace");
                crmTrace.AppendLine("Action: " + Action);
                Entity CraneTrace = new Entity(BuildTraceHistory.EntityLogicalName);
                if (targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                {
                    if (preImage.Contains(WorkPermitEntityAttributeName.GotoJobFiling))
                    {
                        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.GotoJobFiling).Id, new ColumnSet(JobFilingEntityAttributeName.IsHistoricJobFiling));
                        if (!JF.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) || JF[JobFilingEntityAttributeName.IsHistoricJobFiling] == null)
                        {
                            crmTrace.AppendLine("Not Historic Filing");
                            CraneTrace.Attributes.Add(BuildTraceHistory.Name, preImage.GetAttributeValue<string>(WorkPermitEntityAttributeName.TrackingNumber) + ": " + Action);
                            CraneTrace.Attributes.Add(BuildTraceHistory.RegardingWorkPermit, new EntityReference(targetEntity.LogicalName, targetEntity.Id));
                            CraneTrace.Attributes.Add(BuildTraceHistory.Comments, "Comments not applicable");
                            service.Create(CraneTrace);
                        }
                    }
                }
                if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                {
                    if (preImage.Contains(AfterHourVarianceAttributeNames.JobFiling))
                    {
                        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(AfterHourVarianceAttributeNames.JobFiling).Id, new ColumnSet(JobFilingEntityAttributeName.IsHistoricJobFiling));
                        if (!JF.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) || JF.Attributes[JobFilingEntityAttributeName.IsHistoricJobFiling] == null)
                        {
                            crmTrace.AppendLine("Not Historic Filing");
                            CraneTrace.Attributes.Add(BuildTraceHistory.Name, preImage.GetAttributeValue<string>(AfterHourVarianceAttributeNames.AHVPermitNumber) + ": " + Action);
                            CraneTrace.Attributes.Add(BuildTraceHistory.RegardingAHV, new EntityReference(targetEntity.LogicalName, targetEntity.Id));
                            CraneTrace.Attributes.Add(BuildTraceHistory.Comments, "Comments not applicable");
                            service.Create(CraneTrace);
                        }
                    }
                }
                if (targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                {
                    if (!preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) || preImage[JobFilingEntityAttributeName.IsHistoricJobFiling] == null)
                    {
                        CraneTrace.Attributes.Add(BuildTraceHistory.Name, preImage.GetAttributeValue<string>(JobFilingEntityAttributeName.JobFilingNumAttribute) + ": " + Action);
                        //CraneTrace.Attributes.Add(BuildTraceHistory.Currentfilingstatus, new OptionSetValue(targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value));
                        CraneTrace.Attributes.Add(BuildTraceHistory.RegardingjobFiling, new EntityReference(targetEntity.LogicalName, targetEntity.Id));
                        CraneTrace.Attributes.Add(BuildTraceHistory.Comments, "Comments not applicable");
                        service.Create(CraneTrace);
                    }
                }
                if (targetEntity.LogicalName == LOCPW7EntityAttributeName.EntityLogicalName)
                {
                    if (preImage.Contains(LOCPW7EntityAttributeName.GotoJobFiling))
                    {
                        Entity JF = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, preImage.GetAttributeValue<EntityReference>(LOCPW7EntityAttributeName.GotoJobFiling).Id, new ColumnSet(JobFilingEntityAttributeName.IsHistoricJobFiling));
                        if (!JF.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling) || JF[JobFilingEntityAttributeName.IsHistoricJobFiling] == null)
                        {
                            CraneTrace.Attributes.Add(BuildTraceHistory.Name, preImage.GetAttributeValue<string>(LOCPW7EntityAttributeName.Name) + ": " + Action);
                            CraneTrace.Attributes.Add(BuildTraceHistory.RegardingLOC, new EntityReference(targetEntity.LogicalName, targetEntity.Id));
                            CraneTrace.Attributes.Add(BuildTraceHistory.Comments, "Comments not applicable");
                            service.Create(CraneTrace);
                        }
                    }
                }
                if (targetEntity.LogicalName == OP49EntityAttributeNames.EntityLogicalName)
                {
                    CraneTrace.Attributes.Add(BuildTraceHistory.Name, preImage.GetAttributeValue<string>(OP49EntityAttributeNames.Name) + ": " + Action);
                    CraneTrace.Attributes.Add(BuildTraceHistory.RegardingOP49, new EntityReference(targetEntity.LogicalName, targetEntity.Id));
                    CraneTrace.Attributes.Add(BuildTraceHistory.Comments, "Comments not applicable");
                    service.Create(CraneTrace);
                }

                crmTrace.AppendLine("End CreateBuildTrace");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                throw ex;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "SubmitHandler - BuildTraceHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw ex;
            }
        }

    } //class ends
} // namespace ends
