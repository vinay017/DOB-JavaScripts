﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOB.Logging;
using Microsoft.Xrm.Client;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class JobFilingWithdrawalHandler : PluginHandlerBase
    {
        public static void Withdrawal(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, Entity preImage, int withdrawalStatus)
        {
            try
            {

                Entity Tentity = (Entity)preImage;
                crmTrace.AppendLine("Tentity: " + Tentity.LogicalName);
                Guid jobFilingGuid = ((EntityReference)Tentity[WithdrawalRequestEntityAttributeName.GotoJobFiling]).Id;
                crmTrace.AppendLine("Regarding Job Filing Guid: " + jobFilingGuid.ToString());

                string[] Column_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.ProfessionalCertificate,
                    JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.SprinklerCheckBox};
                Entity response = Retrieve(service, Column_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);
                string regardingJobNumber = response.GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                crmTrace.AppendLine("Regarding JobNumber: " + regardingJobNumber);

                crmTrace.AppendLine("Withdrawal started!");

                #region Withdrawal initiated On Hold Logic
                if (withdrawalStatus == (int)WithdrawalStatus.PendingQAAssignment)
                {
                    Entity WithdrawalRequest = Retrieve(service, new String[] { WithdrawalRequestEntityAttributeName.Withdrawalof }, targetEntity.Id, WithdrawalRequestEntityAttributeName.EntityLogicalName);
                    int withdrawalof = WithdrawalRequest.GetAttributeValue<OptionSetValue>(WithdrawalRequestEntityAttributeName.Withdrawalof).Value;
                    crmTrace.AppendLine("withdrawalof: " + withdrawalof);

                    #region Withdrawal of Job initiated
                    if(withdrawalof == (int)Withdrawalof.Job)
                    {
                        crmTrace.AppendLine("Withdrawal of Job initiated Started");
                        ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { regardingJobNumber });
                        EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription }, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                        Guid jfID = new Guid();

                        crmTrace.AppendLine("Got all the Job Filing and related Job filings");
                        // Make sure what ever you are checking you are retrieving above

                        if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                            for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                            {
                                crmTrace.AppendLine("Updating Job filing:" + i);
                                jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.OnHold));
                                crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                service.Update(jobFiling);
                                crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                                //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                            }

                        }

                    }
                    #endregion

                    #region Withdrawal of Filing initiated
                    if (withdrawalof == (int)Withdrawalof.Filing)
                    {
                        crmTrace.AppendLine("Withdrawal of Filing initiated Started");
                        string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status,
                       JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription,
                       JobFilingEntityAttributeName.IsPlanApproved, JobFilingEntityAttributeName.IsAfterPermitIssued, JobFilingEntityAttributeName.FilingType};

                        ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                        Guid jfID = new Guid();

                        string JobNumber = jobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                        string IsplanApproved = jobfilingResponse.Entities[0].GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPlanApproved).ToString();
                        crmTrace.AppendLine("JobNumber: " + JobNumber);

                        // check if There is a PAA and is not approved
                        ConditionExpression PAACondition1 = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { JobNumber });
                        ConditionExpression PAACondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingType, ConditionOperator.Equal, new string[] { ((int)FilingType.PAA).ToString() });
                        ConditionExpression PAACondition3 = CreateConditionExpression(JobFilingEntityAttributeName.IsPlanApproved, ConditionOperator.Equal, new string[] { false.ToString() });

                        EntityCollection PAAResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { PAACondition1, PAACondition2, PAACondition3 }, LogicalOperator.And);


                        crmTrace.AppendLine("Got the Job Filing record");
                        // Make sure what ever you are checking you are retrieving above

                        if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                            for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                            {
                                crmTrace.AppendLine("Updating Job filing:" + i);
                                jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.OnHold));
                                crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                service.Update(jobFiling);
                                crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                                //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                            }

                        }


                        if (PAAResponse != null && PAAResponse.Entities != null && PAAResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("PAAResponse count: " + PAAResponse.Entities.Count);
                            for (int i = 0; i < PAAResponse.Entities.Count; i++)
                            {
                                crmTrace.AppendLine("Updating PAA Job filing:" + i);
                                jfID = Guid.Parse(PAAResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.OnHold));

                                crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                service.Update(jobFiling);
                                crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                                //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                            }

                        }

                    }
                    #endregion

                    #region Withdrawal of DP initiated
                    if (withdrawalof == (int)Withdrawalof.DesignProfessional)
                    {
                        crmTrace.AppendLine("Withdrawal of Deisgn professional initiated Started");
                        ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.ApplicantPerson, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription }, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                        Guid jfID = new Guid();

                        crmTrace.AppendLine("Got all the Job Filing and related Job filings");
                        // Make sure what ever you are checking you are retrieving above

                        if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                        {
                            crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                            for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                            {
                                crmTrace.AppendLine("Updating Job filing:" + i);
                                jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                Entity jobFiling = new Entity();
                                jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                                jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.OnHold));

                                crmTrace.AppendLine("Job filing Guid:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                                service.Update(jobFiling);


                            }

                        }

                    }
                    #endregion

                }
                #endregion

                #region Withdrawal QA Failed Clear Legal Content
                if (withdrawalStatus == (int)WithdrawalStatus.QAFailed)
                {
                    Entity Withdrawal = new Entity();
                    Withdrawal.LogicalName = WithdrawalRequestEntityAttributeName.EntityLogicalName;
                    Withdrawal.Attributes.Add(WithdrawalRequestEntityAttributeName.WithdrawalRequestId, targetEntity.Id);
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.DPCheck] = null;
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.DPDate] = null;
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.DpName] = null;
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.POCheck] = null;
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.PODate] = null;
                    Withdrawal.Attributes[WithdrawalRequestEntityAttributeName.POName] = null;
                    
                    service.Update(Withdrawal);
                }

                #endregion

                #region Withdrawal of Job Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofJobApproved)
                {
                    crmTrace.AppendLine("Withdrawal of Job Approved Started");
                    ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { regardingJobNumber });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription }, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                    Guid jfID = new Guid();

                    crmTrace.AppendLine("Got all the Job Filing and related Job filings");
                    // Make sure what ever you are checking you are retrieving above

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Job filing:" + i);
                            jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            Entity jobFiling = new Entity();
                            jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue(17));
                            crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            service.Update(jobFiling);
                            crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                            //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                        }

                    }

                    crmTrace.AppendLine("All the Job Filing and related Job filings are deactivated");


                } // Withdrawal of Job Approved Ends
                #endregion

                #region Withdrawal of Filing Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofFilingApproved)
                {
                    crmTrace.AppendLine("Withdrawal of Filing Approved Started");
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, 
                       JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription,
                       JobFilingEntityAttributeName.IsPlanApproved, JobFilingEntityAttributeName.IsAfterPermitIssued, JobFilingEntityAttributeName.FilingType};

                    ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                    Guid jfID = new Guid();

                    string JobNumber = jobfilingResponse.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                    string IsplanApproved = jobfilingResponse.Entities[0].GetAttributeValue<bool>(JobFilingEntityAttributeName.IsPlanApproved).ToString();
                    crmTrace.AppendLine("JobNumber: " + JobNumber);

                    // check if There is a PAA and is not approved
                    ConditionExpression PAACondition1 = CreateConditionExpression(JobFilingEntityAttributeName.JobNumberAttributeName, ConditionOperator.Equal, new string[] { JobNumber });
                    ConditionExpression PAACondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingType, ConditionOperator.Equal, new string[] { ((int)FilingType.PAA).ToString() });
                    ConditionExpression PAACondition3 = CreateConditionExpression(JobFilingEntityAttributeName.IsPlanApproved, ConditionOperator.Equal, new string[] { false.ToString() });

                    EntityCollection PAAResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { PAACondition1, PAACondition2, PAACondition3 }, LogicalOperator.And);


                    crmTrace.AppendLine("Got the Job Filing record");
                    // Make sure what ever you are checking you are retrieving above

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Job filing:" + i);
                            jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            Entity jobFiling = new Entity();
                            jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue(17));
                            crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            service.Update(jobFiling);
                            crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                            //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                        }

                    }


                    if (PAAResponse != null && PAAResponse.Entities != null && PAAResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("PAAResponse count: " + PAAResponse.Entities.Count);
                        for (int i = 0; i < PAAResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating PAA Job filing:" + i);
                            jfID = Guid.Parse(PAAResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            Entity jobFiling = new Entity();
                            jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue(17));
                            
                            crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            service.Update(jobFiling);
                            crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                            //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                        }

                    }


                    crmTrace.AppendLine("The Job Filing is deactivated");


                } // Withdrawal of Filing Approved Ends
                #endregion

                #region Withdrawal of Deisgn professional Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofDesignProfessionalApproved)
                {
                    crmTrace.AppendLine("Withdrawal of Deisgn professional Approved Started");
                    ConditionExpression jobfilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    EntityCollection jobfilingResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.ApplicantPerson, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription }, new ConditionExpression[] { jobfilingCondition }, LogicalOperator.And);
                    Guid jfID = new Guid();

                    crmTrace.AppendLine("Got all the Job Filing and related Job filings");
                    // Make sure what ever you are checking you are retrieving above

                    if (jobfilingResponse != null && jobfilingResponse.Entities != null && jobfilingResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Job Filing count: " + jobfilingResponse.Entities.Count);
                        for (int i = 0; i < jobfilingResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Job filing:" + i);
                            jfID = Guid.Parse(jobfilingResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            Entity jobFiling = new Entity();
                            jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                            jobFiling.Attributes[JobFilingEntityAttributeName.ApplicantPerson] = null;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.OnHold));
                            
                            crmTrace.AppendLine("Job filing Guid:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            service.Update(jobFiling);


                        }

                    }

                    crmTrace.AppendLine("All the Job Filing and related Job filings are deactivated");


                } // Withdrawal of Deisgn professional Approved Ends
                #endregion

                #region Withdrawal of Contractor Approved

                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofContractorApproved)
                {
                    crmTrace.AppendLine("withdrawalStatus: WithdrawalofContractorApproved");

                    string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.GotoJobFiling, WorkPermitEntityAttributeName.ApplicantContractor, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.WorkPermitId };
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.ApplicantPerson,
                                                                       JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.Withdrawalof,
                                                                       JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription };
                    //Entity jobfiling = Retrieve(service, new string[] { JobFilingEntityAttributeName.WithdrawalRequester }, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);
                    //EntityReference entityRef = (EntityReference)jobfiling.Attributes[JobFilingEntityAttributeName.WithdrawalRequester]; // identifies the lookup record
                    //var ApplicantGuid = entityRef.Id;

                    Guid ApplicantGuid = ((EntityReference)Tentity[WithdrawalRequestEntityAttributeName.Requester]).Id;
                    Guid WorkPermitGuid = ((EntityReference)Tentity[WithdrawalRequestEntityAttributeName.WorkPermit]).Id;
                    crmTrace.AppendLine("WithdrawalRequester Guid: " + ApplicantGuid);
                    crmTrace.AppendLine("Withdrawal of Contractor Approved Started");
                    //ConditionExpression workpermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    //ConditionExpression workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.ApplicantContractor, ConditionOperator.Equal, new string[] { ApplicantGuid.ToString()
                    ConditionExpression workpermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitId, ConditionOperator.Equal, new string[] { WorkPermitGuid.ToString() });
                    EntityCollection workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition }, LogicalOperator.And);
                    Guid wpID = new Guid();

                    crmTrace.AppendLine("Got all the Workpermits");
                    // Make sure what ever you are checking you are retrieving above
                    if (workpermitResponse == null && workpermitResponse.Entities.Count == 0)
                    {
                        crmTrace.AppendLine("Workpermit Not found ");
                        return;
                    }

                    if (workpermitResponse != null && workpermitResponse.Entities != null && workpermitResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Workpermits count: " + workpermitResponse.Entities.Count);
                        for (int i = 0; i < workpermitResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating workpermit:" + i);
                            wpID = Guid.Parse(workpermitResponse.Entities[i].Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());

                            Entity workpermit = new Entity();
                            workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, wpID);
                            //workpermit.Attributes[WorkPermitEntityAttributeName.ApplicantContractor] = null;
                            workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitInactive));
                            crmTrace.AppendLine("workpermit Guid:" + workpermit.Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());
                            service.Update(workpermit);
                            //DeactivateRecord(crmTrace, WorkPermitEntityAttributeName.EntityLogicalName, wpID, service);

                        }

                    }

                    crmTrace.AppendLine("All the workpermits are Updated");

                    //throw new Exception("aqib");

                } // Withdrawal of Contractor Approved Ends */
                #endregion

                #region Withdrawal of PAA Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofPostAprrovalAmendmentApproved)
                {
                    crmTrace.AppendLine("Withdrawal of PAA Approved Started");
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, 
                       JobFilingEntityAttributeName.Withdrawalof, JobFilingEntityAttributeName.WithdrawalStatus, JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription,
                       JobFilingEntityAttributeName.IsPlanApproved, JobFilingEntityAttributeName.IsAfterPermitIssued, JobFilingEntityAttributeName.FilingType};


                    // check if There is a PAA and is not approved
                    ConditionExpression PAACondition1 = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    ConditionExpression PAACondition2 = CreateConditionExpression(JobFilingEntityAttributeName.FilingType, ConditionOperator.Equal, new string[] { ((int)FilingType.PAA).ToString() });
                    ConditionExpression PAACondition3 = CreateConditionExpression(JobFilingEntityAttributeName.IsPlanApproved, ConditionOperator.Equal, new string[] { false.ToString() });

                    EntityCollection PAAResponse = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { PAACondition1, PAACondition2, PAACondition3 }, LogicalOperator.And);
                    Guid jfID = new Guid();

                    crmTrace.AppendLine("Got the Job Filing record");
                    // Make sure what ever you are checking you are retrieving above


                    if (PAAResponse != null && PAAResponse.Entities != null && PAAResponse.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("PAAResponse count: " + PAAResponse.Entities.Count);
                        for (int i = 0; i < PAAResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating PAA Job filing:" + i);
                            jfID = Guid.Parse(PAAResponse.Entities[i].Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            Entity jobFiling = new Entity();
                            jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jfID);
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue(17));
                            crmTrace.AppendLine("Job filing Status:" + jobFiling.Attributes[JobFilingEntityAttributeName.JobFilingId].ToString());

                            service.Update(jobFiling);
                            crmTrace.AppendLine("Record Guid:" + jfID.ToString());
                            //DeactivateRecord(crmTrace, JobFilingEntityAttributeName.EntityLogicalName, jfID, service);

                        }

                    }
                }
                #endregion

                #region Withdrawal of special inspections approved.
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofSpecialInspectionsApproved)
                {
                    ConditionExpression specialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelation_Withdrawalid, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection specialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelation_Withdrawalid, SpecialInspectionCategoriesAttributeNames.GoToJobFiling }, new ConditionExpression[] { specialInspCondition }, LogicalOperator.And);
                    EntityReferenceCollection specialInsps = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the specialInsps");

                    if (specialInspResponse != null && specialInspResponse.Entities != null && specialInspResponse.Entities.Count > 0)
                    {
                        Guid jfID = new Guid();
                        crmTrace.AppendLine("specialInspResponse count: " + specialInspResponse.Entities.Count);
                        for (int i = 0; i < specialInspResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Special Inspection Record:" + i);
                            jfID = ((EntityReference)specialInspResponse.Entities[i].Attributes[SpecialInspectionCategoriesAttributeNames.GoToJobFiling]).Id;
                            crmTrace.AppendLine("jfID:" + jfID.ToString());
                            Entity SpecialInspEntity = new Entity();
                            SpecialInspEntity.LogicalName = SpecialInspectionCategoriesAttributeNames.EntityLogicalName;
                            crmTrace.AppendLine("specialInspResponse.Entities[i].Id:" + specialInspResponse.Entities[i].Id);
                            SpecialInspEntity.Attributes.Add(SpecialInspectionCategoriesAttributeNames.SpecialInspectionCategoriesId, specialInspResponse.Entities[i].Id);
                            SpecialInspEntity.Attributes.Add(SpecialInspectionCategoriesAttributeNames.Withdrawn, true);
                            crmTrace.AppendLine("SpecialInspEntity Superseded Status:" + SpecialInspEntity.Attributes[SpecialInspectionCategoriesAttributeNames.Withdrawn].ToString());

                            service.Update(SpecialInspEntity);

                            specialInsps.Add(new EntityReference(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, SpecialInspEntity.Id));

                            Entity temp = CreateSpecialInspectionCategorieslist(service, specialInspResponse.Entities[i], jfID, crmTrace);
                            service.Create(temp);
                        }

                    }
                }

                #endregion

                #region Withdrawal of ProgressInspector Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofProgressInspectionsApproved)
                {
                    ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelation_WithdrawalId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelation_WithdrawalId, ProgressInspectionCategoryEntityAttributeName.GoToJobFiling }, new ConditionExpression[] { progressInspCondition }, LogicalOperator.And);
                    EntityReferenceCollection progressInsps = new EntityReferenceCollection();

                    crmTrace.AppendLine("Got all the progressInsps");

                    if (progressInspResponse != null && progressInspResponse.Entities != null && progressInspResponse.Entities.Count > 0)
                    {
                        Guid jfID = new Guid();
                        crmTrace.AppendLine("progressInspResponse count: " + progressInspResponse.Entities.Count);
                        for (int i = 0; i < progressInspResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating Progress Inspection Record:" + i);
                            jfID = ((EntityReference)progressInspResponse.Entities[i].Attributes[ProgressInspectionCategoryEntityAttributeName.GoToJobFiling]).Id;
                            crmTrace.AppendLine("jfID:" + jfID.ToString());
                            Entity ProgressInsp = new Entity();
                            ProgressInsp.LogicalName = ProgressInspectionCategoryEntityAttributeName.EntityLogicalName;
                            crmTrace.AppendLine("progressInspResponse.Entities[i].Id:" + progressInspResponse.Entities[i].Id);
                            ProgressInsp.Attributes.Add(ProgressInspectionCategoryAttributeNames.ProgressInspectionCategoryId, progressInspResponse.Entities[i].Id);
                            ProgressInsp.Attributes.Add(ProgressInspectionCategoryEntityAttributeName.Withdrawn, true);
                            crmTrace.AppendLine("ProgressInsp Superseded Status:" + ProgressInsp.Attributes[ProgressInspectionCategoryEntityAttributeName.Withdrawn].ToString());

                            service.Update(ProgressInsp);

                            progressInsps.Add(new EntityReference(ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, ProgressInsp.Id));

                            Entity temp = CreateProgressInspectionCategorieslist(service, progressInspResponse.Entities[i], jfID, crmTrace);
                            service.Create(temp);
                        }


                    }

                    crmTrace.AppendLine("All the progress Inspection records are associated");


                } //Superseding of ProgressInspector Approved
                #endregion

                #region Withdrawal of Work Type Approved
                if (withdrawalStatus == (int)WithdrawalStatus.WithdrawalofWorkTypeApproved)
                {
                    ConditionExpression workTypeCondition = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.WithdrawalRequestId, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection workTypeResponse = RetrieveMultiple(service, AssociatedWorkTypesEntityAttributeName.EntityLogicalName, new string[] { AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, AssociatedWorkTypesEntityAttributeName.GotoJobFiling, AssociatedWorkTypesEntityAttributeName.WorkTypeStandard }, new ConditionExpression[] { workTypeCondition }, LogicalOperator.And);
                    crmTrace.AppendLine("Got all the Associated WorkTypes");

                    if (workTypeResponse != null && workTypeResponse.Entities != null && workTypeResponse.Entities.Count > 0)
                    {
                        Guid jfID = new Guid();
                        crmTrace.AppendLine("workTypeResponse count: " + workTypeResponse.Entities.Count);
                        for (int i = 0; i < workTypeResponse.Entities.Count; i++)
                        {
                            crmTrace.AppendLine("Updating workTypeResponse Record:" + i);
                            jfID = ((EntityReference)workTypeResponse.Entities[i].Attributes[AssociatedWorkTypesEntityAttributeName.GotoJobFiling]).Id;
                            crmTrace.AppendLine("jfID:" + jfID.ToString());
                            Entity WT = new Entity();
                            WT.LogicalName = AssociatedWorkTypesEntityAttributeName.EntityLogicalName;
                            crmTrace.AppendLine("workTypeResponse.Entities[i].Id:" + workTypeResponse.Entities[i].Id);
                            WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.AssociateWorkTypeId, workTypeResponse.Entities[i].Id);
                            WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, new OptionSetValue((int)CurrentFilingStatus.Withdrawn));
                                                        
                            service.Update(WT);
                            crmTrace.AppendLine("Updated workTypeResponse Record:" + i);

                            #region Inactivate Work Permits
                            crmTrace.AppendLine("Start Inactivcate Work Permits");
                            Guid StandardWTId = ((EntityReference)workTypeResponse.Entities[i].Attributes[AssociatedWorkTypesEntityAttributeName.WorkTypeStandard]).Id;
                            string[] Column_StandardWT = new string[] { StandardWorkTypesEntityAttributeName.Name, StandardWorkTypesEntityAttributeName.ConfigurationName};
                            Entity responseStandardWT = Retrieve(service, Column_StandardWT, StandardWTId, StandardWorkTypesEntityAttributeName.EntityLogicalName);
                            string ConfigName = responseStandardWT.GetAttributeValue<string>(StandardWorkTypesEntityAttributeName.ConfigurationName);
                            crmTrace.AppendLine("ConfigName: " + ConfigName);
                            InactivatePermits(service, crmTrace, ConfigName, jfID);
                            #endregion
                        }
                    }

                    crmTrace.AppendLine("All the associated Work Type are withdrawan");


                } //Withdrawal of Work Type Approved
                #endregion

                //throw new Exception("Withdrawal Debugging");   

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - Withdrawal", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static void InactivatePermits(IOrganizationService service, StringBuilder crmTrace, string ConfigName, Guid JobFilingGuid)
        {
            try 
            {
                string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.GotoJobFiling, WorkPermitEntityAttributeName.ApplicantContractor, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.WorkPermitId };
                    
                ConditionExpression workpermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid.ToString() });
                ConditionExpression workpermitCondition2 = new ConditionExpression();
                ConditionExpression workpermitCondition3 = new ConditionExpression();
                EntityCollection workpermitResponse = new EntityCollection();

                #region Check Config Name and create conditions
                if (ConfigName == "PL")
                {
                    crmTrace.AppendLine("ConfigName: PL");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Plumbing });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2 }, LogicalOperator.And);
                }
                if (ConfigName == "SP")
                {
                    crmTrace.AppendLine("ConfigName: SP");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Sprinkler });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2 }, LogicalOperator.And);
                }
                if (ConfigName == "PL_LG")
                {
                    crmTrace.AppendLine("ConfigName: PL_LG"); 
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Plumbing });
                    workpermitCondition3 = CreateConditionExpression(WorkPermitEntityAttributeName.NoWorkCheckBox, ConditionOperator.Equal, new object[] { true });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2, workpermitCondition3 }, LogicalOperator.And);
                }
                if (ConfigName == "SP_LG")
                {
                    crmTrace.AppendLine("ConfigName: SP_LG");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Sprinkler });
                    workpermitCondition3 = CreateConditionExpression(WorkPermitEntityAttributeName.NoWorkCheckBox, ConditionOperator.Equal, new object[] { true });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2, workpermitCondition3 }, LogicalOperator.And);
                }
                #endregion

                if (workpermitResponse != null && workpermitResponse.Entities != null && workpermitResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Workpermits count: " + workpermitResponse.Entities.Count);
                    for (int i = 0; i < workpermitResponse.Entities.Count; i++)
                    {
                        crmTrace.AppendLine("Updating workpermit:" + i);
                        Guid wpID = Guid.Parse(workpermitResponse.Entities[i].Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());

                        Entity workpermit = new Entity();
                        workpermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                        workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, wpID);
                        //workpermit.Attributes[WorkPermitEntityAttributeName.ApplicantContractor] = null;
                        workpermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitInactive));
                        crmTrace.AppendLine("workpermit Guid:" + workpermit.Attributes[WorkPermitEntityAttributeName.WorkPermitId].ToString());
                        service.Update(workpermit);
                       
                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - InactivatePermits", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        //Deactivate a record
        public static void DeactivateRecord(StringBuilder crmTrace, string entityName, Guid recordId, IOrganizationService organizationService)
        {
            var cols = new ColumnSet(new[] { "statecode", "statuscode" });
            crmTrace.AppendLine(" Deactivate Record Started");
            //Check if it is Active or not
            var entity = organizationService.Retrieve(entityName, recordId, cols);

            if (entity != null && entity.GetAttributeValue<OptionSetValue>("statecode").Value == 0)
            {
                //StateCode = 1 and StatusCode = 2 for deactivating Account or Contact
                SetStateRequest setStateRequest = new SetStateRequest()
                {
                    EntityMoniker = new EntityReference
                    {
                        Id = recordId,
                        LogicalName = entityName,
                    },
                    State = new OptionSetValue(1),
                    Status = new OptionSetValue(2)
                };
                organizationService.Execute(setStateRequest);
            }
        }

        public static Entity CreateSpecialInspectionCategorieslist(IOrganizationService service, Entity currentSpecialInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity SIC = new Entity();
            try
            { ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(SpecialInspectionCategoriesAttributeNames.EntityLogicalName, currentSpecialInspectionCategoriesRecord.Id, columns);


                SIC = EntityExtensions.Clone(response, false);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.GoToJobFiling);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectionCategoriesId);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ICertifyCompleteInspectionsTests);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectoinRelationid);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IWithdrawResponsibility);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.Withdrawn);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspector);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.LicenseType);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IResponsibleName);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ICentifyName);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.DateForIdentificationofResponsibility);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.DateForCertifyCompleteInspections);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.SpecialInspectionAgencyNo);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.IORStatement1);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.FinalIOR);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.InspectionApplicantNameStatement);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ResponsibleStatementDate);
                SIC.Attributes.Remove(SpecialInspectionCategoriesAttributeNames.ResponsibilityofIdentifingRequirement);
                SIC.Attributes.Add(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                SIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("SIC ID :" + SIC.Id.ToString());

                return SIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return SIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateSpecialInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return SIC;
            }
        }

        public static Entity CreateProgressInspectionCategorieslist(IOrganizationService service, Entity currentProgressInspectionCategoriesRecord, Guid ParentJobGuid, StringBuilder crmTrace)
        {
            Entity PIC = new Entity();
            try
            {
                ColumnSet columns = new ColumnSet(true);
                Entity response = service.Retrieve(ProgressInspectionCategoryAttributeNames.EntityLogicalName, currentProgressInspectionCategoriesRecord.Id, columns);


                PIC = EntityExtensions.Clone(response, false);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.GoToJobFiling);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ProgressInspectionCategoryId);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ICertifyCompleteInspectionsTests);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressInspectionsrelationId);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.Withdrawn);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressInspector);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.LicenseType);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IReponsibleCheckName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ICertifyCheckName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IdentificationofResponsibilities);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.CertificateofCompleteInspections);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.IORStatement1);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressInsFinalStatememt);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressResponsibleName);
                PIC.Attributes.Remove(ProgressInspectionCategoryEntityAttributeName.ProgressReponsibleDate);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.IWithdrawResponsibility);
                PIC.Attributes.Remove(ProgressInspectionCategoryAttributeNames.ResponsibilityofIdentifingRequirement);
                PIC.Attributes.Add(ProgressInspectionCategoryAttributeNames.GoToJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, ParentJobGuid));
                PIC.Id = Guid.NewGuid();
                crmTrace.AppendLine("PIC ID :" + PIC.Id.ToString());

                return PIC;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return PIC;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(ParentJobGuid.ToString(), SourceChannel.CRM, "JobFilingWithdrawalHandler - CreateProgressInspectionCategorieslist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return PIC;
            }
        }
        
    } // class ends here
}// namespace ends here
