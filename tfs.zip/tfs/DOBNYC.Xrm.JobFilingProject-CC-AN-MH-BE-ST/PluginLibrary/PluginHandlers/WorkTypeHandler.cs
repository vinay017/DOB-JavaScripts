﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using Microsoft.Xrm.Sdk.Messages;
using System.ServiceModel;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class WorkTypeHandler : PluginHandlerBase
    {
        public static async Task<Boolean> CreateAssociatedWorkTypes_UpdateAsync(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace)
        {

            try
            {
               #region Start Create/Delete WT
                string[] Column_JobFiling = new string[] {JobFilingEntityAttributeName.CurrentFilingStatusAttributeName, JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerCheckBox, JobFilingEntityAttributeName.SprinklerWorkLegalization, JobFilingEntityAttributeName.StandPipeWorkType, JobFilingEntityAttributeName.ANCheckBox, JobFilingEntityAttributeName.CCCheckBox,
                JobFilingEntityAttributeName.Sign, JobFilingEntityAttributeName.SidewalkShed,JobFilingEntityAttributeName.ConstructionFence, JobFilingEntityAttributeName.SupportedScaffold};
                Entity response = Retrieve(service, Column_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);

                int FilingStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value;
                crmTrace.AppendLine("FilingStatus: " + FilingStatus.ToString());

                #region PL
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.PlumbingCheckBox is present ");
                    bool currentPL = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    crmTrace.AppendLine("currentPL: " + currentPL.ToString());
                    bool PreviousPL = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    crmTrace.AppendLine("PreviousPL: " + PreviousPL.ToString());
                    if (currentPL != PreviousPL)
                    {
                        crmTrace.AppendLine("PLCheckBox: " + currentPL.ToString());
                        if (currentPL == true)
                        {
                            crmTrace.AppendLine("Creating PL Associated WT");
                            CreateAssociatedWT(service, response, "PL", crmTrace);
                            crmTrace.AppendLine("Created PL Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting PL Associated WT");
                            DeleteAssociatedWT(service, response, "PL", crmTrace);
                            crmTrace.AppendLine("Deleted PL Associated WT");
                        }
                    }
                }
                #endregion

                #region SP
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SprinklerCheckBox is present ");
                    bool currentSP = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    crmTrace.AppendLine("currentSP: " + currentSP.ToString());
                    bool PreviousSP = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    crmTrace.AppendLine("PreviousSP: " + PreviousSP.ToString());
                    if (currentSP != PreviousSP)
                    {
                        crmTrace.AppendLine("SPCheckBox: " + currentSP.ToString());
                        if (currentSP == true)
                        {
                            crmTrace.AppendLine("Creating SP Associated WT");
                            CreateAssociatedWT(service, response, "SP", crmTrace);
                            crmTrace.AppendLine("Created SP Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SP Associated WT");
                            DeleteAssociatedWT(service, response, "SP", crmTrace);
                            crmTrace.AppendLine("Deleted SP Associated WT");
                        }
                    }
                }
                #endregion

                #region SP_LG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SprinklerWorkLegalization is present ");
                    bool currentSP_LG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                    crmTrace.AppendLine("currentSP_LG: " + currentSP_LG.ToString());
                    bool PreviousSP_LG = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                    crmTrace.AppendLine("PreviousSP_LG: " + PreviousSP_LG.ToString());
                    if (currentSP_LG != PreviousSP_LG)
                    {
                        crmTrace.AppendLine("SP_LGCheckBox: " + currentSP_LG.ToString());
                        if (currentSP_LG == true)
                        {
                            crmTrace.AppendLine("Creating SP_LG Associated WT");
                            CreateAssociatedWT(service, response, "SP_LG", crmTrace);
                            crmTrace.AppendLine("Created SP_LG  Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SP_LG Associated WT");
                            DeleteAssociatedWT(service, response, "SP_LG", crmTrace);
                            crmTrace.AppendLine("Deleted SP_LG Associated WT");
                        }
                    }
                }
                #endregion

                #region PL_LG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.PlumbingWorkLegalization is present ");
                    bool currentPL_LG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                    crmTrace.AppendLine("currentPL_LG: " + currentPL_LG.ToString());
                    bool PreviousPL_LG = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                    crmTrace.AppendLine("PreviousPL_LG: " + PreviousPL_LG.ToString());
                    if (currentPL_LG != PreviousPL_LG)
                    {
                        crmTrace.AppendLine("PL_LGCheckBox: " + currentPL_LG.ToString());
                        if (currentPL_LG == true)
                        {
                            crmTrace.AppendLine("Creating PL_LG Associated WT");
                            CreateAssociatedWT(service, response, "PL_LG", crmTrace);
                            crmTrace.AppendLine("Created PL_LG  Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting PL_LG Associated WT");
                            DeleteAssociatedWT(service, response, "PL_LG", crmTrace);
                            crmTrace.AppendLine("Deleted PL_LG Associated WT");
                        }
                    }
                }
                #endregion

                #region SD
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StandPipeWorkType))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.StandPipeWorkType is present ");
                    bool currentSD = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType);
                    crmTrace.AppendLine("currentSD: " + currentSD.ToString());
                    bool PreviousSD = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType);
                    crmTrace.AppendLine("PreviousSD: " + PreviousSD.ToString());
                    if (currentSD != PreviousSD)
                    {
                        crmTrace.AppendLine("SDCheckBox: " + currentSD.ToString());
                        if (currentSD == true)
                        {
                            crmTrace.AppendLine("Creating SD Associated WT");
                            CreateAssociatedWT(service, response, "SD", crmTrace);
                            crmTrace.AppendLine("Created SD Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SD Associated WT");
                            DeleteAssociatedWT(service, response, "SD", crmTrace);
                            crmTrace.AppendLine("Deleted SD Associated WT");
                        }
                    }
                }
                #endregion

                #region AN
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.ANCheckBox is present ");
                    bool currentAN = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox);
                    crmTrace.AppendLine("currentAN: " + currentAN.ToString());
                    bool PreviousAN = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox);
                    crmTrace.AppendLine("PreviousAN: " + PreviousAN.ToString());
                    if (currentAN != PreviousAN)
                    {
                        crmTrace.AppendLine("ANCheckBox: " + currentAN.ToString());
                        if (currentAN == true)
                        {
                            crmTrace.AppendLine("Creating AN Associated WT");
                            CreateAssociatedWT(service, response, "AN", crmTrace);
                            crmTrace.AppendLine("Created AN Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting AN Associated WT");
                            DeleteAssociatedWT(service, response, "AN", crmTrace);
                            crmTrace.AppendLine("Deleted AN Associated WT");
                        }
                    }
                }
                #endregion

                #region CC
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.CCCheckBox is present ");
                    bool currentCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox);
                    crmTrace.AppendLine("currentCC: " + currentCC.ToString());
                    bool PreviousCC = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox);
                    crmTrace.AppendLine("PreviousCC: " + PreviousCC.ToString());
                    if (currentCC != PreviousCC)
                    {
                        crmTrace.AppendLine("CCCheckBox: " + currentCC.ToString());
                        if (currentCC == true)
                        {
                            crmTrace.AppendLine("Creating CC Associated WT");
                            CreateAssociatedWT(service, response, "CC", crmTrace);
                            crmTrace.AppendLine("Created CC Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting CC Associated WT");
                            DeleteAssociatedWT(service, response, "CC", crmTrace);
                            crmTrace.AppendLine("Deleted CC Associated WT");
                        }
                    }
                }
                #endregion

                #region SF
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SupportedScaffold is present ");
                    bool currentSF = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold);
                    crmTrace.AppendLine("currentSF: " + currentSF.ToString());
                    bool PreviousSF = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold);
                    crmTrace.AppendLine("PreviousSF: " + PreviousSF.ToString());
                    if (currentSF != PreviousSF)
                    {
                        crmTrace.AppendLine("SFCheckBox: " + currentSF.ToString());
                        if (currentSF == true)
                        {
                            crmTrace.AppendLine("Creating SF Associated WT");
                            CreateAssociatedWT(service, response, "SF", crmTrace);
                            crmTrace.AppendLine("Created SF Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SF Associated WT");
                            DeleteAssociatedWT(service, response, "SF", crmTrace);
                            crmTrace.AppendLine("Deleted SF Associated WT");
                        }
                    }
                }
                #endregion

                #region SG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.Sign is present ");
                    bool currentSG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign);
                    crmTrace.AppendLine("currentSG: " + currentSG.ToString());
                    bool PreviousSG = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign);
                    crmTrace.AppendLine("PreviousSG: " + PreviousSG.ToString());
                    if (currentSG != PreviousSG)
                    {
                        crmTrace.AppendLine("SGCheckBox: " + currentSG.ToString());
                        if (currentSG == true)
                        {
                            crmTrace.AppendLine("Creating SG Associated WT");
                            CreateAssociatedWT(service, response, "SG", crmTrace);
                            crmTrace.AppendLine("Created SG Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SG Associated WT");
                            DeleteAssociatedWT(service, response, "SG", crmTrace);
                            crmTrace.AppendLine("Deleted SG Associated WT");
                        }
                    }
                }
                #endregion

                #region FN
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.ConstructionFence is present ");
                    bool currentFN = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence);
                    crmTrace.AppendLine("currentFN: " + currentFN.ToString());
                    bool PreviousFN = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence);
                    crmTrace.AppendLine("PreviousFN: " + PreviousFN.ToString());
                    if (currentFN != PreviousFN)
                    {
                        crmTrace.AppendLine("FNCheckBox: " + currentFN.ToString());
                        if (currentFN == true)
                        {
                            crmTrace.AppendLine("Creating FN Associated WT");
                            CreateAssociatedWT(service, response, "FN", crmTrace);
                            crmTrace.AppendLine("Created FN Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting FN Associated WT");
                            DeleteAssociatedWT(service, response, "FN", crmTrace);
                            crmTrace.AppendLine("Deleted FN Associated WT");
                        }
                    }
                }
                #endregion

                #region SH
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SidewalkShed is present ");
                    bool currentSH = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed);
                    crmTrace.AppendLine("currentSH: " + currentSH.ToString());
                    bool PreviousSH = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed);
                    crmTrace.AppendLine("PreviousSH: " + PreviousSH.ToString());
                    if (currentSH != PreviousSH)
                    {
                        crmTrace.AppendLine("SHCheckBox: " + currentSH.ToString());
                        if (currentSH == true)
                        {
                            crmTrace.AppendLine("Creating SH Associated WT");
                            CreateAssociatedWT(service, response, "SH", crmTrace);
                            crmTrace.AppendLine("Created SH Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting SH Associated WT");
                            DeleteAssociatedWT(service, response, "SH", crmTrace);
                            crmTrace.AppendLine("Deleted SH Associated WT");
                        }
                    }
                }
                #endregion

                #region EL
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.isElectricalWorkType))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SidewalkShed is present ");
                    bool currentEL = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType);
                    crmTrace.AppendLine("currentEL: " + currentEL.ToString());
                    bool PreviousEL = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType);
                    crmTrace.AppendLine("PreviousEL: " + PreviousEL.ToString());
                    if (currentEL != PreviousEL)
                    {
                        crmTrace.AppendLine("ELCheckBox: " + currentEL.ToString());
                        if (currentEL == true)
                        {
                            crmTrace.AppendLine("Creating EL Associated WT");
                            CreateAssociatedWT(service, response, "EL", crmTrace);
                            crmTrace.AppendLine("Created EL Associated WT");
                        }
                        else
                        {
                            crmTrace.AppendLine("Deleting EL Associated WT");
                            DeleteAssociatedWT(service, response, "EL", crmTrace);
                            crmTrace.AppendLine("Deleted EL Associated WT");
                        }
                    }

                }
                #endregion

                #region GC
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.GeneralConstructionWorkType is present ");
                //    bool currentGC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType);
                //    crmTrace.AppendLine("currentGC: " + currentGC.ToString());
                //    bool PreviousGC = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType);
                //    crmTrace.AppendLine("PreviousGC: " + PreviousGC.ToString());
                //    if (currentGC != PreviousGC)
                //    {
                //        crmTrace.AppendLine("GCCheckBox: " + currentGC.ToString());
                //        if (currentGC == true)
                //        {
                //            crmTrace.AppendLine("Creating GC Associated WT");
                //            CreateAssociatedWT(service, response, "GC", crmTrace);
                //            crmTrace.AppendLine("Created GC Associated WT");
                //        }
                //        else
                //        {
                //            crmTrace.AppendLine("Deleting GC Associated WT");
                //            DeleteAssociatedWT(service, response, "GC", crmTrace);
                //            crmTrace.AppendLine("Deleted GC Associated WT");
                //        }
                //    }
                //}
                #endregion

                #region MH
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MechanicalWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.MechanicalWorkType is present ");
                //    bool currentMH = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType);
                //    crmTrace.AppendLine("currentMH: " + currentMH.ToString());
                //    bool PreviousMH = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType);
                //    crmTrace.AppendLine("PreviousMH: " + PreviousMH.ToString());
                //    if (currentMH != PreviousMH)
                //    {
                //        crmTrace.AppendLine("MHCheckBox: " + currentMH.ToString());
                //        if (currentMH == true)
                //        {
                //            crmTrace.AppendLine("Creating MH Associated WT");
                //            CreateAssociatedWT(service, response, "MH", crmTrace);
                //            crmTrace.AppendLine("Created MH Associated WT");
                //        }
                //        else
                //        {
                //            crmTrace.AppendLine("Deleting MH Associated WT");
                //            DeleteAssociatedWT(service, response, "MH", crmTrace);
                //            crmTrace.AppendLine("Deleted MH Associated WT");
                //        }
                //    }
                //}
                #endregion

                #region ST
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StructuralWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.StructuralWorkType is present ");
                //    bool currentST = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralWorkType);
                //    crmTrace.AppendLine("currentST: " + currentST.ToString());
                //    bool PreviousST = preImage.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralWorkType);
                //    crmTrace.AppendLine("PreviousST: " + PreviousST.ToString());
                //    if (currentST != PreviousST)
                //    {
                //        crmTrace.AppendLine("STCheckBox: " + currentST.ToString());
                //        if (currentST == true)
                //        {
                //            crmTrace.AppendLine("Creating ST Associated WT");
                //            CreateAssociatedWT(service, response, "ST", crmTrace);
                //            crmTrace.AppendLine("Created ST Associated WT");
                //        }
                //        else
                //        {
                //            crmTrace.AppendLine("Deleting ST Associated WT");
                //            DeleteAssociatedWT(service, response, "ST", crmTrace);
                //            crmTrace.AppendLine("Deleted ST Associated WT");
                //        }
                //    }
                //}
                #endregion

                #endregion


            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Update", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

            return true;

        }

        public static void CreateAssociatedWorkTypes_Create(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                #region Start Create WT
                
                #region PL
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.PlumbingCheckBox is present ");
                    bool currentPL = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                    crmTrace.AppendLine("currentPL: " + currentPL.ToString());
                        if (currentPL == true)
                        {
                            crmTrace.AppendLine("Creating PL Associated WT");
                            CreateAssociatedWT(service, targetEntity, "PL", crmTrace);
                            crmTrace.AppendLine("Created PL Associated WT");
                        }
                                           
                }
                #endregion

                #region SP
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SprinklerCheckBox is present ");
                    bool currentSP = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                    crmTrace.AppendLine("currentSP: " + currentSP.ToString());
                       if (currentSP == true)
                        {
                            crmTrace.AppendLine("Creating SP Associated WT");
                            CreateAssociatedWT(service, targetEntity, "SP", crmTrace);
                            crmTrace.AppendLine("Created SP Associated WT");
                        }
                }
                #endregion

                #region SP_LG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SprinklerWorkLegalization))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SprinklerWorkLegalization is present ");
                    bool currentSP_LG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                      if (currentSP_LG == true)
                        {
                            crmTrace.AppendLine("Creating SP_LG Associated WT");
                            CreateAssociatedWT(service, targetEntity, "SP_LG", crmTrace);
                            crmTrace.AppendLine("Created SP_LG  Associated WT");
                        }
                }
                #endregion

                #region PL_LG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingWorkLegalization))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.PlumbingWorkLegalization is present ");
                    bool currentPL_LG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                    crmTrace.AppendLine("currentPL_LG: " + currentPL_LG.ToString());
                       if (currentPL_LG == true)
                        {
                            crmTrace.AppendLine("Creating PL_LG Associated WT");
                            CreateAssociatedWT(service, targetEntity, "PL_LG", crmTrace);
                            crmTrace.AppendLine("Created PL_LG  Associated WT");
                        }
                }
                #endregion

                #region SD
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StandPipeWorkType))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.StandPipeWorkType is present ");
                    bool currentSD = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType);
                    crmTrace.AppendLine("currentSD: " + currentSD.ToString());
                    if (currentSD == true)
                    {
                        crmTrace.AppendLine("Creating SD Associated WT");
                        CreateAssociatedWT(service, targetEntity, "SD", crmTrace);
                        crmTrace.AppendLine("Created SD Associated WT");
                    }

                }
                #endregion

                #region AN
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ANCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.ANCheckBox is present ");
                    bool currentAN = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox);
                    crmTrace.AppendLine("currentAN: " + currentAN.ToString());
                    if (currentAN == true)
                    {
                        crmTrace.AppendLine("Creating AN Associated WT");
                        CreateAssociatedWT(service, targetEntity, "AN", crmTrace);
                        crmTrace.AppendLine("Created AN Associated WT");
                    }

                }
                #endregion

                #region CC
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CCCheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.CCCheckBox is present ");
                    bool currentCC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox);
                    crmTrace.AppendLine("currentCC: " + currentCC.ToString());
                    if (currentCC == true)
                    {
                        crmTrace.AppendLine("Creating CC Associated WT");
                        CreateAssociatedWT(service, targetEntity, "CC", crmTrace);
                        crmTrace.AppendLine("Created CC Associated WT");
                    }

                }
                #endregion

                #region SF
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SupportedScaffold))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SupportedScaffold is present ");
                    bool currentSF = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SupportedScaffold);
                    crmTrace.AppendLine("currentSF: " + currentSF.ToString());
                    if (currentSF == true)
                    {
                        crmTrace.AppendLine("Creating SF Associated WT");
                        CreateAssociatedWT(service, targetEntity, "SF", crmTrace);
                        crmTrace.AppendLine("Created SF Associated WT");
                    }

                }
                #endregion

                #region SG
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.Sign))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.Sign is present ");
                    bool currentSG = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.Sign);
                    crmTrace.AppendLine("currentSG: " + currentSG.ToString());
                    if (currentSG == true)
                    {
                        crmTrace.AppendLine("Creating SG Associated WT");
                        CreateAssociatedWT(service, targetEntity, "SG", crmTrace);
                        crmTrace.AppendLine("Created SG Associated WT");
                    }

                }
                #endregion

                #region FN
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ConstructionFence))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.ConstructionFence is present ");
                    bool currentFN = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ConstructionFence);
                    crmTrace.AppendLine("currentFN: " + currentFN.ToString());
                    if (currentFN == true)
                    {
                        crmTrace.AppendLine("Creating FN Associated WT");
                        CreateAssociatedWT(service, targetEntity, "FN", crmTrace);
                        crmTrace.AppendLine("Created FN Associated WT");
                    }

                }
                #endregion

                #region SH
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.SidewalkShed))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.SidewalkShed is present ");
                    bool currentSH= targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.SidewalkShed);
                    crmTrace.AppendLine("currentSH: " + currentSH.ToString());
                    if (currentSH== true)
                    {
                        crmTrace.AppendLine("Creating SHAssociated WT");
                        CreateAssociatedWT(service, targetEntity, "SH", crmTrace);
                        crmTrace.AppendLine("Created SHAssociated WT");
                    }

                }
                #endregion

                #region EL
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.isElectricalWorkType))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.isElectricalWorkType is present ");
                    bool currentEL = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.isElectricalWorkType);
                    crmTrace.AppendLine("currentEL: " + currentEL.ToString());
                    if (currentEL == true)
                    {
                        crmTrace.AppendLine("Creating ELAssociated WT");
                        CreateAssociatedWT(service, targetEntity, "EL", crmTrace);
                        crmTrace.AppendLine("Created ELAssociated WT");
                    }

                }
                #endregion

                #region GC
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.GeneralConstructionWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.GeneralConstructionWorkType is present ");
                //    bool currentGC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.GeneralConstructionWorkType);
                //    crmTrace.AppendLine("currentGC: " + currentGC.ToString());
                //    if (currentGC == true)
                //    {
                //        crmTrace.AppendLine("Creating GC Associated WT");
                //        CreateAssociatedWT(service, targetEntity, "GC", crmTrace);
                //        crmTrace.AppendLine("Created GC Associated WT");
                //    }

                //}
                #endregion

                #region MH
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.MechanicalWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.MechanicalWorkType is present ");
                //    bool currentMH = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.MechanicalWorkType);
                //    crmTrace.AppendLine("currentMH: " + currentMH.ToString());
                //    if (currentMH == true)
                //    {
                //        crmTrace.AppendLine("Creating MH Associated WT");
                //        CreateAssociatedWT(service, targetEntity, "MH", crmTrace);
                //        crmTrace.AppendLine("Created MH Associated WT");
                //    }

                //}
                #endregion

                #region ST
                //if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.StructuralWorkType))
                //{
                //    crmTrace.AppendLine("JobFilingEntityAttributeName.StructuralWorkType is present ");
                //    bool currentST = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.StructuralWorkType);
                //    crmTrace.AppendLine("currentST: " + currentST.ToString());
                //    if (currentST == true)
                //    {
                //        crmTrace.AppendLine("Creating ST Associated WT");
                //        CreateAssociatedWT(service, targetEntity, "ST", crmTrace);
                //        crmTrace.AppendLine("Created ST Associated WT");
                //    }

                //}
                #endregion

                #region PA
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PACheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.StructuralWorkType is present ");
                    bool currentPA = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox);
                    crmTrace.AppendLine("currentPA: " + currentPA.ToString());
                    if (currentPA == true)
                    {
                        crmTrace.AppendLine("Creating PA Associated WT");
                        CreateAssociatedWT(service, targetEntity, "PA", crmTrace);
                        crmTrace.AppendLine("Created PA Associated WT");
                    }

                }
                #endregion

                #region TPA
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.TPACheckBox))
                {
                    crmTrace.AppendLine("JobFilingEntityAttributeName.StructuralWorkType is present ");
                    bool currentTPA = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.TPACheckBox);
                    crmTrace.AppendLine("currentTPA: " + currentTPA.ToString());
                    if (currentTPA == true)
                    {
                        crmTrace.AppendLine("Creating TPA Associated WT");
                        CreateAssociatedWT(service, targetEntity, "TPA", crmTrace);
                        crmTrace.AppendLine("Created TPA Associated WT");
                    }

                }
                #endregion

                #endregion


            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes_Create", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void CreateAssociatedWorkTypes(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            try
            {
                #region Reterive all associated WorkTypes and remove them
                ConditionExpression associatedWTCondition = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection associatedWTResponse = RetrieveMultiple(service, AssociatedWorkTypesEntityAttributeName.EntityLogicalName, new string[] { AssociatedWorkTypesEntityAttributeName.WorkTypeStandard, AssociatedWorkTypesEntityAttributeName.WorkTypeStatus }, new ConditionExpression[] { associatedWTCondition }, LogicalOperator.And);
                crmTrace.AppendLine("associatedWTResponse count:  " + associatedWTResponse.Entities.Count);
                if (associatedWTResponse != null && associatedWTResponse.Entities != null && associatedWTResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Starting to Delete all associated WorkTypes ");
                    DeleteEntityCollection(service, associatedWTResponse, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all associated WorkTypes ");
                }
                #endregion

                #region Start Creating WT
                string[] Column_JobFiling = new string[] { JobFilingEntityAttributeName.CurrentFilingStatusAttributeName, JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerCheckBox, JobFilingEntityAttributeName.SprinklerWorkLegalization, JobFilingEntityAttributeName.StandPipeWorkType, JobFilingEntityAttributeName.ANCheckBox, JobFilingEntityAttributeName.CCCheckBox };
                Entity response = Retrieve(service, Column_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);

                int FilingStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value;
                crmTrace.AppendLine("FilingStatus: " + FilingStatus.ToString());

                bool PLCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                crmTrace.AppendLine("PLCheckBox: " + PLCheckBox.ToString());
                if (PLCheckBox == true)
                {
                    crmTrace.AppendLine("Creating PL Associated WT");
                    CreateAssociatedWT(service, response, "PL", crmTrace);
                    crmTrace.AppendLine("Created PL Associated WT");
                }

                bool SPCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerCheckBox);
                crmTrace.AppendLine("SPCheckBox: " + SPCheckBox.ToString());
                if (SPCheckBox == true)
                {
                    crmTrace.AppendLine("Creating SP Associated WT");
                    CreateAssociatedWT(service, response, "SP", crmTrace);
                    crmTrace.AppendLine("Created SP Associated WT");
                }

                bool SP_LGCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.SprinklerWorkLegalization);
                crmTrace.AppendLine("SP_LGCheckBox: " + SP_LGCheckBox.ToString());
                if (SP_LGCheckBox == true)
                {
                    crmTrace.AppendLine("Creating SP_LG Associated WT");
                    CreateAssociatedWT(service, response, "SP_LG", crmTrace);
                    crmTrace.AppendLine("Created SP_LG  Associated WT");
                }

                bool PL_LGCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingWorkLegalization);
                crmTrace.AppendLine("PL_LGCheckBox: " + PL_LGCheckBox.ToString());
                if (PL_LGCheckBox == true)
                {
                    crmTrace.AppendLine("Creating PL_LG Associated WT");
                    CreateAssociatedWT(service, response, "PL_LG", crmTrace);
                    crmTrace.AppendLine("Created PL_LG  Associated WT");
                }

                bool SDCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.StandPipeWorkType);
                crmTrace.AppendLine("SDCheckBox: " + SDCheckBox.ToString());
                if (SDCheckBox == true)
                {
                    crmTrace.AppendLine("Creating SD Associated WT");
                    CreateAssociatedWT(service, response, "SD", crmTrace);
                    crmTrace.AppendLine("Created SD Associated WT");
                }

                bool ANCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.ANCheckBox);
                crmTrace.AppendLine("ANCheckBox: " + ANCheckBox.ToString());
                if (ANCheckBox == true)
                {
                    crmTrace.AppendLine("Creating AN Associated WT");
                    CreateAssociatedWT(service, response, "AN", crmTrace);
                    crmTrace.AppendLine("Created AN Associated WT");
                }

                bool CCCheckBox = response.GetAttributeValue<bool>(JobFilingEntityAttributeName.CCCheckBox);
                crmTrace.AppendLine("CCCheckBox: " + CCCheckBox.ToString());
                if (CCCheckBox == true)
                {
                    crmTrace.AppendLine("Creating CC Associated WT");
                    CreateAssociatedWT(service, response, "CC", crmTrace);
                    crmTrace.AppendLine("Created CC Associated WT");
                }

                #endregion


            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWorkTypes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void UpdateAssociatedWorkTypes(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, int CurrentFilingStatus)
        {

            try
            {
                #region Reterive all associated WorkTypes and Update them
                ConditionExpression associatedWTCondition = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection associatedWTResponse = RetrieveMultiple(service, AssociatedWorkTypesEntityAttributeName.EntityLogicalName, new string[] { AssociatedWorkTypesEntityAttributeName.WorkTypeStandard, AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, AssociatedWorkTypesEntityAttributeName.GotoJobFiling }, new ConditionExpression[] { associatedWTCondition }, LogicalOperator.And);
                crmTrace.AppendLine("associatedWTResponse count:  " + associatedWTResponse.Entities.Count);
                if (associatedWTResponse != null && associatedWTResponse.Entities != null && associatedWTResponse.Entities.Count > 0)
                {

                    for (int j = 0; j < associatedWTResponse.Entities.Count; j++)  // checks through all the DocumentList records and looks for the record to be deleted.
                    {
                        Entity WT = new Entity();
                        WT.LogicalName = AssociatedWorkTypesEntityAttributeName.EntityLogicalName;
                        crmTrace.AppendLine("associatedWTResponse.Entities[i].Id:" + associatedWTResponse.Entities[j].Id);
                        WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.AssociateWorkTypeId, associatedWTResponse.Entities[j].Id);
                        WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, new OptionSetValue(CurrentFilingStatus));
                        crmTrace.AppendLine("WorkTypeStatus:" + WT.Attributes[AssociatedWorkTypesEntityAttributeName.WorkTypeStatus].ToString());

                        service.Update(WT);
                    } 
                    
                    
                }
                #endregion


            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - UpdateAssociatedWorkTypes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        }

        public static void DeleteEntityCollection(IOrganizationService service, EntityCollection removeList, StringBuilder crmTrace)
        {
            string trackingGuid = Guid.NewGuid().ToString();
            try
            { crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest RemoveRequestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };

                crmTrace.AppendLine(" Request object created");

                // Creates requests for each removeDocumentList record
                crmTrace.AppendLine(" Creating DeleteRequest requests for each removeList record and adding them to Request Object");
                foreach (var entity in removeList.Entities)
                {
                    DeleteRequest deleteRequest = new DeleteRequest { Target = entity.ToEntityReference() };
                    RemoveRequestWithResults.Requests.Add(deleteRequest);
                }
                crmTrace.AppendLine(" DeleteRequest Created requests for each removeList record and added to Request Object");

                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse RemoveResponseWithResults = (ExecuteMultipleResponse)service.Execute(RemoveRequestWithResults);
                foreach (var responseItem in RemoveResponseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Response);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid, SourceChannel.CRM, "WorkTypeHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        } // DeleteEntityCollection Method ends here

        public static void DeleteEntityCollection2(IOrganizationService service, EntityCollection removeList, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Deleting EntityCollection Records");

                foreach (Entity record in removeList.Entities)
                {
                    crmTrace.AppendLine("record.LogicalName: " + record.LogicalName);
                    crmTrace.AppendLine("record.Id: " + record.Id);
                    service.Delete(record.LogicalName, record.Id);
                }

                crmTrace.AppendLine("Done Deleting EntityCollection Records");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog("DeleteEntityCollection", SourceChannel.CRM, "PAAHandler - DeleteEntityCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CreateAssociatedWT(IOrganizationService service, Entity JobFiling, String configName, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("configName: " + configName);
                ConditionExpression StandardWTCondition = CreateConditionExpression(StandardWorkTypesEntityAttributeName.ConfigurationName, ConditionOperator.Equal, new string[] { configName });
                EntityCollection StandardWTResponse = RetrieveMultiple(service, StandardWorkTypesEntityAttributeName.EntityLogicalName, new string[] { StandardWorkTypesEntityAttributeName.Name }, new ConditionExpression[] { StandardWTCondition }, LogicalOperator.And);
                Entity WT = new Entity();
                crmTrace.AppendLine("StandardWTResponse: " + StandardWTResponse.Entities.Count);
                
                if (StandardWTResponse != null && StandardWTResponse.Entities != null && StandardWTResponse.Entities.Count > 0)
                {
                    Guid StandardWTGuid = StandardWTResponse.Entities[0].Id;
                    crmTrace.AppendLine("StandardWTGuid: " + StandardWTGuid.ToString());
                    int FilingStatus = JobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.CurrentFilingStatusAttributeName).Value;
                    crmTrace.AppendLine("FilingStatus: " + FilingStatus.ToString());
                    WT.LogicalName = AssociatedWorkTypesEntityAttributeName.EntityLogicalName;
                    WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.WorkTypeStandard, new EntityReference(StandardWorkTypesEntityAttributeName.EntityLogicalName, StandardWTGuid));
                    WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, new OptionSetValue(FilingStatus));
                    WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.GotoJobFiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFiling.Id));
                    WT.Attributes.Add(AssociatedWorkTypesEntityAttributeName.Name, configName);

                    crmTrace.AppendLine("Creating Associated WT");
                    service.Create(WT);
                    crmTrace.AppendLine("Created Associated WT");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - CreateAssociatedWT", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void DeleteAssociatedWT(IOrganizationService service, Entity JobFiling, String configName, StringBuilder crmTrace)
        {
            try
            {
                ConditionExpression StandardWTCondition = CreateConditionExpression(StandardWorkTypesEntityAttributeName.ConfigurationName, ConditionOperator.Equal, new string[] { configName });
                EntityCollection StandardWTResponse = RetrieveMultiple(service, StandardWorkTypesEntityAttributeName.EntityLogicalName, new string[] { StandardWorkTypesEntityAttributeName.Name }, new ConditionExpression[] { StandardWTCondition }, LogicalOperator.And);
                Guid StandardWTGuid = StandardWTResponse.Entities[0].Id;
                crmTrace.AppendLine("StandardWTGuid: " + StandardWTGuid.ToString());

                ConditionExpression associatedWTCondition1 = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { JobFiling.Id.ToString() });
                ConditionExpression associatedWTCondition2 = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.WorkTypeStandard, ConditionOperator.Equal, new string[] { StandardWTGuid.ToString() });
                EntityCollection associatedWTResponse = RetrieveMultiple(service, AssociatedWorkTypesEntityAttributeName.EntityLogicalName, new string[] { AssociatedWorkTypesEntityAttributeName.WorkTypeStandard, AssociatedWorkTypesEntityAttributeName.WorkTypeStatus }, new ConditionExpression[] { associatedWTCondition1, associatedWTCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("associatedWTResponse Count: " + associatedWTResponse.Entities.Count);
                if (associatedWTResponse != null && associatedWTResponse.Entities != null && associatedWTResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Starting to Delete all associated WorkTypes ");
                    DeleteEntityCollection2(service, associatedWTResponse, crmTrace);
                    crmTrace.AppendLine("Retrieved and Deleted all associated WorkTypes ");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFiling.Id.ToString(), SourceChannel.CRM, "WorkTypeHandler - DeleteAssociatedWT", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

    } // class ends here
}// namespace ends here
