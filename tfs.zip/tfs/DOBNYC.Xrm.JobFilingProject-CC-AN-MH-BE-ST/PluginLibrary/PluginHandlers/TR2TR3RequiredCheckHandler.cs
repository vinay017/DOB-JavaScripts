﻿using DOB.Logging;
using DOBNYC.XRM.JobFiling.Common;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class TR2TR3RequiredCheckHandler : PluginHandlerBase
    {
        #region Delete TR2 TR3 Records if not required
        public static void DeleteTR2TR3Records(IOrganizationService service, string jobFilingGuid, StringBuilder crmTrace, bool deleteTR2, bool deleteTR3)
        {
            crmTrace.AppendLine("DeleteTR2TR3Records: Start");
            try
            {
                #region TR2 Technical Report deletion
                if (deleteTR2)
                {
                    crmTrace.AppendLine("Deleting TR2 Technical Report record - Start");
                    ConditionExpression TR2Condition = CreateConditionExpression(TR2TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid });
                    EntityCollection TR2Response = RetrieveMultiple(service, TR2TechnicalReport.EntityLogicalName, new string[] { TR2TechnicalReport.Name }, new ConditionExpression[] { TR2Condition }, LogicalOperator.And);

                    crmTrace.AppendLine("TR2Response.Entities.Count: " + TR2Response.Entities.Count);

                    if (TR2Response != null && TR2Response.Entities.Count > 0)
                    {
                        foreach (Entity TR2Record in TR2Response.Entities)
                        {
                            crmTrace.AppendLine("TR2Record.LogicalName to delete: " + TR2Record.LogicalName);
                            service.Delete(TR2Record.LogicalName, TR2Record.Id);
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("No TR2 Technical Report records to delete.");
                    }
                    crmTrace.AppendLine("Deleting TR2 Technical Report record - End");

                }
                #endregion

                #region TR3 Technical Report deletion
                if (deleteTR3)
                {
                    #region Delete TR3 Technical Reports
                    crmTrace.AppendLine("Deleting TR3 Technical Report record - End");
                    ConditionExpression TR3Condition = CreateConditionExpression(TR3TechnicalReport.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid });
                    EntityCollection TR3Response = RetrieveMultiple(service, TR3TechnicalReport.EntityLogicalName, new string[] { TR3TechnicalReport.Name }, new ConditionExpression[] { TR3Condition }, LogicalOperator.And);

                    crmTrace.AppendLine("TR3Response.Entities.Count: " + TR3Response.Entities.Count);

                    if (TR3Response != null && TR3Response.Entities.Count > 0)
                    {
                        foreach (Entity TR3Record in TR3Response.Entities)
                        {
                            crmTrace.AppendLine("TR3Record.LogicalName to delete: " + TR3Record.LogicalName);
                            service.Delete(TR3Record.LogicalName, TR3Record.Id);
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("No TR3 records to delete.");
                    }
                    crmTrace.AppendLine("Deleting TR3 Technical Report record - End");
                    #endregion

                    #region Delete TR3 Directors
                    crmTrace.AppendLine("Deleting TR3 Technical Report record - End");
                    ConditionExpression TR3DirectorCondition = CreateConditionExpression(TR3Director.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid });
                    EntityCollection TR3DirectorResponse = RetrieveMultiple(service, TR3Director.EntityLogicalName, new string[] { TR3Director.Name }, new ConditionExpression[] { TR3DirectorCondition }, LogicalOperator.And);

                    crmTrace.AppendLine("TR3DirectorResponse.Entities.Count: " + TR3DirectorResponse.Entities.Count);

                    if (TR3DirectorResponse != null && TR3DirectorResponse.Entities.Count > 0)
                    {
                        foreach (Entity TR3DirectorRecord in TR3DirectorResponse.Entities)
                        {
                            crmTrace.AppendLine("TR3DirectorRecord.LogicalName to delete: " + TR3DirectorRecord.LogicalName);
                            service.Delete(TR3DirectorRecord.LogicalName, TR3DirectorRecord.Id);
                        }
                    }
                    else
                    {
                        crmTrace.AppendLine("No TR3 Director records to delete.");
                    }
                    crmTrace.AppendLine("Deleting TR3 Director Record - End");
                    #endregion
                }
                #endregion
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jobFilingGuid, SourceChannel.CRM, "TR2TR3RequiredCheckHandler - DeleteTR2TR3Records", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
        #endregion
    }
}
