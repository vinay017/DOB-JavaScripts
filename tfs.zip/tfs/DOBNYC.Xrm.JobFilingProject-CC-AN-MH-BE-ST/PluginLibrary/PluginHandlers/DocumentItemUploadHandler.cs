﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using System.Globalization;
using Microsoft.Xrm.Sdk.Messages;
using DOB.Logging;
using System.ServiceModel;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk.Messages;


namespace DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers
{
    public class DocumentItemUploadHandler : PluginHandlerBase
    {

        public static async Task<Boolean> CreateRequiredItemstoJobFiling(IOrganizationService service, Entity targetEntity, Entity PreImage, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling started!");
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { JobFilingEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });

                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldType, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.OtherfieldMappings },
                    new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                //Select FieldMapping from DocumentsRequiredConfigurationsEntity where EntitySchema = JobFilingEntityAttributeName.EntityLogicalName
                EntityCollection documentList = new EntityCollection();
                EntityCollection removeDocumentList = new EntityCollection();


                crmTrace.AppendLine("CreateRequiredItemstoJobFiling started! M1");
                #region Preliminary Commissioning Report Certification
                bool PLCheckBox = false;
                bool ProfCert = false;
                int BuildingType = 1;
                bool ComplianceNYCEE = false;
                bool RequiresPCRC = false;
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PlumbingCheckBox))
                    PLCheckBox = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PlumbingCheckBox);
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.ProfessionalCertificate))
                    ProfCert = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.BuildingType))
                    BuildingType = targetEntity.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.BuildingType).Value;
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.CompliacnewiththeNYCECC))
                    ComplianceNYCEE = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.CompliacnewiththeNYCECC);
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName))
                    RequiresPCRC = targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.DesignApplicantsStatementsandSignaturesECAAttributeName);
                crmTrace.AppendLine("PLCheckBox: " + PLCheckBox.ToString());
                crmTrace.AppendLine("ProfCert: " + ProfCert.ToString());
                crmTrace.AppendLine("BuildingType: " + BuildingType.ToString());
                crmTrace.AppendLine("ComplianceNYCEE: " + ComplianceNYCEE.ToString());
                crmTrace.AppendLine("RequiresPCRC: " + RequiresPCRC.ToString());


                if ((PLCheckBox == true && ProfCert == true && ComplianceNYCEE == true && RequiresPCRC == true) && (BuildingType == 3 || BuildingType == 4))
                {
                    crmTrace.AppendLine("Start PCRC -  Required ");

                    string PCRC = "PRELIMINARY COMMISSIONING REPORT CERTIFICATION";
                    ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { PCRC });
                    ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);
                    Entity documentType = new Entity();
                    crmTrace.AppendLine("documentTypeResponse countL " + documentTypeResponse.Entities.Count);
                    if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        documentType = (Entity)documentTypeResponse.Entities[0];
                    crmTrace.AppendLine("documentTypeGuid" + documentType.Id.ToString());
                    bool PCRCalreadyExisits = CheckDocumentAlreadyExists(service, targetEntity, documentType.Id);
                    if (PCRCalreadyExisits == false)
                    {
                        CreatePCRC(service, targetEntity.Id, documentType, crmTrace);
                        crmTrace.AppendLine("PCRC created ");
                    }
                }
                else
                {
                    crmTrace.AppendLine("PRELIMINARY COMMISSIONING REPORT CERTIFICATION is not required");
                    string PCRC = "PRELIMINARY COMMISSIONING REPORT CERTIFICATION";
                    ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { PCRC });
                    ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);
                    Entity documentType = new Entity();

                    if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                        documentType = (Entity)documentTypeResponse.Entities[0];
                    Guid documentTypeGuid = documentType.Id;
                    crmTrace.AppendLine("documentTypeGuid" + documentTypeGuid.ToString());
                    crmTrace.AppendLine("Get the records from DocumentList where Job filing is current and have Document Name equal to documentTypeGuid");
                    // Get all the Document List records regarding this job filing
                    ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                    EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition }, LogicalOperator.And);
                    crmTrace.AppendLine("documentListResponse count" + documentListResponse.Entities.Count);
                    for (int j = 0; j < documentListResponse.Entities.Count; j++)  // checks through all the DocumentList records and looks for the record to be deleted.
                    {
                        Entity recordDocumentList = (Entity)documentListResponse.Entities[j];
                        Guid recordGuid = documentListResponse.Entities[j].Id;
                        // Get Guid of Document Name in each record
                        Guid documentNameId = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Id;
                        crmTrace.AppendLine("documentNameId" + documentNameId.ToString());
                        if (documentNameId == documentTypeGuid)
                        {
                            crmTrace.AppendLine("documentNameId == documentTypeGuid");
                            removeDocumentList.Entities.Add(recordDocumentList);  // adds the record to removeDocumentList collection
                        }
                    }

                }

                #endregion

                #region Configured Document Population
                crmTrace.AppendLine("Initialized documentRequiredConfigurationsCondition FieldMapping Condition Expression");
                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    #region GetAssociated Work Types
                    if(context.MessageName == MessageName.Update)
                    {
                        Task<bool> getWorkTypes =  WorkTypeHandler.CreateAssociatedWorkTypes_UpdateAsync(service, targetEntity, PreImage, crmTrace);
                        bool iscompleted = await getWorkTypes;
                    }
                    
                    string fetch = string.Format(FetchXml.GetAssociatedWorkTypes, targetEntity.Id.ToString());
                    crmTrace.AppendLine("fetch: " + fetch);
                    EntityCollection wt_response = service.RetrieveMultiple(new FetchExpression(fetch));
                    crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                    #endregion

                    #region Check Filing Type
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName };
                    Entity jfresponse = Retrieve(service, ColumnNames_JobFiling, targetEntity.Id, JobFilingEntityAttributeName.EntityLogicalName);
                    int filingType = jfresponse.Contains(JobFilingEntityAttributeName.FilingType) ? jfresponse.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value : 1;
                    #endregion

                    #region Looping document configs
                    for (int i = 0; i < documentRequiredConfigurationsResponse.Entities.Count; i++)  // check if target entity contains Field mapping (schema name of the field that requires doc)
                    {
                        string fieldType = documentRequiredConfigurationsResponse.Entities[i].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldType].ToString();
                        string fieldName = documentRequiredConfigurationsResponse.Entities[i].GetAttributeValue<string>(DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping);

                        if (targetEntity.Contains(fieldName)) // check if target entity contains Field mapping (schema name of the field that requires doc)
                        {
                            //check if the required field value/ boolean is selected for the document to be uploaded. The required field value is already in Document Required config
                            //Type t = targetEntity.Attributes[(documentRequiredConfigurationsResponse.Entities[i]).ToString()].GetType();

                           string jobFilingOptionSetValue = string.Empty;
                            string pre_jobFilingOptionSetValue = string.Empty;
                            string[] OtherFieldMappings;
                            string SchemaNames = string.Empty;
                            crmTrace.AppendLine("documentRequiredConfigurations field Name: " + fieldName);
                            crmTrace.AppendLine("documentRequiredConfigurations field type: " + fieldType);

                            #region OptionSet
                            if (fieldType == FieldType.OptionSet)
                            {
                                jobFilingOptionSetValue = targetEntity.GetAttributeValue<OptionSetValue>(fieldName).Value.ToString();
                                pre_jobFilingOptionSetValue = PreImage.Contains(fieldName) ? PreImage.GetAttributeValue<OptionSetValue>(fieldName).Value.ToString() : string.Empty;

                            }
                            #endregion

                            #region SingleLineofText
                            if (fieldType == FieldType.SingleLineofText)
                            {
                                crmTrace.AppendLine("value: " + targetEntity.GetAttributeValue<string>(fieldName));
                                jobFilingOptionSetValue = targetEntity.GetAttributeValue<string>(fieldName);
                                pre_jobFilingOptionSetValue = PreImage.Contains(fieldName) ? PreImage.GetAttributeValue<string>(fieldName) : string.Empty;
                                if (!string.IsNullOrEmpty(jobFilingOptionSetValue))
                                    jobFilingOptionSetValue = FieldType.SingleLineofText;

                            }
                            #endregion

                            #region Text
                            if (fieldType == FieldType.Text)
                            {
                                crmTrace.AppendLine("value: " + targetEntity.GetAttributeValue<string>(fieldName));
                                jobFilingOptionSetValue = targetEntity.GetAttributeValue<string>(fieldName);
                                pre_jobFilingOptionSetValue = PreImage.Contains(fieldName) ? PreImage.GetAttributeValue<string>(fieldName) : string.Empty;
                                if (string.IsNullOrEmpty(jobFilingOptionSetValue))
                                    jobFilingOptionSetValue = FieldType.SingleLineofText;

                            }
                            #endregion

                            #region TwoOptions

                            if (fieldType == FieldType.TwoOptions)
                            {
                                jobFilingOptionSetValue = targetEntity.GetAttributeValue<bool>(fieldName).ToString();
                                pre_jobFilingOptionSetValue = PreImage.Contains(fieldName) ? PreImage.GetAttributeValue<bool>(fieldName).ToString() : string.Empty;
                               
                                if (documentRequiredConfigurationsResponse.Entities[i].Attributes.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.OtherfieldMappings))
                                {
                                    if (documentRequiredConfigurationsResponse.Entities[i].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.OtherfieldMappings] != null)
                                        SchemaNames = documentRequiredConfigurationsResponse.Entities[i].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.OtherfieldMappings].ToString();
                                }


                                crmTrace.AppendLine("jobFilingOptionSetValue " + jobFilingOptionSetValue);

                                if (!string.IsNullOrEmpty(SchemaNames))
                                {
                                    crmTrace.AppendLine("SchemaNames " + SchemaNames);
                                    bool value;

                                    if (SchemaNames.Contains(";"))
                                    {
                                        OtherFieldMappings = SchemaNames.Split(';');

                                    }
                                    else
                                        OtherFieldMappings = new string[] { SchemaNames };


                                    foreach (var Field in OtherFieldMappings)
                                    {

                                        value = targetEntity.GetAttributeValue<bool>(Field);

                                        crmTrace.AppendLine("Field " + Field + value);

                                        if (value)
                                        {

                                            jobFilingOptionSetValue = value.ToString();
                                            pre_jobFilingOptionSetValue = PreImage.Contains(Field) ? PreImage.GetAttributeValue<bool>(Field).ToString() : string.Empty;

                                        }
                                    }
                                }


                            }
                            #endregion

                            string docReqConfigOptionSet = documentRequiredConfigurationsResponse.Entities[i].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();


                            crmTrace.AppendLine("FieldValue: " + jobFilingOptionSetValue);
                            crmTrace.AppendLine("ConfigValue: " + docReqConfigOptionSet);
                            crmTrace.AppendLine("pre_jobFilingOptionSetValue: " + pre_jobFilingOptionSetValue);

                            crmTrace.AppendLine("context.MessageName: " + context.MessageName);
                            if (jobFilingOptionSetValue.Contains(docReqConfigOptionSet))
                            {
                                #region Check if PreImage value and target value is different
                                if ((context.MessageName == MessageName.Update && jobFilingOptionSetValue != pre_jobFilingOptionSetValue) || context.MessageName == MessageName.Create)
                                {
                                    crmTrace.AppendLine("FieldValue is equal to ConfigValue");
                                    Entity entity = (Entity)documentRequiredConfigurationsResponse.Entities[i];
                                    Guid documentTypeGuid = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                    string documentTypeName = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Name;

                                    crmTrace.AppendLine("documentTypeGuid: " + documentTypeGuid.ToString());
                                    crmTrace.AppendLine("documentTypeName: " + documentTypeName);
                                    // need to check if document is already there!!//
                                    bool alreadyExisits = false;
                                    if (context.MessageName == MessageName.Update)
                                        alreadyExisits = CheckDocumentAlreadyExists(service, targetEntity, documentTypeGuid);
                                    if (alreadyExisits == false)
                                    {
                                        Entity tempDocList = CreateDocumentlist(service, targetEntity, wt_response, filingType, documentTypeGuid, JobFilingEntityAttributeName.EntityLogicalName, crmTrace, jfresponse);
                                        if (tempDocList.LogicalName != null)
                                            service.Create(tempDocList);
                                    }
                                }
                                #endregion
                            }
                            else
                            {
                                if (context.MessageName == MessageName.Update)
                                {
                                    crmTrace.AppendLine("jobFilingOptionSetValue is not equal to docReqConfigOptionSet");
                                    Entity entity = (Entity)documentRequiredConfigurationsResponse.Entities[i];
                                    Guid documentTypeGuid = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                    string documentTypeName = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Name;
                                    crmTrace.AppendLine("documentTypeGuid" + documentTypeGuid.ToString());
                                    crmTrace.AppendLine("documentTypeName: " + documentTypeName);
                                    crmTrace.AppendLine("Get the records from DocumentList where Job filing is current and have Document Name equal to : " + documentTypeName);
                                    // Get all the Document List records regarding this job filing
                                    ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                                    EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition }, LogicalOperator.And);
                                    for (int j = 0; j < documentListResponse.Entities.Count; j++)  // checks through all the DocumentList records and looks for the record to be deleted.
                                    {
                                        Entity recordDocumentList = (Entity)documentListResponse.Entities[j];
                                        Guid recordGuid = documentListResponse.Entities[j].Id;
                                        // Get Guid of Document Name in each record
                                        Guid documentNameId = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Id;

                                        if (documentNameId == documentTypeGuid)
                                        {
                                            removeDocumentList.Entities.Add(recordDocumentList);  // adds the record to removeDocumentList collection
                                        }
                                    }
                                }

                            }

                        }  // if ends here

                    }  // for ends here

                    #endregion

                    #region Check and delete documents
                    if (removeDocumentList != null && removeDocumentList.Entities != null && removeDocumentList.Entities.Count > 0)  //Checking if removeDocumentList contains some records
                    {
                        crmTrace.AppendLine("Started DeleteremoveDocumentListCollection Method");
                        DeleteRemoveDocumentListCollection(service, removeDocumentList, context, crmTrace);
                        crmTrace.AppendLine("Completed DeleteremoveDocumentListCollection Method");
                    }
                    #endregion

                }  // if ends here

                #endregion

                //throw new Exception("Document Upload testing");

                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - test", null, crmTrace.ToString(), null, null);
            }  // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            return true;


        }  // CreateRequiredItemstoJobFiling Method ends here

        public static void CreateRequiredItemstoJobFiling_ProgressInspection(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ProgressInspection started!");

                // Delete all the document list records for current jobfilling created due to ProgressInspection entity

                ConditionExpression documentListCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.CreatedDueto, ConditionOperator.Equal, new string[] { ProgressInspectionCategoryEntityAttributeName.EntityLogicalName });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition1, documentListCondition2 }, LogicalOperator.And);
                //DeleteRemoveDocumentListCollection(service, documentListResponse, context, crmTrace);
                crmTrace.AppendLine("Deleted all the document list records for current jobfilling created due to ProgressInspection entity");

                // Get all the configurations for Progress Inspection Catagory entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ProgressInspectionCategoryEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldType, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType },
                    new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                crmTrace.AppendLine("Got all the configurations for Progress Inspection Catagory entity");

                crmTrace.AppendLine("Get all the Progress Inspection Catagory entity records for current job filing (target entity)");
                ConditionExpression progressInspectionRecordsCondition = CreateConditionExpression(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection progressInspectionRecordsResponse = RetrieveMultiple(service, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, new string[] { ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement }, new ConditionExpression[] { progressInspectionRecordsCondition }, LogicalOperator.And);
                crmTrace.AppendLine("progressInspectionRecordsResponse count: " + progressInspectionRecordsResponse.Entities.Count);
                EntityCollection documentList = new EntityCollection();


                if (progressInspectionRecordsResponse != null && progressInspectionRecordsResponse.Entities != null && progressInspectionRecordsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    for (int i = 0; i < progressInspectionRecordsResponse.Entities.Count; i++)  // check if Progress Inspection Catagory entity contains Field mapping (schema name of the field that requires doc)
                    {
                        Entity entity = (Entity)progressInspectionRecordsResponse.Entities[i];
                        string inspectionComponentGuid = ((EntityReference)entity[ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement]).Id.ToString().ToUpper();
                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();

                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("inspectionComponentGuid: " + inspectionComponentGuid);
                            crmTrace.AppendLine("fieldValueGuid: " + fieldValueGuid);
                            if (inspectionComponentGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("inspectionComponentGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                bool alreadyExisits = CheckDocumentAlreadyExists(service, targetEntity, documentTypeGuid);
                                if (alreadyExisits == true)
                                { return; }

                                if (alreadyExisits == false)
                                {
                                    //Entity tempDocList = CreateDocumentlist(service, targetEntity, documentTypeGuid, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, crmTrace);
                                    //if (tempDocList.LogicalName != null)
                                    //    documentList.Entities.Add(tempDocList);//.Add(new EntityReference(DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, documentRequiredConfigurationsResponse.Entities[i].Id));
                                    //crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");
                                }

                            } // if ends here

                        } // for ends here

                    } // for ends here

                    crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                    CreateDocumentListCollection(service, documentList, context, crmTrace);

                    crmTrace.AppendLine("Completed CreateDocumentListCollection Method");


                } // if ends here

                //throw new Exception("aqib");
            }  // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }



        } // CreateRequiredItemstoJobFiling_ProgressInspection Method Ends here

        public static void CreateRequiredItemstoJobFiling_ProgressInspection2(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ProgressInspection2 started!");

                // Get all the configurations for Progress Inspection Catagory entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ProgressInspectionCategoryEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldType, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType },
                    new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                crmTrace.AppendLine("Got all the configurations for Progress Inspection Catagory entity");

                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    if (targetEntity.Attributes.Contains(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement) && targetEntity.Attributes.Contains(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling))
                    {
                        string inspectionComponentGuid = ((EntityReference)targetEntity[ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement]).Id.ToString().ToUpper();
                        string JobFilingGuid = ((EntityReference)targetEntity[ProgressInspectionCategoryEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();

                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();

                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("inspectionComponentGuid: " + inspectionComponentGuid);
                            crmTrace.AppendLine("fieldValueGuid: " + fieldValueGuid);
                            if (inspectionComponentGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("inspectionComponentGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                bool alreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentTypeGuid);
                                if (alreadyExisits == true)
                                { return; }

                                if (alreadyExisits == false)
                                {
                                    Entity tempDocList = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), documentTypeGuid, ProgressInspectionCategoryEntityAttributeName.EntityLogicalName, crmTrace);
                                    //documentList.Entities.Add(tempDocList); //.Add(new EntityReference(DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, documentRequiredConfigurationsResponse.Entities[i].Id));
                                    if (tempDocList.LogicalName != null)
                                        service.Create(tempDocList);
                                    crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");
                                }

                            } // if ends here

                        } // for ends here

                    }




                    //crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                    //CreateDocumentListCollection(service, documentList, context, crmTrace);

                    //crmTrace.AppendLine("Completed CreateDocumentListCollection Method");


                } // if ends here

                //throw new Exception("aqib");
            }  // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ProgressInspection2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ProgressInspection Method Ends here

        public static void DeleteRequiredItemstoJobFiling_ProgressInspection(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("DeleteRequiredItemstoJobFiling_ProgressInspection started!");

                // Get all the configurations for Progress Inspection Catagory entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ProgressInspectionCategoryEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldType, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType },
                    new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                crmTrace.AppendLine("Got all the configurations for Progress Inspection Catagory entity");

                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    if (targetEntity.Attributes.Contains(ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement) && targetEntity.Attributes.Contains(ProgressInspectionCategoryEntityAttributeName.GoToJobFiling))
                    {
                        string inspectionComponentGuid = ((EntityReference)targetEntity[ProgressInspectionCategoryEntityAttributeName.IdentificationofRequirement]).Id.ToString().ToUpper();
                        string JobFilingGuid = ((EntityReference)targetEntity[ProgressInspectionCategoryEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();

                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();

                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("inspectionComponentGuid: " + inspectionComponentGuid);
                            crmTrace.AppendLine("fieldValueGuid: " + fieldValueGuid);
                            if (inspectionComponentGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("inspectionComponentGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                CheckandDeleteIfDocumentExists(service, JobFilingGuid, documentTypeGuid, crmTrace);

                            } // if ends here

                        } // for ends here

                    }

                } // if ends here

                //throw new Exception("aqib");
            }  // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ProgressInspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // DeleteRequiredItemstoJobFiling_ProgressInspection Method Ends here

        

        public static void CreateRequiredItemstoJobFiling_ScopeofWork(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ScopeofWork started!");

                // Delete all the document list records for current jobfilling created due to ScopeofWork entity

                ConditionExpression documentListCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.CreatedDueto, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });

                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition1, documentListCondition2 }, LogicalOperator.And);
                //DeleteRemoveDocumentListCollection(service, documentListResponse, context, crmTrace);
                //crmTrace.AppendLine("Deleted all the document list records for current jobfilling created due to ScopeofWork entity");

                // Get all the configurations for ScopeofWork entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for ScopeofWork entity");

                crmTrace.AppendLine("Get all the ScopeofWork entity records for current job filing (target entity)");
                ConditionExpression ScopeofWorkRecordsCondition = CreateConditionExpression(ScopeOfWorkEntityAttributeName.GoToJobFiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection ScopeofWorkRecordsResponse = RetrieveMultiple(service, ScopeOfWorkEntityAttributeName.EntityLogicalName, new string[] { ScopeOfWorkEntityAttributeName.System, ScopeOfWorkEntityAttributeName.WorkType }, new ConditionExpression[] { ScopeofWorkRecordsCondition }, LogicalOperator.And);
                EntityCollection documentList = new EntityCollection();

                if (ScopeofWorkRecordsResponse != null && ScopeofWorkRecordsResponse.Entities != null && ScopeofWorkRecordsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    for (int i = 0; i < ScopeofWorkRecordsResponse.Entities.Count; i++)
                    {
                        Entity entity = (Entity)ScopeofWorkRecordsResponse.Entities[i];
                        string systemGuid = ((EntityReference)entity[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();
                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("systemGuid: " + systemGuid);
                            if (systemGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("systemGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                                // check if the documentList already contains a document with this guid.
                                bool alreadyExisits = CheckDocumentAlreadyExists(service, targetEntity, documentTypeGuid);
                                if (alreadyExisits == true)
                                { return; }

                                if (alreadyExisits == false)
                                {
                                    //Entity tempDocList = CreateDocumentlist(service, targetEntity, documentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                    //if (tempDocList.LogicalName != null)
                                    //{
                                    //    bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                    //    if (isalreadyincluded == false)// added
                                    //        documentList.Entities.Add(tempDocList);
                                    //}

                                }
                                crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("SecondDocumentType is there!");
                                        Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                        crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                        // check if the documentList already contains a document with this guid.
                                        bool alreadyExisits2 = CheckDocumentAlreadyExists(service, targetEntity, secondDocumentTypeGuid);
                                        crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                        if (alreadyExisits2 == true)
                                        { return; }

                                        if (alreadyExisits2 == false)
                                        {
                                            //Entity tempDocList1 = CreateDocumentlist(service, targetEntity, secondDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                            //if (tempDocList1.LogicalName != null)
                                            //{
                                            //    bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                            //    if (isalreadyincluded == false)// added
                                            //        documentList.Entities.Add(tempDocList1);
                                            //}

                                        }
                                    }
                                }

                                crmTrace.AppendLine("Check if third is there!");
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("ThirdDocumentType is there!");
                                        Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                        // check if the documentList already contains a document with this guid.
                                        bool alreadyExisits3 = CheckDocumentAlreadyExists(service, targetEntity, thirdDocumentTypeGuid);
                                        if (alreadyExisits3 == true)
                                        { return; }

                                        if (alreadyExisits3 == false)
                                        {
                                            //Entity tempDocList2 = CreateDocumentlist(service, targetEntity, thirdDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                            //if (tempDocList2.LogicalName != null)
                                            //{
                                            //    bool isalreadyincluded = CheckDocumentList(documentList, tempDocList2); // added
                                            //    if (isalreadyincluded == false)// added
                                            //        documentList.Entities.Add(tempDocList2);
                                            //}

                                        }
                                    }
                                }

                                crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                            } // if ends here

                        } // for ends here

                    } // for ends here

                    crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                    CreateDocumentListCollection(service, documentList, context, crmTrace);

                    crmTrace.AppendLine("Completed CreateDocumentListCollection Method");

                } // if ends here

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void CreateRequiredItemstoJobFiling_ScopeofWork2(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ScopeofWork2 started!");


                // Get all the configurations for ScopeofWork entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for ScopeofWork entity");

                EntityCollection documentList = new EntityCollection();
                EntityCollection removeDocumentList = new EntityCollection();

                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    if (targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.System) && targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.GoToJobFiling))
                    {
                        string systemGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                        string JobFilingGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();
                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();
                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("systemGuid: " + systemGuid);
                            crmTrace.AppendLine("fieldValueGuid: " + fieldValueGuid);
                            if (systemGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("systemGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                                // check if the documentList already contains a document with this guid.
                                bool alreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentTypeGuid);
                                if (alreadyExisits == true)
                                { return; }

                                if (alreadyExisits == false)
                                {
                                    Entity tempDocList = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), documentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                    if (tempDocList.LogicalName != null)
                                    {
                                        bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                        if (isalreadyincluded == false)// added
                                            documentList.Entities.Add(tempDocList);
                                    }

                                }
                                crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("SecondDocumentType is there!");
                                        Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                        crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                        // check if the documentList already contains a document with this guid.
                                        bool alreadyExisits2 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, secondDocumentTypeGuid);
                                        crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                        if (alreadyExisits2 == true)
                                        { return; }

                                        if (alreadyExisits2 == false)
                                        {
                                            Entity tempDocList1 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), secondDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                            if (tempDocList1.LogicalName != null)
                                            {
                                                bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                                if (isalreadyincluded == false)// added
                                                    documentList.Entities.Add(tempDocList1);
                                            }

                                        }
                                    }
                                }

                                crmTrace.AppendLine("Check if third is there!");
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("ThirdDocumentType is there!");
                                        Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                        // check if the documentList already contains a document with this guid.
                                        bool alreadyExisits3 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, thirdDocumentTypeGuid);
                                        if (alreadyExisits3 == true)
                                        { return; }

                                        if (alreadyExisits3 == false)
                                        {
                                            Entity tempDocList2 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), thirdDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                            if (tempDocList2.LogicalName != null)
                                            {
                                                bool isalreadyincluded = CheckDocumentList(documentList, tempDocList2); // added
                                                if (isalreadyincluded == false)// added
                                                    documentList.Entities.Add(tempDocList2);

                                            }

                                        }
                                    }
                                }

                                crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                            } // if ends here
                            else
                            {
                                if (context.MessageName == MessageName.Update)
                                {
                                    crmTrace.AppendLine("systemGuid is NOT equal to fieldValueGuid");
                                    Entity entity = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                    Guid documentTypeGuid = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                                    string documentTypeName = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Name;
                                    Guid SeconddocumentTypeGuid = (entity.Attributes.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType)) ? ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id : Guid.Empty;
                                    Guid ThirddocumentTypeGuid = (entity.Attributes.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType)) ? ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id : Guid.Empty;
                                    crmTrace.AppendLine("Config documentTypeName: " + documentTypeName.ToString());
                                    crmTrace.AppendLine("Get the records from DocumentList where Job filing is current and have Document Name equal to documentTypeGuid");
                                    // Get all the Document List records regarding this job filing
                                    ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                                    EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition }, LogicalOperator.And);
                                    crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                                    for (int k = 0; k < documentListResponse.Entities.Count; k++)  // checks through all the DocumentList records and looks for the record to be deleted.
                                    {
                                        Entity recordDocumentList = (Entity)documentListResponse.Entities[k];
                                        Guid recordGuid = documentListResponse.Entities[k].Id;
                                        // Get Guid of Document Name in each record
                                        Guid documentNameId = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Id;
                                        string docname = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Name;
                                        crmTrace.AppendLine("Job Filing docname: " + docname.ToString());
                                        if (documentTypeGuid == documentNameId || documentNameId == SeconddocumentTypeGuid || documentNameId == ThirddocumentTypeGuid)
                                        {
                                            crmTrace.AppendLine("Document to be deleted with ID: " + documentNameId.ToString());
                                            removeDocumentList.Entities.Add(recordDocumentList);  // adds the record to removeDocumentList collection
                                        }

                                    }
                                }


                            }

                        } // for ends here

                        crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                        CreateDocumentListCollection(service, documentList, context, crmTrace);

                        crmTrace.AppendLine("Completed CreateDocumentListCollection Method");
                        crmTrace.AppendLine("removeDocumentList.Entities.Count: " + removeDocumentList.Entities.Count);
                        if (removeDocumentList != null && removeDocumentList.Entities != null && removeDocumentList.Entities.Count > 0)  //Checking if removeDocumentList contains some records
                        {
                            crmTrace.AppendLine("Started DeleteremoveDocumentListCollection Method");
                            DeleteRemoveDocumentListCollection(service, removeDocumentList, context, crmTrace);
                            crmTrace.AppendLine("Completed DeleteremoveDocumentListCollection Method");
                        }

                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", null, crmTrace.ToString(), null, null);


                    }

                } // if ends here

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWork2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void CreateRequiredItemstoJobFiling_ScopeofWorkCreate(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ScopeofWorkCreate started!");

                if (targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.System) && targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.GoToJobFiling))
                {
                    crmTrace.AppendLine("Get the configuration for ScopeofWork target entity");
                    string systemGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("systemGuid: " + systemGuid);
                    string JobFilingGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("JobFilingGuid: " + JobFilingGuid);

                    ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                    ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                    ConditionExpression condition2 = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, ConditionOperator.Equal, new string[] { systemGuid });
                    EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition, condition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("Got the configurations for ScopeofWork target entity");

                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                    {
                        EntityCollection documentList = new EntityCollection();
                        EntityCollection removeDocumentList = new EntityCollection();

                        Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[0];
                        Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                        // check if the documentList already contains a document with this guid.
                        bool alreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentTypeGuid);
                        if (alreadyExisits == true)
                        { return; }

                        if (alreadyExisits == false)
                        {
                            Entity tempDocList = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), documentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                            if (tempDocList.LogicalName != null)
                            {
                                bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                if (isalreadyincluded == false)// added
                                    documentList.Entities.Add(tempDocList);
                            }

                        }
                        crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);
                        if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                        {
                            if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                            {
                                crmTrace.AppendLine("SecondDocumentType is there!");
                                Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                // check if the documentList already contains a document with this guid.
                                bool alreadyExisits2 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, secondDocumentTypeGuid);
                                crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                if (alreadyExisits2 == true)
                                { return; }

                                if (alreadyExisits2 == false)
                                {
                                    Entity tempDocList1 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), secondDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                    if (tempDocList1.LogicalName != null)
                                    {
                                        bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                        if (isalreadyincluded == false)// added
                                            documentList.Entities.Add(tempDocList1);
                                    }

                                }
                            }
                        }

                        crmTrace.AppendLine("Check if third is there!");
                        if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                        {
                            if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                            {
                                crmTrace.AppendLine("ThirdDocumentType is there!");
                                Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                // check if the documentList already contains a document with this guid.
                                bool alreadyExisits3 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, thirdDocumentTypeGuid);
                                if (alreadyExisits3 == true)
                                { return; }

                                if (alreadyExisits3 == false)
                                {
                                    Entity tempDocList2 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), thirdDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                    if (tempDocList2.LogicalName != null)
                                    {
                                        bool isalreadyincluded = CheckDocumentList(documentList, tempDocList2); // added
                                        if (isalreadyincluded == false)// added
                                            documentList.Entities.Add(tempDocList2);
                                    }

                                }
                            }
                        }

                        crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                        crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                        CreateDocumentListCollection(service, documentList, context, crmTrace);

                        crmTrace.AppendLine("Completed CreateDocumentListCollection Method");
                    }
                }

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", null, crmTrace.ToString(), null, null);
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkCreate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void CreateRequiredItemstoJobFiling_ScopeofWorkUpdate(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_ScopeofWorkUpdate started!");

                if (targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.System) && preImage.Attributes.Contains(ScopeOfWorkEntityAttributeName.GoToJobFiling))
                {
                    crmTrace.AppendLine("Get the configuration for ScopeofWork target entity");
                    string systemGuid_target = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("systemGuid_target: " + systemGuid_target);
                    string systemGuid_pre = ((EntityReference)preImage[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("systemGuid_pre: " + systemGuid_pre);
                    string JobFilingGuid = ((EntityReference)preImage[ScopeOfWorkEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("JobFilingGuid: " + JobFilingGuid);
                    if (systemGuid_target != systemGuid_pre)
                    {
                        #region Get the configuration for ScopeofWork target entity
                        ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                        ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        ConditionExpression condition2 = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, ConditionOperator.Equal, new string[] { systemGuid_target });
                        EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition, condition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("Got the configurations for ScopeofWork target entity");
                        #endregion

                        #region If found config for ScopeofWork target entity
                        crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                        if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                        {
                            EntityCollection documentList = new EntityCollection();
                            EntityCollection removeDocumentList = new EntityCollection();

                            Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[0];
                            Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                            // check if the documentList already contains a document with this guid.
                            bool alreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentTypeGuid);
                            if (alreadyExisits == true)
                            { return; }

                            if (alreadyExisits == false)
                            {
                                Entity tempDocList = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), documentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                if (tempDocList.LogicalName != null)
                                {
                                    bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                    if (isalreadyincluded == false)// added
                                        documentList.Entities.Add(tempDocList);
                                }

                            }
                            crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);

                            #region Check if Second is there!
                            if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                            {
                                if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                {
                                    crmTrace.AppendLine("SecondDocumentType is there!");
                                    Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                    crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                    // check if the documentList already contains a document with this guid.
                                    bool alreadyExisits2 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, secondDocumentTypeGuid);
                                    crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                    if (alreadyExisits2 == true)
                                    { return; }

                                    if (alreadyExisits2 == false)
                                    {
                                        Entity tempDocList1 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), secondDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                        if (tempDocList1.LogicalName != null)
                                        {
                                            bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                            if (isalreadyincluded == false)// added
                                                documentList.Entities.Add(tempDocList1);
                                        }

                                    }
                                }
                            }
                            #endregion

                            #region Check if third is there!
                            crmTrace.AppendLine("Check if third is there!");
                            if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                            {
                                if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                                {
                                    crmTrace.AppendLine("ThirdDocumentType is there!");
                                    Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                    // check if the documentList already contains a document with this guid.
                                    bool alreadyExisits3 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, thirdDocumentTypeGuid);
                                    if (alreadyExisits3 == true)
                                    { return; }

                                    if (alreadyExisits3 == false)
                                    {
                                        Entity tempDocList2 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), thirdDocumentTypeGuid, ScopeOfWorkEntityAttributeName.EntityLogicalName, crmTrace);
                                        if (tempDocList2.LogicalName != null)
                                        {
                                            bool isalreadyincluded = CheckDocumentList(documentList, tempDocList2); // added
                                            if (isalreadyincluded == false)// added
                                                documentList.Entities.Add(tempDocList2);
                                        }

                                    }
                                }
                            }
                            #endregion

                            crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                            crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                            CreateDocumentListCollection(service, documentList, context, crmTrace);

                            crmTrace.AppendLine("Completed CreateDocumentListCollection Method");
                        }
                        #endregion

                        #region Check and delete document for preImage System

                        #region Get the configuration for ScopeofWork preImage entity
                        ConditionExpression documentRequiredConfigurationsCondition_pre = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                        ConditionExpression condition_pre = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                        ConditionExpression condition2_pre = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, ConditionOperator.Equal, new string[] { systemGuid_pre });
                        EntityCollection documentRequiredConfigurationsResponse_pre = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition_pre, condition_pre, condition2_pre }, LogicalOperator.And);
                        crmTrace.AppendLine("Got the configurations for ScopeofWork target entity");
                        #endregion

                        #region If found config for ScopeofWork preImage entity
                        crmTrace.AppendLine("documentRequiredConfigurationsResponse_pre count: " + documentRequiredConfigurationsResponse_pre.Entities.Count);
                        if (documentRequiredConfigurationsResponse_pre != null && documentRequiredConfigurationsResponse_pre.Entities != null && documentRequiredConfigurationsResponse_pre.Entities.Count > 0)
                        {
                            EntityCollection removeDocumentList = new EntityCollection();

                            Entity entity = (Entity)documentRequiredConfigurationsResponse_pre.Entities[0];
                            Guid documentTypeGuid = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;
                            string documentTypeName = ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Name;
                            Guid SeconddocumentTypeGuid = (entity.Attributes.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType)) ? ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id : Guid.Empty;
                            Guid ThirddocumentTypeGuid = (entity.Attributes.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType)) ? ((EntityReference)entity[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id : Guid.Empty;
                            crmTrace.AppendLine("Config documentTypeName: " + documentTypeName.ToString());
                            crmTrace.AppendLine("Get the records from DocumentList where Job filing is current and have Document Name equal to documentTypeGuid");
                            // Get all the Document List records regarding this job filing
                            ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                            EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition }, LogicalOperator.And);
                            crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                            for (int k = 0; k < documentListResponse.Entities.Count; k++)  // checks through all the DocumentList records and looks for the record to be deleted.
                            {
                                Entity recordDocumentList = (Entity)documentListResponse.Entities[k];
                                Guid recordGuid = documentListResponse.Entities[k].Id;
                                // Get Guid of Document Name in each record
                                Guid documentNameId = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Id;
                                string docname = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Name;
                                crmTrace.AppendLine("Job Filing docname: " + docname.ToString());
                                if (documentTypeGuid == documentNameId || documentNameId == SeconddocumentTypeGuid || documentNameId == ThirddocumentTypeGuid)
                                {
                                    crmTrace.AppendLine("Document to be deleted with ID: " + documentNameId.ToString());
                                    removeDocumentList.Entities.Add(recordDocumentList);  // adds the record to removeDocumentList collection
                                }

                            }

                            crmTrace.AppendLine("removeDocumentList.Entities.Count: " + removeDocumentList.Entities.Count);
                            if (removeDocumentList != null && removeDocumentList.Entities != null && removeDocumentList.Entities.Count > 0)  //Checking if removeDocumentList contains some records
                            {
                                crmTrace.AppendLine("Started DeleteremoveDocumentListCollection Method");
                                DeleteRemoveDocumentListCollection(service, removeDocumentList, context, crmTrace);
                                crmTrace.AppendLine("Completed DeleteremoveDocumentListCollection Method");
                            }

                        }
                        #endregion

                        #endregion
                    }

                }

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", null, crmTrace.ToString(), null, null);
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_ScopeofWorkUpdate", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void CreateRequiredItemstoJobFiling_DS1Update(IOrganizationService service, Entity targetEntity, Entity preImage, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_DS1Update started!");

                if (targetEntity.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals) && preImage.Attributes.Contains(AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling))
                {
                    crmTrace.AppendLine("Get the configuration for DS1 target entity");
                    bool UseOtherMechanicals_target = targetEntity.GetAttributeValue<bool>(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals);
                    crmTrace.AppendLine("UseOtherMechanicals_target: " + UseOtherMechanicals_target);
                    bool UseOtherMechanicals_pre = preImage.GetAttributeValue<bool>(AntennaDemolitionSubmittalCertificationEntityAttributeName.UseOtherMechanicals);
                    crmTrace.AppendLine("UseOtherMechanicals_pre: " + UseOtherMechanicals_pre);
                    string JobFilingGuid = ((EntityReference)preImage[AntennaDemolitionSubmittalCertificationEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("JobFilingGuid: " + JobFilingGuid);
                    if (UseOtherMechanicals_target != UseOtherMechanicals_pre)
                    {
                        #region if Checked
                        if (UseOtherMechanicals_target)
                        {
                            string PCRC = "PARTIAL DEMO: 10-DAY NoTICE (FOR AL/EW-OT PERMITS) P41";
                            ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { PCRC });
                            ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                            EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);
                            Entity documentType = new Entity();
                            crmTrace.AppendLine("documentTypeResponse countL " + documentTypeResponse.Entities.Count);
                            if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                                documentType = (Entity)documentTypeResponse.Entities[0];
                            crmTrace.AppendLine("documentTypeGuid" + documentType.Id.ToString());
                            bool PCRCalreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentType.Id);
                            if (PCRCalreadyExisits == false)
                            {
                                CreatePCRC(service, Guid.Parse(JobFilingGuid), documentType, crmTrace);
                                crmTrace.AppendLine("10 Day Notice created ");
                            }
                        }
                        else
                        {
                            crmTrace.AppendLine("PARTIAL DEMO: 10-DAY NoTICE (FOR AL/EW-OT PERMITS) P41 is not required");
                            string PCRC = "PARTIAL DEMO: 10-DAY NoTICE (FOR AL/EW-OT PERMITS) P41";
                            ConditionExpression documentTypeCondition = CreateConditionExpression(DocumentTypeEntityAttributeName.RequiredItemNumber, ConditionOperator.Equal, new string[] { PCRC });
                            ConditionExpression condition2 = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                            EntityCollection documentTypeResponse = RetrieveMultiple(service, DocumentTypeEntityAttributeName.EntityLogicalName, new string[] { DocumentTypeEntityAttributeName.DocumentName }, new ConditionExpression[] { documentTypeCondition, condition2 }, LogicalOperator.And);
                            Entity documentType = new Entity();

                            if (documentTypeResponse != null && documentTypeResponse.Entities.Count > 0)
                                documentType = (Entity)documentTypeResponse.Entities[0];
                            Guid documentTypeGuid = documentType.Id;
                            crmTrace.AppendLine("documentTypeGuid" + documentTypeGuid.ToString());
                            crmTrace.AppendLine("Get the records from DocumentList where Job filing is current and have Document Name equal to documentTypeGuid");
                            // Get all the Document List records regarding this job filing
                            ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilingGuid });
                            EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition }, LogicalOperator.And);
                            crmTrace.AppendLine("documentListResponse count" + documentListResponse.Entities.Count);
                            for (int j = 0; j < documentListResponse.Entities.Count; j++)  // checks through all the DocumentList records and looks for the record to be deleted.
                            {
                                Entity recordDocumentList = (Entity)documentListResponse.Entities[j];
                                Guid recordGuid = documentListResponse.Entities[j].Id;
                                // Get Guid of Document Name in each record
                                Guid documentNameId = ((EntityReference)recordDocumentList[DocumentListEntityAttributeName.DocumentName]).Id;
                                crmTrace.AppendLine("documentNameId" + documentNameId.ToString());
                                if (documentNameId == documentTypeGuid)
                                {
                                    crmTrace.AppendLine("documentNameId == documentTypeGuid");
                                    service.Delete(DocumentListEntityAttributeName.EntityLogicalName, recordDocumentList.Id);  // adds the record to removeDocumentList collection
                                }
                            }
                        }

                        #endregion

                    }

                }

                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", null, crmTrace.ToString(), null, null);
            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_DS1Update", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void DeleteRequiredItemstoJobFiling_ScopeofWork(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("DeleteRequiredItemstoJobFiling_ScopeofWork started!");


                // Get all the configurations for ScopeofWork entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { ScopeOfWorkEntityAttributeName.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for ScopeofWork entity");

                EntityCollection documentList = new EntityCollection();
                //throw new Exception("aqib testing");
                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                    if (targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.System) && targetEntity.Attributes.Contains(ScopeOfWorkEntityAttributeName.GoToJobFiling))
                    {
                        string systemGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.System]).Id.ToString().ToUpper();
                        string JobFilingGuid = ((EntityReference)targetEntity[ScopeOfWorkEntityAttributeName.GoToJobFiling]).Id.ToString().ToUpper();
                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldValueGuid = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();
                            // compare the both the guids.. if progressInspectionRecords Guid matches with configuration.. create document
                            crmTrace.AppendLine("systemGuid: " + systemGuid);
                            if (systemGuid == fieldValueGuid)
                            {
                                crmTrace.AppendLine("systemGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                                // check if the documentList already contains a document with this guid then Delete.
                                CheckandDeleteIfDocumentExists(service, JobFilingGuid, documentTypeGuid, crmTrace);
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("SecondDocumentType is there!");
                                        Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                        crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                        // check if the documentList already contains a document with this guid.
                                        CheckandDeleteIfDocumentExists(service, JobFilingGuid, secondDocumentTypeGuid, crmTrace);
                                    }
                                }

                                crmTrace.AppendLine("Check if third is there!");
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("ThirdDocumentType is there!");
                                        Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                        // check if the documentList already contains a document with this guid.
                                        CheckandDeleteIfDocumentExists(service, JobFilingGuid, thirdDocumentTypeGuid, crmTrace);
                                    }
                                }


                            } // if ends here

                        } // for ends here

                    }

                } // if ends here

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // DeleteRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static void CreateRequiredItemstoJobFiling_PropertyProfile(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_PropertyProfile started!");

                // Delete all the document list records for current jobfilling created due to PropertyProfile entity

                ConditionExpression documentListCondition1 = CreateConditionExpression(DocumentListEntityAttributeName.CreatedDueto, ConditionOperator.Equal, new string[] { PropertyProfileAttributeNames.EntityLogicalName });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition1, documentListCondition2 }, LogicalOperator.And);
                //DeleteRemoveDocumentListCollection(service, documentListResponse, context, crmTrace);
                //crmTrace.AppendLine("Deleted all the document list records for current jobfilling created due to ScopeofWork entity");

                // Get all the configurations for PropertyProfile entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { PropertyProfileAttributeNames.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for PropertyProfile entity");

                crmTrace.AppendLine("Get the PropertyProfile entity records for current job filing (target entity)");
                string[] ColumnNames_PropertyProfile = new string[] { PropertyProfileAttributeNames.SpecialArea1, PropertyProfileAttributeNames.SpecialArea2, PropertyProfileAttributeNames.SpecialArea3, PropertyProfileAttributeNames.SpecialArea4,
                PropertyProfileAttributeNames.SpecialArea5, PropertyProfileAttributeNames.SpecialDistrict1, PropertyProfileAttributeNames.SpecialDistrict2, PropertyProfileAttributeNames.LoftFlag, PropertyProfileAttributeNames.TransitAuthority, PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower()};

                ConditionExpression PropertyProfileRecordsCondition = CreateConditionExpression(PropertyProfileAttributeNames.dobnyc_JobFilingRecord_PP.ToLower(), ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
                EntityCollection PropertyProfileResponse = RetrieveMultiple(service, PropertyProfileAttributeNames.EntityLogicalName, ColumnNames_PropertyProfile, new ConditionExpression[] { PropertyProfileRecordsCondition }, LogicalOperator.And);
                EntityCollection documentList = new EntityCollection();

                if (PropertyProfileResponse != null && PropertyProfileResponse.Entities != null && PropertyProfileResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("PropertyProfileResponse count: " + PropertyProfileResponse.Entities.Count);
                    for (int i = 0; i < PropertyProfileResponse.Entities.Count; i++)
                    {
                        Entity entity = (Entity)PropertyProfileResponse.Entities[i];
                        string SpecialArea1 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea1);
                        string SpecialArea2 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea2);
                        string SpecialArea3 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea3);
                        string SpecialArea4 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea4);
                        string SpecialArea5 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea5);
                        string SpecialDistrict1 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialDistrict1);
                        string SpecialDistrict2 = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialDistrict2);
                        string LoftFalg = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.LoftFlag);
                        string TransitAuthority = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.TransitAuthority);
                        string LandMark = entity.GetAttributeValue<string>(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower());


                        // Getting the inspectionComponent Guid for each progressInspectionRecords
                        for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                        {
                            // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                            string fieldMapping = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping].ToString();
                            string fieldValue = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();

                            if ((fieldMapping == PropertyProfileAttributeNames.SpecialArea1 && fieldValue == SpecialArea1) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialArea2 && fieldValue == SpecialArea2) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialArea3 && fieldValue == SpecialArea3) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialArea4 && fieldValue == SpecialArea4) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialArea5 && fieldValue == SpecialArea5) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialDistrict1 && fieldValue == SpecialDistrict1) ||
                                (fieldMapping == PropertyProfileAttributeNames.SpecialDistrict2 && fieldValue == SpecialDistrict2) ||
                                (fieldMapping == PropertyProfileAttributeNames.LoftFlag && fieldValue == LoftFalg) ||
                                (fieldMapping == PropertyProfileAttributeNames.TransitAuthority && fieldValue == TransitAuthority) ||
                                (fieldMapping == PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower() && fieldValue == LandMark))
                            {
                                crmTrace.AppendLine("systemGuid is equal to fieldValueGuid");
                                Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                                Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                                // check if the documentList already contains a document with this guid.
                                bool alreadyExisits = CheckDocumentAlreadyExists(service, targetEntity, documentTypeGuid);
                                //if (alreadyExisits == true)
                                //{ return; }

                                if (alreadyExisits == false)
                                {
                                    //Entity tempDocList = CreateDocumentlist(service, targetEntity, documentTypeGuid, PropertyProfileAttributeNames.EntityLogicalName, crmTrace);
                                    //if (tempDocList.LogicalName != null)
                                    //{
                                    //    bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                    //    if (isalreadyincluded == false)// added
                                    //        documentList.Entities.Add(tempDocList);
                                    //}

                                }
                                crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);
                                if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                                {
                                    if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                    {
                                        crmTrace.AppendLine("SecondDocumentType is there!");
                                        Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                        crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                        // check if the documentList already contains a document with this guid.
                                        bool alreadyExisits2 = CheckDocumentAlreadyExists(service, targetEntity, secondDocumentTypeGuid);
                                        crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                        //if (alreadyExisits2 == true)
                                        //{ return; }

                                        if (alreadyExisits2 == false)
                                        {
                                            //Entity tempDocList1 = CreateDocumentlist(service, targetEntity, secondDocumentTypeGuid, PropertyProfileAttributeNames.EntityLogicalName, crmTrace);
                                            //bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                            //if (isalreadyincluded == false)// added
                                            //    documentList.Entities.Add(tempDocList1);
                                        }
                                    }
                                }

                                crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                            } // if ends here

                        } // for ends here

                    } // for ends here

                    crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                    CreateDocumentListCollection(service, documentList, context, crmTrace);

                    crmTrace.AppendLine("Completed CreateDocumentListCollection Method");

                } // if ends here

                //throw new Exception("Property Profile Test");

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_PropertyProfile Method Ends here

        public static void CreateRequiredItemstoJobFiling_PropertyProfile2(IOrganizationService service, Entity targetEntity, string JobFilingGuid, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("CreateRequiredItemstoJobFiling_PropertyProfile2 started!");

                // Get all the configurations for PropertyProfile entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { PropertyProfileAttributeNames.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for PropertyProfile entity");

                EntityCollection documentList = new EntityCollection();

                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);

                    crmTrace.AppendLine("PropertyProfileAttributeNames.dobnyc_JobFilingRecord_PP is present");
                    //string JobFilingGuid = ((EntityReference)targetEntity[PropertyProfileAttributeNames.dobnyc_JobFilingRecord_PP.ToLower()]).Id.ToString().ToUpper();
                    crmTrace.AppendLine("JobFilingGuid: " + JobFilingGuid);

                    string SpecialArea1 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialArea1))
                    {
                        SpecialArea1 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea1).ToString();
                        crmTrace.AppendLine("SpecialArea1: " + SpecialArea1.ToString());
                    }

                    string SpecialArea2 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialArea2))
                    {
                        SpecialArea2 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea2).ToString();
                        crmTrace.AppendLine("SpecialArea2: " + SpecialArea2);
                    }

                    string SpecialArea3 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialArea3))
                    {
                        SpecialArea3 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea3).ToString();
                        crmTrace.AppendLine("SpecialArea3: " + SpecialArea3);
                    }

                    string SpecialArea4 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialArea4))
                    {
                        SpecialArea4 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea4).ToString();
                        crmTrace.AppendLine("SpecialArea4: " + SpecialArea4);
                    }

                    string SpecialArea5 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialArea5))
                    {
                        SpecialArea5 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialArea5).ToString();
                        crmTrace.AppendLine("SpecialArea5: " + SpecialArea5);
                    }

                    string EnvironmentalRestriction = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower()))
                    {
                        EnvironmentalRestriction = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower()).ToString();
                        crmTrace.AppendLine("EnvironmentalRestriction: " + EnvironmentalRestriction);
                    }

                    string SpecialDistrict1 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialDistrict1))
                    {
                        SpecialDistrict1 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialDistrict1).ToString();
                        crmTrace.AppendLine("SpecialDistrict1: " + SpecialDistrict1);
                    }

                    string SpecialDistrict2 = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.SpecialDistrict2))
                    {
                        SpecialDistrict2 = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.SpecialDistrict2).ToString();
                        crmTrace.AppendLine("SpecialDistrict2: " + SpecialDistrict2);
                    }
                    string LoftFalg = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.LoftFlag))
                    {
                        LoftFalg = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.LoftFlag).ToString();
                        crmTrace.AppendLine("LoftFalg: " + LoftFalg);
                    }
                    string TransitAuthority = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.TransitAuthority))
                    {
                        TransitAuthority = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.TransitAuthority).ToString();
                        crmTrace.AppendLine("TransitAuthority: " + TransitAuthority);
                    }

                    string SRORestricted = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower()))
                    {
                        SRORestricted = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower()).ToString();
                        crmTrace.AppendLine("SRORestricted: " + SRORestricted);
                    }
                    string LandMark = string.Empty;
                    if (targetEntity.Attributes.Contains(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower()))
                    {
                        LandMark = targetEntity.GetAttributeValue<string>(PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower()).ToString();
                        crmTrace.AppendLine("LandMark: " + LandMark);
                    }
                    // Getting the inspectionComponent Guid for each progressInspectionRecords
                    for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                    {
                        // Get the Guid stored in fieldValue in DocumentRequiredConfiguration entity
                        string fieldMapping = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping].ToString();
                        crmTrace.AppendLine("fieldMapping: " + fieldMapping);
                        string fieldValue = documentRequiredConfigurationsResponse.Entities[j].Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue].ToString();
                        crmTrace.AppendLine("fieldValue: " + fieldValue);

                        if ((fieldMapping == PropertyProfileAttributeNames.SpecialArea1 && fieldValue == SpecialArea1) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialArea2 && fieldValue == SpecialArea2) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialArea3 && fieldValue == SpecialArea3) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialArea4 && fieldValue == SpecialArea4) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialArea5 && fieldValue == SpecialArea5) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialDistrict1 && fieldValue == SpecialDistrict1) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.SpecialDistrict2 && fieldValue == SpecialDistrict2) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.LoftFlag && fieldValue == LoftFalg) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.TransitAuthority && fieldValue == TransitAuthority) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.dobnyc_SRORestricted.ToLower() && fieldValue == SRORestricted) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.dobnyc_EnvironmentalRestrictions.ToLower() && fieldValue != EnvironmentalRestriction) && targetEntity.Attributes.Contains(fieldMapping) ||
                            (fieldMapping == PropertyProfileAttributeNames.dobnyc_LandmarkStatus.ToLower() && fieldValue == LandMark && targetEntity.Attributes.Contains(fieldMapping)))
                        {
                            crmTrace.AppendLine("systemGuid is equal to fieldValueGuid");
                            Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                            Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                            // check if the documentList already contains a document with this guid.
                            bool alreadyExisits = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, documentTypeGuid);
                            //if (alreadyExisits == true)
                            //{ return; }

                            if (alreadyExisits == false)
                            {
                                Entity tempDocList = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), documentTypeGuid, PropertyProfileAttributeNames.EntityLogicalName, crmTrace);
                                if (tempDocList.LogicalName != null)
                                    service.Create(tempDocList);
                                //bool isalreadyincluded = CheckDocumentList(documentList, tempDocList); // added
                                //if (isalreadyincluded == false)// added
                                //    documentList.Entities.Add(tempDocList);
                            }
                            crmTrace.AppendLine("entity_documentRequiredConfigurationRecord count: " + entity_documentRequiredConfigurationRecord.Attributes.Count);
                            //if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                            if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                            {
                                if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                                {
                                    crmTrace.AppendLine("SecondDocumentType is there!");
                                    Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                    crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                    // check if the documentList already contains a document with this guid.
                                    bool alreadyExisits2 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, secondDocumentTypeGuid);
                                    crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                    //if (alreadyExisits2 == true)
                                    //{ return; }

                                    if (alreadyExisits2 == false)
                                    {
                                        Entity tempDocList1 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), secondDocumentTypeGuid, PropertyProfileAttributeNames.EntityLogicalName, crmTrace);
                                        if (tempDocList1.LogicalName != null)
                                            service.Create(tempDocList1);
                                        //bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                        //if (isalreadyincluded == false)// added
                                        //    documentList.Entities.Add(tempDocList1);
                                    }
                                }
                            }

                            if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                            {
                                if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                                {
                                    crmTrace.AppendLine("ThirdDocumentType is there!");
                                    Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                    crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                    // check if the documentList already contains a document with this guid.
                                    bool alreadyExisits2 = CheckDocumentAlreadyExists_Id(service, JobFilingGuid, secondDocumentTypeGuid);
                                    crmTrace.AppendLine("alreadyExisits2 : " + alreadyExisits2.ToString());
                                    //if (alreadyExisits2 == true)
                                    //{ return; }

                                    if (alreadyExisits2 == false)
                                    {
                                        Entity tempDocList1 = CreateDocumentlist_Id(service, Guid.Parse(JobFilingGuid), secondDocumentTypeGuid, PropertyProfileAttributeNames.EntityLogicalName, crmTrace);
                                        if (tempDocList1.LogicalName != null)
                                            service.Create(tempDocList1);
                                        //bool isalreadyincluded = CheckDocumentList(documentList, tempDocList1); // added
                                        //if (isalreadyincluded == false)// added
                                        //    documentList.Entities.Add(tempDocList1);
                                    }
                                }
                            }

                            crmTrace.AppendLine("added the DocumentsRequiredConfigurationsEntity record to collection");

                        } // if ends here

                    } // for ends here

                    crmTrace.AppendLine("Started CreateDocumentListCollection Method");

                    //CreateDocumentListCollection(service, documentList, context, crmTrace);

                    crmTrace.AppendLine("Completed CreateDocumentListCollection Method");



                } // if ends here

                //throw new Exception("Property Profile Test");

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateRequiredItemstoJobFiling_PropertyProfile2", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // CreateRequiredItemstoJobFiling_PropertyProfile Method Ends here

        public static void DeleteRequiredItemstoJobFiling_PropertyProfile(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, IPluginExecutionContext context)
        {
            try
            {
                //targetentity is JobFiling
                crmTrace.AppendLine("DeleteRequiredItemstoJobFiling_PropertyProfile started!");


                // Get all the configurations for ScopeofWork entity
                ConditionExpression documentRequiredConfigurationsCondition = CreateConditionExpression(DocumentsRequiredConfigurationsEntityAttibuteName.EntitySchema, ConditionOperator.Equal, new string[] { PropertyProfileAttributeNames.EntityLogicalName });
                ConditionExpression condition = CreateConditionExpression(GenericConstants.StatusCode, ConditionOperator.Equal, new object[] { GenericConstants.StatusCodeActive });
                EntityCollection documentRequiredConfigurationsResponse = RetrieveMultiple(service, DocumentsRequiredConfigurationsEntityAttibuteName.EntityLogicalName, new string[] { DocumentsRequiredConfigurationsEntityAttibuteName.FieldMapping, DocumentsRequiredConfigurationsEntityAttibuteName.FieldValue, DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType, DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType }, new ConditionExpression[] { documentRequiredConfigurationsCondition, condition }, LogicalOperator.And);
                crmTrace.AppendLine("Got all the configurations for PropertyProfile entity");

                EntityCollection documentList = new EntityCollection();

                if (documentRequiredConfigurationsResponse != null && documentRequiredConfigurationsResponse.Entities != null && documentRequiredConfigurationsResponse.Entities.Count > 0)
                {
                    for (int j = 0; j < documentRequiredConfigurationsResponse.Entities.Count; j++)
                    {
                        crmTrace.AppendLine("documentRequiredConfigurationsResponse count: " + documentRequiredConfigurationsResponse.Entities.Count);
                        Entity entity_documentRequiredConfigurationRecord = (Entity)documentRequiredConfigurationsResponse.Entities[j];
                        Guid documentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.DocumentType]).Id;

                        // check if the documentList already contains a document with this guid then Delete.
                        CheckandDeleteIfDocumentExists(service, targetEntity.Id.ToString(), documentTypeGuid, crmTrace);
                        if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType))
                        {
                            if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType] != null)
                            {
                                crmTrace.AppendLine("SecondDocumentType is there!");
                                Guid secondDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.SecondDocumentType]).Id;
                                crmTrace.AppendLine("secondDocumentTypeGuid : " + secondDocumentTypeGuid.ToString());
                                // check if the documentList already contains a document with this guid.
                                CheckandDeleteIfDocumentExists(service, targetEntity.Id.ToString(), secondDocumentTypeGuid, crmTrace);
                            }
                        }

                        crmTrace.AppendLine("Check if third is there!");
                        if (entity_documentRequiredConfigurationRecord.Contains(DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType))
                        {
                            if (entity_documentRequiredConfigurationRecord[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType] != null)
                            {
                                crmTrace.AppendLine("ThirdDocumentType is there!");
                                Guid thirdDocumentTypeGuid = ((EntityReference)entity_documentRequiredConfigurationRecord.Attributes[DocumentsRequiredConfigurationsEntityAttibuteName.ThirdDocumentType]).Id;
                                // check if the documentList already contains a document with this guid.
                                CheckandDeleteIfDocumentExists(service, targetEntity.Id.ToString(), thirdDocumentTypeGuid, crmTrace);
                            }
                        }
                    }
                } // if ends here

            } // try ends here
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRequiredItemstoJobFiling_ScopeofWork", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }


        } // DeleteRequiredItemstoJobFiling_ScopeofWork Method Ends here

        public static Entity CreateDocumentlist(IOrganizationService service, Entity targetEntity, EntityCollection wt_response, int filingType, Guid documentTypeGuid, string createdDueto, StringBuilder crmTrace, Entity JF_Reterieved)
        {
            Entity DocumentList = new Entity();

            try
            {
                #region
                crmTrace.AppendLine("Start CreateDocumentlist ");
                crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                string[] workTypes = targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity[JobFilingEntityAttributeName.workTypesTextbox] != null ? targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox).Split('/') : new string[] { };
                
                if ((wt_response != null && wt_response.Entities.Count > 0) || (workTypes.Length > 0))
                {
                    crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                    List<string> WorkTyes = new List<string>();
                    foreach (Entity wt in wt_response.Entities)
                    {
                        string wt_ConfigName = wt.GetAttributeValue<string>(AssociatedWorkTypesEntityAttributeName.Name);
                        crmTrace.AppendLine("wt_ConfigName: " + wt_ConfigName);
                        WorkTyes.Add(wt_ConfigName);
                    }
                    #region BE-MS-ST
                    if (WorkTyes.Count == 0)
                    {
                        foreach (string workType in workTypes)
                        {
                            crmTrace.AppendLine("Dashboard Worktypes: " + workType.ToUpper());
                            WorkTyes.Add(workType.ToUpper());
                        }
                    }
                    crmTrace.AppendLine("WorkTyes: " + WorkTyes.ToString());
                    #endregion

                    #region

                    crmTrace.AppendLine("Start CreateDocumentlist Method");
                    string[] ColumnNames_DocumentType = new string[] { DocumentTypeEntityAttributeName.PortalDocumentDescription, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes };
                    Entity response = Retrieve(service, ColumnNames_DocumentType, documentTypeGuid, DocumentTypeEntityAttributeName.EntityLogicalName);
                    string requiredforWorkTypes = response.Contains(DocumentTypeEntityAttributeName.RequiredforWorkTypes) ? response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredforWorkTypes).Replace(",", " ") : "X";
                    crmTrace.AppendLine("Document Name: " + response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName));
                    crmTrace.AppendLine("requiredforWorkTypes: " + requiredforWorkTypes);
                    bool allowCreateDoc = false;
                    #region Looping wt array
                    foreach (var wt_string in WorkTyes)
                    {
                        crmTrace.AppendLine("wt_string: " + wt_string);
                        if (requiredforWorkTypes.Contains(wt_string.ToString()))
                            allowCreateDoc = true;
                    }
                    #endregion

                    //#region BE-MS-ST
                    //if(targetEntity.Contains(JobFilingEntityAttributeName.workTypesTextbox) && targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox) != null)
                    //{
                    //    string wtype = targetEntity.GetAttributeValue<string>(JobFilingEntityAttributeName.workTypesTextbox);
                    //    if(wtype.Contains(requiredforWorkTypes))
                    //        allowCreateDoc = true;
                    //}

                    //#endregion
                    crmTrace.AppendLine("allowCreateDoc: " + allowCreateDoc);
                    #region Finally Create Doc as per workType
                    if (allowCreateDoc)
                    {
                        var PriortoStatus = response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                        if (filingType == (int)FilingType.PAA && PriortoStatus != (int)CurrentFilingStatus.Approved)
                        {
                            return DocumentList;
                        }
                        #region Added 01/09/2018 SD3.3 PAA WD requirements
                        if (filingType == (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Start 01/09/2018 SD3.3 PAA WD requirements");
                            crmTrace.AppendLine("filingType: " + "PAA");
                            Guid parentJFId = JF_Reterieved.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;
                            crmTrace.AppendLine("parentJFId: " + parentJFId.ToString());
                            var response_tuple = CheckParentDocumentinParentJob(service, parentJFId, documentTypeGuid, crmTrace);
                            if (response_tuple.Item1 == true)
                            {
                                Entity documentListRecord_Parent = response_tuple.Item2;
                                int documentstatus_parent = documentListRecord_Parent.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;
                                crmTrace.AppendLine("documentstatus_parent: " + documentstatus_parent);
                                if (documentstatus_parent == (int)DocumentStatus.DeferralApproved)
                                    return DocumentList;
                            }

                        }
                        #endregion

                        #region Added 08/16/2018 PA PAA Do not populate documents if no intend to change requirements
                        if (filingType == (int)FilingType.PAA && targetEntity.Contains(JobFilingEntityAttributeName.PACheckBox) && targetEntity.GetAttributeValue<bool>(JobFilingEntityAttributeName.PACheckBox))
                        {
                            crmTrace.AppendLine("Start 08/16/2018 PA PAA Do not populate documents if no intend to change requirements");
                            crmTrace.AppendLine("filingType: " + "PAA");
                            if (targetEntity.Contains(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp))
                            {
                                ColumnSet columns = new ColumnSet(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans);
                                Entity placeofAssembly = service.Retrieve(PlaceofAssemblySpaceInformation.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.PlaceOfAssemblyLookUp).Id, columns);
                                crmTrace.AppendLine("placeofAssembly: " + placeofAssembly.ToString());
                                if (!placeofAssembly.GetAttributeValue<bool>(PlaceofAssemblySpaceInformation.IntendToupdatePrimaryPlans))
                                {
                                        return DocumentList;
                                }
                            }

                        }
                        #endregion


                        string RequiredItemNumber = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredItemNumber);
                        string documentName = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        string priortoStage = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                        var RequiredStatus = 1;
                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentTypeGuid));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.CreatedDueto, createdDueto);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, documentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequestNumber, documentName);
                        bool AllowWaiver = response.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, AllowWaiver);
                        if (filingType == (int)FilingType.PAA)
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, false);
                        }
                        else
                        {
                            bool AllowDeferral = response.Contains(DocumentTypeEntityAttributeName.AllowDeferral) ? response.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowDeferral) : false;
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, AllowDeferral);
                        }

                        if (RequiredItemNumber.ToLower().Contains("plan"))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(1));
                        }
                        else
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                        }
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(RequiredStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priortoStage);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentUploadNote, response.Contains(DocumentTypeEntityAttributeName.PortalDocumentDescription)?
                            response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PortalDocumentDescription) : string.Empty);
                        if (response.Contains(DocumentTypeEntityAttributeName.DocumentClass))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                        }
                        else
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue((int)DcoumentClass.NonTechnical));
                        crmTrace.AppendLine("End CreateDocumentlist Method");
                    }
                    #endregion

                    #endregion

                }

                #endregion

                //throw new Exception("Test");
                //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);

                return DocumentList;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return DocumentList;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return DocumentList;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                throw new Exception(ex + ": " + crmTrace.ToString());
                return DocumentList;
            }



        }  // CreateDocumentlist Method ends here

        public static Entity CreateDocumentlist_Id(IOrganizationService service, Guid JobFilingId, Guid documentTypeGuid, string createdDueto, StringBuilder crmTrace)
        {
            Entity DocumentList = new Entity();

            try
            {
                crmTrace.AppendLine("Start CreateDocumentlist_Id ");
                string fetch = string.Format(FetchXml.GetAssociatedWorkTypes, JobFilingId.ToString());
                crmTrace.AppendLine("fetch: " + fetch);
                EntityCollection wt_response = service.RetrieveMultiple(new FetchExpression(fetch));
                crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                if (wt_response != null && wt_response.Entities.Count > 0)
                {
                    crmTrace.AppendLine("wt_response.Entities.Count: " + wt_response.Entities.Count);
                    List<string> WorkTyes = new List<string>();
                    foreach (Entity wt in wt_response.Entities)
                    {
                        string wt_ConfigName = wt.GetAttributeValue<string>(AssociatedWorkTypesEntityAttributeName.Name);
                        WorkTyes.Add(wt_ConfigName);
                    }

                    crmTrace.AppendLine("WorkTyes: " + WorkTyes);
                    #region Check Filing Type
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName };
                    Entity jfresponse = Retrieve(service, ColumnNames_JobFiling, JobFilingId, JobFilingEntityAttributeName.EntityLogicalName);
                    int filingType = jfresponse.Contains(JobFilingEntityAttributeName.FilingType) ? jfresponse.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value : 1;
                    #endregion

                    #region
                    crmTrace.AppendLine("Start CreateDocumentlist_Id Method");
                    string[] ColumnNames_DocumentType = new string[] { DocumentTypeEntityAttributeName.PortalDocumentDescription, DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage, DocumentTypeEntityAttributeName.AllowWaiver, DocumentTypeEntityAttributeName.RequiredforWorkTypes };
                    Entity response = Retrieve(service, ColumnNames_DocumentType, documentTypeGuid, DocumentTypeEntityAttributeName.EntityLogicalName);
                    string required_WorkTypes = response.Contains(DocumentTypeEntityAttributeName.RequiredforWorkTypes) ? response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredforWorkTypes).Replace(",", " ") : "X";
                    crmTrace.AppendLine("Document Name: " + response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName));
                    crmTrace.AppendLine("required_WorkTypes: " + required_WorkTypes);
                    bool allowCreateDoc = false;
                    #region Looping wt array
                    foreach (var wt_string in WorkTyes)
                    {
                        if (required_WorkTypes.Contains(wt_string.ToString()))
                            allowCreateDoc = true;
                    }
                    #endregion
                    crmTrace.AppendLine("allowCreateDoc: " + allowCreateDoc);

                    #region Finally Create Doc as per workType
                    if (allowCreateDoc)
                    {

                        var PriortoStatus = response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                        if (filingType == (int)FilingType.PAA && PriortoStatus != (int)CurrentFilingStatus.Approved)
                        {
                            return DocumentList;
                        }
                        #region Added 01/09/2018 SD3.3 PAA WD requirements
                        if (filingType == (int)FilingType.PAA)
                        {
                            crmTrace.AppendLine("Start 01/09/2018 SD3.3 PAA WD requirements");
                            crmTrace.AppendLine("filingType: " + "PAA");
                            Guid parentJFId = jfresponse.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName).Id;
                            crmTrace.AppendLine("parentJFId: " + parentJFId.ToString());
                            var response_tuple = CheckParentDocumentinParentJob(service, parentJFId, documentTypeGuid, crmTrace);
                            if (response_tuple.Item1 == true)
                            {
                                Entity documentListRecord_Parent = response_tuple.Item2;
                                int documentstatus_parent = documentListRecord_Parent.GetAttributeValue<OptionSetValue>(DocumentListEntityAttributeName.DocumentStatus).Value;
                                crmTrace.AppendLine("documentstatus_parent: " + documentstatus_parent);
                                if (documentstatus_parent == (int)DocumentStatus.DeferralApproved)
                                    return DocumentList;
                            }

                        }
                        #endregion
                        string RequiredItemNumber = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredItemNumber);
                        string documentName = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                        string priortoStage = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                        bool AllowWaiver = response.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver);
                        var RequiredStatus = 1;
                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentTypeGuid));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFilingId));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.CreatedDueto, createdDueto);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, documentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequestNumber, RequiredItemNumber);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, AllowWaiver);
                        bool AllowDeferral = response.Contains(DocumentTypeEntityAttributeName.AllowDeferral) ? response.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowDeferral) : false;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowDeferral, AllowDeferral);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentUploadNote, response.Contains(DocumentTypeEntityAttributeName.PortalDocumentDescription) ?
                            response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PortalDocumentDescription) : string.Empty);
                        if (RequiredItemNumber.ToLower().Contains("plan"))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(1));
                        }
                        else
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                        }
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(RequiredStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priortoStage);
                        if (response.Contains(DocumentTypeEntityAttributeName.DocumentClass))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                        }
                        else
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue((int)DcoumentClass.NonTechnical));
                        crmTrace.AppendLine("End CreateDocumentlist_Id Method");
                        //throw new Exception("Test");
                    }
                    #endregion

                    #endregion

                }

                //DOBLogger.WriteTraceLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);

                return DocumentList;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return DocumentList;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return DocumentList;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlist_Id", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return DocumentList;
            }



        }  // CreateDocumentlist Method ends here

        public static bool CheckDocumentList(EntityCollection documentList, Entity entity)
        {
            bool isalreadyincluded = false;
            Guid documentName = ((EntityReference)entity.Attributes[DocumentListEntityAttributeName.DocumentName]).Id;
            foreach (Entity ent in documentList.Entities)
            {
                Guid guid = ((EntityReference)ent.Attributes[DocumentListEntityAttributeName.DocumentName]).Id;
                if (guid == documentName)
                    isalreadyincluded = true;

            }

            return isalreadyincluded;

        }

        public static bool CheckDocumentAlreadyExists(IOrganizationService service, Entity targetEntity, Guid Id)
        {
            bool ifExist = false;
            ConditionExpression documentListCondition = new ConditionExpression();
            if(targetEntity.LogicalName == JobFilingEntityAttributeName.EntityLogicalName)
                documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
            else if(targetEntity.LogicalName == WorkPermitEntityAttributeName.EntityLogicalName)
                documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoWorkPermit, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
            else if (targetEntity.LogicalName == AfterHourVarianceAttributeNames.EntityLogicalName)
                documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoAHV, ConditionOperator.Equal, new string[] { targetEntity.Id.ToString() });
            ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { Id.ToString() });
            EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
            if (documentListResponse.Entities.Count > 0)
            {
                ifExist = true;
            }

            return ifExist;
        }

        public static Tuple<bool, Entity> CheckParentDocumentinParentJob(IOrganizationService service, Guid parentJobId, Guid Id, StringBuilder crmTrace)
        {
            Entity dummy = new Entity();
            var response = new Tuple<bool, Entity>(true, dummy);
            try
            {
                crmTrace.AppendLine("Start CheckParentDocumentinParentJob");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { parentJobId.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { Id.ToString() });
                ConditionExpression documentListCondition3 = CreateConditionExpression(DocumentListEntityAttributeName.ParentDocumentList, ConditionOperator.Null, new string[] { });
                ColoumnName columns = new ColoumnName();
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, columns.DocumentList_Coloumns, new ConditionExpression[] { documentListCondition, documentListCondition2, documentListCondition3 }, LogicalOperator.And);

                if (documentListResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                    response = new Tuple<bool, Entity>(true, documentListResponse.Entities[0]);
                }
                else
                    response = new Tuple<bool, Entity>(false, dummy);
                crmTrace.AppendLine("End CheckParentDocumentinParentJob");
                return response;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return response;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return response;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(parentJobId.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CheckParentDocumentinParentJob", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                //throw new Exception(ex + ": " + crmTrace.ToString());
                return response;
            }
        }

        public static void CheckandDeleteIfDocumentExists_Permit(IOrganizationService service, string WorkPermitID, Guid Id, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CheckandDeleteIfDocumentExists_Permit");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.GotoWorkPermit, ConditionOperator.Equal, new string[] { WorkPermitID });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { Id.ToString() });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName, ent.Id);

                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(WorkPermitID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists_Permit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        public static void CheckandDeleteIfDocumentExists(IOrganizationService service, string JobFilngID, Guid Id, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CheckandDeleteIfDocumentExists");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { Id.ToString() });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        service.Delete(DocumentListEntityAttributeName.EntityLogicalName, ent.Id);

                    }
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID, SourceChannel.CRM, "DocumentItemUploadHandler - CheckandDeleteIfDocumentExists", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static EntityCollection RetrievePlansDocument_JobFiling(IOrganizationService service, Guid JobFilngID, StringBuilder crmTrace)
        {
            EntityCollection plan_Doc = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start RetrievePlansDocument_JobFiling");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentCategory, ConditionOperator.Equal, new string[] { "1" });
                ConditionExpression documentListCondition3 = CreateConditionExpression(DocumentListEntityAttributeName.ParentDocumentList, ConditionOperator.Null, new string[] { });
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber, DocumentListEntityAttributeName.DocumentURL, DocumentListEntityAttributeName.UploadedDate }, new ConditionExpression[] { documentListCondition, documentListCondition2, documentListCondition3 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        plan_Doc.Entities.Add(ent);

                    }
                }
                return plan_Doc;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return plan_Doc;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return plan_Doc;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrievePlansDocument_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return plan_Doc;
            }

        }

        public static EntityCollection RetrieveParentDocuments_JobFiling(IOrganizationService service, Guid JobFilngID, StringBuilder crmTrace)
        {
            EntityCollection docs = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start RetrieveParentDocuments_JobFiling");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID.ToString() });
                ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.ParentDocumentList, ConditionOperator.Null, new string[] { });
                ColoumnName coloumns = new ColoumnName();
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, coloumns.DocumentList_Coloumns, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        docs.Entities.Add(ent);

                    }
                }
                return docs;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return docs;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_JobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }

        }
        public static EntityCollection RetrieveParentDocuments_PAJobFiling(IOrganizationService service, Guid JobFilngID, StringBuilder crmTrace)
        {
            EntityCollection docs = new EntityCollection();
            try
            {
                crmTrace.AppendLine("Start RetrieveParentDocuments_JobFiling");
                ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID.ToString() });
                //ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.ParentDocumentList, ConditionOperator.Null, new string[] { });
                ColoumnName coloumns = new ColoumnName();
                EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, coloumns.DocumentList_Coloumns, new ConditionExpression[] { documentListCondition}, LogicalOperator.And);
                crmTrace.AppendLine("documentListResponse.Entities.Count: " + documentListResponse.Entities.Count);
                if (documentListResponse.Entities.Count > 0)
                {
                    foreach (Entity ent in documentListResponse.Entities)
                    {
                        docs.Entities.Add(ent);

                    }
                }
                return docs;
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return docs;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilngID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - RetrieveParentDocuments_PAJobFiling", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return docs;
            }

        }

        public static bool CheckDocumentAlreadyExists_Id(IOrganizationService service, string JobFilngID, Guid Id)
        {
            bool ifExist = false;

            ConditionExpression documentListCondition = CreateConditionExpression(DocumentListEntityAttributeName.DocumentListtoJobfiling, ConditionOperator.Equal, new string[] { JobFilngID });
            ConditionExpression documentListCondition2 = CreateConditionExpression(DocumentListEntityAttributeName.DocumentName, ConditionOperator.Equal, new string[] { Id.ToString() });
            EntityCollection documentListResponse = RetrieveMultiple(service, DocumentListEntityAttributeName.EntityLogicalName, new string[] { DocumentListEntityAttributeName.DocumentName, DocumentListEntityAttributeName.RequiredItemNumber }, new ConditionExpression[] { documentListCondition, documentListCondition2 }, LogicalOperator.And);
            if (documentListResponse.Entities.Count > 0)
            {
                ifExist = true;
            }

            return ifExist;
        }

        public static bool IsDocumentListContains(Guid documentGuid, EntityCollection documentList)
        {
            bool contains = false;
            for (int x = 0; x < documentList.Entities.Count; x++)
            {
                Entity entity_documentList = (Entity)documentList.Entities[x];
                Guid documentList_documentTypeGuid = ((EntityReference)entity_documentList.Attributes[DocumentListEntityAttributeName.DocumentName]).Id;
                if (documentGuid == documentList_documentTypeGuid)
                    contains = true;
            }

            return contains;

        } // IsDocumentListContains Method ends here

        public static void CreateDocumentListCollection(IOrganizationService service, EntityCollection documentList, IPluginExecutionContext context, StringBuilder crmTrace)
        {
            Guid trackingGuid = Guid.NewGuid();
            try
            {
                // Will Create an ExecuteMultipleRequest object (requestWithResults).
                crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };
                crmTrace.AppendLine(" Request object created");
                // Creates requests for each documentList record

                crmTrace.AppendLine(" Creating CreateRequest requests for each documentList record and adding them to Request Object");
                foreach (var entity in documentList.Entities)
                {
                    CreateRequest createRequest = new CreateRequest { Target = entity };
                    requestWithResults.Requests.Add(createRequest);
                }
                crmTrace.AppendLine(" CreateRequest Created requests for each documentList record and added to Request Object");

                // Execute
                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);

                foreach (var responseItem in responseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Response);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }  // CreateDocumentListCollection Method ends here

        public static void DeleteRemoveDocumentListCollection(IOrganizationService service, EntityCollection removeDocumentList, IPluginExecutionContext context, StringBuilder crmTrace)
        {
            Guid trackingGuid = Guid.NewGuid();
            try
            {
                crmTrace.AppendLine("Creating Request object");
                ExecuteMultipleRequest RemoveRequestWithResults = new ExecuteMultipleRequest()
                {
                    // Assign settings that define execution behavior: continue on error, return responses. 
                    Settings = new ExecuteMultipleSettings()
                    {
                        ContinueOnError = true,
                        ReturnResponses = true
                    },
                    // Create an empty organization request collection.
                    Requests = new OrganizationRequestCollection()
                };

                crmTrace.AppendLine(" Request object created");

                // Creates requests for each removeDocumentList record
                crmTrace.AppendLine(" Creating DeleteRequest requests for each removeDocumentList record and adding them to Request Object");
                foreach (var entity in removeDocumentList.Entities)
                {
                    DeleteRequest deleteRequest = new DeleteRequest { Target = entity.ToEntityReference() };
                    RemoveRequestWithResults.Requests.Add(deleteRequest);
                }
                crmTrace.AppendLine(" DeleteRequest Created requests for each removeDocumentList record and added to Request Object");

                crmTrace.AppendLine(" Executing the Request object");
                ExecuteMultipleResponse RemoveResponseWithResults = (ExecuteMultipleResponse)service.Execute(RemoveRequestWithResults);
                foreach (var responseItem in RemoveResponseWithResults.Responses)
                {
                    // A valid response.
                    if (responseItem.Response != null)
                        crmTrace.AppendLine("Valid Response: " + responseItem.Response);

                    // An error has occurred.
                    else if (responseItem.Fault != null)
                        crmTrace.AppendLine("Error Response: " + responseItem.Response);
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(trackingGuid.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - DeleteRemoveDocumentListCollection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        } // DeleteRemoveDocumentListCollection Method ends here

        public static void CreatePCRC(IOrganizationService service, Guid jF_ID, Entity documentType, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("Start CreatePCRC method");
                //DocumentClass, PriortoStatus, RequiredItemNumber, DocumentName, PriortoStage, AllowWaiver, RequiredforWorkTypes
                var PriortoStatus = documentType.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                string priortoStage = documentType.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                Entity DocumentList = new Entity();
                DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentType.Id));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue((int)DocumentStatus.Required));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, jF_ID));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.Documentfor, new OptionSetValue((int)Documentfor.JobFiling));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priortoStage);
                bool AllowWaiver = documentType.Contains(DocumentTypeEntityAttributeName.AllowWaiver) ? documentType.GetAttributeValue<bool>(DocumentTypeEntityAttributeName.AllowWaiver) : false;
                DocumentList.Attributes.Add(DocumentListEntityAttributeName.AllowWaiver, AllowWaiver);
                if (documentType.Contains(DocumentTypeEntityAttributeName.DocumentClass))
                {
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(documentType.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                }
                else
                    DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue((int)DcoumentClass.NonTechnical));
                //throw new Exception("Test");
                service.Create(DocumentList);
                crmTrace.AppendLine("End CreatePCRC method");
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(jF_ID.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreatePCRC", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }  // CreatePCRC Method ends here

        public static Entity CreateDocumentlistVersions(IOrganizationService service, Entity PreImage, Guid documentTypeGuid, string createdDueto, StringBuilder crmTrace)
        {
            Entity DocumentList = new Entity();

            try
            {
                crmTrace.AppendLine("Start CreateDocumentlistVersions Method");
                string[] ColumnNames_DocumentType = new string[] { DocumentTypeEntityAttributeName.AllowDeferral, DocumentTypeEntityAttributeName.DocumentClass, DocumentTypeEntityAttributeName.PriortoStatus, DocumentTypeEntityAttributeName.RequiredItemNumber, DocumentTypeEntityAttributeName.DocumentName, DocumentTypeEntityAttributeName.PriortoStage };
                Entity response = Retrieve(service, ColumnNames_DocumentType, documentTypeGuid, DocumentTypeEntityAttributeName.EntityLogicalName);
                var PriortoStatus = response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.PriortoStatus).Value;
                string RequiredItemNumber = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.RequiredItemNumber);
                string documentName = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.DocumentName);
                string priortoStage = response.GetAttributeValue<string>(DocumentTypeEntityAttributeName.PriortoStage);
                int RequiredStatus = ((OptionSetValue)PreImage.Attributes[DocumentListEntityAttributeName.DocumentStatus]).Value;
                string PreImageDocumentSource = (PreImage.Attributes[DocumentListEntityAttributeName.DocumentSource]).ToString();
                Guid JobFilingGuid = new Guid();
                if (PreImage.Contains(DocumentListEntityAttributeName.DocumentListtoJobfiling))
                {
                    if (((EntityReference)PreImage.Attributes[DocumentListEntityAttributeName.DocumentListtoJobfiling]).Id != null)
                    {
                        JobFilingGuid = ((EntityReference)PreImage.Attributes[DocumentListEntityAttributeName.DocumentListtoJobfiling]).Id;


                        DocumentList.LogicalName = DocumentListEntityAttributeName.EntityLogicalName;
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentListtoJobfiling, new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, JobFilingGuid));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentName, new EntityReference(DocumentTypeEntityAttributeName.EntityLogicalName, documentTypeGuid));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.ParentDocumentList, new EntityReference(DocumentListEntityAttributeName.EntityLogicalName, PreImage.Id));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentSource, PreImageDocumentSource);

                        if (PreImage.Attributes.Contains(DocumentListEntityAttributeName.ManuallySelected))
                        {
                            if (PreImage.Attributes[DocumentListEntityAttributeName.ManuallySelected] != null)
                                DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, Convert.ToBoolean(PreImage.Attributes[DocumentListEntityAttributeName.ManuallySelected]));
                        }
                        else
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.ManuallySelected, false);

                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.CreatedDueto, createdDueto);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.UploadedDate, Convert.ToDateTime(PreImage.Attributes[DocumentListEntityAttributeName.UploadedDate]));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequiredItemNumber, documentName);
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.RequestNumber, RequiredItemNumber);
                        if (RequiredItemNumber.ToLower().Contains("plan"))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(1));
                        }
                        else
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentCategory, new OptionSetValue(2));
                        }
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStatus, new OptionSetValue(PriortoStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentStatus, new OptionSetValue(RequiredStatus));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.PriortoStage, priortoStage);
                        if (response.Contains(DocumentTypeEntityAttributeName.DocumentClass))
                        {
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue(response.GetAttributeValue<OptionSetValue>(DocumentTypeEntityAttributeName.DocumentClass).Value));
                        }
                        else
                            DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentClass, new OptionSetValue((int)DcoumentClass.NonTechnical));
                        DocumentList.Attributes.Add(DocumentListEntityAttributeName.DocumentURL, PreImage.Attributes[DocumentListEntityAttributeName.DocumentURL].ToString());
                        crmTrace.AppendLine("End CreateDocumentlistVersions Method");
                        //throw new Exception("Test");
                    }
                }
                return DocumentList;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return DocumentList;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return DocumentList;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(PreImage.Id.ToString(), SourceChannel.CRM, "DocumentItemUploadHandler - CreateDocumentlistVersions", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return DocumentList;
            }



        } //CreateDocumentlistVersions methods ends here
      
    } // class ends here
} // namespace ends here
