﻿using System;
using System.Collections.Generic;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginLibrary.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class NoGoodCheckHandler : PluginHandlerBase
    {
        public static void NoGoodCheck(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {

            #region variable declarations
            //decimal newWorkFilingFee = 0;
            decimal amountDue = 0;
            bool? noGoodCheck = null;
            int noGoodCheckCount = 0;
            string phGuid = string.Empty;
            Guid thGuid = new Guid();
            EntityCollection getFeeParameterResponse = new EntityCollection();
            EntityCollection transCodesResponse = new EntityCollection();
            List<string> transCodesList = new List<string>();
            EntityReference jobFilingIdReference = new EntityReference();
            EntityReferenceCollection tHistory = new EntityReferenceCollection();
            decimal noGoodCheckFee = 0;
            #endregion
          
            try
            {
                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.AmountDue))
                    amountDue = ((Money)(targetEntity.Attributes[JobFilingEntityAttributeName.AmountDue])).Value;

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckFlag))
                    noGoodCheck = (bool)(targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckFlag]);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.NoGoodCheckCount))
                    noGoodCheckCount = (int)(targetEntity.Attributes[JobFilingEntityAttributeName.NoGoodCheckCount]);

                if (targetEntity.Attributes.Contains(JobFilingEntityAttributeName.PaymentHistoryGUID))
                    phGuid = targetEntity.Attributes[JobFilingEntityAttributeName.PaymentHistoryGUID].ToString();

                if (targetEntity.Id != null)
                    jobFilingIdReference = new EntityReference(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.Id);

                crmTrace.AppendLine("amount due " + amountDue + " no good check:" + noGoodCheck.ToString() + " nogood check count: " + noGoodCheckCount + " phguid" + phGuid.ToString());
                if (noGoodCheck == true && phGuid != null)
                {
                    getFeeParameterResponse = FeeCalculationHelper.GetFeeCalculatorParameters(FormulaeName.NoGoodCheckFee, service, crmTrace);

                    transCodesResponse = FeeCalculationHelper.RetrieveIntersectEntity(service, crmTrace, getFeeParameterResponse, targetEntity);

                    crmTrace.AppendLine(transCodesResponse.Entities.Count.ToString());
                    //Build Transaction codes
                      foreach (var transCodes in transCodesResponse.Entities)
                    {
                        transCodesList.Add(transCodes.Attributes[TransactionCodeAttributeNames.TransCode].ToString());
                    }
                    crmTrace.AppendLine("good check fee transaction code : " + transCodesList[0]);
                    #region create transaction history
                    foreach (var tcollection in transCodesResponse.Entities)
                    {
                        crmTrace.AppendLine("Bounce fee:" + getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce].ToString());
                        Entity transHistory = new Entity();
                        transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                        //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, jobFilingIdReference);
                        if (targetEntity.Contains(JobFilingEntityAttributeName.JobNumberAttributeName))
                            transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, targetEntity.Attributes[JobFilingEntityAttributeName.JobNumberAttributeName]);
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce].ToString());
                        thGuid = service.Create(transHistory);
                        crmTrace.AppendLine("Transaction history record created");
                    }
                    #endregion

                    #region Associate transaction history with Payment history
                    tHistory.Add(new EntityReference(TransactionHistoryAttributeNames.EntityLogicalName, thGuid));
                    service.Associate(PaymentHistoryAttributeNames.EntityLogicalName, new Guid(phGuid), new Relationship(PaymentHistoryAttributeNames.PaymentHistTransHistRelationShipName), tHistory);
                    crmTrace.AppendLine("Transaction History Record Successully ASsociated");
                    #endregion

                    #region Update Jobfiling with NoGoodCheck
                    noGoodCheckFee = decimal.Parse(getFeeParameterResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.CheckBounce].ToString()) * noGoodCheckCount;
                    crmTrace.AppendLine("No good check fee: " + noGoodCheckFee + " No good check count " + noGoodCheckCount);
                    Entity jobFilingEntity = new Entity();
                    jobFilingEntity.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                    jobFilingEntity.Id = targetEntity.Id;
                    jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFee, new Money(noGoodCheckFee));
                    jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.AmountDue, new Money((amountDue + noGoodCheckFee)));
                    jobFilingEntity.Attributes.Add(JobFilingEntityAttributeName.NoGoodCheckFlag, false);
                    service.Update(jobFilingEntity);
                    #endregion
                }

            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "NoGoodCheckHandler - NoGoodCheck", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }
    }
}

