﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DOBNYC.XRM.JobFiling.Helpers.SqlHelper;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;
using DOBNYC.XRM.JobFiling.PluginHandlers;
using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;
using DOBNYC.XRM.JobFiling.PluginLibrary.PluginHandlers;
using DOBNYC.XRM.JobFiling.PluginLibrary.Objects;
using Microsoft.Xrm.Sdk.Messages;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class WorkPermitNumberHandler : PluginHandlerBase
    {
        public static Entity GenerateWorkPermitNumber(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace)
        {
            string jobNumber = string.Empty; ;
            string filingNumber = string.Empty;
            string typeofPermit = string.Empty;
            int filingType;
            string borough = string.Empty;
            string secondaryIncrement = string.Empty;
            string workPermitformatString = "{0}-{1}-{2}";
            string workPermitformatString2 = "{0}-{1}-{2}-{3}";
            string secondaryPermitformatString = "{0}{1}-{2}-{3}";
            string secondaryPermitformatString2 = "{0}{1}-{2}-{3}-{4}";

            string workPermitFormatted = string.Empty;
            string secondaryPermitFormatted = string.Empty;


            try
            {
                crmTrace.AppendLine("Get Regarding Job Filing Guid");
                string[] Column_WorkPermit = new string[] { WorkPermitEntityAttributeName.GotoJobFiling, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus,
                WorkPermitEntityAttributeName.RenewalPermitWithChanges, WorkPermitEntityAttributeName.RenewalPermitWithOutChanges, WorkPermitEntityAttributeName.RenewalInitialPermitNo};
                Entity workPermitRecord = Retrieve(service, Column_WorkPermit, targetEntity.Id, WorkPermitEntityAttributeName.EntityLogicalName);
                Guid jobFilingGuid = ((EntityReference)workPermitRecord[WorkPermitEntityAttributeName.GotoJobFiling]).Id;
                string currentWorkPermitNumber = workPermitRecord.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber);
                string PermitString = "Permit is not yet issued";
                crmTrace.AppendLine("Regarding Job Filing Guid: " + jobFilingGuid.ToString());

                string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.BoroughAttributeName,
                   JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.Status, JobFilingEntityAttributeName.SupersedingRequestStatus, JobFilingEntityAttributeName.FilingType,
                   JobFilingEntityAttributeName.JobFilingId, JobFilingEntityAttributeName.JobDescription, JobFilingEntityAttributeName.SupersedingRequesterId, JobFilingEntityAttributeName.ProfessionalCertificate,
                   JobFilingEntityAttributeName.ApplicantPerson,  JobFilingEntityAttributeName.SupersedingWorkpermit, JobFilingEntityAttributeName.PlanApprovedDate};


                crmTrace.AppendLine("Retreive Regarding Job Filing Record");
                ConditionExpression jobFilingCondition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                EntityCollection response = RetrieveMultiple(service, JobFilingEntityAttributeName.EntityLogicalName, ColumnNames_JobFiling, new ConditionExpression[] { jobFilingCondition }, LogicalOperator.And);
                crmTrace.AppendLine("Retreived Regarding Job Filing Record");
                crmTrace.AppendLine("Regarding Job Filing response count:" + response.Entities.Count);

                if (response != null && response.Entities != null && response.Entities.Count > 0)
                {
                    jobNumber = response.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.JobNumberAttributeName);
                    filingNumber = response.Entities[0].GetAttributeValue<string>(JobFilingEntityAttributeName.FilingNumberAttributeName);
                    filingType = response.Entities[0].GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value;
                    bool profcert = response.Entities[0].GetAttributeValue<bool>(JobFilingEntityAttributeName.ProfessionalCertificate);
                    int filingStatus = response.Entities[0].GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;
                    borough = Enum.GetName(typeof(Borough), ((OptionSetValue)response.Entities[0].Attributes[JobFilingEntityAttributeName.BoroughAttributeName]).Value);
                    crmTrace.AppendLine("Retreived Regarding jobNumber:" + jobNumber);
                    crmTrace.AppendLine("Retreived Regarding filingNumber:" + filingNumber);
                    crmTrace.AppendLine("Retreived Regarding filingType:" + filingType);
                    int permitType = workPermitRecord.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                    crmTrace.AppendLine("permitType int value:" + permitType.ToString());
                    typeofPermit = GetPermitType(permitType);
                    crmTrace.AppendLine("Reterive Type of Permit: " + typeofPermit);

                    //if ((profcert == true) && (filingStatus == (int)CurrentFilingStatus.PreFiling ||filingStatus == (int)CurrentFilingStatus.DesignProfessionalReview ||filingStatus == (int)CurrentFilingStatus.PendingProfCertQAAssignment ||filingStatus == (int)CurrentFilingStatus.PendingProfCertQAReview ))
                    //{
                    //    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.ProfCertQAReview));
                    //}

                    // Set filing number for Accela use
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.FilingNumber, filingNumber);

                    #region Add Plan Approved Date
                    DateTime planApprovedDate_JF = response.Entities[0].Contains(JobFilingEntityAttributeName.PlanApprovedDate) ? response.Entities[0].GetAttributeValue<DateTime>(JobFilingEntityAttributeName.PlanApprovedDate).Date : DateTime.Now;
                    crmTrace.AppendLine("planApprovedDate_JF:" + planApprovedDate_JF.ToShortDateString());
                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PlanApprovedDate, Convert.ToDateTime(planApprovedDate_JF.Date.ToShortDateString()));


                    #endregion

                    // Check if the regarding Job has already a WorkPermit with same Type of Permit
                    crmTrace.AppendLine("Retreive Regarding Job Filing WorkPermits with same Type of Permit");
                    ConditionExpression workPermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new string[] { permitType.ToString() });
                    ConditionExpression workPermitCondition3 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.In, new string[] { ((int)WorkpermitStatus.PermitIssued).ToString(), ((int)WorkpermitStatus.PermitSignedoff).ToString() });
                    EntityCollection WorkPermitresponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitNumber }, new ConditionExpression[] { workPermitCondition1, workPermitCondition2, workPermitCondition3 }, LogicalOperator.And);
                    crmTrace.AppendLine("Retreived Regarding Job Filing WorkPermits with same Type of Permit");
                    crmTrace.AppendLine("Regarding Job Filing WorkPermits with same Type of Permit count:" + WorkPermitresponse.Entities.Count);

                    // If Primary Permit!!
                    if (WorkPermitresponse.Entities.Count == 0 || (workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges) || workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithChanges)))
                    {
                        #region Permit Number for Different Work Types
                        // IF PL
                        if (permitType == (int)TypeofPermit.Plumbing)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - PL");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                            }
                        }

                        // IF SD
                        if (permitType == (int)TypeofPermit.Standpipe)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - SD");
                            workPermitFormatted = String.Format(workPermitformatString2, jobNumber, filingNumber, "EW", typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SDCheck, true);

                            }
                        }

                        // IF SP
                        if (permitType == (int)TypeofPermit.Sprinkler)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - SP");
                            workPermitFormatted = String.Format(workPermitformatString2, jobNumber, filingNumber, "EW", typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SPCheck, true);
                            }
                        }

                        // IF AN
                        if (permitType == (int)TypeofPermit.Antenna)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - AN");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                            }
                        }

                        // IF CC
                        if (permitType == (int)TypeofPermit.CurbCut)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - CC");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                // CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                            }
                        }

                        // IF FAB4 Permit
                        if (permitType == (int)TypeofPermit.SupportedScaffold || permitType == (int)TypeofPermit.ConstructionFence || permitType == (int)TypeofPermit.Sign || permitType == (int)TypeofPermit.SideWalkShed)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - FAB4");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                //CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                            }
                        }

                        // IF BE
                        if (permitType == (int)TypeofPermit.BoilerEquipment)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - BE");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                            }
                        }

                        // IF MS
                        if (permitType == (int)TypeofPermit.Mechanical)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - MS");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                            }
                        }

                        // IF ST
                        if (permitType == (int)TypeofPermit.Structural)
                        {
                            crmTrace.AppendLine("Primary Work Permit! - ST");
                            workPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                            crmTrace.AppendLine("Primary workPermitFormatted: " + workPermitFormatted);
                            if (currentWorkPermitNumber == PermitString)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, workPermitFormatted);
                            }
                        }
                        #endregion

                        #region Set Sequence Number
                        if (!(workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges) || workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithChanges)))
                        {
                            crmTrace.AppendLine("Set Sequence Number 1 - Not renewal request");
                            CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                        }
                        else
                        {
                            crmTrace.AppendLine("Renewal request");
                            string intialPermitNumber = (workPermitRecord.Contains(WorkPermitEntityAttributeName.RenewalInitialPermitNo) && workPermitRecord.Attributes[WorkPermitEntityAttributeName.RenewalInitialPermitNo] != null) ? workPermitRecord.GetAttributeValue<string>(WorkPermitEntityAttributeName.RenewalInitialPermitNo) : "";
                            ConditionExpression cnd1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                            ConditionExpression cnd2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new string[] { permitType.ToString() });
                            ConditionExpression cnd3 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitNumber, ConditionOperator.Equal, new string[] { intialPermitNumber });
                            ConditionExpression cnd4 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.In, new string[] { ((int)WorkpermitStatus.PermitIssued).ToString(), ((int)WorkpermitStatus.PermitSignedoff).ToString() });
                            EntityCollection filtered_primary = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitNumber }, new ConditionExpression[] { cnd1, cnd2, cnd3, cnd4 }, LogicalOperator.And);

                            crmTrace.AppendLine("filtered_primary.Entities.Count: " + filtered_primary.Entities.Count);
                            if (filtered_primary.Entities.Count > 0)
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, filtered_primary.Entities.Count + 1);
                                if (intialPermitNumber != "")
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, intialPermitNumber);
                            }
                            else
                            {
                                CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                if (intialPermitNumber != "")
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, intialPermitNumber);

                            }

                        }
                        #endregion

                        //DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", null, crmTrace.ToString(), null, null);
                    }

                    // If Secondary Permit / Renewal Permits!!
                    if (WorkPermitresponse.Entities.Count > 0)
                    {
                        #region Secondary Permits
                        if (!(workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges) || workPermitRecord.GetAttributeValue<bool>(WorkPermitEntityAttributeName.RenewalPermitWithChanges)))
                        {
                            crmTrace.AppendLine("Not a renewal Work Permit!");
                            Random rnd = new Random();
                            int eightDigitRandom = rnd.Next(10000000, 99999999);
                            crmTrace.AppendLine("sixDigitRandom" + eightDigitRandom);
                            crmTrace.AppendLine("Secondary Work Permit!");
                            int workPermitCount = WorkPermitresponse.Entities.Count;
                            crmTrace.AppendLine("workPermitCount: " + workPermitCount);
                            //secondaryIncrement = GetIncementSequence(workPermitCount, crmTrace); Sequence not in used for now!!!!!
                            //crmTrace.AppendLine("secondaryIncrement: " + secondaryIncrement);

                            // IF PL
                            if (permitType == (int)TypeofPermit.Plumbing)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString, borough, eightDigitRandom.ToString(), filingNumber, typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                                }
                            }

                            // IF SD
                            if (permitType == (int)TypeofPermit.Standpipe)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString2, borough, eightDigitRandom.ToString(), filingNumber, "EW", typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SDCheck, true);

                                }
                            }

                            // IF SP
                            if (permitType == (int)TypeofPermit.Sprinkler)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString2, borough, eightDigitRandom.ToString(), filingNumber, "EW", typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SPCheck, true);

                                }

                            }


                            // IF AN
                            if (permitType == (int)TypeofPermit.Antenna)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString, borough, eightDigitRandom.ToString(), filingNumber, typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                    // CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                                }
                            }

                            // IF CC
                            if (permitType == (int)TypeofPermit.CurbCut)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString, borough, eightDigitRandom.ToString(), filingNumber, typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                    // CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.PLCheck, true);

                                }
                            }

                            // IF BE
                            if (permitType == (int)TypeofPermit.BoilerEquipment)
                            {
                                secondaryPermitFormatted = String.Format(workPermitformatString, jobNumber, filingNumber, typeofPermit);
                                
                                //For Boiler if it is secondary permit then add EW at the end
                                secondaryPermitFormatted = secondaryPermitFormatted + "-EW";
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                }
                            }

                            // IF MS
                            if (permitType == (int)TypeofPermit.Mechanical)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString, borough, eightDigitRandom.ToString(), filingNumber, typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                }
                            }

                            // IF ST
                            if (permitType == (int)TypeofPermit.Structural)
                            {
                                secondaryPermitFormatted = String.Format(secondaryPermitformatString, borough, eightDigitRandom.ToString(), filingNumber, typeofPermit);
                                crmTrace.AppendLine("Secondary workPermitFormatted: " + secondaryPermitFormatted);
                                if (currentWorkPermitNumber == PermitString)
                                {
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.WorkPermitNumber, secondaryPermitFormatted);
                                    CommonPluginLibrary.SetAttributeValue(targetEntity, WorkPermitEntityAttributeName.SequenceNumber, 1);
                                }
                            }
                        }

                        #endregion
                    }

                    //throw new Exception("Testing");
                }

                return targetEntity;

            } // try ends here

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return targetEntity;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - GenerateWorkPermitNumber", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return targetEntity;
            }


        }

        public static void WorkPermitIssued(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace, int workPermitStatus)
        {
            try
            {
                crmTrace.AppendLine("WorkPermitIssued Started!!");
                Entity Tentity = (Entity)preTargetEntity;
                crmTrace.AppendLine("Tentity: " + Tentity.LogicalName);
                Guid jobFilingGuid = ((EntityReference)Tentity[WorkPermitEntityAttributeName.GotoJobFiling]).Id;
                crmTrace.AppendLine("Regarding Job Filing Guid: " + jobFilingGuid.ToString());

                #region Associate Work Permits to Prof Cert QA Task
                if (workPermitStatus == (int)WorkpermitStatus.ProfCertQAReview || workPermitStatus == (int)WorkpermitStatus.L2ApprovedProfCertQAReview)
                {
                    string[] ColumnNames_JobFiling = new string[] {  JobFilingEntityAttributeName.FilingStatus};
                    Entity response = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);
                    int filingStatus = response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingStatus).Value;

                    if (filingStatus == (int)CurrentFilingStatus.ProfCertQAinReview || filingStatus == (int)CurrentFilingStatus.PendingProfCertQAReview || filingStatus == (int)CurrentFilingStatus.L2ApprovedProfCertQAReview)
                    {
                        ConditionExpression taskCondition1 = CreateConditionExpression(TaskEntityAttributeNames.RegardingObjectId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        ConditionExpression taskCondition2 = CreateConditionExpression(TaskEntityAttributeNames.StatusFieldName, ConditionOperator.Equal, new object[] { TaskEntitySatus.Open });
                        EntityCollection taskresponse = RetrieveMultiple(service, TaskEntityAttributeNames.EntityLogicalName, new string[] { TaskEntityAttributeNames.CurrentFilingStatus }, new ConditionExpression[] { taskCondition1, taskCondition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("Got all the Open Tasks");
                        crmTrace.AppendLine("taskresponse count: " + taskresponse.Entities.Count);
                        //crmTrace.AppendLine("taskresponse.Entities[0].Id: " + taskresponse.Entities[0].Id);
                        EntityReferenceCollection workPermits = new EntityReferenceCollection();
                        workPermits.Add(new EntityReference(WorkPermitEntityAttributeName.EntityLogicalName, targetEntity.Id));

                        if (taskresponse != null && taskresponse.Entities != null && taskresponse.Entities.Count > 0)
                        {
                            Guid taskID = taskresponse.Entities[0].Id;
                            crmTrace.AppendLine("taskID: " + taskID.ToString());

                            crmTrace.AppendLine("Start WorkPermit Association from  QA Documents");
                            service.Associate(TaskEntityAttributeNames.EntityLogicalName, taskID, new Relationship(TaskEntityAttributeNames.QAWorkPermitsRelationShipName), workPermits);
                            crmTrace.AppendLine("End WorkPermit Association from  QA Documents");
                         }

                    }
                }
                #endregion

                #region Permit Issued
                if (workPermitStatus == (int)WorkpermitStatus.PermitIssued)
                {
                   
                    // Retreive the Job Filing regarding which the permit is issued
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.FilingType, JobFilingEntityAttributeName.ParentJobFilingAttributeName, JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.HouseStreetAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.ProfessionalCertificate,
                    JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.SprinklerCheckBox, JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerWorkLegalization,JobFilingEntityAttributeName.StandPipeWorkType,JobFilingEntityAttributeName.ANCheckBox,JobFilingEntityAttributeName.CCCheckBox, JobFilingEntityAttributeName.SupportedScaffold, JobFilingEntityAttributeName.Sign,
                        JobFilingEntityAttributeName.SidewalkShed, JobFilingEntityAttributeName.ConstructionFence, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.workTypesTextbox};

                    //ConditionExpression Condition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    Entity response = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                    #region Check if PAA Work Permit is issued - Inactivate Initial Filing Primary permits
                    if (response.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.FilingType).Value == (int)FilingType.PAA)
                    {
                        crmTrace.AppendLine("Permit Issued is against a PAA");
                        if (response.Attributes.Contains(JobFilingEntityAttributeName.ParentJobFilingAttributeName) && response.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName) != null)
                        {
                            EntityReference initialJF = response.GetAttributeValue<EntityReference>(JobFilingEntityAttributeName.ParentJobFilingAttributeName);
                            Guid intialJFGuid = initialJF.Id;
                            crmTrace.AppendLine("intialJFGuid: " + intialJFGuid.ToString());
                            int typeofPermit = Tentity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                            crmTrace.AppendLine("typeofPermit: " + typeofPermit.ToString());
                            #region fetchXML
                            string fetchXML = @"<?xml version='1.0'?>
                                      <fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>
                                       <entity name='dobnyc_workpermit'>
                                        <attribute name='dobnyc_workpermitid' />
                                        <attribute name='dobnyc_name' />
                                        <attribute name='createdon' />
                                        <attribute name='dobnyc_permitissueddate' />
                                        <order attribute='dobnyc_permitissueddate' descending='true' />
                                        <filter type='and'>
                                          <condition attribute='dobnyc_wp_typeofpermit' operator='eq' value=' " + typeofPermit + @" ' />
                                          <condition attribute='dobnyc_workpermittojobfilingrelationshid' operator='eq' uitype='dobnyc_jobfiling' value='" + intialJFGuid + @"' />
                                          <condition attribute='dobnyc_workpermit_status' operator='in'>
                                            <value>10</value>
                                            <value>13</value>
                                            <value>4</value>
                                            <value>12</value>
                                            <value>7</value>
                                            <value>11</value>
                                          </condition>
                                        </filter>
                                      </entity>
                                    </fetch>";
                            #endregion
                            crmTrace.AppendLine("fetchXML: " + fetchXML);
                            EntityCollection WPresponse = service.RetrieveMultiple(new FetchExpression(fetchXML));

                            if (WPresponse.Entities != null && WPresponse.Entities.Count > 0)
                            {
                                crmTrace.AppendLine("WPresponse.Entities.Count: " + WPresponse.Entities.Count);
                                string currentWorkPermitNo = targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.WorkPermitNumber) ? targetEntity.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber) : string.Empty;
                                crmTrace.AppendLine("currentWorkPermitNo: " + currentWorkPermitNo);
                                if (currentWorkPermitNo != string.Empty)
                                {
                                    bool iscurrentprimary = CheckifPrimaryPermit(currentWorkPermitNo, crmTrace);
                                    crmTrace.AppendLine("iscurrentprimary: " + iscurrentprimary);
                                    if (!iscurrentprimary)
                                    {
                                        foreach (Entity wp in WPresponse.Entities)
                                        {
                                            wp.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitInactive));
                                            service.Update(wp);
                                        }
                                    }
                                    else
                                    {
                                        foreach (Entity wp in WPresponse.Entities)
                                        {
                                            string workPermitNumber = wp.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber);
                                            crmTrace.AppendLine("workPermitNumber: " + workPermitNumber);
                                            bool isprimary = CheckifPrimaryPermit(workPermitNumber, crmTrace);
                                            if (isprimary)
                                            {
                                                wp.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitStatus, new OptionSetValue((int)WorkpermitStatus.PermitInactive));
                                                service.Update(wp);
                                            }

                                        }
                                    }
                                }


                            }

                        }
                    }
                    #endregion

                    #region Send Emails to Progress Inspectors and Special Inspectors - Commented out 5/18/2019 SI PI are added in the same emails
                    //string[] ColumnNames_Progress = new string[] { ProgressInspectionCategoryAttributeNames.ProgressInspector };
                    //ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                    //ConditionExpression progressInspCondition2 = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.ProgressInspector, ConditionOperator.NotNull, new string[] { });
                    //EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ColumnNames_Progress, new ConditionExpression[] { progressInspCondition, progressInspCondition2 }, LogicalOperator.And);
                    //crmTrace.AppendLine("progressInspResponse.Entities.Count: " + progressInspResponse.Entities.Count);
                    //if (progressInspResponse != null && progressInspResponse.Entities.Count > 0)
                    //{
                    //    foreach (Entity prgInspection in progressInspResponse.Entities)
                    //    {
                    //        crmTrace.AppendLine("Start ProgressInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    //        EmailHandler.ProgressInspectorEmail_PermitIssued(service, prgInspection, response, Tentity, crmTrace);
                    //        crmTrace.AppendLine("End ProgressInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    //    }
                    //}

                    //string[] ColumnNames_Special = new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspector };
                    //ConditionExpression SpecialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                    //ConditionExpression SpecialInspCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspector, ConditionOperator.NotNull, new string[] { });
                    //EntityCollection SpecialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, ColumnNames_Special, new ConditionExpression[] { SpecialInspCondition, SpecialInspCondition2 }, LogicalOperator.And);
                    //crmTrace.AppendLine("SpecialInspResponse.Entities.Count: " + SpecialInspResponse.Entities.Count);
                    //if (SpecialInspResponse != null && SpecialInspResponse.Entities.Count > 0)
                    //{
                    //    foreach (Entity spclInspection in SpecialInspResponse.Entities)
                    //    {
                    //        crmTrace.AppendLine("Start SpecialInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    //        EmailHandler.SpecialInspectorEmail_PermitIssued(service, spclInspection, response, Tentity, crmTrace);
                    //        crmTrace.AppendLine("End SpecialInspectorEmail_PermitIssued Email: " + PluginHelperStrings.CreateMessageName);
                    //    }
                    //}

                    #endregion

                    #region Expire Old Permits
                    int typeOfPermit = ((OptionSetValue)preTargetEntity.Attributes[WorkPermitEntityAttributeName.TypeofPermit]).Value;
                    crmTrace.AppendLine("Type of permit " + typeOfPermit.ToString());
                    ConditionExpression matchJfGuid = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    ConditionExpression matchWorkType = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new string[] { typeOfPermit.ToString() });
                    ConditionExpression excludeCurrentPermit = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitId, ConditionOperator.NotEqual, new string[] { targetEntity.Id.ToString() });
                    crmTrace.AppendLine("Started getting permits to expire");
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                    EntityCollection permitsToExpire = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.WorkPermitId }, new ConditionExpression[] { matchJfGuid, matchWorkType, excludeCurrentPermit }, LogicalOperator.And);
                    crmTrace.AppendLine("Ended getting permits to expire");
                    DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                    if (permitsToExpire != null && permitsToExpire.Entities.Count > 0)
                    {
                        crmTrace.AppendLine("Number of permits to expire : " + permitsToExpire.Entities.Count);
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                        EntityCollection expireRenewalsCollection = new EntityCollection();
                        foreach (var permit in permitsToExpire.Entities)
                        {
                            Entity permitToExpire = new Entity(WorkPermitEntityAttributeName.EntityLogicalName);
                            permitToExpire.Id = new Guid(permit.Id.ToString());
                            crmTrace.AppendLine("guid : " + permit.Id.ToString());
                            DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                            permitToExpire.SetAttributeValue(WorkPermitEntityAttributeName.IsPermitExpired, true);
                            expireRenewalsCollection.Entities.Add(permitToExpire);
                        }
                        if (expireRenewalsCollection != null && expireRenewalsCollection.Entities.Count > 0)
                        {
                            List<string> guidsList = new List<string>();
                            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
                            {
                                Settings = new ExecuteMultipleSettings()
                                {
                                    ContinueOnError = false,
                                    ReturnResponses = true
                                },
                                Requests = new OrganizationRequestCollection()
                            };
                            foreach (var entity in expireRenewalsCollection.Entities)
                            {
                                UpdateRequest uploadRequest = new UpdateRequest { Target = entity };
                                requestWithResults.Requests.Add(uploadRequest);
                            }
                            crmTrace.AppendLine("Started expiring");
                            DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                            ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)service.Execute(requestWithResults);
                            crmTrace.AppendLine("Ended expiring");
                            DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                        }
                    }
                    #endregion Expire Old Permits

                    #region Set Permit Expiry dates
                    if (Tentity.Contains(WorkPermitEntityAttributeName.LicenseeType))
                    {
                        EntityReference licensee = Tentity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.LicenseeType);
                        Entity Licensee = service.Retrieve(LicenseeEntityAttributeName.EntityLogicalName, licensee.Id, new ColumnSet(LicenseeEntityAttributeName.Name));
                        string licenseType = Licensee.GetAttributeValue<string>(LicenseeEntityAttributeName.Name);
                        crmTrace.AppendLine("licenseType: " + licenseType);
                        if (licenseType.Contains(LicenseType.PR))
                        {
                            #region License Type PR
                            crmTrace.AppendLine("License Type PR");
                            DateTime dt = DateTime.Now;
                            targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = dt.AddYears(1).Date;
                            service.Update(targetEntity);
                            #endregion

                        }
                        else if (licenseType.Contains(LicenseType.PE) || licenseType.Contains(LicenseType.RA) || licenseType.Contains(LicenseType.LA))
                        {
                            #region License Type PE/RA/LA
                            crmTrace.AppendLine("License Type PE/RA/LA");
                            DateTime Liability_dt = Tentity.Contains(WorkPermitEntityAttributeName.LiabilityInsuranceExpDate) ? Tentity.GetAttributeValue<DateTime>(WorkPermitEntityAttributeName.LiabilityInsuranceExpDate).Date : DateTime.Now.Date;
                            crmTrace.AppendLine("Liability_dt: " + Liability_dt.ToString());
                            DateTime WorkerComp_dt = Tentity.Contains(WorkPermitEntityAttributeName.WorkerCompInsuranceExpDate) ? Tentity.GetAttributeValue<DateTime>(WorkPermitEntityAttributeName.WorkerCompInsuranceExpDate).Date : DateTime.Now.Date;
                            crmTrace.AppendLine("WorkerComp_dt: " + WorkerComp_dt.ToString());
                            DateTime DiabilityIns_dt = Tentity.Contains(WorkPermitEntityAttributeName.DisabilityInsuranceExpDate) ? Tentity.GetAttributeValue<DateTime>(WorkPermitEntityAttributeName.DisabilityInsuranceExpDate).Date : DateTime.Now.Date;
                            crmTrace.AppendLine("DiabilityIns_dt: " + DiabilityIns_dt.ToString());
                            DateTime dt = DateTime.Now;
                            List<DateTime> dt_list = new List<DateTime>();
                            dt_list.Add(Liability_dt);
                            dt_list.Add(WorkerComp_dt);
                            dt_list.Add(DiabilityIns_dt);
                            DateTime min_dt = dt_list.Min<DateTime>().Date;
                            crmTrace.AppendLine("min_dt: " + Convert.ToDateTime(min_dt.ToShortDateString()));

                            if (min_dt.Date < dt.AddYears(1).Date)
                                targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = Convert.ToDateTime(min_dt.ToShortDateString());
                            else
                                targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = dt.AddYears(1).Date;
                            service.Update(targetEntity);
                            #endregion
                        }
                        else
                        {
                            #region Call BIS to get latest insurance information - Added 09/07/2018
                            crmTrace.AppendLine("Call BIS to get latest insurance information");
                            ExternalSystem_LicenseValidation LL = new ExternalSystem_LicenseValidation();
                            LicenseValidationRequest request = new LicenseValidationRequest();
                            LicenseValidationReponse LResponse = new LicenseValidationReponse();
                            string LNumber = licenseType.Substring(licenseType.IndexOf("-") + 1, licenseType.Length - (licenseType.IndexOf("-") + 1)).Trim();
                            crmTrace.AppendLine("LNumber: " + LNumber);
                            string LType = licenseType.Substring(0, licenseType.IndexOf("-")).Replace(" ", String.Empty);
                            crmTrace.AppendLine("LType: " + LType);
                            request.LicenseNumber = LNumber;
                            request.LicenseType = LType == "GC" ? "G" : LType;
                            LResponse = LL.GetLicenseDetails(request);

                            if (LResponse != null && LResponse.LicenseNumber != null)
                            {
                                crmTrace.AppendLine("Got BIS Response");
                                DateTime Liability_dt = DateTime.Now.Date;
                                DateTime WorkerComp_dt = DateTime.Now.Date;
                                DateTime DiabilityIns_dt = DateTime.Now.Date;
                                DateTime LicenseExp_dt = DateTime.Now.Date;

                                crmTrace.AppendLine("LResponse.BusinessName1: " + LResponse.BusinessName1);
                                crmTrace.AppendLine("LResponse.BusinessName2: " + LResponse.BusinessName2);
                                crmTrace.AppendLine("CRM Business: " + Tentity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.BusinessNameLookup).Name);

                                #region Business 1
                                if (LResponse.BusinessName1 == Tentity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.BusinessNameLookup).Name)
                                {
                                    crmTrace.AppendLine("Business 1");
                                    #region LiabilityInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.LiabilityInsuranceName] = LResponse.CompanyName_GLI_1;
                                    if (LResponse.ExpirationDate_GLI_1 != null)
                                    {
                                        string date = LResponse.ExpirationDate_GLI_1;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.LiabilityInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                Liability_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("Liability_dt: " + Liability_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region WorkerCompInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.WorkerCompInsuranceName] = LResponse.CompanyName_WCI_1;
                                    if (LResponse.ExpirationDate_WCI_1 != null)
                                    {
                                        string date = LResponse.ExpirationDate_WCI_1;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.WorkerCompInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                WorkerComp_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("WorkerComp_dt: " + WorkerComp_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region DisabilityInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.DisabilityInsuranceName] = LResponse.CompanyName_DIS_1;
                                    if (LResponse.ExpirationDate_DIS_1 != null)
                                    {
                                        string date = LResponse.ExpirationDate_DIS_1;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.DisabilityInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                DiabilityIns_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("DiabilityIns_dt: " + DiabilityIns_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region LicenseExpiry
                                    if (LResponse.EXPIRE_DATE != null)
                                    {
                                        string date = LResponse.EXPIRE_DATE;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                LicenseExp_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("LicenseExp_dt: " + LicenseExp_dt.ToString());
                                                #region Update Applicant License Expiration and Status -April 2019 release for emails
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.ApplicantLicenseExpirationDate] = LicenseExp_dt;
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.ApplicantLicenseStatus] = (LResponse.Status != null) ? LResponse.Status : string.Empty;
                                                #endregion
                                            }
                                        }
                                    }
                                    #endregion

                                    #region Min date validations
                                    DateTime dt = DateTime.Now;
                                    List<DateTime> dt_list = new List<DateTime>();
                                    dt_list.Add(Liability_dt);
                                    dt_list.Add(WorkerComp_dt);
                                    dt_list.Add(DiabilityIns_dt);
                                    dt_list.Add(LicenseExp_dt);
                                    DateTime min_dt = dt_list.Min<DateTime>().Date;
                                    crmTrace.AppendLine("min_dt: " + Convert.ToDateTime(min_dt.ToShortDateString()));

                                    if (min_dt.Date < dt.AddYears(1).Date)
                                        targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = Convert.ToDateTime(min_dt.ToShortDateString());
                                    else
                                        targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = dt.AddYears(1).Date;
                                    #endregion

                                    service.Update(targetEntity);
                                }
                                #endregion

                                #region Business 2
                                if (LResponse.BusinessName2 == Tentity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.BusinessNameLookup).Name)
                                {
                                    #region LiabilityInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.LiabilityInsuranceName] = LResponse.CompanyName_GLI_2;
                                    if (LResponse.ExpirationDate_GLI_2 != null)
                                    {
                                        string date = LResponse.ExpirationDate_GLI_2;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.LiabilityInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                Liability_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("Liability_dt: " + Liability_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region WorkerCompInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.WorkerCompInsuranceName] = LResponse.CompanyName_WCI_2;
                                    if (LResponse.ExpirationDate_WCI_2 != null)
                                    {
                                        string date = LResponse.ExpirationDate_WCI_2;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.WorkerCompInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                WorkerComp_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("WorkerComp_dt: " + WorkerComp_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region DisabilityInsurance
                                    targetEntity.Attributes[WorkPermitEntityAttributeName.DisabilityInsuranceName] = LResponse.CompanyName_DIS_2;
                                    if (LResponse.ExpirationDate_DIS_2 != null)
                                    {
                                        string date = LResponse.ExpirationDate_DIS_2;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                targetEntity.Attributes[WorkPermitEntityAttributeName.DisabilityInsuranceExpDate] = Convert.ToDateTime(ConvertToCRMFormat(formatedDate));
                                                DiabilityIns_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("DiabilityIns_dt: " + DiabilityIns_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region LicenseExpiry
                                    if (LResponse.EXPIRE_DATE != null)
                                    {
                                        string date = LResponse.EXPIRE_DATE;
                                        string formatedDate = null;
                                        if (date.Length == 8)
                                        {
                                            formatedDate = date.Insert(4, "/").Insert(7, "/");
                                            if (!(formatedDate.Contains(@"0000")))
                                            {
                                                LicenseExp_dt = Convert.ToDateTime(ConvertToCRMFormat(formatedDate)).Date;
                                                crmTrace.AppendLine("LicenseExp_dt: " + LicenseExp_dt.ToString());
                                            }
                                        }
                                    }
                                    #endregion

                                    #region Min date validations
                                    DateTime dt = DateTime.Now;
                                    List<DateTime> dt_list = new List<DateTime>();
                                    dt_list.Add(Liability_dt);
                                    dt_list.Add(WorkerComp_dt);
                                    dt_list.Add(DiabilityIns_dt);
                                    dt_list.Add(LicenseExp_dt);
                                    DateTime min_dt = dt_list.Min<DateTime>().Date;
                                    crmTrace.AppendLine("min_dt: " + Convert.ToDateTime(min_dt.ToShortDateString()));

                                    if (min_dt.Date < dt.AddYears(1).Date)
                                        targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = Convert.ToDateTime(min_dt.ToShortDateString());
                                    else
                                        targetEntity.Attributes[WorkPermitEntityAttributeName.PermitExprirationDate] = dt.AddYears(1).Date;
                                    #endregion

                                    service.Update(targetEntity);
                                }
                                #endregion
                            }
                            #endregion
                        }
                        DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - LicenseeType", null, crmTrace.ToString(), null, null);
                    }
                    #endregion

                    bool isHistoricFiling = response.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.IsHistoricJobFiling]) : false;
                    crmTrace.AppendLine("isHistoricFiling: " + isHistoricFiling);
                    string WorkTypes = response.Attributes[JobFilingEntityAttributeName.PlumbingCheckBox].ToString();
                    crmTrace.AppendLine("WorkTypes: " + WorkTypes);
                    FeeCalculationObject targetFCObject = new FeeCalculationObject();
                    FeeCalculationStandardizationHandler.setWorktypeFlagsinFeeObject(response, targetFCObject, crmTrace);

                    if (isHistoricFiling)
                    {
                        crmTrace.AppendLine("Historic Filing..");
                        bool Plumbing = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.PlumbingCheckBox]);
                        bool Sprinkler = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SprinklerCheckBox]);
                        bool Plumbing_Leg = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.PlumbingWorkLegalization]);
                        bool Sprinkler_Leg = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SprinklerWorkLegalization]);
                        bool Standpipe = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.StandPipeWorkType]);
                        bool Antenna = response.Contains(JobFilingEntityAttributeName.ANCheckBox) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.ANCheckBox]) : false;
                        bool CurbCut = response.Contains(JobFilingEntityAttributeName.CCCheckBox) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.CCCheckBox]) : false;
                        bool SupportedScaffold = response.Contains(JobFilingEntityAttributeName.SupportedScaffold) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SupportedScaffold]) : false;
                        bool Sign = response.Contains(JobFilingEntityAttributeName.Sign) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.Sign]) : false;
                        bool ConstructionFence = response.Contains(JobFilingEntityAttributeName.ConstructionFence) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.ConstructionFence]) : false;
                        bool SidewalkShed = response.Contains(JobFilingEntityAttributeName.SidewalkShed) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SidewalkShed]) : false;
                        crmTrace.AppendLine("Plumbing: " + Plumbing);
                        crmTrace.AppendLine("Sprinkler: " + Sprinkler);
                        crmTrace.AppendLine("Plumbing_Leg: " + Plumbing_Leg);
                        crmTrace.AppendLine("Sprinkler_Leg: " + Sprinkler_Leg);
                        crmTrace.AppendLine("Standpipe: " + Standpipe);
                        crmTrace.AppendLine("Antenna: " + Antenna);
                        crmTrace.AppendLine("CurbCut: " + CurbCut);
                        crmTrace.AppendLine("SidewalkShed: " + SidewalkShed);
                        crmTrace.AppendLine("ConstructionFence: " + ConstructionFence);
                        crmTrace.AppendLine("Sign: " + Sign);
                        crmTrace.AppendLine("SupportedScaffold: " + SupportedScaffold);

                        string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.NoWorkCheckBox };
                        ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.In, new string[] { ((int)WorkpermitStatus.PermitIssued).ToString(), ((int)WorkpermitStatus.PermitSignedoff).ToString() });
                        EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition, workPermitCondition2 }, LogicalOperator.And);
                        bool PlubmingPermitIssued = false;
                        bool SprinklerPermitIssued = false;
                        bool SprinklerLegPermitIssued = false;
                        bool PlubmingLegPermitIssued = false;
                        bool StandpipeIssued = false;
                        bool AntennaIssued = false;
                        bool CurbCutIssued = false;
                        bool SidewalkShedIssued = false;
                        bool ConstructionFenceIssued = false;
                        bool SignIssued = false;
                        bool SupportedScaffoldIssued = false;

                        if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                        {
                            for (int i = 0; i < workPermitResponse.Entities.Count; i++)  // check if Progress Inspection Catagory entity contains Field mapping (schema name of the field that requires doc)
                            {
                                Entity entity = (Entity)workPermitResponse.Entities[i];
                                int typeofPermit = entity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                                bool NoWork_CheckBox = entity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.NoWorkCheckBox);
                                crmTrace.AppendLine("NoWork_CheckBox: " + NoWork_CheckBox);

                                if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == false)
                                    PlubmingPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == false)
                                    SprinklerPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == true)
                                    PlubmingLegPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == true)
                                    SprinklerLegPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Standpipe && NoWork_CheckBox == false)
                                    StandpipeIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Antenna)
                                    AntennaIssued = true;
                                if (typeofPermit == (int)TypeofPermit.CurbCut)
                                    CurbCutIssued = true;
                                if (typeofPermit == (int)TypeofPermit.SideWalkShed)
                                    SidewalkShedIssued = true;
                                if (typeofPermit == (int)TypeofPermit.ConstructionFence)
                                    ConstructionFenceIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sign)
                                    SignIssued = true;
                                if (typeofPermit == (int)TypeofPermit.SupportedScaffold)
                                    SupportedScaffoldIssued = true;
                            }

                            //if (PlubmingPermitIssued == true && SprinklerPermitIssued == true && StandpipeIssued == true)
                            //{
                            //    for (int i = 0; i < workPermitResponse.Entities.Count; i++)  // check if Progress Inspection Catagory entity contains Field mapping (schema name of the field that requires doc)
                            //    {
                            //        crmTrace.AppendLine("Start Updating Workpermit: " + i);
                            //        Entity entity = (Entity)workPermitResponse.Entities[i];
                            //        Guid permitGuid = entity.Id;

                            //        Entity workPermit = new Entity();
                            //        workPermit.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                            //        workPermit.Attributes.Add(WorkPermitEntityAttributeName.WorkPermitId, permitGuid);
                            //        workPermit.Attributes.Add(WorkPermitEntityAttributeName.PLCheck, true);
                            //        workPermit.Attributes.Add(WorkPermitEntityAttributeName.SPCheck, true);
                            //        workPermit.Attributes.Add(WorkPermitEntityAttributeName.SDCheck, true);
                            //        service.Update(workPermit);
                            //        crmTrace.AppendLine("End Updating Workpermit: " + i);
                            //    }
                            //}
                        }


                        crmTrace.AppendLine("PlubmingPermitIssued: " + PlubmingPermitIssued);
                        crmTrace.AppendLine("SprinklerPermitIssued: " + SprinklerPermitIssued);
                        crmTrace.AppendLine("SprinklerLegPermitIssued: " + SprinklerLegPermitIssued);
                        crmTrace.AppendLine("PlubmingLegPermitIssued: " + PlubmingLegPermitIssued);
                        crmTrace.AppendLine("StandpipeIssued: " + StandpipeIssued);
                        crmTrace.AppendLine("AntennaIssued: " + AntennaIssued);
                        crmTrace.AppendLine("CurbCutIssued: " + CurbCutIssued);
                        crmTrace.AppendLine("SidewalkShedIssued: " + SidewalkShedIssued);
                        crmTrace.AppendLine("ConstructionFenceIssued: " + ConstructionFenceIssued);
                        crmTrace.AppendLine("SignIssued: " + SignIssued);
                        crmTrace.AppendLine("SupportedScaffoldIssued: " + SupportedScaffoldIssued);

                        crmTrace.AppendLine("Atleast one Plumbing and Sprinkler permit have been issued ");
                        crmTrace.AppendLine("Update the Filing Status to Permit Entire");
                        Entity jobFiling = new Entity();
                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);

                        if (Plumbing == PlubmingPermitIssued && Sprinkler == SprinklerPermitIssued && Plumbing_Leg == PlubmingLegPermitIssued && Sprinkler_Leg == SprinklerLegPermitIssued && Standpipe == StandpipeIssued && Antenna == AntennaIssued && CurbCut == CurbCutIssued &&
                            SupportedScaffold == SupportedScaffoldIssued && Sign == SignIssued && ConstructionFence == ConstructionFenceIssued && SidewalkShed == SidewalkShedIssued)
                        {
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntire));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }
                        else
                        {
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitIssued));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }

                    }
                    else
                    {
                        string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.NoWorkCheckBox };
                        ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.In, new string[] { ((int)WorkpermitStatus.PermitIssued).ToString(), ((int)WorkpermitStatus.PermitSignedoff).ToString() });
                        EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition, workPermitCondition2 }, LogicalOperator.And);
                        bool PlubmingPermitIssued = false;
                        bool SprinklerPermitIssued = false;
                        bool SprinklerLegPermitIssued = false;
                        bool PlubmingLegPermitIssued = false;
                        bool StandpipeIssued = false;
                        bool AntennaIssued = false;
                        bool CurbCutIssued = false;
                        bool SidewalkShedIssued = false;
                        bool ConstructionFenceIssued = false;
                        bool SignIssued = false;
                        bool SupportedScaffoldIssued = false;
                        bool BoilerIssued = false;
                        bool MechanicalIssued = false;
                        bool StructuralIssued = false;
                        bool GCMHSTIssued = false;
                        bool GCMHIssued = false;
                        bool GCSTIssued = false;
                        bool GCIssued = false;

                        if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                        {
                            for (int i = 0; i < workPermitResponse.Entities.Count; i++)  // check if Progress Inspection Catagory entity contains Field mapping (schema name of the field that requires doc)
                            {
                                Entity entity = (Entity)workPermitResponse.Entities[i];
                                int typeofPermit = entity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                                bool NoWork_CheckBox = entity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.NoWorkCheckBox);
                                crmTrace.AppendLine("NoWork_CheckBox: " + NoWork_CheckBox);

                                if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == false)
                                    PlubmingPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == false)
                                    SprinklerPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == true)
                                    PlubmingLegPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == true)
                                    SprinklerLegPermitIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Standpipe && NoWork_CheckBox == false)
                                    StandpipeIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Antenna)
                                    AntennaIssued = true;
                                if (typeofPermit == (int)TypeofPermit.CurbCut)
                                    CurbCutIssued = true;
                                if (typeofPermit == (int)TypeofPermit.SideWalkShed)
                                    SidewalkShedIssued = true;
                                if (typeofPermit == (int)TypeofPermit.ConstructionFence)
                                    ConstructionFenceIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Sign)
                                    SignIssued = true;
                                if (typeofPermit == (int)TypeofPermit.SupportedScaffold)
                                    SupportedScaffoldIssued = true;
                                if (typeofPermit == (int)TypeofPermit.BoilerEquipment)
                                    BoilerIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Mechanical)
                                    MechanicalIssued = true;
                                if (typeofPermit == (int)TypeofPermit.Structural)
                                    StructuralIssued = true;
                                if (typeofPermit == (int)TypeofPermit.GCMHST)
                                    GCMHSTIssued = true;
                                if (typeofPermit == (int)TypeofPermit.GCMH)
                                    GCMHIssued = true;
                                if (typeofPermit == (int)TypeofPermit.GCST)
                                    GCSTIssued = true;
                                if (typeofPermit == (int)TypeofPermit.GeneralConstruction)
                                    GCIssued = true;
                            }
                        }

                        crmTrace.AppendLine("Plubming: " + targetFCObject.IsPL);
                        crmTrace.AppendLine("PlubmingPermitIssued: " + PlubmingPermitIssued);
                        crmTrace.AppendLine("Sprinkler: " + targetFCObject.IsSP);
                        crmTrace.AppendLine("SprinklerPermitIssued: " + SprinklerPermitIssued);
                        crmTrace.AppendLine("SprinklerLeg: " + targetFCObject.IsSP);
                        crmTrace.AppendLine("SprinklerLegPermitIssued: " + SprinklerLegPermitIssued);
                        crmTrace.AppendLine("PlubmingLeg: " + targetFCObject.IsPL);
                        crmTrace.AppendLine("PlubmingLegPermitIssued: " + PlubmingLegPermitIssued);
                        crmTrace.AppendLine("Standpipe: " + targetFCObject.IsSD);
                        crmTrace.AppendLine("StandpipeIssued: " + StandpipeIssued);
                        crmTrace.AppendLine("AN: " + targetFCObject.IsAN);
                        crmTrace.AppendLine("AntennaIssued: " + AntennaIssued);
                        crmTrace.AppendLine("CC: " + targetFCObject.IsCC);
                        crmTrace.AppendLine("CurbCutIssued: " + CurbCutIssued);
                        crmTrace.AppendLine("SidewalkShed: " + targetFCObject.IsSH);
                        crmTrace.AppendLine("SidewalkShedIssued: " + SidewalkShedIssued);
                        crmTrace.AppendLine("FN: " + targetFCObject.IsFN);
                        crmTrace.AppendLine("ConstructionFenceIssued: " + ConstructionFenceIssued);
                        crmTrace.AppendLine("SG: " + targetFCObject.IsSG);
                        crmTrace.AppendLine("SignIssued: " + SignIssued);
                        crmTrace.AppendLine("Scaffold: " + targetFCObject.IsSF);
                        crmTrace.AppendLine("SupportedScaffoldIssued: " + SupportedScaffoldIssued);
                        crmTrace.AppendLine("BE: " + targetFCObject.IsBE);
                        crmTrace.AppendLine("BoilerIssued: " + BoilerIssued);
                        crmTrace.AppendLine("MS: " + targetFCObject.IsMS);
                        crmTrace.AppendLine("MechanicalIssued: " + MechanicalIssued);
                        crmTrace.AppendLine("ST: " + targetFCObject.IsST);
                        crmTrace.AppendLine("StructuralIssued: " + StructuralIssued);
                        crmTrace.AppendLine("GC: " + targetFCObject.IsGC);
                        crmTrace.AppendLine("GCIssued: " + GCIssued);

                        crmTrace.AppendLine("Atleast one Plumbing and Sprinkler permit have been issued ");
                        crmTrace.AppendLine("Update the Filing Status to Permit Entire");
                        Entity jobFiling = new Entity();
                        jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                        jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);

                        if (targetFCObject.IsPL == PlubmingPermitIssued && targetFCObject.IsSP == SprinklerPermitIssued && targetFCObject.IsSD == StandpipeIssued && targetFCObject.IsAN == AntennaIssued && targetFCObject.IsCC == CurbCutIssued
                            && targetFCObject.IsSF == SupportedScaffoldIssued && targetFCObject.IsSG == SignIssued && targetFCObject.IsFN == ConstructionFenceIssued && targetFCObject.IsSH == SidewalkShedIssued
                            && targetFCObject.IsBE == BoilerIssued && targetFCObject.IsMS == MechanicalIssued && targetFCObject.IsST == StructuralIssued && targetFCObject.IsGC==GCIssued)
                        {
                            crmTrace.AppendLine("Update Status to Permit Entire");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntire));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }
                        else if ((targetFCObject.IsGC == GCIssued || targetFCObject.IsGC == GCMHSTIssued || targetFCObject.IsGC == GCMHIssued || targetFCObject.IsGC == GCSTIssued))
                        {
                            crmTrace.AppendLine("Update Status to Permit Entire");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntire));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }
                        else if ((PlubmingLegPermitIssued && (targetFCObject.IsPL == PlubmingLegPermitIssued)) || (SprinklerLegPermitIssued && (targetFCObject.IsSP == SprinklerLegPermitIssued)))
                        {
                            crmTrace.AppendLine("Update Legalization Status to Permit Entire");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitEntire));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }
                        else
                        {
                            crmTrace.AppendLine("Update the Filing Status  to Permit Issued");
                            jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.PermitIssued));
                            service.Update(jobFiling);
                            crmTrace.AppendLine("Update the Filing Status  End");
                        }
                    }
                    SubmitHandler.CreateBuildTrace(service, targetEntity, preTargetEntity, "Permit Issued", crmTrace);
                    //throw new Exception("aqib");
                }
                #endregion

              //  DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued--Test ", null, crmTrace.ToString(), null, null);

                #region Permit Sign off QA Failed
                //if (workPermitStatus == (int)WorkpermitStatus.ObjectionstoSignoff)
                //{
                //    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.HouseStreetAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.ProfessionalCertificate,
                //    JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.SprinklerCheckBox, JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerWorkLegalization};
                //    Entity response = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                //    #region Send Emails to Progress Inspectors and Special Inspectors
                //    string[] ColumnNames_Progress = new string[] { ProgressInspectionCategoryAttributeNames.ProgressInspector };
                //    ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                //    ConditionExpression progressInspCondition2 = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.ProgressInspector, ConditionOperator.NotNull, new string[] { });
                //    EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ColumnNames_Progress, new ConditionExpression[] { progressInspCondition, progressInspCondition2 }, LogicalOperator.And);
                //    crmTrace.AppendLine("progressInspResponse.Entities.Count: " + progressInspResponse.Entities.Count);
                //    if (progressInspResponse != null && progressInspResponse.Entities.Count > 0)
                //    {
                //        foreach (Entity prgInspection in progressInspResponse.Entities)
                //        {
                //            crmTrace.AppendLine("Start ProgressInspectorEmail_SignOffQAFailed Email: " + PluginHelperStrings.CreateMessageName);
                //            EmailHandler.ProgressInspectorEmail_SignOffQAFailed(service, prgInspection, response, targetEntity, crmTrace);
                //            crmTrace.AppendLine("End ProgressInspectorEmail_SignOffQAFailed Email: " + PluginHelperStrings.CreateMessageName);
                //        }
                //    }

                //    string[] ColumnNames_Special = new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspector };
                //    ConditionExpression SpecialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                //    ConditionExpression SpecialInspCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspector, ConditionOperator.NotNull, new string[] { });
                //    EntityCollection SpecialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, ColumnNames_Special, new ConditionExpression[] { SpecialInspCondition, SpecialInspCondition2 }, LogicalOperator.And);
                //    crmTrace.AppendLine("SpecialInspResponse.Entities.Count: " + SpecialInspResponse.Entities.Count);
                //    if (SpecialInspResponse != null && SpecialInspResponse.Entities.Count > 0)
                //    {
                //        foreach (Entity spclInspection in SpecialInspResponse.Entities)
                //        {
                //            crmTrace.AppendLine("Start SpecialInspectorEmail_SignOffQAFailed Email: " + PluginHelperStrings.CreateMessageName);
                //            EmailHandler.SpecialInspectorEmail_SignOffQAFailed(service, spclInspection, response, targetEntity ,crmTrace);
                //            crmTrace.AppendLine("End SpecialInspectorEmail_SignOffQAFailed Email: " + PluginHelperStrings.CreateMessageName);
                //        }
                //    }

                //    #endregion
                //}
                #endregion

                #region Permit Sign off
                if (workPermitStatus == (int)WorkpermitStatus.PermitSignedoff)
                {
                   SubmitHandler.CreateBuildTrace(service, targetEntity, preTargetEntity, "Signed-off", crmTrace);
                    // Retreive the Job Filing regarding which the permit is issued
                    string[] ColumnNames_JobFiling = new string[] { JobFilingEntityAttributeName.JobNumberAttributeName, JobFilingEntityAttributeName.FilingNumberAttributeName, JobFilingEntityAttributeName.HouseStreetAttributeName, JobFilingEntityAttributeName.FilingStatus, JobFilingEntityAttributeName.ProfessionalCertificate,
                    JobFilingEntityAttributeName.PlumbingCheckBox, JobFilingEntityAttributeName.SprinklerCheckBox, JobFilingEntityAttributeName.PlumbingWorkLegalization, JobFilingEntityAttributeName.SprinklerWorkLegalization, JobFilingEntityAttributeName.StandPipeWorkType, JobFilingEntityAttributeName.ANCheckBox, JobFilingEntityAttributeName.CCCheckBox};

                    //ConditionExpression Condition = CreateConditionExpression(JobFilingEntityAttributeName.JobFilingId, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    Entity response = Retrieve(service, ColumnNames_JobFiling, jobFilingGuid, JobFilingEntityAttributeName.EntityLogicalName);

                    #region Send Emails to Progress Inspectors and Special Inspectors
                    string[] ColumnNames_Progress = new string[] { ProgressInspectionCategoryAttributeNames.ProgressInspector };
                    ConditionExpression progressInspCondition = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                    ConditionExpression progressInspCondition2 = CreateConditionExpression(ProgressInspectionCategoryAttributeNames.ProgressInspector, ConditionOperator.NotNull, new string[] { });
                    EntityCollection progressInspResponse = RetrieveMultiple(service, ProgressInspectionCategoryAttributeNames.EntityLogicalName, ColumnNames_Progress, new ConditionExpression[] { progressInspCondition, progressInspCondition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("progressInspResponse.Entities.Count: " + progressInspResponse.Entities.Count);
                    if (progressInspResponse != null && progressInspResponse.Entities.Count > 0)
                    {
                        foreach (Entity prgInspection in progressInspResponse.Entities)
                        {
                            crmTrace.AppendLine("Start ProgressInspectorEmail_WTSignOff Email: " + PluginHelperStrings.CreateMessageName);
                            EmailHandler.ProgressInspectorEmail_WTSignOff(service, prgInspection, response, targetEntity, crmTrace);
                            crmTrace.AppendLine("End ProgressInspectorEmail_WTSignOff Email: " + PluginHelperStrings.CreateMessageName);
                        }
                    }

                    string[] ColumnNames_Special = new string[] { SpecialInspectionCategoriesAttributeNames.SpecialInspector };
                    ConditionExpression SpecialInspCondition = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.GoToJobFiling, ConditionOperator.Equal, new string[] { response.Id.ToString() });
                    ConditionExpression SpecialInspCondition2 = CreateConditionExpression(SpecialInspectionCategoriesAttributeNames.SpecialInspector, ConditionOperator.NotNull, new string[] { });
                    EntityCollection SpecialInspResponse = RetrieveMultiple(service, SpecialInspectionCategoriesAttributeNames.EntityLogicalName, ColumnNames_Special, new ConditionExpression[] { SpecialInspCondition, SpecialInspCondition2 }, LogicalOperator.And);
                    crmTrace.AppendLine("SpecialInspResponse.Entities.Count: " + SpecialInspResponse.Entities.Count);
                    if (SpecialInspResponse != null && SpecialInspResponse.Entities.Count > 0)
                    {
                        foreach (Entity spclInspection in SpecialInspResponse.Entities)
                        {
                            crmTrace.AppendLine("Start SpecialInspectorEmail_WTSignOff Email: " + PluginHelperStrings.CreateMessageName);
                            EmailHandler.SpecialInspectorEmail_WTSignOff(service, spclInspection, response, targetEntity,crmTrace);
                            crmTrace.AppendLine("End SpecialInspectorEmail_WTSignOff Email: " + PluginHelperStrings.CreateMessageName);
                        }
                    }

                    #endregion

                    #region OlD Sign off Logic - Commented on 07-10-2017
                    //bool Plumbing = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.PlumbingCheckBox]);
                    //bool Sprinkler = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SprinklerCheckBox]);
                    //bool Plumbing_Leg = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.PlumbingWorkLegalization]);
                    //bool Sprinkler_Leg = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.SprinklerWorkLegalization]);
                    //bool Standpipe = Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.StandPipeWorkType]);
                    //bool Antenna = response.Contains(JobFilingEntityAttributeName.ANCheckBox) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.ANCheckBox]) : false;
                    //bool CurbCut = response.Contains(JobFilingEntityAttributeName.CCCheckBox) ? Convert.ToBoolean(response.Attributes[JobFilingEntityAttributeName.CCCheckBox]) : false;
                    //crmTrace.AppendLine("Plumbing: " + Plumbing);
                    //crmTrace.AppendLine("Sprinkler: " + Sprinkler);
                    //crmTrace.AppendLine("Plumbing_Leg: " + Plumbing_Leg);
                    //crmTrace.AppendLine("Sprinkler_Leg: " + Sprinkler_Leg);
                    //crmTrace.AppendLine("Standpipe: " + Standpipe);
                    //crmTrace.AppendLine("Antenna: " + Antenna);
                    //crmTrace.AppendLine("CurbCut: " + CurbCut);

                    //string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.WorkPermitNumber, WorkPermitEntityAttributeName.WorkPermitStatus, WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.NoWorkCheckBox };
                    //ConditionExpression workPermitCondition = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                    //ConditionExpression workPermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, new string[] { ((int)WorkpermitStatus.PermitSignedoff).ToString() });
                    //EntityCollection workPermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workPermitCondition, workPermitCondition2 }, LogicalOperator.And);
                    //bool PlubmingPermitIssued = false;
                    //bool SprinklerPermitIssued = false;
                    //bool SprinklerLegPermitIssued = false;
                    //bool PlubmingLegPermitIssued = false;
                    //bool StandpipePermitIssued = false;
                    //bool AntennaIssued = false;
                    //bool CurbCutIssued = false;
                    //if (workPermitResponse != null && workPermitResponse.Entities != null && workPermitResponse.Entities.Count > 0)
                    //{
                    //    for (int i = 0; i < workPermitResponse.Entities.Count; i++)  // check if Progress Inspection Catagory entity contains Field mapping (schema name of the field that requires doc)
                    //    {
                    //        Entity entity = (Entity)workPermitResponse.Entities[i];
                    //        int typeofPermit = entity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                    //        bool NoWork_CheckBox = entity.GetAttributeValue<bool>(WorkPermitEntityAttributeName.NoWorkCheckBox);
                    //        crmTrace.AppendLine("NoWork_CheckBox: " + NoWork_CheckBox);

                    //        if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == false)
                    //            PlubmingPermitIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == false)
                    //            SprinklerPermitIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.Plumbing && NoWork_CheckBox == true)
                    //            PlubmingLegPermitIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.Sprinkler && NoWork_CheckBox == true)
                    //            SprinklerLegPermitIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.Standpipe && NoWork_CheckBox == false)
                    //            StandpipePermitIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.Antenna && NoWork_CheckBox == false)
                    //            AntennaIssued = true;
                    //        if (typeofPermit == (int)TypeofPermit.CurbCut && NoWork_CheckBox == false)
                    //            CurbCutIssued = true;
                    //    }

                      
                    //}


                    //crmTrace.AppendLine("PlubmingPermitIssued: " + PlubmingPermitIssued);
                    //crmTrace.AppendLine("SprinklerPermitIssued: " + SprinklerPermitIssued);
                    //crmTrace.AppendLine("SprinklerLegPermitIssued: " + SprinklerLegPermitIssued);
                    //crmTrace.AppendLine("PlubmingLegPermitIssued: " + PlubmingLegPermitIssued);
                    //crmTrace.AppendLine("StandpipePermitIssued: " + StandpipePermitIssued);
                    //crmTrace.AppendLine("AntennaIssued: " + AntennaIssued);
                    //crmTrace.AppendLine("CurbCutIssued: " + CurbCutIssued);

                    //crmTrace.AppendLine("Atleast one Plumbing and Sprinkler permit have been issued ");
                    //crmTrace.AppendLine("Update the Filing Status to Permit Entire");
                    //Entity jobFiling = new Entity();
                    //jobFiling.LogicalName = JobFilingEntityAttributeName.EntityLogicalName;
                    //jobFiling.Attributes.Add(JobFilingEntityAttributeName.JobFilingId, jobFilingGuid);

                    //if (Plumbing == PlubmingPermitIssued && Sprinkler == SprinklerPermitIssued && Plumbing_Leg == PlubmingLegPermitIssued && Sprinkler_Leg == SprinklerLegPermitIssued && Standpipe == StandpipePermitIssued && Antenna == AntennaIssued && CurbCut == CurbCutIssued)
                    //{
                    //    jobFiling.Attributes.Add(JobFilingEntityAttributeName.FilingStatus, new OptionSetValue((int)CurrentFilingStatus.SignedOff));
                    //    service.Update(jobFiling);
                    //    crmTrace.AppendLine("Update the Filing Status  End");
                    //}
                    //else
                    //{
                        
                    //    crmTrace.AppendLine("All permits are not signed off");
                    //}
                    #endregion


                    //throw new Exception("aqib");
                }

                #endregion

                #region QA Failed
                if (workPermitStatus == (int)WorkpermitStatus.QAFailed)
                {
                   // SubmitHandler.CreateBuildTrace(service, targetEntity, preTargetEntity, "QA Failed", crmTrace);
                }

                #endregion

                #region Pending L2 Review	
                if (workPermitStatus == (int)WorkpermitStatus.PendingL2Review)
                {
                   // SubmitHandler.CreateBuildTrace(service, targetEntity, preTargetEntity, "Pending L2 Review", crmTrace);
                }

                #endregion

                #region L2 Approved - Prof Cert QA Review
                if (workPermitStatus == (int)WorkpermitStatus.L2ApprovedProfCertQAReview)
                {
                    //SubmitHandler.CreateBuildTrace(service, targetEntity, preTargetEntity, "L2 Approved - Prof Cert QA Review", crmTrace);
                }

                #endregion





            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermitIssued", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static string GetPermitType (int permitType)
        {
            string response = string.Empty;

            switch (permitType)
                {
                case (int)TypeofPermit.Plumbing:
                    response = "PL";
                    break;
                case (int)TypeofPermit.Sprinkler:
                    response = "SP";
                    break;
                case (int)TypeofPermit.Standpipe:
                    response = "SD";
                    break;
                case (int)TypeofPermit.Antenna:
                    response = "AN";
                    break;
                case (int)TypeofPermit.CurbCut:
                    response = "CC";
                    break;
                case (int)TypeofPermit.SupportedScaffold:
                    response = "SF";
                    break;
                case (int)TypeofPermit.ConstructionFence:
                    response = "FN";
                    break;
                case (int)TypeofPermit.Sign:
                    response = "SG";
                    break;
                case (int)TypeofPermit.SideWalkShed:
                    response = "SH";
                    break;
                case (int)TypeofPermit.BoilerEquipment:
                    response = "BE";
                    break;
                case (int)TypeofPermit.Mechanical:
                    response = "MS";
                    break;
                case (int)TypeofPermit.Structural:
                    response = "ST";
                    break;
            }
            return response;

        }

        public static string GetIncementSequence(int permitcount, StringBuilder crmTrace)
        {
            string response = string.Empty;
            int Count = permitcount;
            #region Incement Number Generated
            if (permitcount > 0 && permitcount < 9)
            {
                response = "A" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 9 && permitcount < 18)
            {
                Count = permitcount - 9;
                response = "B" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 18 && permitcount < 27)
            {
                Count = permitcount - 18;
                response = "C" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 27 && permitcount < 36)
            {
                Count = permitcount - 27;
                response = "D" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 36 && permitcount < 45)
            {
                Count = permitcount - 36;
                response = "E" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 45 && permitcount < 54)
            {
                Count = permitcount - 45;
                response = "F" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 54 && permitcount < 63)
            {
                Count = permitcount - 54;
                response = "G" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }

            if (permitcount >= 63 && permitcount < 72)
            {
                Count = permitcount - 63;
                response = "H" + (Count + 1).ToString();
                crmTrace.AppendLine("response: " + response);
            }
            #endregion
            return response;
        }

        public static void WorkPermit_InspectionComplete(IOrganizationService service, Entity targetEntity, Entity preTargetEntity, StringBuilder crmTrace)
        {
            try
            {
                crmTrace.AppendLine("WorkPermit_InspectionComplete Started!!");
                Entity Tentity = (Entity)preTargetEntity;
                crmTrace.AppendLine("Tentity: " + Tentity.LogicalName);
                Guid jobFilingGuid = ((EntityReference)Tentity[WorkPermitEntityAttributeName.GotoJobFiling]).Id;
                crmTrace.AppendLine("Regarding Job Filing Guid: " + jobFilingGuid.ToString());

                #region Get Withdrawal Request against the Job Filing
                ConditionExpression WRCondition1 = CreateConditionExpression(WithdrawalRequestEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                ConditionExpression WRCondition2 = CreateConditionExpression(WithdrawalRequestEntityAttributeName.WithdrawalStatus, ConditionOperator.Equal, new object[] { WithdrawalStatus.InspectionRequired });
                EntityCollection WRresponse = RetrieveMultiple(service, WithdrawalRequestEntityAttributeName.EntityLogicalName, new string[] { WithdrawalRequestEntityAttributeName.Withdrawalof }, new ConditionExpression[] { WRCondition1, WRCondition2 }, LogicalOperator.And);
                if (WRresponse != null && WRresponse.Entities != null && WRresponse.Entities.Count > 0)
                {
                    int withdrawalof = WRresponse.Entities[0].GetAttributeValue<OptionSetValue>(WithdrawalRequestEntityAttributeName.Withdrawalof).Value;
                    crmTrace.AppendLine("withdrawalof: " + withdrawalof);
                    Guid withdrawalId = WRresponse.Entities[0].Id;
                    crmTrace.AppendLine("withdrawalId: " + withdrawalId.ToString());

                    #region Withdrawal of Filing
                    if (withdrawalof == (int)Withdrawalof.Filing)
                    {
                        //Get all the Issued Permits for the filing
                        ConditionExpression WPCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { jobFilingGuid.ToString() });
                        ConditionExpression WPCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.WorkPermitStatus, ConditionOperator.Equal, new object[] { WorkpermitStatus.PermitIssued });
                        EntityCollection WPresponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, new string[] { WorkPermitEntityAttributeName.InspectionCompleted, WorkPermitEntityAttributeName.InspectionStatus }, new ConditionExpression[] { WPCondition1, WPCondition2 }, LogicalOperator.And);
                        crmTrace.AppendLine("WPresponse.Entities.Count: " + WPresponse.Entities.Count);
                        if (WPresponse != null && WPresponse.Entities != null && WPresponse.Entities.Count > 0)
                        {
                            bool passFinal_All = true;
                            for (int i = 0; i < WPresponse.Entities.Count; i++)
                            {
                                Entity entity = (Entity)WPresponse.Entities[i];
                                int inspectionStatus = entity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.InspectionStatus).Value;
                                crmTrace.AppendLine("inspectionStatus: " + inspectionStatus);
                                if (inspectionStatus != ((int)InspectionStatus.PassFinal))
                                {
                                    passFinal_All = false;
                                }
                            }

                            #region All Pass Final Auto Approval
                            if(passFinal_All == true)
                            {
                                crmTrace.AppendLine("Start Updating Withdrawal Request ");
                                Entity WR = new Entity();
                                WR.LogicalName = WithdrawalRequestEntityAttributeName.EntityLogicalName;
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.WithdrawalRequestId, withdrawalId);
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.WithdrawalStatus, new OptionSetValue((int)WithdrawalStatus.WithdrawalofFilingApproved));
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.InspectionCompleted, true);
                                service.Update(WR);
                                crmTrace.AppendLine("End Updating Withdrawal Request ");
                            }
                            #endregion
                        }
                    }
                    #endregion

                    #region Withdrawal of Work Type
                    if (withdrawalof == (int)Withdrawalof.WorkType)
                    {
                        string[] ColumnNames_WP = new string[] { WorkPermitEntityAttributeName.TypeofPermit, WorkPermitEntityAttributeName.NoWorkCheckBox };
                        Entity permitRec = Retrieve(service, ColumnNames_WP, targetEntity.Id, WorkPermitEntityAttributeName.EntityLogicalName);
                        int typeofPermit = permitRec.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.TypeofPermit).Value;
                        crmTrace.AppendLine("typeofPermit: " + typeofPermit);

                        ConditionExpression workTypeCondition = CreateConditionExpression(AssociatedWorkTypesEntityAttributeName.WithdrawalRequestId, ConditionOperator.Equal, new string[] { withdrawalId.ToString() });
                        EntityCollection workTypeResponse = RetrieveMultiple(service, AssociatedWorkTypesEntityAttributeName.EntityLogicalName, new string[] { AssociatedWorkTypesEntityAttributeName.WorkTypeStatus, AssociatedWorkTypesEntityAttributeName.GotoJobFiling, AssociatedWorkTypesEntityAttributeName.WorkTypeStandard }, new ConditionExpression[] { workTypeCondition }, LogicalOperator.And);
                        crmTrace.AppendLine("Got all the Associated WorkTypes");

                        if (workTypeResponse != null && workTypeResponse.Entities != null && workTypeResponse.Entities.Count > 0)
                        {
                            bool PassFinal_All = true;
                            crmTrace.AppendLine("workTypeResponse count: " + workTypeResponse.Entities.Count);
                            bool[] pf = new bool[workTypeResponse.Entities.Count];
                            for (int i = 0; i < workTypeResponse.Entities.Count; i++)
                            {
                                Guid StandardWTId = ((EntityReference)workTypeResponse.Entities[i].Attributes[AssociatedWorkTypesEntityAttributeName.WorkTypeStandard]).Id;
                                crmTrace.AppendLine("StandardWTId:" + StandardWTId.ToString());
                                string[] Column_StandardWT = new string[] { StandardWorkTypesEntityAttributeName.Name, StandardWorkTypesEntityAttributeName.ConfigurationName };
                                Entity responseStandardWT = Retrieve(service, Column_StandardWT, StandardWTId, StandardWorkTypesEntityAttributeName.EntityLogicalName);
                                string ConfigName = responseStandardWT.GetAttributeValue<string>(StandardWorkTypesEntityAttributeName.ConfigurationName);
                                crmTrace.AppendLine("ConfigName: " + ConfigName);
                                pf[i] = CheckPermits_Inspection(service, crmTrace, ConfigName, jobFilingGuid);
                            }

                            for (int j = 0; j < pf.Length; j++)
                            {
                                crmTrace.AppendLine("pf[j]: " + pf[j].ToString());
                                if (pf[j] == false)
                                {
                                    PassFinal_All = false;
                                }
                            }

                            #region All Pass Final Auto Approval
                            if (PassFinal_All == true)
                            {
                                crmTrace.AppendLine("Start Updating Withdrawal Request ");
                                Entity WR = new Entity();
                                WR.LogicalName = WithdrawalRequestEntityAttributeName.EntityLogicalName;
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.WithdrawalRequestId, withdrawalId);
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.WithdrawalStatus, new OptionSetValue((int)WithdrawalStatus.WithdrawalofWorkTypeApproved));
                                WR.Attributes.Add(WithdrawalRequestEntityAttributeName.InspectionCompleted, true);
                                service.Update(WR);
                                crmTrace.AppendLine("End Updating Withdrawal Request ");
                            }
                            #endregion

                            //throw new Exception("Aqib debugging");

                        }


                    }
                    #endregion

                }
                #endregion
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - WorkPermit_InspectionComplete", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }

        }

        public static bool CheckPermits_Inspection(IOrganizationService service, StringBuilder crmTrace, string ConfigName, Guid JobFilingGuid)
        {
            bool allPassFinal = true;
            try
            {
                string[] ColumnNames_WorkPermit = new string[] { WorkPermitEntityAttributeName.InspectionCompleted, WorkPermitEntityAttributeName.InspectionStatus };

                ConditionExpression workpermitCondition1 = CreateConditionExpression(WorkPermitEntityAttributeName.GotoJobFiling, ConditionOperator.Equal, new string[] { JobFilingGuid.ToString() });
                ConditionExpression workpermitCondition2 = new ConditionExpression();
                ConditionExpression workpermitCondition3 = new ConditionExpression();
                EntityCollection workpermitResponse = new EntityCollection();

                #region Check Config Name and create conditions
                if (ConfigName == "PL")
                {
                    crmTrace.AppendLine("ConfigName: PL");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Plumbing });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2 }, LogicalOperator.And);
                }
                if (ConfigName == "SP")
                {
                    crmTrace.AppendLine("ConfigName: SP");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Sprinkler });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2 }, LogicalOperator.And);
                }
                if (ConfigName == "PL_LG")
                {
                    crmTrace.AppendLine("ConfigName: PL_LG");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Plumbing });
                    workpermitCondition3 = CreateConditionExpression(WorkPermitEntityAttributeName.NoWorkCheckBox, ConditionOperator.Equal, new object[] { true });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2, workpermitCondition3 }, LogicalOperator.And);
                }
                if (ConfigName == "SP_LG")
                {
                    crmTrace.AppendLine("ConfigName: SP_LG");
                    workpermitCondition2 = CreateConditionExpression(WorkPermitEntityAttributeName.TypeofPermit, ConditionOperator.Equal, new object[] { TypeofPermit.Sprinkler });
                    workpermitCondition3 = CreateConditionExpression(WorkPermitEntityAttributeName.NoWorkCheckBox, ConditionOperator.Equal, new object[] { true });
                    workpermitResponse = RetrieveMultiple(service, WorkPermitEntityAttributeName.EntityLogicalName, ColumnNames_WorkPermit, new ConditionExpression[] { workpermitCondition1, workpermitCondition2, workpermitCondition3 }, LogicalOperator.And);
                }
                #endregion

                if (workpermitResponse != null && workpermitResponse.Entities != null && workpermitResponse.Entities.Count > 0)
                {
                    crmTrace.AppendLine("Workpermits count: " + workpermitResponse.Entities.Count);
                    for (int i = 0; i < workpermitResponse.Entities.Count; i++)
                    {
                        Entity entity = (Entity)workpermitResponse.Entities[i];
                        int inspectionStatus = entity.GetAttributeValue<OptionSetValue>(WorkPermitEntityAttributeName.InspectionStatus).Value;
                        crmTrace.AppendLine("inspectionStatus: " + inspectionStatus);
                        if (inspectionStatus != ((int)InspectionStatus.PassFinal))
                        {
                            allPassFinal = false;
                        }

                    }
                }
                return allPassFinal;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return allPassFinal;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return allPassFinal;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(JobFilingGuid.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckPermits_Inspection", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return allPassFinal;
            }

        }

        public static bool CheckifPrimaryPermit(string workPermitNumber, StringBuilder crmTrace)
        {
            bool isPrimary = true;
            try
            {
                string sub = workPermitNumber.Substring(1, 1);
                crmTrace.AppendLine("sub: " + sub);
                if (sub != "0")
                    isPrimary = false;
                return isPrimary;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return isPrimary;
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return isPrimary;
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(workPermitNumber.ToString(), SourceChannel.CRM, "WorkPermitNumberHandler - CheckifPrimaryPermit", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return isPrimary;
            }

        }

    } // class ends here
}// namespace ends here
