﻿using System;
using System.Collections.Generic;
using System.Text;
using DOBNYC.XRM.JobFiling.Common;
using Microsoft.Xrm.Sdk;

using Microsoft.Xrm.Sdk.Query;
using DOBNYC.XRM.JobFiling.Helpers;
using DOB.Logging;
using System.ServiceModel;

namespace DOBNYC.XRM.JobFiling.PluginHandlers
{
    public class WorkPermitHandler : PluginHandlerBase
    {

        public static void CalculateFee(IOrganizationService service, Entity targetEntity, StringBuilder crmTrace, string messageName, Entity preImage)
        {

            #region Varibale Declarations
            bool? permitRenewalChange = null;
            bool? permitRenewalNoChange = null;
            string transHistoryGuid = string.Empty; ;
            List<string> tCodeList = new List<string>();
            EntityReference workPermitGuid = new EntityReference();
            EntityReference jobFilingId = new EntityReference();
            Entity workPermitEntity = new Entity();
            decimal renewalFee = 0;
            string phGuid = string.Empty;
            decimal amountPaid = 0;
            string thGuid = string.Empty;
            Entity phResponse = new Entity();
            #endregion

            try
            {
                if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.WorkPermitStatus))
                    preImage.Attributes.Remove(WorkPermitEntityAttributeName.WorkPermitStatus);

                if (targetEntity.Contains(WorkPermitEntityAttributeName.RenewalPermitWithChanges))
                    permitRenewalChange = (bool)targetEntity.Attributes[WorkPermitEntityAttributeName.RenewalPermitWithChanges];

                if (targetEntity.Contains(WorkPermitEntityAttributeName.RenewalPermitWithOutChanges))
                    permitRenewalNoChange = (bool)targetEntity.Attributes[WorkPermitEntityAttributeName.RenewalPermitWithOutChanges];
                crmTrace.AppendLine(permitRenewalNoChange + "  " + permitRenewalChange);
                #region Delete if payment is not Posted
                if (messageName == "UPDATE")
                {
                    if (permitRenewalChange == false || permitRenewalNoChange == false)
                    {

                        if (preImage.Attributes.Contains(WorkPermitEntityAttributeName.PaymentHistoryGUID))
                        {
                            phGuid = preImage.Attributes[WorkPermitEntityAttributeName.PaymentHistoryGUID].ToString();

                            crmTrace.AppendLine("payment history " + " " + phGuid);
                            phResponse = Retrieve(service, new string[] { PaymentHistoryAttributeNames.IsPosted }, new Guid(phGuid), PaymentHistoryAttributeNames.EntityLogicalName);

                            crmTrace.AppendLine(phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted].ToString());

                            if (phResponse.Attributes.Contains(PaymentHistoryAttributeNames.IsPosted))
                            {
                                if ((bool)phResponse.Attributes[PaymentHistoryAttributeNames.IsPosted] == false)
                                    service.Delete(PaymentHistoryAttributeNames.EntityLogicalName, phResponse.Id);
                                workPermitEntity.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                                workPermitEntity.Id = targetEntity.Id;

                                workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.PermitRenewalFee, decimal.Parse("0"));
                                workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, decimal.Parse("0"));
                                workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.PaymentHistoryGUID, string.Empty);
                                workPermitEntity.Attributes.Remove(WorkPermitEntityAttributeName.WorkPermitStatus);
                                service.Update(workPermitEntity);
                            }
                        }
                    }

                }

                #endregion

                if (permitRenewalChange == true || permitRenewalNoChange == true)
                {
                    crmTrace.AppendLine("Workpermit guid " + targetEntity.Id);

                    if (preImage.Contains(WorkPermitEntityAttributeName.GotoJobFiling))
                    {
                        CommonPluginLibrary.Merge(targetEntity, preImage);
                    }

                    crmTrace.AppendLine("Retrieve Renewal Fee- Start");
                    ConditionExpression calcNameCondition = CreateConditionExpression(FeeCalculationConfigurationAttributeNames.CalculationName, ConditionOperator.Equal, new string[] { FormulaeName.PermitRenewalFee });
                    EntityCollection calcResponse = RetrieveMultiple(service, FeeCalculationConfigurationAttributeNames.EntityLogicalName, new string[] { FeeCalculationConfigurationAttributeNames.PermitRenewalFee }, new ConditionExpression[] { calcNameCondition }, LogicalOperator.And);
                    crmTrace.AppendLine("Retrieve Renewal Fee- End");

                    if (calcResponse.Entities[0].Attributes.Contains(FeeCalculationConfigurationAttributeNames.PermitRenewalFee))
                        renewalFee = decimal.Parse(calcResponse.Entities[0].Attributes[FeeCalculationConfigurationAttributeNames.PermitRenewalFee].ToString());

                    crmTrace.AppendLine("Build Query for Retrieving Transaction code- Start");
                    QueryExpression ieQuery = RetrieveIntersectEntity(crmTrace, calcResponse, targetEntity);
                    crmTrace.AppendLine("Build Query for Retrieving Transaction code- End");

                    tCodeList.Add(TransactionCodes.PermitRenewal);

                    crmTrace.AppendLine("Create Transaction history - Start");
                    //Create Transaction history
                    transHistoryGuid = CreateEntityTransCodes(crmTrace, ieQuery, service, targetEntity, tCodeList, new Money(renewalFee));
                    crmTrace.AppendLine("Create Transaction history - End");

                    //Create Payment history
                    crmTrace.AppendLine("Create Payment history - Start");

                    #region Old job Filing 

                    Entity jobFiling = service.Retrieve(JobFilingEntityAttributeName.EntityLogicalName, targetEntity.GetAttributeValue<EntityReference>(WorkPermitEntityAttributeName.GotoJobFiling).Id, new ColumnSet(
                      JobFilingEntityAttributeName.workTypesTextbox, JobFilingEntityAttributeName.IsHistoricJobFiling, JobFilingEntityAttributeName.OwnerTypePW1Statement, JobFilingEntityAttributeName.ProposeeBuildingStories));

                    if ((jobFiling.Contains(JobFilingEntityAttributeName.IsHistoricJobFiling) && jobFiling[JobFilingEntityAttributeName.IsHistoricJobFiling] != null && jobFiling.GetAttributeValue<bool>(JobFilingEntityAttributeName.IsHistoricJobFiling))) //for Old job filings we should return
                    {
                        crmTrace.AppendLine("Old Job filing");
                        phGuid = CreatePaymentHistory(service, crmTrace, targetEntity, new Guid(transHistoryGuid), new Money(renewalFee), false);

                    }

                    #endregion
                    #region New Job filing

                    else
                    {
                        #region check jobfiling is fee exempt
                        crmTrace.AppendLine("Check Owner Type of initial filing");
                        int OwnerType = jobFiling.Contains(JobFilingEntityAttributeName.OwnerTypePW1Statement) && jobFiling[JobFilingEntityAttributeName.OwnerTypePW1Statement] != null ? jobFiling.GetAttributeValue<OptionSetValue>(JobFilingEntityAttributeName.OwnerTypePW1Statement).Value : 0;
                        crmTrace.AppendLine("ownerType" + OwnerType);
                        if (OwnerType == (int)OwnerTypeJobFiling.SCA || OwnerType == (int)OwnerTypeJobFiling.NYCAgency || OwnerType == (int)OwnerTypeJobFiling.OtherGovernment || OwnerType == (int)OwnerTypeJobFiling.SpecifNYCHAHHCicUser|| OwnerType == (int)OwnerTypeJobFiling.NonProfit)
                        {
                            crmTrace.AppendLine("Feexempt true so make renewal fee 0");

                            renewalFee = 0;

                        }


                        #endregion

                        crmTrace.AppendLine("New Job filing ");
                        if(renewalFee>0)
                        phGuid = CreatePaymentHistory(service, crmTrace, targetEntity, new Guid(transHistoryGuid), new Money(renewalFee), true);
                    }
                    #endregion



                    crmTrace.AppendLine("Create Payment history - End");

                    #region Update WorkPermit
                    workPermitEntity.LogicalName = WorkPermitEntityAttributeName.EntityLogicalName;
                    workPermitEntity.Id = targetEntity.Id;
                    workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.PermitRenewalFee, renewalFee);
                    workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.PaymentHistoryGUID, phGuid);

                    if (amountPaid == 0)
                    {
                        workPermitEntity.Attributes.Add(WorkPermitEntityAttributeName.AmountDue, renewalFee);
                    }
                    workPermitEntity.Attributes.Remove(WorkPermitEntityAttributeName.WorkPermitStatus);
                    service.Update(workPermitEntity);
                    #endregion
                    crmTrace.AppendLine("Permit Renewal  - End of Calculation");
                }
            }

            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CalculateFee", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
            }
        }

        #region Queryexpression for Retrieving from Transhistory Intersect Entity
        public static QueryExpression RetrieveIntersectEntity(StringBuilder crmTrace, EntityCollection calcResponse, Entity targetEntity)
        {
            crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity-Start");
            QueryExpression query = new QueryExpression()
            {
                EntityName = TransactionCodeAttributeNames.EntityLogicalName,
                ColumnSet = new ColumnSet(TransactionCodeAttributeNames.BudgetCode, TransactionCodeAttributeNames.ReportCategory, TransactionCodeAttributeNames.RevenueSource,
                TransactionCodeAttributeNames.SubSource, TransactionCodeAttributeNames.TransactionText, TransactionCodeAttributeNames.TransCode, TransactionCodeAttributeNames.TransType, TransactionCodeAttributeNames.FeeSchemaName),
                LinkEntities =
                        {
                            new LinkEntity()
                            {

                                LinkFromEntityName = TransactionCodeAttributeNames.EntityLogicalName,
                                LinkFromAttributeName = TransactionCodeAttributeNames.Id,
                                LinkToEntityName = FeeCalculationTransactionCodeIntersect.EntityLogicalName,
                                LinkToAttributeName = TransactionCodeAttributeNames.Id,
                                LinkCriteria = new FilterExpression
                                {
                                    FilterOperator = LogicalOperator.And,
                                    Conditions =
                                    {
                                        new ConditionExpression
                                        {
                                            AttributeName = FeeCalculationConfigurationAttributeNames.Id,
                                            Operator = ConditionOperator.Equal,
                                            Values = { calcResponse.Entities[0].Id }
                                        }
                                    }
                                }
                            }
                        }
            };
            crmTrace.AppendLine("Query Expression to Retrieve records from an Intersect Entity-End");
            return query;
        }
        #endregion


        #region Create Transaction History based on Transaction Codes
        public static string CreateEntityTransCodes(StringBuilder crmTrace, QueryExpression query, IOrganizationService service, Entity targetEntity, List<string> transCodes, Money renewalFee)
        {
            Guid transHistoryId = new Guid();
            try
            {
                EntityCollection transCollection = service.RetrieveMultiple(query);
                foreach (var tcollection in transCollection.Entities)
                {
                    Entity transHistory = new Entity();
                    transHistory.LogicalName = TransactionHistoryAttributeNames.EntityLogicalName;
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.BudgetCode, tcollection.Attributes[TransactionCodeAttributeNames.BudgetCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.ReportCategory, tcollection.Attributes[TransactionCodeAttributeNames.ReportCategory]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.RevenueSource, tcollection.Attributes[TransactionCodeAttributeNames.RevenueSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.SubSource, tcollection.Attributes[TransactionCodeAttributeNames.SubSource]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionText, tcollection.Attributes[TransactionCodeAttributeNames.TransactionText]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransCode, tcollection.Attributes[TransactionCodeAttributeNames.TransCode]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransType, tcollection.Attributes[TransactionCodeAttributeNames.TransType]);
                    //transHistory.Attributes.Add(TransactionHistoryAttributeNames.ItemizedFeeType, tcollection.Attributes[TransactionCodeAttributeNames.ItemizedFeeType]);
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.Fees, renewalFee);
                    if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.GotoJobFiling))
                    {
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobfilingLookup, new EntityReference(TransactionCodeAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling]).Id));
                        transHistory.Attributes.Add(TransactionHistoryAttributeNames.JobNumber, ((EntityReference)targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling]).Name);
                    }
                    transHistory.Attributes.Add(TransactionHistoryAttributeNames.TransactionCodeId, new EntityReference(TransactionCodeAttributeNames.EntityLogicalName, tcollection.Id));
                    for (int i = 0; i < transCodes.Count; i++)
                    {
                        if (transCodes[i] == tcollection.Attributes[TransactionCodeAttributeNames.TransCode].ToString())
                        {
                            transHistoryId = service.Create(transHistory);
                        }
                    }
                }
                crmTrace.AppendLine(transHistoryId.ToString());
                return transHistoryId.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return transHistoryId.ToString();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return transHistoryId.ToString();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreateEntityTransCodes", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return transHistoryId.ToString();
            }
        }
        #endregion


        #region Create Payment History
        public static string CreatePaymentHistory(IOrganizationService service, StringBuilder crmTrace, Entity targetEntity, Guid tHistoryId, Money totalFee, bool isNewJobFiling)
        {
            string jobNumber = string.Empty;
            Entity paymentHistory = new Entity();
            Guid paymentHistoryId = Guid.Empty;
            try
            {
                crmTrace.AppendLine("CreatePaymentHistory: Build Transaction history Entity Reference for Association - Start");
                EntityReferenceCollection tHistory = new EntityReferenceCollection();
                tHistory.Add(new EntityReference(TransactionHistoryAttributeNames.EntityLogicalName, tHistoryId));
                crmTrace.AppendLine("CreatePaymentHistory: Build Transaction history Entity Reference for Association - End");
                #region Create Payment History
                crmTrace.AppendLine("CreatePaymentHistory: Build PaymentHistory Object for Creation- Start");
                paymentHistory.LogicalName = PaymentHistoryAttributeNames.EntityLogicalName;

                if (isNewJobFiling)
                {
                    crmTrace.AppendLine("CreatePaymentHistory: isNewJobFiling so fill permit lookup - Start");
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.GoToPw2, targetEntity.ToEntityReference());
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, targetEntity.GetAttributeValue<string>(WorkPermitEntityAttributeName.WorkPermitNumber));
                    paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling]).Id)); //will separete out in mAf package
                    crmTrace.AppendLine("CreatePaymentHistory: isNewJobFiling so fill permit lookup - End");
                }
                else
                {
                    if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.GotoJobFiling))
                    {
                        crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage - Start");
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobfilingLookup, new EntityReference(PaymentHistoryAttributeNames.EntityLogicalName, ((EntityReference)targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling]).Id));
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.JobNumber, ((EntityReference)targetEntity.Attributes[WorkPermitEntityAttributeName.GotoJobFiling]).Name);
                        crmTrace.AppendLine("CreatePaymentHistory: Get JobNumber and GUID from preImage - End");
                    }
                }

                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.FeeType, new OptionSetValue(FeeType.PermitRenewal));
                paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.TotalFees, totalFee);
                if (targetEntity.Attributes.Contains(WorkPermitEntityAttributeName.LicenseeType))
                    if (!string.IsNullOrEmpty((((EntityReference)(targetEntity.Attributes[WorkPermitEntityAttributeName.LicenseeType])).ToString())))
                        paymentHistory.Attributes.Add(PaymentHistoryAttributeNames.LicenseType, ((EntityReference)(targetEntity.Attributes[WorkPermitEntityAttributeName.LicenseeType])));
                crmTrace.AppendLine("CreatePaymentHistory: Build PaymentHistory Object for Creation- End");
                paymentHistoryId = service.Create(paymentHistory);
                #endregion

                crmTrace.AppendLine("Start Association for Payment history");
                service.Associate(PaymentHistoryAttributeNames.EntityLogicalName, paymentHistoryId, new Relationship(PaymentHistoryAttributeNames.PaymentHistTransHistRelationShipName), tHistory);
                crmTrace.AppendLine("End Association for Payment history");

                return paymentHistoryId.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", ex.Detail.Message, LogLevelL4N.FATAL, null, "\nTimeStamp:" + ex.Detail.Timestamp.ToString() + "\n Exception Details:" + (ex.Detail.InnerFault != null ? ex.Detail.InnerFault.ToString() : "No Inner Fault"));
                return paymentHistoryId.ToString();
            }
            catch (TimeoutException ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return paymentHistoryId.ToString();
            }
            catch (Exception ex)
            {
                DOBLogger.WriteTraceLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", null, crmTrace.ToString(), null, null);
                DOBLogger.WriteExceptionLog(targetEntity.Id.ToString(), SourceChannel.CRM, "WorkPermitHandler - CreatePaymentHistory", ex.Message, LogLevelL4N.FATAL, null, "Stack Trace:" + ex.StackTrace + " \nInnerException" + (ex.InnerException != null ? ex.InnerException.ToString() : "No Inner Fault"), null);
                return paymentHistoryId.ToString();
            }


        }
        #endregion
    }
}

