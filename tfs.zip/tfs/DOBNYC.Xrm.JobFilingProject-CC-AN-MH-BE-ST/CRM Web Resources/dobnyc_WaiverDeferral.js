// JavaScript source code

function OnRequestFormLoad() {
    if (Xrm.Page.getAttribute("dobnyc_priortostatus") && Xrm.Page.getAttribute("dobnyc_priortostatus").getValue()) {
        try {
            if (Xrm.Page.getAttribute("dobnyc_jobfilingwp") && Xrm.Page.getAttribute("dobnyc_jobfilingwp").getValue()) {
                var options = new Array();
                options = [18];
                SetDeferToOptions(options);
            }

            //Bug 8018 fix
            if (Xrm.Page.getAttribute("dobnyc_type").getValue() == 2 && Xrm.Page.getAttribute("dobnyc_action").getValue() == 1) {
                DOB.WD.ShowHideControl("dobnyc_priortostatus", true);
                DOB.WD.ShowHideControl("dobnyc_defertostage", true);
                DOB.WD.SetRequirementLevel("dobnyc_defertostage", "required");
            }
        } catch (e) {

        }
    }
}

function OnTaskSubmit(context) {
    try {
        var saveEvent = context.getEventArgs();
        if (Xrm.Page.getAttribute("dobnyc_task_taskform") && Xrm.Page.getAttribute("dobnyc_task_taskform").getValue() == 10 && (saveEvent.getSaveMode() == 5 || saveEvent.getSaveMode() == 58)) {
            if (!DOB.WD.CheckActionPerformedOnRequests(Xrm.Page.data.entity.getId())) {
                Xrm.Utility.alertDialog('Please take action on all the requests in this task first!')
                saveEvent.preventDefault();
            }
        }
    }
    catch (e)
    { }
}

function OnDeferralActionChange() {
    try {
        if (Xrm.Page.getAttribute("dobnyc_type").getValue() == 2 && Xrm.Page.getAttribute("dobnyc_action").getValue() == 1) {
            DOB.WD.ShowHideControl("dobnyc_priortostatus", true);
            DOB.WD.ShowHideControl("dobnyc_defertostage", true);
            DOB.WD.SetRequirementLevel("dobnyc_defertostage", "required");
        }
        else {
            DOB.WD.ShowHideControl("dobnyc_priortostatus", false);
            DOB.WD.ShowHideControl("dobnyc_defertostage", false);
            Xrm.Page.getAttribute("dobnyc_defertostage").setValue(null);
            DOB.WD.SetRequirementLevel("dobnyc_defertostage", "none");
        }
    }
    catch (e)
    { }
}

function SetDeferToOptions(options) {
    Xrm.Page.getControl("dobnyc_defertostage").clearOptions();
    for (var i = 0; i < options.length; i++) {
        Xrm.Page.getControl("dobnyc_defertostage").addOption(Xrm.Page.getAttribute("dobnyc_defertostage").getOption(options[i]));
    }
}

function OnActionChange() {
    if (Xrm.Page.getAttribute("dobnyc_waiverdeferralaction") && Xrm.Page.getAttribute("dobnyc_waiverdeferralaction").getValue() == 1) {
        if (!DOB.WD.CheckActionPerformedOnRequests(Xrm.Page.data.entity.getId())) {
            Xrm.Utility.alertDialog('Please take action on all the requests in this task first!');
            Xrm.Page.getAttribute("dobnyc_waiverdeferralaction").setValue(null);
        }
    }
}