﻿// JavaScript Document
function getLookupId(attributeName) {

    var lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}



function setVisible(onOff, fieldNames) {
    if (fieldNames != null && fieldNames != "") {
        var fields = fieldNames.split(";");
        for (var i = 0; i < fields.length; i++) {
            Xrm.Page.ui.controls.get(fields[i]).setVisible(onOff);
        }
    }
}

function setSchduleB_Fields() {
    //debugger;
    var Id = getLookupId("dobnyc_systemsbs");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("dobnyc_buildingsystemsSet", "?select=dobnyc_Description,dobnyc_Code&$filter=dobnyc_buildingsystemsId eq guid'" + Id + "'");


    if (returnValue != null && returnValue[0] != null) {
        // Xrm.Page.getAttribute("dobnyc_worktypescategory").setValue(returnValue[0].dobnyc_Description);
        Xrm.Page.getAttribute("dobnyc_name").setValue(returnValue[0].dobnyc_Code);
        //      Xrm.Page.getAttribute("new_worktypepw1b").setValue(returnValue[0].dobnyc_CodeObjection);
    }
    if (returnValue[0].dobnyc_Code != null)
    var system_code = ScheduleB_fields(returnValue[0].dobnyc_Code);

    if (system_code != null) {
        setVisible("true", system_code);
    }
    else {
        return;
    }

}

function ScheduleB_fields(keyCode) {

    var serverUrl = Xrm.Page.context.getClientUrl();
    var xmlPath = serverUrl + "//WebResources/dobnyc_ScheduleB_XML";
    var xmlDoc;

    if (typeof window.DOMParser != "undefined") {
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET", xmlPath, false);
        if (xmlhttp.overrideMimeType) {
            xmlhttp.overrideMimeType('text/xml');
        }
        xmlhttp.send();
        xmlDoc = xmlhttp.responseXML;

    }
    else {
        xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.load(xmlPath);
    }

    var NodeCode = xmlDoc.getElementsByTagName(keyCode)[0];
    var ChildObj = NodeCode.childNodes[0];
    if (!ChildObj) {
        return;
    }
    else {
        var m = ChildObj.nodeValue;
        return m;
    }
}