﻿// JavaScript Document 
var DOBJF = {

    MasterTab: "Master_Tab",
    HiddenFeeSubmitted: "dobnyc_feesubmitted",
    HiddenEnableRibbonPayment: "dobnyc_enableribbonpayment",
    TotalWorkCost: "dobnyc_totaljobcost",
    ObjectionDescription: "dobnyc_objections_objectiondetail",
    CodeLanguage: "dobnyc_codelanguageobjection",
    Code: "dobnyc_name",
    BusinessProcessCurrentStage: "header_process_dobnyc_currentstage",
    ParentJobFilingLookup: "dobnyc_parentjobfiling",
    EntityNameAttribute: "dobnyc_name",
    CreateFormID: "_CreateFromId",
    CreateFormType: "_CreateFromType",
    FilingStatusType: "dobnyc_filingstatustype",
    JobFilingEntityName: "dobnyc_jobfiling",
    BinOnHold: "dobnyc_binonhold",
    WorkPermitViolation: "dobnyc_workpermitviolation",
    PlanWorkStageName: "Plan/Work Application",
    ScopeOfWorkStageName: "Scope Of Work",
    CostAffidavitStageName: "Cost Affidavit",
    DocumentsStageName: "Documents",
    TR1StageName: "Technical Report - Statement Of Responsibility",
    TR8StageName: "Technical Report - Energy Code Progress Inspection",
    EN2StageName: "EN2",
    WorkPermitsStageName: "Work Permit",
    SealsAndSignatureStageName: "Statements & Signatures",
    LOCRequest: "Letter Of Completion",
    CustomConfiguratonKey: {

        CustomConfigurationConfirmPayment: "ConfirmPayment",
        CustomConfigurationPaymentWorkFlowId: "PaymentWorkFlowId",
        CustomConfigurationConfirmSubmit: "ConfirmSubmit",
        CustomConfigurationDisableStages: "DisableStages",
        CustomConfigurationJobFilingEntityCode: "JobFilingEntityCode",
        CustomConfigurationFieldMappingSet: "FieldMappingSet"
    }

};

var SDPiping = Xrm.Page.getAttribute("dobnyc_sdstandpipe").getValue();
var PlWorkType = Xrm.Page.getAttribute("dobnyc_pl_plumbing").getValue();
var SpWorkType = Xrm.Page.getAttribute("dobnyc_spsprinkler").getValue();
var PlLegalWorkType = Xrm.Page.getAttribute("dobnyc_plplumbinglegalization").getValue();
var SpLegalWorkType = Xrm.Page.getAttribute("dobnyc_spsprinklerlegalization").getValue();
var SpecialInspsctionsLabels = {

    PostinstalledAnchors: "Post-installed Anchors",
    SprinklerSystems: "Sprinkler Systems",
    FireResistantPenetrationsAndJoints: "Fire-resistant Penetrations and Joints",
    HighPressureFuelGasPipingWelding: "High Pressure Fuel-Gas Piping (Welding)",
    StandpipeSystem: "Standpipe System"

};

function setContractorInfoAHV() {
    var Id = getLookupId("dobnyc_contractor");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("ContactSet", "?$select=dobnyc_LicenseNumber,EMailAddress1,Telephone1,FirstName,LastName,MiddleName,Fax,Address1_StateOrProvince,Address1_PostalCode,Address1_City,Address1_Line1,dobnyc_TaxPayerID,dobnyc_BusinessName,dobnyc_RegistrationNumber&$filter=ContactId eq guid'" + Id + "'");
    if (returnValue != null && returnValue[0] != null) {
        Xrm.Page.getAttribute("dobnyc_firstname").setValue(returnValue[0].FirstName);
        Xrm.Page.getAttribute("dobnyc_lastname").setValue(returnValue[0].LastName);
        Xrm.Page.getAttribute("dobnyc_middlename").setValue(returnValue[0].MiddleName);
        Xrm.Page.getAttribute("dobnyc_businessaddress").setValue(returnValue[0].Address1_Line1);
        Xrm.Page.getAttribute("dobnyc_businessfax").setValue(returnValue[0].Fax);
        Xrm.Page.getAttribute("dobnyc_licensenumber").setValue(returnValue[0].dobnyc_LicenseNumber);
        Xrm.Page.getAttribute("dobnyc_city").setValue(returnValue[0].Address1_City);
        Xrm.Page.getAttribute("dobnyc_state").setValue(returnValue[0].Address1_StateOrProvince);
        Xrm.Page.getAttribute("dobnyc_businesstelephone").setValue(returnValue[0].Telephone1);
        //Xrm.Page.getAttribute("dobnyc_wp_mobiletelephone").setValue(returnValue[0].);
        Xrm.Page.getAttribute("dobnyc_zip").setValue(returnValue[0].Address1_PostalCode);
        //Xrm.Page.getAttribute("dobnyc_wp_taxpayerid").setValue(returnValue[0].dobnyc_TaxPayerID);
        Xrm.Page.getAttribute("dobnyc_email").setValue(returnValue[0].EMailAddress1);
    }

    disableFormFields(true);
}

function setFilingRepInfo() {
    var Id = getLookupId("dobnyc_filingrepresentative");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("ContactSet", "?$select=dobnyc_LicenseNumber,dobnyc_RegistrationNumber&$filter=ContactId eq guid'" + Id + "'");
    if (returnValue != null && returnValue[0] != null) {
        Xrm.Page.getAttribute("dobnyc_registrationnumberfilingrepresentative").setValue(returnValue[0].dobnyc_RegistrationNumber);
    }
}
function IssuePermit() {
    //alert ("Hi");

    var gotojobFiling = Xrm.Page.getAttribute("dobnyc_workpermittojobfilingrelationshid");
    var jobfilingId = gotojobFiling.getValue()[0].id;
    var workPermitId = Xrm.Page.data.entity.getId();
    var returnJobFiling = null;
    var sealSig_Accepted = true;
    var isWorkPermitViolation = false;
    var BinOnHold = false;
    var specialInspection_Check = true;
    var returnSpecialInspection = null;
    var progressInspection_Check = true;
    var returnProgressInspection = null;

    returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_WorkPermitViolation, dobnyc_BinOnHold, dobnyc_ProfessionalCertificate&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

    returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWorkPermit/Id eq guid'" + workPermitId + "'and  dobnyc_ParentDocument eq null");

    returnSpecialInspection = retrieveMultipleCustom("dobnyc_specialinspectioncategoriesSet", "?select=dobnyc_FinalIOR,dobnyc_IORStatement1,dobnyc_ResponsibilityofIdentifingRequirement&$filter=dobnyc_JobFilingtoSpecialInspectionsCaId/Id eq guid'" + jobfilingId + "'");
    returnProgressInspection = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_EnergyProgressInsResponsibilityStmt,dobnyc_InspectionType,dobnyc_ProgressResponsibilityIdentifingRequirm,dobnyc_IORStatement1,dobnyc_ProgressInsFinalStatememt&$filter=dobnyc_ProgressionInspectioncategorytoId/Id eq guid'" + jobfilingId + "'");


    if (returnJobFiling[0].dobnyc_ProfessionalCertificate == false) {
        var returnOpenProfTasks = retrieveMultipleCustom("TaskSet", "?select=dobnyc_Current&$filter=dobnyc_task_ClickheretogotoWorkPermit/Id eq guid'" + workPermitId + "' and StateCode/Value eq 0");

        if (returnOpenProfTasks != null && returnOpenProfTasks.length > 0) {
            alert("Please issue the permit from open task");
            return;

        }
    }

    if (returnSealSig != null && returnSealSig.length > 0) {
        for (var i = 0; i < returnSealSig.length; i++) {
            var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

            //alert(dobnyc_DocumentStatus);
            if (dobnyc_DocumentStatus != 3)
                sealSig_Accepted = false;

        }

    }
    if (sealSig_Accepted == false) {
        alert("Please accept Seal and Signature of Contractor in Permit.");
        return;
    }

    //if (returnSpecialInspection != null && returnSpecialInspection.length > 0) {
    //    for (var i = 0; i < returnSpecialInspection.length; i++) {
    //        var dobnyc_FinalIOR = returnSpecialInspection[i].dobnyc_FinalIOR;
    //        var dobnyc_IORStatement1 = returnSpecialInspection[i].dobnyc_IORStatement1;
    //        var dobnyc_ResponsibilityofIdentifingRequirement = returnSpecialInspection[i].dobnyc_ResponsibilityofIdentifingRequirement;

    //        //alert(dobnyc_DocumentStatus);
    //        if (dobnyc_FinalIOR != true || dobnyc_IORStatement1 != true || dobnyc_ResponsibilityofIdentifingRequirement != true)
    //            specialInspection_Check = false;

    //    }

    //}

    //if (specialInspection_Check == false) {
    //    alert("Atleast one of the Special Inspection Catagory is missing Identification of Responsibilities and/or Legal Content. Permit cannot be issued!");
    //    return;
    //}

    //if (returnProgressInspection != null && returnProgressInspection.length > 0) {
    //    for (var i = 0; i < returnProgressInspection.length; i++) {
    //        var dobnyc_InspectionType = returnProgressInspection[i].dobnyc_InspectionType.Value;
    //        var dobnyc_ProgressResponsibilityIdentifingRequirm = returnProgressInspection[i].dobnyc_ProgressResponsibilityIdentifingRequirm;
    //        var dobnyc_IORStatement1 = returnProgressInspection[i].dobnyc_IORStatement1;
    //        var dobnyc_ProgressInsFinalStatememt = returnProgressInspection[i].dobnyc_ProgressInsFinalStatememt;
    //        var dobnyc_EnergyProgressInsResponsibilityStmt = returnProgressInspection[i].dobnyc_EnergyProgressInsResponsibilityStmt;

    //        if (dobnyc_InspectionType == 1) {
    //            if (dobnyc_ProgressResponsibilityIdentifingRequirm != true || dobnyc_IORStatement1 != true || dobnyc_ProgressInsFinalStatememt != true)
    //                progressInspection_Check = false;
    //        }

    //        if (dobnyc_InspectionType == 2) {
    //            if (dobnyc_ProgressResponsibilityIdentifingRequirm != true || dobnyc_EnergyProgressInsResponsibilityStmt != true)
    //                progressInspection_Check = false;
    //        }

    //    }

    //}

    //if (progressInspection_Check == false) {
    //    alert("Atleast one of the Progress Inspection Catagory is missing Identification of Responsibilities and/or Legal Content. Permit cannot be issued!");
    //    return;
    //}

    if (returnJobFiling != null && returnJobFiling.length > 0) {
        isWorkPermitViolation = returnJobFiling[0].dobnyc_WorkPermitViolation;
        BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
        //alert (isWorkPermitViolation);
        if (isWorkPermitViolation == true) {
            alert("There is Work Without Permit Violation. Permit cannot be issued.");

            return;

        }
        if (BinOnHold == true) {
            alert("The BIN is on hold. Permit cannot be issued.");

            return;

        }
    }

    var permitno = Xrm.Page.getAttribute("dobnyc_trackingnumber").getValue();

    var message = "Would you like to Issue Permit # " + permitno;
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        Xrm.Page.getAttribute("dobnyc_workpermit_status").setValue(4);
        Xrm.Page.data.entity.save();
        alert("Permit issued successfully!");
    }
    function noCloseCallback() {
        return;
    }

}

function TimeOff() {
    var message = "Would you like to take a day off?";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        var myWindow = window.open("http://msdwva-dobcrm01:5555/DOBCRMDEV/SM/workplans/Dialogs/timeoff.aspx?calendarId=&dType=1&id=&resourceId=%7b6F6127A4-519F-E511-80F7-005056AB45D6%7d&selecteddates=2016-03-07T00%3a00%3a00", "Time", "width=700, height=400");
        alert("Alert! You can only take off for complete day");
    }
    function noCloseCallback() {
        return;
    }

}


function DocValidate_onWPSignoff() // for QA Clerk review for sign off
{
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    var workpermitstatus = Xrm.Page.getAttribute("dobnyc_task_workpermitstatus").getValue();
    if (workpermitstatus != 12)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision7").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var allowApproval = true;
        var returnValue = null;
        var returnJobFiling = null;
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "'and  dobnyc_ParentDocument eq null");
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Signoff_onHold == "Y") {
                        alert("Signoff is on Hold for this Filing. Permit cannot be Signed off!");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                        return;

                    }
                    else {
                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 18) {
                                    alert("All the documents required prior to signoff are not submitted. Permit cannot be Signed off.");
                                    Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                                    return;
                                }

                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 18) {
                                    allowApproval = false;
                                }

                            }
                        }
                        if (allowApproval == false) {
                            alert("Please accept all the documents before Sign off!");
                            Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                        }

                        if (allowApproval == true) {
                            //alert ("Permit can be Signed off now!");
                        }

                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while downloading document. Please try again or contact administrator.");
                }
            });
        }



    }

}

function DocValidate_onLOCIssuance() // for QA Clerk review for LOC  07142017
{
    var isLOCTask = Xrm.Page.getAttribute("dobnyc_isloctaskform").getValue();
    if (!isLOCTask)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision8").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var allowApproval = true;
        var returnValue = null;
        var returnJobFiling = null;
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "'and  dobnyc_ParentDocument eq null");
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        ///Validating Special and Progress Inspection documents acceptance at the time of issuing Work Permit
        var jobName = gotojobFiling.getValue()[0].name;
        var workType = null;
        var selectedWorkType = retrieveMultipleCustom("dobnyc_worktypeSet", "?select=dobnyc_name&$filter=dobnyc_AWT_GotoJobFiling/Id eq guid'" + jobfilingId + "' ");
        if (selectedWorkType.length > 0) {
            for (var key in selectedWorkType) {
                workType = selectedWorkType[key].dobnyc_name;
                if (workType != null) {
                    var specialInspectionDocSet = GetSpecialInspectionDocStatus(jobName, workType);
                    if (specialInspectionDocSet.length > 0) {
                        for (var i = 0; i < specialInspectionDocSet.length; i++) {
                            if (specialInspectionDocSet[i].attributes.dobnyc_documentstatus.value != 3) {
                                alert('Please accept the document: ' + specialInspectionDocSet[i].attributes.dobnyc_name.value + '.');
                                Xrm.Page.getAttribute("dobnyc_qadecision8").setValue(null);
                                return;
                            }
                        }
                    }

                    var progressInspectionDocSet = GetProgressInspectionDocStatus(jobName, workType);
                    if (progressInspectionDocSet.length > 0) {
                        for (var i = 0; i < progressInspectionDocSet.length; i++) {
                            if (progressInspectionDocSet[i].attributes.dobnyc_documentstatus.value != 3) {
                                alert('Please accept the document: ' + progressInspectionDocSet[i].attributes.dobnyc_name.value + '.');
                                Xrm.Page.getAttribute("dobnyc_qadecision8").setValue(null);
                                return;
                            }
                        }
                    }
                }
            }
        }


        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Signoff_onHold == "Y") {
                        alert("Signoff is on hold for this Filing. Letter of Completion cannot be issued.");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision8").setValue(null);
                        return;

                    }
                    else {
                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 18) {
                                    alert("All the documents required prior to Letter of Completion are not submitted. Letter of Completion cannot be issued.");
                                    Xrm.Page.getAttribute("dobnyc_qadecision8").setValue(null);
                                    return;
                                }

                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 18) {
                                    allowApproval = false;
                                }

                            }
                        }
                        if (allowApproval == false) {
                            alert("Please accept all the documents before Letter of Completion.");
                            Xrm.Page.getAttribute("dobnyc_qadecision8").setValue(null);
                        }

                        if (allowApproval == true) {
                            alert("Letter of Completion can be issued now.");
                        }

                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        }



    }

}

function DocValidate_onProfApproval() // for Prof QA Clerk when no work permit are there Approval
{
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    var Id = Xrm.Page.data.entity.getId();

    if (currentFilingStatus != 27)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_task_qadecision6").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");


        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var allowApproval = true;
        var returnValue = null;
        var returnJobFiling = null;
        var returnPermits = null;
        var isWorkPermitViolation = false;
        var BinOnHold = false;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_WorkPermitViolation,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "' or dobnyc_ProfQADocumentId/Id eq guid'" + Id + "') and  dobnyc_ParentDocument eq null");
        returnPermits = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WorkPermit_Status&$filter=dobnyc_WorkPermittoJobFilingRelationshId/Id eq guid'" + jobfilingId + "' and dobnyc_IsWorkPermitSubmitted eq true");

        if (returnPermits != null && returnPermits.length > 0) {
            alert("Permit(s) have been filed during the review. Please review newly added Permit(s).");
            Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable").setValue(true);
            Xrm.Page.data.entity.save();
            Xrm.Utility.openEntityForm("task", Id);

        }

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Approval_onHold == "Y") {
                        alert("Approval is on hold for this Filing. Plans cannot be approved.");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                        Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                        Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                        return;

                    }
                    else {
                        isWorkPermitViolation = returnJobFiling[0].dobnyc_WorkPermitViolation;
                        BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
                        //alert (isWorkPermitViolation);
                        if (isWorkPermitViolation == true) {
                            alert("There is Work Without Permit Violation. Permit cannot be issued.");
                            Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                            return;

                        }
                        if (BinOnHold == true) {
                            alert("The Filing is on hold. Permit cannot be issued.");
                            Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                            return;

                        }
                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                var dobnyc_ManuallySelected = returnValue[i].dobnyc_ManuallySelected;
                                var dobnyc_RejectionReason = returnValue[i].dobnyc_RejectionReason.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 6) {
                                    alert("All the documents required prior to approval are not submitted. Job cannot be approved.");
                                    Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                                    Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                                    Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                                    return;
                                }

                                //Documents which are not approved
                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6) {
                                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                                        allowApproval = true;
                                    }
                                    else {
                                        allowApproval = false;
                                    }
                                }

                            }
                        }

                        if (allowApproval == false) {
                            alert("Please accept all the documents before Approval.");
                            Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                        }

                        if (allowApproval == true) {
                            //alert ("Permit can be issued now.");
                        }

                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        }
    }

}


function DocValidate_onPermitIssue() // for QA Clerk Standard Plan
{
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    var workpermitstatus = Xrm.Page.getAttribute("dobnyc_task_workpermitstatus").getValue();
    if (currentFilingStatus != 6 && workpermitstatus != 2)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setValue(1);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
        Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
        Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("required");


        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var returnOpenProfTasks = retrieveMultipleCustom("TaskSet", "?select=dobnyc_Current&$filter=dobnyc_task_ClickheretogotoJobFiling/Id eq guid'" + jobfilingId + "' and StateCode/Value eq 0 and RegardingObjectId/Id eq guid'" + jobfilingId + "'");
        if (returnOpenProfTasks != null && returnOpenProfTasks.length > 0) {
            alert("Parent Job Filing is not yet Approved/Permit Issued. Task cannot be completed until the review is completed")
            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
            return;

        }

        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var gotojobWorkPermit = Xrm.Page.getAttribute("dobnyc_task_clickheretogotoworkpermit");
        var workPermitId = gotojobWorkPermit.getValue()[0].id;
        var allowApproval = true;
        var sealSig_Accepted = true;
        var returnValue = null;
        var returnSealSig = null;
        var specialInspection_Check = true;
        var returnSpecialInspection = null;
        var returnJobFiling = null;
        var isWorkPermitViolation = false;
        var BinOnHold = false;
        var progressInspection_Check = true;
        var returnProgressInspection = null;
        var returnOpenProfTasks = retrieveMultipleCustom("TaskSet", "?select=dobnyc_Current&$filter=dobnyc_task_ClickheretogotoJobFiling/Id eq guid'" + jobfilingId + "' and StateCode/Value eq 0 and RegardingObjectId/Id eq guid'" + jobfilingId + "'");
        var QAFailedStatus = 0;
        var PermitDocName = "Seal and Signature";
        //alert(returnOpenProfTasks.length);
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_WorkPermitViolation,dobnyc_QAFailedStatus,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "') and  dobnyc_ParentDocument eq null");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus,dobnyc_DocumentNameDocumentList&$filter=dobnyc_GotoWorkPermit/Id eq guid'" + workPermitId + "'and  dobnyc_ParentDocument eq null");
        returnSpecialInspection = retrieveMultipleCustom("dobnyc_specialinspectioncategoriesSet", "?select=dobnyc_FinalIOR,dobnyc_IORStatement1,dobnyc_ResponsibilityofIdentifingRequirement&$filter=dobnyc_JobFilingtoSpecialInspectionsCaId/Id eq guid'" + jobfilingId + "'");
        returnProgressInspection = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_EnergyProgressInsResponsibilityStmt,dobnyc_InspectionType,dobnyc_ProgressResponsibilityIdentifingRequirm,dobnyc_IORStatement1,dobnyc_ProgressInsFinalStatememt&$filter=dobnyc_ProgressionInspectioncategorytoId/Id eq guid'" + jobfilingId + "'");

        var returnPermits = null;
        returnPermits = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_QAFailedReason,dobnyc_QAFailedStatus&$filter=dobnyc_workpermitId eq guid'" + workPermitId + "'");
        if (returnPermits != null && returnPermits.length > 0) {
            QAFailedStatus = returnPermits[0].dobnyc_QAFailedStatus.Value;

            if (QAFailedStatus == 2) {
                alert("QA Failed Status will be set to closed automatically.");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(3);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(returnPermits[0].dobnyc_QAFailedReason);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);
            }
            else {
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);
                Xrm.Page.getControl("dobnyc_task_status").setVisible(false);
            }
        }

        //if (returnSpecialInspection != null && returnSpecialInspection.length > 0) {
        //    for (var i = 0; i < returnSpecialInspection.length; i++) {
        //        var dobnyc_FinalIOR = returnSpecialInspection[i].dobnyc_FinalIOR;
        //        var dobnyc_IORStatement1 = returnSpecialInspection[i].dobnyc_IORStatement1;
        //        var dobnyc_ResponsibilityofIdentifingRequirement = returnSpecialInspection[i].dobnyc_ResponsibilityofIdentifingRequirement;

        //        //alert(dobnyc_DocumentStatus);
        //        if (dobnyc_FinalIOR != true || dobnyc_IORStatement1 != true || dobnyc_ResponsibilityofIdentifingRequirement != true)
        //            specialInspection_Check = false;

        //    }

        //}

        //if (specialInspection_Check == false) {
        //    alert("Atleast one of the Special Inspection Catagory is missing Identification of Responsibilities and/or Legal Content!");
        //    Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
        //    return;
        //}

        //if (returnProgressInspection != null && returnProgressInspection.length > 0) {
        //    for (var i = 0; i < returnProgressInspection.length; i++) {
        //        var dobnyc_InspectionType = returnProgressInspection[i].dobnyc_InspectionType.Value;
        //        var dobnyc_ProgressResponsibilityIdentifingRequirm = returnProgressInspection[i].dobnyc_ProgressResponsibilityIdentifingRequirm;
        //        var dobnyc_IORStatement1 = returnProgressInspection[i].dobnyc_IORStatement1;
        //        var dobnyc_ProgressInsFinalStatememt = returnProgressInspection[i].dobnyc_ProgressInsFinalStatememt;
        //        var dobnyc_EnergyProgressInsResponsibilityStmt = returnProgressInspection[i].dobnyc_EnergyProgressInsResponsibilityStmt;

        //        if (dobnyc_InspectionType == 1) {
        //            if (dobnyc_ProgressResponsibilityIdentifingRequirm != true || dobnyc_IORStatement1 != true || dobnyc_ProgressInsFinalStatememt != true)
        //                progressInspection_Check = false;
        //        }

        //        if (dobnyc_InspectionType == 2) {
        //            if (dobnyc_ProgressResponsibilityIdentifingRequirm != true || dobnyc_EnergyProgressInsResponsibilityStmt != true)
        //                progressInspection_Check = false;
        //        }

        //    }

        //}

        //if (progressInspection_Check == false) {
        //    alert("Atleast one of the Progress Inspection Catagory is missing Identification of Responsibilities and/or Legal Content!");
        //    Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
        //    return;
        //}

        ///Validating Special and Progress Inspection documents acceptance at the time of issuing Work Permit
        var jobName = gotojobFiling.getValue()[0].name;
        if (ValidateInspectionCategories(returnPermits, jobName) == false) { return; }


        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Permit_onHold == "Y") {
                        alert("Permit is on hold for this Filing. Permit cannot be issued.");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                        return;

                    }
                    else {
                        if (returnOpenProfTasks != null && returnOpenProfTasks.length > 0) {
                            alert("Parent Job Filing is not yet Approved/Permit Issued. Task cannot be completed until the review is completed")
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                            return;

                        }
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;
                                PermitDocName = returnSealSig[i].dobnyc_DocumentNameDocumentList.Name;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }
                        if (sealSig_Accepted == false) {
                            alert("Please accept " + PermitDocName + " in Permit.");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                            return;
                        }
                        isWorkPermitViolation = returnJobFiling[0].dobnyc_WorkPermitViolation;
                        BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
                        //alert (isWorkPermitViolation);
                        if (isWorkPermitViolation == true) {
                            alert("There is Work Without Permit Violation. Permit cannot be issued.");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            return;

                        }
                        if (BinOnHold == true) {
                            alert("The BIN is on Hold. Permit cannot be issued!");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            return;

                        }
                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                var dobnyc_ManuallySelected = returnValue[i].dobnyc_ManuallySelected;
                                var dobnyc_RejectionReason = returnValue[i].dobnyc_RejectionReason.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 10) {
                                    alert("All the documents required prior to permit issue are not submitted. Permit cannot be issued.");
                                    Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                                    return;
                                }

                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 10) {
                                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                                        allowApproval = true;
                                    }
                                    else {
                                        allowApproval = false;
                                    }
                                }

                                //Documents which are not approved
                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6) {
                                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                                        allowApproval = true;
                                    }
                                    else {
                                        allowApproval = false;
                                    }
                                }

                            }
                        }

                        if (allowApproval == false) {
                            alert("Please accept all the documents before Permit Issue.");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                        }

                        if (allowApproval == true) {
                            alert("Permit can be issued now.");
                        }
                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        }
    }

}
function CloseObjection() {
    //alert ("Hi");
    if (Xrm.Page.data.entity.attributes.get("dobnyc_objectionstojobfilingid").getValue() != null) {
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_objectionstojobfilingid");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var returnOpenTasks = retrieveMultipleCustom("TaskSet", "?select=dobnyc_Current&$filter=dobnyc_task_ClickheretogotoJobFiling/Id eq guid'" + jobfilingId + "' and StateCode/Value eq 0 and RegardingObjectId/Id eq guid'" + jobfilingId + "'");
        //alert("returnOpenTasks.length" + returnOpenTasks.length);
        if (returnOpenTasks.length == 0) {
            alert("There are no open tasks against regarding Job Filing, Objection cannot be addressed.")
            return;
        }
    }

    var message = "Would you like to mark this objection as Addressed?";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        Xrm.Page.getAttribute("dobnyc_task_objectionstatus").setValue(3);
        Xrm.Page.data.entity.save();
    }
    function noCloseCallback() {
        return;
    }

}

function DismissObjection() {
    //alert ("Hi");
    var gotojobFiling = Xrm.Page.getAttribute("dobnyc_objectionstojobfilingid");
    var jobfilingId = gotojobFiling.getValue()[0].id;
    var returnOpenTasks = retrieveMultipleCustom("TaskSet", "?select=dobnyc_Current&$filter=dobnyc_task_ClickheretogotoJobFiling/Id eq guid'" + jobfilingId + "' and StateCode/Value eq 0 and RegardingObjectId/Id eq guid'" + jobfilingId + "'");
    //alert("returnOpenTasks.length" + returnOpenTasks.length);
    if (returnOpenTasks.length == 0) {
        alert("There are no open Tasks against regarding Job Filing, Objection cannot be Dismissed.")
        return;
    }

    var message = "Would you like to Dismiss this objection?";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        Xrm.Page.getAttribute("dobnyc_task_objectionstatus").setValue(4);
        Xrm.Page.data.entity.save();
    }
    function noCloseCallback() {
        return;
    }

}

function AcceptDocument() {
    var DocumentURL = Xrm.Page.getAttribute("dobnyc_documenturl").getValue();
    var waiverReq = Xrm.Page.getAttribute("dobnyc_waiverrequested").getValue();

    var DefferalReq = Xrm.Page.getAttribute("dobnyc_deferralrequested").getValue();
    var DocumentComments = Xrm.Page.getAttribute("dobnyc_comments").getValue();
    if (DefferalReq == true && DocumentComments == null) {
        alert('Comments required to accept the document.');
        return;
    }

    //alert(waiverReq );
    if (DocumentURL == null && waiverReq == false) {
        alert("There is no document uploaded to be accepted.");
        return;
    }
    var currentUserId = Xrm.Page.context.getUserId();
    var currentUserRoles = GetRoleName(currentUserId);
    var hasQARole = false;
    var hasOtherRole = false;
    for (var i = 0; i < currentUserRoles.length; i++) {
        //var userRoleId = currentUserRoles[i];

        if (currentUserRoles[i].attributes.name.value == "BUILDNYC - QA" || currentUserRoles[i].attributes.name.value == "BUILDNYC - QA Supervisor") {
            hasQARole = true;

        }
        else {
            hasOtherRole = true;
        }

    }
    if (hasOtherRole == false && hasQARole == true) {
        var PriortoStatus = Xrm.Page.getAttribute("dobnyc_documentlist_priortostatus").getValue();
        if (PriortoStatus == 6 && waiverReq == false) {
            alert("QA cannot Accept documents prior to Approval.");
            return;
        }
    }
    var lookup = new Array();
    lookup[0] = new Object();
    lookup[0].id = Xrm.Page.context.getUserId();
    lookup[0].name = Xrm.Page.context.getUserName();
    lookup[0].entityType = "systemuser";
    var loginId = lookup[0].id;
    var ViewedbyId = getLookupId("dobnyc_viewedby");
    if (ViewedbyId != loginId && waiverReq == false) {
        alert("Please view document first before accepting.");
        return;
    }

    var message = "Would you like to accept this document?";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        Xrm.Page.getAttribute("dobnyc_rejectionreason").setValue(null);
        Xrm.Page.getAttribute("dobnyc_documentstatus").setValue(3);
        Xrm.Page.data.entity.save();
    }
    function noCloseCallback() {
        return;
    }

}

function RejectDocument() {
    //alert ("Hi");
    var DocumentURL = Xrm.Page.getAttribute("dobnyc_documenturl").getValue();
    var waiverReq = Xrm.Page.getAttribute("dobnyc_waiverrequested").getValue();
    //alert(DocumentURL );

    var DefferalReq = Xrm.Page.getAttribute("dobnyc_deferralrequested").getValue();
    var DocumentComments = Xrm.Page.getAttribute("dobnyc_comments").getValue();
    if (DefferalReq == true && DocumentComments == null) {
        alert('Comments required to reject the document.');
        return;
    }

    if (DocumentURL == null && waiverReq == false) {
        alert("There is no document uploaded to be Rejected.");
        return;
    }
    var lookup = new Array();
    lookup[0] = new Object();
    lookup[0].id = Xrm.Page.context.getUserId();
    lookup[0].name = Xrm.Page.context.getUserName();
    lookup[0].entityType = "systemuser";
    var loginId = lookup[0].id;
    var ViewedbyId = getLookupId("dobnyc_viewedby");
    if (ViewedbyId != loginId && waiverReq == false) {
        alert("Please view document first before Rejecting.");
        return;
    }
    var currentUserId = Xrm.Page.context.getUserId();
    var currentUserRoles = GetRoleName(currentUserId);
    var hasQARole = false;
    var hasOtherRole = false;
    for (var i = 0; i < currentUserRoles.length; i++) {
        //var userRoleId = currentUserRoles[i];

        if (currentUserRoles[i].attributes.name.value == "BUILDNYC - QA" || currentUserRoles[i].attributes.name.value == "BUILDNYC - QA Supervisor") {
            hasQARole = true;

        }
        else {
            hasOtherRole = true;
        }

    }
    if (hasOtherRole == false && hasQARole == true) {
        var PriortoStatus = Xrm.Page.getAttribute("dobnyc_documentlist_priortostatus").getValue();
        if (PriortoStatus == 6 && waiverReq == false) {
            alert("QA cannot Reject documents prior to Approval.");
            return;
        }
    }
    var isSupportDoc = Xrm.Page.getAttribute("dobnyc_manuallyselected").getValue();
    var rejectReasonVal = Xrm.Page.getAttribute("dobnyc_rejectionreason").getValue();
    var message = null;
    if (isSupportDoc == true && rejectReasonVal == null) {
        message = "Please select the rejection reason before proceeding.";
    }
    else {
        message = "Would you like to reject this document?";
    }
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        if (isSupportDoc == true && rejectReasonVal == null) {
            return;
        }
        Xrm.Page.getAttribute("dobnyc_documentstatus").setValue(4);
        Xrm.Page.data.entity.save();
        var documentfor = Xrm.Page.getAttribute("dobnyc_documentfor").getValue();
        if (documentfor == 6) {
            var Id = getLookupId("dobnyc_gotoahv");

            var entity = {};
            entity.dobnyc_DocumentRejected = true;

            SDK.REST.updateRecord(
                Id,
                entity,
                "dobnyc_afterhourvariancepw5",
                function () {
                    alert("AHV auto approval canceled.");
                },
                function (error) {
                    alert(error.message);
                }
            );
        }

    }
    function noCloseCallback() {
        return;
    }

}

function setApplicantInfoWP() {
    var Id = getLookupId("dobnyc_applicantcontractor");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("ContactSet", "?$select=dobnyc_LicenseNumber,EMailAddress1,Telephone1,FirstName,LastName,MiddleName,Fax,Address1_StateOrProvince,Address1_PostalCode,Address1_City,Address1_Line1,dobnyc_TaxPayerID,dobnyc_BusinessName,dobnyc_RegistrationNumber&$filter=ContactId eq guid'" + Id + "'");
    if (returnValue != null && returnValue[0] != null) {
        Xrm.Page.getAttribute("dobnyc_wp_firstname").setValue(returnValue[0].FirstName);
        Xrm.Page.getAttribute("dobnyc_wp_lastname").setValue(returnValue[0].LastName);
        Xrm.Page.getAttribute("dobnyc_wp_middleinitial").setValue(returnValue[0].MiddleName);
        Xrm.Page.getAttribute("dobnyc_wp_businessaddress").setValue(returnValue[0].Address1_Line1);
        Xrm.Page.getAttribute("dobnyc_wp_businessfax").setValue(returnValue[0].Fax);
        Xrm.Page.getAttribute("dobnyc_wp_licensenumber").setValue(returnValue[0].dobnyc_LicenseNumber);
        Xrm.Page.getAttribute("dobnyc_wp_city").setValue(returnValue[0].Address1_City);
        Xrm.Page.getAttribute("dobnyc_wp_state").setValue(returnValue[0].Address1_StateOrProvince);
        Xrm.Page.getAttribute("dobnyc_wp_businesstelephone").setValue(returnValue[0].Telephone1);
        //Xrm.Page.getAttribute("dobnyc_wp_mobiletelephone").setValue(returnValue[0].);
        Xrm.Page.getAttribute("dobnyc_wp_zip").setValue(returnValue[0].Address1_PostalCode);
        Xrm.Page.getAttribute("dobnyc_wp_taxpayerid").setValue(returnValue[0].dobnyc_TaxPayerID);
        Xrm.Page.getAttribute("dobnyc_wp_email").setValue(returnValue[0].EMailAddress1);
    }
}

function setFilingRepInfoWP() {
    var Id = getLookupId("dobnyc_filingrepresentative");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("ContactSet", "?$select=dobnyc_LicenseNumber,EMailAddress1,Telephone1,FirstName,LastName,MiddleName,Fax,Address1_StateOrProvince,Address1_PostalCode,Address1_City,Address1_Line1,dobnyc_TaxPayerID,dobnyc_BusinessName,dobnyc_RegistrationNumber&$filter=ContactId eq guid'" + Id + "'");
    if (returnValue != null && returnValue[0] != null) {
        Xrm.Page.getAttribute("dobnyc_wp_fr_firstname").setValue(returnValue[0].FirstName);
        Xrm.Page.getAttribute("dobnyc_wp_fr_lastname").setValue(returnValue[0].LastName);
        Xrm.Page.getAttribute("dobnyc_wp_fr_middleinitial").setValue(returnValue[0].MiddleName);
        Xrm.Page.getAttribute("dobnyc_wp_fr_businessaddress").setValue(returnValue[0].Address1_Line1);
        Xrm.Page.getAttribute("dobnyc_wp_fr_businessfax").setValue(returnValue[0].Fax);
        //Xrm.Page.getAttribute("dobnyc_wp_fr_licensenumber").setValue(returnValue[0].dobnyc_LicenseNumber);
        Xrm.Page.getAttribute("dobnyc_wp_fr_city").setValue(returnValue[0].Address1_City);
        Xrm.Page.getAttribute("dobnyc_wp_fr_state").setValue(returnValue[0].Address1_StateOrProvince);
        Xrm.Page.getAttribute("dobnyc_wp_fr_businesstelephone").setValue(returnValue[0].Telephone1);
        //Xrm.Page.getAttribute("dobnyc_wp_fr_mobiletelephone").setValue(returnValue[0].);
        Xrm.Page.getAttribute("dobnyc_wp_fr_zip").setValue(returnValue[0].Address1_PostalCode);
        //Xrm.Page.getAttribute("dobnyc_wp_fr_taxpayerid").setValue(returnValue[0].dobnyc_TaxPayerID);
        Xrm.Page.getAttribute("dobnyc_wp_fr_email").setValue(returnValue[0].EMailAddress1);
        Xrm.Page.getAttribute("dobnyc_wp_fr_registrationnumber").setValue(returnValue[0].dobnyc_RegistrationNumber);

    }
}



function setFilingRepInfo() {
    var Id = getLookupId("dobnyc_filingrepresentative");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("ContactSet", "?$select=dobnyc_LicenseNumber,dobnyc_RegistrationNumber&$filter=ContactId eq guid'" + Id + "'");
    if (returnValue != null && returnValue[0] != null) {
        Xrm.Page.getAttribute("dobnyc_registrationnumberfilingrepresentative").setValue(returnValue[0].dobnyc_RegistrationNumber);
    }
}

function getMessage(key) {
    /// get Data from configuration entity
    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Page.context.getUserLcid() + "'");

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0].dobnyc_name;



    return "Unable to get configuration message for Key : " + key + ".";
}



// function isProcessStageCompleted(stageName)

// {
//   var activeStage = Xrm.Page.data.process.getSelectedStage();
//   var stepsCollection = activeStage.getSteps();
//   var collectionReturn = "";
//   stepsCollection.forEach(function (stage, n)
//   {
//      if(stage.isRequired())
//      {
//         var stageattribute = stage.getName();
//         collectionReturn = collectionReturn + stageattribute  + ";"
//      }
//   }
//   )


//   if (collectionReturn != "")
//   {
//      var attributeArray = collectionReturn.split(";");
//      for (var i = 0; i < attributeArray.length;
//      i ++ )
//      {
//         if (attributeArray[i] != null && attributeArray[i] != "" && Xrm.Page.getAttribute(attributeArray[i]).getValue() == null)
//         {
//            return false;
//         }
//      }
//   }

//   return true;
// }

function hideDocuments_AddressChangeTaskForm() {
    var isAddressChangerequest = Xrm.Page.getAttribute("dobnyc_isaddresschangerequest").getValue();
    if (isAddressChangerequest == true) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(false);

    }
    else {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(true);

    }
}

function validateCurrentSections() {
    var sectionControl;
    var i = 0;
    var controlsAll = Xrm.Page.getAttribute();
    for (i = 0; i < controlsAll.length; i++) {
        if (controlsAll[i].getRequiredLevel() != "none" && controlsAll[i].getValue() == null) {
            sectionControl = Xrm.Page.getControl(controlsAll[i].getName()).getParent();
            if (sectionControl.getVisible()) {
                return true;
            }
        }

    }

    return true;
}

function showJobFilings_QATaskForm() {
    var isLOCTask = Xrm.Page.getAttribute("dobnyc_isloctaskform").getValue();
    if (isLOCTask == true) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_10").setVisible(true);

    }
    else {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_10").setVisible(false);

    }
}
function showHideTabeBPF() {
    try {
        document.body.scrollTop = document.documentElement.scrollTop = 0;
        Xrm.Page.getControl(DOBJF.BusinessProcessCurrentStage).setVisible(false);
        var activeStage = Xrm.Page.data.process.getActiveStage();
        var stageName = activeStage.getName();
        //var masterTab = "Master_Tab";
        var sectionArray = getAllSectionName(DOBJF.MasterTab);
        setVisibleTabSection(DOBJF.MasterTab, sectionArray, false, "");
        setVisibleTabSection(DOBJF.MasterTab, sectionArray, true, stageName);
        Xrm.Page.ui.controls.get("DocumentList").refresh();
        //calculateTotalCost();
    }

    catch (err) {

    }

    //Xrm.Page.getControl("CategoriesofWork").addOnLoad(calculateTotalCost); // On-Prem
}

function showHideTabeBPFSelection() {
    try {
        Xrm.Page.getControl(DOBJF.BusinessProcessCurrentStage).setVisible(false);
        var activeStage = Xrm.Page.data.process.getSelectedStage();

        var stageName = activeStage.getName();

        if (!validateCurrentSections()) {
            var activeStage = Xrm.Page.data.process.getActiveStage();
            stageName = activeStage.getName();
            // Xrm.Page.data.process.setActiveStage(activeStage.getId(), showHideTabeBPF);
            Xrm.Page.data.process.movePrevious(showHideTabeBPF)
        }
        var sectionArray = getAllSectionName(DOBJF.MasterTab);
        setVisibleTabSection(DOBJF.MasterTab, sectionArray, false, "");
        setVisibleTabSection(DOBJF.MasterTab, sectionArray, true, stageName);

        if (stageName == "Documents") {
            var DocumentListgrid = Xrm.Page.ui.controls.get('DocumentList');
            if (DocumentListgrid == null) {

                return;
            }
            else {
                DocumentListgrid.refresh();
            }
        }

        if (stageName == "Scope Of Work") {
            var SystemBuildingsgrid = Xrm.Page.ui.controls.get('SystemBuildings');
            if (SystemBuildingsgrid == null) {

                return;
            }
            else {
                SystemBuildingsgrid.refresh();
            }
            // debugger;
            // DOB.ASW.ToggleAntennaScopeOfWork();
        }

        if (stageName == "Cost Affidavit") {
            hideSection_CostAffidavit();
            var CategoriesofWorkgrid = Xrm.Page.ui.controls.get('CategoriesofWork');
            if (CategoriesofWorkgrid == null) {

                return;
            }
            else {
                CategoriesofWorkgrid.refresh();
                hideshowCostAffidavitFields();
            }
        }

        if (stageName == "Technical Report - Statement Of Responsibility") {
            var JobFiling2SplInspectionCategorygrid = Xrm.Page.ui.controls.get('JobFiling2SplInspectionCategory');
            if (JobFiling2SplInspectionCategorygrid == null) {

                return;
            }
            else {
                JobFiling2SplInspectionCategorygrid.refresh();
            }

            var Progressgrid = Xrm.Page.ui.controls.get('Progress');
            if (Progressgrid == null) {

                return;
            }
            else {
                Progressgrid.refresh();
            }
        }

        if (stageName == "EN2") {
            var EnergyGridgrid = Xrm.Page.ui.controls.get('EnergyGrid');
            if (EnergyGridgrid == null) {

                return;
            }
            else {
                EnergyGridgrid.refresh();
            }
        }

        if (stageName == "Work Permit") {
            var WorkPermitsgrid = Xrm.Page.ui.controls.get('WorkPermits');
            if (WorkPermitsgrid == null) {

                return;
            }
            else {
                WorkPermitsgrid.refresh();
            }
        }

        //var DocumentsGridgrid = Xrm.Page.ui.controls.get('DocumentsGrid');
        //if (DocumentsGridgrid == null) {
        //    setTimeout(showHideTabeBPFSelection, 1000);
        //    return;
        //}
        //else {
        //    DocumentsGridgrid.refresh();
        //}
        //Xrm.Page.ui.controls.get("DocumentList").refresh();
        //Xrm.Page.ui.controls.get("SystemBuildings").refresh();
        //Xrm.Page.ui.controls.get("CategoriesofWork").refresh();
        //Xrm.Page.ui.controls.get("JobFiling2SplInspectionCategory").refresh();
        //Xrm.Page.ui.controls.get("Progress").refresh();
        //Xrm.Page.ui.controls.get("EnergyGrid").refresh();
        //Xrm.Page.ui.controls.get("WorkPermits").refresh();
        //Xrm.Page.ui.controls.get("DocumentsGrid").refresh();

        //calculateTotalCost();
        //Xrm.Page.getControl("CategoriesofWork").addOnLoad(calculateTotalCost); // On-Prem
    }
    catch (ex) {
        alert(ex);
    }

}

function AssignFieldname() {
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus == 25) {
        Xrm.Page.ui.controls.get("dobnyc_assigntoqaclerk").setLabel("Assign to Prof Cert QA Administrator");

    }


}

function hideShowTabs(tabIds, trueFalse) {
    if (tabIds != "") {
        var idsArray = tabIds.split(";");
        for (var i = 0; i < idsArray.length; i++) {
            if (idsArray[i] != null && idsArray[i] != "") {
                Xrm.Page.ui.tabs.get(idsArray[i]).setVisible(trueFalse);
            }
        }
    }



}


function getAllSectionName(TAB) {
    var collectionReturn = "";
    var sectionNames = Xrm.Page.ui.tabs.get(TAB).sections.get();
    for (var i in sectionNames) {
        collectionReturn = collectionReturn + sectionNames[i].getName() + ";";
    }

    return collectionReturn;
}

function CertValidate_onWTSignoff() {
    var permitStatus = Xrm.Page.getAttribute("dobnyc_task_workpermitstatus").getValue();
    if (permitStatus != 12)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision7").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var gotoWorkPermit = Xrm.Page.getAttribute("dobnyc_task_clickheretogotoworkpermit");
        var workPermitId = gotoWorkPermit.getValue()[0].id;
        var allowApproval_pr = true;
        var allowApproval_sp = true;
        var allowApproval_EN2 = true;
        var returnProgress = null;
        var returnSpecial = null;
        var returnWorkPermit = null;
        var returnEN2 = null;
        var retrunJobFiling = null;
        returnWorkPermit = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WP_TypeofPermit&$filter=dobnyc_workpermitId eq guid'" + workPermitId + "'");
        returnProgress = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_CertificateOfCompletionStatement,dobnyc_CertiOfCompletionECins,dobnyc_EneryCodeCertiOfComA,dobnyc_EneryCodeCertiOfComB,dobnyc_InspectionType&$filter=dobnyc_ProgressionInspectioncategorytoId/Id eq guid'" + jobfilingId + "'");
        returnSpecial = retrieveMultipleCustom("dobnyc_specialinspectioncategoriesSet", "?select=dobnyc_CertificateOfCompletionStatement,dobnyc_SpecialInspections&$filter=dobnyc_JobFilingtoSpecialInspectionsCaId/Id eq guid'" + jobfilingId + "' ");
        retrunJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_CompliacnewiththeNYCECC&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        var typeofPermit = returnWorkPermit[0].dobnyc_WP_TypeofPermit.Value;

        if (typeofPermit == 1 || typeofPermit == 3) // PL or SD validate EN2
        {
            var NYCECCCompliance = retrunJobFiling[0].dobnyc_CompliacnewiththeNYCECC;
            if (NYCECCCompliance != null && NYCECCCompliance == true) {
                returnEN2 = retrieveMultipleCustom("dobnyc_en2Set", "?select=dobnyc_ProgressInspectorStatementCheckBox&$filter=dobnyc_JobfiningtoEn2Id/Id eq guid'" + jobfilingId + "' ");
                if (returnEN2 == null || returnEN2.length == 0) {
                    alert("There is no EN2 record found. Work Type cannot be Sign off");
                    Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                    return;
                }
                if (returnEN2 != null && returnEN2.length > 0) {
                    for (var i = 0; i < returnEN2.length; i++) {
                        var dobnyc_ProgressInspectorStatementCheckBox = returnEN2[i].dobnyc_ProgressInspectorStatementCheckBox;
                        if (dobnyc_ProgressInspectorStatementCheckBox != true)
                            allowApproval_EN2 = false;
                    }
                }
                if (allowApproval_EN2 == false) {
                    alert("At least one of the EN2 is missing Progress Inspector Acknowledgement. Work Type cannot be Sign off");
                    Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                    return;

                }
            }
        }

        if (returnProgress != null && returnProgress.length > 0) {
            //alert("returnProgress.length = " + returnProgress.length);
            for (var i = 0; i < returnProgress.length; i++) {
                var dobnyc_InspectionType = returnProgress[i].dobnyc_InspectionType.Value;

                if (dobnyc_InspectionType == 1) {
                    var dobnyc_CertificateOfCompletionStatement = returnProgress[i].dobnyc_CertificateOfCompletionStatement;
                    //alert(dobnyc_CertificateOfCompletionStatement);
                    if (dobnyc_CertificateOfCompletionStatement != true)
                        allowApproval_pr = false;
                }

                if (dobnyc_InspectionType == 2) {
                    var dobnyc_EneryCodeCertiOfComA = returnProgress[i].dobnyc_EneryCodeCertiOfComA;
                    var dobnyc_EneryCodeCertiOfComB = returnProgress[i].dobnyc_EneryCodeCertiOfComB;
                    //alert(dobnyc_DocumentStatus);
                    if (dobnyc_EneryCodeCertiOfComA == false && dobnyc_EneryCodeCertiOfComB == false)
                        allowApproval_pr = false;
                }


            }
        }

        if (returnSpecial != null && returnSpecial.length > 0) {
            //alert("returnSpecial.length = " + returnSpecial.length);
            for (var i = 0; i < returnSpecial.length; i++) {
                if (typeofPermit == 1) {
                    var SpecialInspection = returnSpecial[i].dobnyc_SpecialInspections;
                    var lookuptextvalue = SpecialInspection.Name.toUpperCase();
                    if (lookuptextvalue != "SPRINKLER SYSTEMS" && lookuptextvalue != "POST-INSTALLED ANCHORS") {
                        var dobnyc_CertificateOfCompletionStatement = returnSpecial[i].dobnyc_CertificateOfCompletionStatement;
                        if (dobnyc_CertificateOfCompletionStatement != true)
                            allowApproval_sp = false;
                    }

                }
                if (typeofPermit == 2) {
                    var SpecialInspection = returnSpecial[i].dobnyc_SpecialInspections;
                    var lookuptextvalue = SpecialInspection.Name.toUpperCase();
                    if (lookuptextvalue == "SPRINKLER SYSTEMS" || lookuptextvalue == "POST-INSTALLED ANCHORS" || lookuptextvalue == "FIRE-RESISTANT PENETRATIONS AND JOINTS") {
                        var dobnyc_CertificateOfCompletionStatement = returnSpecial[i].dobnyc_CertificateOfCompletionStatement;
                        if (dobnyc_CertificateOfCompletionStatement != true)
                            allowApproval_sp = false;
                    }

                }
                if (typeofPermit == 3) {
                    var SpecialInspection = returnSpecial[i].dobnyc_SpecialInspections;
                    var lookuptextvalue = SpecialInspection.Name.toUpperCase();
                    if (lookuptextvalue == "STANDPIPE SYSTEM") {
                        var dobnyc_CertificateOfCompletionStatement = returnSpecial[i].dobnyc_CertificateOfCompletionStatement;
                        if (dobnyc_CertificateOfCompletionStatement != true)
                            allowApproval_sp = false;
                    }

                }
                //var dobnyc_CertificateOfCompletionStatement = returnSpecial[i].dobnyc_CertificateOfCompletionStatement;
                //alert("Sp"+dobnyc_CertificateOfCompletionStatement);
                //if (dobnyc_CertificateOfCompletionStatement != true)
                //allowApproval_sp = false;

            }
        }
        if (allowApproval_pr == false && allowApproval_sp == true) {
            alert("At least one of the Progress Inspection is missing Certificate of Completion. Work Type cannot be Sign off");
            Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
        }
        if (allowApproval_pr == false && allowApproval_sp == false) {
            alert("At least one of the Progress Inspection and Special Inspection is missing Certificate of Completion. Work Type cannot be Sign off");
            Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
        }
        if (allowApproval_pr == true && allowApproval_sp == false) {
            alert("At least one of the Special Inspection is missing Certificate of Completion. Work Type cannot be Sign off");
            Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
        }
        if (allowApproval_pr == true && allowApproval_sp == true) {
            //alert ("Permits Issued!");
        }
    }

}


function getAllStageCollection() {
    var collectionReturn = "";
    var activeProcess = Xrm.Page.data.process.getActiveProcess();
    var stageCollection = activeProcess.getStages();
    stageCollection.forEach(function (stage, n) {

        var name = stage.getName();
        collectionReturn = collectionReturn + name + ";"
    }
    )


    // alert(collectionReturn);
    return collectionReturn;
}

// Show / Hide Sections
function setVisibleTabSection(tabname, sectionnames, showhide, processName) {
    var tab = Xrm.Page.ui.tabs.get(tabname);
    if (tab != null) {
        if (sectionnames == "")
            tab.setVisible(showhide);
        else {
            var idsArray = sectionnames.split(";");
            for (var i = 0; i < idsArray.length; i++) {

                if (idsArray[i] != null && idsArray[i] != "") {
                    var section = tab.sections.get(idsArray[i]);
                    if (section != null && idsArray[i].indexOf(tabname) == -1) {
                        if (processName == "")
                            section.setVisible(showhide);

                        if (processName != "" && idsArray[i].indexOf(processName) != -1)
                            section.setVisible(showhide);
                    }

                }
            }
        }
    }
}

// Calculate total cost added in related entity Cost Detail

function calculateTotalCost() {
    try {
        var formType = Xrm.Page.ui.getFormType();

        if (formType == 1)
            return;

        //var FEE_SUBMITTED = "dobnyc_feesubmitted";
        //var TOTAL_WORK_COST = "dobnyc_totaljobcost";
        var isFeeSubmitted = Xrm.Page.getAttribute(DOBJF.HiddenFeeSubmitted).getValue();

        if (isFeeSubmitted)
            return;

        var totalCost = 0;
        var PlCost = 0;
        var SPCost = 0;
        var Id = Xrm.Page.data.entity.getId();
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_categoriesofworkdetailSet", "?select=dobnyc_WorkCategory,dobnyc_TotalCost&$filter=dobnyc_CategoriesofWorkId/Id eq guid'" + Id + "'");


        if (returnValue != null && returnValue[0] != null) {

            for (var i = 0; i < returnValue.length; i++) {
                if (returnValue[i].dobnyc_TotalCost != null) {
                    totalCost += parseFloat(returnValue[i].dobnyc_TotalCost.Value);

                    if (returnValue[i].dobnyc_WorkCategory.Value == 1) {
                        PlCost += parseFloat(returnValue[i].dobnyc_TotalCost.Value)
                    }
                    else {
                        SPCost += parseFloat(returnValue[i].dobnyc_TotalCost.Value)
                    }
                }
            }
            Xrm.Page.getAttribute(DOBJF.TotalWorkCost).setValue(parseFloat(totalCost));
            Xrm.Page.getAttribute("dobnyc_totalplumbingcost").setValue(parseFloat(PlCost));
            Xrm.Page.getAttribute("dobnyc_totalsprinklercost").setValue(parseFloat(SPCost));
            Xrm.Page.getAttribute(DOBJF.TotalWorkCost).setSubmitMode("always");
        }
        else {
            Xrm.Page.getAttribute(DOBJF.TotalWorkCost).setValue(null);
            Xrm.Page.getAttribute("dobnyc_totalplumbingcost").setValue(null);
            Xrm.Page.getAttribute("dobnyc_totalsprinklercost").setValue(null);
            Xrm.Page.getAttribute(DOBJF.TotalWorkCost).setSubmitMode("always");
        }
        // when total job cost have some value in it, it is pushed to estimated job cost

        //if (DOBJF.TotalWorkCost != null)
        //{
        //Xrm.Page.getAttribute("dobnyc_estimatedjobcost").setValue(parseFloat(totalCost));
        // }
    }


    catch (err) {

    }
}

// Function to MAke Service Call to related entity and map the fields
function setRestRetrieveReturnFields(odasetName, fieldName, setFieldNames, objectFieldNames, fieldTypeNames, fireOnChangeFields) {
    var lookup = Xrm.Page.getAttribute(fieldName).getValue();

    if (lookup != null) {
        var id = lookup[0].id;
        retrieveRecordCustom(id, odasetName, setRestRetrieveReturnFieldsCompleted, null, setFieldNames, objectFieldNames, fieldTypeNames, fireOnChangeFields);
    }
    else {
        var setFields = setFieldNames.split(";");
        for (var i = 0; i < setFields.length; i++) {
            Xrm.Page.getAttribute(setFields[i]).setValue(null);
        }
    }
}

function setRestRetrieveReturnFieldsCompleted(data, textStatus, XmlHttpRequest, setFieldNames, objectFieldNames, fieldTypeNames, fireOnChangeFields) {
    if (data != null) {
        var setFields = setFieldNames.split(";");
        var objectFields = objectFieldNames.split(";");
        var fieldTypes = fieldTypeNames.split(";")

        for (var i = 0; i < setFields.length; i++) {

            if (Xrm.Page.getAttribute(setFields[i]) != null) {
                if (data[objectFields[i]] == null) {
                    Xrm.Page.getAttribute(setFields[i]).setValue(null);
                }
                else {
                    if (fieldTypes[i] == "string") {
                        Xrm.Page.getAttribute(setFields[i]).setValue(data[objectFields[i]]);
                    }
                    else if (fieldTypes[i] == "datetime") {
                        var dateValue = new Date(parseInt(data[objectFields[i]].replace("/Date(", "").replace(")/", ""), 10));
                        Xrm.Page.getAttribute(setFields[i]).setValue(dateValue);
                    }
                    else if (fieldTypes[i] == "optionset") {
                        Xrm.Page.getAttribute(setFields[i]).setValue(data[objectFields[i]]["Value"]);
                    }
                    else if (fieldTypes[i] == "currency") {
                        Xrm.Page.getAttribute(setFields[i]).setValue(parseFloat(data[objectFields[i]]["Value"]));
                    }
                    else if (fieldTypes[i] == "decimal") {
                        Xrm.Page.getAttribute(setFields[i]).setValue(parseFloat(data[objectFields[i]]));
                    }
                    else if (fieldTypes[i] == "object") {
                        if (data[objectFields[i]]["Id"] != null) {
                            var lookupValue = new Array();
                            lookupValue[0] = new Object();
                            lookupValue[0].id = data[objectFields[i]]["Id"];
                            lookupValue[0].name = data[objectFields[i]]["Name"];
                            lookupValue[0].entityType = data[objectFields[i]]["LogicalName"];
                            Xrm.Page.getAttribute(setFields[i]).setValue(lookupValue);
                        }
                    }

                    if (fireOnChangeFields.indexOf(setFields[i]) != -1)
                        Xrm.Page.getAttribute(setFields[i]).fireOnChange();
                }

                Xrm.Page.getAttribute(setFields[i]).setSubmitMode("always");
            }
        }
    }
}

function getLookupId(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}

function onPayment() // Payment function required
{
    if (!confirm(getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationConfirmPayment)))
        return;

    var recordId = Xrm.Page.data.entity.getId().replace("{", "").replace("}", "");
    var workflowId = getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationPaymentWorkFlowId);
    if (!onDemandWorkflow(recordId, workflowId))
        return;

    Xrm.page.getAttribute("dobnyc_enableribbonpayment").setValue(true);
    Xrm.Page.data.entity.save();

}

function onWithdrawalRequest() {
    var withdrawalRequestFlag = Xrm.Page.getAttribute("dobnyc_iswithdrawalrequestmade").getValue();
    var withdrawalof = Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalof").getText();
    var withdrawalof_value = Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalof").getValue();
    var isAfterPermit = Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").getValue();

    if (withdrawalRequestFlag == true) {
        if (withdrawalof != null) {
            var message = "Would you like to Submit Withdrawal Request of:" + withdrawalof;
            Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
            function yesCloseCallback() {
                if ((withdrawalof_value == 1 || withdrawalof_value == 2 || withdrawalof_value == 3 || withdrawalof_value == 6) && (isAfterPermit == true)) {
                    Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalstatus").setValue(1);
                    Xrm.Page.getAttribute("dobnyc_createawithdrawalrequest").setValue(1);

                }
                else {
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(16);
                    Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalstatus").setValue(1);
                    Xrm.Page.getAttribute("dobnyc_createawithdrawalrequest").setValue(1);
                }
            }
            function noCloseCallback() {
                Xrm.Page.getAttribute("dobnyc_iswithdrawalrequestmade").setValue(false);
            }
        }
        else {
            alert("Please select the Withdrawal of options");
            Xrm.Page.getAttribute("dobnyc_iswithdrawalrequestmade").setValue(false);
            Xrm.Page.getAttribute("dobnyc_createawithdrawalrequest").setValue(0);
        }
    }
    else {
        Xrm.Page.getAttribute("dobnyc_createawithdrawalrequest").setValue(0);
        return;
    }

}

function onChangeLocation() // change current filing status to Pending Plan Examiner
{
    var changeLocFlag = Xrm.Page.getAttribute("dobnyc_ischangelocationrequest").getValue();
    if (changeLocFlag == true)
        Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(3);
    else
        return;
}

function onMinorChange()  // changes the current status and runs the workflow  
{
    alert("you have a minor change");
    var minorChange = Xrm.Page.getAttribute("dobnyc_isminorplanchanges").getValue();
    var proCert = Xrm.Page.getAttribute("dobnyc_professionalcertificate").getValue();

    if (minorChange == true) {
        if (proCert == true) {
            Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
        }
        else
            Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(3);
    }
    else
        return;

}

function onSubmit() // submit function for inspection, permit etc
{
    //alert("Hi Script working ");
    if (!confirm(getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationConfirmSubmit)))
        return;

    var proCert = Xrm.Page.getAttribute("dobnyc_professionalcertificate").getValue();
    var revertDP = Xrm.Page.getAttribute("dobnyc_revertedtodpfrom").getValue();
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
    var pAAbyMod3or12 = Xrm.Page.getAttribute("dobnyc_ispaabymodsec3or12").getValue();
    //alert(proCert);
    //alert(revertDP);
    //alert(currentFillingStatus);

    if (proCert == true) {
        switch (revertDP) {
            case 1:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                break;
            case 5:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(8);
                break;
            default:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                break;
        }

    }

    else {
        switch (revertDP) {
            case 1:
                if (currentFillingStatus == 2) {
                    if (pAAbyMod3or12 == true)
                        Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                    else
                        Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(3);
                    break;
                }
                if (currentFillingStatus == 6) {
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                }
                else
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(3);
                break;
            case 2:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(3);
                break;
            case 3:
                if (currentFillingStatus == 6) {
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                }
                else
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(4);
                break;
            case 4:
                if (currentFillingStatus == 6) {
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                }
                else
                    Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(4);
                break;
            case 5:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(8);
                break;
            default:
                Xrm.Page.getAttribute("dobnyc_currentfilingstatus").setValue(7);
                break;
        }
    }


}

function isAfterPermitIssued() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();

    if (currentFillingStatus == 16)
        return;
    if (currentFillingStatus == 10 || currentFillingStatus == 18) {
        Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").setValue(true);
        var flag = Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").getValue();

    }
    else {
        Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").setValue(false);
        var flag = Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").getValue();

    }
}

function onSave() // submit function for inspection, permit etc
{
    // NotMandatoryFormFields();
    Xrm.Page.data.entity.save();

}

function onRefresh() {
    //createRelatedApplication()
    Xrm.Page.getControl("DocumentList").refresh();
    Xrm.Page.getControl("Inspection").refresh();
    Xrm.Page.getControl("Tasks").refresh();
    Xrm.Page.getControl("Emails").refresh();

}


function disableSubgrid(subgridName) {
    document.getElementById(subgridName + "_span").disabled = "true";

}

function onHoldStatus()  // use when Withdrawal request is made and On Hold
{
    if (Xrm.Page.ui.getFormType() == 2 && Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue() == 16) {
        disableFormFields(true);
    }
}

function disableFormFields(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }

    }
    );
    //Xrm.Page.getControl("dobnyc_currentfilingstatus").setDisabled(false);
}

function doesControlHaveattribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}

function NotMandatoryFormFields() {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (!control.getDisabled()) {
            if (doesControlHaveattribute(control)) {
                SetRequirementLevel(control.getName(), 'none');
            }
        }
    }
    );
}
// JavaScript Document                                                                                                                                                              

function SetRequirementLevel(setFieldNames, reqLevel) {
    //reqLevel = none or required or recommended
    if (setFieldNames != "") {
        var fieldsArray = setFieldNames.split(";");
        for (var i = 0; i < fieldsArray.length; i++) {
            var field = Xrm.Page.getAttribute(fieldsArray[i]);
            if (field != null)
                field.setRequiredLevel(reqLevel);
        }
    }
}

function formLoadFunction() {
    showHideTabeBPF();
    hideShowFieldsJobFiling();
    var formType = Xrm.Page.ui.getFormType();
    Xrm.Page.data.process.addOnStageSelected(showHideTabeBPFSelection);
    Xrm.Page.data.process.addOnStageChange(showHideTabeBPF);

    if (formType == 1)
        return;


    // Show and Hide Tabs On Load
    // Add Show / HId Tab on Stage Selected


    Xrm.Page.ui.refreshRibbon();

    var disableStages = getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationDisableStages);
    var currentStage = Xrm.Page.getAttribute("dobnyc_currentstage").getValue();
    if (disableStages.indexOf(currentStage) != -1) {
        disableFormFields(true);

    }

    var filingStatus = Xrm.Page.getAttribute(DOBJF.FilingStatusType).getValue();
    // if (filingStatus == 2) {
    //    compareApplicationRecord();
    //setFieldColors("dobnyc_name;dobnyc_streetname;dobnyc_workonfloors;dobnyc_lot");
    //  }

    //setDisabled(false, "header_process_dobnyc_isworkpermitavailable;dobnyc_currentstage;header_process_dobnyc_isplanexaminerstage;header_process_dobnyc_isinspectionstage;header_process_dobnyc_issignoffstage");


    /// refresh Ribbon

    if (Xrm.Page.getAttribute(DOBJF.BinOnHold).getValue() == true) {
        document.getElementById(DOBJF.BinOnHold).style.color = "red";
        document.getElementById(DOBJF.BinOnHold).style.backgroundColor = "red";
    }
    if (Xrm.Page.getAttribute(DOBJF.WorkPermitViolation).getValue() == true) {
        document.getElementById(DOBJF.WorkPermitViolation).style.color = "red";
        document.getElementById(DOBJF.WorkPermitViolation).style.backgroundColor = "red";
    }
    disableFormFields(true);
}


function getAutoNumberRecord(key) {
    /// get Data from configuration entity
    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Page.context.getUserLcid() + "'");

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0];

    return null;
}



function autoNumbergeneration() {
    try {
        var entityToBeUpdate = new Object();
        var autoNumberFieldAttribute = "dobnyc_name";
        var currentNumber = 0;
        var currentAutoNumberEntity = getAutoNumberRecord("CurrentAutoNumberValue");
        if (currentAutoNumberEntity != null) {
            currentNumber += parseInt(currentAutoNumberEntity.dobnyc_name);
            var Id = currentAutoNumberEntity.dobnyc_customconfigurationsId;
            entityToBeUpdate[autoNumberFieldAttribute] = currentNumber;
            updateRecord(Id, entityToBeUpdate, "dobnyc_customconfigurationsSet", updateCompletedPostBack, updateErrorPostBack)
        }
    }

    catch (err) {
        // alert(err);
    }

}

function updateCompletedPostBack(data, textStatus, XmlHttpRequest) {
    return true;
}


function updateErrorPostBack(request, textStatus, errorThrown) {
    return false;
}


function formatAutoNumber(stringValue) {
    var currentate = new datetime();
    var fomratedDate_yyyymmdd = currentate.toISOString().slice(0, 10).replace(/-/g, "");
    var pad = "0000"
    var padString = pad.substring(0, pad.length - stringValue.length) + stringValue;
    var formattedString = fomratedDate_yyyymmdd + "-" + padString;
    return formattedString;
}

function createRelatedApplication(filingType) {
    if (filingType == 3) // logic for Subsequent filing when Withdrawal request is made
    {
        //var isAfterPermitIssued = Xrm.Page.getAttribute("dobnyc_jobfiling_isafterpermitissued").getValue();
        //var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
        var withdrawalof = Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalof").getValue();
        var withdrawalof_Text = Xrm.Page.getAttribute("dobnyc_jobfiling_withdrawalof").getText();
        var createWithdrawalRequest = Xrm.Page.getAttribute("dobnyc_createawithdrawalrequest").getValue();

        if (createWithdrawalRequest == true) {
            if (withdrawalof == 1 || withdrawalof == 5) {
                alert("Subsequent Filing Request cannot be made at this time because one of the following reasons; \n * Job Withdrawal Request is made. \n * Applicant of Record Withdrawal Request is made.");
                return;

            }

        }

    }
    var parameters = [];
    var parentRecord = new Object();
    parentRecord.Id = Xrm.Page.data.entity.getId();
    parentRecord.Name = Xrm.Page.getAttribute(DOBJF.EntityNameAttribute).getValue();
    parameters[DOBJF.CreateFormID] = Xrm.Page.data.entity.getId();
    parameters[DOBJF.CreateFormType] = getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationJobFilingEntityCode);
    parameters[DOBJF.FilingStatusType] = filingType;
    Xrm.Utility.openEntityForm(DOBJF.JobFilingEntityName, null, parameters);

}

function setDisabled(onOff, fieldNames) {
    //alert(fieldNames);
    if (fieldNames != null && fieldNames != "") {
        var fields = fieldNames.split(";");
        for (var i = 0; i < fields.length; i++) {
            Xrm.Page.ui.controls.get(fields[i]).setDisabled(onOff);
        }
    }
}

function setDefaultFieldColors(fieldNames) {
    if (fieldNames != "") {
        var fieldsArray = fieldNames.split(",");
        for (var i = 0; i < fieldsArray.length; i++) {
            if (document.getElementById(fieldsArray[i]) != null) {

                document.getElementById(fieldsArray[i]).style.backgroundColor = "white";
            }
        }
    }
}

function compareApplicationRecord() {
    var fieldMappingConfigurationRecord = getMessage(DOBJF.CustomConfiguratonKey.CustomConfigurationFieldMappingSet);
    if (fieldMappingConfigurationRecord != null) {
        var fieldMappingArray = fieldMappingConfigurationRecord.split(";");
        var formFields = fieldMappingArray[0].split(",");
        var relatedEntityFields = fieldMappingArray[1].split(",");
        var relatedEntityData = getParentApplicationRecord(relatedEntityFields);  // Must be case sensitive in configuration
        if (relatedEntityData == null)
            return;

        setDefaultFieldColors(fieldMappingArray[0]);
        for (var i = 0; i < formFields.length; i++) {
            var attr = Xrm.Page.getAttribute(formFields[i]);
            if (attr != null && attr != undefined) {
                if (attr.getAttributeType() == 'lookup') {
                    if (attr.getValue() != null && attr.getValue()[0] != null && attr.getValue()[0] != relatedEntityData[relatedEntityFields[i]].Id) {
                        document.getElementById(formFields[i]).style.color = "red";
                        document.getElementById(formFields[i]).style.backgroundColor = "red";
                    }
                    else if (attr.getValue() != relatedEntityData[relatedEntityFields[i]]) {
                        document.getElementById(formFields[i]).style.color = "red";
                        document.getElementById(formFields[i]).style.backgroundColor = "red";
                    }
                }
                else if (attr.getAttributeType() == 'money') {
                    if (attr.getValue() != relatedEntityData[relatedEntityFields[i]]) {
                        document.getElementById(formFields[i]).style.color = "red";
                        document.getElementById(formFields[i]).style.backgroundColor = "red";
                    }
                }
                else if (attr.getAttributeType() != 'money' && attr.getAttributeType() != 'lookup') {
                    if (attr.getValue() != relatedEntityData[relatedEntityFields[i]]) {
                        document.getElementById(formFields[i]).style.color = "red";
                        document.getElementById(formFields[i]).style.backgroundColor = "red";
                    }
                }
            }
        }
    }
}

function setVisibleAll(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setVisible(onOff);
        }
    }
    );
}

function onResubmit() {
    var withdrawalof = Xrm.Page.getAttribute("dobnyc_withdrawalrequest_withdrawalof").getText();
    var withdrawalStatus = Xrm.Page.getAttribute("dobnyc_withdrawalrequest_withdrawalstatus").getValue();
    if (withdrawalStatus == 12 || withdrawalStatus == 13) {
        var message = "Would you like to Resubmit Withdrawal Request of:" + withdrawalof;
        Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
        function yesCloseCallback() {
            Xrm.Page.getAttribute("dobnyc_withdrawalrequest_withdrawalstatus").setValue(2);
        }
        function noCloseCallback() {
            return;
        }
    }
    else
        alert("You cannot Resubmit Withdrawal Request at this moment");

}

function getRecordGuid() {
    var currentCaseId = Xrm.Page.data.entity.getId();
    Xrm.Page.getAttribute("dobnyc_inspectioncomponentguid").setValue(currentCaseId);
}

function getParentApplicationRecord(fieldsArray) {
    /// get Data from configuration entity
    var returnValue = null;
    var parentJobGUID = getLookupId(DOBJF.ParentJobFilingLookup);
    if (parentJobGUID == null)
        return null;
    returnValue = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=" + fieldsArray + "&$filter=dobnyc_jobfilingId eq guid'" + parentJobGUID + "'");

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0];

    return null;
}

function isPlanApproved() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
    var professionalCertification = Xrm.Page.getAttribute("dobnyc_professionalcertificate").getValue();
    var isWorkPermitAvailable = Xrm.Page.getAttribute("dobnyc_isworkpermitavailable").getValue();

    if (currentFillingStatus == 16)
        return;

    if (isWorkPermitAvailable == true) {
        if (currentFillingStatus == 6 || currentFillingStatus == 7 || currentFillingStatus == 8 || currentFillingStatus == 9 || currentFillingStatus == 10 || currentFillingStatus == 18) {
            Xrm.Page.getAttribute("dobnyc_isplanapproved").setValue(true);
            return;
        }
        else {
            Xrm.Page.getAttribute("dobnyc_isplanapproved").setValue(false);
            return;
        }

    }

    else
        Xrm.Page.getAttribute("dobnyc_isplanapproved").setValue(false);

}

function hideDocuments_AHVTaskForm() {
    var isAHVrequest = Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade").getValue();
    if (isAHVrequest == true) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(false);

    }
    else {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(true);

    }
}

function getJobFilingRecordGuid() {
    var currentCaseId = Xrm.Page.data.entity.getId();
    Xrm.Page.getAttribute("dobnyc_jobfilingguid").setValue(currentCaseId);
}

function hideSection_TaskForm() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFillingStatus == 5) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_5").setVisible(true);

    }
    else {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_5").setVisible(false);

    }
}

function LdCSS() {

    var path = "/WebResources/dobnyc_custom";
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = path;
    link.media = 'all';
    head.appendChild(link);
}
function hideshowCostAffidavitFields() {
    if (PlWorkType == true)
        setVisible(true, "dobnyc_totalplumbingcost")
    else
        setVisible(false, "dobnyc_totalplumbingcost")
    if (SpWorkType == true)
        setVisible(true, "dobnyc_totalsprinklercost")
    else
        setVisible(false, "dobnyc_totalsprinklercost")
    if (PlLegalWorkType == true)
        setVisible(true, "dobnyc_totallegalizationplumbingcost")
    else
        setVisible(false, "dobnyc_totallegalizationplumbingcost")
    if (SpLegalWorkType == true)
        setVisible(true, "dobnyc_totallegalizationsprinklercost")
    else
        setVisible(false, "dobnyc_totallegalizationsprinklercost")
    if (SDPiping == true)
        setVisible(true, "dobnyc_totalstandpipecost")
    else
        setVisible(false, "dobnyc_totalstandpipecost")
}
function hideShowFieldsJobFiling() {
    try {
        var compwithNYCECC = Xrm.Page.getAttribute("dobnyc_compliacnewiththenycecc").getValue();
        var exemNYCECC = Xrm.Page.getAttribute("dobnyc_exemptfromnycecc").getValue();
        var CRFN = Xrm.Page.getAttribute("dobnyc_crfnsrestrictivedeclarationeasement").getValue();
        var AddrViolation = Xrm.Page.getAttribute("dobnyc_filingtoaddressviolation").getValue();
        var ComplyToLocalLaws = Xrm.Page.getAttribute("dobnyc_complyingtolocallaws").getValue();

        if (compwithNYCECC == true) {

            setVisible(true, "dobnyc_codecompliancepath;dobnyc_energyanalysis");
            Xrm.Page.getAttribute("dobnyc_nyceccexemptifyeschooseone").setValue(null);
            Xrm.Page.getAttribute("dobnyc_exemptfromnycecc").setValue(null);
            setVisible(false, "dobnyc_exemptfromnycecc;dobnyc_nyceccexemptifyeschooseone");
        }

        else {
            setVisible(true, "dobnyc_exemptfromnycecc;dobnyc_nyceccexemptifyeschooseone");
            Xrm.Page.getAttribute("dobnyc_exemptfromnycecc").setValue(true);
            Xrm.Page.getAttribute("dobnyc_codecompliancepath").setValue(null);
            Xrm.Page.getAttribute("dobnyc_energyanalysis").setValue(null);
            setVisible(false, "dobnyc_codecompliancepath;dobnyc_energyanalysis");
        }


        if (stageName == DOBJF.SealsAndSignatureStageName) {
            var OwnerType = Xrm.Page.getAttribute("dobnyc_ownertypepw1statement").getValue();
            if (OwnerType == "7") {
                setVisible(true, "dobnyc_titlecondocoopboard");
                setVisible(false, "dobnyc_relationshiptoowner;dobnyc_businessnameandagency");
            }
            else {
                setVisible(true, "dobnyc_relationshiptoowner;dobnyc_businessnameandagency");
                setVisible(false, "dobnyc_titlecondocoopboard");
            }
        }

        if (SDPiping == true) {

            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(true);
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(true);
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_49").setVisible(true);
            setVisible(true, "dobnyc_existingstandpipe;dobnyc_proposedstandpipe");



        }
        else {

            setVisible(false, "dobnyc_existingstandpipe;dobnyc_proposedstandpipe");
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(false);
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(false);
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_49").setVisible(false);

        }

        if (CRFN == true)
            setVisible(true, "dobnyc_crfnnumber1;dobnyc_crfnnumber2;dobnyc_crfnnumber3;dobnyc_crfnnumber4");
        else
            setVisible(false, "dobnyc_crfnnumber1;dobnyc_crfnnumber2;dobnyc_crfnnumber3;dobnyc_crfnnumber4");

        if (AddrViolation == true)
            setVisible(true, "dobnyc_listviolationssdoborecb;dobnyc_ecbnumbers");
        else
            setVisible(false, "dobnyc_listviolationssdoborecb;dobnyc_ecbnumbers");

        if (ComplyToLocalLaws == true)
            setVisible(true, "dobnyc_listeachlawnumber");
        else
            setVisible(false, "dobnyc_listeachlawnumber");
    }

    catch (err) {
    }
}

function SdFloodHazardArea() {
    var FloodhazardareaSDPiping = Xrm.Page.getAttribute("dobnyc_floodhazardarea").getValue();
    if (FloodhazardareaSDPiping == true) {
        setVisible(true, "dobnyc_substantialimprovement;dobnyc_substantiallydamaged;dobnyc_floodshieldspartofproposedwork");
    }
    else {
        setVisible(false, "dobnyc_substantialimprovement;dobnyc_substantiallydamaged;dobnyc_floodshieldspartofproposedwork");
    }
}

function ApprovedPermit() {
    var Id = Xrm.Page.data.entity.getId();
    var WPID = Id.substring(1, Id.length - 1);
    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WorkPermit_Status,dobnyc_WP_Borough&$filter=dobnyc_workpermitId eq guid'" + Id + "'");

    if (returnValue != null && returnValue[0] != null) {
        if (((returnValue[0].dobnyc_WorkPermit_Status).Value == 4 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 7 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 10 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 12 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 13) && (returnValue[0].dobnyc_WP_Borough).Value == 1) {
            Xrm.Utility.openWebResource("dobnyc_ApprovedWorkPermit", WPID);
        }
        else if (((returnValue[0].dobnyc_WorkPermit_Status).Value == 4 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 7 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 10 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 12 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 13) && (returnValue[0].dobnyc_WP_Borough).Value == 3) {
            Xrm.Utility.openWebResource("dobnyc_WorkPermitBrooklyn", WPID);
        }
        else if (((returnValue[0].dobnyc_WorkPermit_Status).Value == 4 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 7 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 10 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 12 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 13) && (returnValue[0].dobnyc_WP_Borough).Value == 2) {
            Xrm.Utility.openWebResource("dobnyc_WorkPermitBronx", WPID);
        }
        else if (((returnValue[0].dobnyc_WorkPermit_Status).Value == 4 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 7 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 10 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 12 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 13) && (returnValue[0].dobnyc_WP_Borough).Value == 4) {
            Xrm.Utility.openWebResource("dobnyc_WorkPermitQueens", WPID);
        }
        else if (((returnValue[0].dobnyc_WorkPermit_Status).Value == 4 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 7 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 10 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 12 || (returnValue[0].dobnyc_WorkPermit_Status).Value == 13) && (returnValue[0].dobnyc_WP_Borough).Value == 5) {
            Xrm.Utility.openWebResource("dobnyc_WorkPermitStateIsland", WPID);
        }
        else {
            alert("Permit is Not Yet Issued");
        }
    }
}

function ProCertQAinProcess() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFillingStatus == 26) {
        Xrm.Page.getAttribute("dobnyc_task_qareviewinprocess").setValue(true);
        Xrm.Page.getAttribute("dobnyc_current").setValue(27);
        //Xrm.Page.data.entity.save();

        var Isworkpermitavailable = Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable").getValue();
        if (Isworkpermitavailable == false) {
            Xrm.Page.getAttribute("dobnyc_qadecision").setRequiredLevel("none");
            Xrm.Page.getControl("dobnyc_qadecision").setVisible(false);
            Xrm.Page.getControl("dobnyc_task_qadecision6").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_task_qadecision6").setRequiredLevel("required");
        }



    }
    if (currentFillingStatus == 27) {

        var Isworkpermitavailable = Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable").getValue();
        if (Isworkpermitavailable == false) {
            Xrm.Page.getAttribute("dobnyc_qadecision").setRequiredLevel("none");
            Xrm.Page.getControl("dobnyc_qadecision").setVisible(false);
            Xrm.Page.getControl("dobnyc_task_qadecision6").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_task_qadecision6").setRequiredLevel("required");
        }


    }
    else {
        Xrm.Page.getAttribute("dobnyc_task_qareviewinprocess").setValue(false);
        //Xrm.Page.data.entity.save();

    }
}



function showWorkPermits_QATaskForm() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    var Isworkpermitavailable = Xrm.Page.getAttribute("dobnyc_task_isworkpermitavailable").getValue();
    var IswithdrawalTask = Xrm.Page.getAttribute("dobnyc_task_iswithdrawalrequestmade").getValue();
    if (Isworkpermitavailable == true && (currentFillingStatus == 25 || currentFillingStatus == 26 || currentFillingStatus == 27)) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_9").setVisible(true);

    }
    if (IswithdrawalTask == true) {
        var WithdrawalStatus = Xrm.Page.getAttribute("dobnyc_task_withdrawstatus").getValue();
        var IsInspComp = Xrm.Page.getAttribute("dobnyc_isinspectioncompleted").getValue();
        if (WithdrawalStatus == 2 && IsInspComp == true) {
            Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(false);
            var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
            var jobfilingId = gotojobFiling.getValue()[0].id;
            //alert("jobfilingId: " + jobfilingId);
            var ConnectionSubgrid = document.getElementById("WorkPermitd_Inspection");
            if (ConnectionSubgrid == null) {
                setTimeout(function () { showWorkPermits_QATaskForm(); }, 2000); //if the grid hasn’t loaded run this again
                return;
            }
            //alert("geting FetchXml");
            var fetchXml = "<?xml version='1.0'?>" +
                            "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                            "<entity name='dobnyc_workpermit'>" +
                            "<attribute name='dobnyc_workpermitid' />" +
                            "<attribute name='dobnyc_name' />" +
                            "<attribute name='createdon' />" +
                            "<attribute name='dobnyc_workpermittojobfilingrelationshid' />" +
                            "<attribute name='dobnyc_workpermit_status' /> " +
                            "<attribute name='dobnyc_wp_typeofpermit' /> " +
                            "<attribute name='dobnyc_trackingnumber' /> " +
                            "<attribute name='dobnyc_applicantcontractor' /> " +
                            "<order attribute='dobnyc_name' descending='false' /> " +
                            "<filter type='and'>" +
                            "<condition attribute='dobnyc_workpermittojobfilingrelationshid' operator='eq' uitype='dobnyc_jobfiling' value='" + jobfilingId + "' />" +
                            "<condition attribute='dobnyc_wp_inspectioncompleted' operator='eq' value='1' /> " +
                            "</filter>" +
                            "</entity>" +
                            "</fetch>";
            var changesetRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
            //alert(changesetRecords.length);

            ConnectionSubgrid.control.SetParameter("fetchXml", fetchXml);
            if (changesetRecords.length > 0) {
                ConnectionSubgrid.control.Refresh();
                Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_11").setVisible(true);
                //alert("Got FetchXml");

            }

        }
    }

}

function SetDocumentList_QATask() {
    var IsAHVTask = Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade").getValue();
    if (IsAHVTask == true) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(false);
        return;
    }
    else {
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var DocumentSubgrid = document.getElementById("Documents");
        if (DocumentSubgrid == null) {
            setTimeout(function () { SetDocumentList_QATask(); }, 2000); //if the grid hasn’t loaded run this again
            Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(false);
            return;
        }
        var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
 "<entity name='dobnyc_documentlist'>" +
   "<attribute name='dobnyc_documentlistid' />" +
   "<attribute name='createdon' />" +
   "<attribute name='dobnyc_documentlist_priortostatus' />" +
   "<attribute name='dobnyc_documentstatus' />" +
   "<attribute name='dobnyc_documentnamedocumentlist' />" +
   "<attribute name='dobnyc_waiverrequested' />" +
   "<order attribute='createdon' descending='false' />" +
   "<filter type='and'>" +
   "<filter type='or'>" +
       "<condition attribute='dobnyc_manuallyselected' operator='eq' value='0' />" +
       "<condition attribute='dobnyc_manuallyselected' operator='null' />" +
     "</filter>" +
     "<condition attribute='dobnyc_documentlisttojobfilingid' operator='eq' uitype='dobnyc_jobfiling' value='" + jobfilingId + "' />" +
     "<condition attribute='dobnyc_parentdocument' operator='null' />" +
     "</filter>" +
 "</entity>" +
"</fetch>";

        var documentlistRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
        var documentCount = documentlistRecords.length;
        DocumentSubgrid.control.SetParameter("fetchXml", fetchXml);
        if (documentlistRecords.length > 0) {
            Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("TASK_TAB_section_6").setVisible(true);
            DocumentSubgrid.control.Refresh();
        }
    }
}

function SetSupportingDocumentList_QATask() {
    var IsAHVTask = Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade").getValue();
    if (IsAHVTask == true) {
        Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("Task_section_11").setVisible(false);
        return;
    }
    else {
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var DocumentSubgrid = document.getElementById("SupportingDocuments");
        if (DocumentSubgrid == null) {
            setTimeout(function () { SetSupportingDocumentList_QATask(); }, 2000); //if the grid hasn’t loaded run this again
            Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("Task_section_11").setVisible(false);
            return;
        }
        var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
 "<entity name='dobnyc_documentlist'>" +
   "<attribute name='dobnyc_documentlistid' />" +
   "<attribute name='createdon' />" +
   "<attribute name='dobnyc_documentlist_priortostatus' />" +
   "<attribute name='dobnyc_documentstatus' />" +
   "<attribute name='dobnyc_documentnamedocumentlist' />" +
   "<attribute name='dobnyc_waiverrequested' />" +
   "<order attribute='createdon' descending='false' />" +
   "<filter type='and'>" +
   "<filter type='or'>" +
       "<condition attribute='dobnyc_manuallyselected' operator='eq' value='1' />" +
       "</filter>" +
     "<condition attribute='dobnyc_documentlisttojobfilingid' operator='eq' uitype='dobnyc_jobfiling' value='" + jobfilingId + "' />" +
     "<condition attribute='dobnyc_parentdocument' operator='null' />" +
     "</filter>" +
 "</entity>" +
"</fetch>";

        var documentlistRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
        var documentCount = documentlistRecords.length;
        DocumentSubgrid.control.SetParameter("fetchXml", fetchXml);
        if (documentlistRecords.length > 0) {
            Xrm.Page.ui.tabs.get("TASK_TAB").sections.get("Task_section_11").setVisible(true);
            DocumentSubgrid.control.Refresh();
        }
    }
}


function AsBuiltInformation() {

    try {
        var AsBuiltInformation2 = Xrm.Page.getAttribute("dobnyc_asbuiltinformation2").getValue();

        if (AsBuiltInformation2 == true) {
            setVisible(true, "WebResource_AsBuiltInformationA;WebResource_AsBuiltInformationB;dobnyc_dateen2;dobnyc_asbuiltinformationa;dobnyc_asbuiltinformationb");
        }
        else if (AsBuiltInformation2 == false) {
            setVisible(false, "WebResource_AsBuiltInformationA;WebResource_AsBuiltInformationB;dobnyc_asbuiltinformationa;dobnyc_dateen2;dobnyc_asbuiltinformationb");
        }
    }
    catch (err)
    { }
}

function Appointmentvalidate() {
    var Isappointmentrequired = Xrm.Page.getAttribute("dobnyc_task_sdpappointment").getValue();
    if (Isappointmentrequired == 2) {
        var returnTaskObjections = null;
        var taskId = Xrm.Page.data.entity.getId();
        returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_TaskObjectionsId/Id eq guid'" + taskId + "'");
        //alert(returnTaskObjections.length);
        if (returnTaskObjections != null && returnTaskObjections.length == 0) {
            alert("Appointment cannot be requested without adding Objection.");
            Xrm.Page.getAttribute("dobnyc_task_sdpappointment").setValue(null);
        }

        var action = Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").getValue();
        if (action == 625470000) {
            alert("Appointment cannot be requested while approving.");
            Xrm.Page.getAttribute("dobnyc_task_sdpappointment").setValue(null);
        }


    }

}

function DocumentValidate_onApproval() {
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 4)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").getValue();
    if (action == 625470001) {
        Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").setValue(null);
        Xrm.Page.getControl("dobnyc_approvedplansuploaded").setVisible(false);
        var Isappointmentrequired = Xrm.Page.getAttribute("dobnyc_task_sdpappointment").getValue();
        //alert(Isappointmentrequired);
        if (Isappointmentrequired == 2) {
            var returnTaskObjections = null;
            var taskId = Xrm.Page.data.entity.getId();
            returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_TaskObjectionsId/Id eq guid'" + taskId + "'");
            //alert(returnTaskObjections.length);
            if (returnTaskObjections != null && returnTaskObjections.length == 0) {
                alert("Appointment cannot be requested without adding Objection!");
                Xrm.Page.getAttribute("dobnyc_task_sdpappointment").setValue(null);
                return;
            }
        }

        var returnTaskObjections = null;
        var taskId = Xrm.Page.data.entity.getId();
        returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_TaskObjectionsId/Id eq guid'" + taskId + "'");
        //alert(returnTaskObjections.length);
        if (returnTaskObjections != null && returnTaskObjections.length == 0) {
            alert("At least one Objection must be raised.");
            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
            return;
        }
        if (returnTaskObjections != null && returnTaskObjections.length > 0) {
            var objections_Check = false;
            for (var i = 0; i < returnTaskObjections.length; i++) {
                var dobnyc_task_ObjectionStatus = returnTaskObjections[i].dobnyc_task_ObjectionStatus.Value;
                //alert(dobnyc_task_ObjectionStatus);
                if (dobnyc_task_ObjectionStatus == 1) {
                    objections_Check = true;

                }
            }
            if (objections_Check == false) {
                alert("At least one Objection must be open Objection.");
                Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                return;

            }
            else {
                alert("Reminder! Please upload revised Plan with markups.");

            }
        }

        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 625470000) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var Isappointmentrequired = Xrm.Page.getAttribute("dobnyc_task_sdpappointment").getValue();
        //alert(Isappointmentrequired);
        if (Isappointmentrequired == 2) {
            alert("Appointment cannot be requested while Approving!");
            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
            return;

        }
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var taskId = Xrm.Page.data.entity.getId();
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var allowApproval = true;
        var allowApproval_Obj = true;
        var returnValue = null;
        var returnObjections = null;
        var returnJobFiling = null;
        var BinOnHold = false;
        var ApprovalonHold = false;
        var IsCorrectionInitiated = false;
        var IsCorrectionCompleted = false;
        var isProvideDocument = false;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "' or dobnyc_TaskDocumentsId/Id eq guid'" + taskId + "')and  dobnyc_ParentDocument eq null");
        returnObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_ObjectionstoJobFilingId/Id eq guid'" + jobfilingId + "'");
        returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_TaskObjectionsId/Id eq guid'" + taskId + "'");
        if (returnValue != null && returnValue.length > 0) {
            for (var i = 0; i < returnValue.length; i++) {
                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                var dobnyc_ManuallySelected = returnValue[i].dobnyc_ManuallySelected;
                var dobnyc_RejectionReason = returnValue[i].dobnyc_RejectionReason.Value;

                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 6) {
                    alert("All the documents required prior to approval are not submitted. ");
                    Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                    return;
                }
                //Documents which are not approved
                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6) {
                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                        allowApproval = true;
                    }
                    else {
                        allowApproval = false;
                    }
                }
            }
        }

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Approval_onHold == "Y") {
                        alert("Approval is on hold for this Filing. Plans cannot be approved.");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                        return;

                    }
                    else {
                        BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
                        IsCorrectionInitiated = returnJobFiling[0].dobnyc_IsCorrectionInitiated;
                        IsCorrectionCompleted = returnJobFiling[0].dobnyc_IsCorrectionCompleted;
                        if (BinOnHold == true) {
                            alert("The Filing is on hold. Filing cannot be approved.");
                            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                            return;
                        }
                        if (IsCorrectionInitiated == true) {
                            alert("Please be noted that corrections have been initiated by Applicant of Record during your review. \n Filing cannot be approved until corrections are completed");
                            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                            return;
                        }
                        if (IsCorrectionCompleted == true) {
                            alert("Please be noted that corrections have been made by Applicant of Record.");
                        }

                        if (returnObjections != null && returnObjections.length > 0) {
                            for (var i = 0; i < returnObjections.length; i++) {
                                var dobnyc_task_ObjectionStatus = returnObjections[i].dobnyc_task_ObjectionStatus.Value;
                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_task_ObjectionStatus != 3 && dobnyc_task_ObjectionStatus != 4)
                                    allowApproval_Obj = false;

                            }
                        }
                        if (returnTaskObjections != null && returnTaskObjections.length > 0) {
                            //alert("returnTaskObjections: " + returnTaskObjections.length);
                            for (var i = 0; i < returnTaskObjections.length; i++) {
                                var dobnyc_task_ObjectionStatus2 = returnTaskObjections[i].dobnyc_task_ObjectionStatus.Value;
                                //alert(dobnyc_task_ObjectionStatus2);
                                if (dobnyc_task_ObjectionStatus2 != 3 && dobnyc_task_ObjectionStatus2 != 4)
                                    allowApproval_Obj = false;

                            }
                        }
                        if (allowApproval == false && allowApproval_Obj == true) {
                            alert("Please accept all the documents required before approval.");
                            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                            Xrm.Page.getControl("dobnyc_approvedplansuploaded").setVisible(false);
                            return;
                        }
                        if (allowApproval == false && allowApproval_Obj == false) {
                            alert("Please accept all the documents and close all Objections before approval.");
                            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                        }
                        if (allowApproval == true && allowApproval_Obj == false) {
                            alert("Please close all open Objections before approval.");
                            Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").setValue(null);
                        }
                        if (allowApproval == true && allowApproval_Obj == true) {
                            Xrm.Page.getControl("dobnyc_approvedplansuploaded").setVisible(true);
                            Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").setRequiredLevel("required");
                            alert("Please confirm that approved plan set is sealed and uploaded.");
                            var control = Xrm.Page.ui.controls.get("dobnyc_approvedplansuploaded");
                            control.setFocus();
                        }

                    }


                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        }
    }
}

function DocumentValidate_onApprovalCPE() {

    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 5)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_reviewactions").getValue();
    if (action == 2 || action == 3) {
        var returnTaskObjections = null;
        var taskId = Xrm.Page.data.entity.getId();
        returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_ChiefPlanExaminerObjectionsId/Id eq guid'" + taskId + "'");
        //alert(returnTaskObjections.length);
        if (returnTaskObjections != null && returnTaskObjections.length == 0) {
            alert("At least one Objection must be raised.");
            Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
            return;
        }
        if (returnTaskObjections != null && returnTaskObjections.length > 0) {
            var objections_Check = false;
            for (var i = 0; i < returnTaskObjections.length; i++) {
                var dobnyc_task_ObjectionStatus = returnTaskObjections[i].dobnyc_task_ObjectionStatus.Value;
                //alert(dobnyc_task_ObjectionStatus);
                if (dobnyc_task_ObjectionStatus == 1) {
                    objections_Check = true;

                }
            }
            if (objections_Check == false) {
                alert("At least one Objection must be open Objection.");
                Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
                return;

            }
        }
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var taskId = Xrm.Page.data.entity.getId();
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var allowApproval = true;
        var allowApproval_Obj = true;
        var returnValue = null;
        var returnObjections = null;
        var returnTaskObjections = null;
        var returnJobFiling = null;
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "' or dobnyc_ChiefPlanExaminerDocumentsId/Id eq guid'" + taskId + "') and  dobnyc_ParentDocument eq null");
        returnObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_ObjectionstoJobFilingId/Id eq guid'" + jobfilingId + "'");
        returnTaskObjections = retrieveMultipleCustom("dobnyc_objectionsSet", "?select=dobnyc_task_ObjectionStatus&$filter=dobnyc_ChiefPlanExaminerObjectionsId/Id eq guid'" + taskId + "'");
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Approval_onHold == "Y") {
                        alert("Approval is on hold for this Filing. Plans cannot be approved.");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
                        return;

                    }
                    else {
                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && dobnyc_Documentlist_PriortoStatus == 6) {
                                    alert("All the documents required prior to approval are not submitted.");
                                    Xrm.Page.getAttribute("dobnyc_qadecision7").setValue(null);
                                    return;
                                }

                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6) {
                                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                                        allowApproval = true;
                                    }
                                    else {
                                        allowApproval = false;
                                    }
                                }

                            }
                        }
                        if (returnObjections != null && returnObjections.length > 0) {
                            for (var i = 0; i < returnObjections.length; i++) {
                                var dobnyc_task_ObjectionStatus = returnObjections[i].dobnyc_task_ObjectionStatus.Value;
                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_task_ObjectionStatus != 4 && dobnyc_task_ObjectionStatus != 3)
                                    allowApproval_Obj = false;

                            }
                        }
                        if (returnTaskObjections != null && returnTaskObjections.length > 0) {
                            //alert("returnTaskObjections: " + returnTaskObjections.length);
                            for (var i = 0; i < returnTaskObjections.length; i++) {
                                var dobnyc_task_ObjectionStatus2 = returnTaskObjections[i].dobnyc_task_ObjectionStatus.Value;
                                //alert(dobnyc_task_ObjectionStatus2);
                                if (dobnyc_task_ObjectionStatus2 != 4 && dobnyc_task_ObjectionStatus2 != 3)
                                    allowApproval_Obj = false;

                            }
                        }
                        if (allowApproval == false && allowApproval_Obj == true) {
                            alert("Please accept all the documents before Approval.");
                            Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
                        }
                        if (allowApproval == false && allowApproval_Obj == false) {
                            alert("Please accept all the documents and dismiss all Objections before approval.");
                            Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
                        }
                        if (allowApproval == true && allowApproval_Obj == false) {
                            alert("Please dismiss all Open Objections before approval.");
                            Xrm.Page.getAttribute("dobnyc_reviewactions").setValue(null);
                        }
                        if (allowApproval == true && allowApproval_Obj == true) {
                            //alert ("Plans Approved!");
                        }
                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while downloding document. Please try again or contact administrator.");
                }
            });
        }

    }

}
function HighlightNoGoodCheck() {
    var formType = Xrm.Page.ui.getFormType();
    if (formType != 1) {
        var filingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
        if (filingStatus == 21) {
            document.getElementById("dobnyc_currentfilingstatus").style.color = "red";
            document.getElementById("dobnyc_currentfilingstatus").style.backgroundColor = "red";
        }

    }
}

function HighlightchengeSetFields() {
    var formType = Xrm.Page.ui.getFormType();
    if (formType != 1) {
        var filingId = Xrm.Page.data.entity.getId();
        var entityName = Xrm.Page.data.entity.getEntityName();

        var changesetRecords = retrieveMultipleCustom("dobnyc_jobfilingchangesetSet", "?select=dobnyc_name&$filter=dobnyc_JobFiling/Id eq guid'" + filingId + "' and dobnyc_EntityName eq '" + entityName + "'");

        if (changesetRecords.length > 0) {

            for (var i = 0; i < changesetRecords.length; i++) {
                if (changesetRecords[i].dobnyc_name != undefined) {
                    var attributename = changesetRecords[i].dobnyc_name;
                    document.getElementById(attributename).style.color = "red";
                    document.getElementById(attributename).style.backgroundColor = "red";
                }
            }
        }
    }
}
function HighlightchangeSetScopeOfWorkFields() {
    var formType = Xrm.Page.ui.getFormType();
    if (formType != 1) {
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_schedulebuildingsystemstojobfilid");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var entityName = Xrm.Page.data.entity.getEntityName();

        var changesetRecords = retrieveMultipleCustom("dobnyc_jobfilingchangesetSet", "?select=dobnyc_name&$filter=dobnyc_JobFiling/Id eq guid'" + jobfilingId + "' and dobnyc_EntityName eq '" + entityName + "'");
        if (changesetRecords.length > 0) {

            for (var i = 0; i < changesetRecords.length; i++) {
                if (changesetRecords[i].attributes.dobnyc_name != undefined) {
                    var attributename = changesetRecords[i].attributes.dobnyc_name;
                    document.getElementById(attributename).style.color = "red";
                    document.getElementById(attributename).style.backgroundColor = "red";
                }
            }
        }
    }
}

function HighlightchangeSetWorkCostDetailFields() {
    var formType = Xrm.Page.ui.getFormType();
    if (formType != 1) {
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_categoriesofworkid");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var entityName = Xrm.Page.data.entity.getEntityName();

        var changesetRecords = retrieveMultipleCustom("dobnyc_jobfilingchangesetSet", "?select=dobnyc_name&$filter=dobnyc_JobFiling/Id eq guid'" + jobfilingId + "' and dobnyc_EntityName eq '" + entityName + "'");
        if (changesetRecords.length > 0) {

            for (var i = 0; i < changesetRecords.length; i++) {
                if (changesetRecords[i].attributes.dobnyc_name != undefined) {
                    var attributename = changesetRecords[i].attributes.dobnyc_name;
                    document.getElementById(attributename).style.color = "red";
                    document.getElementById(attributename).style.backgroundColor = "red";
                }
            }
        }
    }
}



function AHVOnLoad() {

    // var Id = getLookupId("dobnyc_jobfiling");
    // if (Id == null)
    // return;
    // var returnValue = null;
    // returnValue = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_JobDescription&$filter=dobnyc_jobfilingId eq guid'" + Id + "'");

    // if (returnValue != null && returnValue[0] != null) {
    // var Set = returnValue[0].dobnyc_JobDescription;

    // Xrm.Page.getAttribute("dobnyc_jobdescription").setValue(Set);
    // Xrm.Page.getAttribute("dobnyc_jobdescription").setSubmitMode("always");
    // }

    disableFormFields(true);
}

function PermitDocValidate_onPermitIssue() {
    var taskId = Xrm.Page.data.entity.getId();
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 27)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setValue(1);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
        Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
        Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");


        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var taskId = Xrm.Page.data.entity.getId();
        var allowApproval = true;
        var allowPermitIssue = true;
        var sealSig_Accepted = true;
        var returnValue = null;
        var returnPermits = null;
        var returnTaskPermits = null;
        var returnJobFiling = null;
        var QAFailedStatus = 0;
        returnValue = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_Documentlist_PriortoStatus,dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "' or dobnyc_ProfQADocumentId/Id eq guid'" + taskId + "') and  dobnyc_ParentDocument eq null");
        returnPermits = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_TrackingNumber,dobnyc_WorkPermit_Status,dobnyc_workpermitId,dobnyc_WP_TypeofPermit&$filter=dobnyc_WorkPermittoJobFilingRelationshId/Id eq guid'" + jobfilingId + "' and dobnyc_IsWorkPermitSubmitted eq true");
        returnTaskPermits = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WorkPermit_Status&$filter=dobnyc_QAWorkPermitsId/Id eq guid'" + taskId + "'");
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold,dobnyc_QAFailedStatus,dobnyc_QAFailedReason&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        var count = document.getElementById("WorkPermits").control.get_totalRecordCount();
        //alert(count);

        ///Validating Special and Progress Inspection documents acceptance at the time of issuing Work Permit
        var jobName = gotojobFiling.getValue()[0].name;

        if (ValidateInspectionCategories(returnPermits, jobName) == false) { return; }

        if (returnTaskPermits.length != count) {
            alert("Additional Permits have been filed during the review. Please review newly added Permits.");
            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
            Xrm.Page.ui.controls.get("WorkPermits").refresh();
            return;

        }
        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            QAFailedStatus = returnJobFiling[0].dobnyc_QAFailedStatus.Value;
            if (QAFailedStatus == 2) {
                alert("QA Failed Status will be set to closed automatically.");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(3);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(returnJobFiling[0].dobnyc_QAFailedReason);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);

                //return;
            }
            else {
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);
                Xrm.Page.getControl("dobnyc_task_status").setVisible(false);
                //return;
            }
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    var trackingNos = "";
                    if (data.Approval_onHold == "Y") {
                        alert("Approval is on Hold for this Filing. Permits cannot be issued!");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                        return;

                    }
                    if (data.Permit_onHold == "Y") {
                        alert("Permit is on Hold for this Filing. Permits cannot be issued!");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                        return;

                    }
                    else {
                        if (returnTaskPermits.length != returnPermits.length) {
                            alert("Additional Permits have been filed during the review. Please review newly added Permits.");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            Xrm.Page.ui.controls.get("WorkPermits").refresh();
                        }

                        // validate Seal and Signature in each permit
                        if (returnPermits != null && returnPermits.length > 0) {
                            var tempNumber = '';
                            for (var j = 0; j < returnPermits.length; j++) {
                                var workPermitId = returnPermits[j].dobnyc_workpermitId;
                                var trackingNumber = returnPermits[j].dobnyc_TrackingNumber;
                                var returnSealSig = null;
                                returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWorkPermit/Id eq guid'" + workPermitId + "'and  dobnyc_ParentDocument eq null");
                                if (returnSealSig != null && returnSealSig.length > 0) {
                                    for (var i = 0; i < returnSealSig.length; i++) {
                                        var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;
                                        if (dobnyc_DocumentStatus != 3) {
                                            sealSig_Accepted = false;
                                            tempNumber += trackingNumber + ' ';
                                        }

                                    }

                                }

                            }
                            trackingNos = tempNumber;
                        }
                        if (sealSig_Accepted == false) {
                            alert("Please accept the Seal & Signature in Permit(s) with tracking# " + trackingNos + ".");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                            return;
                        }

                        if (returnValue != null && returnValue.length > 0) {
                            for (var i = 0; i < returnValue.length; i++) {
                                var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                                var dobnyc_ManuallySelected = returnValue[i].dobnyc_ManuallySelected;
                                var dobnyc_RejectionReason = returnValue[i].dobnyc_RejectionReason.Value;
                                //alert(dobnyc_DocumentStatus);

                                if ((dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2) && (dobnyc_Documentlist_PriortoStatus == 6 || dobnyc_Documentlist_PriortoStatus == 10)) {
                                    alert("All the documents required prior to Approval or Permit Issued are not submitted.");
                                    Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                                    Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                                    Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                                    return;
                                }
                                //Documents which are not approved
                                //debugger;
                                if (dobnyc_DocumentStatus != 3 && (dobnyc_Documentlist_PriortoStatus == 6 || dobnyc_Documentlist_PriortoStatus == 10)) {
                                    if (dobnyc_DocumentStatus == 4 && dobnyc_RejectionReason == 1 && allowApproval == true && dobnyc_ManuallySelected == true) {
                                        allowApproval = true;
                                    }
                                    else {
                                        allowApproval = false;
                                    }
                                }
                            }
                        }

                        if (allowApproval == false) {
                            alert("Please accept all the documents before Approval and Permit Issuance.");
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                            Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                        }

                        if (allowApproval == true) {
                            alert("Permit(s) will be issued now once the task is completed.");
                        }

                    }
                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occurred while getting BIS violation Flags. Please try again or contact administrator.");
                }
            });
        }

    } //
}



function WorkCostDetailTotalCost() {
    var UnitCost = Xrm.Page.getAttribute("dobnyc_unitcost").getValue();
    var Area = Xrm.Page.getAttribute("dobnyc_areaunits_num").getValue();

    var Total = UnitCost * Area;
    Xrm.Page.getAttribute("dobnyc_totalcost").setValue(Total);

}

function MeetingComplete() {
    var Meetingstatus = Xrm.Page.getAttribute("dobnyc_meetingstatus").getValue();
    if (Meetingstatus == 1) {
        Xrm.Page.getControl("dobnyc_meetingoutcome").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setRequiredLevel("required");
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setValue(null);
        Xrm.Page.getControl("dobnyc_reasonforcancellation").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_describeother").setValue(null);
        Xrm.Page.getControl("dobnyc_describeother").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setValue(null);

    }
    if (Meetingstatus == 3) {
        Xrm.Page.getControl("dobnyc_reasonforcancellation").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setRequiredLevel("required");
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setValue(null);
        Xrm.Page.getControl("dobnyc_meetingoutcome").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_describeother").setValue(null);
        Xrm.Page.getControl("dobnyc_describeother").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setValue(null);

    }
    if (Meetingstatus == 2 || Meetingstatus == null) {
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setValue(null);
        Xrm.Page.getControl("dobnyc_meetingoutcome").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setValue(null);
        Xrm.Page.getControl("dobnyc_reasonforcancellation").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_describeother").setValue(null);
        Xrm.Page.getControl("dobnyc_describeother").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setValue(null);
    }
}

function CancelOther() {
    var reasonforcancellation = Xrm.Page.getAttribute("dobnyc_reasonforcancellation").getValue();
    if (reasonforcancellation == 4) {
        Xrm.Page.getControl("dobnyc_describeother").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("required");
    }
    else {
        Xrm.Page.getAttribute("dobnyc_describeother").setValue(null);
        Xrm.Page.getControl("dobnyc_describeother").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("none");

    }

}


function RescheduleApt() {

    Xrm.Page.getAttribute("dobnyc_isreschedule").setValue(false);
    Xrm.Page.getAttribute("dobnyc_iscompleted").setValue(false);
    Xrm.Page.data.entity.save();
    var gotojobFiling = Xrm.Page.getAttribute("regardingobjectid");
    var jobfilingId = gotojobFiling.getValue()[0].id;
    var returnscheduleApt = retrieveMultipleCustom("AppointmentSet", "?select=dobnyc_MeetingStatus&$filter=RegardingObjectId/Id eq guid'" + jobfilingId + "' and StateCode/Value eq 3");
    //alert("returnscheduleApt.length" + returnscheduleApt.length);
    if (returnscheduleApt != null && returnscheduleApt.length > 0) {
        alert("Appointment cannot be Rescheduled. There is already a Scheduled Appointment against this Job Filing");
        return;

    }

    var allow = true;
    allow = validateTimeSlots();
    if (allow == false)
        return;

    var message = "Would you like to reschedule this Appointment";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        Xrm.Page.getAttribute("dobnyc_isreschedule").setValue(true);
        Xrm.Page.getAttribute("dobnyc_iscompleted").setValue(false);
        Xrm.Page.getAttribute("dobnyc_meetingstatus").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_meetingstatus").setValue(null);
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setValue(null);
        Xrm.Page.getControl("dobnyc_meetingoutcome").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_meetingoutcome").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setValue(null);
        Xrm.Page.getControl("dobnyc_reasonforcancellation").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforcancellation").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_describeother").setValue(null);
        Xrm.Page.getControl("dobnyc_describeother").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_describeother").setRequiredLevel("none");
        Xrm.Page.data.entity.save();
        LockAppointmentFields();

    }
    function noCloseCallback() {
        return;
    }
}

function ProfQAClerk_Correction() {
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 27)
        return;

    var action = Xrm.Page.getAttribute("dobnyc_qadecision").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(true);
        Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("required");
        Xrm.Page.getAttribute("dobnyc_task_status").setValue(1);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
        Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");

        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var BinOnHold = false;
        var IsCorrectionInitiated = false;
        var IsCorrectionCompleted = false;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
            IsCorrectionInitiated = returnJobFiling[0].dobnyc_IsCorrectionInitiated;
            IsCorrectionCompleted = returnJobFiling[0].dobnyc_IsCorrectionCompleted;

            if (BinOnHold == true) {
                alert("The BIN is on Hold. Filing cannot be approved!");
                Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                return;
            }
            if (IsCorrectionInitiated == true) {
                alert("Please be noted that corrections have been initiated by Applicant of Record during your review. \n Filing cannot be approved until corrections are completed");
                Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                return;
            }
            if (IsCorrectionCompleted == true) {
                alert("Please be noted that corrections have been made by Applicant of Record.");
            }

        }

    }



}

function CPEvalidation() {

    var taskId = Xrm.Page.data.entity.getId();
    var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
    var jobfilingId = gotojobFiling.getValue()[0].id;
    var rejectedDocCount = 0;
    var returnRejectedDocs = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=(dobnyc_DocumentListtoJobfilingId/Id eq guid'" + jobfilingId + "' or dobnyc_ChiefPlanExaminerDocumentsId/Id eq guid'" + taskId + "')and  dobnyc_ParentDocument eq null");
    if (returnRejectedDocs != null && returnRejectedDocs.length > 0) {
        for (var i = 0; i < returnRejectedDocs.length; i++) {
            if (returnRejectedDocs[i].dobnyc_DocumentStatus.Value == 4 && returnRejectedDocs[i].dobnyc_RejectionReason.Value != 1)

                rejectedDocCount++;
        }
    }

    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 5 && currentFilingStatus != 3)
        return;

    var action = Xrm.Page.getAttribute("dobnyc_isthejobapplicationcomplete2").getValue();
    if (rejectedDocCount > 0 && action == 2) {
        alert("Job with rejected documents can't be completed.");
        Xrm.Page.getAttribute("new_planexaminer").setValue(null);
        Xrm.Page.getAttribute("dobnyc_isthejobapplicationcomplete2").setValue(null);
        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        //var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        //var jobfilingId = gotojobFiling.getValue()[0].id;
        var BinOnHold = false;
        var IsCorrectionInitiated = false;
        var IsCorrectionCompleted = false;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
            IsCorrectionInitiated = returnJobFiling[0].dobnyc_IsCorrectionInitiated;
            IsCorrectionCompleted = returnJobFiling[0].dobnyc_IsCorrectionCompleted;

            if (BinOnHold == true) {
                alert("The BIN is on Hold. Filing cannot be approved!");
                Xrm.Page.getAttribute("dobnyc_isthejobapplicationcomplete2").setValue(null);
                return;
            }
            if (IsCorrectionInitiated == true) {
                alert("Please be noted that corrections have been initiated by Applicant of Record during your review. \n Filing cannot be approved until corrections are completed");
                Xrm.Page.getAttribute("dobnyc_isthejobapplicationcomplete2").setValue(null);
                return;
            }
            if (IsCorrectionCompleted == true) {
                alert("Please be noted that corrections have been made by Applicant of Record.");
            }

        }

    }

}

function ProfQAClerk_Correction2() {
    var currentFilingStatus = Xrm.Page.getAttribute("dobnyc_current").getValue();
    if (currentFilingStatus != 27)
        return;

    var action = Xrm.Page.getAttribute("dobnyc_task_qadecision6").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_task_status").setValue(1);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
        Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
        Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
        Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(true);
        Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("required");

        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");


        Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
        var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotojobFiling.getValue()[0].id;
        var BinOnHold = false;
        var IsCorrectionInitiated = false;
        var IsCorrectionCompleted = false;
        var QAFailedStatus = 0;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_IsCorrectionCompleted,dobnyc_IsCorrectionInitiated,dobnyc_QAFailedReason,dobnyc_QAFailedStatus,dobnyc_BinOnHold&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            BinOnHold = returnJobFiling[0].dobnyc_BinOnHold;
            IsCorrectionInitiated = returnJobFiling[0].dobnyc_IsCorrectionInitiated;
            IsCorrectionCompleted = returnJobFiling[0].dobnyc_IsCorrectionCompleted;
            QAFailedStatus = returnJobFiling[0].dobnyc_QAFailedStatus.Value;

            if (QAFailedStatus == 2) {
                alert("QA Failed Status will be set to closed automatically.");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(3);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getControl("dobnyc_task_status").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(returnJobFiling[0].dobnyc_QAFailedReason);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);
                return;
            }
            else {
                Xrm.Page.getAttribute("dobnyc_task_status").setValue(null);
                Xrm.Page.ui.controls.get("dobnyc_task_status").setDisabled(true);
                Xrm.Page.getAttribute("dobnyc_task_status").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setValue(null);
                Xrm.Page.getAttribute("dobnyc_qafailedreason").setRequiredLevel("none");
                Xrm.Page.getControl("dobnyc_qafailedreason").setVisible(false);
                Xrm.Page.getControl("dobnyc_task_status").setVisible(false);
                return;
            }

            if (BinOnHold == true) {
                alert("The BIN is on Hold. Filing cannot be approved!");
                Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                return;
            }
            if (IsCorrectionInitiated == true) {
                alert("Please be noted that corrections have been initiated by Applicant of Record during your review. \n Filing cannot be approved until corrections are completed");
                Xrm.Page.getAttribute("dobnyc_task_qadecision6").setValue(null);
                return;
            }
            if (IsCorrectionCompleted == true) {
                alert("Please be noted that corrections have been made by Applicant of Record.");
            }

        }

    }



}
function AntennaWorkonFloor_Change() {
    var AntennaWorkonFloor = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
    if (AntennaWorkonFloor == true) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("antennaworkonfloors").setVisible(true);
        Xrm.Page.getControl("dobnyc_workonfloors").setVisible(false);
    }
    else {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("antennaworkonfloors").setVisible(false);
        Xrm.Page.getControl("dobnyc_workonfloors").setVisible(true);
    }

}
function Applicationhighlights() {
    var filingType = Xrm.Page.getAttribute("dobnyc_filingstatustype").getValue();
    var CreateSuperseding = Xrm.Page.getAttribute("dobnyc_jobfiling_createasupersedingrequest").getValue();
    var InspectionComplete = Xrm.Page.getAttribute("dobnyc_jf_inspectioncompleted").getValue();
    var AntennaWorkonFloor = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
    if (AntennaWorkonFloor == true) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("antennaworkonfloors").setVisible(true);

    }
    if (InspectionComplete == true) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_53").setVisible(true);

    }
    if (filingType == 1) {
        if (CreateSuperseding == true) {
            Xrm.Page.getControl("dobnyc_parentjobfiling").setVisible(true);
            Xrm.Page.getControl("dobnyc_jobfiling_supersedingrequeststatus").setVisible(true);
            Xrm.Page.getControl("dobnyc_supersedingdprequestno").setVisible(true);
        }
        else {
            Xrm.Page.getControl("dobnyc_parentjobfiling").setVisible(false);
            Xrm.Page.getControl("dobnyc_supersedingdprequestno").setVisible(false);
        }
        Xrm.Page.getControl("dobnyc_paafee").setVisible(false);
    }
    if (filingType == 2) {
        Xrm.Page.getControl("dobnyc_parentjobfiling").setVisible(true);
        Xrm.Page.getControl("dobnyc_paafee").setVisible(true);

    }
    if (filingType == 3) {
        Xrm.Page.getControl("dobnyc_parentjobfiling").setVisible(true);
    }

    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
    if (currentFillingStatus == 3 || currentFillingStatus == 4 || currentFillingStatus == 5 || currentFillingStatus == 23 || currentFillingStatus == 25 || currentFillingStatus == 26 || currentFillingStatus == 27)
        Xrm.Page.getControl("dobnyc_jobfiling_currenttask").setVisible(true);

}

function CompleteApt() {
    Xrm.Page.data.entity.save();
    var Meetingstatus = Xrm.Page.getAttribute("dobnyc_meetingstatus").getValue();
    if (Meetingstatus == null) {
        alert("Please select appropriate meeting status!");
        Xrm.Page.getAttribute("dobnyc_meetingstatus").setRequiredLevel("required");
        var control = Xrm.Page.ui.controls.get("dobnyc_meetingstatus");
        control.setFocus();
        return;

    }
    if (Meetingstatus == 1) {
        var Meetingoutcome = Xrm.Page.getAttribute("dobnyc_meetingoutcome").getValue();
        if (Meetingoutcome == null) {
            alert("Please select appropriate meeting outcome!");
            var control = Xrm.Page.ui.controls.get("dobnyc_meetingoutcome");
            control.setFocus();
            return;
        }
        if (Meetingoutcome == 2) {
            var Reasonforunprepared = Xrm.Page.getAttribute("dobnyc_reasonforunprepared").getValue();

            if (Reasonforunprepared == null) {
                alert("Please provide reason for unprepared!");
                var control = Xrm.Page.ui.controls.get("dobnyc_reasonforunprepared");
                control.setFocus();
                return;

            }
        }

    }
    if (Meetingstatus == 3) {
        var ReasonforCancelation = Xrm.Page.getAttribute("dobnyc_reasonforcancellation").getValue();
        if (ReasonforCancelation == null) {
            alert("Please provide reason for cancellation!");
            var control = Xrm.Page.ui.controls.get("dobnyc_reasonforcancellation");
            control.setFocus();
            return;
        }

    }

    var currentUserId = Xrm.Page.context.getUserId();
    var currentUserRoles = GetRoleName(currentUserId);
    var allow = false;
    for (var i = 0; i < currentUserRoles.length; i++) {
        //var userRoleId = currentUserRoles[i];

        if (currentUserRoles[i].attributes.name.value == "BUILDNYC - Scheduling Coordinator" || currentUserRoles[i].attributes.name.value == "System Administrator")
            allow = true;
    }
    if (allow == false) {
        var startTime = Xrm.Page.getAttribute("scheduledstart").getValue();
        var endTime = Xrm.Page.getAttribute("scheduledend").getValue();
        var startTime_Full = startTime.toLocaleDateString();
        var endTime_Full = endTime.toLocaleDateString();
        var currentDateTime = new Date();
        if (startTime > currentDateTime || endTime > currentDateTime) {
            alert("Appointment cannot be completed before Appointment Start/End time!");
            return;
        }
    }

    var message = "Would you like to close this Appointment";
    Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
    function yesCloseCallback() {
        //Xrm.Page.data.entity.save();
        Xrm.Page.getAttribute("dobnyc_iscompleted").setValue(true);
        Xrm.Page.getAttribute("dobnyc_isreschedule").setValue(false);
        Xrm.Page.data.entity.save();
        disableFormFields(false);
    }
    function noCloseCallback() {
        return;
    }
}

function AppointmentType() {
    var appointmentType = Xrm.Page.getAttribute("dobnyc_appointmenttype").getValue();
    if (appointmentType == 1) {
        Xrm.Page.getControl("regardingobjectid").setVisible(true);
        Xrm.Page.getControl("requiredattendees").setVisible(true);
        Xrm.Page.getControl("scheduledstart").setShowTime(true);
        Xrm.Page.getControl("scheduledend").setShowTime(true);
        Xrm.Page.getControl("requiredattendees").setVisible(true);
    }
    if (appointmentType == 2) {
        Xrm.Page.getControl("regardingobjectid").setVisible(false);
        Xrm.Page.getControl("requiredattendees").setVisible(false);
        Xrm.Page.getControl("scheduledstart").setShowTime(true);
        Xrm.Page.getControl("scheduledend").setShowTime(true);
    }

}

function Timeslots(context) {
    var formType = Xrm.Page.ui.getFormType();
    if (formType == 1) {
        var saveEvent = context.getEventArgs();
        var appointmentType = Xrm.Page.getAttribute("dobnyc_appointmenttype").getValue();
        var allow = true;
        allow = validateTimeSlots();
        if (allow == false) {
            saveEvent.preventDefault();
            return;
        }

    }
}

function validateTimeSlots() {
    var startTime = Xrm.Page.getAttribute("scheduledstart").getValue();
    var endTime = Xrm.Page.getAttribute("scheduledend").getValue();
    var startTime_Full = startTime.toLocaleDateString();
    var endTime_Full = endTime.toLocaleDateString();
    var currentDateTime = new Date();
    var currentTime_Full = currentDateTime.toLocaleDateString();

    if (startTime < currentDateTime || endTime < currentDateTime) {
        alert("Start/End Date cannot be a past date!");
        Xrm.Page.getAttribute("scheduledstart").setValue(null);
        Xrm.Page.getAttribute("scheduledend").setValue(null);
        var control = Xrm.Page.ui.controls.get("scheduledstart");
        control.setFocus();
        return false;
    }
    if (startTime_Full != endTime_Full) {
        alert("You can only schedule Apppointment/Breaks within the same day!");
        var control = Xrm.Page.ui.controls.get("scheduledend");
        control.setFocus();
        return false;
    }

    if (startTime_Full == endTime_Full) {
        var start_Year = startTime.getFullYear();
        var start_hour = startTime.getHours();
        var start_min = startTime.getMinutes();
        var end_hour = endTime.getHours();
        var end_min = endTime.getMinutes();
        if (start_hour == end_hour) {
            if (start_min >= end_min) {
                alert("End Time cannot be less than/Equal to Start Time!");
                var control = Xrm.Page.ui.controls.get("scheduledend");
                control.setFocus();
                return false;

            }
            else {
                var minDifference = end_min - start_min;
                if (minDifference < 20) {
                    alert("At least 20 minutes Appointment/Break can be scheduled!");
                    var control = Xrm.Page.ui.controls.get("scheduledend");
                    control.setFocus();
                    return false;
                }
            }
        }
        if (start_hour > end_hour) {
            alert("End Time cannot be less than Start Time!");
            var control = Xrm.Page.ui.controls.get("scheduledend");
            control.setFocus();
            return false;

        }

    }

}

function DocValidate_onAHVIssue() // for QA Clerk Standard Plan Seal Signature
{
    var AHVpermitstatus = Xrm.Page.getAttribute("dobnyc_task_ahvpermitstatus").getValue();
    if (AHVpermitstatus != 2)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision5").getValue();
    if (action == 2 || action == 3) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        Xrm.Page.getAttribute("dobnyc_ahvreasonofapproval").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_ahvreasonofapproval").setVisible(false);

        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");
        Xrm.Page.getControl("dobnyc_ahvreasonofapproval").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_ahvreasonofapproval").setRequiredLevel("required");
        var control = Xrm.Page.ui.controls.get("dobnyc_ahvreasonofapproval");
        control.removeOption(10);

        var gotoAHVPermit = Xrm.Page.getAttribute("dobnyc_clickheretogotoahv");
        var AHVPermitId = gotoAHVPermit.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnAHV = null;
        returnAHV = retrieveMultipleCustom("dobnyc_afterhourvariancepw5Set", "?select=dobnyc_BIN&$filter=dobnyc_afterhourvariancepw5Id eq guid'" + AHVPermitId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoAHV/Id eq guid'" + AHVPermitId + "'and  dobnyc_ParentDocument eq null");

        if (returnAHV != null && returnAHV.length > 0) {
            var bin = returnAHV[0].dobnyc_BIN;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Approval_onHold == "Y") {
                        alert("Approval is on Hold for this Filing. AHV Request cannot be approved!");
                        ApprovalonHold = true;
                        Xrm.Page.getAttribute("dobnyc_qadecision5").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Contractor in AHV Permit!");
                            Xrm.Page.getAttribute("dobnyc_qadecision5").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onWithdrawalApproval() // for QA Clerk  Seal Signature
{
    var withdrawalStatus = Xrm.Page.getAttribute("dobnyc_task_withdrawstatus").getValue();
    if (withdrawalStatus != 2)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision_2").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 3) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoWithdrawal = Xrm.Page.getAttribute("dobnyc_task_clickheretogotowithdrawalrequest");
        var WithdrawalId = gotoWithdrawal.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWithdrawalRequest/Id eq guid'" + WithdrawalId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Withdrawal_onHold == "Y") {
                        alert("Withdrawal is on Hold for this Filing. Withdrawal Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_qadecision_2").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Withdrawal Request!");
                            Xrm.Page.getAttribute("dobnyc_qadecision_2").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onWithdrawalApproval2() // for QA Clerk  Seal Signature
{
    var withdrawalStatus = Xrm.Page.getAttribute("dobnyc_task_withdrawstatus").getValue();
    if (withdrawalStatus != 2)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision_1").getValue();
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoWithdrawal = Xrm.Page.getAttribute("dobnyc_task_clickheretogotowithdrawalrequest");
        var WithdrawalId = gotoWithdrawal.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWithdrawalRequest/Id eq guid'" + WithdrawalId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Withdrawal_onHold == "Y") {
                        alert("Withdrawal is on Hold for this Filing. Withdrawal Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_qadecision_1").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Withdrawal Request!");
                            Xrm.Page.getAttribute("dobnyc_qadecision_1").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onWithdrawalApproval3() // for QA Clerk  Seal Signature
{
    var withdrawalStatus = Xrm.Page.getAttribute("dobnyc_task_withdrawstatus").getValue();
    if (withdrawalStatus != 2)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision_3").getValue();
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoWithdrawal = Xrm.Page.getAttribute("dobnyc_task_clickheretogotowithdrawalrequest");
        var WithdrawalId = gotoWithdrawal.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWithdrawalRequest/Id eq guid'" + WithdrawalId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Withdrawal_onHold == "Y") {
                        alert("Withdrawal is on Hold for this Filing. Withdrawal Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_qadecision_3").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Withdrawal Request!");
                            Xrm.Page.getAttribute("dobnyc_qadecision_3").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onWithdrawalApproval_QASup() // for QA Supervisor Clerk  Seal Signature
{
    var withdrawalStatus = Xrm.Page.getAttribute("dobnyc_task_withdrawstatus").getValue();
    if (withdrawalStatus != 1)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_task_withdrawalapproved").getValue();
    if (action == false) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == true) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoWithdrawal = Xrm.Page.getAttribute("dobnyc_task_clickheretogotowithdrawalrequest");
        var WithdrawalId = gotoWithdrawal.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoWithdrawalRequest/Id eq guid'" + WithdrawalId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Withdrawal_onHold == "Y") {
                        alert("Withdrawal is on Hold for this Filing. Withdrawal Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_task_withdrawalapproved").setValue(null);
                        Xrm.Page.getAttribute("dobnyc_task_withdrawalapproved").setRequiredLevel("required");
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Withdrawal Request!");
                            Xrm.Page.getAttribute("dobnyc_task_withdrawalapproved").setValue(null);
                            Xrm.Page.getAttribute("dobnyc_task_withdrawalapproved").setRequiredLevel("required");
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onSupersedingApproval_QASup() // for QA Supervisor Clerk  Seal Signature
{
    var supersedingStatus = Xrm.Page.getAttribute("dobnyc_task_supersedingrequeststatus").getValue();
    var supersedingfor = Xrm.Page.getAttribute("dobnyc_task_supersedingrequestfor").getValue();
    if (supersedingStatus != 1 || supersedingfor == 1)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").getValue();
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoSuperseding = Xrm.Page.getAttribute("dobnyc_task_clickheretogotosupersedingrequest");
        var SupersedingId = gotoSuperseding.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoSupersedingRequest/Id eq guid'" + SupersedingId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Filing_onHold == "Y") {
                        alert("Filing is on Hold for this Filing. Superseding Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Superseding Request!");
                            Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onSupersedingApproval() // for QA  Clerk  Seal Signature
{
    var supersedingStatus = Xrm.Page.getAttribute("dobnyc_task_supersedingrequeststatus").getValue();
    var supersedingfor = Xrm.Page.getAttribute("dobnyc_task_supersedingrequestfor").getValue();
    if (supersedingStatus != 2 || supersedingfor == 1)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision_4").getValue();
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoSuperseding = Xrm.Page.getAttribute("dobnyc_task_clickheretogotosupersedingrequest");
        var SupersedingId = gotoSuperseding.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus&$filter=dobnyc_GotoSupersedingRequest/Id eq guid'" + SupersedingId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Filing_onHold == "Y") {
                        alert("Filing is on Hold for this Filing. Superseding Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_qadecision_4").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;

                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept Seal and Signature of Requester in Superseding Request!");
                            Xrm.Page.getAttribute("dobnyc_qadecision_4").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onSupersedingDPApproval() // for QA  Clerk  Seal Signature
{
    var supersedingStatus = Xrm.Page.getAttribute("dobnyc_task_supersedingrequeststatus").getValue();
    var supersedingfor = Xrm.Page.getAttribute("dobnyc_task_supersedingrequestfor").getValue();
    if (supersedingStatus != 2 || supersedingfor != 1)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_qadecision_4").getValue();
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("required");
        return;
    }
    if (action == 1) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoSuperseding = Xrm.Page.getAttribute("dobnyc_clickheretogotosupersedingdprequest");
        var SupersedingId = gotoSuperseding.getValue()[0].id;
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus,dobnyc_Documentlist_PriortoStatus&$filter=dobnyc_DocumentListtoJobfilingId/Id eq guid'" + SupersedingId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Filing_onHold == "Y") {
                        alert("Filing is on Hold for this Filing. Superseding Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_qadecision_4").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnSealSig[i].dobnyc_Documentlist_PriortoStatus.Value;
                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept all documents before approval!");
                            Xrm.Page.getAttribute("dobnyc_qadecision_4").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DocValidate_onSupersedingDPApproval_QASup() // for QA Supervisor Clerk  Seal Signature
{
    var supersedingStatus = Xrm.Page.getAttribute("dobnyc_task_supersedingrequeststatus").getValue();
    var supersedingfor = Xrm.Page.getAttribute("dobnyc_task_supersedingrequestfor").getValue();
    if (supersedingStatus != 1 || supersedingfor != 1)
        return;
    var action = Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").getValue();
    if (action == 2) {
        Xrm.Page.getAttribute("description").setRequiredLevel("none");

        var gotoJobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
        var jobfilingId = gotoJobFiling.getValue()[0].id;
        var gotoSuperseding = Xrm.Page.getAttribute("dobnyc_clickheretogotosupersedingdprequest");
        var SupersedingId = gotoSuperseding.getValue()[0].id;
        //alert(SupersedingId);
        var sealSig_Accepted = true;
        var returnSealSig = null;
        var returnJobFiling = null;
        returnJobFiling = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin&$filter=dobnyc_jobfilingId eq guid'" + jobfilingId + "'");
        returnSealSig = retrieveMultipleCustom("dobnyc_documentlistSet", "?select=dobnyc_DocumentStatus,dobnyc_Documentlist_PriortoStatus&$filter=dobnyc_DocumentListtoJobfilingId/Id eq guid'" + SupersedingId + "'and  dobnyc_ParentDocument eq null");

        if (returnJobFiling != null && returnJobFiling.length > 0) {
            var bin = returnJobFiling[0].dobnyc_Bin;
            //alert("BIN:" + bin);
            $.ajax({
                type: "POST",
                url: "http://10.155.208.61:5050/WrapperService.svc/GetViolationFlags",
                processData: true,
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                data: JSON.stringify({ BIN: bin }),
                cache: false,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data) {
                    if (data.Filing_onHold == "Y") {
                        alert("Filing is on Hold for this Filing. Superseding Request cannot be approved!");
                        Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").setValue(null);
                        return;

                    }
                    else {
                        if (returnSealSig != null && returnSealSig.length > 0) {
                            //alert(returnSealSig.length);
                            for (var i = 0; i < returnSealSig.length; i++) {
                                var dobnyc_DocumentStatus = returnSealSig[i].dobnyc_DocumentStatus.Value;
                                var dobnyc_Documentlist_PriortoStatus = returnSealSig[i].dobnyc_Documentlist_PriortoStatus.Value;
                                //alert(dobnyc_DocumentStatus);
                                if (dobnyc_DocumentStatus != 3 && dobnyc_Documentlist_PriortoStatus == 6)
                                    sealSig_Accepted = false;

                            }

                        }

                        if (sealSig_Accepted == false) {
                            alert("Please accept all documents before approval!");
                            Xrm.Page.getAttribute("dobnyc_task_qasupervisoraction").setValue(null);
                            return;
                        }

                    }

                },
                error: function (xhr, status, error) {
                    alert(error);
                    alert("An error occured while getting BIS flags. Please try again or contact administrator.");
                }
            });
        }

    }

}

function DisableSubgridNewButton() {
    //var populated = false;
    var CurrentForm = Xrm.Page.ui.formSelector.getCurrentItem();
    if (CurrentForm != null) {
        var strFormLabel = CurrentForm.getLabel();
        if (strFormLabel == "Job Filing") {
            var currentUserId = Xrm.Page.context.getUserId();
            var currentUserRoles = GetRoleName(currentUserId);

            for (var i = 0; i < currentUserRoles.length; i++) {
                //var userRoleId = currentUserRoles[i];

                if (currentUserRoles[i].attributes.name.value == "BUILDNYC - Operations Admin" || currentUserRoles[i].attributes.name.value == "System Administrator")
                    return true;
            }
            return false;
        }
        else if (strFormLabel == "QA Administrator Task form" || strFormLabel == "QA Supervisor Task Form") {
            return false;
        }
        else {
            return true;
        }
    }
}

function CheckUserRole() {
    try {
        var Meetingstatus = Xrm.Page.getAttribute("dobnyc_meetingstatus").getValue();
        var meetingOutcome = Xrm.Page.getAttribute("dobnyc_meetingoutcome").getValue();
        var Reason = Xrm.Page.getAttribute("dobnyc_reasonforcancellation").getValue();
        if (Meetingstatus == 1) {
            Xrm.Page.getControl("dobnyc_meetingoutcome").setVisible(true);
        }
        if (Meetingstatus == 3) {
            Xrm.Page.getControl("dobnyc_reasonforcancellation").setVisible(true);
        }
        if (Reason == 4) {
            Xrm.Page.getControl("dobnyc_describeother").setVisible(true);
        }
        if (meetingOutcome == 2) {
            Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(true);
        }
        var currentUserId = Xrm.Page.context.getUserId();
        var currentUserRoles = GetRoleName(currentUserId);
        var SCRole = false;
        var AdminRole = false;
        var PERole = false;
        for (var i = 0; i < currentUserRoles.length; i++) {
            //var userRoleId = currentUserRoles[i];

            if (currentUserRoles[i].attributes.name.value == "BUILDNYC - Scheduling Coordinator")
                SCRole = true;

            if (currentUserRoles[i].attributes.name.value == "System Administrator")
                AdminRole = true;

            if (currentUserRoles[i].attributes.name.value == "BUILDNYC - Plan Examiner" || currentUserRoles[i].attributes.name.value == "ELEVATORS - Plan Examiner")
                PERole = true;
        }
        if (SCRole == false && PERole == true && AdminRole == false) {
            var control = Xrm.Page.ui.controls.get("dobnyc_meetingstatus");
            control.removeOption(3);
            Xrm.Page.getControl("dobnyc_gotomeetinginvitecreated").setDisabled(true);

        }
        if (SCRole == true && PERole == false && AdminRole == false) {
            var control = Xrm.Page.ui.controls.get("dobnyc_meetingstatus");
            control.removeOption(1);
            control.removeOption(2);
        }


        var formType = Xrm.Page.ui.getFormType();
        if (formType == 2) {
            var Id = Xrm.Page.data.entity.getId();
            //alert(Id);
            var returnAppointment = null;
            returnAppointment = retrieveMultipleCustom("AppointmentSet", "?select=StateCode,StatusCode&$filter=ActivityId eq guid'" + Id + "'");
            if (returnAppointment != null && returnAppointment.length > 0) {
                var statecode = returnAppointment[0].StateCode.Value;
                //alert(statecode);
                if (statecode == 3) {
                    LockAppointmentFields();
                    return;
                }
            }

        }

        if (SCRole == false && AdminRole == false) {
            //disableFormFields(true);
            LockAppointmentFields();
        }
    }
    catch (Exception) {
        alert(Exception);
    }
}

function LockAppointmentFields() {
    Xrm.Page.getControl("dobnyc_appointmenttype").setDisabled(true);
    Xrm.Page.getControl("requiredattendees").setDisabled(true);
    Xrm.Page.getControl("organizer").setDisabled(true);
    Xrm.Page.getControl("regardingobjectid").setDisabled(true);
    Xrm.Page.getControl("scheduledstart").setDisabled(true);
    Xrm.Page.getControl("scheduledend").setDisabled(true);
    Xrm.Page.getControl("subject").setDisabled(true);

}

function GetRoleName(userId) {
    var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >" +
    "<entity name='role' >" +
        "<attribute name='name' />" +
        "<order attribute='name' descending='false' />" +
        "<link-entity name='systemuserroles' from='roleid' to='roleid' visible='false' intersect='true' >" +
            "<link-entity name='systemuser' from='systemuserid' to='systemuserid' alias='aa' >" +
                "<filter type='and' >" +
                    "<condition attribute='systemuserid' operator='eq' value='" + userId + "'/>" +
                "</filter>" +
            "</link-entity>" +
        "</link-entity>" +
    "</entity>" +
"</fetch>";
    var retrievedContacts = XrmServiceToolkit.Soap.Fetch(fetchXml);
    return retrievedContacts;
    //var serverUrl = Xrm.Page.context.getServerUrl();
    //var serverUrl = location.protocol + "//" + location.host + "/" + Xrm.Page.context.getOrgUniqueName();
    //var odataSelect = serverUrl + "/XRMServices/2011/OrganizationData.svc" + "/" + "RoleSet?$select=Name,lk_rolebase_createdby/SystemUserId&$expand=lk_rolebase_createdby&$filter=lk_rolebase_createdby/SystemUserId eq guid'" + userId + "'";
    //var roleName = null;
    //$.ajax(
    //    {
    //        type: "GET",
    //        async: false,
    //        contentType: "application/json; charset=utf-8",
    //        datatype: "json",
    //        url: odataSelect,
    //        beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
    //        success: function (data, textStatus, XmlHttpRequest) {
    //            roleName = data.d.results[0].Name;
    //        },
    //        error: function (XmlHttpRequest, textStatus, errorThrown) { alert('OData Select Failed: ' + textStatus + errorThrown + odataSelect); }
    //    }
    //);
}

function setPartyOrganizer() {
    var party = Xrm.Page.getAttribute("organizer");
    var attendees = party.getValue();
    for (var indxAttendees = 0; indxAttendees < attendees.length; indxAttendees++) {
        if (attendees[indxAttendees].type == 8) {

            var PlanExaminerId = attendees[indxAttendees].id;
            var PlanExaminerName = attendees[indxAttendees].name
            //alert(PlanExaminerId);
            //alert(PlanExaminerName);
            var lookup = new Array();
            lookup[0] = new Object();
            lookup[0].id = PlanExaminerId;
            lookup[0].name = PlanExaminerName;
            lookup[0].entityType = "systemuser";
            Xrm.Page.getAttribute("dobnyc_forplanexaminer").setValue(lookup);
            //Xrm.Page.data.entity.save();
        }
    }
}

function subGridOnload() {
    var grid = $('#SystemBuildings');  //Replace Grid name here
    if (grid == null) {
        // delay one second and try again. 
        setTimeout(subGridOnload, 1000);
        return;
    }

    if (grid[0] == undefined) {
        // delay one second and try again. 
        setTimeout(subGridOnload, 1000);
        return;
    }

    if (grid[0].control == undefined) {
        // delay one second and try again. 
        setTimeout(subGridOnload, 1000);
        return;
    }

    if (grid[0].control == null) {
        // delay one second and try again. 
        setTimeout(subGridOnload, 1000);
        return;
    }

    if (grid[0].control.get_totalRecordCount() == -1) {
        // delay one second and try again. 
        setTimeout(subGridOnload, 1000);
        return;
    }

    // logic Replace status names and colours as required

    $('#SystemBuildings td').filter(function () {
        return $(this).text() == 'Test';
    }).closest('tr').css('background-color', 'red');

    //Xrm.Page.ui.controls.get("WorkType").refresh();


}


function LoadCSS(path) {
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = path;
    link.media = 'all';
    head.appendChild(link);
}

function validateJobFiling() {
    var isOnHold_NoGood = validateTaskOnHold_NoGood();
    if (!isOnHold_NoGood) {
        Xrm.Page.ui.setFormNotification("There is a No good check on this Filing. The workflow actions have been temporarily suspended.", "WARNING");
    }

}


function validateTaskOnHold_NoGood() {
    var EnbMarkComplete = true;
    var IsAHVTask = Xrm.Page.getAttribute("dobnyc_task_isahvrequestmade").getValue();
    if (IsAHVTask == true)
        return EnbMarkComplete = true;
    var gotojobFiling = Xrm.Page.getAttribute("dobnyc_task_clickheretogotojobfiling");
    var jobfilingId = gotojobFiling.getValue()[0].id;
    if (jobfilingId != null) {
        XrmServiceToolkit.Rest.Retrieve(
			jobfilingId,
			"dobnyc_jobfilingSet",
			"dobnyc_CurrentFilingStatus",
			null,
			function (result) {
			    var dobnyc_CurrentFilingStatus = result.dobnyc_CurrentFilingStatus.Value;
			    //alert(dobnyc_CurrentFilingStatus);
			    if (dobnyc_CurrentFilingStatus == 21) {
			        EnbMarkComplete = false;
			        //alert(EnbMarkComplete);
			    }

			},
			function (error) {
			    alert(error.message);
			},
			false
		);
    }
    //alert(EnbMarkComplete);
    return EnbMarkComplete;


}

function Meetingoutcome() {
    var meetingOutcome = Xrm.Page.getAttribute("dobnyc_meetingoutcome").getValue();
    if (meetingOutcome == 2) {
        Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setRequiredLevel("required");
    }
    else {
        Xrm.Page.getControl("dobnyc_reasonforunprepared").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_reasonforunprepared").setRequiredLevel("none");
    }

}

function ApprovedPlansUploaded() {
    var ApprovedPlansUpload = Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").getValue();

    if (ApprovedPlansUpload == 2) {
        alert("Please upload the Approved Plan.");
        Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").setValue(null);
    }

    if (ApprovedPlansUpload == 1) {
        var action = Xrm.Page.getAttribute("dobnyc_isjobapplicationapproved").getValue();

        if (action == null) {
            alert("Please select Plan Examiner Action.");
            Xrm.Page.getAttribute("dobnyc_approvedplansuploaded").setValue(null);
        }
    }

}
function profCertQASupervisor() {
    var isFenceTask = Xrm.Page.getAttribute("dobnyc_ts_isfencetask").getValue();
    if (isFenceTask) {
        //fence work type is checked so show pending actions field
        Xrm.Page.getControl("dobnyc_ts_pendingprofcertqaassignmentactions").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_ts_pendingprofcertqaassignmentactions").setRequiredLevel("required");


    }
    else {
        //show qa clerk  and make it mandatory
        Xrm.Page.getControl("dobnyc_assigntoqaclerk").setVisible(true);
        Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setRequiredLevel("required");

    }
}

function profCertQASupervisorActions() {
    var Pendingaction = Xrm.Page.getAttribute("dobnyc_ts_pendingprofcertqaassignmentactions").getValue();
    if (Pendingaction && Pendingaction != null && Pendingaction > 0) {
        if (Pendingaction == 1)//Assign QA
        {
            Xrm.Page.getControl("dobnyc_assigntoqaclerk").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setRequiredLevel("required");

        }
        if (Pendingaction == 2)// REject
        {
            Xrm.Page.getAttribute("description").setRequiredLevel("required");
            Xrm.Page.getControl("dobnyc_assigntoqaclerk").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setValue(null);
        }
    }
    else {
        Xrm.Page.getControl("dobnyc_assigntoqaclerk").setVisible(false);
        Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setRequiredLevel("none");
        Xrm.Page.getAttribute("dobnyc_assigntoqaclerk").setValue(null);
    }
}


function TaskFormQAfailedFileds() {
    var QAFailedStatus = Xrm.Page.getAttribute("dobnyc_task_status").getValue();
    var QAFailedReason = Xrm.Page.getAttribute("dobnyc_qafailedreason").getValue();

    if (QAFailedStatus != null) {
        setVisible(true, "dobnyc_task_status");

        if (QAFailedStatus == 1) {
            if (QAFailedReason != null)
                setVisible(true, "dobnyc_qafailedreason");
            else
                setVisible(false, "dobnyc_qafailedreason");
        }
    }
    else
        setVisible(false, "dobnyc_task_status");
}

function setVisible(onOff, fieldNames) {
    if (fieldNames != null && fieldNames != "") {
        var fields = fieldNames.split(";");
        for (var i = 0; i < fields.length; i++) {
            Xrm.Page.ui.controls.get(fields[i]).setVisible(onOff);
        }
    }
}

function hideSection_CostAffidavit() {
    var currentFillingStatus = Xrm.Page.getAttribute("dobnyc_currentfilingstatus").getValue();
    if (currentFillingStatus == 18) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Cost Affidavit_section_FinalCost").setVisible(true);
    }
    else {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Cost Affidavit_section_FinalCost").setVisible(false);
    }
}

function GetSpecialInspectionDocStatus(jobName, workType) {
    var fetchXml =
	"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
		"<entity name='dobnyc_documentlist' >" +
			"<attribute name='dobnyc_documentlistid' />" +
			"<attribute name='dobnyc_name' />" +
			"<attribute name='dobnyc_priortostage' />" +
			"<attribute name='dobnyc_documentstatus' />" +
			"<order attribute='dobnyc_name' descending='false' />" +
			"<filter type='and'>" +
				"<filter type='and'>" +
					"<condition attribute='dobnyc_parentdocument' operator='null' />" +
					"<condition attribute='dobnyc_manuallyselected' operator='eq' value='0' />" +
				"</filter>" +
			"</filter>" +
			"<link-entity name='dobnyc_specialinspectioncategories' from='dobnyc_specialinspectioncategoriesid' to='dobnyc_gotospecialinspection' alias='bj'>" +
				"<link-entity name='dobnyc_jobfiling' from='dobnyc_jobfilingid' to='dobnyc_jobfilingtospecialinspectionscaid' alias='bk'>" +
					"<filter type='and'>" +
						"<condition attribute='dobnyc_name' operator='eq' value='" + jobName + "'/>" +
					"</filter>" +
				"</link-entity>" +
				"<link-entity name='dobnyc_specialinspectionscomponents' from='dobnyc_specialinspectionscomponentsid' to='dobnyc_specialinspections' alias='bl'>" +
					"<filter type='and'>" +
						"<condition attribute='dobnyc_worktype' operator='like' value='%" + workType + "%' />" +
					"</filter>" +
				"</link-entity>" +
			"</link-entity>" +
		"</entity>" +
	"</fetch>";

    var specialInspectionDocList = XrmServiceToolkit.Soap.Fetch(fetchXml);
    return specialInspectionDocList;
}

function GetProgressInspectionDocStatus(jobName, workType) {
    var fetchXml =
	"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
		"<entity name='dobnyc_documentlist' >" +
			"<attribute name='dobnyc_documentlistid' />" +
			"<attribute name='dobnyc_name' />" +
			"<attribute name='dobnyc_priortostage' />" +
			"<attribute name='dobnyc_documentstatus' />" +
			"<order attribute='dobnyc_name' descending='false' />" +
			"<filter type='and'>" +
				"<filter type='and'>" +
					"<condition attribute='dobnyc_parentdocument' operator='null' />" +
					"<condition attribute='dobnyc_manuallyselected' operator='eq' value='0' />" +
				"</filter>" +
			"</filter>" +
			"<link-entity name='dobnyc_progressinspectioncategory' from='dobnyc_progressinspectioncategoryid' to='dobnyc_gotoprogressinspection' alias='am'>" +
				"<link-entity name='dobnyc_jobfiling' from='dobnyc_jobfilingid' to='dobnyc_progressioninspectioncategorytoid' alias='an'>" +
					"<filter type='and'>" +
						"<condition attribute='dobnyc_name' operator='eq' value='" + jobName + "'/>" +
					"</filter>" +
				"</link-entity>" +
				"<link-entity name='dobnyc_specialinspectionscomponents' from='dobnyc_specialinspectionscomponentsid' to='dobnyc_progressinspection' alias='ao'>" +
					"<filter type='and'>" +
						"<condition attribute='dobnyc_worktype' operator='like' value='%" + workType + "%' />" +
					"</filter>" +
				"</link-entity>" +
			"</link-entity>" +
		"</entity>" +
	"</fetch>";

    var progressInspectionDocList = XrmServiceToolkit.Soap.Fetch(fetchXml);
    return progressInspectionDocList;
}

function ValidateInspectionCategories(returnPermits, jobName) {
    if (returnPermits != null && returnPermits.length > 0) {
        for (var i = 0; i < returnPermits.length; i++) {
            var workType = null;
            var workTypeId = returnPermits[i].dobnyc_WP_TypeofPermit.Value;
            switch (workTypeId) {
                case 1:
                    workType = "PL";
                    break;
                case 2:
                    workType = "SP";
                    break;
                case 3:
                    workType = "SD";
                    break;
                case 4:
                    workType = "AN";
                    break;
                case 5:
                    workType = "CC";
                    break;
                case 7:
                    workType = "SG";
                    break;
                case 8:
                    workType = "SF";
                    break;
                case 9:
                    workType = "SH";
                    break;
                case 10:
                    workType = "FN";
                    break;
                default:
                    workType = null;
            }

            if (workType != null && jobName != null) {
                var specialInspectionDocSet = GetSpecialInspectionDocStatus(jobName, workType);
                if (specialInspectionDocSet.length > 0) {
                    for (var j = 0; i < specialInspectionDocSet.length; j++) {
                        if (specialInspectionDocSet[j].attributes.dobnyc_documentstatus.value != 3) {
                            alert('Please accept the document: ' + specialInspectionDocSet[j].attributes.dobnyc_name.value + '.');
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            return false;
                        }
                    }
                }

                var progressInspectionDocSet = GetProgressInspectionDocStatus(jobName, workType);
                if (progressInspectionDocSet.length > 0) {
                    for (var k = 0; k < progressInspectionDocSet.length; k++) {
                        if (progressInspectionDocSet[k].attributes.dobnyc_documentstatus.value != 3) {
                            alert('Please accept the document: ' + progressInspectionDocSet[k].attributes.dobnyc_name.value + '.');
                            Xrm.Page.getAttribute("dobnyc_qadecision").setValue(null);
                            return false;
                        }
                    }
                }
            }
        }
    }
}
