﻿function OnLoad() {

    var Id = getLookupId("dobnyc_workpermittojobfilingrelationshid");
    if (Id == null)
        return;
    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_JobDescription,dobnyc_PlanApprovedDate&$filter=dobnyc_jobfilingId eq guid'" + Id + "'");

    var temp = HandleODataDate(returnValue[0].dobnyc_PlanApprovedDate);

    Xrm.Page.getAttribute("dobnyc_planaprroveddate").setValue(temp);

    Xrm.Page.getAttribute("dobnyc_planaprroveddate").setSubmitMode("always");
    Xrm.Page.getAttribute("dobnyc_workpermit_status").setSubmitMode("always");
    Xrm.Page.getAttribute("dobnyc_jobdescription").setSubmitMode("always");

    //disableFormFields(true);

}

function disableFormFields(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }

    }
    );

}


function getLookupId(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}



function HandleODataDate(dateValue) {

    var returnValue = null;

    try {

        dateValue = dateValue == null ? "" : dateValue.toString();

        if (dateValue != "") {

            dateValue = dateValue.replace("/", "");

            dateValue = dateValue.replace("Date(", "");

            dateValue = dateValue.replace(")", "");

            dateValue = dateValue.replace("/", "");

            var returnValue = new Date(parseInt(dateValue));

            returnValue = isNaN(returnValue) ? null : returnValue;

        }

    }

    catch (Exception) { }

    return returnValue;

}