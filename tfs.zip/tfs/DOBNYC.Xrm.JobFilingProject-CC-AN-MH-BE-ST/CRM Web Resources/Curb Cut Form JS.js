///====================================================================
/// Name        :   Curb Cut Form
/// Description :   Contains all functions related to Curb Cut
/// Usage       :   
/// Script Name :   dobnyc_CurbCutFormJS.js
/// Author      :   Department of Buildings
///====================================================================
 
DOB = window.DOB || {};
DOB.CC = function () {
    "use strict";
     //Variable Declaration
		var IsCurbCut = null;
		var IsAntenna = null;
		
		var CurbCutPW1Fields_Sections = 
		[
		 "Plan/Work Application_section_16_CCDescription"
		 //,"Plan/Work Application_section5"
		];

		var CurbCutSealSignature_HideSections = 
		["Statements & Signatures_Section_5",
		 "Statements & Signatures_section_4",
		 "Statements & Signatures_section_50",
		 "Statements & Signatures_Section_6",
		 "Statements & Signatures_section_45"
		];
		
		var FAB4CommonPW1_Fields = 
		[
		"dobnyc_f4_sromultipledwelling",
		"dobnyc_f4_loftboard",
		"dobnyc_f4_sitesafetyjobproject",
		"dobnyc_f4_includedinlmcc"
		];
		
		var CurbCutPW1Fields_Hide = 
		[
		 "dobnyc_jobdescriptionlegalization"
		 ,"dobnyc_an_relateddobjobnumbers"
		 ,"dobnyc_requestinglegalizationofworkwherenowork"
		 ,"dobnyc_workincludespermanentremovalofstandpipe"		 
		];
    //Controls declaration
    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================
 
    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns> 
    };
 
    var setState = function (enabled) {
        ///<summary> Set State of attributes and Tabs </summary>
        ///<returns>no return</returns>
        ///<param name="enabled" type="Boolean">Set state for tabs and attributes.</param>            
    };
 
    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================
 
    var helper = function () {
        ///<summary> Set state of attributes and tabs based on Antenna Scope of Work is in ecosystem </summary>
        ///<returns>no return</returns> 
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of Antenna Scope of Work
    ///==================================================================================================================
 
    var onLoad = function () {   
        init();
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of Antenna Scope of Work
    ///==================================================================================================================
 
 
    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();  
    };
 
    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in Antenna Scope of Work
    ///==================================================================================================================
	
	var CurbCutonload = function(){debugger;
		Xrm.Page.data.process.addOnStageSelected(toggleCurbCutFields);
		IsCurbCut = Xrm.Page.getAttribute("dobnyc_cc_curbcut").getValue();
		if(!IsCurbCut){
			showHide_CurbCutPW1Fields(false);
		}
		else{
			showHide_CurbCutPW1Fields(true);
			activateCurbCutBusinessProcess();
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(false);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section5").setVisible(true);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(false);
			DOB.Utilities.SetVisibleByArray(false, CurbCutPW1Fields_Hide);
			//Xrm.Page.getControl("dobnyc_jobdescriptionlegalization").setVisible(false);
			//Xrm.Page.getControl("dobnyc_an_relateddobjobnumbers").setVisible(false);			
			DOB.Utilities.HighlightQuickViewFields("dobnyc_curbcutquestionnaire","dobnyc_cc_curbcutquestionnaire");
		}		
	};
	
	var toggleCurbCutFields = function () {
		var activeStage = Xrm.Page.data.process.getSelectedStage();
        var stageName = activeStage.getName();
		IsCurbCut = Xrm.Page.getAttribute("dobnyc_cc_curbcut").getValue();
		//Plan/Work Application Tab - PW1
		if (stageName == "Plan/Work") {
			if(!IsCurbCut){
				showHide_CurbCutPW1Fields(false);
			}
			else{
					showHide_CurbCutPW1Fields(true);
					Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(false);					
					Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section5").setVisible(true);
					Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(false);
					Xrm.Page.getControl("dobnyc_workonfloors").setVisible(true);
					DOB.Utilities.SetVisibleByArray(false, CurbCutPW1Fields_Hide);
					//Xrm.Page.getControl("dobnyc_jobdescriptionlegalization").setVisible(false);
					//Xrm.Page.getControl("dobnyc_an_relateddobjobnumbers").setVisible(false);
					DOB.Utilities.HighlightQuickViewFields("dobnyc_curbcutquestionnaire","dobnyc_cc_curbcutquestionnaire");
				}
		}
		
		//Statements & Signature Tab - PW1
		if (stageName == "Statements & Signatures") {	
			if(IsCurbCut)
			{
				debugger;
				showHide_CurbCutSealSignature(false);
				DOB.ASW.ToggleAttestationSection();
			}
		}
	};
	
	var showCurbCutPW1Fields = function (){
		Xrm.Page.getControl("dobnyc_cc_curbcutworktype").setVisible(true);
		Xrm.Page.getControl("dobnyc_workonfloors").setVisible(true);
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutPW1Fields_Sections, true);
	};
	
	var hideCurbCutPW1Fields = function (){
		Xrm.Page.getControl("dobnyc_cc_curbcutworktype").setVisible(false);
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutPW1Fields_Sections, false);
	};
	
	var showHide_CurbCutPW1Fields = function (showHide){
		//true or false as param to show or hide
		Xrm.Page.getControl("dobnyc_cc_curbcutworktype").setVisible(showHide);
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutPW1Fields_Sections, showHide);
	};
	
	var activateCurbCutBusinessProcess = function (){
		//var curbCutProcessName = "Department of Building Curb Cut Business Flow";
		var curbCutProcessName = "Antenna and Curb Cut Business Flow";
		DOB.Utilities.SetBusinessProcessFlowbyName(curbCutProcessName);
	};
	
	var checkCurbCutWorkType = function(){
		var jobfilingId = Xrm.Page.data.entity.getId();		
		if(jobfilingId == null)
			return;

		var returnPermits = null;		
		returnPermits = retrieveMultipleCustom("dobnyc_worktypeSet", "?select=dobnyc_name,dobnyc_worktypeid$filter=dobnyc_awt_gotojobfiling eq guid'" + jobfilingId + "'");
		
		var fetchXml = "<?xml version='1.0'?>" +
							"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
							"<entity name='dobnyc_worktype'>" +
							"<attribute name='dobnyc_worktypeid' />" +
							"<attribute name='dobnyc_name' />" +                            
							"<order attribute='dobnyc_name' descending='false' /> " +
							"<filter type='and'>" +
							"<condition attribute='dobnyc_awt_gotojobfiling' operator='eq' uitype='dobnyc_jobfiling' value='" + jobfilingId + "' />" +
							"</filter>" +
							"</entity>" +
							"</fetch>";
		
		var workTypeRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
		if(workTypeRecords.length == 1){
			if(workTypeRecords[0].attributes.dobnyc_name.value == 'CC')
				return true;
			else
				return false;
		}
		else
			return false;
	};
	
	var showHide_CurbCutSealSignature = function (showHide) {
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutSealSignature_HideSections, showHide);
	};
	
	var showCurbCutSealSignature = function () {
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutSealSignature_HideSections, true);
	};
	
	var hideCurbCutSealSignature = function () {
		DOB.Utilities.DisplayHideSections("Master_Tab", CurbCutSealSignature_HideSections, false);
	};
	
	
    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  
 
    return {
        OnLoad: onLoad,
        OnSave: onSave,
		CurbCutOnload: CurbCutonload,
		ToggleCurbCutFields: toggleCurbCutFields,
		ActivateCurbCutBusinessProcess: activateCurbCutBusinessProcess,
		CheckCurbCutWorkType: checkCurbCutWorkType,
		ShowCurbCutPW1Fields: showCurbCutPW1Fields,
		HideCurbCutPW1Fields: hideCurbCutPW1Fields,
		ShowCurbCutSealSignature: showCurbCutSealSignature,
		HideCurbCutSealSignature: hideCurbCutSealSignature
    };
}();
