﻿function LicenseDescription() {
    debugger;
    var Id = getLookupId("dobnyc_licensetype");
    if (Id == null)
        return;

    var returnValue = null;

    returnValue = retrieveMultipleCustom("dobnyc_licensetypeSet", "?$select=dobnyc_LicenseDescription&$filter=dobnyc_licensetypeId eq guid'" + Id + "'");

    if(returnValue != null)
    {

    }

    //var returnValue2 = null;

    //returnValue2 = retrieveRecord(Id, "dobnyc_licensetypeSet",true,false,"dobnyc_name","string");

    //alert(returnValue);
    
}

function getLookupId(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}