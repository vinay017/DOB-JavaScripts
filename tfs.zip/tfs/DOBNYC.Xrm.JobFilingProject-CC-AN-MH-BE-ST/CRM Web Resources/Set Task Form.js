﻿function SetTaskForm() {
    var Taskform = Xrm.Page.getAttribute("dobnyc_task_taskform").getValue();
    var form = Xrm.Page.ui.formSelector.getCurrentItem();
    if (form != null) {
        var formId = form.getId();
        var formLabel = form.getLabel();
    }
    if (Taskform == 1 && formLabel != "Chief Plan Examiner Task Form") //	Pending Plan Examiner Assignment
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();

            if (formLabel == "Chief Plan Examiner Task Form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
    if (Taskform == 2 && formLabel != "Plan Examiner Task Form") //	Plan Examiner Review in Process
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Plan Examiner Task Form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
    if (Taskform == 4 && formLabel != "QA Supervisor Task Form") //	Pending QA Assignment
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "QA Supervisor Task Form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
    if (Taskform == 3 && formLabel != "QA Clerk Task form") //	8.	QA Review in Process
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "QA Clerk Task form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
    if (Taskform == 5 && formLabel != "Prof Cert QA Supervisor Task Form") //	
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Prof Cert QA Supervisor Task Form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
    if (Taskform == 6 && formLabel != "Prof Cert QA Clerk Task form") //	
    {

        var items = Xrm.Page.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Prof Cert QA Clerk Task form") //Check condition either on ID or Label from Form
            {
                form.navigate();
                return;
            }
        }
    }
}