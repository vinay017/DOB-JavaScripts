﻿function LegalHideShow() {

    var inspectionType = Xrm.Page.getAttribute("dobnyc_inspectiontype").getValue();

    if (inspectionType == 1) {
        var tab = Xrm.Page.ui.tabs.get("Legal Statements");
        tab.setVisible(true);
        var section1 = tab.sections.get("EC responsibility");
        section1.setVisible(false);

        var section2 = tab.sections.get("EC Completion");
        section2.setVisible(false);

        var section3 = tab.sections.get("PI Responsibility");
        section3.setVisible(true);

        var section4 = tab.sections.get("PI Completion");
        section4.setVisible(true);

    }
    else if (inspectionType == 2) {
        var tab = Xrm.Page.ui.tabs.get("Legal Statements");
        tab.setVisible(true);
        var section1 = tab.sections.get("PI Responsibility");
        section1.setVisible(false);

        var section2 = tab.sections.get("PI Completion");
        section2.setVisible(false);

        var section3 = tab.sections.get("EC responsibility");
        section3.setVisible(true);

        var section4 = tab.sections.get("EC Completion");
        section4.setVisible(true);
    }
    else if (inspectionType == null) {
        var tab = Xrm.Page.ui.tabs.get("Legal Statements");
        tab.setVisible(false);
    }

}