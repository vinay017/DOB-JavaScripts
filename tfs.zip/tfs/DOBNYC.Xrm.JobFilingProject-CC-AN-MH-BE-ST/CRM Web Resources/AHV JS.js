﻿function AHV() {
    var Id = Xrm.Page.data.entity.getId();
    var AHVID = Id.substring(1, Id.length - 1);
    var status = Xrm.Page.getAttribute("dobnyc_ahvpermitstatus").getValue();

    var borough = Xrm.Page.getAttribute("dobnyc_borough").getValue();

    if (status == 5 && borough == 1) {
        Xrm.Utility.openWebResource("dobnyc_ApprovedAHVPermit", AHVID);
    }
    else if (status == 5 && borough == 3) {
        Xrm.Utility.openWebResource("dobnyc_ApprovedAHVPermitBrooklyn", AHVID);
    }
    else if (status == 5 && borough == 2) {
        Xrm.Utility.openWebResource("dobnyc_ApprovedAHVPermitBronx", AHVID);
    }
    else if (status == 5 && borough == 4) {
        Xrm.Utility.openWebResource("dobnyc_ApprovedAHVPermitQueens", AHVID);
    }
    else if (status == 5 && borough == 5) {
        Xrm.Utility.openWebResource("dobnyc_ApprovedAHVPermitStateIsland", AHVID);
    }
    else {
        alert("Permit is Not Yet Issued");
    }

}