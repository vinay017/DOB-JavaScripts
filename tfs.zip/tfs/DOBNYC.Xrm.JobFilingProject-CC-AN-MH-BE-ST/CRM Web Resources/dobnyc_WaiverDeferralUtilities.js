///====================================================================
/// Name        :   Waiver and Deferral Scripts
/// Description :   Contains all functions related to Waiver and Deferral
/// Script Name :   dobnyc_WaiverandDeferralUtilitiesJS.js
/// Author      :   Department of Buildings
///====================================================================
DOB = window.DOB || {};
DOB.WD = function () {
    "use strict";
    var anyWaiverRequested = false;
    var anyDeferalRequested = false;
    var isWaiverApproved = false;
    var isDeferalApproved = false;

    //Controls declaration
    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================
    var init = function ()
    { };
    var setState = function (enabled)
    { };
    var helper = function ()
    { };
    var onLoad = function () {
        init();
    };
    var onSave = function () {
        init();
    };
    ///==================================================================================================================
    /// Event :   User Methods
    ///==================================================================================================================
    //var checkWaiverDeferralStatus = function(jobfilingId, taskId, profQADocId){
    var checkWaiverDeferralStatus = function (returnValue) {
        var waiverFalseCount = 0;
        var DeferralFalseCount = 0;
        var waiverRequestArray = new Array(6, 7, 8, 9, 10, 11, 12, 13, 20, 21, 23, 25);
        var deferralRequestArray = new Array(14, 15, 16, 17, 18, 19, 22, 24);
        var errorMessage = null;
        try {
            if (returnValue != null && returnValue.length > 0) {
                for (var i = 0; i < returnValue.length; i++) {
                    var dobnyc_DocumentStatus = returnValue[i].dobnyc_DocumentStatus.Value;
                    var dobnyc_Documentlist_PriortoStatus = returnValue[i].dobnyc_Documentlist_PriortoStatus.Value;
                    var dobnyc_AnyWaiverRequest = returnValue[i].dobnyc_AnyWaiverRequest;
                    var dobnyc_AnyDeferralRequest = returnValue[i].dobnyc_AnyDeferralRequest;
                    var dobnyc_WaiverRequested = returnValue[i].dobnyc_WaiverRequested;
                    var dobnyc_DeferralRequested = returnValue[i].dobnyc_DeferralRequested;
                    var documentName = returnValue[i].dobnyc_DocumentNameDocumentList.Name;

                    if (dobnyc_DocumentStatus == 1 || dobnyc_DocumentStatus == 2 || dobnyc_DocumentStatus == 5 || dobnyc_DocumentStatus == 3 || dobnyc_DocumentStatus == 4)
                        continue; //Not waiver/deferral anymore

                    if ((dobnyc_AnyWaiverRequest && waiverRequestArray.indexOf(dobnyc_DocumentStatus) > -1) && (dobnyc_Documentlist_PriortoStatus == 6 || dobnyc_Documentlist_PriortoStatus == 10 || dobnyc_Documentlist_PriortoStatus == 18)) {
                        if (anyWaiverRequested == false) anyWaiverRequested = true;

                        if (dobnyc_DocumentStatus == 6)
                            isWaiverApproved = true;
                        else {
                            waiverFalseCount++;
                            isWaiverApproved = false;
                            errorMessage = formErrorMessage(dobnyc_DocumentStatus, documentName);
                            break;
                        }

                    }
                    else if ((dobnyc_AnyDeferralRequest && deferralRequestArray.indexOf(dobnyc_DocumentStatus) > -1) && (dobnyc_Documentlist_PriortoStatus == 6 || dobnyc_Documentlist_PriortoStatus == 10)) {
                        if (anyDeferalRequested == false) anyDeferalRequested = true;

                        if (dobnyc_DocumentStatus == 14)
                            isDeferalApproved = true;
                        else {
                            DeferralFalseCount++;
                            isDeferalApproved = false;
                            errorMessage = formErrorMessage(dobnyc_DocumentStatus, documentName);
                            break;
                        }
                    }
                }
            }

            if (waiverFalseCount > 0) isWaiverApproved = false;
            if (DeferralFalseCount > 0) isDeferalApproved = false;

            var returnObject = [anyWaiverRequested, isWaiverApproved, anyDeferalRequested, isDeferalApproved, errorMessage];
            return returnObject;
        }
        catch (ex) { alert(ex); }
    };
    var showHideControl = function (ctrlName, visibility) {
        try {
            var control = Xrm.Page.getControl(ctrlName);
            if (control) {
                control.setVisible(visibility);
            }
        }
        catch (e)
        { }
    };
    var setRequirementLevel = function (fieldName, level) {
        try {
            var field = Xrm.Page.getAttribute(fieldName);
            if (field) {
                field.setRequiredLevel(level);
            }
        }
        catch (e)
        { }
    };

    var checkActionPerformedOnRequests = function (taskId) {
        var allowSubmit = false;
        try {
            var returnValue = retrieveMultipleCustom("dobnyc_waiverdeferraltaskintersectSet", "?$select=dobnyc_waiverdeferraltaskintersectId&$filter=dobnyc_Action eq null and dobnyc_TaskId/Id eq (guid'" + taskId + "')")
            if (returnValue != null && returnValue.length > 0) {
                allowSubmit = false;
            }
            else {
                allowSubmit = true;
            }
        }
        catch (e)
        { }
        return allowSubmit;
    };

    var checkUserRole = function (roleName) {
        var currentUserRoles = Xrm.Page.context.getUserRoles();
        for (var i = 0; i < currentUserRoles.length; i++) {
            var userRoleId = currentUserRoles[i];
            var userRoleName = getRoleName(userRoleId);
            if (userRoleName == roleName) {
                return true;
            }
        }
        return false;
    };

    var getRoleName = function (userRoleId) {
        try {
            var selectQuery = "RoleSet(guid'" + userRoleId + "')?$select=Name";
            var odataSelect = Xrm.Page.context.getClientUrl() + "/XRMServices/2011/OrganizationData.svc/" + selectQuery;
            //alert(odataSelect);
            var roleName = null;
            $.ajax({
                type: "GET",
                async: false,
                contentType: "application/json; charset=utf-8",
                datatype: "json",
                url: odataSelect,
                beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
                success: function (data, textStatus, XmlHttpRequest) {
                    var result = data.d;
                    if (!!result) {
                        roleName = result.Name;
                    }
                },
                error: function (XmlHttpRequest, textStatus, errorThrown) {
                    //alert('OData Select Failed: ' + odataSelect);
                }
            });
            return roleName;
        } catch (e) {

        }
    };

    var formErrorMessage = function (dobnyc_DocumentStatus, documentName) {
        var returnMessage = null;
        switch (dobnyc_DocumentStatus) {
            case 7:                
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 20:
            case 21:
            case 23:
            case 25:
            case 15:
            case 16:
            case 17:
            case 18:
            case 19:
            case 22:
            case 24:
                //Bug 7747
                returnMessage = "This task cannot be approved because one or more Waiver/ Deferral requests for required documents are in �Rejected� status or �In Review� status";
                break;
            default:
                returnMessage = "All waiver/deferral requests must be approved before you approve the form.";
                break;
        }
        return returnMessage;
    };

    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  
    return {
        Init: init,
        SetState: setState,
        Helper: helper,
        OnLoad: onLoad,
        OnSave: onSave,
        CheckWaiverDeferralStatus: checkWaiverDeferralStatus,
        ShowHideControl: showHideControl,
        SetRequirementLevel: setRequirementLevel,
        CheckActionPerformedOnRequests: checkActionPerformedOnRequests,
        GetRoleName: getRoleName,
        CheckUserRole: checkUserRole
    };
}();