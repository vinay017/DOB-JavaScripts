///====================================================================
/// Name        :   Common Utilities
/// Description :   This file contains all common functions/methods called through out the CRM site. 
/// Usage       :   
/// Script Name :   dobnyc_CommonUtilities.js
/// Author      :   Department of Buildings
///====================================================================
 
DOB = window.DOB || {};
DOB.Utilities = function () {
    "use strict";
     //Variable Declaration

    //Controls declaration
    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================
 
    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns> 
    };
 
    var setState = function (enabled) {
        ///<summary> Set State of attributes and Tabs </summary>
        ///<returns>no return</returns>
        ///<param name="enabled" type="Boolean">Set state for tabs and attributes.</param>            
    };
 
    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================
 
    var helper = function () {
        ///<summary> Set state of attributes and tabs based on Antenna Scope of Work is in ecosystem </summary>
        ///<returns>no return</returns> 
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of Antenna Scope of Work
    ///==================================================================================================================
 
    var onLoad = function () {   
        init();
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of Antenna Scope of Work
    ///==================================================================================================================
 
 
    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();  
    };
 
    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in Antenna Scope of Work
    ///==================================================================================================================
	
	var getLookupId = function (attributeName) {
		
		var lookupObject = Xrm.Page.getAttribute(attributeName);

		if (lookupObject != null) {
			var lookUpObjectValue = lookupObject.getValue();
			if ((lookUpObjectValue != null)) {
				var lookuptextvalue = lookUpObjectValue[0].name;
				var lookupid = lookUpObjectValue[0].id;
				return lookupid;
			}
		}
	};
	
	var setBusinessProcessFlowbyName = function (BusinessProcessName){
		var activeProcessId = Xrm.Page.data.process.getActiveProcess().getId();
		Xrm.Page.data.process.getEnabledProcesses(function (processes) {
			for (var processId in processes)
			{
				var processId = processId;				
				var processName = processes[processId];
				
				if (processName.toUpperCase() == BusinessProcessName.toUpperCase()) 
				{
					if(activeProcessId.toUpperCase() == processId.toUpperCase())
						return; //Same process is currently active
					else{					
						Xrm.Page.data.process.setActiveProcess(processId, function (status)
						{
							if (status == "success")
								return;
						});
					}
				}
			}
		});
	};
	
    //hide or display sections
	 var  DisplayHideSections=function(parentTabName, sectionNames, isVisible) {
        try {
            if (parentTabName != null && Xrm.Page.ui.tabs.get(parentTabName) && sectionNames != null && sectionNames.length > 0) {
                for (var i = 0; i < sectionNames.length; i++) {
                    Xrm.Page.ui.tabs.get(parentTabName).sections.get(sectionNames[i]).setVisible(isVisible);
                }
            }
        }
        catch (excp) {
            alert(excp)
        }
    };
	
	   var setVisibleByArray = function (onOff, fieldNames) {
		///<summary> Pass all the attributes from Master library file which ever should be set visible from form designer.</summary>
		///<summary> This function parameters are passed from form designer params.</summary>
        ///<returns>no return</returns>
		///<params>true/false, [fields array]</param>
        if (fieldNames != null && fieldNames != "") {
            //var fields = fieldNames.split(";");
            for (var i = 0; i < fieldNames.length; i++) {
                Xrm.Page.ui.controls.get(fieldNames[i]).setVisible(onOff);
            }
        }
    };
	

	var checkWorkType = function(workType, jobfilingId){
		var returnValue = false;
		if(jobfilingId == null)
			return returnValue;

		var returnPermits = null;		
		returnPermits = retrieveMultipleCustom("dobnyc_worktypeSet", "?select=dobnyc_name,dobnyc_worktypeid$filter=dobnyc_awt_gotojobfiling eq guid'" + jobfilingId + "'");
		
		var fetchXml = "<?xml version='1.0'?>" +
							"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
							"<entity name='dobnyc_worktype'>" +
							"<attribute name='dobnyc_worktypeid' />" +
							"<attribute name='dobnyc_name' />" +                            
							"<order attribute='dobnyc_name' descending='false' /> " +
							"<filter type='and'>" +
							"<condition attribute='dobnyc_awt_gotojobfiling' operator='eq' uitype='dobnyc_jobfiling' value='" + jobfilingId + "' />" +
							"</filter>" +
							"</entity>" +
							"</fetch>";
		
		var workTypeRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
		if(workTypeRecords.length > 0) {
			for (var i = 0; i < workTypeRecords.length; i++) {
				if(workTypeRecords[i].attributes.dobnyc_name.value.toUpperCase() == workType.toUpperCase())
					returnValue = true;	
			}
		}
		
		return returnValue;
	};
	
	var highlightchengeSetFields = function () {
		var formType = Xrm.Page.ui.getFormType();
		if (formType != 1) {
			//var filingId = Xrm.Page.data.entity.getId();
			var entityName = Xrm.Page.data.entity.getEntityName();
			var gotojobFiling = null;
			if(entityName == "dobnyc_antennascopeofwork")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_asw_gotojobfiling");
			else if(entityName == "dobnyc_demolitionsubmittalcertificationds1")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_an_gotojobfiling");
			else if(entityName == "dobnyc_curbcutquestionnaire")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_cc_gotojobfiling");
			else if(entityName == "dobnyc_fencescopeofwork")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_f4_fsw_gotojobfiling");
			else if(entityName == "dobnyc_sidewalkshedscopeofwork")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_f4_swsw_gotojobfiling");
			else if(entityName == "dobnyc_scaffoldscopeofwork")
				gotojobFiling = Xrm.Page.getAttribute("dobnyc_f4_sfsw_gotojobfiling");
			if(gotojobFiling != null)
			{	if(gotojobFiling.getValue() != null){
					var filingId = gotojobFiling.getValue()[0].id;
					var changesetRecords = retrieveMultipleCustom("dobnyc_jobfilingchangesetSet", "?select=dobnyc_name&$filter=dobnyc_JobFiling/Id eq guid'" + filingId + "' and dobnyc_EntityName eq '" + entityName + "'");

					if (changesetRecords.length > 0) {

						for (var i = 0; i < changesetRecords.length; i++) {
							if (changesetRecords[i].dobnyc_name != undefined) {
								var attributename = changesetRecords[i].dobnyc_name;
								if(document.getElementById(attributename) != null){
									document.getElementById(attributename).style.color = "red";
									document.getElementById(attributename).style.backgroundColor = "red";
								}
							}
						}
					}
				}
			}
		}
	};
	
	var highlightQuickViewFields = function (entityName, lookupName) {
        var filingId = Xrm.Page.data.entity.getId();
		var fetchXml = 
			"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >" +
				"<entity name='dobnyc_jobfilingchangeset' >" +
					"<attribute name='dobnyc_entityname' />" +
						"<filter type='and'>" +
                            "<condition attribute='dobnyc_jobfiling' operator='eq' uitype='dobnyc_jobfiling' value='" + filingId + "' />" +
							"<condition attribute='dobnyc_entityname' operator='eq' value='" + entityName + "' />" +
                        "</filter>" +
				"</entity>" +
			"</fetch>";
			
		var changesetRecords = XrmServiceToolkit.Soap.Fetch(fetchXml);
		//var changesetRecords = retrieveMultipleCustom("dobnyc_jobfilingchangesetSet", "?select=dobnyc_EntityName&$filter=dobnyc_JobFiling/Id eq guid'" + filingId  + "'");

		if (changesetRecords.length > 0) {
			for (var i = 0; i < changesetRecords.length; i++) {
				if (changesetRecords[i].attributes.dobnyc_entityname.value == entityName) {
					var attributename = lookupName;
					if(document.getElementById(attributename) != null){
						document.getElementById(attributename).style.color = "red";
						document.getElementById(attributename).style.backgroundColor = "red";
					}
				}
			}
		}
	};
 
    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  
 
    return {
        OnLoad: onLoad,
        OnSave: onSave,
		GetLookupId: getLookupId,
		CheckWorkType: checkWorkType,
		SetBusinessProcessFlowbyName: setBusinessProcessFlowbyName,
		DisplayHideSections:DisplayHideSections,
		SetVisibleByArray:setVisibleByArray
		,HighlightchengeSetFields: highlightchengeSetFields
		,HighlightQuickViewFields: highlightQuickViewFields
    };
}();