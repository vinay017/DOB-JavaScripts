﻿// JavaScript source code
function feeCalcOnSave() {
    var feeTypeVal = Xrm.Page.getAttribute("dobnyc_feetype").getText();
    if (feeTypeVal != 'Facade Filing Fee') {
        if (feeTypeVal == 'Filing Fees') {
            var nameVal = Xrm.Page.getAttribute("dobnyc_name").getValue(calcName);

            var buildType = Xrm.Page.getAttribute("dobnyc_buildingtype").getText();
            var buildSplit = buildType.split(" ");
            var buildTypeSub = buildSplit[0];
            var permitType = Xrm.Page.getAttribute("dobnyc_permittype").getText();
            //var permitSplit = permitType.split(" ");
            //var permitValue = permitSplit[0].substring(0, 1) + permitSplit[1];
            //var jobVal = Xrm.Page.getAttribute("dobnyc_jobtype").getText();
            //var filingStatus = Xrm.Page.getAttribute("dobnyc_filingstatus").getText();
            // var permitTypeSub = buildType.substring(0,5);
            var calcName = buildTypeSub + " " + permitType + " " + feeTypeVal;
        }
        if (buildTypeSub == null || permitType == null) {
            var calcName = feeTypeVal;
        }


        Xrm.Page.getAttribute("dobnyc_name").setValue(calcName);
    }
    else {
        // abanerjee: Naming for Façade filing types
        var facadeFilingType = "";
        if (Xrm.Page.getAttribute("dobnyc_facadefilingtype").getText() == '') {
            facadeFilingType = "Extention";
        }
        else {
            facadeFilingType = Xrm.Page.getAttribute("dobnyc_facadefilingtype").getText();
        }
        var calcName = feeTypeVal + '-' + facadeFilingType;
        Xrm.Page.getAttribute("dobnyc_name").setValue(calcName);
    }
}