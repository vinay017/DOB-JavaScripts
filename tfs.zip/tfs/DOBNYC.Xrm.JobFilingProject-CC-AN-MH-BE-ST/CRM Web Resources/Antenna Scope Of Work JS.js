///====================================================================
/// Name        :   Antenna Scope of Work 
/// Description :   This will be called on Onload of Antenna Scope of Work Form
/// Usage       :   
/// Script Name :   dobnyc_AntennaScopeOfWorkJS.js
/// Author      :   Department of Buildings
///====================================================================
 
DOB = window.DOB || {};
DOB.ASW = function () {
    "use strict";
     //Variable Declaration
		var IsAntenna = null;
		var IsCurbCut = null;
		var IsNBJobInBIS = null;
		var returnValue = null;
		var IsDirective14 = null;
		var IsPW1SameAsDS1 = null;
		var IsDS1Signed = null;
		
		var AntennaPW1Fields_Sections = 
		["Plan/Work Application_Section_Zoning_Exemptions_PW1",
		 "antennaworkonfloors",
		 "Plan/Work Application_Section_9E",
		 "Plan/Work Application_Section_9F",
		 "Plan/Work Application_section_9I",
		 "Plan/Work Application_section_9L",
		 "Plan/Work Application_section5"
		 ];
		 
		var AntennaSOWFields_Sections = 
		["Scope Of Work_ANSW_JF_All_Sections",
		"Scope Of Work_ANSW_JF_Section1A_Q",
		"Scope Of Work_ANSW_JF_Section1A_A",
		"Scope Of Work_ANSW_JF_Section2_Q",
		"Scope Of Work_ANSW_JF_Section2_A",
		"Scope Of Work_ANSW_JF_Section3_A"
		];
		
		var AntennaSOWFields_New_Antenna = 
		["Scope Of Work_ANSW_JF_Section2_Q",
		"Scope Of Work_ANSW_JF_Section2_A"
		];
		
		var AntennaSOWFields_Existing_Antenna = 
		["Scope Of Work_ANSW_JF_Section1A_Q",
		"Scope Of Work_ANSW_JF_Section1A_A"
		];
			
		var AntennaPW1Fields_Hide = 
		["dobnyc_workonfloors"
		 ,"dobnyc_jobdescriptionlegalization"
		 ,"dobnyc_an_relateddobjobnumbers"
		 ,"dobnyc_requestinglegalizationofworkwherenowork"
		 ,"dobnyc_workincludespermanentremovalofstandpipe"		 
		];

		//Controls declaration
    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================
 
    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns> 
    };
 
    var setState = function (enabled) {
        ///<summary> Set State of attributes and Tabs </summary>
        ///<returns>no return</returns>
        ///<param name="enabled" type="Boolean">Set state for tabs and attributes.</param>            
    };
 
    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================
 
    var helper = function () {
        ///<summary> Set state of attributes and tabs based on Antenna Scope of Work is in ecosystem </summary>
        ///<returns>no return</returns> 
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of Antenna Scope of Work
    ///==================================================================================================================
 
    var onLoad = function () {   
        init();
    };
 
    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of Antenna Scope of Work
    ///==================================================================================================================
 
 
    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();  
    };
 
    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in Antenna Scope of Work
    ///==================================================================================================================
	
	var toggleAntennaFields = function () {
		var activeStage = Xrm.Page.data.process.getSelectedStage();
        var stageName = activeStage.getName();
		IsAntenna = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
		IsCurbCut = Xrm.Page.getAttribute("dobnyc_cc_curbcut").getValue();
		var antennaWorkType = Xrm.Page.getAttribute("dobnyc_an_antennaworktype").getValue();
		//Scope of Work Tab
		if (stageName == "Scope Of Work") {			
			if(IsAntenna){
				toggleSOWAnswers();
				DOB.Utilities.DisplayHideSections("Master_Tab", ["Scope Of Work_section_1"], false);
				if(antennaWorkType == 1){
					showHide_AntennaSOWFields(true);
					DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_New_Antenna, true);
					DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_Existing_Antenna, false);
				}else if(antennaWorkType == 2){
					showHide_AntennaSOWFields(true);
					DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_New_Antenna, false);
					DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_Existing_Antenna, true);
				}else{
					showHide_AntennaSOWFields(true);
				}
				DOB.Utilities.HighlightQuickViewFields("dobnyc_antennascopeofwork","dobnyc_asw_antennascopeofwork");				
			}
			else{
				showHide_AntennaSOWFields(false);
				}
	    }
		
		//Plan/Work Application Tab - PW1
		if (stageName == "Plan/Work") {			
			toggleAntennaPW1Fields();
        }
		
		//Statements & Signatures Tab
		if (stageName == "Statements & Signatures") {			
			toggleAttestationSection();
        }
		
		//DS1 Tab
		if (stageName == "DS1") {			
			toggleDS1Section();
			DOB.Utilities.HighlightQuickViewFields("dobnyc_demolitionsubmittalcertificationds1","dobnyc_an_ds1");
        }
	};
	
	var antennaOnLoad = function () {debugger;
		Xrm.Page.data.process.addOnStageSelected(toggleAntennaFields);
		IsAntenna = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
		if(!IsAntenna){
			showHide_AntennaPW1Fields(false);
		}
		else{
			showHide_AntennaPW1Fields(true);
			activateAntennaBusinessProcess();
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(false);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_Section_9F").setVisible(true);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section5").setVisible(true);			
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(false);
			DOB.Utilities.SetVisibleByArray(false, AntennaPW1Fields_Hide);
			//Xrm.Page.getControl("dobnyc_workonfloors").setVisible(false);
			//Xrm.Page.getControl("dobnyc_jobdescriptionlegalization").setVisible(false);
			//Xrm.Page.getControl("dobnyc_an_relateddobjobnumbers").setVisible(false);
			//Xrm.Page.getControl("dobnyc_requestinglegalizationofworkwherenowork").setVisible(false);
			//Xrm.Page.getControl("dobnyc_workincludespermanentremovalofstandpipe").setVisible(false);			
		}
		togglePW1NBJobinBISAssociation();
	};
	
	var AlignAntennaSOWFields = function () {
		 var Question1 = document.getElementsByName("ANSW_Section1A_Q_Tab_1");
		 var Question2 = document.getElementsByName("ANSW_Section2_Q_Tab_1");
		 var Question4 = document.getElementsByName("ANSW_Section4_Q_Tab_1");
		 var Question5 = document.getElementsByName("ANSW_Section5_Q_Tab_1");
		 var Question6 = document.getElementsByName("ANSW_Section6_Q_Tab_1");
		 var Question7 = document.getElementsByName("ANSW_Section7_Q_Tab_1");
		 
		 var AntennaSection = document.getElementsByName("Scope Of Work_ANSW_JF_All_Sections");
		 // if(AntennaSection != null)
		    // AntennaSection[0].style.marginTop = '-34px';

		
		if(Question1 != null) {
			Question1[0].style.marginTop = '-15px';
			Question1[0].style.marginBottom = '-25px';
		}
		
		if(Question2 != null) {
			Question2[0].style.marginTop = '-15px';
			Question2[0].style.marginBottom = '-25px';
		}
		
		if(Question4 != null) {
			Question4[0].style.marginTop = '-15px';
			Question4[0].style.marginBottom = '-15px';
		}
		
		if(Question5 != null) {
			Question5[0].style.marginTop = '-15px';
			Question5[0].style.marginBottom = '-15px';
		}

		if(Question6 != null) {
			Question6[0].style.marginTop = '-15px';
			Question6[0].style.marginBottom = '-15px';
		}
		
		if(Question7 != null) {
			Question7[0].style.marginTop = '-15px';
			Question7[0].style.marginBottom = '-15px';
		}
	};
	
	var showAntennaPW1Fields = function () {
		Xrm.Page.getControl("dobnyc_an_antennaworktype").setVisible(true);
		Xrm.Page.getControl("dobnyc_workonfloors").setVisible(false);
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaPW1Fields_Sections, true);	
	};
	
	var hideAntennaPW1Fields = function () {
		Xrm.Page.getControl("dobnyc_an_antennaworktype").setVisible(false);
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaPW1Fields_Sections, false);
		
	};
	
	var showHide_AntennaPW1Fields = function (showHide) {
		//true or false as param to show or hide
		Xrm.Page.getControl("dobnyc_an_antennaworktype").setVisible(showHide);
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaPW1Fields_Sections, showHide);	
	};
	
	var showHide_AntennaSOWFields = function (showHide) {
		//true or false as param to show or hide
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_Sections, showHide);
	};
	
	var showAntennaSOWFields = function () {
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_Sections, true);
	};
	
	var hideAntennaSOWFields = function () {
		DOB.Utilities.DisplayHideSections("Master_Tab", AntennaSOWFields_Sections, false);		
	};
	
	var toggleAntennaPW1Fields = function () {
		IsAntenna = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
		if(!IsAntenna ){
			showHide_AntennaPW1Fields(false);
		}
		else{
			showHide_AntennaPW1Fields(true);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_52").setVisible(false);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_Section_9F").setVisible(true);
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section5").setVisible(true);	
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Plan/Work Application_section_45").setVisible(false);
			DOB.Utilities.SetVisibleByArray(false, AntennaPW1Fields_Hide);
			//Xrm.Page.getControl("dobnyc_jobdescriptionlegalization").setVisible(false);
			//Xrm.Page.getControl("dobnyc_an_relateddobjobnumbers").setVisible(false);			
			//Xrm.Page.getControl("dobnyc_requestinglegalizationofworkwherenowork").setVisible(false);
			//Xrm.Page.getControl("dobnyc_workincludespermanentremovalofstandpipe").setVisible(false);
		}
		
		togglePW1NBJobinBISAssociation();
	};
	
	var toggleSOWAnswers = function () {
		var AntennaSOWId = getLookupId("dobnyc_asw_antennascopeofwork");
		if (AntennaSOWId == null)
			return;
		var ASOWQ1Value = null;
		var ASOWQ2Value = null;
		AlignAntennaSOWFields();
		returnValue = retrieveMultipleCustom("dobnyc_antennascopeofworkSet", "?select=dobnyc_ASW_ExistingAntennas,dobnyc_ASW_NewAntennasOrArrays&$filter=dobnyc_antennascopeofworkId eq guid'" + AntennaSOWId + "'");

		if (returnValue != null && returnValue[0] != null){
			ASOWQ1Value = returnValue[0].dobnyc_ASW_ExistingAntennas;
			ASOWQ2Value = returnValue[0].dobnyc_ASW_NewAntennasOrArrays;
		}
		
		if(ASOWQ1Value){
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Scope Of Work_ANSW_JF_Section1A_A").setVisible(true);			
			document.getElementsByName("ANSW_Section1A_A_Tab_1A")[0].style.marginTop = '-25px';
			document.getElementsByName("ANSW_Section1A_A_Tab_1A")[0].style.marginBottom = '-25px';
			document.getElementsByName("ANSW_Section1A_A_Tab_1A2")[0].style.marginTop = '-25px';
			document.getElementsByName("ANSW_Section1A_A_Tab_1A2")[0].style.marginBottom = '-25px';
		}
		else
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Scope Of Work_ANSW_JF_Section1A_A").setVisible(false);
		
		if(ASOWQ2Value){
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Scope Of Work_ANSW_JF_Section2_A").setVisible(true);
			document.getElementsByName("ANSW_Section2_A_Tab_1")[0].style.marginTop = '-15px';
			document.getElementsByName("ANSW_Section2_A_Tab_1")[0].style.marginBottom = '-25px';
		}
		else
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Scope Of Work_ANSW_JF_Section2_A").setVisible(false);
	};
	
	var activateAntennaBusinessProcess = function (){
		//var antennaProcessName = "Department of Building Filing Job Business Flow";
		var antennaProcessName = "Antenna and Curb Cut Business Flow";
		DOB.Utilities.SetBusinessProcessFlowbyName(antennaProcessName);
	};

	var togglePW1NBJobinBISAssociation = function (){
		IsNBJobInBIS = Xrm.Page.getAttribute("dobnyc_isconjunctionjob").getValue();
		IsAntenna = Xrm.Page.getAttribute("dobnyc_an_antenna").getValue();
		IsCurbCut = Xrm.Page.getAttribute("dobnyc_cc_curbcut").getValue();
		var isFence = Xrm.Page.getAttribute("dobnyc_f4_constructionfencecheckbox").getValue();
        var isScaffold = Xrm.Page.getAttribute("dobnyc_f4_supportedscaffoldcheckbox").getValue();
        var isSidewalkshed = Xrm.Page.getAttribute("dobnyc_f4_swssidewalkshed").getValue();
        var isSign = Xrm.Page.getAttribute("dobnyc_f4_signcheckbox").getValue();
		
		if(IsAntenna || IsCurbCut || isFence || isScaffold || isSidewalkshed || isSign){
			if(IsNBJobInBIS){
				Xrm.Page.getControl("dobnyc_an_alternatejobinbisassociation").setVisible(false);
				Xrm.Page.getControl("dobnyc_bisrelatedjobnumber").setVisible(true);
			}
			else
			{				
				Xrm.Page.getControl("dobnyc_an_alternatejobinbisassociation").setVisible(true);
				Xrm.Page.getControl("dobnyc_bisrelatedjobnumber").setVisible(false);
				togglePW1AltJobinBISAssociation();	
			}
		}	
	};
	
	var togglePW1AltJobinBISAssociation = function(){
		IsNBJobInBIS = Xrm.Page.getAttribute("dobnyc_an_alternatejobinbisassociation").getValue();
		if(IsNBJobInBIS){
			Xrm.Page.getControl("dobnyc_bisrelatedjobnumber").setVisible(true);
		}
		else{
			Xrm.Page.getControl("dobnyc_bisrelatedjobnumber").setVisible(false);
		}
	};
	
	var toggleAttestationSection = function () {
		IsDirective14 = Xrm.Page.getAttribute("dobnyc_an_directive14").getValue();
		if(IsDirective14){
			showAntennaAttestationSection();
		}
		else{
			hideAntennaAttestationSection();
		}
	};
	
	var showAntennaAttestationSection = function () {
		Xrm.Page.getControl("WebResource_ownerscertificatefordirective14").setVisible(true);
		Xrm.Page.getControl("dobnyc_an_ownerscertificationfordirective14").setVisible(true);
		Xrm.Page.getControl("WebResource_DesignApplicantStatementPW1Dir14").setVisible(true);
	};
	
	var hideAntennaAttestationSection = function () {
		Xrm.Page.getControl("WebResource_ownerscertificatefordirective14").setVisible(false);
		Xrm.Page.getControl("dobnyc_an_ownerscertificationfordirective14").setVisible(false);
		Xrm.Page.getControl("WebResource_DesignApplicantStatementPW1Dir14").setVisible(false);
	};
	
	var toggleDS1Section = function () {
		var AntennaDS1Id = getLookupId("dobnyc_an_ds1");
		if (AntennaDS1Id == null)
			return;

		returnValue = retrieveMultipleCustom("dobnyc_demolitionsubmittalcertificationds1Set", "?select=dobnyc_AN_IsPW1ApplicantSameAsDS1,dobnyc_IsSigned&$filter=dobnyc_demolitionsubmittalcertificationds1Id eq guid'" + AntennaDS1Id + "'");

		if (returnValue != null && returnValue[0] != null){
			IsPW1SameAsDS1 = returnValue[0].dobnyc_AN_IsPW1ApplicantSameAsDS1;
			IsDS1Signed = returnValue[0].dobnyc_IsSigned;
		}		
		
		if(IsPW1SameAsDS1){
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("DS1_section_53").setVisible(false);
			// document.getElementsByName("DS1_Section_54")[0].style.marginTop = '-18px';
			// document.getElementsByName("DS1_Section_54")[0].style.marginBottom = '-40px';
			// document.getElementsByName("DS1_section_51")[0].style.marginTop = '2px';
		}
		else{
			Xrm.Page.ui.tabs.get("Master_Tab").sections.get("DS1_section_53").setVisible(true);
			// document.getElementsByName("DS1_Section_54")[0].style.marginTop = '-10px';
			// document.getElementsByName("DS1_Section_54")[0].style.marginBottom = '-10px';
			// document.getElementsByName("DS1_section_53")[0].style.marginTop = '-37px';
			// document.getElementsByName("DS1_section_53")[0].style.marginBottom = '-37px';
			// document.getElementsByName("DS1_section_51")[0].style.marginTop = '-10px';
		}
		
		if(IsDS1Signed)
		{
			Xrm.Page.getAttribute("dobnyc_dpchecktr8").setValue(true);
		}
		else
		{
			Xrm.Page.getAttribute("dobnyc_dpchecktr8").setValue(false);
		}
	};
	
	var toggleObjectionsAddressed = function (){ 
		var objectionStatus = Xrm.Page.getAttribute("dobnyc_task_objectionstatus").getValue();
		
		if(objectionStatus == 4) //Objection Dismissed
			return false;
		else
			return true;
	};

	
    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  
 
    return {
        OnLoad: onLoad,
        OnSave: onSave,		
		AntennaOnLoad: antennaOnLoad,
		ToggleAntennaPW1Fields: toggleAntennaPW1Fields,
		ToggleSOWAnswers: toggleSOWAnswers,
		ActivateAntennaBusinessProcess: activateAntennaBusinessProcess,
		ShowAntennaPW1Fields: showAntennaPW1Fields,
		HideAntennaPW1Fields: hideAntennaPW1Fields,
		ShowAntennaSOWFields: showAntennaSOWFields,
		HideAntennaSOWFields: hideAntennaSOWFields,
		TogglePW1NBJobinBISAssociation: togglePW1NBJobinBISAssociation,
		TogglePW1AltJobinBISAssociation: togglePW1AltJobinBISAssociation,
		ToggleAttestationSection: toggleAttestationSection,
		ShowAntennaAttestationSection: showAntennaAttestationSection,
		HideAntennaAttestationSection: hideAntennaAttestationSection,
		ToggleDS1Section: toggleDS1Section,
		ToggleObjectionsAddressed: toggleObjectionsAddressed
    };
}();