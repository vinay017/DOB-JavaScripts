﻿function UploadDocument() {

    var ReqNo = Xrm.Page.getAttribute("dobnyc_requestnumber").getValue();
    var docCat = Xrm.Page.getAttribute("dobnyc_documentcategory").getValue();
    var docLabel = Xrm.Page.getAttribute("dobnyc_documentcategory").getText();
    var docTypeName = getLookupName("dobnyc_documentnamedocumentlist");

    var DocListidId = Xrm.Page.data.entity.getId();
    var JBGUID = null;

    var Documentfor = Xrm.Page.getAttribute("dobnyc_documentfor").getValue();
    // alert("Documentfor: " + Documentfor);
    if (Documentfor == 1) //JobFiling
    {

        JBGUID = getLookupId("dobnyc_documentlisttojobfilingid");
    }
    if (Documentfor == 2) //Workpermit
    {
        var WorkpermitId = getLookupId("dobnyc_gotoworkpermit");
        //alert("WorkpermitId: " + WorkpermitId);
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WorkPermit_Status,dobnyc_WorkPermittoJobFilingRelationshId&$filter=dobnyc_workpermitId eq guid'" + WorkpermitId + "'");
        //alert(returnValue.length);
        JBGUID = returnValue[0].dobnyc_WorkPermittoJobFilingRelationshId.Id;
        //alert("JBGUID: " + JBGUID);
    }
    if (Documentfor == 3) //Specialinspection
    {
        var SpecialinspectionId = getLookupId("dobnyc_gotospecialinspection");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_specialinspectioncategoriesSet", "?select=dobnyc_JobFilingtoSpecialInspectionsCaId&$filter=dobnyc_specialinspectioncategoriesId eq guid'" + SpecialinspectionId + "'");
        JBGUID = returnValue[0].dobnyc_JobFilingtoSpecialInspectionsCaId.Id;
    }
    if (Documentfor == 4) // Progressinspection
    {
        var ProgressinspectionId = getLookupId("dobnyc_gotoprogressinspection");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_ProgressionInspectioncategorytoId&$filter=dobnyc_progressinspectioncategoryId eq guid'" + ProgressinspectionId + "'");
        JBGUID = returnValue[0].dobnyc_ProgressionInspectioncategorytoId.Id;
    }
    if (Documentfor == 5) // EN2
    {
        var EN2Id = getLookupId("dobnyc_gotoen2");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_en2Set", "?select=dobnyc_JobfiningtoEn2Id&$filter=dobnyc_en2Id eq guid'" + EN2Id + "'");
        JBGUID = returnValue[0].dobnyc_JobfiningtoEn2Id.Id;
    }
    if (Documentfor == 6) // AHV
    {
        var AHVId = getLookupId("dobnyc_gotoahv");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_afterhourvariancepw5Set", "?select=dobnyc_JobFiling&$filter=dobnyc_afterhourvariancepw5Id eq guid'" + AHVId + "'");
        JBGUID = returnValue[0].dobnyc_JobFiling.Id;
    }
    if (Documentfor == 7) // Withdrawal Request
    {
        var WithdrawalId = getLookupId("dobnyc_gotowithdrawalrequest");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_withdrawalrequestSet", "?select=dobnyc_GotoJobFiling&$filter=dobnyc_withdrawalrequestId eq guid'" + WithdrawalId + "'");
        JBGUID = returnValue[0].dobnyc_GotoJobFiling.Id;
    }

    if (Documentfor == 8) // Superseding Request
    {
        var SupersedingId = getLookupId("dobnyc_gotosupersedingrequest");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_supersedingrequestSet", "?select=dobnyc_Superseding_GotoJobFiling&$filter=dobnyc_supersedingrequestId eq guid'" + SupersedingId + "'");
        JBGUID = returnValue[0].dobnyc_Superseding_GotoJobFiling.Id;
    }


    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_BoroughNYC,dobnyc_FilingNumber,dobnyc_ProjectNumber&$filter=dobnyc_jobfilingId eq guid'" + JBGUID + "'");
    var DOCID = DocListidId.substring(1, DocListidId.length - 1);

    var URL = "http://10.155.208.60:5556/CRMDocumentUpload.html?borough=" + (returnValue[0].dobnyc_BoroughNYC).Value + "&jobNumber=" + returnValue[0].dobnyc_ProjectNumber + "&filingNumber=" + returnValue[0].dobnyc_FilingNumber + "&reqNumber=ReqNo&docCategory=" + docLabel + "&docType=" + docCat + "&docTypeListID=" + DOCID + "&user=UserGUID&docTypeName=" + docTypeName;

    //alert(URL);
    var isChrome = !!window.chrome && !!window.chrome.webstore;
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    var Title = "Upload Document";
    var opt = 'dialogWidth:530px; dialogHeight:200px; center:yes; scroll:no; status:no';

        if (!window.showModalDialog) {
            window.showModalDialog = function (URL, Title, opt) {

                var w;
                var h;
                var resizable = "no";
                var scroll = "no";
                var status = "no";

                // get the modal specs
                var mdattrs = opt.split(";");
                for (i = 0; i < mdattrs.length; i++) {
                    var mdattr = mdattrs[i].split(":");

                    var n = mdattr[0];
                    var v = mdattr[1];
                    if (n) { n = n.trim().toLowerCase(); }
                    if (v) { v = v.trim().toLowerCase(); }

                    if (n == "dialogheight") {
                        h = v.replace("px", "");
                    } else if (n == "dialogwidth") {
                        w = v.replace("px", "");
                    } else if (n == "resizable") {
                        resizable = v;
                    } else if (n == "scroll") {
                        scroll = v;
                    } else if (n == "status") {
                        status = v;
                    }
                }

                var left = window.screenX + (window.outerWidth / 2) - (w / 2);
                var top = window.screenY + (window.outerHeight / 2) - (h / 2);
                var targetWin = window.open(URL, Title, 'toolbar=no, location=no, directories=no, status=' + status + ', menubar=no, scrollbars=' + scroll + ', resizable=' + resizable + ', copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
                targetWin.focus();
            };
            
            window.showModalDialog(URL, Title, opt);
                      
        }
    else
        {
            window.showModalDialog(URL, Title, opt);
            window.location.reload();                
        }
        

    }

function DownloadDocument() {

    //alert("check");
    var URL = Xrm.Page.getAttribute("dobnyc_documenturl").getValue();
    var lookup = new Array();
    lookup[0] = new Object();
    lookup[0].id = Xrm.Page.context.getUserId();
    lookup[0].name = Xrm.Page.context.getUserName();
    lookup[0].entityType = "systemuser";
    
    //Xrm.Page.getAttribute("").setValue( [{id: idValue, name: textValue, entityType: typeValue}]);

    if (URL == null) {
        alert("There is no document to download");
        return;
    }

    var Id = Xrm.Page.data.entity.getId();


    var JBGUID = null;

    var Documentfor = Xrm.Page.getAttribute("dobnyc_documentfor").getValue();
    // alert("Documentfor: " + Documentfor);
    if (Documentfor == 1) //JobFiling
    {

        JBGUID = getLookupId("dobnyc_documentlisttojobfilingid");
    }
    if (Documentfor == 2) //Workpermit
    {
        var WorkpermitId = getLookupId("dobnyc_gotoworkpermit");
        //alert("WorkpermitId: " + WorkpermitId);
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_workpermitSet", "?select=dobnyc_WorkPermit_Status,dobnyc_WorkPermittoJobFilingRelationshId&$filter=dobnyc_workpermitId eq guid'" + WorkpermitId + "'");
        //alert(returnValue.length);
        JBGUID = returnValue[0].dobnyc_WorkPermittoJobFilingRelationshId.Id;
        //alert("JBGUID: " + JBGUID);
    }
    if (Documentfor == 3) //Specialinspection
    {
        var SpecialinspectionId = getLookupId("dobnyc_gotospecialinspection");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_specialinspectioncategoriesSet", "?select=dobnyc_JobFilingtoSpecialInspectionsCaId&$filter=dobnyc_specialinspectioncategoriesId eq guid'" + SpecialinspectionId + "'");
        JBGUID = returnValue[0].dobnyc_JobFilingtoSpecialInspectionsCaId.Id;
    }
    if (Documentfor == 4) // Progressinspection
    {
        var ProgressinspectionId = getLookupId("dobnyc_gotoprogressinspection");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_ProgressionInspectioncategorytoId&$filter=dobnyc_progressinspectioncategoryId eq guid'" + ProgressinspectionId + "'");
        JBGUID = returnValue[0].dobnyc_ProgressionInspectioncategorytoId.Id;
    }
    if (Documentfor == 5) // EN2
    {
        var EN2Id = getLookupId("dobnyc_gotoen2");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_en2Set", "?select=dobnyc_JobfiningtoEn2Id&$filter=dobnyc_en2Id eq guid'" + EN2Id + "'");
        JBGUID = returnValue[0].dobnyc_JobfiningtoEn2Id.Id;
    }
    if (Documentfor == 6) // AHV
    {
        var AHVId = getLookupId("dobnyc_gotoahv");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_afterhourvariancepw5Set", "?select=dobnyc_JobFiling&$filter=dobnyc_afterhourvariancepw5Id eq guid'" + AHVId + "'");
        JBGUID = returnValue[0].dobnyc_JobFiling.Id;
    }
    if (Documentfor == 7) // Withdrawal Request
    {
        var WithdrawalId = getLookupId("dobnyc_gotowithdrawalrequest");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_withdrawalrequestSet", "?select=dobnyc_GotoJobFiling&$filter=dobnyc_withdrawalrequestId eq guid'" + WithdrawalId + "'");
        JBGUID = returnValue[0].dobnyc_GotoJobFiling.Id;
    }

    if (Documentfor == 8) // Superseding Request
    {
        var SupersedingId = getLookupId("dobnyc_gotosupersedingrequest");
        var returnValue = null;
        returnValue = retrieveMultipleCustom("dobnyc_supersedingrequestSet", "?select=dobnyc_Superseding_GotoJobFiling&$filter=dobnyc_supersedingrequestId eq guid'" + SupersedingId + "'");
        JBGUID = returnValue[0].dobnyc_Superseding_GotoJobFiling.Id;
    }

    var returnValue = null;

    returnValue = retrieveMultipleCustom("dobnyc_jobfilingSet", "?select=dobnyc_Bin,dobnyc_Block,dobnyc_Block,dobnyc_BoroughNYC,dobnyc_FilingNumber,dobnyc_ProjectNumber&$filter=dobnyc_jobfilingId eq guid'" + JBGUID + "'");


    if (returnValue != null && returnValue[0] != null) {
        var path = (returnValue[0].dobnyc_BoroughNYC).Value + "\\" + returnValue[0].dobnyc_ProjectNumber + "\\" + returnValue[0].dobnyc_FilingNumber + "\\";
        //alert(path);
        //alert(URL);
    }
    
    var opt = 'dialogWidth:530px; dialogHeight:200px; center:yes; scroll:no; status:no';

    $.ajax({
        type: "POST",
        url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
        processData: true,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
        cache: false,
        beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
        success: function (data) {
            if (data.DownloadIsSuccess == true) {
                //alert("Download Successful");     
                window.open(data.downloadPath);
                Xrm.Page.getAttribute("dobnyc_viewedby").setValue(lookup);
     
            }
            else {

                //alert(data.ErrorDescription);
                alert("Download is unsuccessful");
            }
        },
        error: function (xhr, status, error) {
            //alert(error);
            alert("Document cannot be viewed. Please contact System Administrator.");
        }
    });

}

function DownloadSummaryPDFDocument() {

    //alert("check");
    var Borough = Xrm.Page.getAttribute("dobnyc_boroughnyc").getValue();
    var ProjectNumber = Xrm.Page.getAttribute("dobnyc_projectnumber").getValue();
    var FilingNumber = Xrm.Page.getAttribute("dobnyc_filingnumber").getValue();
    var URL = Xrm.Page.getAttribute("dobnyc_summarypdf").getValue();

    if (URL == null) {
        alert("There is no document to download");
        return;
    }


    var path = (Borough + "\\" + ProjectNumber + "\\" + FilingNumber + "\\");


    $.ajax({
        type: "POST",
        url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumtoCRM",
        processData: true,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
        cache: false,
        beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
        success: function (data) {
            if (data.DownloadIsSuccess == true) {
                //alert("Download Successful");     
                window.open(data.downloadPath);
            }
            else {

                //alert(data.ErrorDescription);
                alert("Download is Un-successful");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            alert("An error occured while downloding document. Please try again or contact administrator.");
        }
    });

}

function getLookupId(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}


function setDocFields() {

    var Id = getLookupId("dobnyc_documentnamedocumentlist");
    if (Id == null)
        return;
    var returnValue = null;

    returnValue = retrieveMultipleCustom("dobnyc_documenttypesSet", "?select=dobnyc_RequiredItemNumber&$filter=dobnyc_documenttypesId eq guid'" + Id + "'");

    if (returnValue != null && returnValue[0] != null) {
        //alert(returnValue[0].dobnyc_Objection);
        //alert((returnValue[0].dobnyc_ObjectionType_ObjectionCatagory).Value);
        Xrm.Page.getAttribute("dobnyc_requestnumber").setValue(returnValue[0].dobnyc_RequiredItemNumber);


    }

}

function OnLoad() {

    var Documentfor = Xrm.Page.getAttribute("dobnyc_documentfor").getValue();
    if (Documentfor == 1) {
        Xrm.Page.getControl("dobnyc_documentlisttojobfilingid").setVisible(true);
    }
    if (Documentfor == 2) {
        Xrm.Page.getControl("dobnyc_gotoworkpermit").setVisible(true);
    }
    if (Documentfor == 3) {
        Xrm.Page.getControl("dobnyc_gotospecialinspection").setVisible(true);
    }
    if (Documentfor == 4) {
        Xrm.Page.getControl("dobnyc_gotoprogressinspection").setVisible(true);
    }
    if (Documentfor == 5) {
        Xrm.Page.getControl("dobnyc_gotoen2").setVisible(true);
    }
    if (Documentfor == 6) {
        Xrm.Page.getControl("dobnyc_gotoahv").setVisible(true);
    }
    if (Documentfor == 7) {
        Xrm.Page.getControl("dobnyc_gotowithdrawalrequest").setVisible(true);
    }
    if (Documentfor == 8) {
        Xrm.Page.getControl("dobnyc_gotosupersedingrequest").setVisible(true);
    }




    Xrm.Page.getAttribute("dobnyc_documenturl").setSubmitMode("always");
    Xrm.Page.getAttribute("dobnyc_documentstatus").setSubmitMode("always");


    //disableFormFields(true);

}

function disableFormFields(onOff) {
    Xrm.Page.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }

    }
    );

}

function doesControlHaveattribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}



// JavaScript source code
