﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;
using System.Xml;
using System.Xml.Linq;


namespace TestingApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //ExternalSystem_AddressViolation svc = new ExternalSystem_AddressViolation();
            //AddressValidationRequest request = new AddressValidationRequest();

            //request.StreetName = "Broadway";
            // request.Borough = "1";
            //request.HouseNumber = "280";
            //svc.GetAddressValidation(request);

            //ExternalSystem_PropertyProfile PP = new ExternalSystem_PropertyProfile();
            //PropertyProfileRequest request = new PropertyProfileRequest();
            //PropertyProfileResponse response = new PropertyProfileResponse();
            //request.Bin = "1079215";
            //response = PP.GetPropertyProfile(request);

            //ExternalSystem_GetElevatorDetails PP = new ExternalSystem_GetElevatorDetails();
            //ElevatorDetailsRequest request = new ElevatorDetailsRequest();
            //ElevatorDetailsResponse response = new ElevatorDetailsResponse();
            //request.Bin = "";
            //request.DeviceNumber = "1P1581";
            //request.RecordNumber = "";
            //response = PP.GetElevatorDetails(request);

            //ExternalSystem_GetBoilersList PP = new ExternalSystem_GetBoilersList();
            //BoilerBrowseRequest request = new BoilerBrowseRequest();
            //BoilerBrowseResponse response = new BoilerBrowseResponse();
            //request.AllBorough = "1";
            //request.AllCount = "0001";
            //request.BiswebReporting = "B";
            //request.BoroughKey = "I";
            //request.ReadSw = "D";
            //request.FinFlag = "N";
            //request.AllKey1 = "1001572";
            //response = PP.GetBoilersList(request);

            //ExternalSystemIntegration_GetBoilerDetails PP = new ExternalSystemIntegration_GetBoilerDetails();
            //BoilerDetailsRequest request = new BoilerDetailsRequest();
            //BoilerDetailsResponse response = new BoilerDetailsResponse();
            //request.AllBorough = "1";
            //request.AllIsn = "0000138961";
            //request.BiswebReporting = "B";
            //request.BoroughKey = "I";
            //request.ReadSw = "D";
            //request.FinFlag = "Y";
            //response = PP.GetBoilerDetails(request);

            //ExternalSystemIntegration_GetBoilerDetailsByDeviceId PP = new ExternalSystemIntegration_GetBoilerDetailsByDeviceId();
            //BoilerDetailsByDeviceIdRequest request = new BoilerDetailsByDeviceIdRequest();
            //BoilerDetailsByDeviceIdResponse response = new BoilerDetailsByDeviceIdResponse();
            //request.Borough = "1";
            //request.BoilerDeviceId = "0000000076";
            //request.BiswebReporting = "B";
            //request.BoroughKey = "I";
            //request.BoilerSerialNumber = "0001";
            //request.BoilerType = "N";
            //response = PP.GetBoilerDetailsByDeviceId(request);

            //ExternalSystemIntegration_GetBoilerComplianceDetails PP = new ExternalSystemIntegration_GetBoilerComplianceDetails();
            //BoilerComplianceDetailsRequest request = new BoilerComplianceDetailsRequest();
            //BoilerComplianceDetailsResponse response = new BoilerComplianceDetailsResponse();
            //request.AllKey1 = "10000000076N0003";
            //request.AllCount = "0001";
            //request.BiswebReporting = "B";
            //request.BoroughKey = "I";
            //request.ReadSw = "D";
            //request.FinFlag = "Y";

            //response = PP.GetBoilerComplianceDetails(request);

            //ExternalSystemIntegration_GetElevatorList PP = new ExternalSystemIntegration_GetElevatorList();
            //ElevatorListRequest request = new ElevatorListRequest();
            //ElevatorListResponse response = new ElevatorListResponse();
            //request.AllBin = "1079215";
            //request.AllCount = "0001";
            //request.PassRecordNumber = "00441";
            //response = PP.GetElevatorList(request);

            ExternalSystemIntegration_GetElectricalPermitDetails PP = new ExternalSystemIntegration_GetElectricalPermitDetails();
            ElectricalPermitRequest request = new ElectricalPermitRequest();
            ElectricalPermitResponse response = new ElectricalPermitResponse();
            request.AllIsn = "0001001572";
            request.AllBorough = "1";
            request.BiswebReporting = "B";
            request.BoroughKey = "I";
            request.PageNumber = "0001";
            response = PP.GetElectricalPermitDetails(request);

            //ExternalSystemIntegration_GetElevatorRecords PP = new ExternalSystemIntegration_GetElevatorRecords();
            //ElevatorRecordNumbersRequest request = new ElevatorRecordNumbersRequest();
            //ElevatorRecordNumbersResponse response = new ElevatorRecordNumbersResponse();
            //request.AllBin = "1000005";
            //request.AllCount = "0001";
            //response = PP.GetElevatorRecords(request);

            //ExternalSystem_LicenseValidation LL = new ExternalSystem_LicenseValidation();
            //LicenseValidationRequest request = new LicenseValidationRequest();
            //LicenseValidationReponse response = new LicenseValidationReponse();
            //request.LicenseNumber = "002222";
            //request.LicenseType = "F";
            //response = LL.GetLicenseDetails(request);

            //ExternalSystem_HotList HL = new ExternalSystem_HotList();
            //HotListRequest request = new HotListRequest();
            //HotListResponse response = new HotListResponse();
            //request.LicenseNumber = "000289";
            //request.LicenseType = "RA";
            //response = HL.GetHotListDetails(request);

            //ExternalSystem_PropertyViolation PV = new ExternalSystem_PropertyViolation();
            //PropertyViolationRequest request = new PropertyViolationRequest();
            //PropertyViolationResponse response = new PropertyViolationResponse();
            //request.Bin = "3040218";
            //response = PV.GetPropertyViolation(request);

            //ExternalSystem_BISJobs BS = new ExternalSystem_BISJobs();
            //BISJobRequest request = new BISJobRequest();
            //BISJobResponse response = new BISJobResponse();
            //request.BISDocNumber = "01";
            //request.BISJobNumber = "102686112";
            //response = BS.GetBISJobInformation(request);

            //ExternalSystem_BisLicenseInformation li = new ExternalSystem_BisLicenseInformation();
            //BisLicenseInformationRequest request = new BisLicenseInformationRequest();
            //BisLicenseInformationResponse response = new BisLicenseInformationResponse();
            //request.Email = "BMULLEN@BUILDINGS.NYC.GOV";
            //response = li.GetBisLicenseInformation(request);

            //Console.WriteLine(response.Fin);
            //Console.WriteLine(response.NmBorough);
            //Console.WriteLine(response.ErrorMessage);
            //Console.WriteLine(response.Date);
            //Console.WriteLine(response.Pgm);
            //Console.WriteLine(response.VinNumberHours);
            //Console.WriteLine(response.NmStreet);
            //Console.WriteLine(response.NmBorough);
            //Console.WriteLine(response.ViZip);
            //Console.WriteLine(response.VitaxBlock);
            //Console.WriteLine(response.ViTaxLot);
            //Console.WriteLine(response.ViCensTract);
            //Console.WriteLine(response.ViHithArea);
            //Console.WriteLine(response.ElapsedTime);
            //Console.WriteLine(response.ViCommBd);
            //Console.WriteLine(response.HseHi);
            //Console.WriteLine(response.GIJobType);
            //Console.WriteLine(response.GiPageN);
            //Console.WriteLine(response.GiRecCountN);
            //Console.WriteLine(response.FoilIndicator);

            //foreach (var val in response.detailList)
            //{
            //    Console.WriteLine("************************** Details List ********************************");                
            //    Console.WriteLine(val.ReBusName);
            //    Console.WriteLine(val.ReEmailAddress);
            //    Console.WriteLine(val.ReAppType);
            //    Console.WriteLine(val.ReAppNumber);
            //    Console.WriteLine(val.ReLastName);
            //    Console.WriteLine(val.ReFirstName);
            //    Console.WriteLine(val.ReStatus);
            //    Console.WriteLine(val.ReStatusDate);
            //    Console.WriteLine(val.RePassword);
            //    Console.WriteLine(val.RePrepAddress);
            //    Console.WriteLine(val.RePrepCity);
            //    Console.WriteLine(val.RePrepState);
            //    Console.WriteLine(val.RePrepZip);
            //    Console.WriteLine(val.RePrepPhone);
            //    Console.WriteLine(val.RePrepMobile);
            //}

            //Console.WriteLine(response.SustianableLink);

            //Console.ReadKey();




            //PP.GetAddressValidation(request);
            //string nodeValue = "Address";
            //CustomConfigurations.GetXMLConfigurationKey(nodeValue);
        }
    }
}
