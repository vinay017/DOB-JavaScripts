function getRegardingValue() {
    debugger;
    var getGuid = executionContext.data.entity.getId();
    var req = new XMLHttpRequest();
    req.open("GET", Xrm.Utility.getGlobalContext().getClientUrl() + "/XRMServices/2011/OrganizationData.svc/dobnyc_facadesdocumenttypeSet?$select=dobnyc_dt_RegardingForm,dobnyc_facadesdocumenttypeId,dobnyc_name&$filter=dobnyc_facadesdocumenttypeId eq (guid'" + getGuid + "')", true);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.onreadystatechange = function () {
        if (this.readyState === 4) {
            this.onreadystatechange = null;
            if (this.status === 200) {
                var returned = JSON.parse(this.responseText).d;
                var results = returned.results;
                for (var i = 0; i < results.length; i++) {
                    var dobnyc_dt_RegardingForm = results[i].dobnyc_dt_RegardingForm.Value;
                    var dobnyc_facadesdocumenttypeId = results[i].dobnyc_facadesdocumenttypeId;
                    var dobnyc_name = results[i].dobnyc_name;
                }
            }
            else {
                alert(this.statusText);
            }
        }
    };
    req.send();
    return dobnyc_dt_RegardingForm;
}