function RefreshRibbonOnChange() {
    executionContext.ui.refreshRibbon();
}

function DownloadDocument() {

    var returnValue = null;
    var lookup = new Array();
    lookup[0] = new Object();
    lookup[0].id = Xrm.Utility.getGlobalContext().userSettings.userId;
    lookup[0].name = Xrm.Utility.getGlobalContext().userSettings.userName;
    lookup[0].entityType = "systemuser";



    //alert("check");
    var URL = executionContext.getAttribute("dobnyc_dl_documenturl").getValue();
    //alert(executionContext.getAttribute("dobnyc_isdocumentviewed").getValue());

    if (URL == null) {
        alert("There is no document to download");
        return;
    }

    var Id = executionContext.data.entity.getId();


    var JBGUID = null;
    var path = null;

    var Documentfor = executionContext.getAttribute("dobnyc_dl_regardingform").getValue();
    //alert("Documentfor: " + Documentfor);
    if (Documentfor == 1) //TR6
    {

        JBGUID = getLookupId("dobnyc_dl_regardingtr6");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //alert(JBGUID);
        //returnValue = retrieveMultipleCustom("dobnyc_tr6Set", "?select=dobnyc_TR6_ControlNumber,dobnyc_TR6_Borough,dobnyc_name&$filter=dobnyc_tr6Id eq guid'" + JBGUID + "'");        
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=_dobnyc_tr6_controlnumber_value,dobnyc_tr6_borough,dobnyc_name&$filter=dobnyc_tr6id eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        //   alert((returnValue[0].dobnyc_TR6_Borough).Value + '\\' + returnValue[0].dobnyc_TR6_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
        if (returnValue != null && returnValue[0] != null) {
            path = "Facades\\" + (returnValue[0]["dobnyc_tr6_borough@OData.Community.Display.V1.FormattedValue"]) + '\\' + returnValue[0]["_dobnyc_tr6_controlnumber_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }
    if (Documentfor == 2) //FISP1
    {
        var regtr6, regfisp3;
        var returnValue1 = null;
        JBGUID = getLookupId("dobnyc_dl_regardingfisp1");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_fisponeSet", "?select=dobnyc_FISP1_RegardingTR6,dobnyc_fisp1_RelatedFisp3,dobnyc_name&$filter=dobnyc_fisponeId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispones", "?$select=_dobnyc_fisp1_regardingtr6_value,_dobnyc_fisp1_relatedfisp3_value,dobnyc_name&$filter=dobnyc_fisponeid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        if (returnValue != null && returnValue[0] != null) {
            regtr6 = returnValue[0]["_dobnyc_fisp1_regardingtr6_value"];
            regfisp3 = returnValue[0]["_dobnyc_fisp1_relatedfisp3_value"];
        }
        if (regtr6) {
            //returnValue1 = retrieveMultipleCustom("dobnyc_tr6Set", "?select=dobnyc_TR6_ControlNumber,dobnyc_TR6_Borough&$filter=dobnyc_tr6Id eq guid'" + regtr6 + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=_dobnyc_tr6_controlnumber_value,dobnyc_tr6_borough&$filter=dobnyc_tr6id eq " + regtr6, function (result) {
                returnValue1 = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });    
            if (returnValue1 != null && returnValue1[0] != null) {
                path = "Facades\\" + (returnValue1[0]["dobnyc_tr6_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue1[0]["_dobnyc_tr6_controlnumber_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

            }
        }
        else {
            //returnValue1 = retrieveMultipleCustom("dobnyc_fispthreeSet", "?select=dobnyc_FISP3_Control,dobnyc_FISP3_Borough,dobnyc_name&$filter=dobnyc_fispthreeId eq guid'" + regfisp3 + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispthrees", "?$select=_dobnyc_fisp3_control_value,dobnyc_fisp3_borough,dobnyc_name&$filter=dobnyc_fispthreeid eq " + regfisp3, function (result) {
                returnValue1 = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });    
            
            if (returnValue1 != null && returnValue1[0] != null) {
                path = "Facades\\" + (returnValue1[0]["dobnyc_fisp3_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue1[0]["_dobnyc_fisp3_control_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

            }

        }

        //alert("JBGUID: " + JBGUID);
    }
    if (Documentfor == 3) //FISP2
    {
        var regtr6, regfisp3;
        JBGUID = getLookupId("dobnyc_dl_regardingfisp2");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_fisptwoSet", "?select=dobnyc_FISP2_RegardingTR6,dobnyc_fisp2_RelatedFisp3,dobnyc_name&$filter=dobnyc_fisptwoId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fisptwos", "?$select=_dobnyc_fisp2_regardingtr6_value,_dobnyc_fisp2_relatedfisp3_value,dobnyc_name&$filter=dobnyc_fisptwoid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
        if (returnValue != null && returnValue[0] != null) {
            regtr6 = returnValue[0]["_dobnyc_fisp2_regardingtr6_value"];
            regfisp3 = returnValue[0]["_dobnyc_fisp2_relatedfisp3_value"];
        }
        if (regtr6) {
            //returnValue1 = retrieveMultipleCustom("dobnyc_tr6Set", "?select=dobnyc_TR6_ControlNumber,dobnyc_TR6_Borough&$filter=dobnyc_tr6Id eq guid'" + regtr6 + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=_dobnyc_tr6_controlnumber_value,dobnyc_tr6_borough&$filter=dobnyc_tr6id eq " + regtr6, function (result) {
                returnValue1 = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
            //  alert((returnValue1[0].dobnyc_TR6_Borough).Value + '\\' + returnValue1[0].dobnyc_TR6_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
            if (returnValue1 != null && returnValue1[0] != null) {
                path = "Facades\\" + (returnValue1[0]["dobnyc_tr6_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue1[0]["_dobnyc_tr6_controlnumber_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
            }
        }
        else {
            //returnValue1 = retrieveMultipleCustom("dobnyc_fispthreeSet", "?select=dobnyc_FISP3_Control,dobnyc_FISP3_Borough,dobnyc_name&$filter=dobnyc_fispthreeId eq guid'" + regfisp3 + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispthrees", "?$select=_dobnyc_fisp3_control_value,dobnyc_fisp3_borough,dobnyc_name&$filter=dobnyc_fispthreeid eq " + regfisp3, function (result) {
                returnValue1 = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
            //alert((returnValue1[0].dobnyc_FISP3_Borough).Value + "\\" + returnValue1[0].dobnyc_FISP3_Control.Name + "\\" + returnValue[0].dobnyc_name);
            if (returnValue1 != null && returnValue1[0] != null) {
                path = "Facades\\" + (returnValue1[0]["dobnyc_fisp3_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue1[0]["_dobnyc_fisp3_control_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

            }
        }




    }
    if (Documentfor == 4) // FISP3
    {
        //var ProgressinspectionId = getLookupId("dobnyc_gotoprogressinspection");
        //var returnValue = null;
        //returnValue = retrieveMultipleCustom("dobnyc_progressinspectioncategorySet", "?select=dobnyc_ProgressionInspectioncategorytoId&$filter=dobnyc_progressinspectioncategoryId eq guid'" + ProgressinspectionId + "'");
        JBGUID = getLookupId("dobnyc_dl_regardingfisp3");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //alert("JBGUID" + JBGUID);
        //returnValue = retrieveMultipleCustom("dobnyc_fispthreeSet", "?select=dobnyc_FISP3_Control,dobnyc_FISP3_Borough,dobnyc_name&$filter=dobnyc_fispthreeId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispthrees", "?$select=_dobnyc_fisp3_control_value,dobnyc_fisp3_borough,dobnyc_name&$filter=dobnyc_fispthreeid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
        //alert((returnValue[0].dobnyc_FISP3_Borough).Value + "\\" + returnValue[0].dobnyc_FISP3_Control.Name + "\\" + returnValue[0].dobnyc_name);
        if (returnValue != null && returnValue[0] != null) {
            path = "Facades\\" + (returnValue[0]["dobnyc_fisp3_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue[0]["_dobnyc_fisp3_control_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }
    if (Documentfor == 5) // PSR
    {
        JBGUID = getLookupId("dobnyc_dl_regardingpsr");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_partialshedremovalSet", "?select=dobnyc_PSR_ControlNumber,dobnyc_PSR_Borough,dobnyc_name&$filter=dobnyc_partialshedremovalId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_partialshedremovals", "?$select=_dobnyc_psr_controlnumber_value,dobnyc_psr_borough,dobnyc_name&$filter=dobnyc_partialshedremovalid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
        //alert((returnValue[0].dobnyc_PSR_Borough).Value + "\\" + returnValue[0].dobnyc_PSR_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
        if (returnValue != null && returnValue[0] != null) {
            path = "Facades\\" + (returnValue[0]["dobnyc_psr_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue[0]["_dobnyc_psr_controlnumber_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }
    if (Documentfor == 6) // HV
    {
        try {
            JBGUID = getLookupId("dobnyc_dl_regardinghv");
            JBGUID = JBGUID.replace("{", "").replace("}", "");
            //  alert("JBGUID:" + JBGUID);
            //returnValue = retrieveMultipleCustom("dobnyc_heightverificationSet", "?select=dobnyc_HV_ControlNumber,dobnyc_HV_Borough,dobnyc_name&$filter=dobnyc_heightverificationId eq guid'" + JBGUID + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_heightverifications", "?$select=_dobnyc_hv_controlnumber_value,dobnyc_hv_borough,dobnyc_name&$filter=dobnyc_heightverificationid eq " + JBGUID, function (result) {
                returnValue = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
            //alert("returnValue" + returnValue);
            //alert("Retrun value inner values" + returnValue[0].dobnyc_HV_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
            if (returnValue != null && returnValue[0] != null) {
                if (returnValue[0]["_dobnyc_hv_controlnumber_value"]) {
                    path = "Facades\\" + (returnValue[0]["dobnyc_hv_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue[0]["_dobnyc_hv_controlnumber_value@OData.Community.Display.V1.FormattedValue"] + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
                }
                else {
                    path = "Facades\\" + (returnValue[0]["dobnyc_hv_borough@OData.Community.Display.V1.FormattedValue"]) + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

                }
            }

        }
        catch (e) {
            alert(e.message);
        }

    }

    //CNR
    if (Documentfor == 7) {
        //dobnyc_controlnumberrequestSet?$select=dobnyc_bin,dobnyc_name&$filter=dobnyc_controlnumberrequestId eq (guid'sdfsdfsdf')
        JBGUID = getLookupId("dobnyc_dl_regardingcnr");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_controlnumberrequestSet", "?select=dobnyc_bin,dobnyc_name&$filter=dobnyc_controlnumberrequestId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_controlnumberrequests", "?$select=dobnyc_bin,dobnyc_name&$filter=dobnyc_controlnumberrequestid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       
        //alert((returnValue[0].dobnyc_PSR_Borough).Value + "\\" + returnValue[0].dobnyc_PSR_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
        if (returnValue != null && returnValue[0] != null) {
            path = "Facades\\" + (returnValue[0].dobnyc_bin) + "\\" + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }



     var Config_URL = getMessage("downloadFromDocumentumToCRM");


    $.support.cors = true;

    $.ajax({
        type: "POST",
        url: Config_URL,
        processData: true,
        crossDomain: true,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
        cache: false,
        headers: {
            'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
        },
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            if (data.DownloadIsSuccess == true) {
                //alert("Download Successful");
                executionContext.getAttribute("dobnyc_isdocumentviewed").setSubmitMode("always");
                executionContext.getAttribute("dobnyc_fl_viewedby").setSubmitMode("always");
                executionContext.getAttribute("dobnyc_isdocumentviewed").setValue(true);
                executionContext.getAttribute("dobnyc_fl_viewedby").setValue(lookup);
                executionContext.data.entity.save();
                window.open(data.downloadPath);

            }
            else {

                //alert(data.ErrorDescription);
                alert("Download is Un-successful");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            alert("An error occured while downloding document. Please try again or contact administrator.");
        }
    });

}

function getMessage(key) {
    /// get Data from configuration entity
    var returnValue = null;
    //returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'");
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_customconfigurationses", "?$filter=dobnyc_key eq '" + key + "' and dobnyc_langugaecode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'", function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });       

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0].dobnyc_name;

    return "Unable to get configuration message for Key : " + key + ".";
}

function getLookupId(attributeName) {

    lookupObject = executionContext.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = executionContext.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}

function checkSecurityRole() {
    var isValidRole = false;
    var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == "System Administrator") {
            isValidRole = true;
            break;
        }

    }
    return isValidRole;
}

function GetRoleName(RoleId) {
    //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
    //var returnValue = retrieveMultipleCustom("RoleSet", "?select=Name&$filter=RoleId eq guid'" + RoleId + "'");

    RoleId = RoleId.replace("{", "").replace("}", "");

    var returnValue = null;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "roles", "?$select=name&$filter=roleid eq " + RoleId, function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
    if (returnValue != null && returnValue[0] != null) {
        // alert("Role name: " + returnValue[0].Name);
        return returnValue[0].name;
    }
}

function ReplaceDocument() {
    //debugger;
    // alert("Replace Documents");
    var Borough = "";
    var control = "";
    var Bin = null;
    var filingNumber = "";
    //tr6
    //fisp3
    //psr
    //HV
    var documentName = executionContext.getAttribute("dobnyc_name").getValue();
    var docTypeName = getLookupName("dobnyc_dl_documenttypeguid");

    var docTypeListID = executionContext.data.entity.getId();
    var docCategory = "Supporting Documents";
    var JBGUID = null;
    var Documentfor = executionContext.getAttribute("dobnyc_dl_regardingform").getValue();
    // alert("Documentfor: " + Documentfor);

    var returnValue = null;
    if (getLookupId("dobnyc_dl_regardingfisp3")) {
        JBGUID = getLookupId("dobnyc_dl_regardingfisp3");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_fispthreeSet", "?select=dobnyc_FISP3_Borough,dobnyc_FISP3_Control,dobnyc_FISP3_BIN,dobnyc_name&$filter=dobnyc_fispthreeId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispthrees", "?$select=dobnyc_fisp3_borough,_dobnyc_fisp3_control_value,dobnyc_fisp3_bin,dobnyc_name&$filter=dobnyc_fispthreeid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });     
        Borough = (returnValue[0]["dobnyc_fisp3_borough@OData.Community.Display.V1.FormattedValue"]);
        control = returnValue[0]["_dobnyc_fisp3_control_value@OData.Community.Display.V1.FormattedValue"];
        Bin = returnValue[0].dobnyc_fisp3_bin;
    }
    if (getLookupId("dobnyc_dl_regardingtr6")) {
        JBGUID = getLookupId("dobnyc_dl_regardingtr6");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_tr6Set", "?select=dobnyc_TR6_ControlNumber,dobnyc_TR6_Borough,dobnyc_TR6_BIN,dobnyc_name&$filter=dobnyc_tr6Id eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=_dobnyc_tr6_controlnumber_value,dobnyc_tr6_borough,dobnyc_tr6_bin,dobnyc_name&$filter=dobnyc_tr6id eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });     
        Borough = (returnValue[0]["dobnyc_tr6_borough@OData.Community.Display.V1.FormattedValue"]);
        control = returnValue[0]["_dobnyc_tr6_controlnumber_value@OData.Community.Display.V1.FormattedValue"];
        Bin = returnValue[0].dobnyc_tr6_bin;
    }
    if (getLookupId("dobnyc_dl_regardinghv")) {
        JBGUID = getLookupId("dobnyc_dl_regardinghv");
        JBGUID = JBGUID.replace("{", "").replace("}", "");

        //returnValue = retrieveMultipleCustom("dobnyc_heightverificationSet", "?select=dobnyc_HV_ControlNumber,dobnyc_HV_BIN,dobnyc_HV_Borough,dobnyc_name&$filter=dobnyc_heightverificationId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_heightverifications", "?$select=_dobnyc_hv_controlnumber_value,dobnyc_hv_bin,dobnyc_hv_borough,dobnyc_name&$filter=dobnyc_heightverificationid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });     
        Borough = (returnValue[0]["dobnyc_hv_borough@OData.Community.Display.V1.FormattedValue"]);
        if (returnValue[0]["_dobnyc_hv_controlnumber_value"]) 
        { 
            control = returnValue[0]["_dobnyc_hv_controlnumber_value@OData.Community.Display.V1.FormattedValue"];
            Bin = returnValue[0].dobnyc_hv_bin;
        }
        else 
        {
            control = "No ControlNumber";
        }
    }
    if (getLookupId("dobnyc_dl_regardingpsr")) {
        JBGUID = getLookupId("dobnyc_dl_regardingpsr");
        JBGUID = JBGUID.replace("{", "").replace("}", "");
        //returnValue = retrieveMultipleCustom("dobnyc_partialshedremovalSet", "?select=dobnyc_PSR_ControlNumber,dobnyc_PSR_BIN,dobnyc_PSR_Borough,dobnyc_name&$filter=dobnyc_partialshedremovalId eq guid'" + JBGUID + "'");
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_partialshedremovals", "?$select=_dobnyc_psr_controlnumber_value,dobnyc_psr_bin,dobnyc_psr_borough,dobnyc_name&$filter=dobnyc_partialshedremovalid eq " + JBGUID, function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });             
        Borough = (returnValue[0]["dobnyc_psr_borough@OData.Community.Display.V1.FormattedValue"]);
        control = returnValue[0]["_dobnyc_psr_controlnumber_value@OData.Community.Display.V1.FormattedValue"];
        Bin = returnValue[0].dobnyc_psr_bin;
    }
    //CNR check security role and allow only admins no other users
    if (getLookupId("dobnyc_dl_regardingcnr")) {
        var isvalid = checkSecurityRole();
        if (isvalid) {
            //dobnyc_controlnumberrequestSet?$select=dobnyc_Borough,dobnyc_name&$filter=dobnyc_controlnumberrequestId eq (guid'as')",
            JBGUID = getLookupId("dobnyc_dl_regardingcnr");
            JBGUID = JBGUID.replace("{", "").replace("}", "");
            //returnValue = retrieveMultipleCustom("dobnyc_controlnumberrequestSet", "?select=dobnyc_Borough,dobnyc_name&$filter=dobnyc_controlnumberrequestId eq guid'" + JBGUID + "'");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_controlnumberrequests", "?$select=dobnyc_borough,dobnyc_name&$filter=dobnyc_controlnumberrequestid eq " + JBGUID, function (result) {
                returnValue = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });             
            Borough = (returnValue[0]["dobnyc_borough@OData.Community.Display.V1.FormattedValue"]);
            control = "No ControlNumber";
        }
        else {
            return;
        }
    }

    var DOCID = docTypeListID.substring(1, docTypeListID.length - 1);

    var URL = "http://10.155.208.60:5556/FacadesCRMDocumentUpload.html?borough=" + Borough + "&controlNumber=" + control + "&reqNumber=" + returnValue[0].dobnyc_name + "&docCategory=" + docCategory + "&documentName=" + documentName + "&docTypeName=" + docTypeName + "&docTypeListID=" + DOCID + "&user=UserGUID" +"&Bin=" + Bin;

    //var customParameters = encodeURIComponent("borough=" +(returnValue[0].dobnyc_BoroughNYC).Value + "&jobNumber=" + returnValue[0].dobnyc_ProjectNumber + "&filingNumber=" + returnValue[0].dobnyc_FilingNumber + "&reqNumber=ReqNo&docCategory=" + docLabel + "&docType=" + docCat + "&docTypeListID=" + DOCID + "&user=UserGUID&docTypeName=" + docTypeName);
    //alert(customParameters);
    //var uri_dec = decodeURIComponent(customParameters);
    //Xrm.Utility.openWebResource("dobnyc_UploadDocument", uri_dec);

    //alert(URL);
    var isChrome = !!window.chrome && !!window.chrome.webstore;
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    var Title = "Upload Document";
    var opt = 'dialogWidth:530px; dialogHeight:200px; center:yes; scroll:no; status:no';

    if (!window.showModalDialog) {
        window.showModalDialog = function (URL, Title, opt) {

            var w;
            var h;
            var resizable = "no";
            var scroll = "no";
            var status = "no";

            // get the modal specs
            var mdattrs = opt.split(";");
            for (i = 0; i < mdattrs.length; i++) {
                var mdattr = mdattrs[i].split(":");

                var n = mdattr[0];
                var v = mdattr[1];
                if (n) { n = n.trim().toLowerCase(); }
                if (v) { v = v.trim().toLowerCase(); }

                if (n == "dialogheight") {
                    h = v.replace("px", "");
                } else if (n == "dialogwidth") {
                    w = v.replace("px", "");
                } else if (n == "resizable") {
                    resizable = v;
                } else if (n == "scroll") {
                    scroll = v;
                } else if (n == "status") {
                    status = v;
                }
            }

            var left = window.screenX + (window.outerWidth / 2) - (w / 2);
            var top = window.screenY + (window.outerHeight / 2) - (h / 2);
            var targetWin = window.open(URL, Title, 'toolbar=no, location=no, directories=no, status=' + status + ', menubar=no, scrollbars=' + scroll + ', resizable=' + resizable + ', copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
            targetWin.focus();
        };


        window.showModalDialog(URL, Title, opt);

    }
    else {
        window.showModalDialog(URL, Title, opt);
        window.location.reload();
    }
}

function setDocFields() {

    var Id = getLookupId("dobnyc_documentnamedocumentlist");    
    if (Id == null)
        return;

    Id = Id.replace("{", "").replace("}", "");
    var returnValue = null;

    //returnValue = retrieveMultipleCustom("dobnyc_documenttypesSet", "?select=dobnyc_RequiredItemNumber&$filter=dobnyc_documenttypesId eq guid'" + Id + "'");
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_documenttypeses", "?$select=dobnyc_requireditemnumber&$filter=dobnyc_documenttypesid eq " + Id, function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });             

    if (returnValue != null && returnValue[0] != null) {
        //alert(returnValue[0].dobnyc_Objection);
        //alert((returnValue[0].dobnyc_ObjectionType_ObjectionCatagory).Value);
        executionContext.getAttribute("dobnyc_requestnumber").setValue(returnValue[0].dobnyc_requireditemnumber);


    }

}

function OnLoad() {
   // debugger;
    onLoadFormFormat();
    //filterDocumentTypeLookup();
    var formType = executionContext.ui.getFormType();
    //executionContext.getControl("dobnyc_dl_documenturl").setVisible(true);

    var admintaskID = getLookupId("dobnyc_documentlisttofacadetaskid");
    var planexaminertaskID = getLookupId("dobnyc_planexaminerdocumentlistforfacaid");
    var inspectiontaskID = getLookupId("dobnyc_inspectiondocumentlistid");
    var plansupervisortaskID = getLookupId("dobnyc_planexaminersupervisordocumentlist");
	var Documentfor = executionContext.getAttribute("dobnyc_dl_regardingform").getValue();
            if (Documentfor == 1) {
                executionContext.getControl("dobnyc_dl_regardingtr6").setVisible(true);
            }
            if (Documentfor == 2) {
                executionContext.getControl("dobnyc_dl_regardingfisp1").setVisible(true);
            }
            if (Documentfor == 3) {
                executionContext.getControl("dobnyc_dl_regardingfisp2").setVisible(true);
            }
            if (Documentfor == 4) {
                executionContext.getControl("dobnyc_dl_regardingfisp3").setVisible(true);
            }
            if (Documentfor == 5) {
                executionContext.getControl("dobnyc_dl_regardingpsr").setVisible(true);
            }
            if (Documentfor == 6) {
				filterDocumentTypeLookup();
                executionContext.getControl("dobnyc_dl_regardinghv").setVisible(true);
            }
            if (Documentfor == 7) {
                executionContext.getControl("dobnyc_dl_regardingcnr").setVisible(true);
            }
    if (admintaskID || planexaminertaskID || inspectiontaskID || plansupervisortaskID) {
        //check URL has data  or not
        var DocumentURL = executionContext.getAttribute("dobnyc_dl_documenturl").getValue();


        if (DocumentURL) {

            
            executionContext.getAttribute("dobnyc_dl_documenturl").setSubmitMode("always");
            executionContext.getAttribute("dobnyc_ft_document_status").setSubmitMode("always");

            formType = executionContext.ui.getFormType();

             if (formType != 1)
                disableFormFields(true);


        }
        else {
            var returnValue = "";
            if (admintaskID) {
                //get the Regarding Task entity from admintask ID
                //dobnyc_facadetaskSet?$select=RegardingObjectId&$filter=ActivityId eq (guid'jhdjhasdjhasdjh')
                getTaskDeatils(admintaskID);


            }
            if (planexaminertaskID) {
                getTaskDeatils(planexaminertaskID);


            }
            if (inspectiontaskID) {
                getTaskDeatils(inspectiontaskID);


            }
            if (plansupervisortaskID) {
                getTaskDeatils(plansupervisortaskID);
            }

        }

    }
    // if (formType != 1)
    //disableFormFields(true);

}


function getTaskDeatils(taskID) {
    taskID = taskID.replace("{", "").replace("}", "");
    //var returnValue = retrieveMultipleCustom("dobnyc_facadetaskSet", "?select=RegardingObjectId&$filter=ActivityId eq guid'" + taskID + "'");
    var returnValue = null;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadetasks", "?$select=_regardingobjectid_value&$filter=activityid eq " + taskID, function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
    if (returnValue[0]["_regardingobjectid_value"]) {
        //call function setlookup
        setDocumentListFields(returnValue[0]["_regardingobjectid_value"]);
    }
}
function setDocumentListFields(entity) {

    //dobnyc_facadesdocumenttypeSet?$select=dobnyc_facadesdocumenttypeId,dobnyc_name&$filter=dobnyc_name eq 'After%20Inspection'

    var fieldName = ""
    var DocumentType = "After Inspection"
    if (entity.LogicalName) {
        if (entity.LogicalName == "dobnyc_tr6") {
            fieldName = "dobnyc_dl_regardingtr6"
            setLookup(fieldName, entity);
            executionContext.getAttribute("dobnyc_dl_regardingform").setValue(1);




        }
        if (entity.LogicalName == "dobnyc_fispthree") {
            fieldName = "dobnyc_dl_regardingfisp3";
            setLookup(fieldName, entity);
            executionContext.getAttribute("dobnyc_dl_regardingform").setValue(4);



        }
        if (entity.LogicalName == "dobnyc_heightverification") {
            fieldName = "dobnyc_dl_regardinghv";
            setLookup(fieldName, entity);
            executionContext.getAttribute("dobnyc_dl_regardingform").setValue(6);



        }
        if (entity.LogicalName == "dobnyc_partialshedremoval") {
            fieldName = "dobnyc_dl_regardingpsr";
            setLookup(fieldName, entity);
            executionContext.getAttribute("dobnyc_dl_regardingform").setValue(5);



        }
        //var returnValue = retrieveMultipleCustom("dobnyc_facadesdocumenttypeSet", "?$select=dobnyc_facadesdocumenttypeId,dobnyc_name&$filter=dobnyc_name eq '" + DocumentType + "'");
        var returnValue = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadesdocumenttypes", "?$select=dobnyc_facadesdocumenttypeid,dobnyc_name&$filter=dobnyc_name eq '" + DocumentType + "'", function (result) {
            returnValue = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
        var entity1 = {};
        entity1.Name = returnValue[0].dobnyc_name;
        entity1.Id = returnValue[0].dobnyc_facadesdocumenttypeid;
        entity1.LogicalName = "dobnyc_facadesdocumenttype";
        setLookup("dobnyc_dl_documenttypeguid", entity1);

        executionContext.getAttribute("dobnyc_isinspectiondocument").setValue(true);
        executionContext.getAttribute("dobnyc_ft_document_status").setValue(3);

    }

}
function setLookup(fieldName, entity) {
    var lookupData = new Array();
    var lookupItem = new Object();
    //Set the GUID
    lookupItem.id = entity.Id;
    //Set the name
    lookupItem.name = entity.Name;
    lookupItem.entityType = entity.LogicalName;
    lookupData[0] = lookupItem;

    //If existing value is empty, then set new value
    var existingValue = executionContext.getAttribute(fieldName).getValue();

    if (existingValue === null) {
        executionContext.getAttribute(fieldName).setValue([{
            id: entity.Id,
            name: entity.Name,
            entityType: entity.LogicalName
        }]);
    } else {
        return;
    }

}


function disableFormFields(onOff) {
    executionContext.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }

    }
    );

}


function doesControlHaveattribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}


function onLoadFormFormat() {
    //debugger;
    if (executionContext.ui.getFormType() == 1) {
        executionContext.getControl("dobnyc_ft_document_status").setDisabled(true);
        executionContext.getControl("dobnyc_dl_regardingtr6").setVisible(false);
        executionContext.getControl("dobnyc_dl_documenturl").setVisible(false);
        executionContext.getControl("dobnyc_dl_documentsource").setVisible(false);
        executionContext.getControl("dobnyc_fl_uploadeddate").setVisible(false);
        executionContext.getControl("dobnyc_fl_viewedby").setVisible(false);
        if (executionContext.getAttribute("dobnyc_dl_regardinghv").getValue() != null) {
            executionContext.getAttribute("dobnyc_dl_regardingform").setValue(6);
        }
    }

    if (executionContext.ui.getFormType() == 2) {
        var name = '';
        var lookupid;
        var lookupObject = executionContext.getAttribute("dobnyc_dl_regardinghv");
        if (lookupObject != null) {
            var lookUpObjectValue = lookupObject.getValue();
            if (lookUpObjectValue != null) {
                name = lookUpObjectValue[0].name;
                lookupid = lookUpObjectValue[0].id;
            }
        }
        if (executionContext.getAttribute("dobnyc_dl_regardinghv").getValue() != null && lookupid != null) {
            executionContext.getControl("dobnyc_ft_document_status").setDisabled(true);
            executionContext.getControl("dobnyc_dl_regardingtr6").setVisible(false);
            executionContext.getControl("dobnyc_dl_documenturl").setVisible(false);
            executionContext.getControl("dobnyc_dl_documentsource").setVisible(false);
            executionContext.getControl("dobnyc_fl_uploadeddate").setVisible(false);
            executionContext.getControl("dobnyc_fl_viewedby").setVisible(true);
        }
    }
}


function filterDocumentTypeLookup() {
    //Check if the control exist on the form
    try {
        var lookupControl = executionContext.getControl("dobnyc_dl_documenttypeguid");
        if (lookupControl != null && lookupControl != undefined) {
            // add the event handler for PreSearch Event
            executionContext.getControl("dobnyc_dl_documenttypeguid").addPreSearch(function () { addFilter(); });
        }
    }
    catch (e) {
        Xrm.Utility.alertDialog("filterLookup Error:" + (e.description || e.message));
    }
}

function addFilter() {
    //var accountId = null;

    //var accountLookup;
    var fetchQuery;
    try {
        //Check if control exist on form
        //if (executionContext.getControl("header_process_parentaccountid") != null && executionContext.getControl("header_process_parentaccountid").getAttribute().getValue() != null) {
        //Get Account lookup value
        //  accountLookup = executionContext.getControl("header_process_parentaccountid").getAttribute().getValue();
        //Get the account id
        // accountId = accountLookup[0].id;
        //}
        //Build fetch
        //if (accountId != null || accountId != undefined) {
        fetchQuery = "<filter type='and'><condition attribute='dobnyc_dt_regardingform' operator='eq' value='6' /></filter>";
        //"<filter type='and'><condition attribute='parentcustomerid' operator='eq' value='" + accountId + "' /></filter>";

        /*
        This style of fetch XML also works, add + after every line
        fetchQuery = "<filter type='and'>"+
              "<condition attribute='parentcustomerid' operator='eq' value='"+accountId+"' />"+
            "</filter>";
        */
        //add custom filter
        executionContext.getControl("dobnyc_dl_documenttypeguid").addCustomFilter(fetchQuery);
    }
    //}
    catch (e) {
        Xrm.Utility.alertDialog("addFilter Error: " + (e.description || e.message));
    }
}