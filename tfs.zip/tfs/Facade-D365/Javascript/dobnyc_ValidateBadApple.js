function BadAppleQEWI(Email)
{
    var BadQEWI = false;
    //var QEWIDetail = retrieveMultipleCustom("dobnyc_qewiSet", "?select=dobnyc_BadAppleQEWI&$filter=dobnyc_name eq '" + Email + "'");
    var QEWIDetail = null;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_qewis", "?$select=dobnyc_badappleqewi&$filter=dobnyc_name eq '" + Email + "'", function (result) {
        QEWIDetail = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });  
    if (QEWIDetail != null && QEWIDetail[0] != null) {
        BadQEWI = QEWIDetail[0].dobnyc_badappleqewi;
    }
    return BadQEWI;
}


var QEWIEmailMapping = {
    "dobnyc_tr6": "dobnyc_tr6_qewiemail",
    "dobnyc_fispone": "dobnyc_fisp1_qewiemail",
    "dobnyc_fisptwo": "dobnyc_fisp2_qewiemail",
	"dobnyc_subcyclereassignmentrequest": "dobnyc_scr_qewiemail",
	"dobnyc_partialshedremoval": "dobnyc_psr_qewiemail",
	"dobnyc_heightverification": "dobnyc_hv_qewiemail",
	"dobnyc_controlnumberrequest": "dobnyc_cr_qewiemail",
	"dobnyc_fispthree": "dobnyc_fisp3_qewiemail"
};

function validateQEWIonload()
{
//debugger;
	  var entityName = executionContext.data.entity.getEntityName();
	  var BadApple = false;    
		var QEWIemail = executionContext.getAttribute(QEWIEmailMapping[entityName]).getValue();
		if(QEWIemail != null)
		BadApple = BadAppleQEWI(QEWIemail);
        if(BadApple)
			 executionContext.ui.setFormNotification("NOTE: This QEWI is on the “Questionable QEWI” list.", "WARNING");

}