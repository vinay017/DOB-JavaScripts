//CNR
function ControlNumberGenerationTaskOnLoad() {
debugger;
    var cnR = executionContext.getAttribute("dobnyc_clickheretogotocontrolnumberrequest").getValue();
    if (cnR != null && cnR[0].id != null) {
        var currentrequestBIN = GetCurrentRequestBin(cnR[0].id);
    }

}


function GetCurrentRequestBin(cnrId) {
    var bin = null;
    var returnValue = null;
    //retrive multiple record 
    //returnValue = retrieveMultipleCustom("dobnyc_controlnumberrequestSet", "?select=dobnyc_bin,dobnyc_name&$filter=dobnyc_controlnumberrequestId eq guid'" + cnrId + "'");
    //if (returnValue != null && returnValue[0] != null) {
    //    GetOtherControlNumbersForThisBin(returnValue[0].dobnyc_bin);
    //}

    cnrId = cnrId.replace("{", "").replace("}", "");

    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_controlnumberrequests", "?$select=dobnyc_bin,dobnyc_name&$filter=dobnyc_controlnumberrequestid eq " + cnrId, function (result) {
        if (result.value.length != 0) {
            GetOtherControlNumbersForThisBin(result.value[0].dobnyc_bin);
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
}

function GetOtherControlNumbersForThisBin(bin) {
    var otherCN = null;
    //dobnyc_controlnumberSet?$select=dobnyc_name&$filter=dobnyc_CN_Bin eq 'dgsdg'"
    var returnValue = null;
    var prevControlNumbers = null;
    //returnValue = retrieveMultipleCustom("dobnyc_controlnumberSet", "?$select=dobnyc_name&$filter=dobnyc_CN_Bin eq '" + bin + "'");
    //if (returnValue != null && returnValue[0] != null)
    //{
    //    if(returnValue.length>0)
    //    {
    //        for (var i = 0; i < returnValue.length; i++) {
    //                            if (i == 0) {
    //                                prevControlNumbers = prevControlNumbers + returnValue[i].dobnyc_name;
    //                            }
    //                            else {
    //                                prevControlNumbers = prevControlNumbers + ", " + returnValue[i].dobnyc_name;
    //                            }
    //        }
    //        executionContext.ui.setFormNotification("The Following Control Numbers Exist for this BIN: " + prevControlNumbers + ". Please ensure validity before accepting.", "ERROR");

    //    }

    //}

    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_controlnumbers", "?$select=dobnyc_name&$filter=dobnyc_cn_bin eq '" + bin + "'", function (result) {
        if (result.value.length != 0) {              
            for (var i = 0; i < result.value.length; i++) {
                if (i == 0) {
                    prevControlNumbers = prevControlNumbers + result.value[i].dobnyc_name;
                }
                else {
                    prevControlNumbers = prevControlNumbers + ", " + result.value[i].dobnyc_name;
                }
            }
            executionContext.ui.setFormNotification("The Following Control Numbers Exist for this BIN: " + prevControlNumbers + ". Please ensure validity before accepting.", "ERROR");
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

}
