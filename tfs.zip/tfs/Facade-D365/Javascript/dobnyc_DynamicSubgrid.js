function dySubgrid() {
    var formLableIs = "Administrative Review Form";
    var Taskform = executionContext.ui.getFormType();
    var form = executionContext.ui.formSelector.getCurrentItem();
    var formId = form.getId();
    var formLabel = form.getLabel();
    var isAdminiReview = "Administrative Review";
    var fetchXml = "";

    var FispValue = "Yes";
    //Tr6 Section
    if ((executionContext.getAttribute("dobnyc_ft_istr6").getValue())) {


        var Tr6guid = getLookupId("dobnyc_ft_gototr6");
        if (Tr6guid) {
            Tr6guid = Tr6guid.replace("{", "").replace("}", "");

            // debugger;
            //var returnValue = retrieveMultipleCustom("dobnyc_tr6Set", "?$select=dobnyc_TR6_ControlNumber,dobnyc_TR6_FilingType&$filter=dobnyc_tr6Id eq (guid'" + Tr6guid + "')&$top=1");
            var returnValue = null;
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=_dobnyc_tr6_controlnumber_value,dobnyc_tr6_filingtype&$filter=dobnyc_tr6id eq " + Tr6guid, function (result) {
                returnValue = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
            ////  alert(returnValue.count);
            var control = returnValue[0]["_dobnyc_tr6_controlnumber_value"];
            var Tr6FilingType = returnValue[0].dobnyc_tr6_filingtype;
            var controlname = returnValue[0]["_dobnyc_tr6_controlnumber_value@OData.Community.Display.V1.FormattedValue"];

            //returnValue = retrieveMultipleCustom("dobnyc_tr6Set", "?$select=dobnyc_tr6Id&$filter=dobnyc_TR6_ControlNumber/Id eq (guid'" + control + "') and dobnyc_TR6_FilingType/Value eq " + Tr6FilingType + "and dobnyc_tr6_IsPossibleDuplicate eq true and  dobnyc_tr6_IsInactive eq false and dobnyc_tr6Id ne (guid'" + Tr6guid + "')");                        
            returnValue = null;
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_tr6s", "?$select=dobnyc_tr6id&$filter=_dobnyc_tr6_controlnumber_value eq " + control + " and dobnyc_tr6_filingtype eq " + Tr6FilingType + "and dobnyc_tr6_ispossibleduplicate eq true and  dobnyc_tr6_isinactive eq false and dobnyc_tr6id ne " + Tr6guid, function (result) {
                returnValue = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

            fetchXml = "<?xml version='1.0'?><fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            fetchXml += "<entity name='dobnyc_tr6'>";
            fetchXml += " <attribute name='dobnyc_name'/>";
            fetchXml += "<attribute name='createdon'/>";
            fetchXml += "<attribute name='dobnyc_tr6_streetname'/>";
            fetchXml += "<attribute name='dobnyc_fr_stories'/>";
            fetchXml += "<attribute name='dobnyc_tr6_qualifiedexteriorwallinspector'/>";
            fetchXml += "<attribute name='dobnyc_tr6_houseno'/>";
            fetchXml += "<attribute name='dobnyc_tr6_filingtype'/>";
            fetchXml += "<attribute name='dobnyc_tr6_filingstatus'/>";
            fetchXml += "<attribute name='dobnyc_tr6_controlnumber'/>";
            fetchXml += "<attribute name='dobnyc_tr6_borough'/>";
            fetchXml += "<attribute name='dobnyc_tr6_block'/>";
            fetchXml += "<attribute name='dobnyc_tr6_bin'/>";

            fetchXml += "<attribute name='dobnyc_tr6_amountpaid'/>";
            fetchXml += "<attribute name='dobnyc_tr6_reportstatus'/>";
            fetchXml += "<attribute name='dobnyc_tr6id'/>";
            fetchXml += "<attribute name='dobnyc_tr6_bin'/>";


            fetchXml += "<order descending='false' attribute='dobnyc_name'/>";
            fetchXml += "<filter type='and'>";
            fetchXml += "<condition attribute='dobnyc_tr6_isinactive' value='0' operator='eq'/>";
            fetchXml += "<condition attribute='dobnyc_tr6_controlnumber' value='" + control + "' uitype='dobnyc_controlnumber' uiname='" + controlname + "' operator='eq'/>";
            fetchXml += " <condition attribute='dobnyc_tr6_filingtype' value='" + Tr6FilingType + "' operator='eq'/>";
            fetchXml += " <condition attribute='dobnyc_tr6_reportstatus' operator='in'>";
            fetchXml += "<value>2</value>";
            fetchXml += " <value>5</value>";
            fetchXml += " <value>4</value>";
            fetchXml += " <value>3</value>";
            fetchXml += " </condition>";


            fetchXml += "</filter></entity></fetch>";
            //Set the fetchxml directly to subgrid

            if (DOB.Dynamics365.IsUCI()) {                
                //var setFetchXmlStr = Microsoft.Crm.Client.Core.Storage.DataApi.ListQuery.prototype.set_FetchXml.toString();
                //var newFunc = setFetchXmlStr.replace("function(e){", "function(e){debugger; if (e.indexOf('dobnyc_tr6') >= 0) {e = fetchXml;}");
                //eval("Microsoft.Crm.Client.Core.Storage.DataApi.ListQuery.prototype.set_FetchXml=" + newFunc);
                //executionContext.getControl("TR6Duplicates").refresh();                
            }
            else {  
                setTimeout(function () {
                    var ConnectionSubgrid = executionContext.getControl("TR6Duplicates");
                    ConnectionSubgrid.getGrid().setParameter("fetchXml", fetchXml);
                    ConnectionSubgrid.refresh();
                }, 3000);                
                //var ConnectionSubgrid = parent.document.getElementById("TR6Duplicates");
                //if (ConnectionSubgrid == null || !ConnectionSubgrid.control) {
                //    setTimeout(function () { dySubgrid(); }, 2000); //if the grid hasn’t loaded run this again                    
                //    return;
                //}
            }

            // countRecords("TR6Duplicates");
            if (returnValue.length >= 1) {
                toggleSection("FT_General", "FT_General_TR6Duplicates", true);

            }
            else {
                toggleSection("FT_General", "FT_General_TR6Duplicates", false);
            }
        }
        else {
            toggleSection("FT_General", "FT_General_TR6Duplicates", false);
        }
    }
    //Fisp1 Section
    if (executionContext.getAttribute("dobnyc_ft_isfispone").getValue()) {
        var fisp1Guid = getLookupId("regardingobjectid");
        fisp1Guid = fisp1Guid.replace("{", "").replace("}", "");

        //var parentTr6Response = retrieveMultipleCustom("dobnyc_fisponeSet", "?$select=dobnyc_FISP1_RegardingTR6&$filter=dobnyc_fisponeId eq (guid'" + fisp1Guid + "')&$top=1");

        var parentTr6Response = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispones", "?$select=_dobnyc_fisp1_regardingtr6_value&$filter=dobnyc_fisponeid eq " + fisp1Guid, function (result) {
            parentTr6Response = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        if (parentTr6Response != null && parentTr6Response[0] != null) {
            //get the guid of Tr6
            var tr6Guid = parentTr6Response[0]["_dobnyc_fisp1_regardingtr6_value"];
            //var DuplicateResponse = retrieveMultipleCustom("dobnyc_fisponeSet", "?$select=dobnyc_fisponeId&$filter=dobnyc_FISP1_RegardingTR6/Id eq (guid'" + tr6Guid + "') and dobnyc_Fisp1_IsPossibleDuplicate eq true and dobnyc_fisp1_IsInactive eq false and dobnyc_fisponeId ne (guid'" + fisp1Guid + "')");

            //?$select=dobnyc_fisponeid,dobnyc_fisp1_regardingtr6,dobnyc_fisp1_ispossibleduplicate,dobnyc_fisp1_isinactive, dobnyc_fisponeid
            //&$select=dobnyc_fisponeid&$filter=_dobnyc_fisp1_regardingtr6_value eq 98597941-204d-e611-810b-005056ab45d6 and dobnyc_fisp1_ispossibleduplicate eq true and dobnyc_fisp1_isinactive eq false and dobnyc_fisponeid ne 3e974a7c-6011-e611-8108-005056ab45d6
            var DuplicateResponse = null;
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fispones", "?$select=dobnyc_fisponeid&$filter=_dobnyc_fisp1_regardingtr6_value eq " + tr6Guid + " and dobnyc_fisp1_ispossibleduplicate eq true and dobnyc_fisp1_isinactive eq false and dobnyc_fisponeid ne " + fisp1Guid, function (result) {
                DuplicateResponse = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

            if (DuplicateResponse.length > 0) {                
                fetchXml = "<?xml version='1.0'?>";
                fetchXml += "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                fetchXml += "<entity name='dobnyc_fispone'>";
                fetchXml += " <attribute name='dobnyc_name'/>";
                fetchXml += " <attribute name='createdon'/>";
                fetchXml += " <attribute name='dobnyc_fisponeid'/>";
                fetchXml += "<attribute name='dobnyc_fisp1_qewi'/>";
                fetchXml += "<attribute name='dobnyc_fisp1_owner'/>";
                fetchXml += "<attribute name='dobnyc_fisp1_currentfilingstatus'/>";
                fetchXml += "<attribute name='dobnyc_fisp1_issubmitted'/>";
                fetchXml += "<attribute name='dobnyc_fisp1_regardingtr6'/>";
                fetchXml += "  <attribute name='dobnyc_f1_requeststatus'/>";
                fetchXml += " <order descending='false' attribute='dobnyc_name'/>";
                fetchXml += " <filter type='and'>";
                fetchXml += " <condition attribute='dobnyc_fisp1_isinactive' value='0' operator='eq'/>";
                fetchXml += "  <condition attribute='dobnyc_f1_requeststatus' operator='in'>";
                fetchXml += "  <value>2</value><value>4</value><value>3</value>";
                fetchXml += "</condition>";
                fetchXml += "<condition attribute='dobnyc_fisp1_regardingtr6' value='" + tr6Guid + "' operator='eq' uitype='dobnyc_tr6'/>";
                fetchXml += "</filter></entity></fetch>";

                if (DOB.Dynamics365.IsUCI()) {
                                
                }
                else {
                    setTimeout(function () {
                        var ConnectionSubgrid = executionContext.getControl("FISP1Duplicates");
                        ConnectionSubgrid.getGrid().setParameter("fetchXml", fetchXml);
                        ConnectionSubgrid.refresh();
                    }, 3000);                    
                }

                if (DuplicateResponse.length >= 1) {
                    toggleSection("FT_General", "FT_General_FISP1Duplicates", true);

                }
                else {
                    toggleSection("FT_General", "FT_General_FISP1Duplicates", false);
                }
            }
            else {
                toggleSection("FT_General", "FT_General_FISP1Duplicates", false);
            }
        }
    }
    //fisp2 Section
    if ((executionContext.getAttribute("dobnyc_ft_isfisptwo").getValue())) {
        var fisp2Guid = getLookupId("regardingobjectid");
        fisp2Guid = fisp2Guid.replace("{", "").replace("}", "");
        //var parentTr6Response = retrieveMultipleCustom("dobnyc_fisptwoSet", "?$select=dobnyc_FISP2_RegardingTR6&$filter=dobnyc_fisptwoId eq (guid'" + fisp2Guid + "')&$top=1");
        var parentTr6Response = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fisptwos", "?$select=_dobnyc_fisp2_regardingtr6_value&$filter=dobnyc_fisptwoid eq " + fisp2Guid, function (result) {
            parentTr6Response = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        var tr6Guid = parentTr6Response[0]["_dobnyc_fisp2_regardingtr6_value"];
        //var DuplicateResponse = retrieveMultipleCustom("dobnyc_fisptwoSet", "?$select=dobnyc_fisptwoId&$filter=dobnyc_FISP2_RegardingTR6/Id eq (guid'" + tr6Guid + "') and dobnyc_fisp2_ispossibleduplicate eq true and dobnyc_fisp2_IsInactive eq false and dobnyc_fisptwoId ne (guid'" + fisp2Guid + "')");
        var DuplicateResponse = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_fisptwos", "?$select=dobnyc_fisptwoid&$filter=_dobnyc_fisp2_regardingtr6_value eq " + tr6Guid + " and dobnyc_fisp2_ispossibleduplicate eq true and dobnyc_fisp2_isinactive eq false and dobnyc_fisptwoid ne " + fisp2Guid, function (result) {
            DuplicateResponse = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        if (DuplicateResponse.length > 0) {
            fetchXml = "<?xml version='1.0'?>";
            fetchXml += "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            fetchXml += "<entity name='dobnyc_fisptwo'>";
            fetchXml += " <attribute name='dobnyc_name'/>";
            fetchXml += " <attribute name='createdon'/>";
            fetchXml += "  <attribute name='dobnyc_fisptwoid'/>";
            fetchXml += "  <attribute name='dobnyc_fisp2_qewi'/>";
            fetchXml += "<attribute name='dobnyc_fisp2_currentfilingstatus'/>";
            fetchXml += "<attribute name='dobnyc_fisp2_currentfilingstatus'/>";
            fetchXml += "<attribute name='dobnyc_fisp2_issubmitted'/>";
            fetchXml += "<attribute name='dobnyc_fisp2_regardingtr6'/>";
            fetchXml += " <attribute name='dobnyc_fisp2_requeststatus'/>";
            fetchXml += " <order descending='false' attribute='dobnyc_name'/>";
            fetchXml += " <filter type='and'>";
            fetchXml += " <condition attribute='dobnyc_fisp2_isinactive' value='0' operator='eq'/>";
            fetchXml += "<condition attribute='dobnyc_fisp2_requeststatus' operator='in'>";
            fetchXml += "  <value>2</value><value>6</value><value>3</value>";
            fetchXml += "</condition>";
            fetchXml += "<condition attribute='dobnyc_fisp2_regardingtr6' value='" + tr6Guid + "' operator='eq' uitype='dobnyc_tr6'/>"
            fetchXml += "</filter></entity></fetch>";

            if (DOB.Dynamics365.IsUCI()) {

            }
            else {
                setTimeout(function () {
                    var ConnectionSubgrid = executionContext.getControl("FISP2Duplicates");
                    ConnectionSubgrid.getGrid().setParameter("fetchXml", fetchXml);
                    ConnectionSubgrid.refresh();
                }, 3000);
            }

            if (DuplicateResponse.length >= 1) {
                toggleSection("FT_General", "FT_General_FISP2Duplicates", true);

            }
            else {
                toggleSection("FT_General", "FT_General_FISP2Duplicates", false);
            }
        }
        else {
            toggleSection("FT_General", "FT_General_FISP2Duplicates", false);
        }
    }
    //HV Section
    if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
        var hvGuid = getLookupId("regardingobjectid");
        hvGuid = hvGuid.replace("{", "").replace("}", "");

        //var ControlNumberResponse = retrieveMultipleCustom("dobnyc_heightverificationSet", "?$select=dobnyc_HV_ControlNumber&$filter=dobnyc_heightverificationId eq (guid'" + hvGuid + "')&$top=1");
        var ControlNumberResponse = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_heightverifications", "?$select=_dobnyc_hv_controlnumber_value&$filter=dobnyc_heightverificationid eq " + hvGuid, function (result) {
            ControlNumberResponse = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        var HVControlNumber = ControlNumberResponse[0]["_dobnyc_hv_controlnumber_value"];
        if (HVControlNumber) {
            //var DuplicateHVResponse = retrieveMultipleCustom("dobnyc_heightverificationSet", "?$select=dobnyc_heightverificationId&$filter=dobnyc_HV_ControlNumber/Id eq (guid'" + HVControlNumber + "') and dobnyc_hv_IsPossibleDuplicate eq true and dobnyc_hv_IsInactive eq false and dobnyc_heightverificationId ne (guid'" + hvGuid + "')");
            var DuplicateHVResponse = null;
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_heightverifications", "?$select=dobnyc_heightverificationid&$filter=_dobnyc_hv_controlnumber_value eq " + HVControlNumber + " and dobnyc_hv_ispossibleduplicate eq true and dobnyc_hv_isinactive eq false and dobnyc_heightverificationid ne " + hvGuid, function (result) {
                DuplicateHVResponse = result.value;
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
            if (DuplicateHVResponse.length > 0) {                
                fetchXml = "<?xml version='1.0'?>";
                fetchXml += "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
                fetchXml += " <entity name='dobnyc_heightverification'>";
                fetchXml += " <attribute name='dobnyc_name'/>";
                fetchXml += " <attribute name='createdon'/>";
                fetchXml += " <attribute name='dobnyc_heightverificationid'/>";
                fetchXml += " <attribute name='dobnyc_hv_streetname'/>";
                fetchXml += " <attribute name='dobnyc_hv_qualifiedexteriorwallinspectorqewi'/>";

                fetchXml += " <attribute name='dobnyc_hv_lot'/>";
                fetchXml += " <attribute name='dobnyc_hv_housenos'/>";
                fetchXml += " <attribute name='dobnyc_hv_controlnumber'/>";
                fetchXml += " <attribute name='dobnyc_hv_borough'/>";
                fetchXml += " <attribute name='dobnyc_hv_block'/>";
                fetchXml += " <attribute name='dobnyc_hv_bin'/>";
                fetchXml += " <attribute name='dobnyc_hv_assignedpe'/>";
                fetchXml += " <attribute name='dobnyc_hv_requeststatus'/>";
                fetchXml += " <order descending='false' attribute='dobnyc_name'/>";

                fetchXml += " <filter type='and'>";
                fetchXml += " <condition attribute='dobnyc_hv_isinactive' value='0' operator='eq'/>";
                fetchXml += "<condition attribute='dobnyc_hv_requeststatus' operator='in'>";
                fetchXml += "  <value>2</value><value>4</value><value>3</value><value>5</value><value>9</value>";
                fetchXml += "</condition>";
                fetchXml += "<condition attribute='dobnyc_hv_controlnumber' value='" + HVControlNumber + "' operator='eq' uitype='dobnyc_controlnumber'/>"
                fetchXml += "</filter></entity></fetch>";

                if (DOB.Dynamics365.IsUCI()) {

                }
                else {
                    setTimeout(function () {
                        var ConnectionSubgrid = executionContext.getControl("HVDuplicates");
                        ConnectionSubgrid.getGrid().setParameter("fetchXml", fetchXml);
                        ConnectionSubgrid.refresh();
                    }, 3000);
                }

                if (DuplicateHVResponse.length >= 1) {
                    toggleSection("FT_General", "FT_General_HVDuplicates", true);

                }
                else {
                    toggleSection("FT_General", "FT_General_HVDuplicates", false);
                }
            }
            else {
                toggleSection("FT_General", "FT_General_HVDuplicates", false);
            }
        }
        else {
            toggleSection("FT_General", "FT_General_HVDuplicates", false);
        }
    }
    //PSR section
    if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
        var psrGuid = getLookupId("regardingobjectid");
        psrGuid = psrGuid.replace("{", "").replace("}", "");

        //var ControlNumberResponse = retrieveMultipleCustom("dobnyc_partialshedremovalSet", "?$select=dobnyc_PSR_ControlNumber&$filter=dobnyc_partialshedremovalId eq (guid'" + psrGuid + "')&$top=1");
        var ControlNumberResponse = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_partialshedremovals", "?$select=_dobnyc_psr_controlnumber_value&$filter=dobnyc_partialshedremovalid eq " + psrGuid, function (result) {
            ControlNumberResponse = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        var PSRControlNumber = ControlNumberResponse[0]["_dobnyc_psr_controlnumber_value"];
        //var DuplicatePSRResponse = retrieveMultipleCustom("dobnyc_partialshedremovalSet", "?$select=dobnyc_partialshedremovalId&$filter=dobnyc_PSR_ControlNumber/Id eq (guid'" + PSRControlNumber + "') and dobnyc_psr_ispossibleduplicate eq true and dobnyc_psr_IsInactive eq false and dobnyc_partialshedremovalId ne (guid'" + psrGuid + "')");
        var DuplicatePSRResponse = null;
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_partialshedremovals", "?$select=dobnyc_partialshedremovalid&$filter=_dobnyc_psr_controlnumber_value eq " + PSRControlNumber + " and dobnyc_psr_ispossibleduplicate eq true and dobnyc_psr_isinactive eq false and dobnyc_partialshedremovalid ne " + psrGuid, function (result) {
            DuplicatePSRResponse = result.value;
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        if (DuplicatePSRResponse.length > 0) {            
            fetchXml = "<?xml version='1.0'?>";
            fetchXml += "<fetch distinct='false' mapping='logical' output-format='xml-platform' version='1.0'>";
            fetchXml += " <entity name='dobnyc_partialshedremoval'>";
            fetchXml += " <attribute name='dobnyc_name'/>";
            fetchXml += " <attribute name='createdon'/>";
            fetchXml += " <attribute name='dobnyc_partialshedremovalid'/>";
            fetchXml += " <attribute name='dobnyc_psr_streetname'/>";
            fetchXml += " <attribute name='dobnyc_psr_qualifiedexteriorwallinspectorqewi'/>";
            fetchXml += " <attribute name='dobnyc_psr_lot'/>";
            fetchXml += " <attribute name='dobnyc_psr_currentfilingstatus'/>";
            fetchXml += " <attribute name='dobnyc_psr_controlnumber'/>";
            fetchXml += " <attribute name='dobnyc_psr_borough'/>";
            fetchXml += " <attribute name='dobnyc_psr_block'/>";
            fetchXml += " <attribute name='dobnyc_psr_bin'/>";
            fetchXml += " <attribute name='dobnyc_psr_assignedpe'/>";
            fetchXml += " <attribute name='dobnyc_psr_requeststatus'/>";
            fetchXml += " <order descending='false' attribute='dobnyc_name'/>";

            fetchXml += " <filter type='and'>";
            fetchXml += " <condition attribute='dobnyc_psr_isinactive' value='0' operator='eq'/>";
            fetchXml += "<condition attribute='dobnyc_psr_requeststatus' operator='in'>";
            fetchXml += "  <value>2</value><value>4</value><value>3</value><value>5</value><value>9</value> ";
            fetchXml += "</condition>";
            fetchXml += " <condition attribute='dobnyc_psr_controlnumber' value='" + PSRControlNumber + "' uitype='dobnyc_controlnumber' operator='eq'/>";
            fetchXml += "</filter></entity></fetch>";
            if (DOB.Dynamics365.IsUCI()) {

            }
            else {
                setTimeout(function () {
                    var ConnectionSubgrid = executionContext.getControl("PSRDuplicates");
                    ConnectionSubgrid.getGrid().setParameter("fetchXml", fetchXml);
                    ConnectionSubgrid.refresh();
                }, 3000);
            }
            if (DuplicatePSRResponse.length >= 1) {
                toggleSection("FT_General", "FT_General_PSRDuplicates", true);

            }
            else {
                toggleSection("FT_General", "FT_General_PSRDuplicates", false);
            }
        }
        else {
            toggleSection("FT_General", "FT_General_PSRDuplicates", false);
        }
    }
}

function toggleSection(tabName, sectionName, flag) {
    executionContext.ui.tabs.get(tabName).sections.get(sectionName).setVisible(flag);
}

function getLookupId(attributeName) {

    lookupObject = executionContext.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = executionContext.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}
