function filingdatehideshow() {

    var filingStatusOptionset = {
        Safe: 1,
        Swarmp: 2,
        Unsafe: 3,
        NRF: 4

    };
    var currentstatus = executionContext.getAttribute("dobnyc_cn_filingstatus").getValue();

    if (currentstatus == filingStatusOptionset.NRF || !currentstatus) {
        executionContext.getControl("dobnyc_cn_effectivefilingdate").setVisible(false);
        executionContext.getControl("dobnyc_cn_initialfilingdate").setVisible(true);
    }
    else {
        executionContext.getControl("dobnyc_cn_effectivefilingdate").setVisible(true);
        executionContext.getControl("dobnyc_cn_initialfilingdate").setVisible(false);
    }
}