function currentTask() {
//debugger;
    var entityName = executionContext.data.entity.getEntityName();
    var requestStatus = "";
    var tr6Optionset = {
        PreFiling: 1,
        Accepted: 6,
        Rejected: 7,
        DuplicateRejected: 8,
        IncompleteSubmission: 5

    };

    var fisp1Optionset = {
        PreFiling: 1,
        Granted: 5,
        Denied: 6,
        DuplicateRejected: 8,
        IncompleteSubmission: 4

    };
    var fisp2Optionset = {
        PreFiling: 1,
        Granted: 4,
        Denied: 5,
        DuplicateRejected: 8,
        IncompleteSubmission: 6

    };
    var fisp3Optionset = {
        PreFiling: 1,
        NoAction: 6,
        Viokations: 5,
        DuplicateRejected: 8,
        IncompleteSubmission: 4

    };
    var psrOptionset = {
        PreFiling: 1,
        Accepted: 6,
        Rejected: 7,
        DuplicateRejected: 8,
        IncompleteSubmission: 5

    };
    var HVOptionset = {
        PreFiling: 1,
        Morethansix: 6,
        lessthansix: 7,
        DuplicateRejected: 8,
        IncompleteSubmission: 4

    };
    var CNROptionset = {
        PreFiling: 1,
        Generated: 3,
        Notrequired: 4,

        IncompleteSubmission: 5

    };
    var SCROptionset = {
        PreFiling: 1,
        Approved: 4,
        Rejected: 5,

        IncompleteSubmission: 3

    };
    var SCOOptionset = {
        PreFiling: 1,
        Approved: 4,
        Rejected: 5,

        IncompleteSubmission: 3

    };

    if (entityName) {
        //tr6
        if (entityName == "dobnyc_tr6") {

            requestStatus = executionContext.getAttribute("dobnyc_tr6_reportstatus").getValue();
            if (requestStatus) {
                if (requestStatus == tr6Optionset.PreFiling || requestStatus == tr6Optionset.Accepted || requestStatus == tr6Optionset.Rejected || requestStatus == tr6Optionset.DuplicateRejected || requestStatus == tr6Optionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_tr6_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_tr6_currenttask").setVisible(true);
                }
            }

        }
        //fisp1

        if (entityName == "dobnyc_fispone") {
            requestStatus = executionContext.getAttribute("dobnyc_f1_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == fisp1Optionset.PreFiling || requestStatus == fisp1Optionset.Granted || requestStatus == fisp1Optionset.Denied || requestStatus == fisp1Optionset.DuplicateRejected || requestStatus == fisp1Optionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_fisp1_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_fisp1_currenttask").setVisible(true);
                }
            }

        }
        //fisp2
        if (entityName == "dobnyc_fisptwo") {
            requestStatus = executionContext.getAttribute("dobnyc_fisp2_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == fisp2Optionset.PreFiling || requestStatus == fisp2Optionset.Granted || requestStatus == fisp2Optionset.Denied || requestStatus == fisp2Optionset.DuplicateRejected || requestStatus == fisp2Optionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_fisp2_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_fisp2_currenttask").setVisible(true);
                }
            }

        }
        //fisp3
        if (entityName == "dobnyc_fispthree") {
            requestStatus = executionContext.getAttribute("dobnyc_fisp3_notificationstatus").getValue();
            if (requestStatus) {
                if (requestStatus == fisp3Optionset.PreFiling || requestStatus == fisp3Optionset.Viokations || requestStatus == fisp3Optionset.NoAction || requestStatus == fisp3Optionset.DuplicateRejected || requestStatus == fisp3Optionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_fisp3_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_fisp3_currenttask").setVisible(true);
                }
            }

        }
        //psr
        if (entityName == "dobnyc_partialshedremoval") {
            requestStatus = executionContext.getAttribute("dobnyc_psr_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == psrOptionset.PreFiling || requestStatus == psrOptionset.Accepted || requestStatus == psrOptionset.Rejected || requestStatus == psrOptionset.DuplicateRejected || requestStatus == psrOptionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_psr_currenttask").setVisible(false);

                }
                else {
                    executionContext.getControl("dobnyc_psr_currenttask").setVisible(true);

                }
            }

        }
        //Hv
        if (entityName == "dobnyc_heightverification") {
            requestStatus = executionContext.getAttribute("dobnyc_hv_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == HVOptionset.PreFiling || requestStatus == HVOptionset.Morethansix || requestStatus == HVOptionset.lessthansix || requestStatus == HVOptionset.DuplicateRejected || requestStatus == HVOptionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_hv_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_hv_currenttask").setVisible(true);
                }
            }

        }
        //CNR
        if (entityName == "dobnyc_controlnumberrequest") {
            requestStatus = executionContext.getAttribute("dobnyc_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == CNROptionset.PreFiling || requestStatus == CNROptionset.Generated || requestStatus == CNROptionset.Notrequired || requestStatus == CNROptionset.IncompleteSubmission) {

                    executionContext.getControl("dobnyc_cnr_currenttask").setVisible(false);
                }
                else {
                    executionContext.getControl("dobnyc_cnr_currenttask").setVisible(true);

                }
            }

        }
        //SCR
        if (entityName == "dobnyc_subcyclereassignmentrequest") {
            requestStatus = executionContext.getAttribute("dobnyc_requeststatus").getValue();
            if (requestStatus) {
                if (requestStatus == SCROptionset.PreFiling || requestStatus == SCROptionset.Approved || requestStatus == SCROptionset.Rejected || requestStatus == SCROptionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_scr_currenttask").setVisible(false);

                }
                else {
                    executionContext.getControl("dobnyc_scr_currenttask").setVisible(true);

                }
            }

        }
        //SCo
        if (entityName == "dobnyc_subcycleoverride") {
            requestStatus = executionContext.getAttribute("dobnyc_sor_reportstatus").getValue();
            if (requestStatus) {
                if (requestStatus == SCOOptionset.PreFiling || requestStatus == SCOOptionset.Approved || requestStatus == SCOOptionset.Rejected || requestStatus == SCOOptionset.IncompleteSubmission) {
                    executionContext.getControl("dobnyc_sor_currenttask").setVisible(false);

                }
                else {
                    executionContext.getControl("dobnyc_sor_currenttask").setVisible(true);

                }
            }

        }

    }

}


function HighlightField() {    
    var filingStatus = executionContext.getAttribute("dobnyc_fisp3_notificationstatus").getValue();
    if (filingStatus) {
        if (DOB.Dynamics365.IsUCI()) {
            if ($("[data-id*='dobnyc_fisp3_notificationstatus']", parent.document).length == 0) {
                setTimeout(HighlightField, 2000);
                return;
            }
            if (filingStatus == 5) {                
                $("[data-id*='dobnyc_fisp3_notificationstatus']", parent.document).css("background-color", "red");
            }
            else {
                $("[data-id*='dobnyc_fisp3_notificationstatus']", parent.document).css("background-color", "");
            }
        }
        else {
            if (filingStatus == 5) {
                parent.document.getElementById("dobnyc_fisp3_notificationstatus").style.color = "red";
                parent.document.getElementById("dobnyc_fisp3_notificationstatus").style.backgroundColor = "red";
            }
            else {
                parent.document.getElementById("dobnyc_fisp3_notificationstatus").style.color = "";
                parent.document.getElementById("dobnyc_fisp3_notificationstatus").style.backgroundColor = "";
            }
        }
    }


}

