function ShowTaskSubCycleEndDateWarning() {
    var scR = executionContext.getAttribute("dobnyc_clickheretogosubcyclereassignmentrequest").getValue();
    if (scR != null && scR[0].id != null) {
        GetAllRequestedControlNumbers(scR[0].id);
    }

}



function ShowSubCycleEndDateWarning() {
    if (executionContext.ui.getFormType() != 1) {
        GetAllRequestedControlNumbers(null);
    }
}

function GetAllRequestedControlNumbers(recGuid) {
    var currentGuid;
    if (recGuid == null) {
        currentGuid = executionContext.data.entity.getId();
    }
    else {
        currentGuid = recGuid;
    }

    //SDK.JQuery.retrieveMultipleRecords(
    //    "dobnyc_subcyclereassignmentandcontrolnumbers",
    //    "?$select=dobnyc_dobnyc_controlnumber_dobnyc_subcyclereassignmentandcontrolnumbers_src_ControlNumber/dobnyc_cn_subcycle&$expand=dobnyc_dobnyc_controlnumber_dobnyc_subcyclereassignmentandcontrolnumbers_src_ControlNumber&$filter=dobnyc_src_Request/Id eq (guid'" + currentGuid + "')",
    //    function (results) {
    //        var distinctSubCycle = [];
    //        for (var i = 0; i < results.length; i++) {
    //            var subCycle = results[i].dobnyc_dobnyc_controlnumber_dobnyc_subcyclereassignmentandcontrolnumbers_src_ControlNumber.dobnyc_cn_subcycle;

    //            if (distinctSubCycle.indexOf(subCycle) == -1) {
    //                distinctSubCycle.push(subCycle);
    //            }
    //        }

    //        FindLeastSubcycleEndDate(distinctSubCycle);
    //    },
    //    function (error) {
    //        alert(error.message);
    //    },
    //    function () {
    //        //On Complete - Do Something
    //    }
    //);

    currentGuid = currentGuid.replace("{", "").replace("}", "");

    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_subcyclereassignmentandcontrolnumberses", "?$select=_dobnyc_src_controlnumber_value&$expand=dobnyc_src_controlnumber($select=_dobnyc_cn_subcycle_value)&$filter=_dobnyc_src_request_value eq " + currentGuid, function (result) {
        var distinctSubCycle = [];
        for (var i = 0; i < result.value.length; i++) {
            var subCycle = result.value[i].dobnyc_src_controlnumber["_dobnyc_cn_subcycle_value@OData.Community.Display.V1.FormattedValue"];

            if (distinctSubCycle.indexOf(subCycle) == -1) {
                distinctSubCycle.push(subCycle);
            }
        }

        FindLeastSubcycleEndDate(distinctSubCycle);
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
}


function FindLeastSubcycleEndDate(subCycleList) {

    var lowestDate = null;

    for (var i = 0; i < subCycleList.length; i++) {
        var subCycle = subCycleList[i];
        //SDK.JQuery.retrieveMultipleRecords(
        //    "dobnyc_facadessubcycle",
        //    "?$select=dobnyc_fsc_EndDate&$filter=dobnyc_name eq '" + subCycle.Name + "'",
        //    function (results) {
        //        for (var i = 0; i < results.length; i++) {
        //            var dobnyc_fsc_EndDate = results[i].dobnyc_fsc_EndDate;
        //            if (lowestDate == null) {
        //                lowestDate = dobnyc_fsc_EndDate;
        //            }
        //            else if (lowestDate > dobnyc_fsc_EndDate) {
        //                lowestDate = dobnyc_fsc_EndDate;
        //            }
        //        }
        //    },
        //    function (error) {
        //        alert(error.message);
        //    },
        //    function () {
        //        //On Complete - Do Something
        //    }
        //);

        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadessubcycles", "?$select=dobnyc_fsc_enddate&$filter=dobnyc_name eq '" + subCycle + "'", function (result) {
            for (var i = 0; i < result.value.length; i++) {
                var dobnyc_fsc_EndDate = result.value[i].dobnyc_fsc_enddate;
                if (lowestDate == null) {
                    lowestDate = dobnyc_fsc_EndDate;
                }
                else if (lowestDate > dobnyc_fsc_EndDate) {
                    lowestDate = dobnyc_fsc_EndDate;
                }
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
    }
    todaysDate = new Date();

    if (lowestDate != null) {
        var daysInBetween = null;
        if (lowestDate > todaysDate) {
            daysInBetween = (lowestDate - todaysDate) / (1000 * 60 * 60 * 24);
        }
        else {
            daysInBetween = (todaysDate - lowestDate) / (1000 * 60 * 60 * 24);
        }

        if (daysInBetween < 180) {
            executionContext.ui.setFormNotification("Atleast one of the Control Numbers have Sub-Cycle End Date within 180 days. ", "ERROR");
        }
    }
}
