//var taskId = executionContext.data.entity.getId();
var Regardings = [
    { FlagField: "dobnyc_ft_istr6", IdField: "dobnyc_ft_gototr6", EntityName: "dobnyc_tr6", IsDupField: "dobnyc_tr6_ispossibleduplicate", RequestStatusField: "dobnyc_tr6_reportstatus" },
    { FlagField: "dobnyc_ft_isfispone", IdField: "dobnyc_ft_gotofispone", EntityName: "dobnyc_fispone", IsDupField: "dobnyc_fisp1_ispossibleduplicate", RequestStatusField: "dobnyc_f1_requeststatus" },
    { FlagField: "dobnyc_ft_isfisptwo", IdField: "dobnyc_ft_gotofisptwo", EntityName: "dobnyc_fisptwo", IsDupField: "dobnyc_fisp2_ispossibleduplicate", RequestStatusField: "dobnyc_fisp2_requeststatus" },
    { FlagField: "dobnyc_ft_isheightverification", IdField: "dobnyc_ft_gotoheightverification", EntityName: "dobnyc_heightverification", IsDupField: "dobnyc_hv_ispossibleduplicate", RequestStatusField: "dobnyc_hv_requeststatus" },
    { FlagField: "dobnyc_ft_ispartialshedremoval", IdField: "dobnyc_ft_gotopartialshedremoval", EntityName: "dobnyc_partialshedremoval", IsDupField: "dobnyc_psr_ispossibleduplicate", RequestStatusField: "dobnyc_psr_requeststatus" },
];

var cnrAdminActions = {
    IncompleteSubmission: 1,
    ControlNumberGenerated: 2,
    ControlNumberNotRequired: 3
};
function LdCSS() {

    //var path = "/WebResources/dobnyc_custom";
    //var head = document.getElementsByTagName('head')[0];
    //var link = document.createElement('link');
    //link.rel = 'stylesheet';
    //link.type = 'text/css';
    //link.href = path;
    //link.media = 'all';
    //head.appendChild(link);
}
function FacadeFormValidations() {
    //debugger;
    AdminReviewSectionEnableDisable();
    PlanningReviewSectionEnableDisable();
    InspectionSectionEnableDisable();
    PEInspectionSectionEnableDisable();
    PlanExaminerSupervisorReview();



    //ribbon refresh for enable/disable mark complete 
    executionContext.ui.refreshRibbon();
    //notification bar if is duplicate
    if (!IsPossibleDuplicate()) {
        executionContext.ui.setFormNotification("This Facades Task Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
    }
    if (!IsNoGoodCheckOnHold()) {
        executionContext.ui.setFormNotification("This Facades Task Record is related to an Check Bounce. Workflows have been temporarily suspended for this record.", "WARNING");
    }
    //  ControlNumberGenerationTaskOnLoad();
    // HeightVerificationTaskOnLoad();




}

function IsPossibleDuplicate() {
    //Initialize
    var FispValue = "Yes";
    var EnableMarkComp = true;

    //find the regarding record type 
    for (var i = 0; i < Regardings.length; i++) {
        if (executionContext.getAttribute(Regardings[i].FlagField).getValue()) {
            var RegardingEntityName = Regardings[i].EntityName;
            var RegardingId = executionContext.getAttribute(Regardings[i].IdField).getValue()[0].id;
            var IsDuplicateField = Regardings[i].IsDupField;
            // retrieve regarding record
            //XrmServiceToolkit.Rest.Retrieve(
            //       RegardingId,
            //       RegardingEntityName + "Set",
            //       null, null,
            //       function (retrievedRecord) {
            //           EnableMarkComp = !retrievedRecord[IsDuplicateField];
            //       },
            //       function (error) {
            //           equal(true, false, error.message);
            //       },
            //       false
            //);
            RegardingId = RegardingId.replace("{", "").replace("}", "");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, RegardingEntityName + "s", "?$filter=" + RegardingEntityName + "id" + " eq " + RegardingId, function (result) {
                if (result.value.length > 0) {
                    EnableMarkComp = !result.value[0][IsDuplicateField];
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        }
    }
    //return true/false to enable/disable mark complete ribbon button

    return EnableMarkComp;
}


function IsNoGoodCheckOnHold() {
    //Initialize
    var FispValue = "Yes";
    var EnableMarkComp = true;
    //find the regarding record type 

    for (var i = 0; i < Regardings.length; i++) {
        if (executionContext.getAttribute(Regardings[i].FlagField).getValue() == FispValue) {
            if (Regardings[i].FlagField == "dobnyc_ft_isheightverification" || Regardings[i].FlagField == "dobnyc_ft_ispartialshedremoval")
                continue;
            var RegardingEntityName = Regardings[i].EntityName;
            var RegardingId = executionContext.getAttribute(Regardings[i].IdField).getValue()[0].id;
            var StatusField = Regardings[i].RequestStatusField;
            // retrieve regarding record
            //XrmServiceToolkit.Rest.Retrieve(
            //       RegardingId,
            //       RegardingEntityName + "Set",
            //       null, null,
            //       function (retrievedRecord) {
            //           if (retrievedRecord[StatusField].Value == 9)//No Good Check on hold status
            //               EnableMarkComp = false;
            //       },
            //       function (error) {
            //           equal(true, false, error.message);
            //       },
            //       false
            //   );
            RegardingId = RegardingId.replace("{", "").replace("}", "");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, RegardingEntityName + "s", "?$filter=" + RegardingEntityName + "id" + " eq " + RegardingId, function (result) {
                if (result.value.length > 0) {
                    if (result.value[0][StatusField].Value == 9)//No Good Check on hold status
                        EnableMarkComp = false;
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        }
    }
    //return true/false to enable/disable mark complete ribbon button
    return EnableMarkComp;
}



function PlanExaminerSupervisorReview() {
    var formLableIs = "Plan Examiner Supervisor Form";
    var Taskform = executionContext.ui.getFormType();
    var form = executionContext.ui.formSelector.getCurrentItem();
    var formId = form.getId();
    var formLabel = form.getLabel();
    var isAdminiReview = "Administrative Review";
    if (formLabel == formLableIs) {
        var FispValue = "Yes";
        //HV Section
        if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Height_Verification_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_HVDuplicates").setVisible(true);
            executionContext.getControl("dobnyc_ft_inspectioncomments").setVisible(true);
            if (executionContext.getAttribute("dobnyc_ft_administrativereviewno").getText() == "2") {
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                executionContext.getControl("dobnyc_ft_hvassignedpe").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_hvassignedpe").setRequiredLevel("required");

            }

        }
        if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
            // var peno = executionContext.getAttribute("dobnyc_pesupervisorreviewno").getText();
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_PSRDuplicates").setVisible(true);

            executionContext.ui.tabs.get("FT_General").sections.get("FT_PartialSchRem_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            if (executionContext.getAttribute("dobnyc_pesupervisorreviewno").getText() == "1" ||
                executionContext.getAttribute("dobnyc_pesupervisorreviewno").getText() == null) {

                executionContext.getControl("dobnyc_pesupervisorreviewactions").setVisible(true);
                executionContext.getAttribute("dobnyc_pesupervisorreviewactions").setRequiredLevel("required");
                if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getValue() == 3) {
                    executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
                }
            }
            if (executionContext.getAttribute("dobnyc_pesupervisorreviewno").getText() == "2") {

                //if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getValue() == 3) {
                executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
                //}
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                //executionContext.getControl("dobnyc_ft_inspectioncomments").setVisible(true);
            }
        }
    }
}

function onChangePlanExaminerSupervisorReview2() {
    //debugger;
    if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getValue() == 3) {
        executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
    }
}

function AdminReviewSectionEnableDisable() {
    var formLableIs = "Administrative Review Form";
    var Taskform = executionContext.ui.getFormType();
    var form = executionContext.ui.formSelector.getCurrentItem();
    var formId = form.getId();
    var formLabel = form.getLabel();
    var isAdminiReview = "Administrative Review";


    if (formLabel == formLableIs) {
        var FispValue = "Yes";
        //FISP1 Section
        if (executionContext.getAttribute("dobnyc_ft_isfispone").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP1_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_FISP1Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);
            executionContext.getControl("dobnyc_fisp1isincompletesubmission").setVisible(true);
            if (executionContext.getAttribute("dobnyc_fisp1isincompletesubmission").getValue() == false) {
                executionContext.getControl("dobnyc_assignfisp1toplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_assignfisp1toplanexaminer").setRequiredLevel("required");
            }
        }
        //SCO Added by Vinay
        else if (executionContext.getAttribute("dobnyc_ft_issco").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_SCO").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            // executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);
            executionContext.getControl("dobnyc_scoadminreviewactions").setVisible(true);
            executionContext.getAttribute("dobnyc_scoadminreviewactions").setRequiredLevel("required");
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(false);
        }
        else if (executionContext.getAttribute("dobnyc_ft_isfisptwo").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_FISP2Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP2_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);
            executionContext.getControl("dobnyc_ft_fisp2isincompletesubmission").setVisible(true);
            if (executionContext.getAttribute("dobnyc_ft_fisp2isincompletesubmission") == false) {
                executionContext.getControl("dobnyc_ft_assignfisp2toplanningexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_assignfisp2toplanningexaminer").setRequiredLevel("required");
            }
        }

        else if (executionContext.getAttribute("dobnyc_ft_isfispthree").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP3_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);

            if (executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == "1" ||
                executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == null) {
                executionContext.getControl("dobnyc_ft_fisp3adminreviewaction").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_fisp3adminreviewaction").setRequiredLevel("required");
            }
            else if (executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == "2") {
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                executionContext.getControl("dobnyc_fisp3reviewactions").setVisible(true);
                executionContext.getAttribute("dobnyc_fisp3reviewactions").setRequiredLevel("required");
            }
        }

        //Control Number Request Admin Review

        else if (executionContext.getAttribute("dobnyc_iscontrolnumberrequest").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_13").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_controlnumberrequestactions").setVisible(true);

            executionContext.getAttribute("dobnyc_controlnumberrequestactions").setRequiredLevel("required");

            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);
            //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            CSRAdminReview();


        }

        //Sub Cycle Reassignment Request

        else if (executionContext.getAttribute("dobnyc_issubcyclereassignmentrequest").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_Sub_Cycle_Reassignment").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_subcyclereassignmentadminactions").setVisible(true);
            executionContext.getAttribute("dobnyc_subcyclereassignmentadminactions").setRequiredLevel("required");
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(false);
            //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");


        }

        else if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Height_Verification_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_HVDuplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);

            if (executionContext.getAttribute("dobnyc_ft_administrativereviewno").getText() == "1" ||
                executionContext.getAttribute("dobnyc_ft_administrativereviewno").getText() == null) {

                executionContext.getControl("dobnyc_hv_reviewactions1").setVisible(true);
                executionContext.getAttribute("dobnyc_hv_reviewactions1").setRequiredLevel("required");
            }

            else if (executionContext.getAttribute("dobnyc_ft_administrativereviewno").getText() == "3") {

                executionContext.getControl("dobnyc_hv_adminreviewactions2").setVisible(true);
                executionContext.getAttribute("dobnyc_hv_adminreviewactions2").setRequiredLevel("required");

                //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

            }
            else if (executionContext.getAttribute("dobnyc_ft_administrativereviewno").getText() == "4") {

                executionContext.getControl("dobnyc_ft_hvadminreview4").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_hvadminreview4").setRequiredLevel("required");

                //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

            }
        }

        else if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_PSRDuplicates").setVisible(true);

            executionContext.ui.tabs.get("FT_General").sections.get("FT_PartialSchRem_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);
            executionContext.getControl("dobnyc_ft_psrincompletesubmission").setVisible(true);
            if (executionContext.getAttribute("dobnyc_ft_psrincompletesubmission").getValue() == false) {
                executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
            }
        }

        else if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_TR6Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_TR_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_section_11").setVisible(true);

            var fillingType = executionContext.getAttribute("dobnyc_ft_filingtype").getText();
            var filingStatus = executionContext.getAttribute("dobnyc_ft_filingstatus").getText();
            if (fillingType == "Initial" || fillingType == "Subsequent") {
                if (executionContext.getAttribute("dobnyc_ft_tr6reportstatus").getValue() == 12) {
                    executionContext.getControl("dobnyc_ft_tr6incompletesubmission").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").setRequiredLevel("required");
                    if (executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").getValue() == false) {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                    }
                    else {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                    }

                }
                else {
                    executionContext.getControl("dobnyc_ft_tr6adminreviewactions2").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").setRequiredLevel("required")
                    if (executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").getValue() == 3) {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                    }
                    else {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                        //executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("false");
                        //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                    }
                }
            }
            else if (fillingType == "Amended") {
                var adminReviewNumber = executionContext.getAttribute("dobnyc_ft_rr6amendadminreviewno").getText();
                if (adminReviewNumber == "1") {

                    executionContext.getControl("dobnyc__tr6_amendedadminreviewactions").setVisible(true);
                    executionContext.getAttribute("dobnyc__tr6_amendedadminreviewactions").setRequiredLevel("required");

                }
                else if (adminReviewNumber == "2") {
                    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                    executionContext.getControl("dobnyc_ft_tr6adminreviewactions2").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").setRequiredLevel("required")
                    if (executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").getValue() == 3) {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                    }
                    else {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("false");
                        //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                    }
                }
                else if (adminReviewNumber == "3") {
                    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                    executionContext.getControl("dobnyc_ft_tr6incompletesubmission").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").setRequiredLevel("required");
                    if (executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").getValue() == false) {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                    }
                    else {
                        executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                        executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                    }
                }
            }
            else {
                alert("Filling type not found");
            }
        }

    }
}


function civilPenaltyApplicable() {
    var isCivilPenalty = executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").getValue();
    if (isCivilPenalty) {
        //make visible effective date
        executionContext.getControl("dobnyc_ft_effectivecivilpenaltydate").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setRequiredLevel("required");
    }
    else {
        //hide the effective date and set it to null
        executionContext.getControl("dobnyc_ft_effectivecivilpenaltydate").setVisible(false);
        executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setValue(null);
    }
}
//Planexaminer Inspection Review Sections Eanable Disable


function PEInspectionSectionEnableDisable() {

    var FispValue = "Yes";
    var Taskform = executionContext.getAttribute("dobnyc_ft_taskformfor").getValue();
    var form = executionContext.ui.formSelector.getCurrentItem();
    if (form != null) {
        var formId = form.getId();
        var formLabel = form.getLabel();
    }
    var unsafePEActions = "";
    var safePEActions = "";
    var adminReviewActions = "";
    //Tr6 section
    if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
        var filingType = executionContext.getAttribute("dobnyc_ft_filingtype").getText();
        if (Taskform == 1 && formLabel == "Administrative Review Form" && filingType == "Amended" && filingType != "Initial") {
            if (executionContext.getAttribute("dobnyc__tr6_amendedadminreviewactions").getValue() != null) {
                adminReviewActions = executionContext.getAttribute("dobnyc__tr6_amendedadminreviewactions").getText();
                if (adminReviewActions) {
                    InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions);
                }
                else {
                    clearInspectionTypeReasonSections();


                }

            }



        }
        else if (Taskform == 3 && formLabel == "Plan Examiner Review Form") {
            if (executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").getText() || executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText()) {
                unsafePEActions = executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").getText();
                safePEActions = executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText();
                if (safePEActions || unsafePEActions) {
                    InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions);
                }
                else {
                    clearInspectionTypeReasonSections();

                }

            }


        }

    }
    //FISP3 Section
    else if (executionContext.getAttribute("dobnyc_ft_isfispthree").getValue()) {
        if (Taskform == 1 && formLabel == "Administrative Review Form") {//only Admin review 1 has request inspection
            if (executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == "1" ||
                executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText()) {
                if (executionContext.getAttribute("dobnyc_ft_fisp3adminreviewaction").getText()) {
                    adminReviewActions = executionContext.getAttribute("dobnyc_ft_fisp3adminreviewaction").getText();
                    if (adminReviewActions) {
                        InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions);
                    }
                    else {
                        clearInspectionTypeReasonSections();

                    }

                }



            }

        }

    }
    //HV Section
    else if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
        if (Taskform == 1 && formLabel == "Administrative Review Form") {
            if (executionContext.getAttribute("dobnyc_hv_reviewactions1").getText()) {
                adminReviewActions = executionContext.getAttribute("dobnyc_hv_reviewactions1").getText();
                if (adminReviewActions) {
                    InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions);

                }
                else {
                    clearInspectionTypeReasonSections();

                }

            }


        }
    }
    //PSR Section
    // PEInspectionSectionEnableDisable();
    // PlanExaminerSupervisorReview();


    else if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
        if (formLabel == "Plan Examiner Supervisor Form" && Taskform == 4) {

            if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getValue() == 3) {
                executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
                executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setValue(null);
            }

            if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getValue() != 3) {
                executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("none");
            }

            if (executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getText()) {
                {
                    adminReviewActions = executionContext.getAttribute("dobnyc_pesupervisorreviewactions").getText();
                    if (adminReviewActions) {
                        InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions);

                    }
                    else {
                        clearInspectionTypeReasonSections();

                    }

                }

            }

        }

    }
}
//Taskform,formLabel,unsafePEActions,safePEActions,adminReviewActions
//This function will make Inspection Type and Inspection Reason enable/disable

function clearInspectionTypeReasonSections() {
    sectionObject("FT_General", "FT_General_InspectionType");
    sectionObject("FT_General", "FT_General_InspectionReason");
    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(false);
    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(false);
}
function MakeVisbleInspectionSections() {
    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
    executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
    InspectionReviewTypes();
}

function InspectionTypeandInspectionReasonEnableDisable(Taskform, formLabel, unsafePEActions, safePEActions, adminReviewActions) {

    if (Taskform == 3 && formLabel == "Plan Examiner Review Form") {

        if ((safePEActions == "Request Inspection" || unsafePEActions == "Request Inspection")) {

            MakeVisbleInspectionSections();

        }
        else {
            clearInspectionTypeReasonSections();

        }
    }
    if (Taskform == 1 && formLabel == "Administrative Review Form") {

        if ((adminReviewActions == "Request Inspection") || (adminReviewActions == "Inspection Request")) {

            MakeVisbleInspectionSections();

        }
        else {
            clearInspectionTypeReasonSections();


        }
    }
    if (Taskform == 4 && formLabel == "Plan Examiner Supervisor Form") {
        if ((adminReviewActions == "Request Inspection") || (adminReviewActions == "Inspection Request")) {

            MakeVisbleInspectionSections();

        }
        else {
            clearInspectionTypeReasonSections();


        }
    }



}

//Clear all fields in section

function sectionObject(tabNumber, sectionNumber) {
    var section = executionContext.ui.tabs.get(tabNumber).sections.get(sectionNumber);




    var controls = section.controls.get();
    var controlsLenght = controls.length;
    for (var i = 0; i < controlsLenght; i++) {
        if (controls[i].getControlType() == "webresource") {

        }
        else {
            //alert(controls[i].getControlType());
            controls[i].getAttribute().setValue(null);
        }
        //executionContext.getAttribute("dobnyc_ft_inspectionreasondescription").setRequiredLevel("none");


    }


}

//Tr6 Safe and Unsafe PE Review Actions on Change

function PESafeandUnsafeReviewActions() {
    var unsafePEActions = executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").getText();
    var safePEActions = executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText();
    if (safePEActions == "Request Inspection" || unsafePEActions == "Request Inspection") {
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
        InspectionReviewTypes();

    }
    else {
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(false);
        sectionObject("FT_General", "FT_General_InspectionType");
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(false);
        sectionObject("FT_General", "FT_General_InspectionReason");
    }
}


function PlanningReviewSectionEnableDisable() {

    var formLableIs = "Plan Examiner Review Form";
    var Taskform = executionContext.ui.getFormType();
    var form = executionContext.ui.formSelector.getCurrentItem();
    var formId = form.getId();
    var formLabel = form.getLabel();

    if (formLabel == formLableIs) {
        var FispValue = "Yes";

        if (executionContext.getAttribute("dobnyc_ft_isfispone").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_FISP1Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP1_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_ft_fisp1planningexaminerreview").setVisible(true);
            InitialiseExtentionControls();

            if (executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").getText() == "" ||
                executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").getText() == null) {
                executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").setRequiredLevel("required");
                //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
        }
        else if (executionContext.getAttribute("dobnyc_ft_isfisptwo").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_FISP2Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP2_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_ft_fisp2planexaminerreview").setVisible(true);
            InitialiseExtentionControlsFISP2();

            if (executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").getText() == "" ||
                executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").getText() == null) {
                executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").setRequiredLevel("required");
            }
        }
        else if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_PSRDuplicates").setVisible(true);

            executionContext.ui.tabs.get("FT_General").sections.get("FT_PartialSchRem_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            var reviewNumber = executionContext.getAttribute("dobnyc_ft_planexaminerreviewno").getText();
            if (reviewNumber == "1") {
                executionContext.getControl("dobnyc_ft_psrperequestinspection").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_psrperequestinspection").setRequiredLevel("required");

            }
            else if (reviewNumber == "2") {
                executionContext.getControl("dobnyc_ft_psrplanexaminerreview").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_psrplanexaminerreview").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_inspectioncomments").setVisible(true);
            }
        }
        else if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_HVDuplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Height_Verification_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_ft_inspectioncomments").setVisible(true);
            executionContext.getControl("dobnyc_ft_pe_reviewactions").setVisible(true);
            executionContext.getAttribute("dobnyc_ft_pe_reviewactions").setRequiredLevel("required");
            //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

        }
        else if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_TR6Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_TR_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);

            var fillingType = executionContext.getAttribute("dobnyc_ft_filingtype").getText();
            var filingStatus = executionContext.getAttribute("dobnyc_ft_filingstatus").getText();

            if (fillingType == "Initial" && filingStatus == "UNSAFE") {
                executionContext.getControl("dobnyc_tr6_unsafepereviewactions").setVisible(true);
                executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").setRequiredLevel("required");

            }
            else if (fillingType == "Initial" && (filingStatus == "SAFE" || filingStatus == "SWARMP")) {
                executionContext.getControl("dobnyc_tr6_safepereviewactions").setVisible(true);
                executionContext.getAttribute("dobnyc_tr6_safepereviewactions").setRequiredLevel("required");
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);

            }
            else if (fillingType == "Subsequent") {
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                if (filingStatus == "SAFE" || filingStatus == "SWARMP") {
                    executionContext.getControl("dobnyc_tr6_safepereviewactions").setVisible(true);
                    executionContext.getAttribute("dobnyc_tr6_safepereviewactions").setRequiredLevel("required");


                }

                if (filingStatus == "UNSAFE") {
                    executionContext.getControl("dobnyc_tr6_unsafepereviewactions").setVisible(true);
                    executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").setRequiredLevel("required");
                }


            }
            else if (fillingType == "Amended") {
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionComments").setVisible(true);
                executionContext.getControl("dobnyc_ft_tr6pereviewactions").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6pereviewactions").setRequiredLevel("required");
            }
            else {
                alert("No Filling Type");
            }
        }
    }

}



function InspectionSectionEnableDisable() {
    var formLableIs = "Inspection Form";
    var Taskform = executionContext.ui.getFormType();
    var form = executionContext.ui.formSelector.getCurrentItem();
    var formId = form.getId();
    var formLabel = form.getLabel();

    if (formLabel == formLableIs) {
        var FispValue = "Yes";
        if (executionContext.getAttribute("dobnyc_ft_isfispthree").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_FISP3_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
            executionContext.getControl("dobnyc_ft_comments").setVisible(true);
            executionContext.getControl("dobnyc_ft_fisp3inspectioncomplete").setVisible(true);
            executionContext.getAttribute("dobnyc_ft_fisp3inspectioncomplete").setRequiredLevel("required");
            //executionContext.getControl("dobnyc_ft_comments").setRequiredLevel("required");

        }
        else if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_PSRDuplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_PartialSchRem_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_ft_psrcompleteinspection").setVisible(true);
            executionContext.getControl("dobnyc_ft_psrcompleteinspection").setRequiredLevel("required");
            //executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

        }
        else if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_TR6Duplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_TR_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc__tr6_amendtr6inspectionreviewactions").setVisible(true);
            executionContext.getAttribute("dobnyc__tr6_amendtr6inspectionreviewactions").setRequiredLevel("required");
            executionContext.getControl("dobnyc_ft_comments").setVisible(true);
            //executionContext.getControl("dobnyc_ft_comments").setRequiredLevel("required");

        }
        else if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_HVDuplicates").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);

            executionContext.ui.tabs.get("FT_General").sections.get("FT_Height_Verification_Section").setVisible(true);
            executionContext.ui.tabs.get("FT_General").sections.get("FT_Comments_Section").setVisible(true);
            executionContext.getControl("dobnyc_ft_completeinspection").setVisible(true);
            executionContext.getAttribute("dobnyc_ft_completeinspection").setRequiredLevel("required");
            //executionContext.getControl("dobnyc_ft_comments").setRequiredLevel("required");

        }

    }
}


function checkSecurityRole() {
    var isValidRole;
    var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == "FACADES - Inspector") {
            isValidRole = false;
        }
        else {
            return true;
        }
    }
    return isValidRole;
}

function GetRoleName(RoleId) {
    //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
    //var returnValue = retrieveMultipleCustom("RoleSet", "?select=Name&$filter=RoleId eq guid'" + RoleId + "'");

    RoleId = RoleId.replcae("{", "").replcae("}", "");

    var returnValue = null;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "roles", "?$select=name&$filter=roleid eq " + RoleId, function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
    if (returnValue != null && returnValue[0] != null) {
        // alert("Role name: " + returnValue[0].Name);
        return returnValue[0].name;
    }
}




function AcceptDocument() {
    var isValidRole = checkSecurityRole();
    if (isValidRole) {
        var DocumentURL = executionContext.getAttribute("dobnyc_dl_documenturl").getValue();
        var DocumentViewed = executionContext.getAttribute("dobnyc_isdocumentviewed").getValue();
        /* if (DocumentURL == null) {
             alert("There is no document uploaded to be accepted!");
             return;
         }*/
        if (DocumentViewed) {
            var confirmStrings = { text: "Would you like to accept this document?", title: "Confirmation Dialog" };
            var confirmOptions = { height: 200, width: 450 };
            Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
                function (success) {
                    if (success.confirmed) {
                        executionContext.getAttribute("dobnyc_ft_document_status").setSubmitMode("always");
                        executionContext.getAttribute("dobnyc_ft_document_status").setValue(4);
                        executionContext.data.entity.save();
                    }
                });
        }
        else {
            alert("Please view the Document atleast once before accepting it");
        }

    }
    else {
        alert("insufficient privileges. Please Contact Administrator. ");
    }



}
function RejectDocument() {

    var isValidRole = checkSecurityRole();
    if (isValidRole) {
        var confirmStrings = { text: "Would you like to reject this document?", title: "Confirmation Dialog" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    executionContext.getAttribute("dobnyc_ft_document_status").setSubmitMode("always");
                    executionContext.getAttribute("dobnyc_ft_document_status").setValue(5);
                    executionContext.data.entity.save();
                }
            });
    }
    else {
        alert("insufficient privileges. Please Contact Administrator. ");

    }



}
function ViewDocument() {
    alert("ViewDocument");
    var lookupObject = executionContext.getAttribute("dobnyc_dl_documenturl");
    if (lookupObject != null) {
        var lookUpObjectValue = lookupObject.getValue();
        if ((lookUpObjectValue != null)) {
            var lookuptextvalue = lookUpObjectValue[0].name;
            var lookupid = lookUpObjectValue[0].id;
        }
    }
    alert(lookuptextvalue);
}
function ReplaceDocument() {
    alert("Replace Documents");
}


//Admin Actions
function Fisp1AdminReview() {
    if (executionContext.getAttribute("dobnyc_fisp1isincompletesubmission").getValue() == false) {
        executionContext.getControl("dobnyc_assignfisp1toplanexaminer").setVisible(true);
        executionContext.getAttribute("dobnyc_assignfisp1toplanexaminer").setRequiredLevel("required");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else {
        executionContext.getControl("dobnyc_assignfisp1toplanexaminer").setVisible(false);
        executionContext.getAttribute("dobnyc_assignfisp1toplanexaminer").setValue(null);
        executionContext.getAttribute("dobnyc_assignfisp1toplanexaminer").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
}
function Fisp2AdminReview() {
    if (executionContext.getAttribute("dobnyc_ft_fisp2isincompletesubmission").getValue() == false) {
        executionContext.getControl("dobnyc_ft_assignfisp2toplanningexaminer").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_assignfisp2toplanningexaminer").setRequiredLevel("required");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else {
        executionContext.getControl("dobnyc_ft_assignfisp2toplanningexaminer").setVisible(false);
        executionContext.getAttribute("dobnyc_ft_assignfisp2toplanningexaminer").setValue(null);
        executionContext.getAttribute("dobnyc_ft_assignfisp2toplanningexaminer").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
}
function Fisp3AdminReview() {
    if (executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == "1") {
        executionContext.getControl("dobnyc_ft_fisp3isincompletesubmission").setVisible(true);
        if (executionContext.getAttribute("dobnyc_ft_fisp3isincompletesubmission").getValue() == false) {
            executionContext.getControl("dobnyc_ft_fisp3isinspectionrequest").setVisible(true);
            executionContext.getAttribute("dobnyc_ft_fisp3isinspectionrequest").setRequiredLevel("required");
            if (executionContext.getAttribute("dobnyc_ft_fisp3isinspectionrequest").getValue()) {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
        }
        else {
            executionContext.getControl("dobnyc_ft_fisp3isinspectionrequest").setVisible(false);
            executionContext.getAttribute("dobnyc_ft_fisp3isinspectionrequest").setRequiredLevel("none");
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
    }
    else if (executionContext.getAttribute("dobnyc_ft_fisp3administrativereviewno").getText() == "2") {
        executionContext.getControl("dobnyc_fisp3reviewactions").setVisible(true);
        executionContext.getAttribute("dobnyc_fisp3reviewactions").setRequiredLevel("required");
        if (executionContext.getAttribute("dobnyc_fisp3reviewactions").getText() == "Violations Issued") {
            var documents = AdminDocuments();
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            //alert(ids.length);

            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                if (statusValue != "4") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Please Approve all Documents in Document List");
                executionContext.getAttribute("dobnyc_fisp3reviewactions").setValue(null);
            }

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            var documents = AdminDocuments();
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            //alert(ids.length);

            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                if (statusValue == "1" || statusValue == "2" || statusValue == "3") {
                    isApproved = false;
                }

            }
            if (!isApproved) {
                alert("Please Approve/Reject all documents in the Document List");
                executionContext.getAttribute("dobnyc_fisp3reviewactions").setValue(null);
            }

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
    }
    else {
        alert("Not found fisp3 administrative review no");
    }
}

function TR6AdminReview() {
    var fillingType = executionContext.getAttribute("dobnyc_ft_filingtype").getText();
    if (fillingType != "Amended") {
        sectionObject("FT_General", "FT_General_InspectionType");
        sectionObject("FT_General", "FT_General_InspectionReason");
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(false);
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(false);
        if (executionContext.getAttribute("dobnyc_ft_tr6reportstatus").getValue() == 12) {
            if (executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").getValue() == false) {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setValue(null);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_comments").setFocus();



            }
        }
        else {
            if (executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").getValue() == 3) {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setValue(null);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_comments").setFocus();



            }
        }

    }
    else if (fillingType == "Amended") {
        sectionObject("FT_General", "FT_General_InspectionType");
        sectionObject("FT_General", "FT_General_InspectionReason");
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
        executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);
        var adminReviewNumber = executionContext.getAttribute("dobnyc_ft_rr6amendadminreviewno").getText();
        if (adminReviewNumber == "1") {
            executionContext.getControl("dobnyc_ft_tr6incompletesubmission").setVisible(true);
            if (executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").getValue() == false) {
                executionContext.getControl("dobnyc_ft_tr6isrequestinspection").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6isrequestinspection").setRequiredLevel("required");
                if (executionContext.getAttribute("dobnyc_ft_tr6isrequestinspection").getValue() == false) {
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
                else {
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
            }
            else {
                executionContext.getControl("dobnyc_ft_tr6isrequestinspection").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_tr6isrequestinspection").setValue(false);

                executionContext.getAttribute("dobnyc_ft_tr6isrequestinspection").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
        }
        else if (adminReviewNumber == "2") {
            if (executionContext.getAttribute("dobnyc_ft_tr6adminreviewactions2").getValue() == 3) {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setValue(null);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_comments").setFocus();



            }
        }
        else if (adminReviewNumber == "3") {

            if (executionContext.getAttribute("dobnyc_ft_tr6incompletesubmission").getValue() == false) {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("required");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getControl("dobnyc_ft_tr6assigntoplanexaminer").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setValue(null);
                executionContext.getAttribute("dobnyc_ft_tr6assigntoplanexaminer").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_comments").setFocus();
            }
        }
    }
    else {
        alert("Filling type not found");
    }

}

function HVAdminReview4() {
    if (executionContext.getAttribute("dobnyc_ft_hvadminreview4").getValue() == 1) {
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else {
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
}

function HVAdminReview() {

    if (executionContext.getAttribute("dobnyc_hv_reviewactions1").getText() == "Incomplete Submission" ||
        executionContext.getAttribute("dobnyc_hv_reviewactions1").getText() == "Request Inspection") {
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else if (executionContext.getAttribute("dobnyc_hv_reviewactions2").getValue() == false) {
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else {
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
}

function AdminDocuments() {
    var taskId = executionContext.data.entity.getId();
    fetchXml = '<fetch version="1.0">' +
        '<entity name="dobnyc_facadesdocumentlist" >' +
        '<attribute name="dobnyc_facadesdocumentlistid" />' +
        '<attribute name="dobnyc_ft_document_status" />' +
        '<filter type="and">' +
        '<condition attribute="dobnyc_documentlisttofacadetaskid" operator="eq" value="' + taskId + '" />' +
        '</filter>' +
        '</entity>' +
        '</fetch>';
    //alert(fetchXml);
    //debugger;
    var documents = DOB.Dynamics365.Fetch("dobnyc_facadesdocumentlists", fetchXml);
    //alert("OPP Result: " + opportunities[0].attributes['name'].value + " " + opportunities[0].attributes['statuscode'].label + " " + opportunities[0].attributes['createdon'].value.getTime() + " " + opportunities[0].attributes['dy_specialty'].value + " " + opportunities[0].attributes['opportunityid'].value);
    // alert(Worksite[0].attributes['dy_city'].value + " " + Worksite[0].attributes['dy_state'].value + " " + Worksite[0].attributes['dy_zip'].value + " " + Worksite[0].attributes['dy_country'].value);
    //alert(Worksite[0].attributes['dy_lawsonreferenceid'].value + " " + Worksite[0].attributes['dy_lawsonreferenceid'].type);

    return documents;
}
function CSRAdminReview() {

    if (executionContext.getAttribute("dobnyc_controlnumberrequestactions").getText()) {
        if (executionContext.getAttribute("dobnyc_controlnumberrequestactions").getText() == "Incomplete Submission" ||
            executionContext.getAttribute("dobnyc_controlnumberrequestactions").getText() == "Control Number Not Required") {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            //hide unnecessary items and set value to null
            executionContext.getControl("dobnyc_ft_iscivilpenaltyapplicable").setVisible(false);
            executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setRequiredLevel("none");
            executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setValue(false);
            executionContext.getControl("dobnyc_ft_effectivecivilpenaltydate").setVisible(false);
            executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setRequiredLevel("none");
            executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setValue(null);


        }

        else {
            if (executionContext.getAttribute("dobnyc_controlnumberrequestactions").getText() == "Control Number Generated") {
                var documents = AdminDocuments();
                //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
                //var ids = gridControl.get_allRecordIds();
                //alert(ids.length);

                var isApproved = true;
                for (i = 0; i < documents.length; i++) {
                    var statusValue = documents[i]['dobnyc_ft_document_status'];
                    //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                    if (statusValue != "4") {
                        isApproved = false;
                    }
                }
                if (!isApproved) {
                    alert("Must approve all documents in the Document List");
                    executionContext.getAttribute("dobnyc_controlnumberrequestactions").setValue(null);
                    executionContext.getControl("dobnyc_ft_iscivilpenaltyapplicable").setVisible(false);
                    executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setRequiredLevel("none");
                    executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setValue(false);
                    executionContext.getControl("dobnyc_ft_effectivecivilpenaltydate").setVisible(false);
                    executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setRequiredLevel("none");
                    executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setValue(null);

                }

                else {
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                    executionContext.getControl("dobnyc_ft_iscivilpenaltyapplicable").setVisible(true);
                    executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setRequiredLevel("required");
                    civilPenaltyApplicable();

                }

            }

        }


    }
}
function SCRAdminReview() {

    if (executionContext.getAttribute("dobnyc_subcyclereassignmentadminactions").getText()) {
        if (executionContext.getAttribute("dobnyc_subcyclereassignmentadminactions").getText() == "Incomplete" ||
            executionContext.getAttribute("dobnyc_subcyclereassignmentadminactions").getText() == "Rejected") {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }

        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }

    }


}

function SCOAdminReview() {

    if (executionContext.getAttribute("dobnyc_scoadminreviewactions").getText()) {
        if (executionContext.getAttribute("dobnyc_scoadminreviewactions").getValue() == 1 ||
            executionContext.getAttribute("dobnyc_scoadminreviewactions").getValue() == 3) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }

        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }

    }


}
function PSRAdminReview() {
    if (executionContext.getAttribute("dobnyc_ft_psrincompletesubmission").getValue() == false) {
        executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("required");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }
    else {
        executionContext.getControl("dobnyc_ft_assignpsrtoplanexaminer").setVisible(false);
        executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setValue(null);
        executionContext.getAttribute("dobnyc_ft_assignpsrtoplanexaminer").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
    }

}




//Plan Examiner Inspection Review Types
function InspectionReviewTypes() {

    if (executionContext.getAttribute("dobnyc_ft_intakereview").getValue()) {
        executionContext.getControl("dobnyc_ins_intakereviewtype").setVisible(true);
        executionContext.getAttribute("dobnyc_ins_intakereviewtype").setRequiredLevel("required");

    }
    else {
        executionContext.getControl("dobnyc_ins_intakereviewtype").setVisible(false);
        executionContext.getAttribute("dobnyc_ins_intakereviewtype").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ins_intakereviewtype").setValue(null);

    }
    if ((executionContext.getAttribute("dobnyc_ft_amendeddismissalunsafe").getValue())) {
        executionContext.getControl("dobnyc_ins_amendeddismissalunsafe").setVisible(true);
        executionContext.getAttribute("dobnyc_ins_amendeddismissalunsafe").setRequiredLevel("required");

    }
    else {
        executionContext.getControl("dobnyc_ins_amendeddismissalunsafe").setVisible(false);
        executionContext.getAttribute("dobnyc_ins_amendeddismissalunsafe").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ins_amendeddismissalunsafe").setValue(null);

    }
    if ((executionContext.getAttribute("dobnyc_ft_midcycle").getValue())) {
        executionContext.getControl("dobnyc_ins_midcyclereviewtype").setVisible(true);
        executionContext.getAttribute("dobnyc_ins_midcyclereviewtype").setRequiredLevel("required");

    }
    else {
        executionContext.getControl("dobnyc_ins_midcyclereviewtype").setVisible(false);
        executionContext.getAttribute("dobnyc_ins_midcyclereviewtype").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ins_midcyclereviewtype").setValue(null);

    }
    if ((executionContext.getAttribute("dobnyc_ft_otherinspectiontype").getValue())) {

        executionContext.getControl("dobnyc_ft_inspectiontypedescription").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_inspectiontypedescription").setRequiredLevel("required");

    }
    else {
        executionContext.getControl("dobnyc_ft_inspectiontypedescription").setVisible(false);
        executionContext.getAttribute("dobnyc_ft_inspectiontypedescription").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_inspectiontypedescription").setValue(null);

    }

    if ((executionContext.getAttribute("dobnyc_ft_otherinspectionreason").getValue())) {
        executionContext.getControl("dobnyc_ft_inspectionreasondescription").setVisible(true);
        executionContext.getAttribute("dobnyc_ft_inspectionreasondescription").setRequiredLevel("required");

    }
    else {

        executionContext.getAttribute("dobnyc_ft_inspectionreasondescription").setRequiredLevel("none");


    }
}





//Plan Examiner Actions
function GetRelatedDocumentList() {
    var taskId = executionContext.data.entity.getId();
    fetchXml = '<fetch version="1.0">' +
        '<entity name="dobnyc_facadesdocumentlist" >' +
        '<attribute name="dobnyc_facadesdocumentlistid" />' +
        '<attribute name="dobnyc_ft_document_status" />' +
        '<filter type="and">' +
        '<condition attribute="dobnyc_planexaminerdocumentlistforfacaid" operator="eq" value="' + taskId + '" />' +
        '</filter>' +
        '</entity>' +
        '</fetch>';
    //alert(fetchXml);
    //debugger;
    var documents = DOB.Dynamics365.Fetch("dobnyc_facadesdocumentlist", fetchXml);
    //alert("OPP Result: " + opportunities[0].attributes['name'].value + " " + opportunities[0].attributes['statuscode'].label + " " + opportunities[0].attributes['createdon'].value.getTime() + " " + opportunities[0].attributes['dy_specialty'].value + " " + opportunities[0].attributes['opportunityid'].value);
    // alert(Worksite[0].attributes['dy_city'].value + " " + Worksite[0].attributes['dy_state'].value + " " + Worksite[0].attributes['dy_zip'].value + " " + Worksite[0].attributes['dy_country'].value);
    //alert(Worksite[0].attributes['dy_lawsonreferenceid'].value + " " + Worksite[0].attributes['dy_lawsonreferenceid'].type);

    return documents;
}




function FISP1PlanExaminerReview() {
    //var taskId = executionContext.data.entity.getId();
    InitialiseExtentionControls();
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_isfispone").getValue()) {
        if (executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").getText() == "Grant Extension") {
            var documents = GetRelatedDocumentList();
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            //alert(ids.length);
            if (documents.length == 0) {
                alert("Documents List must contains Documents");
                executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").setValue(null);
            }
            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                if (statusValue != "4") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Must approve all documents in the Document List");
                executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").setValue(null);
            }

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("required");
            executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(false);
            executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        }
        else {
            executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("none");
            executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("none");
            executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(true);
            executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        }
    }
    else {
        alert("Is fispone not checked");
    }
}
function FISP2PlanExaminerReview() {
    InitialiseExtentionControlsFISP2();
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_isfisptwo").getValue()) {

        if (executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").getText() == "Grant Extension") {
            var documents = GetRelatedDocumentList();
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                if (statusValue != "4") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Must approve all documents in the Document List");
                executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").setValue(null);
            }

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("required");
            executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(false);
            executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        }
        else {
            executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("none");
            executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("none");
            executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(true);
            executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        }
    }
    else {
        alert("Is fisptwo not checked");
    }


}
function PSRPlanExaminerReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
        //if(executionContext.getAttribute("dobnyc_ft_psrrequestinspection").getValue()== false ||
        if (executionContext.getAttribute("dobnyc_ft_psrrequestinspection").getValue()) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        if (executionContext.getAttribute("dobnyc_ft_psrplanexaminerreview").getText() == "REJECT") {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            var documents = GetRelatedDocumentList();
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                if (statusValue != "4") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Please Approve all Documents in Document List");
                executionContext.getAttribute("dobnyc_ft_psrplanexaminerreview").setValue(null);
            }


            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

        }
    }
    else {
        alert("ispartialshedremoval not checked");
    }
}
function HVPlanExaminerReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
        var moreThan = "DETERMINE MORE THAN 6.5 STORIES";

        if (executionContext.getAttribute("dobnyc_ft_pe_reviewactions").getText() == moreThan) {
            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            var documents = GetRelatedDocumentList();
            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                if (statusValue != "4") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Please Approve all Documents in Document List");
                executionContext.getAttribute("dobnyc_ft_pe_reviewactions").setValue(null);
            }
            //Applicable Civil penalty
            else {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_iscivilpenaltyapplicable").setVisible(true);
                executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setRequiredLevel("required");
                civilPenaltyApplicable();
            }

        }
        else {
            //height under validation.
            var documents = GetRelatedDocumentList();
            var isApproved = true;
            for (i = 0; i < documents.length; i++) {
                //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                var statusValue = documents[i]['dobnyc_ft_document_status'];
                if (statusValue == "1" || statusValue == "2" || statusValue == "3") {
                    isApproved = false;
                }
            }
            if (!isApproved) {
                alert("Please Approve/Reject all  document in the Document List");
                executionContext.getAttribute("dobnyc_ft_pe_reviewactions").setValue(null);
            }
            else {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                executionContext.getControl("dobnyc_ft_iscivilpenaltyapplicable").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_iscivilpenaltyapplicable").setValue(false);
                executionContext.getControl("dobnyc_ft_effectivecivilpenaltydate").setVisible(false);
                executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setRequiredLevel("none");
                executionContext.getAttribute("dobnyc_ft_effectivecivilpenaltydate").setValue(null);
            }

        }
    }
    else {
        alert("isheightverification not checked");
    }
}
function TR6PlanExaminerReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
        var fillingType = executionContext.getAttribute("dobnyc_ft_filingtype").getText();
        var filingStatus = executionContext.getAttribute("dobnyc_ft_filingstatus").getText();

        if (fillingType == "Initial" && filingStatus == "UNSAFE") {

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;                   
            //var ids = gridControl.get_allRecordIds();
            if (executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").getText() == "Accept") {
                var documents = GetRelatedDocumentList();
                var isApproved = true;
                for (i = 0; i < documents.length; i++) {
                    //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                    var statusValue = documents[i]['dobnyc_ft_document_status'];
                    if (statusValue != "4") {
                        isApproved = false;
                    }
                }
                if (!isApproved) {
                    alert("Please approve all documents in the Document List");
                    executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").setValue(null);
                }
            }

            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }

        else if (fillingType == "Initial" && (filingStatus == "SAFE" || filingStatus == "SWARMP")) {

            executionContext.getControl("dobnyc_tr6_safepereviewactions").setVisible(true);
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

            //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
            //var ids = gridControl.get_allRecordIds();
            if (executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText() == "Request Inspection") {
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionType").setVisible(true);
                executionContext.ui.tabs.get("FT_General").sections.get("FT_General_InspectionReason").setVisible(true);

            }
            if (executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText() == "Accept") {
                var documents = GetRelatedDocumentList();
                var isApproved = true;
                for (i = 0; i < documents.length; i++) {
                    //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                    var statusValue = documents[i]['dobnyc_ft_document_status'];
                    if (statusValue != "4") {
                        isApproved = false;
                    }
                }
                if (!isApproved) {
                    alert("Please Approve all Documents in Document List");
                    executionContext.getAttribute("dobnyc_tr6_safepereviewactions").setValue(null);
                }
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }
            else {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }


        }
        else if (fillingType == "Subsequent")// && (filingStatus == "SAFE" || filingStatus == "SWARMP"))
        {
            if ((filingStatus == "SAFE" || filingStatus == "SWARMP")) {
                if (executionContext.getAttribute("dobnyc_tr6_safepereviewactions").getText() == "Accept") {
                    var documents = GetRelatedDocumentList();
                    var isApproved = true;
                    for (i = 0; i < documents.length; i++) {
                        //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                        var statusValue = documents[i]['dobnyc_ft_document_status'];
                        if (statusValue != "4") {
                            isApproved = false;
                        }
                    }
                    if (!isApproved) {
                        alert("Please Approve all Documents in Document List");
                        executionContext.getAttribute("dobnyc_tr6_safepereviewactions").setValue(null);
                    }
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
                else {
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
            }
            if ((filingStatus == "UNSAFE")) {
                if (executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").getText() == "Accept") {
                    var documents = GetRelatedDocumentList();
                    var isApproved = true;
                    for (i = 0; i < documents.length; i++) {
                        //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                        var statusValue = documents[i]['dobnyc_ft_document_status'];
                        if (statusValue != "4") {
                            isApproved = false;
                        }
                    }
                    if (!isApproved) {
                        alert("Please Approve all Documents in Document List");
                        executionContext.getAttribute("dobnyc_tr6_unsafepereviewactions").setValue(null);
                    }
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
                else {
                    executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
                }
            }


        }


        else if (fillingType == "Amended")// && filingStatus == "UNSAFE")
        {

            if (executionContext.getAttribute("dobnyc_ft_tr6pereviewactions").getText() == "Accept") {
                //var gridControl = document.getElementById('PlanExaminerDocumentList').control;
                //var ids = gridControl.get_allRecordIds();
                var documents = GetRelatedDocumentList();
                var isApproved = true;
                for (i = 0; i < documents.length; i++) {
                    //var cellValue = gridControl.getCellValue('dobnyc_ft_document_status', ids[i]);
                    var statusValue = documents[i]['dobnyc_ft_document_status'];
                    if (statusValue != "4") {
                        isApproved = false;
                    }
                }
                if (!isApproved) {
                    alert("Please Approve all Documents in Document List");
                    executionContext.getAttribute("dobnyc_ft_tr6pereviewactions").setValue(null);
                }
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");

            }
            else {
                executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            }

        }
        else {
            alert("Filling type not found");
        }
    }
}
//Inspection Actions
function FISP3InspectionReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_isfispthree").getValue()) {
        if (executionContext.getAttribute("dobnyc_ft_fisp3isinspectioncomplete").getValue() == false) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getControl("dobnyc_ft_comments").setVisible(true);
        }
        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
            executionContext.getControl("dobnyc_ft_comments").setVisible(true);
        }
    }
    else {
        alert("isfispthree not checked");
    }
}
function TR6InspectionReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_istr6").getValue()) {
        if (executionContext.getAttribute("dobnyc_ft_tr6isinspectioncomplete").getValue() == false) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
    }
    else {
        alert("istr6 not checked");
    }

}
function PSRInspectionReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_ispartialshedremoval").getValue()) {
        if (executionContext.getAttribute("dobnyc_ft_psrinspectioncomplete").getValue() == false) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
    }
    else {
        alert("ispartialshedremoval not checked");
    }

}
function HVInspectionReview() {
    var FispValue = "Yes";
    if (executionContext.getAttribute("dobnyc_ft_isheightverification").getValue()) {
        if (executionContext.getAttribute("dobnyc_ft_inspectioncomplete").getValue() == false) {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
        else {
            executionContext.getAttribute("dobnyc_ft_comments").setRequiredLevel("required");
        }
    }
    else {
        alert("isheightverification not checked");
    }
}



function onChangeOfApprovalDays() {

    var nosDays = executionContext.getAttribute("dobnyc_ft_extentiondurationdays").getValue();
    if (nosDays == null) {
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setValue(null);
    }
    else if (nosDays > 90 || nosDays < 1) {
        alert("Entention can only be provided for 1 - 90 days");
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setValue(null);
    }
    else {
        var endDate = addDaysToToday(nosDays);
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setValue(endDate);
    }
}


function addDaysToToday(days) {
    var result = new Date();
    result.setDate(result.getDate() + days);
    return result;
}

function onSave() {
    onChangeOfApprovalDays();
    if (executionContext.getControl("dobnyc_ft_extentiondurationdays").getVisible()) {
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setSubmitMode("always");
    }
}

function InitialiseExtentionControls() {

    executionContext.getControl("dobnyc_ft_extentiondurationdays").setVisible(true);
    executionContext.getControl("dobnyc_ft_extentionenddate").setVisible(true);

    if (executionContext.getAttribute("dobnyc_ft_fisp1planningexaminerreview").getText() == "Grant Extension") {
        executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(false);
        executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("required");
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("required");
    }
    else {
        executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(true);
        executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setValue(null);
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setValue(null);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("none");
    }
}

function InitialiseExtentionControlsFISP2() {

    executionContext.getControl("dobnyc_ft_extentiondurationdays").setVisible(true);
    executionContext.getControl("dobnyc_ft_extentionenddate").setVisible(true);

    if (executionContext.getAttribute("dobnyc_ft_fisp2planexaminerreview").getText() == "Grant Extension") {
        executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(false);
        executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("required");
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("required");
    }
    else {
        executionContext.getControl("dobnyc_ft_extentiondurationdays").setDisabled(true);
        executionContext.getControl("dobnyc_ft_extentionenddate").setDisabled(true);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setValue(null);
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setValue(null);
        executionContext.getAttribute("dobnyc_ft_extentiondurationdays").setRequiredLevel("none");
        executionContext.getAttribute("dobnyc_ft_extentionenddate").setRequiredLevel("none");
    }
}

function CheckRejectionDuplicateFlag() {
    if (confirm("On rejection, Open tasks of other Duplicate Records will be cancelled. \nAre you sure you want to Reject Duplicates")) {
        //remove the requried fields
        var requiredAttributes = executionContext.data.entity.attributes.get();
        var nextrequiredAttributes = [];
        for (var i in requiredAttributes) {
            if (requiredAttributes[i].getRequiredLevel() == "required") {
                nextrequiredAttributes.push(requiredAttributes[i]);
                if (requiredAttributes[i].getValue() == null) {
                    requiredAttributes[i].setRequiredLevel("none");
                }
            }
        }
        //update flag
        executionContext.getAttribute("dobnyc_ft_isrejectotherduplicatesflag").setValue(1);
        executionContext.getAttribute("dobnyc_ft_isrejectotherduplicatesflag").setSubmitMode("always");
        executionContext.getControl("dobnyc_ft_comments").setFocus();
        executionContext.data.save();
        //Make manditory fields manditory again-updated by vinay
        for (var i in nextrequiredAttributes) {
            nextrequiredAttributes[i].setRequiredLevel("required");
        }

    }
}