//function registered onchange of requeststatus field
function requestStatusOnChange() {
    if (executionContext.ui.getFormType() == 2 && executionContext.getAttribute("dobnyc_requeststatus").getValue() != 1) {
        disableFormFields(true);
    }
}


//function called on OnLoad event
function CNRformOnload() {
    debugger;
    if (executionContext.ui.getFormType() == 2 && executionContext.getAttribute("dobnyc_requeststatus").getValue() != 1 && executionContext.getAttribute("dobnyc_requeststatus").getValue() != 5 && executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == true) {
        disableFormFields(true);
    }
    if (executionContext.ui.getFormType() == 2 && executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == false) {
        disableFormFields(true);
    }

    if (executionContext.ui.getFormType() == 1) {
        executionContext.getAttribute("dobnyc_isinternalcnr").setValue(true);
        executionContext.getAttribute("dobnyc_isinternalcnr").setSubmitMode("always");
        if (executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == true) {
            executionContext.ui.tabs.get("CNRMainTab").sections.get("ApplicantInformation").setVisible(true);
        }
        executionContext.getAttribute("dobnyc_block").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_bin").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_lot").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_cnr_zip").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_cnr_cbno").setSubmitMode("always");
    }

    if (executionContext.ui.getFormType() == 2 && executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == true) {
        executionContext.ui.tabs.get("CNRMainTab").sections.get("ApplicantInformation").setVisible(true);
        executionContext.getAttribute("dobnyc_block").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_bin").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_lot").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_cnr_zip").setSubmitMode("always");
        executionContext.getAttribute("dobnyc_cnr_cbno").setSubmitMode("always");
    }
}


function disableFormFields(onOff) {
    executionContext.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }
    }
    );
}


//called in disableFormFields
function doesControlHaveattribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}


//function to check if the location information section is fully filled
function validateSubmit() {
    //debugger;

    if (executionContext.ui.getFormType() == 2) {
        var confirmStrings = { text: "Are you sure you want to File Control Number Request?", title: "Confirmation Dialog" };
        var confirmOptions = { height: 200, width: 450 };
        Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
            function (success) {
                if (success.confirmed) {
                    var validAV = false;
                    validAV = addressValidation();
                    var validLocation = validateLocation();
                    //var validDoc = validateDocument();
                    if (validLocation == true && /*validDoc == true && */ validAV == true) {
                        executionContext.getAttribute("dobnyc_issubmitted").setValue(1);
                        executionContext.getAttribute("dobnyc_issubmitted").setSubmitMode("always");
                        executionContext.data.entity.save();
                        alert("The Control Number Request record was filed successfully!");
                    }
                }
            });
    }
}


//this function is being called in validateSubmit function
function validateLocation() {
    // if (executionContext.getControl('Applicant_Information_Applicant_Information_dobnyc_heightverification_firstname') != null) {
    var flagLocation = true;
    var block = executionContext.getAttribute("dobnyc_block").getValue();
    var bin = executionContext.getAttribute("dobnyc_bin").getValue();
    var lot = executionContext.getAttribute("dobnyc_lot").getValue();
    var zip = executionContext.getAttribute("dobnyc_cnr_zip").getValue();
    var cbNumber = executionContext.getAttribute("dobnyc_cnr_cbno").getValue();
    var houseNumber = executionContext.getAttribute("dobnyc_housenumber").getValue();
    var streetName = executionContext.getAttribute("dobnyc_streetname").getValue();
    var Borough = executionContext.getAttribute("dobnyc_borough").getValue();
    //var controlNo = executionContext.getAttribute("dobnyc_hv_controlnumber");
    var location = [block, bin, lot, zip, cbNumber, houseNumber, streetName, Borough];//, controlNo];
    for (var i = 0; i < location.length; i++) {
        if (location[i] == null) {
            flagLocation = false;
            alert("Please confirm if the fields in the Location Information section are populated");
            return flagLocation;
        }
    }
    return flagLocation;
}


//function to check supporting document types
function validateDocument() {
    //debugger;
    var validDoc = true;

    var documentDictionary = {
        PhotoDocumentationofallExteriorWalls: true,
    };

    //documentDictionary.Photographs = executionContext.getAttribute("dobnyc_photographs").getValue();
    //documentDictionary.PropertyProfile = executionContext.getAttribute("dobnyc_propertyprofile").getValue();
    //documentDictionary.DemoSignOff = executionContext.getAttribute("dobnyc_demosignoff").getValue();
    //documentDictionary.Other = executionContext.getAttribute("dobnyc_other").getValue();
    //documentDictionary.Permit = executionContext.getAttribute("dobnyc_permit").getValue();

    var CNRID = executionContext.data.entity.getId();

    var documentTypeDictionary = {
        PhotoDocumentationofallExteriorWalls: "Photo Documentation of all Exterior Walls",
        //    PropertyProfile: "Property Profile",
        //    DemoSignOff: "Demo Sign Off",
        //    Other: "Other",
        //    Permit: "Permit",
    };

    for (var key in documentDictionary) {
        var value = documentDictionary[key];
        if (value == true) {
            var documentName = documentTypeDictionary[key];
            var fetchXMLdoc = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >" +
                "<entity name='dobnyc_facadesdocumenttype'>" +
                "<attribute name='dobnyc_facadesdocumenttypeid' />" +
                "<attribute name='dobnyc_name' />" +
                "<filter type='and'>" +
                "<condition attribute='dobnyc_name' operator='eq' value='" + documentName + "' />" +
                "<condition attribute='dobnyc_dt_regardingform' operator='eq' value='7' />" +
                "</filter>" +
                "</entity>" +
                "</fetch>";
            var retrieveddocType = DOB.Dynamics365.Fetch("dobnyc_facadesdocumenttypes", fetchXMLdoc);
            var count_DocType = retrieveddocType.length;
            if (retrieveddocType.length > 0) {
                var docId = retrieveddocType[0].id;
                var fetchXml = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true' >" +
                    "<entity name='dobnyc_facadesdocumentlist'>" +
                    "<attribute name='dobnyc_facadesdocumentlistid' />" +
                    "<attribute name='dobnyc_name' />" +
                    "<filter type='and'>" +
                    "<condition attribute='dobnyc_dl_documenttypeguid' operator='eq'  value='" + docId + "' />" +
                    "<condition attribute='dobnyc_dl_regardingcnr' operator='eq'  value='" + CNRID + "' />" +
                    "</filter>" +
                    "</entity>" +
                    "</fetch>";
                var retrieveddoc = DOB.Dynamics365.Fetch("dobnyc_facadesdocumentlists", fetchXml);
                var count = retrieveddoc.length;
                if (count == 0) {
                    validDoc = false;
                    alert("Please upload " + documentName + " document before filing!");
                    return validDoc;
                }
            }
        }
    }
    return validDoc;
}



//function called on sumbit button press
function addressValidation(/*context*/) {
    //debugger;
    $.support.cors = true;
    if (executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == false) {
        executionContext.data.entity.save();
        return;
    }
    //var saveEvent = context.getEventArgs();
    var flagAV;
    var houseNumber = executionContext.getAttribute("dobnyc_housenumber").getValue();
    var streetName = executionContext.getAttribute("dobnyc_streetname").getValue();
    var borough = executionContext.getAttribute("dobnyc_borough").getValue();
    var URL = getMessage("CNRValidateAddress");
    $.ajax({
        type: "POST",
        async: false,
        url: URL,
        processData: true,
        crossDomain: true,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({ HouseNo: houseNumber, StreetName: streetName, Borough: borough, IsCnrSearchRequestFromCrm: true }),
        cache: false,
        headers: {
            'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
        },
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            if (data.IsSuccess == true) {

                if (data.locationDetails[0] != null) {
                    executionContext.getAttribute("dobnyc_block").setValue(data.locationDetails[0].Block);
                    executionContext.getAttribute("dobnyc_bin").setValue(data.locationDetails[0].Bin);
                    executionContext.getAttribute("dobnyc_lot").setValue(data.locationDetails[0].Lot);
                    executionContext.getAttribute("dobnyc_cnr_zip").setValue(data.locationDetails[0].ZipCode);
                    executionContext.getAttribute("dobnyc_cnr_cbno").setValue(data.locationDetails[0].CBNO);
                    if (data.FacadesErrorList[0] != null) {
                        /*  var lookup = new Array();
                         lookup[0] = new Object();
                         lookup[0].id = data.locationDetails[0].ControlNumberGuid;
                         lookup[0].name = data.locationDetails[0].ControlNumber;
                         lookup[0].entityType = "dobnyc_controlnumber";
                         executionContext.getAttribute("dobnyc_controlnumber").setValue(lookup); */
                        // if (executionContext.ui.getFormType() == 1)
                        alert(data.FacadesErrorList[0].ErrorDescription + ": " + data.FacadesErrorList[0].FieldName);
                        flagAV = false;
                        return flagAV;
                    }
                    else {
                        executionContext.getAttribute("dobnyc_controlnumber").setValue(null);
                    }
                    executionContext.data.entity.save();
                    flagAV = true;
                    return flagAV;
                }
                /* else {
                    alert(data.FacadesErrorList[0].ErrorDescription + ": " + data.FacadesErrorList[0].FieldName);
                    flagAV = false;
                    return flagAV;
                } */
            }
            else {
                //executionContext.data.refresh();
                //alert("Please provide valid address");
                if (data.FacadesErrorList[0] != null) {
                    alert(data.FacadesErrorList[0].ErrorDescription + ": " + data.FacadesErrorList[0].FieldName);
                    flagAV = false;
                    return flagAV;
                }
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            alert("An error occurred while validating address. Please try again or contact administrator.");
            flagAV = false;
            return flagAV;
            //      saveEvent.preventDefault();
        }
    });
    return flagAV;
}


//function called in addressValidation
function getMessage(key) {
    /// get Data from configuration entity
    var returnValue = null;
    //returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'");

    //if (returnValue != null && returnValue[0] != null)
    //    return returnValue[0].dobnyc_name;
    
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_customconfigurationses", "?$filter=dobnyc_key eq '" + key + "' and dobnyc_langugaecode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'", function (result) {
        if (result.length != 0) {
            returnValue = result[0].dobnyc_name;
        }
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

    if (returnValue == null)
        return "Unable to get configuration message for Key : " + key + ".";
    else
        return returnValue;
}


//used in ribbon workbench to hide/display submit button
function buttonRules() {
    var flag = false;
    if ((executionContext.ui.getFormType() == 2) && executionContext.getAttribute("dobnyc_isinternalcnr").getValue() == true && (executionContext.getAttribute("dobnyc_requeststatus").getValue() == 1 || executionContext.getAttribute("dobnyc_requeststatus").getValue() == 5)) {
        flag = true;
    }
    return flag;
}


//function to populate details in owner information section
function getOwnerInfo() {
    var name = '';
    var lookupid;
    var lookupObject = executionContext.getAttribute("dobnyc_cnr_owner");
    if (lookupObject != null) {
        var lookUpObjectValue = lookupObject.getValue();
        if (lookUpObjectValue != null) {
            name = lookUpObjectValue[0].name;
            lookupid = lookUpObjectValue[0].id;
        }
    }

    var lookupid = lookupid.replace(/[{}]/g, "");

    if (lookupid) {
        //returnValue = retrieveMultipleCustom("ContactSet", "?$select=Address1_City,Address1_Fax,Address1_Line1,Address1_PostalCode,Address1_StateOrProvince,Address1_Telephone1,dobnyc_BusinessName,dobnyc_Phone,EMailAddress1,FirstName,LastName,MiddleName&$filter=ContactId eq guid'" + lookupid + "'");

        //if (returnValue != null && returnValue[0] != null) {
        //    executionContext.getAttribute("dobnyc_cnr_owneremail").setValue(returnValue[0].EMailAddress1);
        //    executionContext.getAttribute("dobnyc_cnr_ownermobile").setValue(returnValue[0].dobnyc_Phone);
        //    executionContext.getAttribute("dobnyc_cnr_ownerbusinessname").setValue(returnValue[0].dobnyc_BusinessName);
        //    executionContext.getAttribute("dobnyc_cnr_ownercity").setValue(returnValue[0].Address1_City);
        //    executionContext.getAttribute("dobnyc_cnr_ownerzip").setValue(returnValue[0].Address1_PostalCode);
        //    executionContext.getAttribute("dobnyc_cnr_ownerbusinessfax").setValue(returnValue[0].Address1_Fax);
        //    executionContext.getAttribute("dobnyc_cnr_ownerbusinessphone").setValue(returnValue[0].Address1_Telephone1);
        //    executionContext.getAttribute("dobnyc_cnr_ownerfirstname").setValue(returnValue[0].FirstName);
        //    executionContext.getAttribute("dobnyc_cnr_ownerlastname").setValue(returnValue[0].LastName);
        //    executionContext.getAttribute("dobnyc_cnr_ownermiddlename").setValue(returnValue[0].MiddleName);
        //    executionContext.getAttribute("dobnyc_cnr_ownertelephone").setValue(returnValue[0].dobnyc_Phone);
        //    executionContext.getAttribute("dobnyc_cnr_owneraddress").setValue(returnValue[0].Address1_Line1);
        //    executionContext.getAttribute("dobnyc_cnr_ownerstate").setValue(returnValue[0].Address1_StateOrProvince);
        //}

        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(true, "contacts", "?$select=address1_city,address1_fax,address1_line1,address1_postalcode,address1_stateorprovince,address1_telephone1,dobnyc_businessname,dobnyc_phone,emailaddress1,firstname,lastname,middlename&$filter=contactid eq " + lookupid, function (result) {
            if (result.value.length != 0) {
                executionContext.getAttribute("dobnyc_cnr_owneremail").setValue(result.value[0].emailaddress1);
                executionContext.getAttribute("dobnyc_cnr_ownermobile").setValue(result.value[0].dobnyc_phone);
                executionContext.getAttribute("dobnyc_cnr_ownerbusinessname").setValue(result.value[0].dobnyc_businessname);
                executionContext.getAttribute("dobnyc_cnr_ownercity").setValue(result.value[0].address1_city);
                executionContext.getAttribute("dobnyc_cnr_ownerzip").setValue(result.value[0].address1_postalcode);
                executionContext.getAttribute("dobnyc_cnr_ownerbusinessfax").setValue(result.value[0].address1_fax);
                executionContext.getAttribute("dobnyc_cnr_ownerbusinessphone").setValue(result.value[0].address1_telephone1);
                executionContext.getAttribute("dobnyc_cnr_ownerfirstname").setValue(result.value[0].firstname);
                executionContext.getAttribute("dobnyc_cnr_ownerlastname").setValue(result.value[0].lastname);
                executionContext.getAttribute("dobnyc_cnr_ownermiddlename").setValue(result.value[0].middlename);
                executionContext.getAttribute("dobnyc_cnr_ownertelephone").setValue(result.value[0].dobnyc_phone);
                executionContext.getAttribute("dobnyc_cnr_owneraddress").setValue(result.value[0].address1_line1);
                executionContext.getAttribute("dobnyc_cnr_ownerstate").setValue(result.value[0].address1_stateorprovince);
            }
        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
    }
}