function SetTaskForm() {
   // debugger;
    var Taskform = executionContext.getAttribute("dobnyc_ft_taskformfor").getValue();
    var form = executionContext.ui.formSelector.getCurrentItem();
    if (form != null) {
        var formId = form.getId();
        var formLabel = form.getLabel();
    }
    if (Taskform == 1 && formLabel != "Administrative Review Form") {
        var items = executionContext.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();

            if (formLabel == "Administrative Review Form") {
                form.navigate();
                return;
            }
        }
        alert("You Do not have enough privileges to complete this action. Please Contact your Administrator.");
        executionContext.ui.close();
    }
    if (Taskform == 2 && formLabel != "Inspection Form") {
        var items = executionContext.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Inspection Form") {
                form.navigate();
                return;
            }
        }
        alert("You Do not have enough privileges to complete this action. Please Contact your Administrator.");
        executionContext.ui.close();
    }
    if (Taskform == 3 && formLabel != "Plan Examiner Review Form") {
        var items = executionContext.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Plan Examiner Review Form") {
                form.navigate();
                return;
            }
        }
        alert("You Do not have enough privileges to complete this action. Please Contact your Administrator.");
        executionContext.ui.close();
    }
    if (Taskform == 4 && formLabel != "Plan Examiner Supervisor Form") {
        var items = executionContext.ui.formSelector.items.get();
        for (var i in items) {
            var form = items[i];
            var formId = form.getId();
            var formLabel = form.getLabel();
            if (formLabel == "Plan Examiner Supervisor Form") {
                form.navigate();
                return;
            }
        }
        alert("You Do not have enough privileges to complete this action. Please Contact your Administrator.");
        executionContext.ui.close();
    }
}