var fieldArray = ["dobnyc_crossstreet1", "dobnyc_crossstreet1numbers", "dobnyc_crossstreet2", "dobnyc_crossstreet2numbers", "dobnyc_crossstreet3", "dobnyc_crossstreet3numbers", "dobnyc_crossstreet4",
    "dobnyc_crossstreet4numbers", "dobnyc_pp_crossstreet5", "dobnyc_pp_crossstreet5number", "dobnyc_pp_crossstreet6", "dobnyc_pp_crossstreet6numbers"];


function HideShowFields() {
    debugger;
    var arrayLength = fieldArray.length;
    for (var i = 0; i < arrayLength; i++) {
        if (executionContext.getAttribute(fieldArray[i]).getValue() == null)
            executionContext.getControl(fieldArray[i]).setVisible(false);
    }


}