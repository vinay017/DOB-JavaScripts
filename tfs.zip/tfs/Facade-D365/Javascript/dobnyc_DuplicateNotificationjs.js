// JavaScript source code

function ShowDuplicateNotificationOnLoad() {
    //debugger;
    var formType = executionContext.ui.getFormType();
    if (formType == 2) {
        var entityName = executionContext.data.entity.getEntityName();
        if (entityName == "dobnyc_tr6") {
            var isDuplicate = executionContext.getAttribute("dobnyc_tr6_ispossibleduplicate").getValue();
            var isInactive = executionContext.getAttribute("dobnyc_tr6_isinactive").getValue();

            if (isDuplicate && !isInactive) {
                executionContext.ui.setFormNotification("This Technical Reports-(TR6) Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
            }
            else if (isInactive) {
                executionContext.ui.setFormNotification("This Technical Reports-(TR6) Record is a duplicate. Workflows have been PERMANENTLY suspended for this record.", "ERROR");
            }
            var houseNumber = executionContext.getAttribute("dobnyc_tr6_houseno").getValue();
            var streetName = executionContext.getAttribute("dobnyc_tr6_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_tr6_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_tr6_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
        else if (entityName == "dobnyc_fispone") {
            var isDuplicate = executionContext.getAttribute("dobnyc_fisp1_ispossibleduplicate").getValue();
            var isInactive = executionContext.getAttribute("dobnyc_fisp1_isinactive").getValue();

            if (isDuplicate && !isInactive) {
                executionContext.ui.setFormNotification("This Initial Extention Request-(FISP 1) Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
            }
            else if (isInactive) {
                executionContext.ui.setFormNotification("This Initial Extention Request-(FISP 1) Record is a duplicate. Workflows have been PERMANENTLY suspended for this record.", "ERROR");
            }

            var TR6ID;
            var lookupObject = executionContext.getAttribute("dobnyc_fisp1_regardingtr6");
            if (lookupObject != null) {
                var lookUpObjectValue = lookupObject.getValue();
                if (lookUpObjectValue != null) {
                    TR6ID = lookUpObjectValue[0].id;
                }
            }
            var retrieveTR6Details = null;
            //retrieveTR6Details = retrieveMultipleCustom("dobnyc_tr6Set", "?$select=dobnyc_TR6_BIN,dobnyc_TR6_HouseNo,dobnyc_TR6_StreetName,dobnyc_TR6_Borough&$filter=dobnyc_tr6Id eq guid'" + TR6ID + "'");
            //if (retrieveTR6Details[0] != null) {
            //    var houseNumber = retrieveTR6Details[0].dobnyc_TR6_HouseNo;
            //    var streetName = retrieveTR6Details[0].dobnyc_TR6_StreetName;
            //    if (streetName != null) {
            //        streetName = streetName.toUpperCase();
            //    }
            //    var bin = retrieveTR6Details[0].dobnyc_TR6_BIN;
            //    var boroughNumber = retrieveTR6Details[0].dobnyc_TR6_Borough.Value;
            //    var boroughName = getBoroughName(boroughNumber);
            //    var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            //    executionContext.ui.setFormNotification(message, "INFORMATION");
            //}
            TR6ID = TR6ID.replace("{", "").replace("}", "");
            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(true, "dobnyc_tr6s", "?$select=dobnyc_tr6_bin,dobnyc_tr6_houseno,dobnyc_tr6_streetname,dobnyc_tr6_borough&$filter=dobnyc_tr6id eq " + TR6ID, function (result) {
                if (result.value.length != 0) {
                    var houseNumber = result.value[0].dobnyc_tr6_houseno;
                    var streetName = result.value[0].dobnyc_tr6_streetname;
                    if (streetName != null) {
                        streetName = streetName.toUpperCase();
                    }
                    var bin = result.value[0].dobnyc_tr6_bin;
                    var boroughNumber = result.value[0].dobnyc_tr6_borough;
                    var boroughName = getBoroughName(boroughNumber);
                    var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
                    executionContext.ui.setFormNotification(message, "INFORMATION");
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });

        }
        else if (entityName == "dobnyc_fisptwo") {
            var isDuplicate = executionContext.getAttribute("dobnyc_fisp2_ispossibleduplicate").getValue();
            var isInactive = executionContext.getAttribute("dobnyc_fisp2_isinactive").getValue();

            if (isDuplicate && !isInactive) {
                executionContext.ui.setFormNotification("This Additional Extention Request-(FISP 2) Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
            }
            else if (isInactive) {
                executionContext.ui.setFormNotification("This Additional Extention Request-(FISP 2) Record is a duplicate. Workflows have been PERMANENTLY suspended for this record.", "ERROR");
            }

            var TR6ID;
            var lookupObject = executionContext.getAttribute("dobnyc_fisp2_regardingtr6");
            if (lookupObject != null) {
                var lookUpObjectValue = lookupObject.getValue();
                if (lookUpObjectValue != null) {
                    TR6ID = lookUpObjectValue[0].id;
                }
            }

            var retrieveTR6Details = null;
            //retrieveTR6Details = retrieveMultipleCustom("dobnyc_tr6Set", "?$select=dobnyc_TR6_BIN,dobnyc_TR6_HouseNo,dobnyc_TR6_StreetName,dobnyc_TR6_Borough&$filter=dobnyc_tr6Id eq guid'" + TR6ID + "'");
            //if (retrieveTR6Details[0] != null) {
            //    var houseNumber = retrieveTR6Details[0].dobnyc_TR6_HouseNo;
            //    var streetName = retrieveTR6Details[0].dobnyc_TR6_StreetName;
            //    if (streetName != null) {
            //        streetName = streetName.toUpperCase();
            //    }
            //    var bin = retrieveTR6Details[0].dobnyc_TR6_BIN;
            //    var boroughNumber = retrieveTR6Details[0].dobnyc_TR6_Borough.Value;
            //    var boroughName = getBoroughName(boroughNumber);
            //    var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            //    executionContext.ui.setFormNotification(message, "INFORMATION");
            //}

            TR6ID = TR6ID.replace("{", "").replace("}", "");

            SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(true, "dobnyc_tr6s", "?$select=dobnyc_tr6_bin,dobnyc_tr6_houseno,dobnyc_tr6_streetname,dobnyc_tr6_borough&$filter=dobnyc_tr6id eq " + TR6ID, function (result) {
                if (result.value.length != 0) {
                    var houseNumber = result.value[0].dobnyc_tr6_houseno;
                    var streetName = result.value[0].dobnyc_tr6_streetname;
                    if (streetName != null) {
                        streetName = streetName.toUpperCase();
                    }
                    var bin = result.value[0].dobnyc_tr6_bin;
                    var boroughNumber = result.value[0].dobnyc_tr6_borough;
                    var boroughName = getBoroughName(boroughNumber);
                    var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
                    executionContext.ui.setFormNotification(message, "INFORMATION");
                }
            }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
        }
        else if (entityName == "dobnyc_heightverification") {
            var isDuplicate = executionContext.getAttribute("dobnyc_hv_ispossibleduplicate").getValue();
            var isInactive = executionContext.getAttribute("dobnyc_hv_isinactive").getValue();

            if (isDuplicate && !isInactive) {
                executionContext.ui.setFormNotification("This Height Verification Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
            }
            else if (isInactive) {
                executionContext.ui.setFormNotification("This Height Verification Record is a duplicate. Workflows have been PERMANENTLY suspended for this record.", "ERROR");
            }
            var houseNumber = executionContext.getAttribute("dobnyc_hv_housenos").getValue();
            var streetName = executionContext.getAttribute("dobnyc_hv_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_hv_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_hv_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
        else if (entityName == "dobnyc_partialshedremoval") {
            var isDuplicate = executionContext.getAttribute("dobnyc_psr_ispossibleduplicate").getValue();
            var isInactive = executionContext.getAttribute("dobnyc_psr_isinactive").getValue();

            if (isDuplicate && !isInactive) {
                executionContext.ui.setFormNotification("This Partial Shed Removal Record is a possible duplicate. Workflows have been temporarily suspended for this record.", "WARNING");
            }
            else if (isInactive) {
                executionContext.ui.setFormNotification("This Partial Shed Removal Record is a duplicate. Workflows have been PERMANENTLY suspended for this record.", "ERROR");
            }
            var houseNumber = executionContext.getAttribute("dobnyc_psr_housenos").getValue();
            var streetName = executionContext.getAttribute("dobnyc_psr_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_psr_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_psr_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
        else if (entityName == "dobnyc_fispthree") {
            var houseNumber = executionContext.getAttribute("dobnyc_fisp3_houseno").getValue();
            var streetName = executionContext.getAttribute("dobnyc_fisp3_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_fisp3_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_fisp3_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
        else if (entityName == "dobnyc_controlnumberrequest") {
            var houseNumber = executionContext.getAttribute("dobnyc_housenumber").getValue();
            var streetName = executionContext.getAttribute("dobnyc_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
        else if (entityName == "dobnyc_subcycleoverride") {
            var houseNumber = executionContext.getAttribute("dobnyc_sor_housenumber").getValue();
            var streetName = executionContext.getAttribute("dobnyc_sor_streetname").getValue();
            if (streetName != null) {
                streetName = streetName.toUpperCase();
            }
            var bin = executionContext.getAttribute("dobnyc_sor_bin").getValue();
            var boroughNumber = executionContext.getAttribute("dobnyc_sor_borough").getValue();
            var boroughName = getBoroughName(boroughNumber);
            var message = "BIN: " + bin + " ADDRESS: " + houseNumber + " " + streetName + " " + boroughName;
            executionContext.ui.setFormNotification(message, "INFORMATION");
        }
    }
}

function getBoroughName(boroughNumber) {
    var boroughName;
    if (boroughNumber == 1) {
        boroughName = "MANHATTAN";
    }
    if (boroughNumber == 2) {
        boroughName = "BRONX";
    }
    if (boroughNumber == 3) {
        boroughName = "BROOKLYN";
    }
    if (boroughNumber == 4) {
        boroughName = "QUEENS";
    }
    if (boroughNumber == 5) {
        boroughName = "STATEN ISLAND";
    }
    if (boroughNumber == null) {
        boroughName = "Null";
    } return boroughName;
}// JavaScript source code