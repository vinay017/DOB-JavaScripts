// JavaScript source code

var EntityNames = {
    TR6: "dobnyc_tr6",
    FISP1: "dobnyc_fispone",
    FISP2: "dobnyc_fisptwo",
    FISP3: "dobnyc_fispthree",
    PSR: "dobnyc_partialshedremoval",
    HV: "dobnyc_heightverification",
    CNR: "dobnyc_controlnumberrequest",
    SCR: "dobnyc_subcyclereassignmentrequest",
};


function Onload() {

    showHideFISPReport();
    executionContext.data.process.addOnStageSelected(showHideFISPReport);
    //disable for other users who are not admins.
    var isvalid = checkSecurityRole();
    if (!isvalid) {
        disableFormFields(true);
    }

}
function showHideFISPReport() {
    if (executionContext.data.process) {
        var activeProcess = executionContext.data.process.getActiveProcess();
        if (activeProcess && activeProcess.isRendered()) {
            // BPF exists on the form
            var activeStage = executionContext.data.process.getSelectedStage();
            var stageName = activeStage.getName();
            if (stageName == "FISP Report") {
                executionContext.ui.tabs.get("FISP_Report").setVisible(true);
                executionContext.ui.tabs.get("TR6").setVisible(false);
                executionContext.ui.tabs.get("TR6_HistoryTrace").setVisible(false);

                var Dates_Of_Inspectiongrid = executionContext.ui.controls.get('Dates_Of_Inspection');
                if (Dates_Of_Inspectiongrid == null) {
                    return;
                }
                else {
                    Dates_Of_Inspectiongrid.refresh();
                }
            }
            else {
                executionContext.ui.tabs.get("FISP_Report").setVisible(false);
                executionContext.ui.tabs.get("TR6").setVisible(true);
                executionContext.ui.tabs.get("TR6_HistoryTrace").setVisible(true);
            }
        }
        else {
            // No BPF exists
        }
    }
}

function disableFormFields(onOff) {
    executionContext.ui.controls.forEach(function (control, index) {
        if (doesControlHaveattribute(control)) {
            control.setDisabled(onOff);
        }

    }
    );
}

function doesControlHaveattribute(control) {
    var controlType = control.getControlType();
    return controlType != "iframe" && controlType != "webresource" && controlType != "subgrid";
}

function getLookupName(attributeName) {

    lookupObject = executionContext.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}

function DownloadSummaryPDFDocument() {

    //alert("check");
    var tr6Guid = executionContext.data.entity.getId();
    var Borough = executionContext.getAttribute("dobnyc_tr6_borough").getText();
    var ReportNumber = executionContext.getAttribute("dobnyc_name").getValue();
    var ControlNumber = getLookupName("dobnyc_tr6_controlnumber");
    var ReportStatus = executionContext.getAttribute("dobnyc_tr6_reportstatus").getValue();

    var init, fin

    if (tr6Guid) {

        init = tr6Guid.indexOf('{');
        fin = tr6Guid.indexOf('}');
        tr6Guid = tr6Guid.substr(init + 1, fin - init - 1);
        var URL = getMessage("TR6GenerateExportPDF");

        $.ajax({
            type: "POST",
            url: URL,
            processData: true,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ TR6Guid: tr6Guid }),
            cache: false,
            beforeSend: function (XMLHttpRequest) { XMLHttpRequest.setRequestHeader("Accept", "application/json"); },
            success: function (data) {
                if (data.IsSuccess == true) {

                    if (data.URL) {
                        var path = (Borough + "\\" + ControlNumber + "\\" + ReportNumber + "\\");

                        window.open(data.URL);
                        return;

                    }
                    else {
                        alert("PDF URL is Not Generated.");
                        return;
                    }
                    //alert("Download Successful");     
                    // window.open(data.downloadPath);
                }
                else {

                    //alert(data.ErrorDescription);
                    alert("PDF Generation is Un-successful");
                }
            },
            error: function (xhr, status, error) {
                alert(error);
                alert("An error occured while downloding document. Please try again or contact administrator.");
            }
        });

    }

}


function getMessage(key) {
    /// get Data from configuration entity
    var returnValue = null;
    //returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'");
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_customconfigurationses", "?$filter=dobnyc_key eq '" + key + "' and dobnyc_langugaecode eq '" + Xrm.Utility.getGlobalContext().userSettings.languageId + "'", function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0].dobnyc_name;

    return "Unable to get configuration message for Key : " + key + ".";
}

function filingDates() {
    var filingOptionset = {
        initial: 1,
        Amended: 3,
        Subsequent: 4,

    };
    var filingStatusOptionset = {
        Safe: 1,
        Swarmp: 2,
        Unsafe: 3,
        NRF: 4

    };
    var filingType = executionContext.getAttribute("dobnyc_tr6_filingtype").getValue();
    if (filingType) {
        if (filingType == filingOptionset.initial) {
            var filingStatus = executionContext.getAttribute("dobnyc_tr6_filingstatus").getValue();
            if (filingStatus) {
                if (filingStatus == filingStatusOptionset.Safe || filingStatus == filingStatusOptionset.Swarmp) {
                    executionContext.getControl("dobnyc_tr6_initialunsafefilingdate").setVisible(false);
                }
                else if (filingStatus == filingStatusOptionset.Unsafe) {
                    executionContext.getControl("dobnyc_tr6_initialunsafefilingdate").setVisible(true);

                }

            }

        }
        else if (filingType == filingOptionset.Subsequent) {
            executionContext.getControl("dobnyc_tr6_initialunsafefilingdate").setVisible(false);
        }
        else if (filingType == filingOptionset.Amended) {

            executionContext.getControl("dobnyc_tr6_initialunsafefilingdate").setVisible(true);

        }
    }

}


function HighlightchangeSetFields() {
    try {
        var formType = executionContext.ui.getFormType();
        if (formType != 1) {
            var entityName = executionContext.data.entity.getEntityName();
            var recordId = executionContext.data.entity.getId();
            recordId = recordId.replace("{", "").replace("}", "");
            //alert(recordId);
            var changesetRecords = null;

            if (entityName == EntityNames.TR6) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_TR6/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_tr6_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }
            if (entityName == EntityNames.FISP1) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_FISP1/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_fisp1_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }
            if (entityName == EntityNames.FISP2) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_FISP2/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_fisp2_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }
            if (entityName == EntityNames.PSR) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_PSR/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_psr_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }
            if (entityName == EntityNames.CNR) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_CNR/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_cnr_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }
            if (entityName == EntityNames.SCR) {
                //changesetRecords = retrieveMultipleCustom("dobnyc_facadeschangesetSet", "?select=dobnyc_FieldSchemaName&$filter=dobnyc_facades_SCR/Id eq guid'" + recordId + "'");
                SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_facadeschangesets", "?$select=dobnyc_fieldschemaname&$filter=_dobnyc_facades_scr_value eq " + recordId, function (result) {
                    changesetRecords = result.value;
                }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });   
            }

            DOB.Dynamics365.HighlightChangesetFields(changesetRecords, "dobnyc_fieldschemaname");

            //if (changesetRecords) {
            //    if (changesetRecords.length > 0) {

            //        for (var i = 0; i < changesetRecords.length; i++) {
            //            //alert("aq");
            //            var attributename = changesetRecords[i].dobnyc_fieldschemaname;
            //            document.getElementById(attributename).style.color = "orange";
            //            document.getElementById(attributename).style.backgroundColor = "orange";
            //        }
            //    }
            //}

        }
    }
    catch (Exception) {
        alert(Exception);

    }
}

var StatusNameMapping = {
    "dobnyc_tr6": "dobnyc_tr6_reportstatus",
    "dobnyc_fispone": "dobnyc_f1_requeststatus",
    "dobnyc_fisptwo": "dobnyc_fisp2_requeststatus"
};


function HighlightNoGoodCheck() {    
    var formType = executionContext.ui.getFormType();    
    if (formType != 1) {
        var entityName = executionContext.data.entity.getEntityName();
        var entityStatusField = StatusNameMapping[entityName];
        var filingStatus = executionContext.getAttribute(entityStatusField).getValue();        
        if (DOB.Dynamics365.IsUCI()) {
            if ($("[data-id*='" + entityStatusField + "']", parent.document).length == 0) {
                setTimeout(HighlightNoGoodCheck, 2000);
                return;
            }
            if (filingStatus == 9 || filingStatus == 10 || filingStatus == 11) {
                $("[data-id*='" + entityStatusField + "']", parent.document).css("background-color", "red");
            }            
        }
        else {
            if (filingStatus == 9 || filingStatus == 10 || filingStatus == 11) {
                parent.document.getElementById(entityStatusField).style.color = "red";
                parent.document.getElementById(entityStatusField).style.backgroundColor = "red";
            }            
        }
    }
}
function checkSecurityRole() {
    var isValidRole = false;
    //get all security roles for the logged in user
    var currentUserRoles = Xrm.Utility.getGlobalContext().userSettings.securityRoles;
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == "System Administrator") {
            isValidRole = true;
            break;
        }

    }
    return isValidRole;
}

function GetRoleName(RoleId) {
    RoleId = RoleId.replace("{", "").replace("}", "");
    //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
    //var returnValue = retrieveMultipleCustom("RoleSet", "?select=Name&$filter=RoleId eq guid'" + RoleId + "'");
    var returnValue = null;
    SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "roles", "?$select=name&$filter=roleid eq " + RoleId, function (result) {
        returnValue = result.value;
    }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });  
    //get the role name
    if (returnValue != null && returnValue[0] != null) {
        // alert("Role name: " + returnValue[0].Name);
        return returnValue[0].name;
    }
}