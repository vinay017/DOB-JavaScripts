﻿using System;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using XRMWebServiceConnectionManager;
using System.Text;
using System.Security.Cryptography;
using System.ServiceModel;

namespace MigrateElevatorData
{
    public class CrmHandlerBase
    {

        #region Get Instance of service
        private static CrmServiceConnector crmServiceConnector = null;
        public static CrmServiceConnector GetCrmServiceConnectorInstance()
        {
            if (crmServiceConnector == null)
            {
                crmServiceConnector = new CrmServiceConnector();
            }
            return crmServiceConnector;
        }
        #endregion Get Instance of service

        public static WhoAmIResponse WhoAmI(string organizationName, bool useAdminCredentials)
        {
            try
            {
                var request = new WhoAmIRequest();

                GetCrmServiceConnectorInstance().Connect();

                return (WhoAmIResponse)GetCrmServiceConnectorInstance().CallExecuteMethod(request, organizationName, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static WhoAmIResponse WhoAmI()
        {
            try
            {
                return WhoAmI(null, false);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, bool useAdminCredentials)
        {
            try
            {
                return RetrieveMultiple(null, entityName, columnNames, conditions, null, logicalOperator, null, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, bool useAdminCredentials, int topcount)
        {
            try
            {
                return RetrieveMultiple(null, entityName, columnNames, conditions, null, logicalOperator, null, useAdminCredentials, topcount);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, bool useAdminCredentials, int topcount, bool isLock)
        {
            try
            {
                return RetrieveMultiple(null, entityName, columnNames, conditions, null, logicalOperator, null, useAdminCredentials, topcount, isLock);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, List<LinkEntity> relatedentities, bool useAdminCredentials)
        {
            try
            {
                return RetrieveMultiple(null, entityName, columnNames, conditions, logicalOperator, null, relatedentities, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string entityName, string[] columnNames, ConditionExpression[] conditions, OrderExpression[] orders, LogicalOperator logicalOperator, bool useAdminCredentials)
        {
            try
            {
                return RetrieveMultiple(null, entityName, columnNames, conditions, orders, logicalOperator, null, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string organizationName, string entityName, string[] columnNames, ConditionExpression[] conditions, LogicalOperator logicalOperator, PagingInfo pagingInfo, List<LinkEntity> relatedentities, bool useAdminCredentials)
        {
            try
            {
                var filterExpression = new FilterExpression();
                foreach (ConditionExpression ce in conditions)
                {
                    filterExpression.Conditions.Add(ce);
                }
                filterExpression.FilterOperator = logicalOperator;

                var temp = new ColumnSet();
                if (columnNames == null)
                    temp.AllColumns = true;
                else
                    temp.AddColumns(columnNames);


                var query = new QueryExpression
                {
                    EntityName = entityName,
                    ColumnSet = temp,
                    Criteria = filterExpression,
                    NoLock = true,
                };

                if (relatedentities != null)
                {
                    query.LinkEntities.AddRange(relatedentities);
                }

                return RetrieveMultiple(query, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string organizationName, string entityName, string[] columnNames, ConditionExpression[] conditions, OrderExpression[] orders, LogicalOperator logicalOperator, PagingInfo pagingInfo, bool useAdminCredentials)
        {
            try
            {
                var filterExpression = new FilterExpression();
                foreach (ConditionExpression ce in conditions)
                {
                    filterExpression.Conditions.Add(ce);
                }
                filterExpression.FilterOperator = logicalOperator;

                var temp = new ColumnSet();
                if (columnNames == null)
                    temp.AllColumns = true;
                else
                    temp.AddColumns(columnNames);

                var query = new QueryExpression
                {
                    EntityName = entityName,
                    ColumnSet = temp,
                    Criteria = filterExpression,
                    NoLock = true

                };

                if (orders != null)
                {
                    foreach (OrderExpression oe in orders)
                    {
                        query.Orders.Add(oe);
                    }
                }
                return RetrieveMultiple(query, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string organizationName, string entityName, string[] columnNames, ConditionExpression[] conditions, OrderExpression[] orders, LogicalOperator logicalOperator, PagingInfo pagingInfo, bool useAdminCredentials, int topCount)
        {
            try
            {
                var filterExpression = new FilterExpression();
                foreach (ConditionExpression ce in conditions)
                {
                    filterExpression.Conditions.Add(ce);
                }
                filterExpression.FilterOperator = logicalOperator;

                var temp = new ColumnSet();
                if (columnNames == null)
                    temp.AllColumns = true;
                else
                    temp.AddColumns(columnNames);

                var query = new QueryExpression
                {
                    EntityName = entityName,
                    ColumnSet = temp,
                    Criteria = filterExpression,
                    NoLock = true,
                    TopCount = topCount


                };

                if (orders != null)
                {
                    foreach (OrderExpression oe in orders)
                    {
                        query.Orders.Add(oe);
                    }
                }

                return RetrieveMultiple(query, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(string organizationName, string entityName, string[] columnNames, ConditionExpression[] conditions, OrderExpression[] orders, LogicalOperator logicalOperator, PagingInfo pagingInfo, bool useAdminCredentials, int topCount, bool isLock)
        {
            try
            {

                var filterExpression = new FilterExpression();
                foreach (ConditionExpression ce in conditions)
                {
                    filterExpression.Conditions.Add(ce);
                }
                filterExpression.FilterOperator = logicalOperator;

                var temp = new ColumnSet();
                if (columnNames == null)
                    temp.AllColumns = true;
                else
                    temp.AddColumns(columnNames);

                var query = new QueryExpression
                {
                    EntityName = entityName,
                    ColumnSet = temp,
                    Criteria = filterExpression,
                    NoLock = isLock,
                    TopCount = topCount


                };

                if (orders != null)
                {
                    foreach (OrderExpression oe in orders)
                    {
                        query.Orders.Add(oe);
                    }
                }

                return RetrieveMultiple(query, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection FetchMultiple(string fetchXml, bool useAdminCredentials)
        {
            try
            {
                var query = new FetchExpression(fetchXml);
                return RetrieveMultiple(query, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityCollection RetrieveMultiple(QueryBase query, Boolean useAdminCredential)
        {
            try
            {
                return GetCrmServiceConnectorInstance().CallRetrieveMultipleMethod(query, useAdminCredential);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public static Entity Retrieve(EntityReference entity, string idFieldName, Boolean useAdminCredential)
        //{
        //    try
        //    {
        //        var query = new QueryExpression(entity.LogicalName);
        //        query.ColumnSet = new ColumnSet(true);
        //        var filter = new FilterExpression();
        //        filter.Conditions.Add(new ConditionExpression(idFieldName, ConditionOperator.Equal, entity.Id));
        //        query.Criteria = filter;
        //        return RetrieveMultiple(query, useAdminCredential).Entities[0];
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        throw ex;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public static Entity RetrieveSingleWithMultipleCondition(string entityName, string[] columns, Boolean useAdminCredential, ConditionExpression[] conditionArray)
        {
            Entity responseEntity = null;

            try
            {
                EntityCollection responseEntityCollection = RetrieveMultiple(entityName, columns, conditionArray, LogicalOperator.And, true, 1, false);
                if (responseEntityCollection.Entities.Count > 0)
                    responseEntity = responseEntityCollection.Entities[0];
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return responseEntity;
        }

        //public static Entity Retrieve(string entityName, string[] columns, ConditionExpression[] conditions,  LogicalOperator logicalOperator, Boolean useAdminCredential)
        //{
        //    try
        //    {
        //        var filterExpression = new FilterExpression();
        //        foreach (ConditionExpression ce in conditions)
        //        {
        //            filterExpression.Conditions.Add(ce);
        //        }
        //        filterExpression.FilterOperator = logicalOperator;

        //        var temp = new ColumnSet();
        //        if (columns == null)
        //            temp.AllColumns = true;
        //        else
        //            temp.AddColumns(columns);

        //        var query = new QueryExpression
        //        {
        //            EntityName = entityName,
        //            ColumnSet = temp,
        //            Criteria = filterExpression,
        //            NoLock = true,
        //            TopCount = 1


        //        };

        //        return RetrieveMultiple(query, useAdminCredential).Entities[0];

        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        throw ex;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}
        public static Entity Retrieve(string entityName, Guid id, string[] columns, Boolean useAdminCredential)
        {
            try
            {
                var entityColumns = (columns == null) ? new ColumnSet(true) : new ColumnSet(columns);
                return GetCrmServiceConnectorInstance().CallRetrieveMethod(entityName, id, new ColumnSet(columns), string.Empty, useAdminCredential);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static OrganizationResponse CallExecuteMethod(OrganizationRequest request)
        {
            try
            {
                return CallExecuteMethod(request, null, false);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static OrganizationResponse CallExecuteMethod(OrganizationRequest request, bool useAdminCredentials)
        {
            try
            {
                return CallExecuteMethod(request, null, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected static OrganizationResponse CallExecuteMethod(OrganizationRequest request, string organizationName, bool useAdminCredentials)
        {
            try
            {
                GetCrmServiceConnectorInstance().Connect(useAdminCredentials);
                return GetCrmServiceConnectorInstance().CallExecuteMethod(request, organizationName, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Guid CallCreateMethod(Entity request)
        {
            try
            {
                return CallCreateMethod(request, null, true);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Guid CallCreateMethod(Entity request, bool useAdminCredentials)
        {
            try
            {
                return CallCreateMethod(request, null, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected static Guid CallCreateMethod(Entity request, string organizationName, bool useAdminCredentials)
        {
            try
            {
                GetCrmServiceConnectorInstance().Connect(useAdminCredentials);
                return GetCrmServiceConnectorInstance().CallCreateMethod(request, organizationName, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void CallUpdateMethod(Entity request)
        {
            try
            {
                CallUpdateMethod(request, null, false);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void CallUpdateMethod(Entity request, bool useAdminCredentials)
        {
            try
            {
                CallUpdateMethod(request, null, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected static void CallUpdateMethod(Entity request, string organizationName, bool useAdminCredentials)
        {
            try
            {
                GetCrmServiceConnectorInstance().Connect(useAdminCredentials);
                GetCrmServiceConnectorInstance().CallUpdateMethod(request, organizationName, useAdminCredentials);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int GetEntityTypeCode(string p)
        {
            try
            {
                RetrieveEntityRequest entityRequest = new RetrieveEntityRequest
                {
                    LogicalName = p,
                    RetrieveAsIfPublished = false
                };
                GetCrmServiceConnectorInstance().Connect();
                RetrieveEntityResponse response = (RetrieveEntityResponse)GetCrmServiceConnectorInstance().CallExecuteMethod(entityRequest, string.Empty, true);
                EntityMetadata entityMetadata = response.EntityMetadata;
                if (entityMetadata.ObjectTypeCode.HasValue)
                    return entityMetadata.ObjectTypeCode.Value;
                else
                    return int.MinValue;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected static ConditionExpression CreateConditionExpression(string attributeName, ConditionOperator conditionOperator, object[] conditionValues)
        {
            try
            {
                ConditionExpression conditionExpression = new ConditionExpression();
                conditionExpression.AttributeName = attributeName;
                conditionExpression.Operator = conditionOperator;

                if (conditionValues != null)
                {
                    foreach (object o in conditionValues)
                        conditionExpression.Values.Add(o);
                }
                return conditionExpression;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string GetOptionSetValueLabel(string entityName, string fieldName, OptionSetValue option)
        {
            try
            {
                string optionLabel = String.Empty;

                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest
                {
                    EntityLogicalName = entityName,
                    LogicalName = fieldName,
                    RetrieveAsIfPublished = true
                };

                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)CallExecuteMethod(attributeRequest, false);
                AttributeMetadata attrMetadata = (AttributeMetadata)attributeResponse.AttributeMetadata;
                PicklistAttributeMetadata picklistMetadata = (PicklistAttributeMetadata)attrMetadata;

                // For every status code value within all of our status codes values
                //  (all of the values in the drop down list)
                foreach (OptionMetadata optionMeta in
                    picklistMetadata.OptionSet.Options)
                {
                    // Check to see if our current value matches
                    if (optionMeta.Value == option.Value)
                    {
                        // If our numeric value matches, set the string to our status code
                        //  label
                        optionLabel = optionMeta.Label.UserLocalizedLabel.Label;
                        break;
                    }
                }

                return optionLabel;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityMetadata GetEntityMetadata(string entityName)
        {
            try
            {
                RetrieveEntityRequest entityRequest = new RetrieveEntityRequest
                {
                    EntityFilters = EntityFilters.Entity,
                    LogicalName = entityName
                };

                RetrieveEntityResponse entityResponse = (RetrieveEntityResponse)CallExecuteMethod(entityRequest, true);
                return entityResponse.EntityMetadata;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityMetadata GetEntityMetadataWithAttributes(string entityName)
        {
            try
            {
                RetrieveEntityRequest entityRequest = new RetrieveEntityRequest
                {
                    EntityFilters = EntityFilters.All,
                    LogicalName = entityName
                };

                RetrieveEntityResponse entityResponse = (RetrieveEntityResponse)CallExecuteMethod(entityRequest, true);
                return entityResponse.EntityMetadata;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static EntityMetadata[] GetAllEntitiesMetadata()
        {
            try
            {
                RetrieveAllEntitiesRequest allEntitiesRequest = new RetrieveAllEntitiesRequest
                {
                    EntityFilters = EntityFilters.Entity,
                };

                RetrieveAllEntitiesResponse allEntitiesResponse = (RetrieveAllEntitiesResponse)CallExecuteMethod(allEntitiesRequest, true);
                return allEntitiesResponse.EntityMetadata;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static AttributeMetadata GetAttributeMetadata(string entityName, string fieldName)
        {
            try
            {
                RetrieveAttributeRequest attributeRequest = new RetrieveAttributeRequest
                {
                    EntityLogicalName = entityName,
                    LogicalName = fieldName,
                    RetrieveAsIfPublished = true
                };
                RetrieveAttributeResponse attributeResponse = (RetrieveAttributeResponse)CallExecuteMethod(attributeRequest, true);
                return attributeResponse.AttributeMetadata;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void AssignRecord(Guid ownerId, string ownerType, string targetEntityName, Guid targetId)
        {
            try
            {
                AssignRequest assignRequest = new AssignRequest();
                assignRequest.Assignee = new EntityReference(ownerType, ownerId);
                assignRequest.Target = new EntityReference(targetEntityName, targetId);
                CallExecuteMethod(assignRequest, true);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void AddToQueue(Guid sourceQueueId, Guid destinationQueueId, string targetEntityName, Guid targetId)
        {
            try
            {
                AddToQueueRequest routeRequest = null;
                if (sourceQueueId != Guid.Empty)
                {
                    routeRequest = new AddToQueueRequest
                    {
                        SourceQueueId = sourceQueueId,
                        Target = new EntityReference(targetEntityName, targetId),
                        DestinationQueueId = destinationQueueId
                    };
                }
                else
                {
                    routeRequest = new AddToQueueRequest
                    {
                        Target = new EntityReference(targetEntityName, targetId),
                        DestinationQueueId = destinationQueueId
                    };
                }
                CallExecuteMethod(routeRequest, true);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EntityCollection GetEntityData(string entityName, List<KeyValuePair<string, object>> constraintKeyFields, List<string> keyFieldName)
        {
            try
            {
                QueryExpression query = new QueryExpression();
                query.EntityName = entityName;
                query.Distinct = false;
                query.NoLock = true;

                query.ColumnSet = new ColumnSet();

                if (keyFieldName == null)
                {
                    /// Retrieve all columns
                    query.ColumnSet.AllColumns = true;
                }
                else if (keyFieldName.Count == 0)
                {
                    /// Retrieve all columns
                    query.ColumnSet.AllColumns = true;
                }
                else
                {
                    /// Retrieve requested columns
                    query.ColumnSet.Columns.AddRange(keyFieldName.ToArray());
                }

                if (constraintKeyFields.Count != 0)
                {
                    query.Criteria = new FilterExpression();

                    query.Criteria.FilterOperator = LogicalOperator.And;

                    for (int i = 0; i < constraintKeyFields.Count; i++)
                    {
                        ConditionExpression expression = new ConditionExpression();

                        expression.AttributeName = constraintKeyFields[i].Key.ToString();
                        expression.Operator = ConditionOperator.Equal;
                        expression.Values.Add(constraintKeyFields[i].Value);
                        query.Criteria.AddCondition(expression);
                        query.NoLock = true;

                    }
                }
                EntityCollection entityColl = RetrieveMultiple(query, true);
                return entityColl;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EntityCollection GetAccountOfficerData(string entityName, List<KeyValuePair<string, object>> constraintKeyFields, List<string> keyFieldName)
        {
            try
            {
                QueryExpression query = new QueryExpression();
                query.EntityName = entityName;
                query.Distinct = false;
                query.NoLock = true;

                query.ColumnSet = new ColumnSet();

                if (keyFieldName == null)
                {
                    /// Retrieve all columns
                    query.ColumnSet.AllColumns = true;
                }
                else if (keyFieldName.Count == 0)
                {
                    /// Retrieve all columns
                    query.ColumnSet.AllColumns = true;
                }
                else
                {
                    /// Retrieve requested columns
                    query.ColumnSet.Columns.AddRange(keyFieldName.ToArray());
                }

                LinkEntity subjectLinkEntity = new LinkEntity(entityName, "systemuser", "vrp_accountofficeruser", "systemuserid", JoinOperator.Inner);
                subjectLinkEntity.EntityAlias = "systemuser";
                subjectLinkEntity.Columns = new ColumnSet(true);
                query.LinkEntities.Add(subjectLinkEntity);

                if (constraintKeyFields.Count != 0)
                {
                    query.Criteria = new FilterExpression();

                    query.Criteria.FilterOperator = LogicalOperator.And;

                    for (int i = 0; i < constraintKeyFields.Count; i++)
                    {
                        ConditionExpression expression = new ConditionExpression();

                        expression.AttributeName = constraintKeyFields[i].Key.ToString();
                        expression.Operator = ConditionOperator.Equal;
                        expression.Values.Add(constraintKeyFields[i].Value);
                        query.Criteria.AddCondition(expression);
                    }
                }

                EntityCollection entityColl = RetrieveMultiple(query, true);

                return entityColl;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public static DataTable RetrieveDataTable(string connString, string sqlQuery)
        //{
        //    try
        //    {
        //        SqlConnection conn = new SqlConnection(connString);
        //        DataSet ds = new DataSet();
        //        conn.Open();
        //        SqlDataAdapter da = new SqlDataAdapter(sqlQuery, conn);
        //        da.Fill(ds, "datatable");
        //        DataTable dt = ds.Tables["datatable"];
        //        return dt;
        //    }
        //    catch (FaultException<OrganizationServiceFault> ex)
        //    {
        //        throw ex;
        //    }
        //    catch (TimeoutException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public static string EncryptPassword(string input)
        {
            try
            {
                StringBuilder strBuilder = new StringBuilder();
                var sha1 = SHA1Managed.Create();
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] outputBytes = sha1.ComputeHash(inputBytes);
                for (int i = 0; i < outputBytes.Length; i++)
                {
                    byte b = outputBytes[i];
                    int r = (int)b;
                    r = r & 255;
                    int r1 = r & 15;
                    int r2 = (int)((uint)r >> 4);
                    strBuilder.Append(r1.ToString("X")).Append(r2.ToString("X"));

                }
                return strBuilder.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string GetAttributeDisplayName(string entitySchemaName, string attributeSchemaName)
        {
            try
            {
                return GetCrmServiceConnectorInstance().GetAttributeDisplayName(entitySchemaName, attributeSchemaName);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void CreateRelatedEntites(EntityCollection collection)
        {
            ExecuteMultipleRequest requestWithResults = new ExecuteMultipleRequest()
            {
                Settings = new ExecuteMultipleSettings()
                {
                    ContinueOnError = true,
                    ReturnResponses = true
                },
                Requests = new OrganizationRequestCollection()
            };

            foreach (var entity in collection.Entities)
            {
                CreateRequest createRequest = new CreateRequest { Target = entity };
                requestWithResults.Requests.Add(createRequest);
            }

            ExecuteMultipleResponse responseWithResults = (ExecuteMultipleResponse)CallExecuteMethod(requestWithResults);

            foreach (var responseItem in responseWithResults.Responses)
            {

                if (responseItem.Response != null)
                {
                }
                else if (responseItem.Fault != null)
                {
                }
            }
        }
    }
}
