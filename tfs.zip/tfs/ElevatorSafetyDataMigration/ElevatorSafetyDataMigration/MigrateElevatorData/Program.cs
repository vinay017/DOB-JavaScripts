﻿using ExternalSystemIntegration;
using ExternalSystemIntegration.Objects;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Text;

namespace MigrateElevatorData
{
    public class Program : CrmHandlerBase
    {
        static void Main(string[] args)
        {
            StringBuilder crmTrace = new StringBuilder();
            try
            {
                string ConnectionString = "Data Source=sdevmsap05-2mt;Initial Catalog=MAF;User Id=Buildings\\svc-crmsqldev;Password=1qaz!QAZ;Trusted_Connection=Yes;";
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    #region Geting data from db
                    //string query = @"SELECT 
                    //                    DeviceGuid,
                    //                    DeviceBorough,
                    //                    DeviceHouseNumber,
                    //                    DeviceStreet,
                    //                    DeviceBin,
                    //                    DeviceBlock,
                    //                    DeviceLot,
                    //                    DeviceZip,
                    //                    IN_INSP_DISP,
                    //                    IN_INSP_TYPE,
                    //                    case when IN_INSP_DATE='' then '' else  case when LEN(IN_INSP_DATE)=8 and ISNUMERIC(IN_INSP_DATE)=1 then cast( IN_INSP_DATE as date)  else '' end end  as [InspectionDate],
                    //                     case when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='P' or SUBSTRING(IN_DEVICE_NUMBER,2,1) ='S' or SUBSTRING(IN_DEVICE_NUMBER,2,1) ='F' or SUBSTRING(IN_DEVICE_NUMBER,2,1) ='L' or SUBSTRING(IN_DEVICE_NUMBER,2,1) ='T' then 1 -- 'Elevator'  
                    //                                                         when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='D' then 1--'Dumbwaiter'
                    //                                                             when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='W' then 1-- 'Accessibility Lift'
                    //                                                              when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='M' then 1 --'Man Lift'
                    //                                                              when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='H' then  1--'Accessibility Lift'  /* 'Handicap Lifts' We have to Map all H to Accessibility lift Integration and portal should allow them to change between elavator an acessibility lift*/
                    //                                                              when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='E' then 1 -- 'Escalator'/* Moving Walk are also will be migrated as Escalator when user doing a  alteration we will dispaly a message to plan examiner this is data migration record if you want to switch the device type you can switch. Integration team should make visible both escalator an moving walk fields when doing it for first time alteration*/
                    //                                                              when SUBSTRING(IN_DEVICE_NUMBER,2,1) ='V' then  2--'Personal Hoist' /*User can switch between Personal Hoist ,Conveyor,Accessibility Lift*/
                    //                                                              end as [ReportType]
                    //                    FROM DOB_BIS_ELEV_INSPECT_1
                    //                    where IN_INSP_TYPE in ('1' , '3' , '5')";
                    string query = @"SELECT * FROM CAT1";
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    #endregion Geting data from db

                    crmTrace.AppendLine("CAT1 Applications");
                    #region Global varialbles


                    #endregion Global varialbles

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        crmTrace.AppendLine("CAT1 Applications start reader");
                        while (reader.Read())
                        {
                            getMasterDeviceEligibility(reader, (int)ELV3ReportType.ElevatorTestInspection, (int)ELV3InspectionType.CAT1, crmTrace);


                        }
                    }


                    crmTrace.AppendLine("PVT Applications");
                    query = @"SELECT * FROM PVTInspections";
                    command = new SqlCommand(query, connection);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        crmTrace.AppendLine("CAT1 Applications start reader");
                        while (reader.Read())
                        {
                            getMasterDeviceEligibility(reader, (int)ELV3ReportType.ElevatorTestInspection, (int)ELV3InspectionType.PVTInspection, crmTrace);


                        }
                    }


                    crmTrace.AppendLine("CAT5 Applications");
                    query = @"SELECT * FROM CAT5";
                    command = new SqlCommand(query, connection);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        crmTrace.AppendLine("CAT1 Applications start reader");
                        while (reader.Read())
                        {
                            getMasterDeviceEligibility(reader, (int)ELV3ReportType.ElevatorTestInspection, (int)ELV3InspectionType.CAT5, crmTrace);


                        }
                    }



                    /*   using (SqlDataReader reader = command.ExecuteReader())
                       {
                           while (reader.Read())
                           {
                               #region Elv 3 Data migration
                               if (reader["IN_INSP_TYPE"] != null && Convert.ToString(reader["IN_INSP_TYPE"]).IsValidString() &&
                                   Convert.ToString(reader["IN_INSP_TYPE"]) == "1" ||
                                   Convert.ToString(reader["IN_INSP_TYPE"]) == "3" ||
                                   Convert.ToString(reader["IN_INSP_TYPE"]) == "5")
                               {
                                   elv3Record = new Entity(Elv3AttributesNames.EntityLogicalName);
                                   elv3Record.Attributes.Add(Elv3AttributesNames.HouseNumber, Convert.ToString(reader["DeviceHouseNumber"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.StreetName, Convert.ToString(reader["DeviceStreet"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.BIN, Convert.ToString(reader["DeviceBin"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.Block, Convert.ToString(reader["DeviceBlock"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.Lot, Convert.ToString(reader["DeviceLot"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.ZipCode, Convert.ToString(reader["DeviceZip"]).Trim());
                                   elv3Record.Attributes.Add(Elv3AttributesNames.IsMigrated, true);
                                   elv3Record.Attributes.Add(Elv3AttributesNames.UserFillingAction, new OptionSetValue(3));

                                   if (reader["DeviceGuid"] != null && Convert.ToString(reader["DeviceGuid"]).IsValidString())
                                       elv3Record.Attributes.Add(Elv3AttributesNames.DeviceGuid, new EntityReference(MasterDeviceAttributeNames.EntityLogicalName, Guid.Parse(reader["DeviceGuid"].ToString())));

                                   date = string.Format("{0:yyyy/MM/dd}", reader["InspectionDate"]);
                                   if (reader["InspectionDate"] != null && date != "01/01/1900" && date != string.Empty && Convert.ToString(reader["InspectionDate"]).IsValidString())
                                   {
                                       date = string.Format("{0:yyyy/MM/dd}", reader["InspectionDate"]);
                                       elv3Record.Attributes.Add(Elv3AttributesNames.InspectionTestDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                                       if (Convert.ToString(reader["IN_INSP_TYPE"]) == "1")
                                           elv3Record.Attributes.Add(Elv3AttributesNames.FilingYear, date.Substring(0, 4));
                                   }

                                   if (Convert.ToString(reader["IN_INSP_TYPE"]) == "1")
                                   {
                                       elv3Record.Attributes.Add(Elv3AttributesNames.InspectionType, new OptionSetValue(1));
                                   }
                                   else if (Convert.ToString(reader["IN_INSP_TYPE"]) == "3")
                                   {
                                       elv3Record.Attributes.Add(Elv3AttributesNames.InspectionType, new OptionSetValue(2));
                                   }
                                   else if (Convert.ToString(reader["IN_INSP_TYPE"]) == "5")
                                   {
                                       elv3Record.Attributes.Add(Elv3AttributesNames.InspectionType, new OptionSetValue(3));
                                   }

                                   if (reader["DeviceBorough"] != null && Convert.ToString(reader["DeviceBorough"]).IsValidString())
                                       elv3Record.Attributes.Add(Elv3AttributesNames.Borough, new OptionSetValue(Convert.ToInt32(reader["DeviceBorough"])));

                                   if (reader["ReportType"] != null && Convert.ToString(reader["ReportType"]).IsValidString())
                                       elv3Record.Attributes.Add(Elv3AttributesNames.ReportType, new OptionSetValue(Convert.ToInt32(reader["ReportType"])));

                                   if (reader["IN_INSP_DISP"] != null && Convert.ToString(reader["IN_INSP_DISP"]).IsValidString() && Convert.ToString(reader["IN_INSP_DISP"]) == "DF")
                                   {
                                       elv3Record.Attributes.Add(Elv3AttributesNames.IsDefectsExist, true);
                                       elv3Record.Attributes.Add(Elv3AttributesNames.ReportStatus, new OptionSetValue(9));
                                   }
                                   else
                                   {
                                       elv3Record.Attributes.Add(Elv3AttributesNames.IsDefectsExist, false);
                                       elv3Record.Attributes.Add(Elv3AttributesNames.ReportStatus, new OptionSetValue(5));
                                   }

                                   CallCreateMethod(elv3Record);
                               }
                               #endregion Elv 3 Data migration
                           }
                       }*/

                    Console.WriteLine("Success" + crmTrace);
                    Console.ReadKey();

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("****Exception****");
                Console.WriteLine(ex.ToString());
                Console.ReadKey();
            }
            Console.WriteLine("DONE");
            Console.ReadKey();
        }



        public static void getMasterDeviceEligibility(SqlDataReader reader, int reportType, int inspectionType, StringBuilder crmTrace)
        {
            ConditionExpression condition1 = new ConditionExpression(ElevatorMasterDevice.DeviceNo, ConditionOperator.Equal, reader["DeviceNumber"]);
            ConditionExpression condition2 = new ConditionExpression(ElevatorMasterDevice.OldBISDeviceNumber, ConditionOperator.Equal, reader["DeviceNumber"]);
            EntityCollection masterDeviceCollection = RetrieveMultiple(ElevatorMasterDevice.EntityLogicalName, new string[] { ElevatorMasterDevice.DeviceStatus, ElevatorMasterDevice.DeviceType, ElevatorMasterDevice.LatestApplication, ElevatorMasterDevice.LatestMovingDevice, ElevatorMasterDevice.LatestRollingDevice }, new ConditionExpression[] { condition1, condition2 }, LogicalOperator.Or, true);
            crmTrace.AppendLine("masterDeviceCollection :" + masterDeviceCollection.Entities.Count);
            if (masterDeviceCollection != null && masterDeviceCollection.Entities.Count > 0)
            {
                foreach (Entity masterEntity in masterDeviceCollection.Entities)
                {
                    crmTrace.AppendLine("masterEntity :" + masterEntity.Id);
                    if (inspectionType == (int)ELV3InspectionType.CAT1 || inspectionType == (int)ELV3InspectionType.CAT5)
                    {
                        cat1EligibleDevices(masterEntity, reader, inspectionType, crmTrace);
                    }
                    createELV3Record(reader, reportType, inspectionType, masterEntity.Id, crmTrace);
                }
            }
        }

        public static void createELV3Record(SqlDataReader reader, int reportType, int inspectionType, Guid deviceId, StringBuilder crmTrace)
        {
            string date = string.Empty;
            Entity elv3Record = new Entity(Elv3AttributesNames.EntityLogicalName);

            if (deviceId != null)
                elv3Record.Attributes.Add(Elv3AttributesNames.DeviceIdLookup, new EntityReference(ElevatorMasterDevice.EntityLogicalName, deviceId));

            if(inspectionType==(int)ELV3InspectionType.CAT5)
            {
                date = string.Format("{0:yyyy/MM/dd}", reader["LastInspectionDate"]);
                if (reader["LastInspectionDate"] != null && date != "01/01/1900" && date != string.Empty && Convert.ToString(reader["LastInspectionDate"]).IsValidString())
                {
                    date = string.Format("{0:yyyy/MM/dd}", reader["LastInspectionDate"]);
                    elv3Record.Attributes.Add(Elv3AttributesNames.InspectionDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                   
                }
            }

            else
            {
                date = string.Format("{0:yyyy/MM/dd}", reader["InspectionDate"]);
                if (reader["InspectionDate"] != null && date != "01/01/1900" && date != string.Empty && Convert.ToString(reader["InspectionDate"]).IsValidString())
                {
                    date = string.Format("{0:yyyy/MM/dd}", reader["InspectionDate"]);
                    elv3Record.Attributes.Add(Elv3AttributesNames.InspectionDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                    if (inspectionType == (int)ELV3InspectionType.CAT1)
                        elv3Record.Attributes.Add(Elv3AttributesNames.ReportYear, date.Substring(0, 4));
                }
            }
            

            elv3Record.Attributes.Add(Elv3AttributesNames.InspectionType, new OptionSetValue(inspectionType));

            elv3Record.Attributes.Add(Elv3AttributesNames.ReportType, new OptionSetValue(reportType));

            if ((inspectionType==(int)ELV3InspectionType.CAT1 ||inspectionType==(int)ELV3InspectionType.PVTInspection) && reader["Defects"] != null && Convert.ToBoolean(reader["Defects"]))
            {
                elv3Record.Attributes.Add(Elv3AttributesNames.IsDefectsExist, true);
                elv3Record.Attributes.Add(Elv3AttributesNames.ReportStatus, new OptionSetValue(9));
            }
            else
            {
                elv3Record.Attributes.Add(Elv3AttributesNames.IsDefectsExist, false);
                elv3Record.Attributes.Add(Elv3AttributesNames.ReportStatus, new OptionSetValue(5));
            }
            elv3Record.Attributes.Add(Elv3AttributesNames.UserFilingActions, new OptionSetValue((int)ELV3UserFilingActions.File));
            elv3Record.Attributes.Add(Elv3AttributesNames.SubmissionDate, DateTime.Now);

            CallCreateMethod(elv3Record);
        }

        public static void cat1EligibleDevices(Entity masterDevice, SqlDataReader reader, int inspectionType, StringBuilder crmTrace)
        {
            Entity updateMaster = new Entity(ElevatorMasterDevice.EntityLogicalName);
            string date = string.Empty;

            switch (inspectionType)
            {
                case (int)ELV3InspectionType.CAT1:
                    {
                        switch (masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceType).Value)
                        {
                            case (int)ElevatorDeviceTypes.Elevator:
                            case (int)ElevatorDeviceTypes.Escalator:
                            case (int)ElevatorDeviceTypes.Conveyor:
                            case (int)ElevatorDeviceTypes.Dumbwaiter:
                            case (int)ElevatorDeviceTypes.Manlift:
                            case (int)ElevatorDeviceTypes.MovingWalk:
                            case (int)ElevatorDeviceTypes.AccessibilityLift:
                                {
                                    if (checkDeviceStatus(masterDevice))
                                    {
                                        crmTrace.AppendLine("set all fields on master device");
                                        crmTrace.AppendLine("ELV3InspectionType.CAT1 Satrt ");
                                        updateMaster.Attributes.Add(ElevatorMasterDevice.CAT1ReportYear, Convert.ToString(reader["ReportYear"]));
                                        date = string.Format("{0:yyyy/MM/dd}", reader["InspectionDate"]);

                                        updateMaster.Attributes.Add(ElevatorMasterDevice.CAT1LatestReportFileDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                                        updateMaster.Attributes.Add(ElevatorMasterDevice.IsCat1Eligible, true);
                                        updateMaster.Id = masterDevice.Id;

                                    }


                                    break;

                                }



                        }
                        break;
                    }
                case (int)ELV3InspectionType.CAT5:
                    {
                        switch (masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceType).Value)
                        {
                            case (int)ElevatorDeviceTypes.Elevator:

                            case (int)ElevatorDeviceTypes.AccessibilityLift:
                            case (int)ElevatorDeviceTypes.Dumbwaiter:

                                {

                                    if (masterDevice.Contains(ElevatorMasterDevice.LatestApplication) && masterDevice[ElevatorMasterDevice.LatestApplication] != null && masterDevice.GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestApplication).Id != null)
                                    {
                                        //get the latest moving details and check the machine type 
                                        if (masterDevice.Contains(ElevatorMasterDevice.LatestMovingDevice) && masterDevice[ElevatorMasterDevice.LatestMovingDevice] != null && masterDevice.GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestMovingDevice).Id != null)
                                        {
                                            Entity movingEntity = Retrieve(ElevatorMovingTypeAttributeNames.EntityLogicalName, masterDevice.GetAttributeValue<EntityReference>(ElevatorMasterDevice.LatestMovingDevice).Id, new string[] { ElevatorMovingTypeAttributeNames.MachineType },true);
                                            if (movingEntity != null && movingEntity.Contains(ElevatorMovingTypeAttributeNames.MachineType) && movingEntity[ElevatorMovingTypeAttributeNames.MachineType] != null)
                                            {
                                                if (movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.MachineType).Value == 2 || movingEntity.GetAttributeValue<OptionSetValue>(ElevatorMovingTypeAttributeNames.MachineType).Value == 6) //machine type= traction or roped-hydrualic
                                                {
                                                    if (checkDeviceStatus(masterDevice))
                                                    {
                                                        crmTrace.AppendLine("alteration appliaction in build andd changed the machine type with correct machine type values");
                                                        crmTrace.AppendLine("ELV3InspectionType.CAT5 Satrt ");

                                                        date = string.Format("{0:yyyy/MM/dd}", reader["LastInspectionDate"]);

                                                        updateMaster.Attributes.Add(ElevatorMasterDevice.CAT5LatestReportFileDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                                                        DateTime tempNextCycleEndDate = DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture).AddYears(5);
                                                        DateTime CAT5NextCycleEndDate = new DateTime(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month, DateTime.DaysInMonth(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month));//set the end cycle to the last day of that month
                                                        updateMaster.Attributes.Add(ElevatorMasterDevice.CAT5NextCycleEndDate, CAT5NextCycleEndDate);
                                                        updateMaster.Attributes.Add(ElevatorMasterDevice.IsCat5Eligible, true);
                                                        updateMaster.Id = masterDevice.Id;

                                                    }
                                                }
                                                else
                                                {
                                                    crmTrace.AppendLine("User created a alteration appliaction in build andd changed the machine type ");
                                                    updateMaster.Attributes.Add(ElevatorMasterDevice.IsCat5Eligible, false);
                                                    updateMaster.Id = masterDevice.Id;
                                                }
                                            }


                                        }

                                    }
                                    else
                                    {
                                        if (checkDeviceStatus(masterDevice))
                                        {
                                            crmTrace.AppendLine("set all fields on master device");
                                            crmTrace.AppendLine("ELV3InspectionType.CAT5 Satrt ");

                                            date = string.Format("{0:yyyy/MM/dd}", reader["LastInspectionDate"]);

                                            updateMaster.Attributes.Add(ElevatorMasterDevice.CAT5LatestReportFileDate, DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture));
                                            DateTime tempNextCycleEndDate = DateTime.ParseExact(date, "yyyy/MM/dd", CultureInfo.InvariantCulture).AddYears(5);
                                            DateTime CAT5NextCycleEndDate = new DateTime(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month, DateTime.DaysInMonth(tempNextCycleEndDate.Year, tempNextCycleEndDate.Month));//set the end cycle to the last day of that month
                                            updateMaster.Attributes.Add(ElevatorMasterDevice.CAT5NextCycleEndDate, CAT5NextCycleEndDate);
                                            updateMaster.Attributes.Add(ElevatorMasterDevice.IsCat5Eligible, true);
                                            updateMaster.Id = masterDevice.Id;

                                        }
                                    }




                                    break;

                                }





                        }
                        break;
                    }
            }


            CallUpdateMethod(updateMaster, true);
        }

        public static bool checkDeviceStatus(Entity masterDevice)
        {
            if (masterDevice.Contains(ElevatorMasterDevice.DeviceStatus) && masterDevice[ElevatorMasterDevice.DeviceStatus] != null &&
                (masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value == (int)ElevatorDeviceStatus.Active ||
                masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value == (int)ElevatorDeviceStatus.HousingAuthority ||
                masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value == (int)ElevatorDeviceStatus.NoJurisdiction ||
                masterDevice.GetAttributeValue<OptionSetValue>(ElevatorMasterDevice.DeviceStatus).Value == (int)ElevatorDeviceStatus.Sealed))
            {
                return true;
            }
            return false;
        }
    }
}


#region Entity Attributes Names

//This class is used to store all field names of Elevator Master Device

public enum ELV3InspectionType : int
{
    CAT1 = 1,
    CAT3 = 2,
    CAT5 = 3,
    HoistJumpUP = 4,
    HoistJumpDown = 5,
    NinetyDayTempRenewal = 6,
    PVTInspection = 7,
    QCInspection = 8


}

public enum ELV3ReportType : int
{
    ElevatorTestInspection = 1,
    PersonnelHoistTestInspection = 2


}

public enum OwnerType : int
{
    Private = 1,
    CityownedNonNYCHA = 2,
    NYCHA = 3,
    State = 4,
    Federal = 5,
    Diplomat = 6,
    NonprofitTaxExempt = 7
}

public enum ELV3ReportStatus : int
{
    Prefiling = 1,
    QASupervisorReview = 2,
    QAReview = 3,
    QAFailed = 4,
    Accepted = 5,
    Incomplete = 6,
    PrefilingPendingPayment = 7,
    AcceptedDefects = 9,
    RejectedFilingDue = 10,
    PaymentVerification = 11,
    NoGoodCheck = 12,
    NRF = 13,
    AcceptedCorrectionsViolationDismissed = 14,
    AcceptedCorrectionsViolationNotDismissed = 15,
    Received = 16,
    CorrectionsAccepted = 17,





}

public enum ELV3RevertedFromIncompleteSubmission : int
{

    QASupervisorReview = 1,
    QAReview = 2,
    None = 3,

}

public enum PaymentMethod : int
{

    Check = 1,
    CreditCard = 2,


}
public enum ELV3UserFilingActions : int
{

    Save = 1,
    CalculateCivilPenality = 2,
    File = 3,

}



public enum ElevatorDeviceStatus : int
{
    Active = 1,
    Dismantled = 2,
    Removed = 3,
    Deleted = 4,
    Sealed = 5,
    NoJurisdiction = 6,
    HousingAuthority = 7,
    WorkinProgress = 8,
    Withdrawn = 9,
}
public enum ElevatorDeviceTypes : int
{
    Elevator = 1,
    Escalator = 2,
    MovingWalk = 3,
    PersonnelHoist = 4,
    Dumbwaiter = 5,
    AccessibilityLift = 6,
    Conveyor = 7,
    // Sidewalk = 8,
    Manlift = 8,
    Others = 9,
}

public enum ElevatorAccessibilityLiftType : int
{
    PlatformLift = 1,
    StairwayChairlift = 2
}

public sealed class ElevatorMovingTypeAttributeNames
{

    public const string TempTarckingNumber = "dobnyc_mv_devicetemptrackingnumber";
    public const string EntityLogicalName = "dobnyc_elv1elevator";
    public const string Name = "dobnyc_name";
    public const string DeviceType = "dobnyc_mv_elevatordevicetype";
    public const string ELV1Filling = "dobnyc_elv_regardingapplication";
    public const string DeviceStatus = "dobnyc_elv_devicestatus";
    public const string DevicePhysicalAddress = "dobnyc_mv_devicephysicaladdress";
    public const string PlungerTypes = "dobnyc_elv_plungertypes";
    public const string GEElevatorPassengerType = "dobnyc_mv_elevatorpassengertype";
    public const string Elv1elevatorid = "dobnyc_elv1elevatorid";
    public const string ElevatorSubDeviceType = "dobnyc_mv_elevatortype";
    public const string AccessbilitySubDeviceType = "dobnyc_mv_accessibilitylift";
    public const string AccessbilityStairwaySubDeviceType = "dobnyc_mv_stairwaychairlifttype";
    public const string AccessbilityPlatformSubDeviceType = "dobnyc_mv_platformlifttype";
    public const string MachineType = "dobnyc_machinetype";
}

public sealed class ElevatorMasterDevice
{
    public const string HouseNo = "dobnyc_housenumber";
    public const string EntityLogicalName = "dobnyc_elevatordevice";
    public const string EntityId = "dobnyc_elevatordeviceid";
    public const string StreetName = "dobnyc_streetname";
    public const string Borough = "dobnyc_borough";
    public const string Lot = "dobnyc_mas_lot";
    public const string Block = "dobnyc_mas_block";
    public const string BIN = "dobnyc_mas_bin";
    public const string Zip = "dobnyc_mas_zipcode";
    public const string FloorFrom = "dobnyc_floorfrom";
    public const string FloorTo = "dobnyc_floorto";
    public const string BISTravelDistance = "dobnyc_bis_traveldistance";
    public const string BISCarEntrances = "dobnyc_bis_carentrances";
    public const string BISSpeed = "dobnyc_bis_speed";
    public const string Capacity = "dobnyc_capacity";
    public const string DeviceNo = "dobnyc_devicenumber";
    public const string DeviceType = "dobnyc_devicetype";
    public const string DeviceStatus = "dobnyc_bis_devicestatus";
    public const string IsCreatedFromNI = "dobnyc_elm_iscreatedfromnewinstallation";
    public const string IsCreatedFromAL = "dobnyc_elm_iscreatedfromalteration";
    public const string DevicePhysicalAddress = "dobnyc_mas_devicephysicaladdress";
    public const string LatestMovingDevice = "dobnyc_latestmovingdeviceversion";
    public const string LatestRollingDevice = "dobnyc_latestrollingdeviceversion";
    public const string LatestApplication = "dobnyc_latestapplication";
    public const string RollingDeviceRelationship = "dobnyc_elevatordevice__elv1escalator_MasterChild";
    public const string MovingDeviceRelationship = "dobnyc_elevatordevice_elv1elevator_MasterChild";
    public const string ApplicationRelationship = "dobnyc_dobnyc_elevatordevice_dobnyc_elevatorappl";
    public const string BISHoistRopesQuantity = "dobnyc_bis_hoistropesquanity";
    public const string BISHoistRopesSize = "dobnyc_bis_hoistropessize";
    public const string BISHoistRopesKind = "dobnyc_bis_hoistropeskind";
    public const string BISCarCounterweightRopesQuantity = "dobnyc_bis_carcounterweightropesquantity";
    public const string BISCarCounterweightRopesSize = "dobnyc_bis_carcounterweightropessize";
    public const string BISCarCounterweightRopesKind = "dobnyc_bis_carcounterweightropeskind";
    public const string BISMachineCounterweightRopesQuantity = "dobnyc_bis_machinecounterweightropesquantity";
    public const string BISMachineCounterweightRopesSize = "dobnyc_bis_machinecounterweightropessize";
    public const string BISMachineCounterweightRopesKind = "dobnyc_bis_machinecounterweightropeskind";
    public const string BISBackdrumRopesQuantity = "dobnyc_bis_backdrumropesquantity";
    public const string BISBackdrumRopesSize = "dobnyc_bis_backdrumropessize";
    public const string BISBackdrumRopesKind = "dobnyc_bis_backdrumropeskind";
    public const string BISGovernorRopesQuantity = "dobnyc_bis_governorropesquantity";
    public const string BISGovernorRopesSize = "dobnyc_bis_governorropessize";
    public const string BISGovernorRopesKind = "dobnyc_bis_governorropeskind";
    public const string BISManufacturer = "dobnyc_bis_manufacturer";
    public const string BISAlterationDate = "dobnyc_bis_alterationdate";

    public const string BISGovernorType = "dobnyc_bis_governortype";
    public const string BISMachineType = "dobnyc_bis_machinetype";
    public const string BISCarBufferType = "dobnyc_bis_carbuffertype";
    public const string BISSafetyType = "dobnyc_bis_safetytype";
    public const string ISDeviceNumberChanged = "dobnyc_mas_isdevicenumberchangedalteration";
    public const string OldBISDeviceNumber = "dobnyc_mas_oldbisnycdeviceid";
    public const string InFlight = "dobnyc_inflight";
    public const string LatestPermitIssuedDate = "dobnyc_latestpermitissueddate";
    public const string IsThisDataMigrationRecord = "dobnyc_mas_isthisdatamigrationrecord";
    public const string IsThisDataMigrationDev = "dobnyc_mas_isthisdatamigrationdev";
    public const string IsCat1Eligible = "dobnyc_els_iscat1eligible";
    public const string IsCat5Eligible = "dobnyc_els_iscat5eligible";

    //add status date (on sign-off) & approval date (on new master device creation); 
    public const string StatusDate = "dobnyc_statusdate";
    public const string ApprovalDate = "dobnyc_approvaldate";
    public const string PH_TempRenewalExpiry = "dobnyc_els_personalhoisttemprenewalexpiry";
    public const string CAT1ReportYear = "dobnyc_els_cat1reportyear";
    public const string CAT1LatestReportFileDate = "dobnyc_els_cat1latestreportfileddate";
    public const string CAT3LatestReportFileDate = "dobnyc_els_cat3latestreportfileddate";
    public const string CAT5LatestReportFileDate = "dobnyc_els_cat5latestreport";
    public const string personalHoistTempRenewal = "dobnyc_els_personalhoisttemprenewalexpiry";
    public const string CAT5NextCycleEndDate = "dobnyc_els_cat5nextcycleenddate";
}

//This Class is used to store all the field names of ELV3.
public sealed class Elv3AttributesNames
{
    public const string EntityLogicalName = "dobnyc_elv3";
    public const string ELV3Id = "dobnyc_elv3id";
    public const string Name = "dobnyc_name";
    public const string AmountPaid = "dobnyc_elv3_amountpaid";
    public const string Adjustment = "dobnyc_elv3_adjustment";
    public const string AmountDue = "dobnyc_elv3_amountdue";
    public const string FilingFee = "dobnyc_elv3_filingfee";
    public const string LateFilingFee = "dobnyc_elv3_latefilingfee";
    public const string ELV3NRFFee = "dobnyc_elv3_elv3nrffee";
    public const string ELV29NRFFee = "dobnyc_elv3_elv29nrffee";
    public const string Totalfee = "dobnyc_elv3_totalfee";
    public const string BIN = "dobnyc_bin";
    public const string InspectionType = "dobnyc_inspectiontype";
    public const string Issubmitted = "dobnyc_elv3_issubmitted";
    public const string IsFilingFeePaid = "dobnyc_elv3_isfilingfeepaid";
    public const string IsLateFilingFeePaid = "dobnyc_elv3_islatefilingfeepaid";
    public const string InspectionDate = "dobnyc_inspectiontestdate";
    public const string DeviceIdLookup = "dobnyc_elv3_elevatorid";
    public const string OwnerType = "dobnyc_owner_type";
    public const string ReportYear = "dobnyc_filingyear";
    public const string TrackingNumber = "dobnyc_trackingnumber";
    public const string ReportStatus = "dobnyc_elv3_reportstatus";
    public const string RevertedIncompleteSubmission = "dobnyc_revertedtoincompletesubmissionform";
    public const string FilingDate = "dobnyc_elv3_submissiondate";
    public const string QASupervisorReviewDate = "dobnyc_elv3_qasupervisorreviewdate";
    public const string QAReviewDate = "dobnyc_elv3_qareviewdate";
    public const string QAFailedDate = "dobnyc_elv3_qafaileddate";
    public const string AccepetedDAte = "dobnyc_elv3_accepeted";
    public const string AccepetedDefectsDAte = "dobnyc_elv3_accepteddefectsdate";
    public const string FeesCalculationDate = "dobnyc_elv3_feescalculationdate";
    public const string IncompleteSubmissionDate = "dobnyc_elv3_incompletesubmissiondate";
    public const string UserFilingActions = "dobnyc_elv3_userfilingactions";
    public const string ResubmissionDate = "dobnyc_elv3_resubmissiondate";
    public const string PropertyProfileLookup = "dobnyc_elv3_propertyprofile";
    public const string ELV3PaymentMethod = "dobnyc_elv3_paymentmethod";
    public const string sharedAmountDue = "sharedAmountDue"; //used to store amountdue in pre-operation such that if amount due>0 then create the payment history else do not create
    public const string sharedFilingFee = "sharedFilingFee";
    public const string sahredLateFilingFee = "sahredLateFilingFee";
    public const string sahredNoGoodCheckFee = "sahredNoGoodCheckFee";
    public const string sahredELV3NRFFee = "sahredELV3NRFFee";
    public const string sahredELV29NRFFee = "sahredELV29NRFFee";
    public const string sahredELV3NRFRecordCount = "sahredELV3NRFRecordCount";//used to identify how many ELV3 failure to file TH should be added
    public const string sahredELV29NRFRecordCount = "sahredELV29NRFRecordCount";//used to identify how many ELV29 failure to file TH should be added
    public const string IsDefectsExist = "dobnyc_elv3_isdefectsexist";
    public const string TNFId = "dobnyc_elv3_tnfid";
    public const string TNFSubmitted = "dobnyc_tnfsubmitted";
    public const string TNFSubmitted3DaysAdvance = "dobnyc_tnfsubmitted3daysadvance";
    public const string SubmissionDate = "dobnyc_elv3_submissiondate";
    public const string ReSubmissionDate = "dobnyc_elv3_resubmissiondate";
    public const string InspectionDateAhead1Day = "dobnyc_inspectiondateahead1day";
    public const string TempRenewalExpiredOnTNFSubmitDate = "dobnyc_90daysexpiredontnfsubmitdate";
    public const string TempRenewalExpiredOnInspectionDate = "dobnyc_90daysexpiredoninspectiondate";
    public const string ReportType = "dobnyc_reporttype";
    public const string noGoodCheckFee = "dobnyc_elv3_nogoodcheckfee";
    public const string ELV3NRFLookup = "dobnyc_elv3_elv3nrflookup";
    public const string statecode = "statecode";
    public const string statusReason = "statuscode";
    public const string violationDate = "dobnyc_elv3_violationdate";

    public const string inspectingAgencyDirectorLegalStatement = "dobnyc_inspectingagency_legalstatement";
    public const string inspectingAgencyDirectorSignature = "dobnyc_inspectingagency_directorname";
    public const string inspectingAgencyDirectorSignatureDate = "dobnyc_inspectingagency_signdate";
    public const string inspectingAgencyInspectorLegalStatement = "dobnyc_inspectingagency_insplegalstatement";
    public const string inspectingAgencyInspectorSignature = "dobnyc_inspectingagency_inspectorsname";
    public const string inspectingAgencyInspectorSignatureDate = "dobnyc_inspectingagency_inspectorsigndate";

    public const string witnessAgencyDirectorLegalStatement = "dobnyc_witnessingagency_legalstatement";
    public const string witnessAgencyDirectorSignature = "dobnyc_witnessingagency_directorname";
    public const string witnessAgencyDirectorSignatureDate = "dobnyc_witnessingagency_signdate";
    public const string witnessAgencyInspectorLegalStatement = "dobnyc_witnessingagency_insplegalstatement";
    public const string witnessAgencyInspectorSignature = "dobnyc_witnessingagency_inspectorname";
    public const string witnessAgencyInspectorSignatureDate = "dobnyc_witnessingagency_inspectorsigndate";

    public const string ownerLegalStatement = "dobnyc_propertyowner_legalstatement";
    public const string ownerSignature = "dobnyc_propertyowner_name";
    public const string ownerSignatureDate = "dobnyc_propertyowner_signdate";
    public const string TNFSubmittedAdvanceDays = "dobnyc_tnfsubmitteddateadvancedays";
}
#endregion Entity Attributes Names
public static class GenericHandler
{
    public static bool IsValidString(this string field)
    {
        if (string.IsNullOrEmpty(field) || string.IsNullOrWhiteSpace(field))
            return false;
        else
            return true;
    }
}

#region SQL queries
//SELECT*
//FROM DOB_BIS_ELEV_INSPECT_1
//where IN_INSP_TYPE in ('1' , '3' , '5')

//--update elvApp
//--set elvApp.DeviceHouseNumber = md.dobnyc_HouseNumber,
//--elvApp.DeviceBin = md.dobnyc_mas_bin,
//--elvApp.DeviceBlock = md.dobnyc_mas_Block,
//--elvApp.DeviceLot = md.dobnyc_mas_Lot,
//--elvApp.DeviceStreet = md.dobnyc_StreetName,
//--elvApp.DeviceBorough = md.dobnyc_Borough,
//--elvApp.DeviceZip = md.dobnyc_mas_Zipcode
//--From DOB_BIS_ELEV_INSPECT_1 as elvApp
//--join[DOBCRMDEV_MSCRM].[dbo].[dobnyc_elevatordevice] as md
//--ON elvApp.DeviceGuid = md.dobnyc_elevatordeviceId
#endregion SQL queries