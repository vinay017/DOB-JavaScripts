﻿using System;
using System.Text;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Net;
using System.ServiceModel;

namespace XRMWebServiceConnectionManager
{
    public class CrmServiceConnector
    {
        private static IOrganizationService service;
        private OrganizationServiceProxy _serviceProxy;
        private static bool isConnected;
        private string webServiceCallParameterInfo;
        private static CrmServiceConnector _crmServiceInstance;

        static CrmServiceConnector()
        {
            _crmServiceInstance = new CrmServiceConnector();
        }

        public static CrmServiceConnector CrmServiceConnectorInstance()
        {
            if (_crmServiceInstance == null)
            {
                _crmServiceInstance = new CrmServiceConnector();
            }
            return _crmServiceInstance;
        }

        public static OrganizationServiceProxy ServiceProxy
        {
            get
            {
                try
                {
                    ServerConnection serverConnect = new ServerConnection();
                    ServerConnection.Configuration serverConfig = serverConnect.GetServerConfiguration(true);
                    ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                    OrganizationServiceProxy serviceProxy = new OrganizationServiceProxy(serverConfig.OrganizationUri, serverConfig.HomeRealmUri, serverConfig.Credentials, serverConfig.DeviceCredentials);
                    return serviceProxy;
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw ex;
                }
                catch (TimeoutException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public string WebServiceCallParameterInfo
        {
            get
            {
                try
                {
                    if (webServiceCallParameterInfo == null)
                    {
                        webServiceCallParameterInfo = GenerateWebServiceCallParameterInfo();
                    }
                    return webServiceCallParameterInfo;
                }
                catch (FaultException<OrganizationServiceFault> ex)
                {
                    throw ex;
                }
                catch (TimeoutException ex)
                {
                    throw ex;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void Configure(Boolean useAdminCredentials)
        {
            try
            {
                ServerConnection serverConnect = new ServerConnection();
                ServerConnection.Configuration serverConfig = serverConnect.GetServerConfiguration(useAdminCredentials);

                // Connect to the Organization service. 
                // The using statement assures that the service proxy will be properly disposed.
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                using (_serviceProxy = new OrganizationServiceProxy(serverConfig.OrganizationUri, serverConfig.HomeRealmUri, serverConfig.Credentials, serverConfig.DeviceCredentials))
                {
                    // This statement is required to enable early-bound type support.
                    // _serviceProxy.ServiceConfiguration.CurrentServiceEndpoint.Behaviors.Add(new ProxyTypesBehavior());
                    _serviceProxy.EnableProxyTypes();
                    service = (IOrganizationService)_serviceProxy;
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Connect()
        {
            try
            {
                Connect(false);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void Connect(Boolean useAdminCredentials)
        {
            try
            {
                if (service == null)
                {
                    Configure(useAdminCredentials);
                }

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GenerateWebServiceCallParameterInfo()
        {
            StringBuilder webServiceCallParameters = new StringBuilder("Web service call parameters : ");
            try
            {
                //    if (this.service == null)
                //    {
                //        webServiceCallParameters.Append("Web service could not be accessed");
                //    }
                //    else
                //    {
                //        if (this.service != null)
                //        {
                //            webServiceCallParameters.Append(String.Format("Web Service Url : {0} \r\n", this.service.Url));
                //            if (this.service.Credentials != null)
                //            {
                //                NetworkCredential credentails = (NetworkCredential)this.service.Credentials;
                //                webServiceCallParameters.Append(String.Format(@"Web Service User: {0}\{1} \r\n", credentails.Domain, credentails.UserName));
                //            }
                //            else if (this.service.UseDefaultCredentials)
                //            {
                //                webServiceCallParameters.Append("Web Service User: Current CRM User . \r\n");
                //            }
                //            else
                //            {
                //                webServiceCallParameters.Append("Web Service User : - \r\n");
                //            }

                //            if (this.service.Proxy != null)
                //            {
                //                WebProxy proxy = (WebProxy)this.service.Proxy;
                //                webServiceCallParameters.Append(String.Format("Proxy Url : {0} \r\n", proxy.Address.AbsoluteUri.ToString()));
                //                if (proxy.Credentials != null)
                //                {
                //                    NetworkCredential proxyCredentails = (NetworkCredential)proxy.Credentials;
                //                    webServiceCallParameters.Append(String.Format(@"Proxy User : {0}\{1} \r\n", proxyCredentails.Domain, proxyCredentails.UserName));
                //                }
                //                else
                //                {
                //                    webServiceCallParameters.Append(String.Format(@"Proxy User : - \r\n"));
                //                }
                //            }
                //        }
                //    }

                return webServiceCallParameters.ToString();
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entity CallRetrieveMethod(string entityName, Guid entityId, ColumnSet columnSet, string organizationName, bool useAdminCredentials)
        {
            try
            {
                if (!isConnected)
                {
                    Connect();
                }
                return service.Retrieve(entityName, entityId, columnSet);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string CallFetchMethod(string fetchXml, string organizationName, bool useAdminCredentials)
        {
            try
            {
                throw new NotImplementedException("CallFetchMethod");
                //service.CrmAuthenticationTokenValue = CreateAutheticationToken(organizationName);
                //if (useAdminCredentials)
                //    service.Credentials = CommonMethods.GetAdminCredentials();
                //else
                //    service.UseDefaultCredentials = true;

                //return service.fet Fetch(fetchXml);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public EntityCollection CallRetrieveMultipleMethod(QueryBase query, Boolean useAdminCredentials)
        {
            try
            {
                if (!isConnected)
                {

                    Connect(useAdminCredentials);
                }
                return service.RetrieveMultiple(query);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public OrganizationResponse CallExecuteMethod(OrganizationRequest request, string organizationName, bool useAdminCredentials)
        {
            try
            {
                if (!isConnected)
                {
                    Connect(useAdminCredentials);
                }
                return service.Execute(request);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Guid CallCreateMethod(Entity entity, string organizationName, bool useAdminCredentials)
        {
            try
            {
                if (!isConnected)
                {
                    Connect(useAdminCredentials);
                }
                return service.Create(entity);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CallUpdateMethod(Entity entity, string organizationName, bool useAdminCredentials)
        {
            try
            {
                if (!isConnected)
                {
                    Connect(useAdminCredentials);
                }
                service.Update(entity);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IOrganizationService XrmConnection()
        {
            try
            {
                if (!isConnected)
                {
                    Connect();
                }
                return service;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetAttributeDisplayName(string entitySchemaName, string attributeSchemaName)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = entitySchemaName,
                LogicalName = attributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}
