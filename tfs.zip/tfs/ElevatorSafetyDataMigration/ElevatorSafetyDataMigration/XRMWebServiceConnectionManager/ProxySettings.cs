﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace XRMWebServiceConnectionManager
{
    public class ProxySettings
    {
        private string proxyServer;
        private int proxyPort;
        private string proxyUserName;
        private string proxyPassword;
        private string proxyDomain;

        public string ProxyServer
        {
            get { return proxyServer; }
            set { proxyServer = value; }
        }
        public int ProxyPort
        {
            get { return proxyPort; }
            set { proxyPort = value; }
        }
        public string ProxyDomain
        {
            get { return proxyDomain; }
            set { proxyDomain = value; }
        }
        public string ProxyPassword
        {
            get { return proxyPassword; }
            set { proxyPassword = value; }
        }
        public string ProxyUserName
        {
            get { return proxyUserName; }
            set { proxyUserName = value; }
        }

        internal NetworkCredential ProxyCredentials
        {
            get { return new NetworkCredential(proxyUserName, proxyPassword, proxyDomain); }
        }
    }
}
