﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using ConfigurationManager;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;


namespace XRMWebServiceConnectionManager
{
    public enum AuthenticationType { AD, Passport, SPLA };

    /// <summary>
    /// Provides server connection information.
    /// </summary>
    public class ServerConnection 
    {
        #region Inner classes
        /// <summary>
        /// Stores CRM server configuration information.
        /// </summary>
        public class Configuration
        {
            public String ServerAddress;
            public String OrganizationName;
            public Uri DiscoveryUri;
            public Uri OrganizationUri;
            public Uri HomeRealmUri = null;
            public ClientCredentials DeviceCredentials = null;
            public ClientCredentials Credentials = null;
            public AuthenticationType EndpointType;
        }
        #endregion Inner classes

        #region Public properties

        public List<Configuration> configurations = null;

        #endregion Public properties

        #region Private properties

        private Configuration config = new Configuration();

        #endregion Private properties

        #region Public methods
        /// <summary>
        /// Obtains the server connection information including the target organization's
        /// Uri and user login credentials from the user.
        /// </summary>
        public  Configuration GetServerConfiguration(Boolean useAdminCredentials)
        {
            try
            {
                // Get the server address. If no value is entered, default to Microsoft Dynamics
                // CRM Online in the North American data center.
                config.ServerAddress = GetServerAddress();

                //config.DiscoveryUri =
                new Uri(String.Format(CustomConfigurations.GetXMLConfigurationKey("crmDiscoveryService")));

                // Get the user's logon credentials.
                config.Credentials = GetUserLogonCredentials(useAdminCredentials);

                // Get the target organization.
                config.OrganizationUri = new Uri(CustomConfigurations.GetXMLConfigurationKey("crmOrganizationService"));
                //Store the completed configuration.
                if (configurations == null) configurations = new List<Configuration>();
                configurations.Add(config);
                return config;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        public OrganizationDetailCollection DiscoverOrganizations(IDiscoveryService service)
        {
            try
            {
                RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
                RetrieveOrganizationsResponse orgResponse = (RetrieveOrganizationsResponse)service.Execute(orgRequest);
                return orgResponse.Details;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name=orgFriendlyName">The friendly name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        public OrganizationDetail FindOrganization(string orgFriendlyName, OrganizationDetail[] orgDetails)
        {
            try
            {
                OrganizationDetail orgDetail = null;

                foreach (OrganizationDetail detail in orgDetails)
                {
                    if (String.Compare(detail.FriendlyName, orgFriendlyName) == 0)
                    {
                        orgDetail = detail;
                        break;
                    }
                }
                return orgDetail;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Reads a server configuration file.
        /// </summary>
        /// <param name="pathname">The file system path to the server configuration file.</param>
        /// <remarks>Server configurations are appended to the public configurations list.</remarks>
        public void ReadConfigurations(String pathname)
        {
            //if (configurations == null)
            //    configurations = new List<Configuration>();
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Writes all server configurations to a file.
        /// </summary>
        /// <remarks>If the file exists, it is overwritten.</remarks>
        /// <param name="pathname">The file name and system path of the output configuration file.</param>
        public void SaveConfigurations(String pathname)
        {
            try
            {
                if (configurations == null)
                    throw new Exception("No server connection configurations were found.");

                //TODO: Delete file if it exists.
                // Delete file here.

                foreach (Configuration config in configurations)
                    SaveConfiguration(pathname, config, true);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Writes a server configuration to a file.
        /// </summary>
        /// <param name="pathname">The file name and system path of the output configuration file.</param>
        /// <param name="config">A server connection configuration.</param>
        /// <param name="append">If true, the configuration is appended to the file, otherwise a new file
        /// is created.</param>
        public void SaveConfiguration(String pathname, Configuration config, bool append)
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Obtains the authentication type of the CRM server.
        /// </summary>
        /// <param name="uri">Uri of the CRM Discovery service.</param>
        /// <returns>Authentication type.</returns>
        public AuthenticationProviderType GetServerType(Uri uri)
        {
            try
            {
                return ServiceConfigurationFactory.CreateConfiguration<IDiscoveryService>(uri).AuthenticationType;
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion Public methods

        #region Protected methods

        /// <summary>
        /// Obtains the name and port of the server running the Microsoft Dynamics CRM
        /// Discovery service.
        /// </summary>
        /// <returns>The server's network name and optional TCP/IP port.</returns>
        protected virtual String GetServerAddress()
        {
            try
            {
                string temp = CustomConfigurations.GetXMLConfigurationKey("crmServerAddress");//"";//"";// ConfigurationSettingsHelper.ApplicationConfigurationSettings[ConfigurationKeyStrings.CRMUrlKey].ToString();
                return temp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected virtual string GetOrganizationName()
        {
            try
            {
                string temp = CustomConfigurations.GetXMLConfigurationKey("crmServerOrgName");//"";// ConfigurationSettingsHelper.ApplicationConfigurationSettings[ConfigurationKeyStrings.DefaultOrganizationNameKey].ToString();
                return temp;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Obtains the Web address (Uri) of the target organization.
        /// </summary>
        /// <param name="discoveryServiceUri">The Uri of the CRM Discovery service.</param>
        /// <returns>Uri of the organization service or an empty string.</returns>
        protected virtual Uri GetOrganizationAddress(Uri discoveryServiceUri)
        {
            try
            {
                ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };
                using (DiscoveryServiceProxy serviceProxy = new DiscoveryServiceProxy(discoveryServiceUri, null, config.Credentials, config.DeviceCredentials))
                {
                    // Obtain organization information from the Discovery service. 
                    if (serviceProxy != null)
                    {
                        // Obtain information about the organizations that the system user belongs to.
                        OrganizationDetailCollection orgs = DiscoverOrganizations(serviceProxy);

                        if (orgs.Count == 1)
                        {
                            return new System.Uri(orgs[0].Endpoints[EndpointType.OrganizationService]);
                        }
                        else if (orgs.Count > 1)
                        {
                            string defaultOrganizationName = GetOrganizationName();
                            foreach (OrganizationDetail de in orgs)
                            {
                                if (de.FriendlyName.ToLower() == defaultOrganizationName.ToLower())
                                    return new System.Uri(de.Endpoints[EndpointType.OrganizationService]);
                            }
                            throw new Exception("The specified organization does not exist.");
                        }
                        else
                        {
                            throw new Exception("You do not belong to any organizations on the specified server.");
                        }
                    }
                    else
                        throw new Exception("An invalid server name was specified.");
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Obtains the user's logon credentials for the target server.
        /// </summary>
        /// <returns>Logon credentials of the user.</returns>
        protected virtual ClientCredentials GetUserLogonCredentials(Boolean useAdminCredential)
        {
            try
            {
                if (useAdminCredential)
                {
                    return CommonMethods.GetAdminCredentials();
                }
                else
                {
                    return CommonMethods.GetCurrenctUserCredentials();
                }
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw ex;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        } 
        #endregion Private methods
    }

    #region Internal Classes

    /// <summary>
    /// The SolutionComponentType defines the type of solution component.
    /// </summary>
    //public static class SolutionComponentType
    //{
    //    public const int Attachment = 35;
    //    public const int Attribute = 2;
    //    public const int AttributeLookupValue = 5;
    //    public const int AttributeMap = 47;
    //    public const int AttributePicklistValue = 4;
    //    public const int ConnectionRole = 63;
    //    public const int ContractTemplate = 37;
    //    public const int DisplayString = 22;
    //    public const int DisplayStringMap = 23;
    //    public const int DuplicateRule = 44;
    //    public const int DuplicateRuleCondition = 45;
    //    public const int EmailTemplate = 36;
    //    public const int Entity = 1;
    //    public const int EntityMap = 46;
    //    public const int EntityRelationship = 10;
    //    public const int EntityRelationshipRelationships = 12;
    //    public const int EntityRelationshipRole = 11;
    //    public const int FieldPermission = 71;
    //    public const int FieldSecurityProfile = 70;
    //    public const int Form = 24;
    //    public const int KBArticleTemplate = 38;
    //    public const int LocalizedLabel = 7;
    //    public const int MailMergeTemplate = 39;
    //    public const int ManagedProperty = 13;
    //    public const int OptionSet = 9;
    //    public const int Organization = 25;
    //    public const int PluginAssembly = 91;
    //    public const int PluginType = 90;
    //    public const int Relationship = 3;
    //    public const int RelationshipExtraCondition = 8;
    //    public const int Report = 31;
    //    public const int ReportCategory = 33;
    //    public const int ReportEntity = 32;
    //    public const int ReportVisibility = 34;
    //    public const int RibbonCommand = 48;
    //    public const int RibbonContextGroup = 49;
    //    public const int RibbonCustomization = 50;
    //    public const int RibbonDiff = 55;
    //    public const int RibbonRule = 52;
    //    public const int RibbonTabToCommandMap = 53;
    //    public const int Role = 20;
    //    public const int RolePrivilege = 21;
    //    public const int SavedQuery = 26;
    //    public const int SavedQueryVisualization = 59;
    //    public const int SDKMessageProcessingStep = 92;
    //    public const int SDKMessageProcessingStepImage = 93;
    //    public const int SDKMessageProcessingStepSecureConfig = 94;
    //    public const int ServiceEndpoint = 95;
    //    public const int SiteMap = 62;
    //    public const int SystemForm = 60;
    //    public const int ViewAttribute = 6;
    //    public const int WebResource = 61;
    //    public const int Workflow = 29;
    //}
    #endregion
}
