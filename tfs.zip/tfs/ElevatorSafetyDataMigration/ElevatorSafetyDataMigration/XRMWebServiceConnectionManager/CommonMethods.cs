﻿using System;
using System.Net;
using System.ServiceModel.Description;
using ConfigurationManager;

namespace XRMWebServiceConnectionManager
{
    public class CommonMethods
    {
        public static ClientCredentials GetAdminCredentials()
        {
            try
            {
                //var section = ConfigurationManager.GetSection("appSettings") as NameValueConfigurationCollection;
                //var username = section["CRMAdminUser"];
                string userName = CustomConfigurations.GetXMLConfigurationKey("crmAdminUname");//ConfigurationManager.AppSettings["CRMAdminUser"]; //"";// ConfigurationSettingsHelper.ApplicationConfigurationSettings[ConfigurationKeyStrings.AdminUserNameKey].ToString();                                                                                               //string encryptedPassword = "1qaz!QAZ";//System.Configuration.ConfigurationManager.AppSettings["Password"];
                string password = CustomConfigurations.GetXMLConfigurationKey("crmAdminPass");// EncryptionHelper.GetDecodedText(encryptedPassword);
                string domain = CustomConfigurations.GetXMLConfigurationKey("crmAdminDomain");//;System.Configuration.ConfigurationManager.AppSettings["Domain"];
                ClientCredentials credentials = new ClientCredentials();
                if (!String.IsNullOrEmpty(userName) && !String.IsNullOrEmpty(domain))
                {
                    credentials.Windows.ClientCredential = new NetworkCredential(userName, password, domain);
                }
                return credentials;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static ClientCredentials GetCurrenctUserCredentials()
        {
            try
            {
                ClientCredentials credentials = new ClientCredentials();
                credentials.Windows.ClientCredential = (NetworkCredential)CredentialCache.DefaultCredentials;
                return credentials;
            }
            catch (TimeoutException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
