﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

namespace XRMWebServiceConnectionManager
{
    public class ConnectionSettings
    {
        private string url;
        private string userName;
        private string password;
        private string domain;
        private ProxySettings proxySetting;

        public string Url
        {
            get { return url; }
            set { url = value; }
        }
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string Domain
        {
            get { return domain; }
            set { domain = value; }
        }
        public ProxySettings ProxySetting
        {
            get { return proxySetting; }
            set { proxySetting = value; }
        }

        internal ICredentials WebServiceConnectionCredentials
        {
            get
            {
                if (string.IsNullOrEmpty(userName) || string.IsNullOrEmpty(password))
                {
                    return CredentialCache.DefaultCredentials;
                }
                else
                {
                    return new NetworkCredential(userName, password, domain);
                }
            }
        }

    }
}
