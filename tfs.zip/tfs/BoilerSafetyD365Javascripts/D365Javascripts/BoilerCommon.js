﻿///====================================================================
/// Name        :   Boiler Common 
/// Description :   This will be Common Methode for boilers 
/// Usage       :   
/// Script Name :   DOB_BolierCommon
/// Author      :   Ajeesh
///====================================================================
DOB = window.DOB || {};
DOB.BoilerCommon = function () {
    "use strict";

    //Variable Declaration
    var relatedChangesets = [];
    var formContext;
    //Controls declaration

    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================

    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns>

    };



    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================

    var getRecords = function (url) {
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: url,
            async: false,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
            },
            success: function (data, textStatus, XmlHttpRequest) {
                if (data && data.d != null && data.d.results != null) {
                    addRecordsToArray(data.d.results);
                    fetchRecordsCallBack(data.d);
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) {
                alert("Error :  has occured during retrieval of the records ");
            }
        });
    };

    var addRecordsToArray = function (records) {
        for (var i = 0; i < records.length; i++) {
            relatedChangesets.push(records[i]);
        }
    };

    var fetchRecordsCallBack = function (records) {
        if (records.__next != null) {
            var url = records.__next;
            GetRecords(url);
        }
    };


    var getRecordsWebApi=function(query)
    {
        SDK.WEBAPI.retrieveMultipleRecordsWithFormattedData(false, "dobnyc_boilerchangesets", query, function (results) {
            if (results.value.length > 0)  //Active requests exist
            {
                      
                addRecordsToArray(results.value);
            }

        }, function (errMsg) { Xrm.Utility.alertDialog(errMsg); }, function () {/*alert("Complete");*/ });
    }

    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of BIR
    ///==================================================================================================================

    var onLoad = function () {
        init();
    };

    function replaceBracketsInGuid(id) {
        return id.replace("{", "").replace("}", "");
    }


    var isUCI = function () {
        return Xrm.Internal.isUci()
    }
    var highlightBoilerChangesetFields = function (changesetRecords) {
        if (isUCI()) {
            setTimeout(highlight, 10000);
        }
        else {
            highlight();
        }

        function highlight() {
            if (changesetRecords) {
                if (changesetRecords.length > 0) {
                    for (var i = 0; i < changesetRecords.length; i++) {
                        var attributename = changesetRecords[i].dobnyc_bcs_fieldschemaname;
                        if (attributename != undefined) {
                            if (isUCI()) {
                                $("[data-id*='" + attributename + "']", parent.document).css("background-color", "red");
                            }
                            else {
                                for (var j = 0; j <= 5; j++) {
                                    var newAttributename = "";

                                    if (j > 0) newAttributename = attributename + j;
                                    else newAttributename = attributename;

                                    if (parent.document.getElementById(newAttributename) != undefined) {
                                        parent.document.getElementById(newAttributename).style.color = "red";
                                        parent.document.getElementById(newAttributename).style.backgroundColor = "red";
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    var highlightchangeSetFields = function (executionContext) {

        try {
            formContext = executionContext.getFormContext();
            var formType = formContext.ui.getFormType();
            if (formType != 1) {
                var entityName = formContext.data.entity.getEntityName();
                var recordId = formContext.data.entity.getId();
                recordId = replaceBracketsInGuid(recordId);
                var serverUrl = formContext.context.getClientUrl();
                //alert(recordId);
                var changesetRecords;
                //BIR 
                if (entityName == "dobnyc_bo9") {
                    //clear array first
                    relatedChangesets = [];

                    var query = "$select=dobnyc_bcs_fieldschemaname&$filter=_dobnyc_bcs_bir_value eq "+recordId;
                  //  var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BIR/Id eq guid'" + recordId + "'";
                    getRecordsWebApi(query);

                }
                    //BIR
                else if (entityName == "dobnyc_boilernotregistered") {
                    //dobnyc_elc_elv1moving
                    relatedChangesets = [];
                    var query = "$select=dobnyc_bcs_fieldschemaname&$filter=_dobnyc_bcs_bnr_value eq " + recordId;
                 //   var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BNR/Id eq guid'" + recordId + "'";
                    getRecordsWebApi(query);

                }
                    //dobnyc_bo13e
                else if (entityName == "dobnyc_bo13e") {
                    relatedChangesets = [];
                    var query = "$select=dobnyc_bcs_fieldschemaname&$filter=_dobnyc_bcs_bo13e_value eq " + recordId;
                   // var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BO13E/Id eq guid'" + recordId + "'";
                    getRecordsWebApi(query);
                }

                if (relatedChangesets) {
                    if (relatedChangesets.length > 0) {

                        highlightBoilerChangesetFields(relatedChangesets);
                    }

                }

                var LocatedIn;
                LocatedIn = formContext.getAttribute("dobnyc_bnr_locatedin").getValue();
                if (LocatedIn != null) {
                    formContext.ui.controls.get('dobnyc_bnr_locatedin').setVisible(true);
                }

            }
        }
        catch (Exception) {
            //alert(Exception);

        }
    };


    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of BIR
    ///==================================================================================================================


    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();

    };

    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in BIR
    ///==================================================================================================================





    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  


    return {
        OnLoad: onLoad,
        OnSave: onSave,
        HighlightchangeSetFields: highlightchangeSetFields

    };
}();

