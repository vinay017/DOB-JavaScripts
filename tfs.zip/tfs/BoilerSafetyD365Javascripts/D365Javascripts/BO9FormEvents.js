﻿// Shows Hides defects grid based on has defect flags on Form
function ShowHideDefectsGrids(executionContext) {
    var formContext = executionContext.getFormContext();
    debugger;
    var hasHazDefects = formContext.getAttribute("dobnyc_bo9_hashazardeousdefects").getValue();
    var hasRecDefects = formContext.getAttribute("dobnyc_bo9_hasrecommendeddefects").getValue();
    var isDefectsExists = formContext.getAttribute("dobnyc_bo9_isdefectexists").getValue();

    //Hide Defect  Legal Statement based on isDefectsExists flag	
    if (isDefectsExists == true) {
        formContext.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_10").setVisible(true);
    }
    else if (isDefectsExists == false) {
        formContext.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_10").setVisible(false);
    }
    if (hasHazDefects == 0 && hasRecDefects == 0) {
        formContext.ui.tabs.get("Master_Tab").sections.get("DefectsGrid").setVisible(false);
    } else {
        formContext.ui.tabs.get("Master_Tab").sections.get("DefectsGrid").setVisible(true);
    }

}




