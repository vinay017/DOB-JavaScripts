﻿function DownloadDocument() {
    debugger;
    var returnValue = null;
    var lookup = new Array();
    lookup[0] = new Object();
    lookup[0].id = Xrm.Page.context.getUserId();
    lookup[0].name = Xrm.Page.context.getUserName();
    lookup[0].entityType = "systemuser";



    //alert("check");
    var URL = Xrm.Page.getAttribute("dobnyc_bdl_documenturl").getValue();
    //alert(Xrm.Page.getAttribute("dobnyc_isdocumentviewed").getValue());

    if (URL == null) {
        alert("There is no document to download");
        return;
    }

    var Id = Xrm.Page.data.entity.getId();


    var JBGUID = null;
    var path = null;

    var Documentfor = Xrm.Page.getAttribute("dobnyc_bdl_regardingform").getValue();
    //alert("Documentfor: " + Documentfor);
    if (Documentfor == 1) //B09
    {

        JBGUID = getLookupId("dobnyc_bdl_bo9");
        //alert(JBGUID);
        returnValue = retrieveMultipleCustom("dobnyc_bo9Set", "?select= dobnyc_bo9_Borough,dobnyc_name,dobnyc_bo9_Boiler&$filter=dobnyc_bo9Id eq guid'" + JBGUID + "'");
        //   alert((returnValue[0].dobnyc_TR6_Borough).Value + '\\' + returnValue[0].dobnyc_TR6_ControlNumber.Name + "\\" + returnValue[0].dobnyc_name);
        if (returnValue != null && returnValue[0] != null) {
            path = "Boilers\\" + returnValue[0].dobnyc_bo9_Boiler.Name + '\\' + (returnValue[0].dobnyc_bo9_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }
    else if (Documentfor == 2) //Extension for BIR
    {
        JBGUID = getLookupId("dobnyc_bdl_bo13e");
        returnValue = retrieveMultipleCustom("dobnyc_bo13eSet", "?select= dobnyc_bo13e_borough,dobnyc_name&$filter=dobnyc_bo13eId eq guid'" + JBGUID + "'");
        if (returnValue != null && returnValue[0] != null) {
            path = "Boilers\\" + returnValue[0].dobnyc_bo13e_Boiler.Name + '\\' + (returnValue[0].dobnyc_bo13e_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";

        }

    }
    else if (Documentfor == 3) //BNR
    {

        JBGUID = getLookupId("dobnyc_bdl_bnr");
        returnValue = retrieveMultipleCustom("dobnyc_boilernotregisteredSet", "?select= dobnyc_bnr_Borough,dobnyc_name,dobnyc_bnr_DeviceId&$filter=dobnyc_boilernotregisteredId eq guid'" + JBGUID + "'");
        if (returnValue != null && returnValue[0] != null) {
            path = "Boilers\\" + returnValue[0].dobnyc_bnr_DeviceId + '\\' + (returnValue[0].dobnyc_bnr_Borough).Value + '\\' + returnValue[0].dobnyc_name + "\\Supporting Documents\\";
        }
    }


    $.support.cors = true;

    $.ajax({
        type: "POST",
        url: "http://10.155.208.61:5050/WrapperService.svc/downloadFromDocumentumToCRM",
        processData: true,
        crossDomain: true,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({ uploadedPath: URL, downloadPath: path }),
        cache: false,
        headers: {
            'Access-Control-Allow-Origin': 'http://msdwva-dobcrm01:5555'
        },
        beforeSend: function (XMLHttpRequest) {
            XMLHttpRequest.setRequestHeader("Accept", "application/json");
        },
        success: function (data, textStatus, XmlHttpRequest) {
            if (data.DownloadIsSuccess == true) {
                //alert("Download Successful");
                Xrm.Page.getAttribute("dobnyc_bdl_isdocumentviewed").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_bdl_viewedby").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_bdl_isdocumentviewed").setValue(true);
                Xrm.Page.getAttribute("dobnyc_bdl_viewedby").setValue(lookup);
                window.open(data.downloadPath);

            }
            else {

                //alert(data.ErrorDescription);
                alert("Download is Un-successful");
            }
        },
        error: function (xhr, status, error) {
            alert(error);
            alert("An error occured while downloding document. Please try again or contact administrator.");
        }
    });

}

function getLookupId(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookupid;

        }

    }
}

function getLookupName(attributeName) {

    lookupObject = Xrm.Page.getAttribute(attributeName);

    if (lookupObject != null) {

        var lookUpObjectValue = lookupObject.getValue();

        if ((lookUpObjectValue != null)) {

            var lookuptextvalue = lookUpObjectValue[0].name;

            var lookupid = lookUpObjectValue[0].id;
            return lookuptextvalue;

        }

    }

}
function documentListOnLoad() {
    if (Xrm.Page.getAttribute("dobnyc_bdl_bo9").getValue() != null)
        Xrm.Page.getControl("dobnyc_bdl_bo9").setVisible(true);
    if (Xrm.Page.getAttribute("dobnyc_bdl_bo13e").getValue() != null)
        Xrm.Page.getControl("dobnyc_bdl_bo13e").setVisible(true);
    if (Xrm.Page.getAttribute("dobnyc_bdl_bnr").getValue() != null)
        Xrm.Page.getControl("dobnyc_bdl_bnr").setVisible(true);
}
function ReplaceDocument() {
    debugger;
    // alert("Replace Documents");
    var Borough = "";
    var deviceId = "";
    var filingNumber = "";
    var docCategory = "Supporting Documents";
    //tr6
    //fisp3
    //psr
    //HV
    var documentName = Xrm.Page.getAttribute("dobnyc_name").getValue();
    var docTypeName = getLookupName("dobnyc_bdl_documenttype");

    var docListRecordId = Xrm.Page.data.entity.getId();
    var JBGUID = null;
    var Documentfor = Xrm.Page.getAttribute("dobnyc_bdl_regardingform").getValue();
    var docListName = Xrm.Page.getAttribute("dobnyc_name").getValue();
    var docTypeListId = getLookupId("dobnyc_bdl_documenttype");
    // alert("Documentfor: " + Documentfor);

    var returnValue = null;

    if (Documentfor == 1) //B09
    {

        JBGUID = getLookupId("dobnyc_bdl_bo9");
        returnValue = retrieveMultipleCustom("dobnyc_bo9Set", "?select= dobnyc_Bo9_Borough,dobnyc_name&$filter=dobnyc_bo9Id eq guid'" + JBGUID + "'");
        if (returnValue != null && returnValue[0] != null) {
            Borough = (returnValue[0].dobnyc_bo9_Borough).Value;
            deviceId = returnValue[0].dobnyc_bo9_Boiler.Name;

        }

    }
    else if (Documentfor == 2) //Extension for BIR
    {

        JBGUID = getLookupId("dobnyc_bdl_bo13e");
        returnValue = retrieveMultipleCustom("dobnyc_bo13eSet", "?select= dobnyc_bo13e_Borough,dobnyc_name&$filter=dobnyc_bo13eId eq guid'" + JBGUID + "'");
        if (returnValue != null && returnValue[0] != null) {
            Borough = (returnValue[0].dobnyc_bo13e_Borough).Value;
            deviceId = returnValue[0].dobnyc_bo13e_Boiler.Name;

        }

    }
    else if (Documentfor == 3) //BNR
    {

        JBGUID = getLookupId("dobnyc_bdl_bnr");
        //alert(JBGUID);
        returnValue = retrieveMultipleCustom("dobnyc_boilernotregisteredSet", "?select= dobnyc_bnr_Borough,dobnyc_name,dobnyc_bnr_DeviceId&$filter=dobnyc_boilernotregisteredId eq guid'" + JBGUID + "'");
        if (returnValue != null && returnValue[0] != null) {
            Borough = (returnValue[0].dobnyc_bnr_Borough).Value;
            deviceId = returnValue[0].dobnyc_bnr_DeviceId;
        }
    }


    var docTypeListIdFormatted = docTypeListId.substring(1, docTypeListId.length - 1);
    var docListRecordIdFormatted = docListRecordId.substring(1, docListRecordId.length - 1);
    var docCategoryRecordIdFormatted = JBGUID.substring(1, JBGUID.length - 1);

    var URL = "http://10.155.208.60:5556/BoilersCRMDocumentUpload.html?borough=" + Borough + "&deviceId=" + deviceId + "&reqNumber=" + returnValue[0].dobnyc_name + "&docTypeListId=" + docTypeListIdFormatted + "&documentName=" + documentName + "&documentTypeName=" + docTypeName + "&docCategory=" + docCategory + "&docCategoryRecordId=" + docCategoryRecordIdFormatted + "&applicationIdentifier=" + "CRM" + "&docListName=" + docListName + "&docListRecordId=" + docListRecordIdFormatted;

    //var customParameters = encodeURIComponent("borough=" +(returnValue[0].dobnyc_BoroughNYC).Value + "&jobNumber=" + returnValue[0].dobnyc_ProjectNumber + "&filingNumber=" + returnValue[0].dobnyc_FilingNumber + "&reqNumber=ReqNo&docCategory=" + docLabel + "&docType=" + docCat + "&docTypeListID=" + DOCID + "&user=UserGUID&docTypeName=" + docTypeName);
    //alert(customParameters);
    //var uri_dec = decodeURIComponent(customParameters);
    //Xrm.Utility.openWebResource("dobnyc_UploadDocument", uri_dec);

    //alert(URL);
    var isChrome = !!window.chrome && !!window.chrome.webstore;
    var isIE = /*@cc_on!@*/false || !!document.documentMode;
    var Title = "Upload Document";
    var opt = 'dialogWidth:530px; dialogHeight:200px; center:yes; scroll:no; status:no';

    if (!window.showModalDialog) {
        window.showModalDialog = function (URL, Title, opt) {

            var w;
            var h;
            var resizable = "no";
            var scroll = "no";
            var status = "no";

            // get the modal specs
            var mdattrs = opt.split(";");
            for (i = 0; i < mdattrs.length; i++) {
                var mdattr = mdattrs[i].split(":");

                var n = mdattr[0];
                var v = mdattr[1];
                if (n) { n = n.trim().toLowerCase(); }
                if (v) { v = v.trim().toLowerCase(); }

                if (n == "dialogheight") {
                    h = v.replace("px", "");
                } else if (n == "dialogwidth") {
                    w = v.replace("px", "");
                } else if (n == "resizable") {
                    resizable = v;
                } else if (n == "scroll") {
                    scroll = v;
                } else if (n == "status") {
                    status = v;
                }
            }

            var left = window.screenX + (window.outerWidth / 2) - (w / 2);
            var top = window.screenY + (window.outerHeight / 2) - (h / 2);
            var targetWin = window.open(URL, Title, 'toolbar=no, location=no, directories=no, status=' + status + ', menubar=no, scrollbars=' + scroll + ', resizable=' + resizable + ', copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
            targetWin.focus();
        };


        window.showModalDialog(URL, Title, opt);

    }
    else {
        window.showModalDialog(URL, Title, opt);
        window.location.reload();
    }
}