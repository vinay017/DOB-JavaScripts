﻿// Shows Hides grid based on filing type on Form
function ShowHideGrids() {
    var filingType = Xrm.Page.getAttribute("dobnyc_bca_filingtype").getValue();
    HideGrids();
    if (filingType == null)
        return;
        // filingType 1: Initial
    else if (filingType == 1) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO9GridSection").setVisible(true);
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo9StatementsSection").setVisible(true);
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo13StatementsSection").setVisible(true);


    }
        // filingType 2: Amended
    else if (filingType == 2) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO13GridSection").setVisible(true);
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo13StatementsSection").setVisible(true);

    }
        // filingType 3: Extension
    else if (filingType == 3) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO13EGridSection").setVisible(true);
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo13EStatementsSection").setVisible(true);

    }
}

// Hides all the Grids
function HideGrids() {
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO9GridSection").setVisible(false);
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo9StatementsSection").setVisible(false);
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO13GridSection").setVisible(false);
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo13StatementsSection").setVisible(false);
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("BO13EGridSection").setVisible(false);
    Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Bo13EStatementsSection").setVisible(false);
}



