﻿// Shows Hides defects grid based on has defect flags on Form
function ShowHideDefectsGrids() {
    debugger;
    var hasHazDefects = Xrm.Page.getAttribute("dobnyc_bo9_hashazardeousdefects").getValue();
    var hasRecDefects = Xrm.Page.getAttribute("dobnyc_bo9_hasrecommendeddefects").getValue();
    var isDefectsExists = Xrm.Page.getAttribute("dobnyc_bo9_isdefectexists").getValue();

    //Hide Defect  Legal Statement based on isDefectsExists flag	
    if (isDefectsExists == true) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_10").setVisible(true);
    }
    else if (isDefectsExists == false) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_10").setVisible(false);
    }
    if (hasHazDefects == 0 && hasRecDefects == 0) {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("DefectsGrid").setVisible(false);
    } else {
        Xrm.Page.ui.tabs.get("Master_Tab").sections.get("DefectsGrid").setVisible(true);
    }

}




