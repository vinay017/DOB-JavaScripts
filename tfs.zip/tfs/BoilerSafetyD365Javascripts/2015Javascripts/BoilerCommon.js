﻿///====================================================================
/// Name        :   Boiler Common 
/// Description :   This will be Common Methode for boilers 
/// Usage       :   
/// Script Name :   DOB_BolierCommon
/// Author      :   Ajeesh
///====================================================================
DOB = window.DOB || {};
DOB.BoilerCommon = function () {
    "use strict";

    //Variable Declaration
    var relatedChangesets = [];

    //Controls declaration

    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================

    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns>

    };



    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================

    var getRecords = function (url) {
        jQuery.ajax({
            type: "GET",
            contentType: "application/json; charset=utf-8",
            datatype: "json",
            url: url,
            async: false,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Accept", "application/json");
            },
            success: function (data, textStatus, XmlHttpRequest) {
                if (data && data.d != null && data.d.results != null) {
                    addRecordsToArray(data.d.results);
                    fetchRecordsCallBack(data.d);
                }
            },
            error: function (XmlHttpRequest, textStatus, errorThrown) {
                alert("Error :  has occured during retrieval of the records ");
            }
        });
    };

    var addRecordsToArray = function (records) {
        for (var i = 0; i < records.length; i++) {
            relatedChangesets.push(records[i]);
        }
    };

    var fetchRecordsCallBack = function (records) {
        if (records.__next != null) {
            var url = records.__next;
            GetRecords(url);
        }
    };

    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of BIR
    ///==================================================================================================================

    var onLoad = function () {
        init();
    };


    var highlightchangeSetFields = function () {

        try {
            var formType = Xrm.Page.ui.getFormType();
            if (formType != 1) {
                var entityName = Xrm.Page.data.entity.getEntityName();
                var recordId = Xrm.Page.data.entity.getId();
                var serverUrl = Xrm.Page.context.getClientUrl();
                //alert(recordId);
                var changesetRecords;
                //BIR 
                if (entityName == "dobnyc_bo9") {
                    //clear array first
                    relatedChangesets = [];
                    var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BIR/Id eq guid'" + recordId + "'";
                    getRecords(oDataUri);

                }
                    //BIR
                else if (entityName == "dobnyc_boilernotregistered") {
                    //dobnyc_elc_elv1moving
                    relatedChangesets = [];
                    var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BNR/Id eq guid'" + recordId + "'";
                    getRecords(oDataUri);

                }
                    //dobnyc_bo13e
                else if (entityName == "dobnyc_bo13e") {
                    relatedChangesets = [];
                    var oDataUri = serverUrl + "/xrmservices/2011/OrganizationData.svc/dobnyc_boilerchangesetSet?$select=dobnyc_bcs_FieldSchemaName&$filter=dobnyc_bcs_BO13E/Id eq guid'" + recordId + "'";
                    getRecords(oDataUri);
                }

                if (relatedChangesets) {
                    if (relatedChangesets.length > 0) {

                        for (var i = 0; i < relatedChangesets.length; i++) {
                            var attributename = relatedChangesets[i].dobnyc_bcs_FieldSchemaName;
                            document.getElementById(attributename).style.color = "red";
                            document.getElementById(attributename).style.backgroundColor = "red";
                        }
                    }

                }

                var LocatedIn;
                LocatedIn = Xrm.Page.getAttribute("dobnyc_bnr_locatedin").getValue();
                if (LocatedIn != null) {
                    Xrm.Page.ui.controls.get('dobnyc_bnr_locatedin').setVisible(true);
                }

            }
        }
        catch (Exception) {
            //alert(Exception);

        }
    };


    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of BIR
    ///==================================================================================================================


    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();

    };

    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in BIR
    ///==================================================================================================================





    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  


    return {
        OnLoad: onLoad,
        OnSave: onSave,
        HighlightchangeSetFields: highlightchangeSetFields

    };
}();

