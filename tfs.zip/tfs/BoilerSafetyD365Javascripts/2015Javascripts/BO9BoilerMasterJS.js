﻿///====================================================================
/// Name        :   BIR 
/// Description :   This will be called on Onload of BIR Forms
/// Usage       :   
/// Script Name :  DBO_BIR
/// Author      :   
///====================================================================

DOB = window.DOB || {};
DOB.BIR = function () {
    "use strict";

    //Variable Declaration
    var complianceReportType;
    var isDefectsExists;
    var isBoilerInfoCorrect;
    var LocatedIn;
    //Controls declaration

    ///==================================================================================================================
    /// Initialization method the initialize all attributes in the entity
    ///==================================================================================================================

    var init = function () {
        ///<summary> All initialize and get the controls and assign to the proper controls </summary>
        ///<returns>no return</returns>
        complianceReportType = Xrm.Page.getAttribute("dobnyc_bo9_reporttype").getValue();
        isDefectsExists = Xrm.Page.getAttribute("dobnyc_bo9_isdefectexists").getValue();
        isBoilerInfoCorrect = Xrm.Page.getAttribute("dobnyc_bo9_isboilerdetailsdifferent").getValue();
        LocatedIn = Xrm.Page.getAttribute("dobnyc_bo9_locatedin").getValue();
    };

    var setState = function (enabled) {
        ///<summary> Set State of attributes and Tabs </summary>
        ///<returns>no return</returns>
        ///<param name="enabled" type="Boolean">Set state for tabs and attributes.</param>
        if (complianceReportType == 1)
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_16").setVisible(enabled);
        if (isDefectsExists == false)
            Xrm.Page.ui.tabs.get("Master_Tab").sections.get("Master_Tab_section_10").setVisible(enabled);
        if (isBoilerInfoCorrect == false) {
            Xrm.Page.ui.controls.get('dobnyc_bo9_newboilermake').setVisible(true);
            Xrm.Page.ui.controls.get('dobnyc_bo9_newboilermodel').setVisible(true);
            Xrm.Page.ui.controls.get('dobnyc_bo9_newyearbuilt').setVisible(true);
        }
        if (LocatedIn != null) {
            Xrm.Page.ui.controls.get('dobnyc_bo9_locatedin').setVisible(true);
        }


    };

    ///==================================================================================================================
    /// Helper Methods
    ///==================================================================================================================

    var helper = function () {
        ///<summary> Set state of attributes and tabs based on BIR is in ecosystem </summary>
        ///<returns>no return</returns>

    };

    ///==================================================================================================================
    /// Event :   Methods called only on OnLoad of BIR
    ///==================================================================================================================

    var onLoad = function () {
        debugger;
        init();
        setState(false);

    };

    ///==================================================================================================================
    /// Event :   Methods called only on OnSave of BIR
    ///==================================================================================================================


    var onSave = function () {
        ///<summary> Onsave Script call</summary>
        ///<returns>no return</returns>
        init();

    };

    ///==================================================================================================================
    /// Event :   Methods called on click of " " button in BIR
    ///==================================================================================================================





    ///==================================================================================================================
    /// Event :   Methods Ribbon Workbench
    ///==================================================================================================================  





    return {
        OnLoad: onLoad,
        OnSave: onSave
    };
}();