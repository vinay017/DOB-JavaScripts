﻿//Boiler Task Master JS//
//By Chen//
//Updated 11/17/2016//


var formCorrect = false;
var BIReviewStatus;
var LIAApplicationType;
var FormMap = { 1: "Extension Request Review Form", 2: "HCN Review Form", 3: "BIR Review Form", 4: "BNR Review Form" };
var BO13EStatusSectionMap = { 2: "QASupervisorReviewSection", 3: "QAReviewSection" };
var HCNStatusSectionMap = { 2: "QASupervisorReviewSection", 3: "InspectionSection" };
var BO9StatusSectionMap = { 4: "QASupervisorReviewSection", 5: "QAReviewSection" };
var BNRStatusSectionMap = { 2: "QASupervisorReviewSection", 3: "QAReviewSection", 5: "InspectionSupervisor" };

function getLookupId(attributeName) {
    lookupObject = Xrm.Page.getAttribute(attributeName);
    if (lookupObject != null) {
        var lookUpObjectValue = lookupObject.getValue();
        if ((lookUpObjectValue != null)) {
            var lookuptextvalue = lookUpObjectValue[0].name;
            var lookupid = lookUpObjectValue[0].id;
            return lookupid;
        }
    }
}

function SetCorrectForm() {
    debugger;
    //Get Form Type
    var taskFor = Xrm.Page.getAttribute("dobnyc_bt_taskformfor").getValue();
    if (taskFor == null) {
        return;
    }
    var currentForm = Xrm.Page.ui.formSelector.getCurrentItem();
    // If currently Opened Form and the Form to show is not same then Set Correct Form
    if (currentForm.getLabel() == FormMap[taskFor]) {
        formCorrect = true;
    } else {
        // Get all Forms Available
        var allForms = Xrm.Page.ui.formSelector.items.get();
        // Loop Through All Form Types
        for (var count in allForms) {
            var form = allForms[count];
            var formLabel = form.getLabel();
            if (formLabel == FormMap[taskFor]) {
                form.navigate();
                return;
            }
        }
    }
}


function BO13EFormOnLoad() {
    SetCorrectForm();
    if (formCorrect) {
        var requestStatus = Xrm.Page.getAttribute("dobnyc_bt_bo13erequeststatus").getValue();
        if (requestStatus == null)
            return;
        var enableSection = BO13EStatusSectionMap[requestStatus];
        Xrm.Page.ui.tabs.get("MasterTab").sections.get(enableSection).setVisible(true);
        //2. QA Supervisor Review 3. QA Review  defalt:  return
        switch (requestStatus) {
            case 2:
                BO13EQASupervisorReview();
                break;
            case 3:
                BO13EQAReview();
                break;
            default:
                return;
        }
    }
}


function BO13EQASupervisorReview() {
    debugger;
    //set Document grid for QAS
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QASDocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_bo13eqasupervisoraction").setRequiredLevel("required");
    var QASupervisorAction = Xrm.Page.getAttribute("dobnyc_bt_bo13eqasupervisoraction").getValue();
    switch (QASupervisorAction) {
        //Assign QA
        case 1:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("required");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
            //Incomplete Submission
        case 2:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //none
        default:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}



function BO13EQAReview() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QADocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_bo13eqareviewaction").setRequiredLevel("required");
    var QAReviewAction = Xrm.Page.getAttribute("dobnyc_bt_bo13eqareviewaction").getValue();
    switch (QAReviewAction) {
        //1. Incomplete Submission 3. Extension Denied
        case 1:
        case 3:
            Xrm.Page.getControl("dobnyc_bt_extensiondurationdays").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_extensiondurationdays").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //Extension Granted
        case 2:
            var taskId = Xrm.Page.data.entity.getId();
            var nextAction = Xrm.Page.getAttribute("dobnyc_bt_bo13eqareviewaction").getValue();
            var documents = GetRelatedDocumentList(taskId, "dobnyc_bdl_qareviewtask");
            if (documents.length > 0) {
                var results = areDocumentsApproved("dobnyc_bt_bo13eqareviewaction", "dobnyc_bdl_qareviewtask");
            }
            if (results == true) {
                Xrm.Page.getControl("dobnyc_bt_extensiondurationdays").setVisible(true);
                Xrm.Page.getAttribute("dobnyc_bt_extensiondurationdays").setRequiredLevel("required");
                Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            }
            else {
                Xrm.Page.getControl("dobnyc_bt_extensiondurationdays").setVisible(false);
                Xrm.Page.getAttribute("dobnyc_bt_extensiondurationdays").setRequiredLevel("none");
                Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            }
            break;
            //none
        default:
            Xrm.Page.getControl("dobnyc_bt_extensiondurationdays").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_extensiondurationdays").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}



function HCNFormOnLoad() {
    SetCorrectForm();
    if (formCorrect) {
        var requestStatus = Xrm.Page.getAttribute("dobnyc_bt_hcnfilingstatus").getValue();
        if (requestStatus == null)
            return;
        var enableSection = HCNStatusSectionMap[requestStatus];
        Xrm.Page.ui.tabs.get("MasterTab").sections.get(enableSection).setVisible(true);
        //1. QA Supervisor Review 2. QA Review  defalt:  return
        switch (requestStatus) {
            case 1:
                HCNQASupervisorReview();
                break;
            case 2:
                HCNInspection();
                break;
            default:
                return;
        }
    }
}


function HCNQASupervisorReview() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QASDocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_hcnqasupervisoraction").setRequiredLevel("required");
    var QASupervisorAction = Xrm.Page.getAttribute("dobnyc_bt_hcnqasupervisoraction").getValue();
    switch (QASupervisorAction) {
        //Assign Inspector
        case 1:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("required");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
            //Incomplete Submission
        case 2:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //none
        default:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}



function HCNInspection() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("InspectionDocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_hcninspectionaction").setRequiredLevel("required");
}



function BO9FormOnLoad() {
    SetCorrectForm();
    if (formCorrect) {
        var reportStatus = Xrm.Page.getAttribute("dobnyc_bt_bo9reportstatus").getValue();
        if (reportStatus == null)
            return;
        var enableSection = BO9StatusSectionMap[reportStatus];

        //4.QA Supervisor Review  5.QA Review  defalt:  return
        switch (reportStatus) {
            case 4:
                Xrm.Page.ui.tabs.get("MasterTab").sections.get(enableSection).setVisible(true);
                BO9QASupervisorReview();
                break;
            case 5:
                Xrm.Page.ui.tabs.get("MasterTab").sections.get(enableSection).setVisible(true);
                var reporttype = Xrm.Page.getAttribute("dobnyc_bt_bo9reporttype").getValue();
                //if bnr
                if (reporttype == 4) { }
                    //if fee exempt
                else {
                    BO9FeeExemptQAReview();
                }

                break;
            default:
                return;
        }
    }
}


function BO9QASupervisorReview() {
    //set Document grid for QAS
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QASDocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_bo9qasupervisoraction").setRequiredLevel("required");
    var QASupervisorAction = Xrm.Page.getAttribute("dobnyc_bt_bo9qasupervisoraction").getValue();
    switch (QASupervisorAction) {
        //Assign QA
        case 1:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("required");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
            //Incomplete Submission
        case 2:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //none
        default:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}



function BO9FeeExemptQAReview() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QADocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_bo9qafeeexemptaction").setRequiredLevel("required");
    var QAReviewAction = Xrm.Page.getAttribute("dobnyc_bt_bo9qafeeexemptaction").getValue();
    switch (QAReviewAction) {
        //3.Rejected - Filing Fee Due  4. Incomplete Submission
        case 3:
        case 4:
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //other cases
        default:
            var results = areDocumentsApproved("dobnyc_bt_bo9qafeeexemptaction", "dobnyc_bdl_qareviewtask");
            if (results == true)
                Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}

function BNRFormOnLoad() {
    SetCorrectForm();
    if (formCorrect) {
        var requestStatus = Xrm.Page.getAttribute("dobnyc_brnrequeststatus").getValue();
        if (requestStatus == null)
            return;
        var enableSection = BNRStatusSectionMap[requestStatus];
        Xrm.Page.ui.tabs.get("MasterTab").sections.get(enableSection).setVisible(true);
        //6. QA Supervisor Review 7. QA Review  defalt:  return
        switch (requestStatus) {
            case 2:
                BNRQASupervisorReview();
                break;
            case 3:
                BNRQAReview();
                break;
            case 5:
                BNRInspectorReview();
                break;
            default:
                return;
        }
    }
}

function BNRQASupervisorReview() {
    //set Document grid for QAS
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QASDocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bnrqasupervisoraction").setRequiredLevel("required");
    var QASupervisorAction = Xrm.Page.getAttribute("dobnyc_bnrqasupervisoraction").getValue();

    switch (QASupervisorAction) {
        //Assign QA
        case 1:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("required");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
            //Incomplete Submission
        case 2:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //none
        default:
            Xrm.Page.getControl("dobnyc_bt_assignto").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_bt_assignto").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }
}



function BNRQAReview() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("QADocumentSection").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bnrqareviewaction").setRequiredLevel("required");

    var QAReviewAction = Xrm.Page.getAttribute("dobnyc_bnrqareviewaction").getValue();

    switch (QAReviewAction) {
        //Assign QA
        case 1:
            Xrm.Page.getControl("dobnyc_jobfilingnumber").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_jobfilingnumber").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //Incomplete Submission
        case 2:
            Xrm.Page.getControl("dobnyc_jobfilingnumber").setVisible(true);
            Xrm.Page.getAttribute("dobnyc_jobfilingnumber").setRequiredLevel("required");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
            //none
        case 3:
            Xrm.Page.getControl("dobnyc_jobfilingnumber").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_jobfilingnumber").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("required");
            break;
        default:
            Xrm.Page.getControl("dobnyc_jobfilingnumber").setVisible(false);
            Xrm.Page.getAttribute("dobnyc_jobfilingnumber").setRequiredLevel("none");
            Xrm.Page.getAttribute("dobnyc_bt_comments").setRequiredLevel("none");
            break;
    }

}

function BNRInspectorReview() {
    //set Document grid for QA
    Xrm.Page.ui.tabs.get("MasterTab").sections.get("InspectionDocumentSections").setVisible(true);

    Xrm.Page.getAttribute("dobnyc_bt_bnrinspectionsupervisoraction").setRequiredLevel("required");
    var InspectionSupAction = Xrm.Page.getAttribute("dobnyc_bt_bnrinspectionsupervisoraction").getValue();
    if (InspectionSupAction != null) {
        switch (InspectionSupAction) {
            case 7:
                Xrm.Page.getControl("dobnyc_deviceid").setVisible(false);
                Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("none");
                break;
            case 8:
                Xrm.Page.getControl("dobnyc_deviceid").setVisible(false);
                Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("none");
                break;
            case 9:
                var results = areDocumentsApproved("dobnyc_bt_bnrinspectionsupervisoraction", "dobnyc_bdl_inspectorreviewtask");
                if (results) {
                    Xrm.Page.getControl("dobnyc_deviceid").setVisible(true);
                    Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("required");
                }
                break;
            case 10:
                areDocumentsApproved("dobnyc_bt_bnrinspectionsupervisoraction", "dobnyc_bdl_inspectorreviewtask");
                Xrm.Page.getControl("dobnyc_deviceid").setVisible(false);
                Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("none");
                break;
            case 11:
                var results = areDocumentsApproved("dobnyc_bt_bnrinspectionsupervisoraction", "dobnyc_bdl_inspectorreviewtask");
                if (results) {
                    Xrm.Page.getControl("dobnyc_deviceid").setVisible(true);
                    Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("required");
                }
                break;
            default:
                Xrm.Page.getControl("dobnyc_deviceid").setVisible(false);
                Xrm.Page.getAttribute("dobnyc_deviceid").setRequiredLevel("none");

                break;
        }
    }

}

function validateDeviceFromBIS(e) {
    var validDevice = true;
    var deviceID = Xrm.Page.getAttribute("dobnyc_deviceid").getValue();
    var URL = getMessage("ValidateDeviceFromBISURL");
    if (deviceID) {
        $.support.cors = true;

        $.ajax({
            type: "POST",
            url: "http://msdwva-dobcrm04.buildings.nycnet:5050/FacadesWrapper/FacadesWrapper.svc/ValidateBoiler",
            processData: true,
            crossDomain: true,
            contentType: "application/json;charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ DeviceId: deviceID }),
            cache: false,
            async: false,
            beforeSend: function (XMLHttpRequest) {
                XMLHttpRequest.setRequestHeader("Accept", "application/json, text/plain, */*");
            },
            success: function (data, textStatus, XmlHttpRequest) {
                if (data.IsSuccess == true) {
                    validDevice = true;
                    alert("Valid BIS Device");
                }
                else {


                    alert("Not Valid BIS Device");
                    Xrm.Page.getAttribute("dobnyc_deviceid").setValue(null);
                    validDevice = false;

                }
            },
            error: function (xhr, status, error) {
                alert(error);
                alert("An error occurred while validating Device ID. Please try again or contact administrator.");
                Xrm.Page.getAttribute("dobnyc_deviceid").setValue(null);
            }
        });
    }


}



function getMessage(key) {
    /// get Data from configuration entity
    var returnValue = null;
    returnValue = retrieveMultipleCustom("dobnyc_customconfigurationsSet", "?$filter=dobnyc_Key eq '" + key + "' and dobnyc_LangugaeCode eq '" + Xrm.Page.context.getUserLcid() + "'");

    if (returnValue != null && returnValue[0] != null)
        return returnValue[0].dobnyc_name;

    return "Unable to get configuration message for Key : " + key + ".";
}



function LdCSS() {

    var path = "/WebResources/dobnyc_custom";
    var head = document.getElementsByTagName('head')[0];
    var link = document.createElement('link');
    link.rel = 'stylesheet';
    link.type = 'text/css';
    link.href = path;
    link.media = 'all';
    head.appendChild(link);
}

function GetRelatedDocumentList(taskId, taskReviewField) {
    fetchXml = '<fetch version="1.0">' +
        '<entity name="dobnyc_boilerdocumentlist" >' +
            '<attribute name="dobnyc_boilerdocumentlistid" />' +
            '<attribute name="dobnyc_bdl_documentstatus" />' +
            '<filter type="and">' +
                '<condition attribute="' + taskReviewField + '" operator="eq" value="' + taskId + '" />' +
            '</filter>' +
          '</entity>' +
        '</fetch>';
    var documents = XrmServiceToolkit.Soap.Fetch(fetchXml);
    return documents;
}

function areDocumentsApproved(taskReviewAction, taskReviewField) {
    var taskId = Xrm.Page.data.entity.getId();
    var nextAction = Xrm.Page.getAttribute(taskReviewAction).getValue();
    if (nextAction == null)
        return true;//false;
    var documents = GetRelatedDocumentList(taskId, taskReviewField);
    // if (documents.length == 0) {
    // alert("Documents List must contains Documents");
    // Xrm.Page.getAttribute(taskReviewAction).setValue(null);
    // return false;
    // }
    var isApproved = true;
    for (i = 0; i < documents.length; i++) {
        var statusValue = documents[i].attributes['dobnyc_bdl_documentstatus'].value;
        if (statusValue != 3) {
            isApproved = false;
        }
    }
    if (!isApproved) {
        alert("Must approve all documents in the Document List");
        Xrm.Page.getAttribute(taskReviewAction).setValue(null);
    }
    return isApproved;
}

function AcceptDocument() {
    debugger;
    var isValidRole = checkSecurityRole();
    if (isValidRole) {
        var DocumentURL = Xrm.Page.getAttribute("dobnyc_bdl_documenturl").getValue();
        var DocumentViewed = Xrm.Page.getAttribute("dobnyc_bdl_isdocumentviewed").getText();
        /* if (DocumentURL == null) {
             alert("There is no document uploaded to be accepted!");
             return;
         }*/
        if (DocumentViewed == "Yes") {
            var message = "Would you like to accept this document?";
            Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
            function yesCloseCallback() {
                Xrm.Page.getAttribute("dobnyc_bdl_documentstatus").setSubmitMode("always");
                Xrm.Page.getAttribute("dobnyc_bdl_documentstatus").setValue(3);
                Xrm.Page.data.entity.save();
            }
            function noCloseCallback() {
                return;
            }
        }
        else {
            alert("Please view the Document at least once before accepting it");
        }

    }
    else {
        alert("insufficient privileges. Please Contact Administrator. ");
    }



}
function RejectDocument() {
    debugger;
    var isValidRole = checkSecurityRole();
    if (isValidRole) {
        var lookup = new Array();
        lookup[0] = new Object();
        lookup[0].id = Xrm.Page.context.getUserId();
        lookup[0].name = Xrm.Page.context.getUserName();
        lookup[0].entityType = "systemuser";
        var loginId = lookup[0].id;
        var ViewedbyId = getLookupId("dobnyc_bdl_viewedby");
        if (ViewedbyId != loginId) {
            alert("Please view document first before Rejecting!");
            return;
        }
        var message = "Would you like to reject this document?";
        Xrm.Utility.confirmDialog(message, yesCloseCallback, noCloseCallback);
        function yesCloseCallback() {
            Xrm.Page.getAttribute("dobnyc_bdl_documentstatus").setSubmitMode("always");
            Xrm.Page.getAttribute("dobnyc_bdl_documentstatus").setValue(4);
            Xrm.Page.data.entity.save();
        }
        function noCloseCallback() {
            return;
        }

    }
    else {
        alert("insufficient privileges. Please Contact Administrator. ");

    }
}

function checkSecurityRole() {
    var isValidRole = false;
    var currentUserRoles = Xrm.Page.context.getUserRoles();
    for (var i = 0; i < currentUserRoles.length; i++) {
        var userRoleId = currentUserRoles[i];
        var userRoleName = GetRoleName(userRoleId);
        if (userRoleName == "BOILER - Inspection Supervisor" || userRoleName == "BOILER - QA Clerk" || userRoleName == "BOILER - QA Supervisor") {
            return true;
        }

    }
    return isValidRole;
}


function GetRoleName(RoleId) {
    //eSet?$select=Name&$filter=RoleId eq (guid'dgffsdgdfgdf')", 
    var returnValue = retrieveMultipleCustom("RoleSet", "?select=Name&$filter=RoleId eq guid'" + RoleId + "'");
    if (returnValue != null && returnValue[0] != null) {
        // alert("Role name: " + returnValue[0].Name);
        return returnValue[0].Name;
    }
}


